---
act: product-digitalisation-directive
version: 2025-05-21_com-proposal
stage: com-proposal
language: de
celex: 52025PC0503
title: Vorschlag für eine RICHTLINIE DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Änderung der Richtlinien 2000/14/EG, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU und 2014/90/EU des Europäischen Parlaments und des Rates im Hinblick auf die Digitalisierung und gemeinsame Spezifikationen
retrieved: '2026-09-24'
converter: tools/eurlex2md.py
counts:
  recitals: 18
  articles: 17
  annexes: 13
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52025PC0503
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# Vorschlag für eine RICHTLINIE DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Änderung der Richtlinien 2000/14/EG, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU und 2014/90/EU des Europäischen Parlaments und des Rates im Hinblick auf die Digitalisierung und gemeinsame Spezifikationen

<a id="begr-ndung"></a>
## BEGRÜNDUNG

### (1) KONTEXT DES VORSCHLAGS

#### • Gründe und Ziele des Vorschlags

Die Kommission hat in ihrer Mitteilung „Langfristige Wettbewerbsfähigkeit der EU: Blick über 2030 hinaus“^(1) betont, wie wichtig ein Regelungsrahmen ist, mit dem sichergestellt wird, dass Ziele zu möglichst geringen Kosten erreicht werden. Sie hat sich daher verpflichtet, entsprechende Anstrengungen zur Rationalisierung und Vereinfachung der Berichtspflichten und des Verwaltungsaufwands zu unternehmen, um solche Pflichten letztlich um 25 % zu verringern, ohne dass die jeweiligen politischen Ziele untergraben werden.

Berichtspflichten spielen eine wichtige Rolle bei der Sicherstellung der ordnungsgemäßen Durchsetzung und Überwachung der Rechtsvorschriften. Die Kosten der Berichterstattung werden insgesamt weitgehend durch die damit verbundenen Vorteile ausgeglichen, insbesondere im Hinblick auf die Überwachung und die Sicherstellung der Einhaltung der wichtigsten politischen Maßnahmen. Allerdings können Berichtspflichten für die Beteiligten auch mit unverhältnismäßig hohen Belastungen einhergehen, was insbesondere für KMU und Kleinstunternehmen gilt. Wenn im Laufe der Zeit immer neue Berichtspflichten hinzukommen, können redundante oder veraltete Verpflichtungen, ineffiziente Berichtsintervalle und Zeitvorgaben oder auch ungeeignete Erfassungsmethoden die Folge sein. Die Kommission fördert in ihrer Digitalstrategie/Besseren Rechtsetzung den Grundsatz „standardmäßig digital“, um den digitalen Wandel zu unterstützen und digitalfähige Maßnahmen zu erleichtern, die der sich rasch wandelnden Welt der Digitalisierung und Technologie Rechnung tragen und standardmäßig digital, interoperabel, zukunftssicher und agil sind^(2).

In der Mitteilung „Ein Kompass für eine wettbewerbsfähige EU“^(3) wird hervorgehoben, dass die Digitalisierung mit Vereinfachungen einhergehen muss, um die Berichtspflichten zu verringern. In der Mitteilung wird betont, dass die Berichterstattung auf digitale Formate auf der Grundlage standardisierter Daten umgestellt werden sollte. Dort, wo schon heute digitale Verfahren existieren, erschweren allerdings Faktoren wie fragmentierte IT-Systeme und ineffiziente Datenaustauschprozesse den Unternehmen die digitale Interaktion mit den Behörden.

Mit der anstehenden Initiative „Europäische Brieftaschen für Unternehmen“ werden diese Herausforderungen angegangen, indem eine digitale Identität für alle Wirtschaftsakteure eingeführt und ein Rahmen für interoperable Unternehmensbrieftaschen geschaffen wird, sodass verifizierte Daten und Berechtigungsnachweise ausgetauscht werden können, wodurch nahtlose digitale Interaktionen zwischen Wirtschaftsakteuren und öffentlichen Verwaltungen in der gesamten Union ermöglicht werden. Auf diese Weise werden die Europäischen Unternehmensbrieftaschen auf den bereits bestehenden digitalen Lösungen aufbauen, mit denen die alltäglichen Tätigkeiten für europäische Wirtschaftsakteure vereinfacht werden sollen, wie das zentrale digitale Zugangstor, das technische System „Once Only Technical System“ („OOTS“), der digitale Produktpass („DPP“) und die elektronische Rechnungstellung, wodurch ein kohärentes Ökosystem digitaler Lösungen geschaffen wird, das Synergien maximiert und eine stärkere wirtschaftliche Integration und Innovation in ganz Europa fördert.

Es gibt jedoch nach wie vor zahlreiche EU-Rechtsvorschriften, in denen die Verwendung des Papierformats vorgesehen ist.

Die Streichung von Verweisen auf das Papierformat würde auch die Behörden dazu zwingen, die Art und Weise zu überdenken, wie sie eingereichte Unterlagen oder Berichte von Unternehmen bearbeiten. Die Vereinfachung solcher Übermittlungen und Meldungen durch die Förderung der standardmäßigen Digitalisierung würde neue Anreize für Investitionen in die Datenerfassung und -verarbeitung mittels E-Government-Lösungen schaffen, die den Weg zu einem dokumentenfreien Binnenmarkt auf der Grundlage interoperabler strukturierter Daten und des Grundsatzes der einmaligen Erfassung ebnen könnten.

Während der neue Rechtsrahmen (NLF – New Legislative Framework) kein bestimmtes Format für die den Produkten beiliegenden Gebrauchsanweisungen vorschreibt, hat die Praxis gezeigt, dass die meisten Marktüberwachungsbehörden erwarten, dass diese Anleitungen in Papierform vorliegen, weshalb dieses Format den Herstellern vorgeschrieben wird.

Der Blue Guide^(4) enthält ausführliche Erläuterungen zu den EU-Produktvorschriften.

Angesichts der Tatsache, dass im Jahr 2024 nicht weniger als 94 % der EU-Haushalte über einen Internetzugang verfügten^(5), ist das Papierformat der Gebrauchsanweisungen, die den unter die Richtlinien fallenden Produkten beizufügen sind, veraltet und entspricht nicht mehr den aktuellen Technologien, Verbrauchergewohnheiten oder ökologischen Zielen.

Folglich sollten Hersteller die Möglichkeit haben, für Gebrauchsanweisungen ein digitales Format zu wählen. Wenn sich Hersteller für die Bereitstellung von Gebrauchsanweisungen in digitaler Form entscheiden, sollten die Sicherheitsinformationen (einschließlich aller Teile der Gebrauchsanweisungen, die für die Sicherheit als unerlässlich erachtet werden) weiterhin in Papierform bereitgestellt werden, um die Sicherheit der Verbraucher zu schützen. Darüber hinaus sollten Endnutzer auf Anfrage – zum Zeitpunkt des Kaufs und für einen bestimmten Zeitraum nach dem Kauf – eine Kopie der Anleitung in Papierform erhalten können.

Die Straffung der Berichterstattungspflichten, die Verringerung des Verwaltungsaufwands und die Förderung der Digitalisierung sind Prioritäten. Vor diesem Hintergrund wird mit dem vorliegenden Vorschlag eine Vereinfachung der Initiativen angestrebt, die unter dem übergeordneten Ziel „Ein neuer Plan für nachhaltigen Wohlstand und nachhaltige Wettbewerbsfähigkeit in Europa“ im Politikbereich Binnenmarkt, Lebensmittelsicherheit und Gesundheit verfolgt werden und eine Vielzahl von Sektoren betreffen.

Darüber hinaus wurde in der Mitteilung „Ein Kompass für eine wettbewerbsfähige EU“ festgestellt, dass alternative Optionen gesucht werden müssen, um Unternehmen Rechtssicherheit in Bezug auf die Einhaltung der EU-Vorschriften in Situationen zu geben, in denen es keine harmonisierten Normen gibt, sie nicht verfügbar sind, nicht ausreichen oder dringend erforderlich sind. Mehrere bestehende Rechtsakte enthalten bereits eine alternative Option, um Unternehmen Rechtssicherheit zu bieten und die Einhaltung der EU-Rechtsvorschriften nachzuweisen, damit solchen Situationen Rechnung getragen werden kann. Ziel des vorliegenden Vorschlags ist die Angleichung der alternativen Option in Rechtsakten, die keine alternative Option zu harmonisierten Normen vorsehen. Die alternative Option ist hinsichtlich ihrer Definition, ihrer Rechtswirkung, der Bedingungen, unter denen sie gewählt werden kann, und des Verfahrens für ihre Annahme einheitlich umzusetzen. Die Initiative für gemeinsame Spezifikationen steht voll und ganz im Einklang mit dem oben genannten Bedarf und zielt darauf ab, das Leben von Unternehmen zu vereinfachen, die eine oder mehrere produktspezifische Gesundheits- und Sicherheitsanforderungen erfüllen müssen, wie sie in sektorspezifischen Verordnungen, in denen harmonisierte Normen verwendet werden, verankert sind.

Mit dem Vorschlag wird darauf abgezielt, die Verpflichtungen der Wirtschaftsakteure gemäß der Richtlinie 2000/14/EG über umweltbelastende Geräuschemissionen von zur Verwendung im Freien vorgesehenen Geräten und Maschinen^(6), der Richtlinie 2010/35/EU über ortsbewegliche Druckgeräte^(7), der Richtlinie 2011/65/EU über die Beschränkung der Verwendung bestimmter gefährlicher Stoffe in Elektro- und Elektronikgeräten^(8), der Richtlinie 2013/53/EU über Sportboote und Wassermotorräder^(9), der Richtlinie 2014/29/EU über einfache Druckbehälter^(10), der Richtlinie 2014/30/EU über die elektromagnetische Verträglichkeit^(11), der Richtlinie 2014/31/EU über nichtselbsttätige Waagen^(12), der Richtlinie 2014/32/EU über Messgeräte^(13), der Richtlinie 2014/33/EU über Aufzüge und Sicherheitsbauteile für Aufzüge^(14), der Richtlinie 2014/34/EU über Geräte und Schutzsysteme zur bestimmungsgemäßen Verwendung in explosionsgefährdeten Bereichen^(15), der Richtlinie 2014/35/EU über elektrische Betriebsmittel zur Verwendung innerhalb bestimmter Spannungsgrenzen^(16), der Richtlinie 2014/53/EU über Funkanlagen^(17), der Richtlinie 2014/68/EU über Druckgeräte^(18) und der Richtlinie 2014/90/EU über Schiffsausrüstung^(19) durch eine Kombination von Maßnahmen zu vereinfachen und zu digitalisieren.

Darüber erfolgt durch den Vorschlag eine einheitliche Angleichung der bestehenden Ausnahmeregelung an die harmonisierten Normen in der Richtlinie 2011/65/EU über die Beschränkung der Verwendung bestimmter gefährlicher Stoffe in Elektro- und Elektronikgeräten, der Richtlinie 2013/53/EU über Sportboote und Wasserskooter, der Richtlinie 2014/29/EU über einfache Druckbehälter, der Richtlinie 2014/30/EU über die elektromagnetische Verträglichkeit, Richtlinie 2014/31/EU über nichtselbsttätige Waagen, Richtlinie 2014/32/EU über Messgeräte, Richtlinie 2014/33/EU über Aufzüge, Richtlinie 2014/34/EU über ATEX, Richtlinie 2014/35/EU über Niederspannung, Richtlinie 2014/53/EU über Funkanlagen und Richtlinie 2014/68/EU über Druckgeräte.

Um Unstimmigkeiten und einen zusätzlichen Aufwand für die Hersteller zu vermeiden und eine allgemeine Kohärenz zwischen den harmonisierten Produktvorschriften im Rahmen des neuen Rechtsrahmens (NLF) zu schaffen, muss eine Bestimmung eingeführt werden, die die Verwendung des Datenträgers des DPP ermöglicht, wenn ein solcher DPP durch eine andere Rechtsvorschrift, die dasselbe Produkt abdeckt, verbindlich vorgeschrieben wird.

#### • Kohärenz mit den bestehenden Vorschriften in diesem Bereich

Der Vorschlag ist Teil eines Maßnahmenpakets zur Vereinfachung. Dies ist ein Schritt in einem kontinuierlichen Prozess, bei dem die bestehenden Berichtspflichten umfassend überprüft werden, um zu bewerten, ob sie weiterhin relevant sind, und sie effizienter zu gestalten.

Die mit diesen Maßnahmen eingeführte Rationalisierung wird die Verwirklichung der Ziele in diesem Politikbereich aus folgenden Gründen nicht beeinträchtigen:

- Die wesentlichen Informationen, die erforderlich sind, um die Einhaltung der EU-Rechtsvorschriften sicherzustellen, werden den zuständigen Behörden und den Endnutzern weiterhin zur Verfügung gestellt.

- Die erhöhte Effizienz der Meldeverfahren wird die Digitalisierung der Meldungen der Unternehmen an die Behörden erleichtern, den Verwaltungsaufwand für die Unternehmen verringern und die allgemeine Wirksamkeit des Rechtsrahmens verbessern.

- Durch die Maßnahmen wird auch ein einheitlicherer und harmonisierterer Ansatz für die Verpflichtungen der Wirtschaftsakteure gemäß verschiedenen EU-Rechtsvorschriften gefördert, wodurch Verwirrung verringert und für Unternehmen, die in mehreren Bereichen tätig sind, die Einhaltung der Vorschriften erleichtert wird.

- Darüber hinaus werden in Fällen, in denen keine harmonisierten Normen vorliegen, gemeinsame Spezifikationen akzeptiert, um die Kohärenz mit bestehenden Rechtsvorschriften in bestimmten sektoralen Bereichen sicherzustellen und den Unternehmen Flexibilität beim Nachweis der Konformität zu gewähren.

#### • Kohärenz mit der Politik der Union in anderen Bereichen

Im Rahmen des Programms zur Gewährleistung der Effizienz und Leistungsfähigkeit der Rechtsetzung (REFIT) stellt die Kommission sicher, dass ihre Rechtsvorschriften ihren Zweck erfüllen, auf die Bedürfnisse der Interessenträger zugeschnitten sind sowie den Aufwand minimieren und gleichzeitig ihre Ziele erreichen. Dieser Vorschlag ist daher Teil des REFIT-Programms, mit dem darauf abgezielt wird, den sich aus den Rechtsvorschriften der Union ergebenden Berichtsaufwand zu verringern.

Bestimmte Pflichten sind zwar von wesentlicher Bedeutung, doch sollten sie so effizient wie möglich sein, und es müssen Überschneidungen vermieden, unnötige Belastungen beseitigt und so weit wie möglich digitale und interoperable Lösungen genutzt werden.

Mit dem vorliegenden Vorschlag werden die Berichtspflichten rationalisiert, sodass die Ziele der Rechtsvorschriften effizienter und mit weniger Aufwand für die Unternehmen und die Behörden erreicht werden.

In Fällen, in denen keine harmonisierten Normen verfügbar sind, sind alternative Lösungen erforderlich, um die Einhaltung der Rechtsvorschriften der Union sicherzustellen. Diese Alternativen sollten so wirksam wie möglich sein, unnötige Komplexität minimieren und innerhalb kurzer Fristen verfügbar sein.

Mit der Einführung dieser alternativen Lösungen wird die Einhaltung der Rechtsvorschriften der Union vereinfacht, sodass sie für Unternehmen und Behörden effizienter und weniger aufwendig wird.

### (2) RECHTSGRUNDLAGE, SUBSIDIARITÄT UND VERHÄLTNISMÄẞIGKEIT

#### • Rechtsgrundlage

Der Vorschlag stützt sich auf Artikel 114 des Vertrags über die Arbeitsweise der Europäischen Union im Einklang mit den ursprünglichen Rechtsgrundlagen für die Annahme der sektorspezifischen Rahmenregelungen, die mit dem vorliegenden Vorschlag geändert werden sollen. Bei diesen sektorspezifischen Rahmen handelt es sich um die Richtlinie 2000/14/EG über umweltbelastende Geräuschemissionen von zur Verwendung im Freien vorgesehenen Geräten und Maschinen, die Richtlinie 2011/65/EU zur Beschränkung gefährlicher Stoffe in Elektro- und Elektronikgeräten, die Richtlinie 2013/53/EU über Sportboote und Wassermotorräder, die Richtlinie 2014/29/EU über einfache Druckbehälter, die Richtlinie 2014/30/EU über elektromagnetische Verträglichkeit, die Richtlinie 2014/31/EU über nichtselbsttätige Waagen, die Richtlinie 2014/32/EU über Messgeräte, die Richtlinie 2014/33/EU über Aufzüge und Sicherheitsbauteile für Aufzüge, die Richtlinie 2014/34/EU über Geräte und Schutzsysteme zur bestimmungsgemäßen Verwendung in explosionsgefährdeten Bereichen, die Richtlinie 2014/35/EU über elektrische Betriebsmittel zur Verwendung innerhalb bestimmter Spannungsgrenzen, die Richtlinie 2014/53/EU über Funkanlagen, die Richtlinie 2014/68/EU über Druckgeräte und die Richtlinie 2014/90/EU über Schiffsausrüstung.

Bei den sektorspezifischen Rahmen der Union, die in den oben genannten Richtlinien festgelegt sind, handelt es sich um sogenannte „Harmonisierungsrechtsvorschriften für Produkte“. Sie enthalten harmonisierte Vorschriften für den Entwurf, die Herstellung, die Konformitätsbewertung und das Inverkehrbringen von Produkten. Im Wesentlichen werden mit diesen sektorspezifischen Rahmenregelungen für jeden Sektor/jede Produktkategorie die grundlegenden Anforderungen von öffentlichem Interesse, die die Produkte erfüllen sollten, sowie die Verfahren zur Bewertung der Einhaltung dieser Anforderungen eingeführt.

Ein weiteres gemeinsames Merkmal dieser Rahmen ist, dass sie mehr oder weniger eng mit den allgemeinen Grundsätzen und der Referenzbestimmung des NLF im Einklang stehen. Der NLF für EU-Produktvorschriften besteht aus zwei Rechtsakten, die 2008 verabschiedet wurden: dem Beschluss Nr. 768/2008/EG des Europäischen Parlaments und des Rates über einen gemeinsamen Rahmen für die Vermarktung von Produkten^(20), der Referenzvorschriften für die Ausarbeitung von Rechtsvorschriften der Union zur Harmonisierung der Bedingungen für die Vermarktung von Produkten enthält, sowie die Verordnung (EG) Nr. 765/2008 des Europäischen Parlaments und des Rates über die Vorschriften für die Akkreditierung und Marktüberwachung im Zusammenhang mit der Vermarktung von Produkten^(21), in der die Grundsätze für die CE-Kennzeichnung und die Akkreditierung von Konformitätsbewertungsstellen festgelegt sind.

Dank des NLF enthalten alle oben genannten Rechtsvorschriften, die von diesem Vorschlag betroffen sind, ähnliche Bestimmungen. Die betreffenden Rechtsakte stehen mit Ausnahme der Richtlinie 2000/14/EG im Einklang mit dem NLF, weisen eine gemeinsame Struktur auf und enthalten Bestimmungen, die auf demselben Modell beruhen. Daher sind die Pflichten der Wirtschaftsakteure, die Bestimmungen über benannte Konformitätsbewertungsstellen, die Akkreditierung und die CE-Kennzeichnung in all diesen Rechtsakten identisch oder sehr ähnlich. Diese Einheitlichkeit erleichtert die Vertrautheit mit den verschiedenen Rechtsinstrumenten, insbesondere für Unternehmen, die Produkte herstellen oder vertreiben, die mehreren EU-Rechtsakten unterliegen. Die Kohärenz dieser Elemente ermöglicht es den Wirtschaftsakteuren, sich leichter in der regulatorischen Landschaft zurechtzufinden, wodurch die Komplexität verringert und die Einhaltung der Vorschriften gefördert wird. Da die Musterbestimmungen jedoch im Jahr 2008 festgelegt wurden, sind bestimmte Aspekte der Verpflichtungen im Laufe der Zeit überflüssig oder veraltet geworden, sodass eine Überprüfung und Aktualisierung erforderlich ist, um ihre fortdauernde Relevanz und Wirksamkeit sicherzustellen.

Für den Bereich Schiffsausrüstung gelten besondere Anforderungen in Bezug auf die Sicherheit an Bord von EU-Schiffen, die in der Richtlinie 2014/90/EU festgelegt sind. Daher enthält diese Richtlinie spezifische Vorschriften, die sich von anderen an den NLF angeglichenen Rechtsvorschriften unterscheiden. Eine solche Vorschrift ist die Verpflichtung, an Bord eines EU-Schiffes ein Papierexemplar der Konformitätserklärung aufzubewahren, bis die Schiffsausrüstung entfernt wird. Die Datenbank der Europäischen Agentur für die Sicherheit des Seeverkehrs, die den Flaggenstaaten der Mitgliedstaaten und den Marktüberwachungsbehörden zur Verfügung steht, ist jedoch für den elektronischen Datenaustausch geeignet, sodass diese Verpflichtung an das digitale Zeitalter angepasst werden muss. Durch das Hochladen eines Exemplars der Konformitätserklärung in diese Datenbank können die erforderlichen Überprüfungen und Kontrollen der Schiffsausrüstung auf dem Schiff elektronisch durchgeführt werden. Dieser Ansatz wird auch dazu beitragen, eine einheitliche Anwendung und ein einheitliches Verfahren im Rahmen dieser Rechtsvorschriften sicherzustellen, das Verfahren zu straffen und den Verwaltungsaufwand zu verringern.

Die Änderung der oben genannten Richtlinien in der vorgeschlagenen Weise, d. h. die Abschaffung papiergestützter Verpflichtungen und der Übergang zu digitalen Entsprechungen, wird zur Digitalisierung der Berichterstattung der Unternehmen an die Behörden beitragen, die Digitalisierung der Pflichten und Meldeverfahren der Wirtschaftsakteure erleichtern und die allgemeine Effizienz und Wirksamkeit des Rechtsrahmens verbessern.

#### • Subsidiarität (bei nicht ausschließlicher Zuständigkeit)

Die betreffenden Berichtspflichten und Pflichten der Wirtschaftsakteure sind durch Unionsrecht vorgeschrieben und können daher nur auf Unionsebene geändert werden. Die Mitgliedstaaten, Unternehmen und Verbraucher werden von der Streichung von Verweisen auf das Papierformat und der Digitalisierung der EU-Konformitätserklärung für die Wirtschaftsakteure, die Gegenstand dieses Vorschlags sind, profitieren.

#### • Verhältnismäßigkeit

Die Rationalisierung und Digitalisierung der Berichtspflichten und der Verpflichtungen der Wirtschaftsakteure vereinfachen den Rechtsrahmen, indem nur minimale Änderungen an den bestehenden Anforderungen vorgenommen werden, die den Inhalt des übergeordneten politischen Ziels nicht beeinträchtigen. Der Vorschlag beschränkt sich daher auf jene Änderungen, die zur Sicherstellung der Effizienz erforderlich sind, lässt jedoch alle wesentlichen Elemente der betreffenden Rechtsvorschriften unberührt.

Mit den Änderungen werden nur minimale Änderungen an den bestehenden Anforderungen vorgenommen, wobei der Schwerpunkt ausschließlich auf der Abschaffung von Verweisen auf Unterlagen in Papierform und der Digitalisierung der EU-Konformitätserklärung und der Gebrauchsanweisungen liegt. Durch die Beschränkung des Vorschlags auf diese notwendigen Änderungen stellt die Kommission sicher, dass die Änderungen in einem angemessenen Verhältnis zu den angestrebten Zielen stehen und die Erreichung der politischen Ziele nicht gefährden.

Gemeinsame Spezifikationen als Ausweichoption für harmonisierte Normen vereinfachen den Rechtsrahmen, indem die Kohärenz im Binnenmarkt in Ermangelung verfügbarer harmonisierter Normen sichergestellt wird. Der Vorschlag beschränkt sich daher auf jene Änderungen, die zur Sicherstellung der Effizienz erforderlich sind, lässt jedoch alle wesentlichen Elemente der betreffenden Rechtsvorschriften unberührt.

Mit den Änderungen werden minimale Änderungen an den bestehenden Rechtsvorschriften vorgenommen, wobei der Schwerpunkt ausschließlich auf der Angleichung in Bezug auf gemeinsame Spezifikationen in den Binnenmarktvorschriften liegt. Durch die Beschränkung des Vorschlags auf diese notwendigen Änderungen stellt die Kommission sicher, dass die Änderungen in einem angemessenen Verhältnis zu den angestrebten Zielen stehen und die Erreichung der politischen Ziele nicht gefährden.

#### • Wahl des Instruments

Alle durch diesen Rechtsakt zu ändernden Richtlinien, nämlich die Richtlinie 2000/14/EG über umweltbelastende Geräuschemissionen von zur Verwendung im Freien vorgesehenen Geräten und Maschinen, die Richtlinie 2011/65/EU zur Beschränkung gefährlicher Stoffe in Elektro- und Elektronikgeräten, die Richtlinie 2013/53/EU über Sportboote, die Richtlinie 2014/29/EU über einfache Druckbehälter, die Richtlinie 2014/30/EU über elektromagnetische Verträglichkeit, die Richtlinie 2014/31/EU über nichtselbsttätige Waagen, die Richtlinie 2014/32/EU über Messgeräte, die Richtlinie 2014/33/EU über Aufzüge und Sicherheitsbauteile für Aufzüge, die Richtlinie 2014/34/EU über Geräte und Schutzsysteme zur bestimmungsgemäßen Verwendung in explosionsgefährdeten Bereichen, die Richtlinie 2014/35/EU über elektrische Betriebsmittel zur Verwendung innerhalb bestimmter Spannungsgrenzen, die Richtlinie 2014/53/EU über Funkanlagen, die Richtlinie 2014/68/EU über Druckgeräte und die Richtlinie 2014/90/EU über Schiffsausrüstungen sind harmonisierte Produktvorschriften im Rahmen der Binnenmarktvorschriften, von denen die meisten an den NLF angeglichen sind.

Die im November 2022 veröffentlichte Evaluierung des NLF ergab, dass der NLF die EU-Produktvorschriften erfolgreich harmonisiert hat, was zu einem kohärenteren Rahmen geführt hat, der seit 2008 zu einer Verringerung des Aufwands und zu Kosteneinsparungen sowohl für Unternehmen als auch für Behörden geführt hat. Die Bewertung hat jedoch auch gezeigt, dass die veralteten Anforderungen des NLF, wie beispielsweise papiergestützte Dokumentation und Korrespondenz hinderlich sind, wenn es darum geht, mit der Digitalisierung Schritt zu halten und modernen Erwartungen gerecht zu werden.

Die durch diesen Rechtsakt in Bezug auf die Angleichung an gemeinsame Spezifikationen zu ändernden Richtlinien, nämlich die Richtlinie 2000/14/EG über umweltbelastende Geräuschemissionen von zur Verwendung im Freien vorgesehenen Geräten und Maschinen, die Richtlinie 2011/65/EU zur Beschränkung gefährlicher Stoffe in Elektro- und Elektronikgeräten, die Richtlinie 2013/53/EU über Sportboote, die Richtlinie 2014/29/EU über einfache Druckbehälter, die Richtlinie 2014/30/EU über die elektromagnetische Verträglichkeit und die Richtlinie 2014/31/EU über nichtselbsttätige Waagen, die Richtlinie 2014/32/EU über Messgeräte, die Richtlinie 2014/33/EU über Aufzüge und Sicherheitsbauteile für Aufzüge, die Richtlinie 2014/34/EU über Geräte und Schutzsysteme zur bestimmungsgemäßen Verwendung in explosionsgefährdeten Bereichen, die Richtlinie 2014/35/EU über elektrische Betriebsmittel zur Verwendung innerhalb bestimmter Spannungsgrenzen, die Richtlinie 2014/53/EU über Funkanlagen, die Richtlinie 2014/68/EU über Druckgeräte und die Richtlinie 2014/90/EU über Schiffsausrüstungen sind harmonisierte Produktvorschriften im Rahmen der Binnenmarktvorschriften und enthalten das Konzept der harmonisierten Normen und der Konformitätsvermutung.

Zusammenfassend kann festgestellt werden, dass dieser Omnibus-Vorschlag als angemessen und effizient einzustufen ist, da auf diese Weise die betreffenden Rechtsvorschriften an künftige Erfordernisse angepasst werden können und ihre Relevanz erhalten bleibt, indem veraltete Verweise, beispielsweise auf Papierformate, gestrichen werden.

### (3) ERGEBNISSE DER EX-POST-BEWERTUNG, DER KONSULTATION DER INTERESSENTRÄGER UND DER FOLGENABSCHÄTZUNG

#### • Ex-post-Bewertung/Eignungsprüfungen bestehender Rechtsvorschriften

Nicht zutreffend

#### • Konsultation der Interessenträger

Am 14. April 2025 organisierte die Kommission im Rahmen der Task Force 1 des Industrieforums eine Outreach-Veranstaltung.

Die Mitgliedstaaten, Industrieverbände, Hersteller und Verbraucherverbände wurden eingeladen, an der Veranstaltung teilzunehmen und Stellungnahmen zur Digitalisierung der Berichterstattung und der Pflichten der Hersteller abzugeben. Insbesondere wurden sie gefragt, ob die Bereitstellung der Konformitätserklärung und der Gebrauchsanweisung in elektronischer Form ihrer Meinung nach als Erleichterung anzusehen wäre.

Die während der Outreach-Veranstaltung eingegangenen Antworten zeigen, dass die Interessenträger die Digitalisierung als eine Form der Verringerung des Verwaltungsaufwands weitgehend befürworten, wobei die überwiegende Mehrheit der Befragten die Digitalisierung als wirksames Mittel zur Verringerung des Verwaltungsaufwands ansieht. Darüber hinaus gab die Mehrheit der Befragten an, dass sie die digitale Konformitätserklärung und die Option, digitale Gebrauchsanweisungen bereitzustellen, als Instrument zur Verringerung des Verwaltungsaufwands ansehen. In Bezug auf digitale Gebrauchsanweisungen sprach sich die Mehrheit der Befragten für freiwillige digitale Anleitungen aus (nur wenn der Hersteller sich für diese Option entscheidet).

Parallel dazu wurde über dasselbe Forum eine schriftliche Konsultation durchgeführt, um die Meinungen der Interessenträger und etwaige Daten zu Kosteneinsparungen einzuholen, die diese Initiative mit sich bringen könnte. Die Mehrheit der Befragten sprach sich für die Digitalisierung aus, einschließlich der digitalen Konformitätserklärung und der digitalen Gebrauchsanweisungen.

#### • Einholung und Nutzung von Expertenwissen

Die vorgeschlagenen Vereinfachungsmaßnahmen wurden im Anschluss an eine interne Prüfung der bestehenden Berichtspflichten und auf der Grundlage der Erfahrungen mit der Umsetzung der entsprechenden Rechtsvorschriften ausgearbeitet. Da dies ein Schritt im Prozess der laufenden Bewertung der Berichtspflichten ist, die sich aus dem Unionsrecht ergeben, wird die Prüfung dieses Aufwands und seiner Auswirkungen auf die Interessenträger fortgesetzt.

#### • Folgenabschätzung

Der Vorschlag betrifft begrenzte und gezielte Änderungen der Rechtsvorschriften, um die Berichtspflichten zu vereinfachen und die Digitalisierung und die Angleichung in Bezug auf gemeinsame Spezifikationen sicherzustellen. Sie beruhen auf Erfahrungen mit der Durchführung von Rechtsvorschriften. Die Änderungen haben keine erheblichen Auswirkungen auf die Politik, sondern stellen lediglich eine effizientere und wirksamere Umsetzung sicher, auch durch die Angleichung in Bezug auf gemeinsame Spezifikationen an die geltenden Rechtsvorschriften.

#### • Effizienz der Rechtsetzung und Vereinfachung

Es handelt sich um einen REFIT-Vorschlag, der darauf abzielt, die Rechtsvorschriften zu vereinfachen und die Belastungen für die Interessenträger zu verringern.

#### • Grundrechte

Nicht zutreffend

### (4) AUSWIRKUNGEN AUF DEN HAUSHALT

Nicht zutreffend

#### (5) WEITERE ANGABEN

#### • Durchführungspläne sowie Monitoring-, Bewertungs- und Berichterstattungsmodalitäten

Nicht zutreffend

#### • Erläuternde Dokumente (bei Richtlinien)

Angesichts des Anwendungsbereichs des Vorschlags ist es nicht gerechtfertigt oder verhältnismäßig, erläuternde Dokumente zu verlangen.

#### • Ausführliche Erläuterung einzelner Bestimmungen des Vorschlags

Dieser Vorschlag umfasst Folgendes:

- – Festlegung, dass die EU-Konformitätserklärung oder ein ähnliches Dokument in elektronischer Form erstellt und über eine Internetadresse oder einen maschinenlesbaren Code zugänglich gemacht werden muss, wenn diese Erklärung einem Produkt beizufügen ist;

- – Hinzufügung „digitaler Kontaktdaten“, die von den Herstellern auf in Verkehr gebrachten Produkten anzugeben sind, um die Kommunikation zwischen den Wirtschaftsakteuren und den nationalen Behörden zu erleichtern. Sobald die Europäische Unternehmensbrieftasche verfügbar ist, könnte die digitale Adresse, die darin den Wirtschaftsakteuren zur Verfügung gestellt wird, die „digitalen Kontaktdaten“ darstellen;

- – Festlegung, dass die den Produkten beigefügten Gebrauchsanleitungen in elektronischer Form bereitgestellt werden können, mit Ausnahme von Sicherheitsinformationen, die aus Verbraucherschutzgründen auf Papier oder auf dem Produkt selbst angegeben werden müssen;

- – Änderung der Berichtspflichten gegenüber nationalen Behörden von der Vorgabe „in Papierform oder elektronischer Form“ auf lediglich „in elektronischer Form“;

- – Einführung einer Verpflichtung zum elektronischen Austausch zwischen den Wirtschaftsakteuren und den zuständigen Behörden;

- – Einführung einer Bestimmung über gemeinsame Spezifikationen als Alternative zu harmonisierten Normen;

- – Verpflichtung, die in der EU-Konformitätserklärung und in der Gebrauchsanleitung enthaltenen Informationen im digitalen Produktpass bereitzustellen, wenn das Produkt einer anderen Unionsvorschrift unterliegt, die die Verwendung eines solchen digitalen Produktpasses vorschreibt.

(Text von Bedeutung für den EWR)

DAS EUROPÄISCHE PARLAMENT UND DER RAT DER EUROPÄISCHEN UNION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union, insbesondere auf Artikel 114,

auf Vorschlag der Europäischen Kommission,

nach Zuleitung des Entwurfs des Gesetzgebungsakts an die nationalen Parlamente,

nach Stellungnahme des Europäischen Wirtschafts- und Sozialausschusses,

gemäß dem ordentlichen Gesetzgebungsverfahren,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Berichtspflichten spielen bei der Sicherstellung der ordnungsgemäßen Überwachung und Durchsetzung der Rechtsvorschriften eine wichtige Rolle. Um jedoch sicherzustellen, dass sie den beabsichtigten Zweck erfüllen, und um den Verwaltungsaufwand zu begrenzen, ist es wichtig, diese Anforderungen zu straffen.

<a id="rec-2"></a>
(2) In ihrer Mitteilung „Langfristige Wettbewerbsfähigkeit der EU: Blick über 2030 hinaus“ hat die Kommission sich verpflichtet, die Berichtspflichten zu rationalisieren und zu vereinfachen, um solche Lasten um 25 % zu verringern, ohne dass die jeweiligen politischen Ziele untergraben werden.

<a id="rec-3"></a>
(3) Die Kommission bringt in ihren Leitlinien für eine bessere Rechtsetzung den Grundsatz „standardmäßig digital“ voran, um den digitalen Wandel zu unterstützen und digitalfähige Maßnahmen zu erleichtern, die der sich rasch wandelnden Welt der Digitalisierung und Technologie Rechnung tragen und standardmäßig digital, interoperabel, zukunftssicher und agil sind

<a id="rec-4"></a>
(4) Angesichts der zunehmenden Bedeutung der Digitalisierung für die Vereinfachung der Rechtsrahmen ist es erforderlich, die Berichtspflichten und die sonstigen Pflichten der Wirtschaftsakteure zu verringern und zu modernisieren. Im Einklang mit den Bemühungen zur Beschleunigung der Digitalisierung ist es unerlässlich, die Berichterstattung der Unternehmen an die Behörden sowie die Pflichten der Wirtschaftsakteure vollständig zu digitalisieren, soweit dadurch der Schutz und die Sicherheit der Verbraucher nicht beeinträchtigt werden. Die Digitalisierung wird nicht nur die Compliance-Verfahren vereinfachen, sondern auch die Gesamteffizienz des Regulierungsrahmens verbessern, was letztlich sowohl den Unternehmen als auch den Behörden zugutekommen wird.

<a id="rec-5"></a>
(5) Eine Reihe sektorspezifischer Rechtsakte der Union enthält harmonisierte Vorschriften über die Pflichten der Wirtschaftsakteure beim Inverkehrbringen oder bei der Inbetriebnahme eines Produkts. Zu diesen Rechtsakten gehören die Richtlinien 2000/14/EG, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU und 2014/90/EU des Europäischen Parlaments und des Rates („die betreffenden Richtlinien“). Die meisten dieser Richtlinien beruhen auf den Grundsätzen des neuen Konzepts für die technische Harmonisierung und sind ferner an die Musterbestimmungen des Beschlusses Nr. 768/2008/EG des Europäischen Parlaments und des Rates angelehnt.

<a id="rec-6"></a>
(6) Gemäß den betreffenden Richtlinien müssen die Hersteller eine EU-Konformitätserklärung ausstellen, aus der hervorgeht, dass die Erfüllung der in den geltenden Richtlinien festgelegten grundlegenden Anforderungen nachgewiesen wurde. Um nahtlose elektronische Verfahren zu ermöglichen, sollte die EU-Konformitätserklärung nur in elektronischer Form ausgestellt werden.

<a id="rec-7"></a>
(7) Darüber hinaus muss dem Produkt gemäß den Richtlinien 2000/14/EG, 2013/53/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU und 2014/53/EU ein Exemplar der EU-Konformitätserklärung beigefügt sein. Angesichts der Weiterentwicklung der Digitalisierung ist es von entscheidender Bedeutung, diese Verpflichtung zu modernisieren, indem vorgeschrieben wird, dass die EU-Konformitätserklärung dem Produkt in elektronischer Form beigefügt sein muss. Der Hersteller sollte daher sicherstellen, dass die EU-Konformitätserklärung über eine Internetadresse oder einen maschinenlesbaren Code zugänglich ist.

<a id="rec-8"></a>
(8) Da im Jahr 2024 nicht weniger als 94 % der Haushalte in der EU Zugang zum Internet hatten, ist das Papierformat der Gebrauchsanweisungen, die den in den Anwendungsbereich der betreffenden Richtlinien fallenden Produkten beigefügt sind, veraltet und steht weder mit den derzeitigen Technologien, der Praxis der Verbraucher noch mit ökologischen Zielen in Einklang. Daher sollte die Möglichkeit eines digitalen Formats der Gebrauchsanleitungen in die Richtlinien aufgenommen werden. Dadurch wird es Herstellern ermöglicht, die Gebrauchsanleitungen in digitaler Form bereitzustellen, wenn sie dies wünschen. Wenn Hersteller sich dafür entscheiden, Anleitungen in digitaler Form bereitzustellen, sollten die Sicherheitsinformationen, einschließlich der Anleitungen, die sich auf die Produktsicherheit auswirken, in Papierform bereitgestellt oder auf dem Produkt angebracht werden, um die Sicherheit der Verbraucher weiterhin zu schützen. Darüber hinaus sollten Endnutzer auf Anfrage – zum Zeitpunkt des Kaufs und für einen bestimmten Zeitraum nach dem Kauf – eine Papierfassung der Gebrauchsanweisung oder der Sicherheitsinformationen erhalten können.

<a id="rec-9"></a>
(9) In der Richtlinie 2014/53/EU ist die Möglichkeit vorgesehen, dass Hersteller eine vereinfachte EU-Konformitätserklärung in elektronischer Form bereitstellen. Da mit diesem Vorschlag ein standardmäßig digitales Format der EU-Konformitätserklärung eingeführt wird, werden die Bestimmungen über die vereinfachte EU-Konformitätserklärung überflüssig. Es ist daher erforderlich, die betreffenden Bestimmungen aus der Richtlinie 2014/53/EU zu streichen.

<a id="rec-10"></a>
(10) Um die Kommunikation zwischen den Wirtschaftsakteuren, den zuständigen nationalen Behörden und den Endnutzern zu erleichtern, ist die Angabe digitaler Kontaktdaten des Herstellers auf dem Produkt und in der EU-Konformitätserklärung erforderlich, damit die Marktüberwachung wirksamer wird und nicht konforme Produkte schneller zurückverfolgt werden können. Derzeit müssen die Wirtschaftsakteure ihre Postanschrift auf dem Produkt angeben, dies reicht jedoch nicht immer aus, um sicherzustellen, dass die zuständigen Behörden schnell Kontakt aufnehmen können. Es ist daher erforderlich, die Wirtschaftsakteure zu verpflichten, auf dem Produkt und in der EU-Konformitätserklärung sowohl eine Postanschrift als auch digitale Kontaktdaten anzugeben. Diese digitalen Kontaktdaten sollten in die Begriffsbestimmungen der Richtlinien aufgenommen werden.

<a id="rec-11"></a>
(11) Gemäß den betreffenden Richtlinien müssen die Wirtschaftsakteure auf begründetes Verlangen einer zuständigen nationalen Behörde oder der Europäischen Kommission alle Informationen und Unterlagen, die für den Nachweis der Konformität der betreffenden Produkte mit den jeweiligen Richtlinien erforderlich sind, in Papierform oder in elektronischer Form übermitteln. Die papiergestützte Form ist eine veraltete Anforderung, während die elektronische Kommunikation die Interaktion zwischen Behörden und Unternehmen verbessert, die Verfahren vereinfacht und den Verwaltungsaufwand verringert. Um die Digitalisierung der Meldepflichten zu erreichen und den Verwaltungsaufwand für die Wirtschaftsakteure und die zuständigen Behörden zu verringern, sollten die Wirtschaftsakteure lediglich verpflichtet werden, die erforderlichen Informationen und Unterlagen in elektronischer Form zur Verfügung zu stellen. Die in elektronischer Form bereitgestellte Dokumentation könnte beispielsweise in einem digitalen druckbaren Format zur Verfügung gestellt werden, das es ermöglicht, die Dokumentation auf einem elektronischen Gerät auszudrucken, herunterzuladen und zu speichern.

<a id="rec-12"></a>
(12) Die Richtlinie 2014/90/EU enthält bestimmte sektorspezifische Besonderheiten, darunter die besonderen Anforderungen zur Gewährleistung der Sicherheit von Schiffsausrüstung an Bord von EU-Schiffen. Aufgrund dieser Besonderheiten unterscheidet sich diese Richtlinie von anderen auf den NLF abgestimmten Rechtsvorschriften. Insbesondere ist vorgesehen, dass ein Exemplar der Konformitätserklärung in Papierform an Bord eines EU-Schiffs vorhanden sein muss, bis die Schiffsausrüstung entfernt wird. Da den Flaggenstaaten der Mitgliedstaaten und Marktüberwachungsbehörden jedoch die Datenbank der Europäischen Agentur für die Sicherheit des Seeverkehrs zur Verfügung steht, sollte diese Verpflichtung künftig durch das Hochladen eines Exemplars der Konformitätserklärung in diese Datenbank erfüllt werden. Dies würde es ermöglichen, die erforderlichen Überprüfungen und Kontrollen der Schiffsausrüstung auf dem Schiff elektronisch durchzuführen, sowie eine einheitliche Anwendung und einheitliche Verfahrensweisen im Rahmen dieser Rechtsvorschriften sicherstellen.

<a id="rec-13"></a>
(13) Der derzeitige Normungsrahmen der Union, der auf der Verordnung (EU) Nr. 1025/2012 des Europäischen Parlaments und des Rates basiert, stellt den Standardrahmen für die Ausarbeitung von Normen dar, wobei eine Konformitätsvermutung mit den einschlägigen grundlegenden Gesundheits- und Sicherheitsanforderungen oder mit anderen Anforderungen vorgesehen ist. Wenn jedoch keine harmonisierten Normen existieren oder diese unzureichend sind, sollte die Kommission als außergewöhnliche Ausweichlösung Durchführungsrechtsakte erlassen können, mit denen gemeinsame Spezifikationen für die grundlegenden Gesundheits- und Sicherheitsanforderungen oder andere Anforderungen festgelegt werden, um den Herstellern die Erfüllung dieser Gesundheits- und Sicherheitsanforderungen oder anderer Anforderungen zu erleichtern.

<a id="rec-14"></a>
(14) Da der digitale Produktpass in bestimmten Rechtsvorschriften der Union, wie der Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates, vorgesehen ist, ist es von wesentlicher Bedeutung, dass die Wirtschaftsakteure verpflichtet werden, die in der EU-Konformitätserklärung und in der Gebrauchsanweisung enthaltenen Informationen im digitalen Produktpass zu speichern, wenn ein Produkt unter mehrere Rechtsvorschriften fällt. Dieser Ansatz würde den Verwaltungsaufwand für die Hersteller verringern, da sie keine separaten Speicherorte für Konformitätsdokumente mehr unterhalten müssten. Durch die Speicherung der Unterlagen an einer Stelle wären alle erforderlichen Unterlagen zum Nachweis der Produktkonformität leicht zugänglich, wodurch Transparenz sichergestellt und die Einhaltung erleichtert würde. Dieser gestraffte Ansatz würde die Gesamteffizienz des Rechtsrahmens erhöhen und steht im Einklang mit dem Grundsatz, dass in Fällen, in denen für ein Produkt mehrere Harmonisierungsrechtsvorschriften der Union gelten, der Hersteller oder gegebenenfalls ein anderer Wirtschaftsakteur eine einzige EU-Konformitätserklärung ausstellen sollte.

<a id="rec-15"></a>
(15) Da die Ziele dieser Richtlinie von den Mitgliedstaaten nicht ausreichend verwirklicht werden können, weil mit dieser Richtlinie Richtlinien zur Harmonisierung von Produktvorschriften geändert werden, sondern vielmehr im Zuge einer Vereinheitlichung der einschlägigen EU-Rechtsvorschriften auf Unionsebene besser zu verwirklichen sind, kann die Union im Einklang mit dem in Artikel 5 des Vertrags über die Europäische Union verankerten Subsidiaritätsprinzip tätig werden. Entsprechend dem in demselben Artikel genannten Grundsatz der Verhältnismäßigkeit geht diese Richtlinie nicht über das für die Verwirklichung dieser Ziele erforderliche Maß hinaus.

<a id="rec-16"></a>
(16) Damit Wirtschaftsakteure Produkte aus ihren Lagerbeständen liefern können, die vor dem Zeitpunkt der Anwendbarkeit der nationalen Maßnahmen zur Umsetzung dieser Richtlinie in Verkehr gebracht wurden, ist es notwendig, eine angemessene Übergangsregelung vorzusehen, die die Marktbereitstellung und die Inbetriebnahme von Produkten nicht behindert, die bereits gemäß der betreffenden Richtlinie vor dem Zeitpunkt der Anwendbarkeit der nationalen Maßnahmen zur Umsetzung dieser Richtlinie in Verkehr gebracht wurden.

<a id="rec-17"></a>
(17) Um einen reibungslosen und wirksamen Übergang zu gewährleisten, Störungen so gering wie möglich zu halten und den Industriezweigen einen angemessenen Zeitrahmen für die Anpassung an die neuen Anforderungen einzuräumen, sollte die Anwendung der Umsetzungsmaßnahmen in Bezug auf die Digitalisierung aufgeschoben werden.

<a id="rec-18"></a>
(18) Die Richtlinien 2000/14/EG, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU und 2014/90/EU sollten daher entsprechend geändert werden —

HABEN FOLGENDE RICHTLINIE ERLASSEN:

<a id="art-1"></a>
### Artikel 1

Änderungen der Richtlinie 2000/14/EG

Die Richtlinie 2000/14/EG wird wie folgt geändert:

- 1. In Artikel 3 wird folgender Buchstabe g angefügt:

„g) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

- 2. Artikel 4 Absatz 1 dritter Gedankenstrich erhält folgende Fassung:

„die Geräte und Maschinen mit der CE-Kennzeichnung und der Angabe des garantierten Schalleistungspegels versehen sind und ihnen die Internetadresse oder der maschinenlesbare Code beigefügt ist, über die bzw. den die EG-Konformitätserklärung abgerufen werden kann.“;

- 3. Artikel 5 Absatz 1 erhält folgende Fassung:

„(1) Die Mitgliedstaaten treffen die erforderlichen Maßnahmen, um sicherzustellen, dass Geräte und Maschinen im Sinne des Artikels 2 Absatz 1 nur in Verkehr gebracht oder in Betrieb genommen werden dürfen, wenn sie den Bestimmungen dieser Richtlinie entsprechen, mit der CE-Kennzeichnung und der Angabe des garantierten Schallleistungspegels sowie der Internetadresse oder dem maschinenlesbaren Code versehen sind, über die die EG-Konformitätserklärung abgerufen werden kann.“

- 4. Artikel 6 Absatz 1 erhält folgende Fassung:

„(1) Die Mitgliedstaaten dürfen das Inverkehrbringen oder die Inbetriebnahme von Geräten und Maschinen im Sinne des Artikels 2 Absatz 1, die den Bestimmungen dieser Richtlinie entsprechen und mit der CE-Kennzeichnung und der Angabe des garantierten Schallleistungspegels sowie der Internetadresse oder dem maschinenlesbaren Code versehen sind, über die die EG-Konformitätserklärung abgerufen werden kann, in ihrem Hoheitsgebiet weder untersagen noch einschränken oder behindern.“

- 5. Artikel 7 erhält folgende Fassung:

„Konformitätsvermutung

Die Mitgliedstaaten gehen davon aus, dass Geräte und Maschinen im Sinne des Artikels 2 Absatz 1, die mit der CE-Kennzeichnung und der Angabe des garantierten Schallleistungspegels sowie der Internetadresse oder dem maschinenlesbaren Code versehen sind, über die die EG-Konformitätserklärung abgerufen werden kann, allen Bestimmungen dieser Richtlinie entsprechen.“

- 6. Artikel 8 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

„(1) Um zu bescheinigen, dass ein Gerät oder eine Maschine den Bestimmungen dieser Richtlinie entspricht, stellt der Hersteller eines Geräts oder einer Maschine im Sinne des Artikels 2 Absatz 1 oder sein in der Gemeinschaft ansässiger Bevollmächtigter für jeden Typ eines hergestellten Gerätes oder einer hergestellten Maschine eine EG-Konformitätserklärung in elektronischer Form aus; die Mindestangaben dieser Konformitätserklärung sind in Anhang II festgelegt.“

  - b) Folgender Absatz 4 wird angefügt:

„(4) Ist der Wirtschaftsakteur aufgrund anderer für das Gerät oder die Maschine geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EG-Konformitätserklärung oder die Anleitung in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang II in die EG-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 11 Absatz 5 genannte Anleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 7. Artikel 14 wird wie folgt geändert:

  - a) Absatz 3 erhält folgende Fassung:

„(3) Die Mitgliedstaaten stellen sicher, dass die Kommission und jeder andere Mitgliedstaat auf begründete Anfrage alle Informationen in elektronischer Form erhalten kann, die im Laufe des Konformitätsbewertungsverfahrens für einen Geräte- oder Maschinentyp verwendet wurden, und insbesondere die technischen Unterlagen gemäß Anhang V Nummer 3, Anhang VI Nummer 3, Anhang VII Nummer 2 sowie Anhang VIII Nummern 3.1 und 3.3.“

  - b) Folgender Absatz 4 wird angefügt:

„(4) Gegebenenfalls übermittelt der Hersteller der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form.“

- 8. Die Anhänge II und V bis VIII werden gemäß Anhang I dieser Richtlinie geändert.

<a id="art-2"></a>
### Artikel 2

Änderung der Richtlinie 2011/65/EU

Die Richtlinie 2011/65/EU wird wie folgt geändert:

- 1. Artikel 3 wird wie folgt geändert:

  - a) Folgende Nummer 6a wird eingefügt:

„6a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 13a wird eingefügt:

„13a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten;“

- 2. Artikel 7 wird wie folgt geändert:

  - a) Punkt c Satz 1 erhält folgende Fassung:

„c) Wurde mit dem in Buchstabe b genannten Verfahren nachgewiesen, dass das Elektro- oder Elektronikgerät den geltenden Anforderungen entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen am fertigen Produkt die CE-Kennzeichnung an.“

  - b) Buchstabe e Satz 2 erhält folgende Fassung:

„Änderungen an der Gestaltung des Produkts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder der technischen Spezifikationen, auf die bei Erklärung der Konformität von Elektro- oder Elektronikgeräten verwiesen wird, werden angemessen berücksichtigt.“

  - c) Buchstabe h erhält folgende Fassung:

„h) Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Elektro- oder Elektronikgerät selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Gerät beigefügten Unterlagen an. In der Postanschrift und den digitalen Kontaktdaten muss eine zentrale Stelle angegeben werden, über die der Hersteller erreichbar ist. Enthalten andere maßgebliche Rechtsvorschriften der Union Bestimmungen über die Anbringung des Namens, der Postanschrift und der digitalen Kontaktdaten des Herstellers, die zumindest gleich streng sind, so finden diese Bestimmungen Anwendung.“

  - d) Buchstabe j erhält folgende Fassung:

„j) Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen in einer Sprache, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann, zur Verfügung, die für den Nachweis der Konformität des Elektro- oder Elektronikgeräts mit der vorliegenden Richtlinie erforderlich sind, und kooperieren mit dieser Behörde auf deren Verlangen bei allen Maßnahmen, die sicherstellen sollen, dass das von ihnen in Verkehr gebrachte Elektro- oder Elektronikgerät die vorliegende Richtlinie einhält.“

- 3. Artikel 8 Buchstabe b zweiter Gedankenstrich erhält folgende Fassung:

„auf begründetes Verlangen einer zuständigen nationalen Behörde Bereitstellung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität von Elektro- oder Elektronikgeräten mit dieser Richtlinie an diese Behörde;“

- 4. Artikel 9 wird wie folgt geändert:

  - a) Buchstabe d erhält folgende Fassung:

„d) Die Importeure geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Elektro- oder Elektronikgerät selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Gerät beigefügten Unterlagen an. Enthalten andere maßgebliche Rechtsvorschriften der Union Bestimmungen über die Anbringung des Namens, der Postanschrift und der digitalen Kontaktdaten des Importeurs, die zumindest gleich streng sind, so gelten diese Bestimmungen.“

  - b) Buchstabe h erhält folgende Fassung:

„h) Die Importeure stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen alle Informationen und Unterlagen, die für den Nachweis der Konformität der Elektro- oder Elektronikgeräte mit der vorliegenden Richtlinie erforderlich sind, in elektronischer Form und in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann, und kooperieren mit dieser Behörde auf deren Verlangen bei allen Maßnahmen, die sicherstellen sollen, dass die Elektro- oder Elektronikgeräte, die sie in Verkehr gebracht haben, diese Richtlinie einhalten.“

- 5. Artikel 10 Buchstabe d erhält folgende Fassung:

„d) Die Vertreiber stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen zur Verfügung, die für den Nachweis der Konformität von Elektro- oder Elektronikgeräten mit der vorliegenden Richtlinie erforderlich sind, und kooperieren mit dieser Behörde auf deren Verlangen bei allen Maßnahmen, die sicherstellen sollen, dass von ihnen auf dem Markt bereitgestellte Elektro- oder Elektronikgeräte diese Richtlinie einhalten.“

- 6. In Artikel 13 wird der folgende Absatz 4 angefügt:

„(4) Ist der Wirtschaftsakteur nach anderen für Elektro- und Elektronikgeräte geltenden Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt die in diesen Rechtsvorschriften festgelegten Anforderungen erfüllt, in einen digitalen Produktpass aufzunehmen oder die Konformitätserklärung in einen digitalen Produktpass hochzuladen, so werden die Informationen, die gemäß Anhang VI in die EU-Konformitätserklärung aufzunehmen sind, nur in diesem digitalen Produktpass bereitgestellt.“

- 7. Folgender Artikel 16a wird eingefügt:

„Artikel 16a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Artikel 4 festgelegten grundlegenden Anforderungen ermöglichen:

a) Die in Artikel 4 festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

b) die Anforderungen gemäß Artikel 4 werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Werkstoffe, Bauteile und Elektro- und Elektronikgeräte nicht den grundlegenden Anforderungen gemäß Artikel 4 entsprechen;

c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Werkstoffe, Bauteile und Elektro- und Elektronikgeräte auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 19 Absatz 3 genannten Beratungsverfahren erlassen.

(2) Bei Werkstoffen, Bauteilen und Elektro- und Elektronikgeräten, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Artikel 4 festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 8. In Artikel 19 wird der folgende Absatz 3 angefügt:

„(3) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 4 der Verordnung (EU) Nr. 182/2011.“

- 9. Die Anhänge V und VI werden entsprechend dem Anhang II dieser Richtlinie geändert.

<a id="art-3"></a>
### Artikel 3

Änderungen der Richtlinie 2013/53/EU

Die Richtlinie 2013/53/EU wird wie folgt geändert:

- 1. Artikel 3 wird wie folgt geändert:

  - a) Folgende Nummer 19a wird eingefügt:

„19a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Die folgende Nummer 20 a wird eingefügt:

„20a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 7 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit diesem Verfahren nachgewiesen, dass das Produkt den geltenden Anforderungen entspricht, so stellen die Hersteller eine Erklärung in elektronischer Form gemäß Artikel 15 aus und bringen die CE-Kennzeichnung gemäß den Artikeln 17 und 18 an.“

  - b) Artikel 4 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Produkts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen oder der gemeinsamen Spezifikationen, auf die bei Erklärung der Konformität eines Produkts verwiesen wird, werden angemessen berücksichtigt.“

  - c) Die Absätze 6 und 7 erhalten folgende Fassung:

„(6) Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Produkt selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Produkt beigefügten Unterlagen an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

(7) Die Hersteller gewährleisten, dass dem Produkt die Gebrauchsanleitung und die Sicherheitsinformationen im Eignerhandbuch in einer Sprache bzw. in Sprachen, die vom betreffenden Mitgliedstaat festgelegt werden, beigefügt sind, die von den Verbrauchern und sonstigen Endbenutzern leicht verstanden werden können. Die Betriebsanleitung und die Sicherheitsinformationen können in elektronischer Form bereitgestellt werden.

Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Gebrauchsanweisungen und die Sicherheitsinformationen den Verwendungszweck und die voraussichtlichen Endnutzer des Produkts

Bei Produkten, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, muss der Hersteller die Sicherheitsinformationen in Papierform bereitstellen oder auf dem Produkt anbringen. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Sicherheitsinformationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung für die Gewährleistung der Sicherheit spielt.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Produkt oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Produkts, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Produkts eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Produkts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Produkts online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Produkts oder bis zu sechs Monate nach dem Kauf die Anleitung oder die Sicherheitsinformationen in Papierform anfordern. Fordert der Endnutzer diese Anleitung oder Sicherheitsinformationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - d) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Hersteller händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Produkts erforderlich sind, in einer Sprache aus, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 8 Absatz 3 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines Produkts an diese Behörde;“

- 4. Artikel 9 wird wie folgt geändert:

  - a) Absatz 3 erhält folgende Fassung:

„(3) Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Produkt selbst oder im Fall von Bauteilen, wo dies nicht möglich ist, auf der Verpackung oder in den dem Produkt beigefügten Unterlagen an.“

  - b) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Importeure händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Produkts erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 10 Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität des Produkts erforderlich sind.“

- 6. Folgender Artikel 14a wird eingefügt:

„Artikel 14a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Artikel 4 festgelegten grundlegenden Anforderungen ermöglichen:

a) Die in Artikel 4 festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

b) die Anforderungen gemäß Artikel 4 werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Produkte nicht den grundlegenden Anforderungen gemäß Artikel 4 entsprechen; oder

c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Produkte auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 50 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Produkten, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Artikel 4 festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 15 wird wie folgt geändert:

  - a) Absatz 4 einleitender Satz erhält folgende Fassung:

„Den folgenden Produkten ist bei ihrer Bereitstellung auf dem Markt oder ihrer Inbetriebnahme die Internetadresse des maschinenlesbaren Codes beizufügen, über den die in Absatz 3 genannte EU-Konformitätserklärung abgerufen werden kann:“

  - b) Folgender Absatz 6 wird angefügt:

„(6) Ist der Wirtschaftsakteur aufgrund anderer für das Produkt geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anleitung in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 7 Absatz 7 genannte Gebrauchsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 8. In Artikel 19 wird der folgende Absatz 5 angefügt:

„(5) Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“;

- 9. In Artikel 20 Absatz 1 Buchstabe b Ziffer i erhalten die Gedankenstriche folgende Fassung:

„bei Übereinstimmung mit den harmonisierten Normen oder den gemeinsamen Spezifikationen in Bezug auf Anhang I Teil A Nummern 3.2 und 3.3: Modul A (interne Fertigungskontrolle), Modul A1 (interne Fertigungskontrolle mit überwachten Produktprüfungen), Modul B (EU-Baumusterprüfung) zusammen mit Modul C, D, E oder F, Modul G (Konformität auf der Grundlage einer Einzelprüfung) oder Modul H (Konformität auf der Grundlage einer umfassenden Qualitätssicherung);

— bei Nichtübereinstimmung mit den harmonisierten Normen oder den gemeinsamen Spezifikationen in Bezug auf Anhang I Teil A Nummern 3.2 und 3.3: Modul A1 (interne Fertigungskontrolle mit überwachten Produktprüfungen), Modul B (EU-Baumusterprüfung) zusammen mit Modul C, D, E oder F, Modul G (Konformität auf der Grundlage einer Einzelprüfung) oder Modul H (Konformität auf der Grundlage einer umfassenden Qualitätssicherung);“

- 10. Artikel 21 wird wie folgt geändert:

  - a) Unter Buchstabe a erhält der einleitende Satz folgende Fassung:

„bei Prüfungen unter Verwendung der harmonisierten Norm oder der gemeinsamen Spezifikation, eines der folgenden Module:“

  - b) In Buchstabe b erhält der einleitende Satz folgende Fassung:

„bei Prüfungen ohne Verwendung der harmonisierten Norm oder der gemeinsamen Spezifikation, eines der folgenden Module:

- 11. Artikel 22 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) Unter Buchstabe a erhält der einleitende Satz folgende Fassung:

„bei Prüfungen unter Verwendung der harmonisierten Norm oder der gemeinsamen Spezifikation für Geräuschmessungen eines der folgenden Module:“

    - ii) Buchstabe b erhält folgende Fassung:

b) bei Prüfungen ohne Verwendung der harmonisierten Norm oder der gemeinsamen Spezifikation für Geräuschmessungen, Modul G (Konformität auf der Grundlage einer Einzelprüfung).“

  - b) Absatz 2 wird wie folgt geändert:

    - i) Unter Buchstabe a erhält der einleitende Satz folgende Fassung:

„bei Prüfungen unter Verwendung der harmonisierten Norm oder der gemeinsamen Spezifikation für Geräuschmessungen eines der folgenden Module:“

    - ii) Buchstabe b erhält folgende Fassung:

b) bei Prüfungen ohne Verwendung der harmonisierten Norm oder der gemeinsamen Spezifikation für Geräuschmessungen, Modul G (Konformität auf der Grundlage einer Einzelprüfung).“

- 12. Artikel 30 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und angemessenes Verständnis der grundlegenden Anforderungen, der geltenden harmonisierten Normen oder der gemeinsamen Spezifikation und der einschlägigen Harmonisierungsrechtsvorschriften der Union und der entsprechenden nationalen Rechtsvorschriften,“

- 13. Artikel 38 Absatz 3 erhält folgende Fassung:

„(3) Bemerkt eine notifizierte Stelle, dass ein Hersteller oder privater Einführer die Anforderungen nicht erfüllt hat, die in Artikel 4 Absatz 1 und in Anhang I oder in den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen festgelegt sind, so fordert sie den Hersteller oder privaten Einführer auf, angemessene Abhilfemaßnahmen zu ergreifen, und stellt keine Konformitätsbescheinigung aus.“

- 14. Die Anhänge I, III, IV und V werden gemäß Anhang III der vorliegenden Richtlinie geändert.

<a id="art-4"></a>
### Artikel 4

Änderung der Richtlinie 2014/29/EU

Die Richtlinie 2014/29/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 7a wird eingefügt:

„7a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 9a wird eingefügt:

„9a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 6 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit diesem Verfahren nachgewiesen, dass ein Behälter, dessen Produkt PS × V mehr als 50 bar.L beträgt, den anwendbaren Anforderungen entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung sowie die in Anhang III Nummer 1 genannten Aufschriften an.“

  - b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Behälters oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder anderer technischer Spezifikationen, auf die bei Erklärung der Konformität eines Behälters verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Behälter an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 erhält folgende Fassung:

„(7) Die Hersteller gewährleisten, dass dem Behälter die Betriebsanleitung und die Sicherheitsinformationen gemäß Anhang III Nummer 2 beigefügt sind, die in einer von dem betreffenden Mitgliedstaat festgelegten Sprache, die von den Endnutzern leicht verstanden werden kann, verfasst sind. Die Betriebsanleitung und die Sicherheitsinformationen gemäß Anhang III Nummer 2 können in elektronischer Form bereitgestellt werden. Diese Betriebsanleitung und Sicherheitsinformationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Der Hersteller muss bei der Wahl des Formats für die Betriebsanleitung und die Sicherheitsinformationen den Verwendungszweck und die voraussichtlichen Endnutzer des Behälters berücksichtigen.

Bei Behältern, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern benutzt werden können, auch wenn sie nicht für sie bestimmt sind, stellt der Hersteller die in Anhang III Nummer 2 genannten Sicherheitsinformationen in Papierform oder auf dem Behälter zur Verfügung. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Sicherheitsinformationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung für die Gewährleistung der Sicherheit spielt.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Behälter oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Behälters darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Behälters eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Behälters und mindestens zehn Jahre lang nach dem Inverkehrbringen des Behälters online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Behälters oder bis zu sechs Monate nach dem Kauf Anweisungen oder Sicherheitsinformationen in Papierform anfordern. Fordert der Endnutzer diese Anleitung oder Sicherheitsinformationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - e) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Behälters mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 7 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines Behälters an diese Behörde;“

- 4. Artikel 8 wird wie folgt geändert:

  - a) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke und ihre Postanschrift sowie ihre digitalen Kontaktdaten entweder auf dem Behälter selbst oder, wenn dies nicht möglich ist, in den dem Behälter beigefügten Unterlagen an.“

  - b) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Behälters erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 9 Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines Behälters erforderlich sind.“

- 6. Folgender Artikel 12a wird eingefügt:

„Artikel 12a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Anhang I festgelegten grundlegenden Anforderungen ermöglichen:

    a) Die in Anhang I festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die Anforderungen gemäß Anhang I werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Behälter, deren Produkt PS × V mehr als 50 bar.L beträgt, nicht den grundlegenden Anforderungen gemäß Artikel 4 entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Behälter, deren Produkt PS × V mehr als 50 bar.L beträgt, auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 39 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Behältern, deren Produkt PS × V mehr als 50 bar.L beträgt und die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Anhang I festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 13 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) Unter Buchstabe a erhält der einleitende Satz folgende Fassung:

„a) Behälter, die nach den harmonisierten Normen in Artikel 12 oder nach den gemeinsamen Spezifikationen in Artikel 12a hergestellt wurden, unterzieht der Hersteller wahlweise“

    - ii) Buchstabe b erhält folgende Fassung:

„b) Bei Behältern, die unter nur teilweiser Einhaltung oder unter Nichteinhaltung der harmonisierten Normen nach Artikel 12 oder der gemeinsamen Spezifikationen nach Artikel 12a hergestellt werden, legt der Hersteller ein für die geplante Produktion repräsentatives Muster des vollständigen Behälters sowie die technischen Unterlagen und zusätzlichen Nachweise für die Prüfung und Bewertung der Eignung des technischen Entwurfs des Behälters (Modul B – Baumuster) zur Prüfung vor.“

  - b) Absatz 3 erhält folgende Fassung:

„(3) Die Aufzeichnungen und der Schriftverkehr betreffend die Konformitätsbewertungsverfahren gemäß den Absätzen 1 und 2 werden in elektronischer Form in einer Amtssprache des Mitgliedstaats, in dem die notifizierte Stelle zugelassen ist, oder in einer von der notifizierten Stelle akzeptierten Sprache abgefasst.“

  - c) Folgender Absatz 4 wird angefügt:

„(4) Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 8. In Artikel 14 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für den Behälter geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 6 Absatz 7 genannte Betriebsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 9. Artikel 21 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Sicherheitsanforderungen nach Anhang I, der geltenden harmonisierten Normen oder gemeinsamen Spezifikationen und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der nationalen Rechtsvorschriften,“

- 10. Artikel 29 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine notifizierte Stelle fest, dass ein Hersteller die wesentlichen Sicherheitsanforderungen nicht erfüllt hat, die in Anhang I oder in den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen oder anderen technischen Spezifikationen festgelegt sind, fordert sie den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Konformitätsbescheinigung aus.“

- 11. Die Anhänge II, III und IV werden gemäß Anhang IV der vorliegenden Richtlinie geändert.

<a id="art-5"></a>
### Artikel 5

Änderung der Richtlinie 2014/30/EU

Die Richtlinie 2014/30/EU wird wie folgt geändert:

- 1. Artikel 3 wird wie folgt geändert:

  - a) Folgende Nummer 15a wird eingefügt:

„15a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 17a wird eingefügt:

„17a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 7 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit diesem Verfahren nachgewiesen, dass das Gerät den anwendbaren Anforderungen entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung an.“

  - b) Absatz 4 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Geräts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder anderer technischer Spezifikationen, auf die bei Erklärung der Konformität eines Geräts verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Gerät selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Gerät beigefügten Unterlagen an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 erhält folgende Fassung:

„(7) Die Hersteller gewährleisten, dass dem Gerät die in Artikel 18 genannten Betriebsanleitungen und Informationen beigefügt sind, die in einer vom betreffenden Mitgliedstaat festgelegten Sprache, die von den Verbrauchern und sonstigen Endnutzern leicht verstanden werden kann, verfasst sind. Die in Artikel 18 genannten Betriebsanleitungen und Informationen können in elektronischer Form bereitgestellt werden. Diese Betriebsanleitungen und Informationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Bei Geräten, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, muss der Hersteller die in Artikel 18 genannten Informationen in Papierform bereitstellen oder auf dem Gerät anbringen. Diese Informationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der in Artikel 18 genannten Informationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Gerät oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Geräts darauf zugreifen kann;

c) sie während der voraussichtlichen Lebensdauer des Geräts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Geräts online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Geräts oder bis zu sechs Monate nach dem Kauf die in Artikel 18 genannten Betriebsanleitungen oder Informationen in Papierform anfordern. Fordert der Endnutzer die in Artikel 18 genannten Anweisungen oder Informationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Anforderung kostenlos zur Verfügung.“

  - e) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen alle Informationen und Unterlagen, die für den Nachweis der Konformität des Geräts mit dieser Richtlinie erforderlich sind, in elektronischer Form in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 8 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität des Geräts an diese Behörde;“

- 4. Artikel 9 wird wie folgt geändert:

  - a) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Gerät selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Gerät beigefügten Unterlagen an.“

  - b) Absatz 8 Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Geräts erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 10 Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität des Geräts erforderlich sind.“

- 6. Folgender Artikel 13a wird eingefügt:

„Artikel 13a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Anhang I festgelegten grundlegenden Anforderungen ermöglichen:

    a) Die in Anhang I festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die Anforderungen gemäß Anhang I werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Geräte nicht den grundlegenden Anforderungen gemäß Anhang I entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Geräte auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 41 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Geräten, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Anhang I festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. In Artikel 14 wird folgender Unterabsatz angefügt:

„Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit dem Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 8. In Artikel 15 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für ein Gerät geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 7 Absatz 7 genannte Gebrauchsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 9. Artikel 24 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Anforderungen nach Anhang I, der geltenden harmonisierten Normen oder gemeinsamen Spezifikationen und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der nationalen Rechtsvorschriften,“

- 10. Artikel 32 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine notifizierte Stelle fest, dass ein Hersteller die wesentlichen Anforderungen nicht erfüllt hat, die in Anhang I oder in den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen oder anderen technischen Spezifikationen festgelegt sind, fordert sie den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Bescheinigung aus.“

- 11. Die Anhänge II, III und IV werden gemäß Anhang V der vorliegenden Richtlinie geändert.

<a id="art-6"></a>
### Artikel 6

Änderung der Richtlinie 2014/31/EU

Die Richtlinie 2014/31/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 9a wird eingefügt:

„9a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 11a wird eingefügt:

„11a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 6 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit dem Konformitätsbewertungsverfahren nachgewiesen, dass ein Gerät, das zu den in Artikel 1 Absatz 2 Buchstaben a bis f genannten Zwecken verwendet werden soll, den anwendbaren Anforderungen entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung und die zusätzliche Metrologie-Kennzeichnung an.“

  - b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf der Geräte oder an ihren Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder anderer technischer Spezifikationen, auf die bei Erklärung der Konformität eines Geräts verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Marke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Gerät an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 erhält folgende Fassung:

„(7) Die Hersteller stellen sicher, dass dem Gerät, das zu den in Artikel 1 Absatz 2 Buchstaben a bis f genannten Zwecken verwendet werden soll, eine Betriebsanleitung und Informationen beigefügt sind, die in einer von dem betreffenden Mitgliedstaat festgelegten Sprache, die von den Endnutzern leicht verstanden werden kann, verfasst sind. Die Anleitungen und Informationen können in elektronischer Form bereitgestellt werden. Diese Betriebsanleitungen und Informationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Gebrauchsanweisung und die Informationen den Verwendungszweck und die voraussichtlichen Endnutzer des Produkts.

Bei Geräten, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, muss der Hersteller die Sicherheitsinformationen in Papierform bereitstellen oder auf dem Gerät anbringen. Diese Informationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Gerät oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Geräts, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Geräts eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Geräts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Geräts online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Erwerbs des Geräts oder bis zu sechs Monate nach dem Kauf Anweisungen und Informationen in Papierform anfordern. Fordert der Endnutzer diese Anweisungen oder Informationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Anforderung kostenlos zur Verfügung.“

  - e) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Geräts mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 7 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines Produkts an diese Behörde;“

- 4. Artikel 8 wird wie folgt geändert:

  - a) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben auf dem Gerät ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten an.“

  - b) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Geräts erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 9 Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines Geräts erforderlich sind.“

- 6. Folgender Artikel 12a wird eingefügt:

„Artikel 12a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Anhang I festgelegten wesentlichen Anforderungen ermöglichen:

    a) Die in Anhang I festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die in Anhang I festgelegten Anforderungen werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Geräte nicht den wesentlichen Anforderungen gemäß Anhang I entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Geräte auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 41 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Geräten, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Anhang I festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 13 Absatz 2 erhält folgende Fassung:

„(2) Die Aufzeichnungen und der Schriftverkehr im Zusammenhang mit den Konformitätsbewertungsverfahren gemäß Absatz 1 sind in elektronischer Form in einer der Amtssprachen des Mitgliedstaats, in welchem die Verfahren durchgeführt werden, oder in einer von der nach Artikel 19 notifizierten Stelle genehmigten Sprache abzufassen.“

- 8. In Artikel 14 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für das Gerät geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 6 Absatz 7 genannte Gebrauchsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 9. Artikel 23 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Anforderungen nach Anhang I, der geltenden harmonisierten Normen oder gemeinsamen Spezifikationen und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der nationalen Rechtsvorschriften,“

- 10. Artikel 31 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine notifizierte Stelle fest, dass ein Hersteller die wesentlichen Anforderungen nicht erfüllt hat, die in Anhang I oder in den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen oder anderen technischen Spezifikationen festgelegt sind, fordert sie den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Konformitätsbescheinigung aus.“

- 11. Die Anhänge II und IV werden entsprechend dem Anhang VI dieser Richtlinie geändert.

<a id="art-7"></a>
### Artikel 7

Änderung der Richtlinie 2014/32/EU

Die Richtlinie 2014/32/EU wird wie folgt geändert:

- 1. Artikel 4 wird wie folgt geändert:

  - a) Folgende Nummer 12a wird eingefügt:

„12a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 14a wird eingefügt:

„14a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 8 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit dem Konformitätsbewertungsverfahren nachgewiesen, dass ein Messgerät den anwendbaren Anforderungen dieser Richtlinie entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung und die zusätzliche Metrologie-Kennzeichnung an.“

  - b) Artikel 4 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Messgeräts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen, gemeinsamen Spezifikationen, normativen Dokumente oder anderen technischen Spezifikationen, auf die bei Erklärung der Konformität eines Messgeräts verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Messgerät an oder, wenn dies nicht möglich ist, in den dem Messgerät beigefügten Unterlagen und gegebenenfalls auf der Verpackung gemäß Anhang I Nummer 9.2. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 Satz 1 erhält folgende Fassung:

„(7) Die Hersteller gewährleisten, dass dem von ihnen in Verkehr gebrachten Messgerät die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, sowie die Betriebsanleitung und die in Anhang I Nummer 9.3 genannten Informationen beigefügt sind, die in einer vom betreffenden Mitgliedstaat festgelegten Sprache, die von den Verbrauchern und sonstigen Endnutzern leicht verstanden werden kann, verfasst sind. Die Anleitungen und Informationen können in elektronischer Form bereitgestellt werden. Diese Betriebsanleitungen und Informationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Gebrauchsanweisung und die in Anhang I Nummer 9.3 genannten Informationen den Verwendungszweck und die voraussichtlichen Endnutzer des Produkts.

Bei Messgeräten, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, muss der Hersteller die in Anhang I Nummer 9.3 genannten Informationen in Papierform bereitstellen oder auf dem Gerät anbringen. Diese Informationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Betriebsanleitung und der in Anhang I Nummer 9.3 genannten Informationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung und diese Informationen für die Gewährleistung der Sicherheit spielen.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Messgerät oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Messgeräts darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Messgeräts eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Messgeräts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Messgeräts online zugänglich machen.

Der Endnutzer kann jedoch beim Kauf des Messgeräts oder bis zu sechs Monate nach dem Kauf Anweisungen und Informationen gemäß Anhang I Nummer 9.3 in Papierform anfordern. Fordert der Endnutzer diese Anweisungen oder Informationen gemäß Anhang I Nummer 9.3 an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Anforderung kostenlos zur Verfügung.“

  - e) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Messgeräts mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 9 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines Messgeräts an diese Behörde;“

- 4. Artikel 10 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Sie gewährleisten, dass der Hersteller die technischen Unterlagen erstellt hat, dass das Messgerät mit der CE-Kennzeichnung und der zusätzlichen Metrologie-Kennzeichnung versehen ist, dass ihm die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, und die erforderlichen Unterlagen beigefügt sind und dass der Hersteller die Anforderungen von Artikel 8 Absätze 5 und 6 erfüllt hat.“

  - b) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Messgerät an oder, wenn dies nicht möglich ist, in den dem Messgerät beigefügten Unterlagen und gegebenenfalls auf der Verpackung gemäß Anhang I Nummer 9.2.“

  - c) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Messgeräts erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 11 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 1 erhält folgende Fassung:

„Bevor sie ein Messgerät auf dem Markt bereitstellen und/oder in Betrieb nehmen, überprüfen die Händler, ob das Messgerät mit der CE-Kennzeichnung und der zusätzlichen Metrologie-Kennzeichnung versehen ist, ob ihm die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, die erforderlichen Unterlagen sowie Betriebsanleitung und die in Anhang I Nummer 9.3 genannten sonstigen Informationen in einer Sprache beigefügt sind, die von den Endnutzern in dem Mitgliedstaat, in dem das Messgerät auf dem Markt bereitgestellt werden soll, leicht verstanden werden kann, und ob der Hersteller und der Einführer die Anforderungen von Artikel 8 Absätze 5 und 6 bzw. von Artikel 10 Absatz 3 erfüllt haben.“

  - b) Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines Messgeräts erforderlich sind.“

- 6. Folgender Artikel 14a wird eingefügt:

„Artikel 14a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der wesentlichen Anforderungen ermöglichen, die in Anhang I und den entsprechenden gerätespezifischen Anhängen, die von diesen Teilen der normativen Dokumente abgedeckt sind, festgelegt sind:

    a) Die Anforderungen, die in Anhang I und den entsprechenden gerätespezifischen und von diesen Teilen der normativen Dokumente abgedeckten Anhängen festgelegt sind, sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) Die Anforderungen, die in Anhang I und den entsprechenden gerätespezifischen und von diesen Teilen der normativen Dokumente abgedeckten Anhängen festgelegt sind, sind durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder durch Teile dieser Normen erfasst, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Messgeräte nicht den wesentlichen Anforderungen gemäß Anhang I und gemäß den entsprechenden gerätespezifischen und von diesen Teilen der normativen Dokumente abgedeckten Anhängen entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nichtkonformer Messgeräte auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Messgeräten, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den in Artikel 6 festgelegten wesentlichen Anforderungen übereinstimmen, die von diesen gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 17 wird wie folgt geändert:

  - a) Unterabsatz 3 erhält folgende Fassung:

„Aufzeichnungen und Schriftwechsel im Zusammenhang mit den Konformitätsbewertungsverfahren werden in elektronischer Form in der (den) Amtssprache(n) des Mitgliedstaats abgefasst, in dem die notifizierte Stelle, die die Konformitätsbewertungsverfahren durchführt, ihren Sitz hat, oder in einer anderen von dieser Stelle anerkannten Sprache.“

  - b) Folgender Unterabsatz wird angefügt:

„Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 8. In Artikel 18 Absatz 3 erhalten die Buchstaben f und g folgende Fassung:

f) eine Liste der ganz oder teilweise angewandten harmonisierten Normen und/oder normativen Dokumente nach Artikel 14 und/oder gemeinsamen Spezifikationen nach Artikel 14a, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind;

g) eine Beschreibung der zur Erfüllung der wesentlichen Anforderungen gewählten Lösungen, soweit die in Artikel 14 genannten harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder normativen Dokumente nicht angewandt worden sind, einschließlich einer Aufstellung, welche sonstigen einschlägigen technischen Spezifikationen angewandt worden sind,

- 9. In Artikel 19 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für Messgeräte geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang XIII in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 8 Absatz 7 genannte Gebrauchsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 10. Artikel 27 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Anforderungen nach Anhang I und den entsprechenden gerätespezifischen Anhängen, der anwendbaren harmonisierten Normen oder gemeinsamen Spezifikationen und normativen Dokumente und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union sowie der nationalen Rechtsvorschriften,“

- 11. Artikel 36 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine notifizierte Stelle fest, dass ein Hersteller die wesentlichen Anforderungen nicht erfüllt hat, die in Anhang I und in den entsprechenden gerätespezifischen Anhängen oder in den entsprechenden harmonisierten Normen, normativen Dokumenten, gemeinsamen Spezifikationen oder anderen technischen Spezifikationen festgelegt sind, fordert sie den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Konformitätsbescheinigung aus.“

- 12. Artikel 45 Absatz 1 Buchstabe d erhält folgende Fassung:

„d) dem Messgerät keine Internetadresse oder kein maschinenlesbarer Code beigefügt ist, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann;“

- 13. Die Anhänge II und XIII werden entsprechend dem Anhang VII dieser Richtlinie geändert.

<a id="art-8"></a>
### Artikel 8

Änderung der Richtlinie 2014/33/EU

Die Richtlinie 2014/33/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 11a wird eingefügt:

„11a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 13a wird eingefügt:

„13a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 7 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit diesem Verfahren nachgewiesen, dass der Aufzug den wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen entspricht, stellt der Montagebetrieb eine EU-Konformitätserklärung in elektronischer Form aus, sorgt dafür, dass dem Aufzug die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, beigefügt ist, und bringt die CE-Kennzeichnung an.“

  - b) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Montagebetriebe geben auf dem Aufzug ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Montagebetrieb erreichbar ist.“

  - c) Absatz 7 erhält folgende Fassung:

„(7) Die Montagebetriebe stellen sicher, dass dem Aufzug die Betriebsanleitung nach Anhang I Nummer 6.2 beigefügt ist; sie ist gemäß der Entscheidung des Mitgliedstaats, in dem der Aufzug in Verkehr gebracht wird, in einer Sprache, die von den Endnutzern leicht verstanden werden kann, zur Verfügung zu stellen. Die Betriebsanleitung kann in elektronischer Form bereitgestellt werden. Die Betriebsanleitung und alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Wenn die Betriebsanleitung in elektronischer Form bereitgestellt wird, muss der Hersteller

a) auf dem Aufzug oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Aufzugs darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Aufzugs eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Geräts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Aufzugs online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Aufzugs oder bis zu sechs Monate nach dem Kauf Anweisungen in Papierform anfordern. Fordert der Endnutzer diese Anweisungen an, so stellt der Montagebetrieb sie dem Endnutzer innerhalb eines Monats nach Eingang der Anfrage kostenlos zur Verfügung.“

  - d) Absatz 9 Unterabsatz 1 erhält folgende Fassung:

„Die Montagebetriebe stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Aufzugs mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 8 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit diesem Verfahren nachgewiesen, dass ein Sicherheitsbauteil für Aufzüge den anwendbaren wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen entspricht, stellt der Hersteller eine EU-Konformitätserklärung in elektronischer Form aus, sorgt dafür, dass dem Sicherheitsbauteil für Aufzüge die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, beigefügt ist, und bringt die CE-Kennzeichnung an.“

  - b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Produkts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder sonstiger technischer Spezifikationen, auf die bei Erklärung der Konformität eines Sicherheitsbauteils für Aufzüge verwiesen wird, sind angemessen zu berücksichtigen.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Sicherheitsbauteil für Aufzüge oder, wenn dies nicht möglich ist, auf dem Typenschild nach Artikel 19 Absatz 1 an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 erhält folgende Fassung:

„(7) Die Hersteller stellen sicher, dass dem Sicherheitsbauteil für Aufzüge die Betriebsanleitung nach Anhang I Nummer 6.1 beigefügt ist, die in einer Sprache, die von den Endnutzern leicht verstanden werden kann, gemäß der Entscheidung des betreffenden Mitgliedstaats zur Verfügung gestellt wird. Die Betriebsanleitung kann in elektronischer Form bereitgestellt werden. Die Betriebsanleitung und alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Wenn die Betriebsanleitung in elektronischer Form bereitgestellt wird, muss der Hersteller

a) auf dem Sicherheitsbauteil für Aufzüge oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Sicherheitsbauteils für Aufzüge eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Sicherheitsbauteils für Aufzüge und mindestens zehn Jahre lang nach dem Inverkehrbringen des Sicherheitsbauteils für Aufzüge online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Sicherheitsbauteils für Aufzüge oder bis zu sechs Monate nach dem Kauf Anweisungen in Papierform anfordern. Fordert der Endnutzer diese Anweisungen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - e) Absatz 9 Unterabsatz 1 Satz 1 erhält folgende Fassung:

„Die Hersteller händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen alle Informationen und Unterlagen, die für den Nachweis der Konformität des Sicherheitsbauteils für Aufzüge mit dieser Richtlinie erforderlich sind, in einer Sprache aus, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 4. Artikel 9 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität des Sicherheitsbauteils für Aufzüge bzw. des Aufzugs an diese Behörde;“

- 5. Artikel 10 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Sie sorgen dafür, dass der Hersteller die technischen Unterlagen erstellt hat, dass das Sicherheitsbauteil für Aufzüge mit der CE-Kennzeichnung versehen ist, dass ihm die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, und die erforderlichen Unterlagen beigefügt sind und dass der Hersteller die Anforderungen nach Artikel 8 Absätze 5 und 6 erfüllt hat.“

  - b) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Sicherheitsbauteil für Aufzüge oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Sicherheitsbauteil beigefügten Unterlagen an.“

  - c) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität eines Sicherheitsbauteils für Aufzüge erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 6. Artikel 11 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 1 erhält folgende Fassung:

„Bevor sie ein Sicherheitsbauteil für Aufzüge auf dem Markt bereitstellen, überprüfen die Händler, ob das Sicherheitsbauteil für Aufzüge mit der CE-Kennzeichnung versehen ist, ob ihm die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann, die erforderlichen Unterlagen und die in Anhang I Nummer 6.1 genannte Betriebsanleitung in einer Sprache beigefügt sind, die von den Endnutzern leicht verstanden werden kann, gemäß der Entscheidung des betreffenden Mitgliedstaats, und ob der Hersteller und der Einführer die Anforderungen nach Artikel 8 Absätze 5 und 6 bzw. Artikel 10 Absatz 3 erfüllt haben.“

  - b) Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines Sicherheitsbauteils für Aufzüge erforderlich sind.“

- 7. Folgender Artikel 14a wird eingefügt:

„Artikel 14a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Anhang I festgelegten grundlegenden Anforderungen ermöglichen:

    a) Die in Anhang I festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die Anforderungen gemäß Anhang I werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Aufzüge und Sicherheitsbauteile für Aufzüge nicht den grundlegenden Anforderungen gemäß Anhang I entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Aufzüge und Bauteile für Aufzüge auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 42 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Aufzügen und Sicherheitsbauteilen für Aufzüge, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Anhang I festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 8. In Artikel 15 wird folgender Unterabsatz angefügt:

„Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren für Sicherheitsbauteile für Aufzüge in elektronischer Form zur Verfügung.“

- 9. In Artikel 16 wird der folgende Absatz 5 angefügt:

„(5) Der Montagebetrieb stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 10. In Artikel 17 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für Aufzüge oder Sicherheitsbauteile für Aufzüge geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang II in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 7 Absatz 7 und Artikel 8 Absatz 7 genannte Betriebsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 11. Artikel 24 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen in Anhang I, der anwendbaren harmonisierten Normen oder gemeinsamen Spezifikationen sowie der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der betreffenden nationalen Rechtsvorschriften;“

- 12. Artikel 32 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine notifizierte Stelle fest, dass ein Montagebetrieb oder Hersteller die wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen dieser Richtlinie oder entsprechende harmonisierte Normen oder gemeinsame Spezifikationen oder andere technische Spezifikationen nicht erfüllt hat, fordert sie den Montagebetrieb oder den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Bescheinigung aus.“

- 13. Artikel 41 Absatz 1 Buchstabe g erhält folgende Fassung:

„g) der Name, der eingetragene Handelsname oder die eingetragene Handelsmarke, die Postanschrift oder die digitalen Kontaktdaten des Montagebetriebs, des Herstellers oder des Einführers wurden nicht nach Maßgabe von Artikel 7 Absatz 6, Artikel 8 Absatz 6 oder Artikel 10 Absatz 3 angegeben;“

- 14. Die Anhänge II und IV bis XII werden gemäß Anhang VIII dieser Richtlinie geändert.

<a id="art-9"></a>
### Artikel 9

Änderung der Richtlinie 2014/34/EU

Die Richtlinie 2014/34/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 16a wird eingefügt:

„16a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 18a wird eingefügt:

„18a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 6 wird wie folgt geändert:

  - a) Absatz 2 Unterabsätze 2, 3 und 4 erhalten folgende Fassung:

„Wurde mit diesem Verfahren nachgewiesen, dass das Produkt, das keine Komponente ist, den anwendbaren Anforderungen entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung an.

Wurde mit dem entsprechenden Konformitätsbewertungsverfahren nachgewiesen, dass eine Komponente den anwendbaren Anforderungen entspricht, stellen die Hersteller eine schriftliche Konformitätsbescheinigung in elektronischer Form nach Artikel 13 Absatz 3 aus.

Die Hersteller stellen sicher, dass jedem Produkt die Internetadresse oder der maschinenlesbare Code beigefügt ist, über die bzw. den die EU-Konformitätserklärung bzw. die Konformitätsbescheinigung abgerufen werden kann. Wenn allerdings eine große Zahl von Produkten an ein und denselben Endnutzer geliefert wird, kann der betreffenden Charge oder Lieferung ein einziger Träger mit der Internetadresse oder dem maschinenlesbaren Code beigefügt sein, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann.“

  - b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Produkts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder anderer technischer Spezifikationen, auf die bei Erklärung der Konformität eines Produkts verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 7 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Produkt selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Produkt beigefügten Unterlagen an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 8 erhält folgende Fassung:

„(8) Die Hersteller gewährleisten, dass dem Produkt die Gebrauchsanweisungen und die Sicherheitsinformationen beigefügt sind; sie werden gemäß der Entscheidung des betreffenden Mitgliedstaats in einer Sprache, die von den Verbrauchern und sonstigen Endnutzern leicht verstanden werden kann, zur Verfügung gestellt. Die Betriebsanleitung und die Sicherheitsinformationen können in elektronischer Form bereitgestellt werden. Diese Betriebsanleitung und Sicherheitsinformationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Gebrauchsanweisungen und die Sicherheitsinformationen den Verwendungszweck und die voraussichtlichen Endnutzer des Produkts.

Bei Produkten, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, muss der Hersteller die Sicherheitsinformationen in Papierform bereitstellen oder auf dem Produkt anbringen. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Sicherheitsinformationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung für die Gewährleistung der Sicherheit spielt.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Produkt oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Produkts, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Produkts eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Produkts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Produkts online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Produkts oder bis zu sechs Monate nach dem Kauf die Anleitung oder die Sicherheitsinformationen in Papierform anfordern. Fordert der Endnutzer diese Anleitung oder Sicherheitsinformationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - e) Absatz 10 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Produkts mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 7 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines Produkts an diese Behörde;“

- 4. Artikel 8 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Sie gewährleisten, dass der Hersteller die technischen Unterlagen erstellt hat, dass das Produkt, sofern erforderlich, mit der CE-Kennzeichnung versehen und ihm die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung bzw. die Konformitätsbescheinigung abgerufen werden kann, sowie die erforderlichen Unterlagen beigefügt sind und dass der Hersteller die Anforderungen von Artikel 6 Absätze 5, 6 und 7 erfüllt hat.“

  - b) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Produkt selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Produkt beigefügten Unterlagen an.“

  - c) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Behälters erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 9 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 1 erhält folgende Fassung:

„Bevor sie ein Produkt auf dem Markt bereitstellen, überprüfen die Händler, ob das Produkt, sofern erforderlich, mit der CE-Kennzeichnung versehen und ihm die Internetadresse oder der maschinenlesbare Code, über die bzw. den die EU-Konformitätserklärung oder die Konformitätsbescheinigung abgerufen werden kann, sowie die erforderlichen Unterlagen und die Betriebsanleitung und die Sicherheitsinformationen in einer Sprache beigefügt sind, die von den Verbrauchern und sonstigen Endnutzern in dem Mitgliedstaat, in dem das Produkt auf dem Markt bereitgestellt werden soll, leicht verstanden werden kann, und ob der Hersteller und der Einführer die Anforderungen von Artikel 6 Absätze 5, 6 und 7 und von Artikel 8 Absatz 3 erfüllt haben.“

  - b) Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines Produkts erforderlich sind.“

- 6. Folgender Artikel 12a wird eingefügt:

„Artikel 12a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Anhang II festgelegten grundlegenden Anforderungen ermöglichen:

    a) Die in Anhang II festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die Anforderungen gemäß Anhang II werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Produkte nicht den grundlegenden Anforderungen gemäß Anhang II entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Produkte auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 39 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Produkten, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Anhang II festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 13 wird wie folgt geändert:

  - a) Absatz 6 erhält folgende Fassung:

„(6) Die Unterlagen und der Schriftwechsel betreffend die Konformitätsbewertungsverfahren nach den Absätzen 1 bis 4 werden in elektronischer Form in einer von dem betreffenden Mitgliedstaat festgelegten Sprache abgefasst.“

  - b) Folgender Absatz 7 wird angefügt:

„(7) Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 8. In Artikel 14 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für ein Produkt geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang X in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 6 Absatz 7 genannte Gebrauchsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 9. Artikel 21 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Gesundheits- und Sicherheitsanforderungen nach Anhang II, der geltenden harmonisierten Normen oder gemeinsamen Spezifikationen und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union sowie der nationalen Rechtsvorschriften;“

- 10. Artikel 29 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine notifizierte Stelle fest, dass ein Hersteller die wesentlichen Gesundheits- und Sicherheitsanforderungen nicht erfüllt hat, die in Anhang II oder in den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen oder anderen technischen Spezifikationen festgelegt sind, fordert sie den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Konformitätsbescheinigung aus.“

- 11. Artikel 38 Absatz 1 Buchstabe e erhält folgende Fassung:

„e) dem Produkt keine Internetadresse oder kein maschinenlesbarer Code beigefügt ist, über die bzw. den die EU-Konformitätserklärung bzw. die Konformitätsbescheinigung abgerufen werden kann;“

- 12. Die Anhänge II bis V und VII bis X werden gemäß Anhang IX dieser Richtlinie geändert.

<a id="art-10"></a>
### Artikel 10

Änderung der Richtlinie 2014/35/EU

Die Richtlinie 2014/35/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 7a wird eingefügt:

„7a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 9a wird eingefügt:

„9a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Sicherheitsziele bieten.“

- 2. Artikel 6 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit dem Konformitätsbewertungsverfahren nach Unterabsatz 1 nachgewiesen, dass ein elektrisches Betriebsmittel den Sicherheitszielen nach Artikel 3 und Anhang I entspricht, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung an.“

  - b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf des Produkts oder an seinen Merkmalen sowie Änderungen der in Artikel 12 genannten harmonisierten Normen, der in Artikel 12a genannten gemeinsamen Spezifikationen, der in den Artikeln 13 und 14 genannten internationalen oder nationalen Normen oder anderer technischer Spezifikationen, auf die bei Erklärung der Konformität eines elektrischen Betriebsmittels verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem elektrischen Betriebsmittel selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem elektrischen Betriebsmittel beigefügten Unterlagen an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 erhält folgende Fassung:

„(7) Die Hersteller gewährleisten, dass dem elektrischen Betriebsmittel eine Betriebsanleitung und Sicherheitsinformationen beigefügt sind, die in einer vom betreffenden Mitgliedstaat festgelegten Sprache, die von den Verbrauchern und sonstigen Endnutzern leicht verstanden werden kann, verfasst sind. Die Betriebsanleitung und die Sicherheitsinformationen können in elektronischer Form bereitgestellt werden. Diese Betriebsanleitung und Sicherheitsinformationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Betriebsanleitung und die Sicherheitsinformationen den Verwendungszweck und die voraussichtlichen Endnutzer des elektrischen Betriebsmittels.

Bei elektrischen Betriebsmitteln, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, muss der Hersteller die Sicherheitsinformationen in Papierform bereitstellen oder auf dem Gerät anbringen. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Sicherheitsinformationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung für die Gewährleistung der Sicherheit spielt.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem elektrischen Betriebsmittel oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Nutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass er jederzeit, insbesondere bei einem Ausfall des elektrischen Betriebsmittels, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des elektrischen Betriebsmittels eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des elektrischen Betriebsmittels und mindestens zehn Jahre lang nach dem Inverkehrbringen des elektrischen Betriebsmittels online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des elektrischen Betriebsmittels oder bis zu sechs Monate nach dem Kauf Gebrauchsanweisungen oder Sicherheitsinformationen in Papierform anfordern. Fordert der Endnutzer diese Anleitung oder Sicherheitsinformationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - e) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des elektrischen Betriebsmittels mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 7 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines elektrischen Betriebsmittels an diese Behörde;“

- 4. Artikel 8 wird wie folgt geändert:

  - a) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem elektrischen Betriebsmittel selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem elektrischen Betriebsmittel beigefügten Unterlagen an.“

  - b) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität eines elektrischen Betriebsmittels erforderlich sind, in einer Sprache aus, die von dieser Behörde leicht verstanden werden kann.“

- 5. Artikel 9 Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines elektrischen Betriebsmittels erforderlich sind.“

- 6. Folgender Artikel 14a wird eingefügt:

„Artikel 14a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Artikel 3 genannten und in Anhang I festgelegten Sicherheitsziele ermöglichen:

    a) Die in Artikel 3 genannten und in Anhang I festgelegten Ziele sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die in Artikel 3 genannten und in Anhang I festgelegten Ziele werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass elektrische Betriebsmittel nicht den grundlegenden Anforderungen gemäß Anhang II entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer elektrischer Betriebsmittel auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 23 Absatz 3a genannten Beratungsverfahren erlassen.

(2) Bei elektrischen Betriebsmitteln, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den Sicherheitszielen übereinstimmen, die von diesen in Artikel 3 genannten und in Anhang I festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. In Artikel 15 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für elektrische Betriebsmittel geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 6 Absatz 7 genannte Gebrauchsanweisungen nur in diesem digitalen Produktpass bereitzustellen.“

- 8. In Artikel 23 wird folgender Absatz 3a eingefügt:

„(3a) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 4 der Verordnung (EU) Nr. 182/2011.“

- 9. Die Anhänge III und IV werden entsprechend dem Anhang X dieser Richtlinie geändert.

<a id="art-11"></a>
### Artikel 11

Änderung der Richtlinie 2014/53/EU

Die Richtlinie 2014/53/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 16a wird eingefügt:

„16a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 18a wird eingefügt:

„18a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 10 wird wie folgt geändert:

  - a) Absatz 3 Unterabsatz 2 erhält folgende Fassung:

„Wurde die Konformität der Funkanlage mit den geltenden Anforderungen im Rahmen dieses Konformitätsbewertungsverfahrens nachgewiesen, stellt der Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringt das CE-Zeichen an.“

  - b) Artikel 5 Satz 2 erhält folgende Fassung:

„Änderungen des Entwurfs einer Funkanlage oder an ihren Merkmalen sowie Änderungen der harmonisierten Normen, der gemeinsamen Spezifikationen oder sonstiger technischer Spezifikationen, auf die bei Erklärung der Konformität einer Funkanlage verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 7 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf der Funkanlage selbst oder, falls dies aufgrund der Größe oder Art der Funkanlage nicht möglich ist, auf der Verpackung oder in den der Funkanlage beigefügten Unterlagen an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 8 erhält folgende Fassung:

„(8) Die Hersteller stellen sicher, dass der Funkanlage eine Gebrauchsanleitung und Sicherheitsinformationen beiliegen. Die Gebrauchsanleitung und Sicherheitsinformationen können gemäß Unterabsatz 6 dieses Absatzes in elektronischer Form zur Verfügung gestellt werden. Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Gebrauchsanleitung und die Sicherheitsinformationen den Verwendungszweck und die voraussichtlichen Endnutzer der Funkanlage. Die Gebrauchsanleitung umfasst die Informationen, die für die bestimmungsgemäße Verwendung der Funkanlage erforderlich sind. Dazu gehört gegebenenfalls eine Beschreibung des Zubehörs und der Bestandteile, einschließlich Software, die den bestimmungsgemäßen Betrieb der Funkanlage ermöglichen. Diese Betriebsanleitung und Sicherheitsinformationen sowie alle Kennzeichnungen müssen klar, verständlich und deutlich sein.

Strahlt die Funkanlage bestimmungsgemäß Funkwellen aus, so müssen in der Gebrauchsanleitung auch die folgenden Informationen enthalten sein:

a) das Frequenzband oder die Frequenzbänder, in dem bzw. denen die Funkanlage betrieben wird,

b) die in dem Frequenzband oder den Frequenzbändern, in dem bzw. denen die Funkanlage betrieben wird, ausgestrahlte maximale Sendeleistung.

Bei Funkanlagen im Sinne von Artikel 3 Absatz 4 sind gemäß Anhang Ia Teil II in der Gebrauchsanleitung die Angaben zur Ladefunktion der Funkanlagen und zu den kompatiblen Ladenetzteilen enthalten. Stellen die Hersteller Verbrauchern und anderen Endnutzern solche Funkanlagen zur Verfügung, sind diese Informationen nicht nur in der Gebrauchsanleitung, sondern auch auf einem Etikett gemäß Anhang Ia Teil IV anzugeben. Das Etikett ist in der Gebrauchsanleitung enthalten und wird auf die Verpackung gedruckt oder als Aufkleber auf der Verpackung angebracht. Wenn es keine Verpackung gibt, wird der Aufkleber mit dem Etikett auf der Funkanlage angebracht. Wenn die Funkanlage Verbrauchern und anderen Endnutzern zur Verfügung gestellt wird, ist das Etikett gut sichtbar und leserlich angebracht; im Falle des Fernabsatzes befindet sich das Etikett in der Nähe der Preisangabe. Wenn dies aufgrund der Größe oder der Art der Funkanlage nicht möglich ist, kann das Etikett als gesondertes Begleitdokument zu der Funkanlage ausgedruckt werden.

Die Gebrauchsanleitung und die Sicherheitsinformationen im Sinne der Unterabsätze 1, 2 und 3 dieses Absatzes sind in einer von dem betreffenden Mitgliedstaat festgelegten Sprache verfasst, die von Verbrauchern und sonstigen Endbenutzern leicht verstanden werden kann.

Der Kommission wird die Befugnis übertragen, gemäß Artikel 44 delegierte Rechtsakte zu erlassen, um Anhang Ia Teile II und IV infolge von Änderungen an Teil I des genannten Anhangs oder infolge künftiger Änderungen der Kennzeichnungsvorschriften oder angesichts des technischen Fortschritts durch die Einführung, Änderung, Hinzufügung oder Entfernung von Einzelheiten bezüglich der in dem vorliegenden Artikel genannten Informations-, Grafik- oder Textelemente zu ändern.“

Bei Funkanlagen, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, stellt der Hersteller die Sicherheitsinformationen in Papierform zur Verfügung. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Sicherheitsinformationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung für die Gewährleistung der Sicherheit spielt.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf der Funkanlage oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Nutzer ermöglicht, die Gebrauchsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass er jederzeit, insbesondere bei einem Ausfall der Funkanlage, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Gebrauchsanleitung in die Software der Funkanlage eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer der Funkanlage und mindestens zehn Jahre lang nach dem Inverkehrbringen der Funkanlage online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs der Funkanlage oder bis zu sechs Monate nach dem Kauf die Gebrauchsanleitung oder Sicherheitsinformationen in Papierform anfordern. Fordert der Endnutzer diese Anleitung oder Sicherheitsinformationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - e) Absatz 9 wird wie folgt geändert:

    - i) Satz 1 erhält folgende Fassung:

„Die Hersteller stellen sicher, dass jeder Funkanlage die Internetadresse oder der maschinenlesbare Code beigefügt ist, über die bzw. den die EU-Konformitätserklärung abgerufen werden kann.“

    - ii) Der zweite Satz wird gestrichen.

  - f) Absatz 12 Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität der Funkanlage mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 3. Artikel 11 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität einer Funkanlage an diese Behörde;“

- 4. Artikel 12 wird wie folgt geändert:

  - a) Absatz 3 die Sätze 1 und 2 erhalten folgende Fassung:

„Die Einführer geben auf der Funkanlage ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten oder, wenn dies nicht möglich ist, auf der Verpackung oder in den der Funkanlage beigefügten Unterlagen an. Dies gilt auch für Fälle, in denen dies aufgrund der Größe der Funkanlage nicht möglich ist oder der Einführer zum Anbringen seines Namens sowie seiner Postanschrift und seiner digitalen Kontaktdaten die Verpackung öffnen müsste.“

  - b) Absatz 9 Satz 1 erhält folgende Fassung:

„Die Einführer stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität der Funkanlage mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

- 5. Artikel 13 Absatz 5 Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität einer Funkanlage erforderlich sind.“

- 6. Folgender Artikel 16a wird eingefügt:

„Artikel 16a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Artikel 3 festgelegten grundlegenden Anforderungen ermöglichen:

    a) Die in Artikel 3 festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die Anforderungen gemäß Artikel 3 werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Funkanlagen nicht den grundlegenden Anforderungen gemäß Artikel 3 entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Funkanlagen auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 45 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Funkanlagen, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Artikel 3 festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 17 wird wie folgt geändert:

  - a) Absatz 3 Satz 1 erhält folgende Fassung:

„(3) Hat der Hersteller bei der Bewertung der Konformität von Funkanlagen mit den grundlegenden Anforderungen in Artikel 3 Absätze 2 und 3 harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsame Spezifikationen angewandt, so wendet er eines der folgenden Verfahren an:“

  - b) Absatz 4 Satz 1 erhält folgende Fassung:

„(4) Hat der Hersteller bei der Bewertung der Konformität von Funkanlagen mit den grundlegenden Anforderungen in Artikel 3 Absätze 2 und 3 harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsame Spezifikationen nicht oder nur zum Teil angewandt oder sind solche harmonisierten Normen oder gemeinsamen Spezifikationen nicht vorhanden, so sind die Funkanlagen im Hinblick auf die grundlegenden Anforderungen einem der folgenden Verfahren zu unterziehen:“

  - c) Folgender Absatz 5 wird angefügt:

„(5) Gegebenenfalls stellt der Hersteller der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 8. Artikel 18 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 wird gestrichen.

  - b) Folgender Absatz 5 wird angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für Funkanlagen geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 10 Absatz 8 genannte Gebrauchsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 9. Artikel 26 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und angemessenes Verständnis der grundlegenden Anforderungen gemäß Artikel 3, der anwendbaren harmonisierten Normen und gemeinsamen Spezifikationen sowie der einschlägigen Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der nationalen Rechtsvorschriften;“

- 10. Die Anhänge Ia und III, IV, V, VI und VII werden gemäß Anhang XI dieser Richtlinie geändert.

<a id="art-12"></a>
### Artikel 12

Änderung der Richtlinie 2014/68/EU

Die Richtlinie 2014/68/EU wird wie folgt geändert:

- 1. Artikel 2 wird wie folgt geändert:

  - a) Folgende Nummer 22a wird eingefügt:

„22a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

  - b) Folgende Nummer 24a wird eingefügt:

„24a) ‚Gemeinsame Spezifikationen‘ eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt, die Mittel zur Einhaltung der für ein Produkt, ein Gerät, einen Dienst, ein Verfahren oder ein System geltenden Anforderungen bieten.“

- 2. Artikel 6 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 erhält folgende Fassung:

„Wurde mit dem Verfahren gemäß Unterabsatz 1 dieses Absatzes nachgewiesen, dass die Druckgeräte oder Baugruppen nach Artikel 4 Absätze 1 und 2 den geltenden Anforderungen entsprechen, stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form aus und bringen die CE-Kennzeichnung an.“

  - b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Änderungen am Entwurf oder den Merkmalen des Druckgeräts oder der Baugruppe sowie Änderungen der harmonisierten Normen oder der gemeinsamen Spezifikationen oder der sonstigen technischen Spezifikationen, auf die bei Erklärung der Konformität eines Druckgeräts oder einer Baugruppe verwiesen wird, werden angemessen berücksichtigt.“

  - c) Absatz 6 Sätze 1 und 2 erhalten folgende Fassung:

„Die Hersteller geben auf dem Druckgerät bzw. der Baugruppe oder, wenn dies nicht möglich ist, auf der Verpackung oder in den Druckgeräten oder Baugruppen beigefügten Unterlagen ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten an. In der Postanschrift und den digitalen Kontaktdaten wird eine zentrale Stelle angegeben, über die der Hersteller erreichbar ist.“

  - d) Absatz 7 erhält folgende Fassung:

„(7) Die Hersteller gewährleisten, dass den Druckgeräten oder Baugruppen nach Artikel 4 Absätze 1 und 2 die Betriebsanleitung und die Sicherheitsinformationen nach Anhang I Nummern 3.3 und 3.4 beigefügt sind; sie werden gemäß der Entscheidung des betreffenden Mitgliedstaats in einer Sprache, die von den Verbrauchern und anderen Endnutzern leicht verstanden werden kann, zur Verfügung gestellt. Die Betriebsanleitung und die Sicherheitsinformationen können in elektronischer Form bereitgestellt werden. Die Betriebsanleitung und die Sicherheitsinformationen müssen klar, verständlich und deutlich sein.

Die Hersteller gewährleisten, dass den Druckgeräten oder Baugruppen nach Artikel 4 Absatz 3 die Betriebsanleitung und die Sicherheitsinformationen nach Artikel 4 Absatz 3 beigefügt sind; sie werden gemäß der Entscheidung des betreffenden Mitgliedstaats in einer Sprache, die von den Verbrauchern und anderen Endnutzern leicht verstanden werden kann, zur Verfügung gestellt. Die Betriebsanleitung und die Sicherheitsinformationen können in elektronischer Form bereitgestellt werden. Die Betriebsanleitung und die Sicherheitsinformationen müssen klar, verständlich und deutlich sein.

Der Hersteller berücksichtigt bei der Festlegung des spezifischen Formats für die Betriebsanleitung und die Sicherheitsinformationen den Verwendungszweck und die voraussichtlichen Endnutzer der Druckgeräte oder Baugruppen.

Bei Druckgeräten oder Baugruppen, die für Verbraucher bestimmt sind oder unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, stellt der Hersteller die Sicherheitsinformationen gemäß Anhang I Nummern 3.3 und 3.4 in Papierform zur Verfügung. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Bei der Abfassung der Sicherheitsinformationen berücksichtigen die Hersteller die bestimmungsgemäße Verwendung und vorhersehbare Fehlanwendung durch Endnutzer sowie die Rolle, die die Anleitung für die Gewährleistung der Sicherheit spielt.

Werden die in Unterabsatz 1 genannten Anweisungen in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Druckgerät oder den Baugruppen oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie auf sie zugegriffen werden kann und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Druckgeräts oder der Baugruppen, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Druckgeräts oder der Baugruppen eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Druckgeräts oder der Baugruppen und mindestens zehn Jahre lang nach dem Inverkehrbringen des Druckgeräts oder der Baugruppen online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Druckgeräts oder der Baugruppen oder bis zu sechs Monate nach dem Kauf die Betriebsanleitung oder die Sicherheitsinformationen in Papierform anfordern. Fordert der Endnutzer diese Anleitung oder Sicherheitsinformationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - e) Absatz 9 wird wie folgt geändert:

    - a) Satz 1 erhält folgende Fassung:

„Die Hersteller stellen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Druckgeräts oder der Baugruppen mit dieser Richtlinie erforderlich sind, in einer Sprache zur Verfügung, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

    - b) Der zweite Satz wird gestrichen.

- 3. Artikel 7 Absatz 2 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen nationalen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität des Druckgeräts oder der Baugruppen an diese Behörde;“

- 4. Artikel 8 wird wie folgt geändert:

  - a) Absatz 3 Satz 1 erhält folgende Fassung:

„Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten auf dem Druckgerät bzw. der Baugruppe selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Druckgerät oder der Baugruppe beigefügten Unterlagen an.“

  - b) Absatz 9 wird wie folgt geändert:

    - a) Satz 1 erhält folgende Fassung:

„Die Einführer händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität eines Druckgeräts oder einer Baugruppe erforderlich sind, in einer Sprache aus, die von dieser zuständigen nationalen Behörde leicht verstanden werden kann.“

    - b) Der zweite Satz wird gestrichen.

- 5. Artikel 9 wird wie folgt geändert:

  - a) Satz 1 erhält folgende Fassung:

„Die Händler händigen der zuständigen nationalen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen aus, die für den Nachweis der Konformität eines Druckgeräts oder einer Baugruppe erforderlich sind.“

  - b) Der zweite Satz wird gestrichen.

- 6. Folgender Artikel 12a wird eingefügt:

„Artikel 12a

Gemeinsame Spezifikationen

(1) Die Kommission kann in folgenden Fällen im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen erlassen, die die Einhaltung der in Anhang I festgelegten grundlegenden Anforderungen ermöglichen:

    a) Die in Anhang I festgelegten Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

    b) die Anforderungen gemäß Anhang I werden von harmonisierten Normen oder von Teilen von harmonisierten Normen abgedeckt, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, die Anwendung dieser Normen oder von Teilen dieser Normen führt jedoch dazu, dass Druckgeräten oder Baugruppen nach Artikel 4 Absätze 1 und 2 nicht den grundlegenden Anforderungen gemäß Anhang I entsprechen; oder

    c) wenn die Kommission der Auffassung ist, dass dringende Bedenken hinsichtlich nicht konformer Druckgeräte oder Baugruppen auszuräumen sind.

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 44 Absatz 2 genannten Beratungsverfahren erlassen.

(2) Bei Druckgeräten oder Baugruppen, die mit der gemeinsamen Spezifikation übereinstimmen, wird davon ausgegangen, dass sie mit den grundlegenden Anforderungen übereinstimmen, die von diesen in Anhang I festgelegten gemeinsamen Spezifikationen oder Teilen davon abgedeckt sind.“

- 7. Artikel 14 wird wie folgt geändert:

  - a) Absatz 8 erhält folgende Fassung:

„(8) Aufzeichnungen und Schriftwechsel im Zusammenhang mit den Konformitätsbewertungsverfahren werden in elektronischer Form in einer Amtssprache des Mitgliedstaats abgefasst, in dem die für die Durchführung der Konformitätsbewertungsverfahren zuständige Stelle ihren Sitz hat, oder in einer anderen von dieser Stelle anerkannten Sprache.“

  - b) Folgender Absatz 9 wird angefügt:

„(9) Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 8. Artikel 15 Absatz 5 Satz 1 erhält folgende Fassung:

„Die notifizierte Stelle, die die europäische Werkstoffzulassung erteilt hat, zieht diese Zulassung zurück, wenn sie feststellt, dass die Zulassung nicht hätte erteilt werden dürfen, oder wenn der Werkstofftyp von einer harmonisierten Norm oder gemeinsamen Spezifikationen erfasst wird.“

- 9. In Artikel 17 wird der folgende Absatz 5 angefügt:

„(5) Ist der Wirtschaftsakteur aufgrund anderer für das Druckgerät oder die Baugruppe geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang IV in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 6 Absatz 7 genannte Betriebsanleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 10. Artikel 24 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Sicherheitsanforderungen nach Anhang I, der geltenden harmonisierten Normen oder gemeinsamen Spezifikationen und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der nationalen Rechtsvorschriften,“

- 11. Artikel 25 Absatz 7 Buchstabe c erhält folgende Fassung:

„c) angemessene Kenntnisse und Verständnis der wesentlichen Sicherheitsanforderungen nach Anhang I, der geltenden harmonisierten Normen oder gemeinsamen Spezifikationen und der betreffenden Bestimmungen der Harmonisierungsrechtsvorschriften der Union und der nationalen Rechtsvorschriften,“

- 12. Artikel 34 Absatz 3 erhält folgende Fassung:

„(3) Stellt eine Konformitätsbewertungsstelle fest, dass ein Hersteller die wesentlichen Sicherheitsanforderungen nicht erfüllt hat, die in Anhang I, den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen oder sonstigen technischen Spezifikationen festgelegt sind, fordert sie den Hersteller auf, angemessene Korrekturmaßnahmen zu ergreifen, und stellt keine Konformitätsbescheinigung aus.“

- 13. Die Anhänge I, III und IV werden entsprechend Anhang XII der vorliegenden Richtlinie geändert.

<a id="art-13"></a>
### Artikel 13

Änderung der Richtlinie 2014/90/EU

Die Richtlinie 2014/90/EU wird wie folgt geändert:

- 1. In Artikel 2 wird folgende Nummer 14a eingefügt:

„14a) ‚digitale Kontaktdaten‘ jeden aktuellen und zugänglichen Online-Kommunikationskanal, über den Wirtschaftsteilnehmer erreicht oder kontaktiert werden können, ohne dass eine Registrierung oder das Herunterladen einer Anwendung erforderlich ist.“

- 2. Artikel 12 wird wie folgt geändert:

  - a) Absatz 3 erhält folgende Fassung:

„(3) Wurde durch das Konformitätsbewertungsverfahren nachgewiesen, dass die Schiffsausrüstung den geltenden Anforderungen entspricht, so stellen die Hersteller eine EU-Konformitätserklärung in elektronischer Form entsprechend Artikel 16 aus und bringen das Steuerrad-Kennzeichen nach den Artikeln 9 und 10 an.“

  - b) Die Absätze 7 und 8 erhalten folgende Fassung:

„(7) Die Hersteller geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Produkt selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Produkt beigefügten Unterlagen oder, soweit angemessen, auf bzw. in beiden an. In der Postanschrift und den digitalen Kontaktdaten muss eine zentrale Stelle angegeben werden, über die der Hersteller erreichbar ist.

(8) Die Hersteller gewährleisten, dass dem Produkt Anleitungen und alle erforderlichen Informationen für die sichere Installation an Bord und die sichere Verwendung des Produkts, auch hinsichtlich eventueller Beschränkungen der Verwendung, beiliegen, die für die Endbenutzer leicht verständlich sind, sowie alle anderen aufgrund der internationalen Instrumente oder Prüfnormen vorgeschriebenen Unterlagen. Die Anleitungen und alle erforderlichen Informationen können in elektronischer Form bereitgestellt werden.

Bei Produkten, die für Verbraucher bestimmt sind oder die unter vernünftigerweise vorhersehbaren Bedingungen von Verbrauchern verwendet werden können, auch wenn sie nicht für sie bestimmt sind, stellt der Hersteller Informationen über die sichere Installation an Bord und die sichere Verwendung des Produkts, einschließlich eventueller Beschränkungen der Verwendung, in Papierform zur Verfügung oder bringt sie auf dem Produkt an. Diese Sicherheitsinformationen müssen für die Verbraucher gut sichtbar und lesbar sein.

Wird die in Unterabsatz 1 genannte Anleitung in elektronischer Form bereitgestellt, so muss der Hersteller

a) auf dem Produkt oder, wenn dies nicht möglich ist, auf der Verpackung oder in einem Begleitdokument angeben, wie sie zugänglich sind und wie sie in Papierform angefordert werden können;

b) diese in einem Format bereitstellen, das es dem Endnutzer ermöglicht, die Betriebsanleitung auszudrucken, herunterzuladen und auf einem elektronischen Gerät zu speichern, sodass der Endnutzer jederzeit, insbesondere bei einem Ausfall des Produkts, darauf zugreifen kann; diese Anforderung gilt auch dann, wenn die Betriebsanleitung in die Software des Produkts eingebettet ist;

c) sie während der voraussichtlichen Lebensdauer des Produkts und mindestens zehn Jahre lang nach dem Inverkehrbringen des Produkts online zugänglich machen.

Der Endnutzer kann jedoch zum Zeitpunkt des Kaufs des Produkts oder bis zu sechs Monate nach dem Kauf Anleitungen oder Informationen für die sichere Installation an Bord und die sichere Verwendung des Produkts, einschließlich Beschränkungen der Verwendung, in Papierform anfordern. Fordert der Endnutzer diese Anleitungen oder Informationen an, so stellt der Hersteller sie dem Endnutzer innerhalb eines Monats nach Eingang der Aufforderung kostenlos zur Verfügung.“

  - c) Absatz 10 Satz 1 erhält folgende Fassung:

„Die Hersteller händigen einer zuständigen Behörde auf deren begründetes Verlangen umgehend alle Informationen und Unterlagen, die für den Nachweis der Konformität des Produkts erforderlich sind, in elektronischer Form und in einer für diese Behörde leicht verständlichen oder annehmbaren Sprache aus, gewähren dieser Behörde entsprechend Artikel 19 der Verordnung (EG) Nr. 765/2008 Zugang zu ihren Räumlichkeiten für Marktüberwachungsmaßnahmen und stellen gemäß Artikel 25 Absatz 4 der vorliegenden Richtlinie Produktmuster bereit oder gewähren Zugang zu den Mustern.“

- 3. Artikel 13 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

„(1) Ein Hersteller, der seinen Sitz nicht im Gebiet mindestens eines Mitgliedstaats hat, benennt schriftlich einen Bevollmächtigten für die Union; in dem betreffenden Auftrag sind der Name des Bevollmächtigten sowie die Postanschrift und die digitalen Kontaktdaten anzugeben, über die er erreichbar ist.“

  - b) Absatz 3 Buchstabe b erhält folgende Fassung:

„b) auf begründetes Verlangen einer zuständigen Behörde Aushändigung in elektronischer Form aller erforderlichen Informationen und Unterlagen zum Nachweis der Konformität eines Produkts an diese Behörde;“

- 4. Artikel 14 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

„(1) Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke sowie ihre Postanschrift und ihre digitalen Kontaktdaten entweder auf dem Produkt selbst oder, wenn dies nicht möglich ist, auf der Verpackung oder in den dem Produkt beigefügten Unterlagen oder, soweit angemessen, auf bzw. in beiden an.“

  - b) Absatz 2 Satz 1 erhält folgende Fassung:

„Einführer und Händler händigen einer zuständigen Behörde auf deren begründetes Verlangen in elektronischer Form alle Informationen und Unterlagen, die für den Nachweis der Konformität des Produkts erforderlich sind, in einer für diese Behörde leicht verständlichen oder annehmbaren Sprache aus.“

- 5. In Artikel 15 wird der folgende Absatz 4 angefügt:

„(4) Der Hersteller stellt der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form zur Verfügung.“

- 6. Artikel 16 wird wie folgt geändert:

  - a) Absatz 4 Satz 1 erhält folgende Fassung:

„Wenn ein EU-Schiff mit Schiffsausrüstung ausgestattet wird, lädt der Hersteller die EU-Konformitätserklärung für die betreffende Ausrüstung in die von der Kommission gemäß Artikel 35 Absatz 4 eingerichtete Datenbank hoch.“

  - b) Absatz 5 erhält folgende Fassung:

„(5) Die EU-Konformitätserklärung wird der notifizierten Stelle oder den Stellen, die die einschlägigen Konformitätsbewertungsverfahren durchgeführt haben, über die von der Kommission gemäß Artikel 35 Absatz 4 eingerichtete Datenbank übermittelt.“

- 7. Folgender Absatz 6 wird angefügt:

„(6) Ist der Wirtschaftsakteur aufgrund anderer für die Schiffsausrüstung geltender Rechtsvorschriften der Union verpflichtet, die Informationen darüber, dass das Produkt den Anforderungen dieser Rechtsvorschriften entspricht, in einen digitalen Produktpass aufzunehmen oder die EU-Konformitätserklärung oder die Anweisungen in einen digitalen Produktpass hochzuladen, so sind die Informationen, die gemäß Anhang III des Beschlusses Nr. 768/2008/EG in die EU-Konformitätserklärung aufzunehmen sind, sowie die in Artikel 12 Absatz 8 genannte Anleitung nur in diesem digitalen Produktpass bereitzustellen.“

- 8. Artikel 29 Absatz 1 Buchstabe f erhält folgende Fassung:

„f) die EU-Konformitätserklärung für das Schiff wurde nicht elektronisch zugänglich gemacht;“

- 9. Anhang II wird entsprechend Anhang XIII dieser Richtlinie geändert.

<a id="art-14"></a>
### Artikel 14

Übergangsbestimmung

Die Mitgliedstaaten dürfen die Bereitstellung von Produkten auf dem Markt nicht behindern, die im Einklang mit den Richtlinien 2000/14/EG, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU und 2014/90/EU vor dem [Amt für Veröffentlichungen: Bitte das in Artikel 15 Absatz 1 Unterabsatz 2 genannte Datum einfügen] in Verkehr gebracht wurden.

<a id="art-15"></a>
### Artikel 15

Umsetzung

- (1) Die Mitgliedstaaten erlassen und veröffentlichen spätestens am [Amt für Veröffentlichungen: Bitte Datum einsetzen: 12 Monate nach Inkrafttreten dieser Änderungsrichtlinie] die Rechts- und Verwaltungsvorschriften, die erforderlich sind, um dieser Richtlinie nachzukommen. Sie teilen der Kommission unverzüglich den Wortlaut dieser Vorschriften mit.

- Sie wenden diese Vorschriften ab dem [Amt für Veröffentlichungen: Bitte Datum einsetzen: 12 Monate nach Inkrafttreten dieser Richtlinie] an.

- Die Mitgliedstaaten wenden folgende Vorschriften jedoch ab dem [Amt für Veröffentlichungen: Bitte Datum einsetzen: 24 Monate nach Inkrafttreten dieser Richtlinie] an.

- a) Artikel 1;

- b) Artikel 2 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c und d sowie Nummern 3, 4, 5 und 6;

- c) Artikel 3 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c und d sowie Nummern 3, 4, 5, 7 und 8;

- d) Artikel 4 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e, Nummern 3, 4 und 5, Nummer 7 Buchstaben b und c und Nummer 8;

- e) Artikel 5 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e sowie Nummern 3, 4, 5, 7 und 8;

- f) Artikel 6 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e sowie Nummern 3, 4, 5, 7 und 8;

- g) Artikel 7 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e sowie Nummern 3, 4, 5, 7, 9 und 12;

- h) Artikel 8 Nummer 1 Buchstabe a, Nummer 2, Nummer 3 Buchstaben a, c, d und e sowie Nummern 4, 5, 6, 8, 9, 10 und 13;

- i) Artikel 9 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e sowie Nummern 3, 4, 5, 7, 8 und 11;

- j) Artikel 10 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e sowie Nummern 3, 4, 5 und 7;

- k) Artikel 11 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d, e und f sowie Nummern 3, 4 und 5, Nummer 7 Buchstabe c und Nummer 8;

- l) Artikel 12 Nummer 1 Buchstabe a, Nummer 2 Buchstaben a, c, d und e sowie Nummern 3, 4, 5, 7 und 9;

- m) Artikel 13;

- n) Anhang I;

- o) Anhang II Nummer 1 und Nummer 2 Buchstabe a;

- p) Anhang III Nummer 1 Buchstabe a Ziffer ii und Buchstabe b Ziffer i, Nummer 2 Buchstabe a, Nummer 3 Buchstabe a und Nummer 4;

- q) Anhang IV Nummer 1 Buchstabe a Ziffern i und c, Nummer 2 und Nummer 3 Buchstabe a;

- r) Anhang V Nummer 2 Buchstabe a Ziffern i und b und Nummer 3 Buchstabe a;

- s) Anhang VI Nummer 1 Buchstabe a Ziffern i, c, d und g sowie Nummer 2 Buchstabe a;

- t) Anhang VII Nummer 1 Buchstabe b Ziffer i erster Gedankenstrich, Buchstabe b Ziffer iii, Buchstabe d Ziffer i, Buchstabe e Ziffer i, Buchstabe f Ziffer i, Buchstabe g Ziffer i, Buchstabe k Ziffer i, Buchstabe l Ziffer i, Buchstabe l Ziffer iv, erster Gedankenstrich und Buchstabe l Ziffer v sowie Nummer 2 Buchstabe a;

- u) Anhang VIII Nummer 1 Buchstabe a Ziffern i und iii, Buchstabe b Ziffern i und iii, Nummer 2 Buchstabe a Ziffern i, v, b Ziffer i und v, Nummer 4 Buchstabe a, Nummer 5 Buchstabe a, Nummer 6 Buchstabe a, Nummer 7 Buchstabe a, Nummer 8 Buchstabe a, Nummer 9 Buchstabe a und Nummer 10 Buchstabe a;

- v) Anhang IX Nummer 1, Nummer 2 Buchstaben a, d und a, Nummer 5 Buchstabe a und Nummer 8 Buchstabe a;

- w) Anhang X Nummer 2 Buchstabe a

- x) Anhang XI Nummer 1, Nummer 2 Buchstabe a Ziffern i und b, Nummer 3 Buchstabe a, Nummer 5 Buchstabe a und Nummer 6;

- y) Anhang XII Nummer 2 Buchstabe c Ziffer i erster Gedankenstrich, Buchstabe c Ziffer iv, Buchstabe c Ziffer v, erster Gedankenstrich, Buchstabe c Ziffer viii, Buchstabe e Ziffer i, Buchstabe f Ziffer ii, Buchstabe g Ziffer i, Buchstabe h Ziffer ii, Buchstabe k Ziffer i, Buchstabe l Ziffern i, v und viii sowie Nummer 3 Buchstaben a und c;

- z) ANHANG XIII.

- (2) Die Mitgliedstaaten teilen der Kommission den Wortlaut der wichtigsten nationalen Vorschriften mit, die sie auf dem unter diese Richtlinie fallenden Gebiet erlassen.

<a id="art-16"></a>
### Artikel 16

Inkrafttreten

Diese Richtlinie tritt am zwanzigsten Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

<a id="art-17"></a>
### Artikel 17

Adressaten

Diese Richtlinie ist an die Mitgliedstaaten gerichtet.

Geschehen zu Brüssel am

Im Namen des Europäischen Parlaments Im Namen des Rates

Die Präsidentin Der Präsident/Die Präsidentin

<a id="finanz-und-digitalbogen-zu-rechtsakten"></a>
## FINANZ- UND DIGITALBOGEN ZU RECHTSAKTEN

### 1. RAHMEN DES VORSCHLAGS/DER INITIATIVE

#### 1.1. Bezeichnung des Vorschlags/der Initiative

    Vorschlag für eine

    RICHTLINIE DES EUROPÄISCHEN PARLAMENTS UND DES RATES

    zur Änderung der Richtlinien 2000/14/EG, 2011/65/EU, 2013/53/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU und 2014/90/EU des Europäischen Parlaments und des Rates im Hinblick auf die Digitalisierung und die Angleichung in Bezug auf gemeinsame Spezifikationen

#### 1.2. Politikbereich(e)

Bessere Rechtsetzung, Wettbewerbsfähigkeit

#### 1.3. Ziel(e)

##### 1.3.1. Allgemeine(s) Ziel(e)

Förderung des Wachstums und der Entwicklung von Unternehmen, um ihre Wettbewerbsfähigkeit und ihren Beitrag zu Wohlstand und Wohlergehen in Europa zu steigern.

Förderung eines unternehmerischen Umfelds und Verringerung des Verwaltungsaufwands für Unternehmen, um so ihre Fähigkeit zu verbessern, innovativ zu sein, Arbeitsplätze zu schaffen und zum Wirtschaftswachstum beizutragen.

##### 1.3.2. Einzelziel(e)

Streichung der Verweise auf das Papierformat bei Konformitätserklärungen für Hersteller, die solche Konformitätserklärungen gemäß den Richtlinien und Verordnungen des neuen Rechtsrahmens (NLF) vorlegen müssen;

Einführung der Möglichkeit für den Hersteller, die Gebrauchsanweisungen in digitaler Form zur Verfügung zu stellen;

Für Fälle, in denen Unternehmen Rechtssicherheit in Bezug auf die Einhaltung der EU-Vorschriften benötigen, weil es keine harmonisierten Normen gibt, diese nicht verfügbar sind oder dringender Bedarf besteht: Bereitstellung von Alternativlösungen.

##### 1.3.3. Erwartete Ergebnisse und Auswirkungen

    Bitte geben Sie an, wie sich der Vorschlag/die Initiative auf die Begünstigten/Zielgruppen auswirken sollte.

Der Vorschlag/die Initiative dürfte sich auf die Begünstigten/Zielgruppen wie folgt auswirken:

- Verringerung der Belastung durch Papierexemplare,

- Weniger Verwaltungsaufwand: Der Verwaltungsaufwand für die Hersteller wird sich verringern, sodass sie sich auf ihr Kerngeschäft konzentrieren und ihre Wettbewerbsfähigkeit verbessern können.

- Verbesserte Wettbewerbsfähigkeit: Die Hersteller werden sowohl auf dem heimischen als auch auf dem internationalen Markt wettbewerbsfähiger, was es ihnen ermöglichen wird, ihren Marktanteil zu erhöhen und zum Wirtschaftswachstum in Europa beizutragen.

- Neu geschaffene Arbeitsplätze: Wachstum und Entwicklung der Hersteller werden zur Schaffung neuer Arbeitsplätze führen, was zur Verringerung der Arbeitslosigkeit und zur Förderung des sozialen Zusammenhalts beitragen wird.

- Verstärkte Innovation: Die Digitalisierung der Konformitätserklärungen und der Anleitungen wird Innovationen fördern und neue Anreize für Investitionen in die Datenerfassung und -verarbeitung mit eGovernment-Lösungen schaffen, was zur Verbesserung der Innovationskapazität der europäischen Wirtschaft insgesamt beitragen wird.

Zielgruppen:

Mit dem Vorschlag/der Initiative wird im Wesentlichen auf die Hersteller abgezielt, die im Bereich der oben genannten Richtlinien tätig sind.

##### 1.3.4. Leistungsindikatoren

    Bitte geben Sie an, anhand welcher Indikatoren die Fortschritte und Ergebnisse verfolgt werden sollen.

    Nicht zutreffend

#### 1.4. Der Vorschlag/Die Initiative betrifft Keinen der folgenden Punkte:

     eine neue Maßnahme

     eine neue Maßnahme im Anschluss an ein Pilotprojekt/eine vorbereitende Maßnahme^(22)

     die Verlängerung einer bestehenden Maßnahme

     die Zusammenführung mehrerer Maßnahmen oder die Neuausrichtung mindestens einer Maßnahme

#### 1.5. Begründung des Vorschlags/der Initiative

##### 1.5.1. Kurz- oder langfristig zu deckender Bedarf, einschließlich einer detaillierten Zeitleiste für die Durchführung der Initiative

Dieser Vorschlag betrifft zwei Omnibus-Rechtsakte zur Änderung von EU-Rechtsvorschriften. Er kann daher nur auf EU-Ebene umgesetzt werden.

##### 1.5.2. Mehrwert aufgrund des Tätigwerdens der EU (kann sich aus unterschiedlichen Faktoren ergeben, z. B. Vorteile durch Koordinierung, Rechtssicherheit, größere Wirksamkeit oder Komplementarität). Für die Zwecke dieses Abschnitts bezeichnet der Ausdruck „Mehrwert aufgrund des Tätigwerdens der EU“ den Wert, der sich aus dem Tätigwerden der EU ergibt und den Wert ergänzt, der andernfalls allein von den Mitgliedstaaten geschaffen worden wäre.

    Nicht zutreffend

##### 1.5.3. Aus früheren ähnlichen Maßnahmen gewonnene Erkenntnisse

    Nicht zutreffend

##### 1.5.4. Vereinbarkeit mit dem Mehrjährigen Finanzrahmen sowie mögliche Synergieeffekte mit anderen geeigneten Instrumenten

    Nicht zutreffend

##### 1.5.5. Bewertung der verschiedenen verfügbaren Finanzierungsoptionen, einschließlich der Möglichkeiten für eine Umschichtung

    Nicht zutreffend

#### 1.6. Laufzeit der vorgeschlagenen Maßnahme/der Initiative und Dauer der finanziellen Auswirkungen

     Befristete Laufzeit

    - –  Laufzeit: [TT.MM.]JJJJ bis [TT.MM.]JJJJ

    - –  Finanzielle Auswirkungen auf die Mittel für Verpflichtungen von JJJJ bis JJJJ und auf die Mittel für Zahlungen von JJJJ bis JJJJ

     Unbefristete Laufzeit

  - – Anlaufphase von JJJJ bis JJJJ

  - – Anschließend reguläre Umsetzung

#### 1.7. Vorgeschlagene Haushaltsvollzugsart(en)^(23)^()^()

     Direkte Mittelverwaltung durch die Kommission

    - –  über ihre Dienststellen, einschließlich ihres Personals in den EU-Delegationen

    - –  über Exekutivagenturen

     Geteilte Mittelverwaltung mit Mitgliedstaaten

     Indirekte Mittelverwaltung durch Übertragung von Haushaltsvollzugsaufgaben an:

    - –  Drittländer oder die von ihnen benannten Einrichtungen

    - –  internationale Einrichtungen und deren Agenturen (bitte angeben)

    - –  die Europäische Investitionsbank und den Europäischen Investitionsfonds

    - –  Einrichtungen im Sinne der Artikel 70 und 71 der Haushaltsordnung

    - –  öffentlich-rechtliche Körperschaften

    - –  privatrechtliche Einrichtungen, die im öffentlichen Auftrag tätig werden, sofern ihnen ausreichende finanzielle Garantien bereitgestellt werden

    - –  privatrechtliche Einrichtungen eines Mitgliedstaats, die mit der Einrichtung einer öffentlich-privaten Partnerschaft betraut werden und denen ausreichende finanzielle Garantien bereitgestellt werden

    - –  Einrichtungen oder Personen, die mit der Durchführung bestimmter Maßnahmen im Bereich der Gemeinsamen Außen- und Sicherheitspolitik im Rahmen des Titels V des Vertrags über die Europäische Union betraut und die in dem maßgeblichen Basisrechtsakt benannt sind

    - – in einem Mitgliedstaat ansässige Einrichtungen, die dem Privatrecht eines Mitgliedstaats oder dem Unionsrecht unterliegen und im Einklang mit sektorspezifischen Vorschriften für die Betrauung mit der Ausführung von Unionsmitteln oder mit der Erteilung von Haushaltsgarantien in Betracht kommen, insofern diese Einrichtungen von privatrechtlichen, im öffentlichen Auftrag tätig werdenden Einrichtungen kontrolliert und von den Kontrollstellen mit angemessenen finanziellen Garantien mit gesamtschuldnerischer Haftung oder gleichwertigen finanziellen Garantien ausgestattet werden, die bei jeder Maßnahme auf den Höchstbetrag der Unionsunterstützung begrenzt sein können.

Bemerkungen

Nicht zutreffend

### 2. VERWALTUNGSMAẞNAHMEN

#### 2.1. Überwachung und Berichterstattung

    Nicht zutreffend

#### 2.2. Verwaltungs- und Kontrollsystem(e)

##### 2.2.1. Begründung der Haushaltsvollzugsart(en), des Durchführungsmechanismus/der Durchführungsmechanismen für die Finanzierung, der Zahlungsmodalitäten und der Kontrollstrategie, wie vorgeschlagen

    Nicht zutreffend

##### 2.2.2. Angaben zu den ermittelten Risiken und dem/den zu deren Eindämmung eingerichteten System(en) der internen Kontrolle

    Nicht zutreffend

##### 2.2.3. Schätzung und Begründung der Kosteneffizienz der Kontrollen (Verhältnis zwischen den Kontrollkosten und dem Wert der betreffenden verwalteten Mittel) sowie Bewertung des erwarteten Ausmaßes des Fehlerrisikos (bei Zahlung und beim Abschluss)

    Nicht zutreffend

#### 2.3. Prävention von Betrug und Unregelmäßigkeiten

    Nicht zutreffend

### 3. GESCHÄTZTE FINANZIELLE AUSWIRKUNGEN DES VORSCHLAGS/DER INITIATIVE

#### 3.1. Betroffene Rubrik(en) des Mehrjährigen Finanzrahmens und Ausgabenlinie(n) im Haushaltsplan

  - · Bestehende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM^(24). | von EFTA-Ländern^(25) | von Kandidatenländern und potenziellen Kandidaten^(26) | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | Nicht zutreffend | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

  - · Neu zu schaffende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM | von EFTA-Ländern | von Kandidatenländern und potenziellen Kandidaten | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | Nicht zutreffend | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

#### 3.2. Geschätzte finanzielle Auswirkungen des Vorschlags auf die Mittel

##### 3.2.1. Übersicht über die geschätzten Auswirkungen auf die operativen Mittel

  - –  Für den Vorschlag/die Initiative werden keine operativen Mittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden operativen Mittel benötigt:

##### 3.2.1.1. Mittel aus dem verabschiedeten Haushaltsplan

in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |
| --- | --- | --- |

| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(27) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <….> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(28) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <….> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK <….> | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |
| --- | --- | --- |

| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(29) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| für die GD <….> | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(30) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| für die GD <….> | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| Mittel INSGESAMT unter der RUBRIK <….> | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  |  |  |  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |
|  |  |  |  | 2024 | 2025 | 2026 | 2027 |  |
| • Operative Mittel INSGESAMT (alle operativen Rubriken) | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| • Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT (alle operativen Rubriken) | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 6 | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| des Mehrjährigen Finanzrahmens (Referenzbetrag) | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |

| Rubrik des Mehrjährigen Finanzrahmens | 7 | „Verwaltungsausgaben“^(31) |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| GD: <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
|  Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD <…….> INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
|  Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD <…….> INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Mittel INSGESAMT unter der RUBRIK 7 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 7 | Verpflichtungen | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

##### 3.2.1.2. Mittel aus externen zweckgebundenen Einnahmen

in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |
| --- | --- | --- |

| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(32) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <….> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(33) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <….> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK <….> | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |  |  |  |  |  |

| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(34) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <….> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(35) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <….> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK <….> | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

==================================================================================================

|  |  |  |  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | 2024 | 2025 | 2026 | 2027 |  |
| • Operative Mittel INSGESAMT (alle operativen Rubriken) | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| • Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT (alle operativen Rubriken) | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 6 | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| des Mehrjährigen Finanzrahmens (Referenzbetrag) | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |

| Rubrik des Mehrjährigen Finanzrahmens | 7 | „Verwaltungsausgaben“^(36) |
| --- | --- | --- |

in Mio. EUR (3 Dezimalstellen)

| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
|  Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD <…….> INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <…….> | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
|  Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD <…….> INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Mittel INSGESAMT unter der RUBRIK 7 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 7 | Verpflichtungen | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

##### 3.2.2. Geschätzte Ergebnisse, die mit operativen Mitteln finanziert werden (nicht auszufüllen im Fall dezentraler Agenturen)

Mittel für Verpflichtungen, in Mio. EUR (3 Dezimalstellen)

| Ziele und Outputs angeben  |  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Bei länger andauernden Auswirkungen bitte weitere Spalten einfügen (siehe 1.6) | INSGESAMT |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art^(37) | Durchschnittskosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Gesamtzahl | Gesamtkosten |
| SPEZIFISCHES ZIEL Nr. 1^(38)… |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EINZELZIEL Nr. 2 ... |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| INSGESAMT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

##### 3.2.3. Übersicht über die geschätzten Auswirkungen auf die Verwaltungsmittel

  - –  Für den Vorschlag/die Initiative werden keine Verwaltungsmittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden Verwaltungsmittel benötigt:

#####  3.2.3.1. Mittel aus dem verabschiedeten Haushaltsplan

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
| RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

===================================================================

##### 3.2.3.2 Mittel aus externen zweckgebundenen Einnahmen

| EXTERNE ZWECKGEBUNDENE EINNAHMEN | Jahr | Jahr | Jahr | Jahr | 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
| RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

##### 3.2.3.3. Mittel insgesamt

| SUMME DER BEWILLIGTEN MITTEL + EXTERNEN ZWECKGEBUNDENEN EINNAHMEN | Jahr | Jahr | Jahr | Jahr | 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
| RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

===================================================================

Der Mittelbedarf für Personal- und sonstige Verwaltungsausgaben wird durch der Verwaltung der Maßnahme zugeordnete Mittel der GD und/oder durch eine Umschichtung innerhalb der GD gedeckt. Hinzu kommen etwaige zusätzliche Mittel, die der für die Verwaltung der Maßnahme zuständigen GD nach Maßgabe der verfügbaren Mittel im Rahmen der jährlichen Mittelzuweisung zugeteilt werden.

##### 3.2.4. Geschätzter Personalbedarf

  - –  Für den Vorschlag/die Initiative wird kein Personal benötigt.

  - –  Für den Vorschlag/die Initiative wird das folgende Personal benötigt:

##### 3.2.4.1. Finanziert aus dem verabschiedeten Haushalt

Schätzung in Vollzeitäquivalenten (VZÄ)^(39)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr |  |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
|  Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 0 | 0 | 0 | 0 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 |  |
| • Externes Personal (in VZÄ) |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 0 | 0 | 0 | 0 |  |

##### 3.2.4.2. Finanziert aus externen zweckgebundenen Einnahmen

| EXTERNE ZWECKGEBUNDENE EINNAHMEN | Jahr | Jahr | Jahr | Jahr |  |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
|  Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 0 | 0 | 0 | 0 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 |  |
| • Externes Personal (in Vollzeitäquivalenten) |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 0 | 0 | 0 | 0 |  |

##### 3.2.4.3. Geschätzter Personalbedarf insgesamt

| SUMME DER BEWILLIGTEN MITTEL + EXTERNEN ZWECKGEBUNDENEN EINNAHMEN | Jahr | Jahr | Jahr | Jahr |  |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
|  Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 0 | 0 | 0 | 0 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 |  |
| • Externes Personal (in Vollzeitäquivalenten) |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 0 | 0 | 0 | 0 |  |

=

    Für die Durchführung des Vorschlags benötigtes Personal (in VZÄ):

|  | Personal aus den Dienststellen der Kommission | Zusatzpersonal (ausnahmsweise)* |  |  |
| --- | --- | --- | --- | --- |
|  |  | Zu finanzieren aus Rubrik 7 oder Forschung | Zu finanzieren aus einer Haushaltslinie für administrative Unterstützung | Zu finanzieren aus Gebühren |
| Planstellen |  |  | Nicht zutreffend |  |
| Externes Personal (VB, ANS, LAK) |  |  |  |  |

    Beschreibung der Aufgaben, die ausgeführt werden sollen durch:

| Beamte und Zeitbedienstete |  |
| --- | --- |
| Externes Personal |  |

##### 3.2.5. Übersicht über die geschätzten Auswirkungen auf die Investitionen im Zusammenhang mit digitalen Technologien

    Obligatorisch: In die Tabelle unten ist die bestmögliche Einschätzung der für den Vorschlag/die Initiative erforderlichen Investitionen in digitale Technologien einzutragen.

    Wenn dies für die Durchführung des Vorschlags/der Initiative erforderlich ist, sollten die Mittel unter Rubrik 7 ausnahmsweise in der dafür vorgesehenen Haushaltslinie ausgewiesen werden.

    Die Mittel unter den Rubriken 1-6 sollten als „IT-Ausgaben zur Politikunterstützung für operationelle Programme“ ausgewiesen sein. Diese Ausgaben beziehen sich auf die operativen Mittel, die für die Wiederverwendung/den Erwerb/die Entwicklung von IT-Plattformen/Instrumenten verwendet werden, welche in direktem Zusammenhang mit der Durchführung der Initiative und den damit verbundenen Investitionen stehen (z. B. Lizenzen, Studien, Datenspeicherung usw.). Die in dieser Tabelle dargelegten Informationen sollten mit den Angaben in Abschnitt 4 „Digitale Aspekte“ vereinbar sein.

| Mittel INSGESAMT für Digitales und IT | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |
| RUBRIK 7 |  |  |  |  |  |
| IT-Ausgaben (intern) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| IT-Ausgaben zur Politikunterstützung für operationelle Programme | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

##### 3.2.6. Vereinbarkeit mit dem derzeitigen Mehrjährigen Finanzrahmen

    Der Vorschlag/Die Initiative

  - –  kann durch Umschichtungen innerhalb der entsprechenden Rubrik des Mehrjährigen Finanzrahmens (MFR) in voller Höhe finanziert werden.

    Nicht zutreffend

  - –  erfordert die Inanspruchnahme des verbleibenden Spielraums unter der einschlägigen Rubrik des MFR und/oder den Einsatz der besonderen Instrumente im Sinne der MFR-Verordnung.

    Nicht zutreffend

  - –  erfordert eine Änderung des MFR.

    Nicht zutreffend

##### 3.2.7. Beiträge Dritter

    Der Vorschlag/Die Initiative

  - –  sieht keine Kofinanzierung durch Dritte vor.

  - –  sieht folgende Kofinanzierung durch Dritte vor:

Mittel in Mio. EUR (3 Dezimalstellen)

|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Insgesamt |
| --- | --- | --- | --- | --- | --- |
| Kofinanzierende Einrichtung |  |  |  |  |  |
| Kofinanzierung INSGESAMT |  |  |  |  |  |

3.3. Geschätzte Auswirkungen auf die Einnahmen

  - –  Der Vorschlag/Die Initiative wirkt sich nicht auf die Einnahmen aus.

  - –  Der Vorschlag/Die Initiative wirkt sich auf die Einnahmen aus, und zwar

- –  auf die Eigenmittel

- –  auf die übrigen Einnahmen

- –  Bitte geben Sie an, ob die Einnahmen bestimmten Ausgabenlinien zugeordnet sind.

in Mio. EUR (3 Dezimalstellen)

| Einnahmenlinie: | Für das laufende Haushaltsjahr zur Verfügung stehende Mittel | Auswirkungen des Vorschlags/der Initiative^(40) |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 |
| Artikel …. |  |  |  |  |  |

    Bitte geben Sie für die sonstigen zweckgebundenen Einnahmen die betreffende(n) Ausgabenlinie(n) im Haushaltsplan an.

    Nicht zutreffend

    Sonstige Anmerkungen (bei der Ermittlung der Auswirkungen auf die Einnahmen verwendete Methode/Formel oder weitere Informationen).

    Nicht zutreffend

### 4. Digitale Aspekte

#### 4.1. Anforderungen von digitaler Relevanz

| Anforderung 1: ·Bezug: Artikel 1 Absatz 1, Artikel 2 Absätze 1a und 1c und andere ·Beschreibung auf übergeordneter Ebene: Definition des Begriffs „digitale Kontaktdaten“: jeder aktuelle und zugängliche Online-Kommunikationskanal ·Interessenträger: Wirtschaftsakteure, Verbraucher und andere Endnutzer, Behörden der Mitgliedstaaten. ·Verfahren auf übergeordneter Ebene: Überprüfung und Überwachung der Marktaufsicht. Anforderung 2: ·Bezug: Artikel 1 Absätze 2, 3, 4 und 5 und andere ·Beschreibung auf übergeordneter Ebene: Den Produkten muss die Internetadresse oder der maschinenlesbare Code beigefügt sein, über die bzw. den die EG-Konformitätserklärung abgerufen werden kann. ·Interessenträger: Wirtschaftsakteure, Behörden der Mitgliedstaaten. ·Verfahren auf übergeordneter Ebene: Überprüfung und Überwachung der Marktaufsicht. Anforderung 3: ·Bezug: Artikel 1 Absatz 6 Buchstabe a, Artikel 2 Absatz 2a und andere ·Beschreibung auf übergeordneter Ebene: Definition der EG-Konformitätserklärung in elektronischer Form. ·Interessenträger: Wirtschaftsakteure, Behörden der Mitgliedstaaten. ·Verfahren auf übergeordneter Ebene: Überprüfung und Überwachung der Marktaufsicht. Anforderung 4: ·Bezug: Artikel 1 Absatz 6 Buchstabe b und andere ·Beschreibung auf übergeordneter Ebene: Die Information, dass das Produkt den Anforderungen der jeweiligen Rechtsvorschrift entspricht, in einen digitalen Produktpass aufnehmen oder die EG-Konformitätserklärung oder die Anleitung in einen digitalen Produktpass hochladen. ·Interessenträger: Wirtschaftsakteure, Behörden der Mitgliedstaaten. ·Verfahren auf übergeordneter Ebene: Überprüfung und Überwachung der Marktaufsicht. Anforderung 5: ·Bezug: Artikel 1 Absatz 7 Buchstabe a und andere ·Beschreibung auf übergeordneter Ebene: Die Mitgliedstaaten stellen sicher, dass die Kommission und jeder andere Mitgliedstaat auf begründeten Antrag alle Informationen in elektronischer Form erhalten können. ·Interessenträger: Wirtschaftsakteure, Behörden der Mitgliedstaaten, Europäische Kommission. ·Verfahren auf übergeordneter Ebene: Konformitätsbewertung Anforderung 6: ·Bezug: Artikel 1 Absatz 7b und andere ·Beschreibung auf übergeordneter Ebene: Gegebenenfalls übermittelt der Hersteller der notifizierten Stelle, die das Konformitätsbewertungsverfahren durchführt, alle Informationen und Unterlagen im Zusammenhang mit den Konformitätsbewertungsverfahren in elektronischer Form. ·Interessenträger: Notifizierte Stellen, Wirtschaftsakteure ·Verfahren auf übergeordneter Ebene: Konformitätsbewertungsverfahren Anforderung 7: ·Bezug: Artikel 2 Absatz 1 Buchstabe b und andere ·Beschreibung auf übergeordneter Ebene: „eine gemeinsame Spezifikation“ kann digital sein oder so strukturiert sein, dass die Interoperabilität erleichtert wird. ·Interessenträger: Europäische Kommission, Wirtschaftsakteure, notifizierte Stellen, Marktüberwachungsbehörden. ·Verfahren auf übergeordneter Ebene: Konformitätsbewertungsverfahren, Überprüfung und Überwachung der Marktaufsicht. Anforderung 8: ·Bezug: Artikel 3 Absatz 2 und andere ·Beschreibung auf übergeordneter Ebene: Die Betriebsanleitung und die Sicherheitsinformationen können in elektronischer Form bereitgestellt werden. Ferner könnte präzisiert werden, dass das Format den Barrierefreiheitsanforderungen entsprechen sollte. ·Interessenträger: Wirtschaftsakteure, Verbraucher und andere Endnutzer, Marktüberwachungsbehörden ·Verfahren auf übergeordneter Ebene: Überprüfung und Überwachung der Marktaufsicht, Konformitätsbewertung. |
| --- |

####  4.2. Daten

| Die Definition „elektronische Form“ ermöglicht einfache Textdateien, PDF-Dateien, Microsoft-Word-Dokumente und Webseiten. Das ist zwar eine Verbesserung im Vergleich zum Papierformat, doch kann die Interoperabilität durch die Verwendung eines Formats, das die Vernetzung von IT-Systemen ermöglicht, weiter verbessert werden. |
| --- |

####  4.3. Digitale Lösungen

Nicht zutreffend

####  4.4. Interoperabilitätsbewertung

| Digitaler öffentlicher Dienst: Überwachung/Überprüfung/Untersuchungen im Bereich der Marktaufsicht. Beglaubigungsdienste. Interoperabilität auf der rechtlichen Ebene: Durch die Überarbeitung des neuen Rechtsrahmens (NLF) kann die Interoperabilität weiter verbessert werden. Potenzielle Barriere auf semantischer Ebene: Die Struktur der digitalen Kontaktdaten, der EU-Konformitätserklärung und der gemeinsamen Spezifikationen könnte besser definiert werden. Potenzielle Barriere für die technische Interoperabilität: Die Definition des Begriffs „elektronische Form“ kann die Interoperabilität behindern, da Formate verwendet werden können, die nicht interoperabel sind, wie Websites, unstrukturierte Word-Dokumente und PDF-Dateien, und sogar Videos oder Fotos. |
| --- |

#### 4.5. Unterstützungsmaßnahmen für die digitale Umsetzung

| Bei der Überarbeitung des neuen Rechtsrahmens (NLF) und der Durchführungsrechtsakte für den digitalen Produktpass werden alle digitalen Anforderungen im Hinblick auf eine weiter verbesserte Interoperabilität bei allen Prozessen, die in den Anwendungsbereich dieser Richtlinie fallen, berücksichtigt. Besondere Aufmerksamkeit wird den Cybersicherheitsaspekten gewidmet. Die Kommission wird dafür Sorge tragen, dass die gemeinsamen Spezifikationen in den Durchführungsrechtsakten in strukturierter Weise definiert werden, um Interoperabilität zu ermöglichen. Die Überprüfungs- und Zertifizierungsverfahren könnten genauer definiert werden, um eine Automatisierung zu ermöglichen und Maßnahmen zur Abwehr etwaiger Bedrohungen im Bereich der Cybersicherheit vorzuschreiben. |
| --- |

^(1) COM(2023) 168.

^(2) https://commission.europa.eu/law/law-making-process/planning-and-proposing-law/better-regulation/better-regulation-guidelines-and-toolbox_en .

^(3) COM(2025) 30 final.

^(4) Bekanntmachung der Kommission Leitfaden für die Umsetzung der Produktvorschriften der EU 2022 („Blue Guide“) (Text von Bedeutung für den EWR) 2022/C 247/01, C/2022/3637 (ABl. C 247 vom 29.6.2022, S. 1).

^(5) Quelle: Digital economy and society statistics - households and individuals - Statistics Explained .

^(6) Richtlinie 2000/14/EG des Europäischen Parlaments und des Rates vom 8. Mai 2000 zur Angleichung der Rechtsvorschriften der Mitgliedstaaten über umweltbelastende Geräuschemissionen von zur Verwendung im Freien vorgesehenen Geräten und Maschinen (ABl. L 162 vom 3.7.2000, S. 1, ELI: http://data.europa.eu/eli/dir/2000/14/oj ).

^(7) Richtlinie 2010/35/EU des Europäischen Parlaments und des Rates vom 16. Juni 2010 über ortsbewegliche Druckgeräte und zur Aufhebung der Richtlinien 76/767/EWG, 84/525/EWG, 84/526/EWG, 84/527/EWG und 1999/36/EG des Rates (ABl. L 165 vom 30.6.2010, S. 1, ELI: http://data.europa.eu/eli/dir/2010/35/oj ).

^(8) Richtlinie 2011/65/EU des Europäischen Parlaments und des Rates vom 8. Juni 2011 zur Beschränkung der Verwendung bestimmter gefährlicher Stoffe in Elektro- und Elektronikgeräten (ABl. L 174 vom 1.7.2011, S. 88, ELI: http://data.europa.eu/eli/dir/2011/65/oj ).

^(9) Richtlinie 2013/53/EU des Europäischen Parlaments und des Rates vom 20. November 2013 über Sportboote und Wassermotorräder und zur Aufhebung der Richtlinie 94/25/EG (ABl. L 354 vom 28.12.2013, S. 90, ELI: http://data.europa.eu/eli/dir/2013/53/oj ).

^(10) Richtlinie 2014/29/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die Harmonisierung der Rechtsvorschriften der Mitgliedstaaten betreffend die Bereitstellung einfacher Druckbehälter auf dem Markt (ABl. L 96 vom 29.3.2014, S. 45, ELI: http://data.europa.eu/eli/dir/2014/29/oj ).

^(11) Richtlinie 2014/30/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Harmonisierung der Rechtsvorschriften der Mitgliedstaaten über die elektromagnetische Verträglichkeit (ABl. L 96 vom 29.3.2014, S. 79, ELI: http://data.europa.eu/eli/dir/2014/30/oj ).

^(12) Richtlinie 2014/31/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Angleichung der Rechtsvorschriften der Mitgliedstaaten betreffend die Bereitstellung nichtselbsttätiger Waagen auf dem Markt (ABl. L 96 vom 29.3.2014, S. 107, ELI: http://data.europa.eu/eli/dir/2014/31/oj ).

^(13) Richtlinie 2014/32/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Angleichung der Rechtsvorschriften der Mitgliedstaaten über die Bereitstellung von Messgeräten auf dem Markt (ABl. L 96 vom 29.3.2014, S. 149, ELI: http://data.europa.eu/eli/dir/2014/32/oj ).

^(14) Richtlinie 2014/33/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Angleichung der Rechtsvorschriften der Mitgliedstaaten über Aufzüge und Sicherheitsbauteile für Aufzüge (ABl. L 96 vom 29.3.2014, S. 251, ELI: http://data.europa.eu/eli/dir/2014/33/oj ).

^(15) Richtlinie 2014/34/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Harmonisierung der Rechtsvorschriften der Mitgliedstaaten für Geräte und Schutzsysteme zur bestimmungsgemäßen Verwendung in explosionsgefährdeten Bereichen (ABl. L 96 vom 29.3.2014, S. 309, ELI: http://data.europa.eu/eli/dir/2014/34/oj ).

^(16) Richtlinie 2014/35/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Harmonisierung der Rechtsvorschriften der Mitgliedstaaten betreffend die Bereitstellung elektrischer Betriebsmittel zur Verwendung innerhalb bestimmter Spannungsgrenzen auf dem Markt (ABl. L 96 vom 29.3.2014, S. 357, ELI: http://data.europa.eu/eli/dir/2014/35/oj ).

^(17) Richtlinie 2014/53/EU des Europäischen Parlaments und des Rates vom 16. April 2014 über die Harmonisierung der Rechtsvorschriften der Mitgliedstaaten über die Bereitstellung von Funkanlagen auf dem Markt und zur Aufhebung der Richtlinie 1999/5/EG (ABl. L 153 vom 22.5.2014, S. 62, ELI: http://data.europa.eu/eli/dir/2014/53/oj ).

^(18) Richtlinie 2014/68/EU des Europäischen Parlaments und des Rates vom 15. Mai 2014 zur Harmonisierung der Rechtsvorschriften der Mitgliedstaaten über die Bereitstellung von Druckgeräten auf dem Markt (ABl. L 189 vom 27.6.2014, S. 164, ELI: http://data.europa.eu/eli/dir/2014/68/oj ).

^(19) Richtlinie 2014/90/EU des Europäischen Parlaments und des Rates vom 23. Juli 2014 über Schiffsausrüstung und zur Aufhebung der Richtlinie 96/98/EG des Rates(ABl. L 257 vom 28.8.2014, S. 146, ELI: http://data.europa.eu/eli/dir/2014/90/oj ).

^(20) Beschluss Nr. 768/2008/EG des Europäischen Parlaments und des Rates vom 9. Juli 2008 über einen gemeinsamen Rechtsrahmen für die Vermarktung von Produkten und zur Aufhebung des Beschlusses 93/465/EWG des Rates (ABl. L 218 vom 13.8.2008, S. 82, ELI: http://data.europa.eu/eli/dec/2008/768(1)/oj ).

^(21) Verordnung (EG) Nr. 765/2008 des Europäischen Parlaments und des Rates vom 9. Juli 2008 über die Vorschriften für die Akkreditierung und Marktüberwachung im Zusammenhang mit der Vermarktung von Produkten und zur Aufhebung der Verordnung (EWG) Nr. 339/93 des Rates (ABl. L 218 vom 13.8.2008, S. 30. ELI: http://data.europa.eu/eli/reg/2008/765/oj ).

^(22) Im Sinne des Artikels 58 Absatz 2 Buchstabe a oder b der Haushaltsordnung.

^(23) Erläuterungen zu den Haushaltsvollzugsarten und Verweise auf die Haushaltsordnung finden sich auf der Website BUDGpedia (in englischer Sprache): https://myintracomm.ec.europa.eu/corp/budget/financial-rules/budget-implementation/Pages/implementation-methods.aspx .

^(24) GM = Getrennte Mittel / NGM = Nichtgetrennte Mittel.

^(25) EFTA: Europäische Freihandelsassoziation.

^(26) Kandidatenländer und gegebenenfalls potenzielle Kandidaten des Westbalkans.

^(27) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(28) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(29) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(30) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(31) Der Mittelbedarf sollte auf der Grundlage der Angaben zu den Durchschnittskosten veranschlagt werden, die auf der einschlägigen BUDGpedia-Seite verfügbar sind.

^(32) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(33) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(34) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(35) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(36) Der Mittelbedarf sollte auf der Grundlage der Angaben zu den Durchschnittskosten veranschlagt werden, die auf der einschlägigen BUDGpedia-Seite verfügbar sind.

^(37) Ergebnisse sind Produkte, die geliefert, und Dienstleistungen, die erbracht werden (z. B. Zahl der Austauschstudenten, gebaute Straßenkilometer usw.).

^(38) Wie in Abschnitt 1.3.2. „Einzelziel(e)“

^(39) Bitte unter der Tabelle angeben, wie viele der aufgeführten VZÄ bereits der Verwaltung der Maßnahme zugeordnet sind und/oder durch Personalumschichtung innerhalb der GD dieser Aufgabe zugeteilt werden können. Den Nettobedarf beziffern.

^(40) Bei den traditionellen Eigenmitteln (Zölle, Zuckerabgaben) sind die Beträge netto, d. h. abzüglich 20 % für Erhebungskosten, anzugeben.

<a id="annex-i"></a>
## Anhang I

Die Anhänge II und V bis VIII der Richtlinie 2000/14/EG werden wie folgt geändert:

- (1) Anhang II wird wie folgt geändert:

  - (a) Der erste und der zweite Gedankenstrich erhalten folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines in der Gemeinschaft ansässigen Bevollmächtigten;

— Name, Postanschrift und digitale Kontaktdaten der Person, die die technischen Unterlagen aufbewahrt;“

  - (b) Der vierte Gedankenstrich erhält folgende Fassung:

„— angewandtes Konformitätsbewertungsverfahren und gegebenenfalls Name, Postanschrift und digitale Kontaktdaten der beteiligten benannten Stelle;“

- (2) Anhang V wird wie folgt geändert:

  - (a) Nummer 2 Satz 3 erhält folgende Fassung:

„In diesem Fall sind der Name, die Postanschrift und die digitalen Kontaktdaten dieser Person in der EG-Konformitätserklärung anzugeben.“

  - (b) Nummer 3 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines in der Gemeinschaft ansässigen Bevollmächtigten;“

- (3) Anhang VI wird wie folgt geändert:

  - (a) Nummer 2 Satz 3 erhält folgende Fassung:

„In diesem Fall sind der Name, die Postanschrift und die digitalen Kontaktdaten dieser Person in der EG-Konformitätserklärung anzugeben.“

  - (b) Nummer 3 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines in der Gemeinschaft ansässigen Bevollmächtigten;“

- (4) In Anhang VII Nummer 2 erhält der erste Gedankenstrich folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

- (5) Anhang VIII Nummer 3.1, erster Gedankenstrich, erster Untergedankenstrich erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines in der Gemeinschaft ansässigen Bevollmächtigten.“

<a id="annex-ii"></a>
## Anhang II

Die Anhänge V und VI der Richtlinie 2011/65/EU werden wie folgt geändert:

- (1) Anhang V Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Antragstellers;“

- (2) Anhang VI wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines Bevollmächtigten“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Gegebenenfalls Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der technischen Spezifikationen, für die die Konformität erklärt wird:“

<a id="annex-iii"></a>
## Anhang III

Die Anhänge I, III, IV und V der Richtlinie 2013/53/EU werden wie folgt geändert:

- (1) Anhang I wird wie folgt geändert:

  - (a) Teil A wird wie folgt geändert:

(I) Nummer 2.1 Unterabsatz 2 erhält folgende Fassung:

„Ausführliche Anforderungen für die Identifizierungsnummer gemäß Absatz 1 sind in der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikationen enthalten.“

(II) Nummer 2.2 Buchstabe a erhält folgende Fassung:

„a) Name, eingetragener Handelsname oder eingetragene Handelsmarke sowie Postanschrift und digitale Kontaktdaten des Herstellers;“

  - (b) Teil B wird wie folgt geändert:

(I) Nummer 1.1 Buchstabe a erhält folgende Fassung:

„a) Name, eingetragener Handelsname oder eingetragene Handelsmarke sowie Postanschrift und digitale Kontaktdaten des Motorenherstellers; gegebenenfalls außerdem Name, Postanschrift und digitale Kontaktdaten der Person, die den Motor angepasst hat;“

(II) Nummer 2.3 Unterabsatz 4 erhält folgende Fassung:

„Die notifizierten Stellen können akzeptieren, dass die Prüfungen anhand anderer Prüfzyklen vorgenommen werden, soweit sie in einer harmonisierten Norm oder gemeinsamen Spezifikationen angegeben und für den Belastungszyklus des Motors anwendbar sind.“

(III) Nummer 2.5 Unterabsatz 2 erhält folgende Fassung:

„Die notifizierten Stellen können Prüfungen akzeptieren, die auf der Grundlage anderer, in einer harmonisierten Norm oder gemeinsamen Spezifikationen angegebener Bezugskraftstoffe durchgeführt wurden.“

(IV) Nummer 4 Buchstabe b erhält folgende Fassung:

„b) die Angabe der nach der harmonisierten Norm oder gemeinsamen Spezifikationen gemessenen Leistung des Motors.“

- (2) Anhang III wird wie folgt geändert:

  - (a) Die Buchstaben a und b erhalten folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers;

b) Name, Postanschrift und digitale Kontaktdaten des in der Union ansässigen Bevollmächtigten des Herstellers oder gegebenenfalls der für das Inverkehrbringen verantwortlichen Person;“

  - (b) Buchstabe d erhält folgende Fassung:

„d) Erklärung darüber, dass das unvollständige Wasserfahrzeug den grundlegenden Anforderungen für die jeweilige Baustufe entspricht; Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der Spezifikationen, für die die Konformität in der jeweiligen Baustufe erklärt wird; außerdem eine Erklärung darüber, dass die Fertigstellung in voller Übereinstimmung mit dieser Richtlinie durch eine andere natürliche oder juristische Person beabsichtigt ist.“

- (3) Anhang IV wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines Bevollmächtigten [der Bevollmächtigte muss ebenfalls die Firma, den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers angeben] oder des privaten Einführers.“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird:“

- (4) Anhang V wird wie folgt geändert:

  - (a) Nummer 2 Absatz 1 erhält folgende Fassung:

„Die Person, die das Produkt in Verkehr bringt oder in Betrieb nimmt, beantragt bei einer notifizierten Stelle eine Begutachtung des Produkts nach Bauausführung; sie muss der notifizierten Stelle zum einen – in elektronischer Form – die Dokumente und technischen Unterlagen, die diese benötigt, um die Übereinstimmung des Produkts mit den Anforderungen dieser Richtlinie zu bewerten, und zum anderen sämtliche verfügbaren Informationen über die Verwendung des Produkts nach der erstmaligen Inbetriebnahme vorlegen.“

  - (b) Nummer 4.2 Unterabsatz 1 Satz 1 erhält folgende Fassung:

„Die Person, die das Produkt in Verkehr bringt oder in Betrieb nimmt, muss eine EU-Konformitätserklärung in elektronischer Form erstellen und diese während zehn Jahren nach dem Datum der Ausstellung der PCA-Bescheinigung für die nationalen Behörden zur Verfügung halten.“

<a id="annex-iv"></a>
## Anhang IV

Die Anhänge II, III und IV der Richtlinie 2014/29/EU werden wie folgt geändert:

- (1) Anhang II wird wie folgt geändert:

  - (a) Nummer 1.3 wird wie folgt geändert:

(I) Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

(II) Buchstabe c Ziffer iv erhält folgende Fassung:

„iv) eine Aufstellung darüber, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung der Lösungen, mit denen den wesentlichen Sicherheitsanforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung darüber, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

(III) Buchstabe e Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen vermerkt sein, nach denen vorgegangen wurde, insbesondere wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

  - (b) Die Nummern 1.4.2, 1.4.3 und 1.4.4 erhalten folgende Fassung:

„1.4.2 Prüfung, ob das/die Muster der Behälter in Übereinstimmung mit den technischen Unterlagen hergestellt wurde/n und unter den vorgesehenen Betriebsbedingungen sicher verwendet werden kann/können, und Feststellung, welche Teile nach den geltenden Vorschriften der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen entworfen wurden und welche Teile gemäß anderen einschlägigen technischen Spezifikationen entworfen wurden;

1.4.3 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich für ihre Anwendung entschieden hat;

1.4.4 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die vom Hersteller gewählten Lösungen, der andere einschlägige technische Spezifikationen anwendet, die entsprechenden wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllen, falls er die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat;“

  - (c) Nummer 1.6 Absatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

  - (d) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Vor dem Inverkehrbringen entnimmt die notifizierte Stelle vor Ort eine geeignete Stichprobe der Endprodukte und untersucht sie; ferner führt sie geeignete Prüfungen entsprechend den einschlägigen Abschnitten der harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen, die in anderen einschlägigen technischen Spezifikationen aufgeführt werden, durch, um die Konformität des Behälters mit dem in der EU-Baumusterprüfbescheinigung beschriebenen Baumuster und den anwendbaren Anforderungen dieser Richtlinie zu prüfen.“

- (2) Anhang III Nummer 1.2 Buchstabe e erhält folgende Fassung:

„e) Name, eingetragener Handelsname oder eingetragene Handelsmarke sowie Postanschrift und digitale Kontaktdaten des Herstellers;“

- (3) Anhang IV wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers und gegebenenfalls seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird:“

<a id="annex-v"></a>
## Anhang V

Die Anhänge II, III und IV der Richtlinie 2014/30/EU werden wie folgt geändert:

- (1) Anhang II Nummer 3 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Anforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

- (2) Anhang III Teil A wird wie folgt geändert:

  - (a) Nummer 3 wird wie folgt geändert:

(I) Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

(II) Buchstabe c Ziffer iv erhält folgende Fassung:

„iv) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Anforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

  - (b) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, die Aspekte der wesentlichen Anforderungen, auf die sich die Prüfung bezieht, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

- (3) Anhang IV wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der verwendeten einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen oder sonstigen technischen Spezifikationen, für die die Konformität erklärt wird, einschließlich des Datums der Normen bzw. der gemeinsamen Spezifikationen bzw. der sonstigen technischen Spezifikationen:“

<a id="annex-vi"></a>
## Anhang VI

Die Anhänge II und IV der Richtlinie 2014/31/EU werden wie folgt geändert:

- (1) Anhang II wird wie folgt geändert:

  - (a) Nummer 1.3 wird wie folgt geändert:

(I) Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

(II) Buchstabe c Ziffer iv erhält folgende Fassung:

„iv) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Anforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

(III) Buchstabe e Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen vermerkt sein, nach denen vorgegangen wurde, insbesondere wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

  - (b) Die Nummern 1.4.2, 1.4.3 und 1.4.4 erhalten folgende Fassung:

„1.4.2 Prüfung, ob die Probe(n) in Übereinstimmung mit den technischen Unterlagen hergestellt wurde/n, und Feststellung, welche Teile nach den geltenden Vorschriften der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen bzw. welche Teile gemäß anderen einschlägigen technischen Spezifikationen entworfen wurden;

1.4.3 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich für ihre Anwendung entschieden hat;

1.4.4 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die vom Hersteller gewählten Lösungen – falls er die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat – auf der Grundlage anderer maßgeblicher technischer Spezifikationen erreicht wurden und die entsprechenden wesentlichen Anforderungen dieser Richtlinie erfüllen;“

  - (c) Absatz 1.6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

  - (d) Nummer 2.3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (e) Nummer 2.3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (f) Nummer 3.2 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Anforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

  - (g) Nummer 3.5.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (h) Nummer 3.5.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (i) Nummer 4.4.1 erhält folgende Fassung:

„4.4.1 Alle Geräte werden einzeln untersucht und es werden geeignete Prüfungen gemäß der/den einschlägigen harmonisierten Norm/-en und/oder einschlägigen gemeinsamen Spezifikationen bzw. gleichwertige Prüfungen, die in anderen einschlägigen technischen Spezifikationen aufgeführt werden, durchgeführt, um ihre Konformität mit der in der EU-Baumusterprüfbescheinigung beschriebenen zugelassenen Bauart und den geltenden Anforderungen dieser Richtlinie zu überprüfen.

In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (j) Unter Nummer 5.2.1 erhält Buchstabe d folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Anforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

  - (k) Nummer 5.5.1 erhält folgende Fassung:

„5.5.1 Alle Geräte sind einzeln zu untersuchen, und es sind entsprechende Prüfungen gemäß der/den einschlägigen harmonisierten Norm/-en bzw. gleichwertige Prüfungen, die in den einschlägigen gemeinsamen Spezifikationen oder in anderen einschlägigen technischen Spezifikationen aufgeführt werden, durchzuführen, um ihre Konformität mit den für sie geltenden Anforderungen sicherzustellen. In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (l) Nummer 6.2.1 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Anforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

  - (m) Nummer 6.4 Unterabsatz 1 erhält folgende Fassung:

„Eine vom Hersteller gewählte notifizierte Stelle führt die entsprechenden Untersuchungen und Prüfungen nach den einschlägigen harmonisierten Normen und/oder einschlägigen gemeinsamen Spezifikationen und/oder anderen einschlägigen technischen Spezifikationen durch oder lässt sie durchführen, um die Konformität des Geräts mit den anwendbaren Anforderungen dieser Richtlinie zu prüfen. In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

- (2) Anhang IV wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers und gegebenenfalls seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird:“

<a id="annex-vii"></a>
## Anhang VII

Die Anhänge II und XIII der Richtlinie 2014/32/EU werden wie folgt geändert:

- (1) Anhang II wird wie folgt geändert:

  - (a) In Modul A2: INTERNE FERTIGUNGSKONTROLLE MIT ÜBERWACHTEN GERÄTEPRÜFUNGEN IN UNREGELMÄSSIGEN ABSTÄNDEN erhalten Nummer 4 Unterabsatz 1 Sätze 2 und 3 folgende Fassung:

„Vor dem Inverkehrbringen entnimmt die Stelle vor Ort eine geeignete Stichprobe der endgültigen Messgeräte und untersucht sie; ferner führt sie geeignete Prüfungen entsprechend den einschlägigen Abschnitten der harmonisierten Norm und/oder des normativen Dokuments und/oder der gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durch, um die Konformität des Gerätes mit den entsprechenden Anforderungen dieser Richtlinie zu prüfen. In Ermangelung einer einschlägigen harmonisierten Norm oder eines einschlägigen normativen Dokuments oder einer gemeinsamen Spezifikation entscheidet die akkreditierte interne Stelle oder die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (b) Modul B: EU-BAUMUSTERPRÜFUNG wird wie folgt geändert:

(I) Nummer 3 wird wie folgt geändert:

      - – Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

      - – Buchstabe e erhält folgende Fassung:

„e) die zusätzlichen Nachweise für eine angemessene Lösung durch den technischen Entwurf. In diesen zusätzlichen Nachweisen müssen alle Unterlagen vermerkt sein, nach denen insbesondere dann vorgegangen worden ist, wenn die einschlägigen harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder normativen Dokumente nicht in vollem Umfang angewandt worden sind. Die zusätzlichen Nachweise umfassen erforderlichenfalls die Ergebnisse von Prüfungen, die nach anderen einschlägigen technischen Spezifikationen von einem geeigneten Labor des Herstellers oder von einem anderen Prüflabor in seinem Auftrag und unter seiner Verantwortung durchgeführt wurden.“

(II) Unter Nummer 4 erhalten die Nummern 4.2, 4.3 und 4.4 folgende Fassung:

„4.2 Prüfung, ob das/die Muster in Übereinstimmung mit den technischen Unterlagen hergestellt wurde/n, und Feststellung, welche Teile nach den geltenden Vorschriften der einschlägigen harmonisierten Normen und/oder normativen Dokumenten und/oder gemeinsamen Spezifikationen entworfen wurden und welche Teile gemäß anderen einschlägigen technischen Spezifikationen entworfen wurden;

4.3 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen, normativen Dokumenten und gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich für ihre Anwendung entschieden hat;

4.4 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die vom Hersteller gewählten Lösungen – falls er die Lösungen aus den einschlägigen harmonisierten Normen und/oder gemeinsamen Spezifikationen nicht angewandt hat – auf der Grundlage anderer maßgeblicher technischer Spezifikationen erreicht wurden und die entsprechenden wesentlichen Anforderungen dieser Richtlinie erfüllen;“

(III) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

  - (c) Modul C2: KONFORMITÄT MIT DER BAUART AUF DER GRUNDLAGE EINER INTERNEN FERTIGUNGSKONTROLLE MIT ÜBERWACHTEN GERÄTEPRÜFUNGEN IN UNREGELMÄSSIGEN ABSTÄNDEN, Punkt 3, Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Vor dem Inverkehrbringen entnimmt die akkreditierte interne Stelle oder die notifizierte Stelle vor Ort eine geeignete Stichprobe der für den Endnutzer bestimmten Messgeräte und untersucht sie; ferner führt sie geeignete Prüfungen entsprechend den einschlägigen Abschnitten der harmonisierten Normen und/oder der normativen Dokumente und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durch, um die Konformität des Gerätes mit der in der EU-Baumusterprüfbescheinigung beschriebenen Bauart und mit den entsprechenden Anforderungen dieser Richtlinie zu prüfen.“

  - (d) Modul D: KONFORMITÄT MIT DEM BAUMUSTER AUF DER GRUNDLAGE EINER AUF DEN PRODUKTIONSPROZESS BEZOGENEN QUALITÄTSSICHERUNG wird wie folgt geändert:

(I) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(II) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (e) Modul D1: QUALITÄTSSICHERUNG BEZOGEN AUF DEN PRODUKTIONSPROZESS wird wie folgt geändert:

(I) In Punkt 5.1 erhält Buchstabe a folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

(II) Nummer 5.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (f) Modul E: KONFORMITÄT MIT DEM BAUMUSTER AUF DER GRUNDLAGE DER AUF DAS PRODUKT BEZOGENEN QUALITÄTSSICHERUNG wird wie folgt geändert:

(I) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“

(II) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (g) Modul E1: QUALITÄTSSICHERUNG VON ENDABNAHME UND PRÜFUNG DER GERÄTE wird wie folgt geändert:

(I) In Punkt 5.1 erhält Buchstabe a folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“

(II) Nummer 5.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (h) Modul F: KONFORMITÄT MIT DEM BAUMUSTER AUF DER GRUNDLAGE EINER PRODUKTPRÜFUNG wird wie folgt geändert:

(I) Nummer 4 Nummer 4.1erhält folgende Fassung:

„4.1 Alle Messgeräte werden einzeln untersucht und es werden geeignete Prüfungen gemäß der/den einschlägigen harmonisierten Norm/en und/oder den normativen Dokumenten und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durchgeführt, um ihre Konformität mit der in der EU-Baumusterprüfbescheinigung beschriebenen zugelassenen Bauart und den anwendbaren Anforderungen dieser Richtlinie zu überprüfen.

In Ermangelung einer harmonisierten Norm oder eines normativen Dokuments oder einer gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

(II) Nummer 5 Nummer 5.2 erhält folgende Fassung:

„5.2 Jedem Los wird gemäß Nummer 5.3 eine beliebige Probe entnommen. Jedes Messgerät aus einer Stichprobe ist einzeln zu untersuchen, und es sind entsprechende Prüfungen gemäß der/den einschlägigen harmonisierten Norm/en, und/oder dem/den normativen Dokument/Dokumenten und/oder der/den gemeinsame(n) Spezifikation(en) und/oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durchzuführen, um seine Konformität mit der in der EU-Baumusterprüfbescheinigung beschriebenen Bauart und mit den anwendbaren Anforderungen dieser Richtlinie sicherzustellen und so zu ermitteln, ob das Los angenommen oder abgelehnt wird. In Ermangelung einer solchen harmonisierten Norm oder eines solchen normativen Dokuments oder einer solchen gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (i) Modul F1: KONFORMITÄT AUF DER GRUNDLAGE EINER PRÜFUNG DER PRODUKTE wird wie folgt geändert:

(I) Nummer 5 Nummer 5.1 erhält folgende Fassung:

„5.1 Alle Messgeräte sind einzeln zu untersuchen und es sind entsprechende Prüfungen gemäß den einschlägigen harmonisierten Normen und/oder normativen Dokumenten und/oder gemeinsamen Spezifikationen, und/oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durchzuführen, um ihre Konformität mit den für sie geltenden Anforderungen sicherzustellen. In Ermangelung einer solchen harmonisierten Norm oder eines normativen Dokuments oder einer gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

(II) Nummer 6 Nummer 6.3 erhält folgende Fassung:

„6.3 Jedes Messgerät aus einer Stichprobe ist einzeln zu untersuchen und es sind entsprechende Prüfungen gemäß den einschlägigen harmonisierten Normen und/oder normativen Dokumenten und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durchzuführen, um seine Konformität mit den geltenden Anforderungen dieser Richtlinie sicherzustellen und zu ermitteln, ob das Los angenommen oder abgelehnt wird. In Ermangelung einer solchen harmonisierten Norm oder eines normativen Dokuments oder einer gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (j) MODUL G: KONFORMITÄT AUF DER GRUNDLAGE EINER EINZELPRÜFUNG Nummer 4 Unterabsatz 1 erhält folgende Fassung:

„Eine vom Hersteller gewählte notifizierte Stelle führt die entsprechenden Untersuchungen und Prüfungen nach den einschlägigen harmonisierten Normen und/oder normativen Dokumenten und/oder gemeinsamen Spezifikationen oder gleichwertige Prüfungen gemäß anderen einschlägigen technischen Spezifikationen durch oder lässt sie durchführen, um die Konformität des Geräts mit den anwendbaren Anforderungen dieser Richtlinie zu prüfen. In Ermangelung einer solchen harmonisierten Norm oder eines normativen Dokuments oder einer gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (k) MODUL H: KONFORMITÄT AUF DER GRUNDLAGE EINER UMFASSENDEN QUALITÄTSSICHERUNG wird wie folgt geändert:

(I) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“

(II) Nummer 3.2 Buchstabe b erhält folgende Fassung:

„b) technische Entwurfsspezifikationen, einschließlich der anzuwendenden Normen, sowie – wenn die einschlägigen harmonisierten Normen und/oder normativen Dokumente und/oder gemeinsamen Spezifikationen nicht vollständig angewandt werden – die Mittel, mit denen gewährleistet werden soll, dass die für die Messgeräte geltenden wesentlichen Anforderungen dieser Richtlinie unter Anwendung anderer einschlägiger technischer Spezifikationen erfüllt werden;“

(III) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (l) Modul H1: KONFORMITÄT AUF DER GRUNDLAGE EINER UMFASSENDEN QUALITÄTSSICHERUNG MIT ENTWURFSPRÜFUNG wird wie folgt geändert:

(I) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“

(II) Nummer 3.2 Buchstabe b erhält folgende Fassung:

„b) technische Entwurfsspezifikationen, einschließlich der anzuwendenden Normen, sowie – wenn die einschlägigen harmonisierten Normen und/oder normativen Dokumente und/oder gemeinsamen Spezifikationen nicht vollständig angewandt werden – die Mittel, mit denen gewährleistet werden soll, dass die für die Messgeräte geltenden wesentlichen Anforderungen dieser Richtlinie unter Anwendung anderer einschlägiger technischer Spezifikationen erfüllt werden;“

(III) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

(IV) Nummer 4.2 wird wie folgt geändert:

      - – Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers“

      - – Buchstabe d erhält folgende Fassung:

„d) die zusätzlichen Nachweise für eine angemessene Lösung durch den technischen Entwurf. Diese zusätzlichen Nachweise enthalten einen Verweis auf sämtliche Dokumente, die zugrunde gelegt wurden, insbesondere wenn die einschlägigen harmonisierten Normen und/oder normativen Dokumente und/oder gemeinsamen Spezifikationen nicht vollständig angewandt wurden, und schließen gegebenenfalls die Ergebnisse von Prüfungen ein, die gemäß anderer einschlägiger technischer Spezifikationen in einem geeigneten Labor des Herstellers oder in seinem Auftrag und unter seiner Verantwortung in einem anderen Prüflabor durchgeführt wurden.“

(V) Nummer 4.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfungen, etwaige Bedingungen für ihre Gültigkeit und die erforderlichen Daten für die Identifizierung des zugelassenen Entwurfs.“

- (2) Anhang XIII wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers und gegebenenfalls seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der einschlägigen harmonisierten Normen oder normativen Dokumente oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der anderen normativen Dokumente oder anderen technischen Spezifikationen, für die die Konformität erklärt wird:“

<a id="annex-viii"></a>
## Anhang VIII

Die Anhänge II und VI bis XII der Richtlinie 2014/33/EU werden wie folgt geändert:

- (1) Anhang II wird wie folgt geändert:

  - (a) Teil A wird wie folgt geändert:

(I) Die Buchstaben a und b erhalten folgende Fassung:

„a) Firmenname, Postanschrift und digitale Kontaktdaten des Herstellers;

b) gegebenenfalls Firmenname, Postanschrift und digitale Kontaktdaten des Bevollmächtigten;“

(II) Buchstabe h erhält folgende Fassung:

„h) gegebenenfalls Bezugnahme auf die zugrunde gelegte(n) harmonisierte(n) Norm(en) oder gemeinsame(n) Spezifikation(en);“

(III) Die Buchstaben i bis k erhalten folgende Fassung:

„i) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die die EU-Baumusterprüfung für Sicherheitsbauteile für Aufzüge nach Anhang IV Teil A und Anhang VI durchgeführt hat und Nummer der EU-Baumusterprüfbescheinigung, die von dieser notifizierten Stelle ausgestellt wurde;

j) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die die Bewertung der Konformität mit der Bauart durch stichprobenartige Prüfungen nach Anhang IX durchgeführt hat;

k) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die das vom Hersteller verwendete Qualitätssicherungssystem gemäß dem Konformitätsbewertungsverfahrens nach Anhang VI oder VII zugelassen hat;“

  - (b) Teil B wird wie folgt geändert:

(I) Die Buchstaben a und b erhalten folgende Fassung:

„a) Firmenname, Postanschrift und digitale Kontaktdaten des Montagebetriebs;

b) gegebenenfalls Firmenname, Postanschrift und digitale Kontaktdaten des Bevollmächtigten;“

(II) Buchstabe g erhält folgende Fassung:

„g) gegebenenfalls Bezugnahme auf die zugrunde gelegte(n) harmonisierte(n) Norm(en) oder gemeinsame(n) Spezifikation(en);“

(III) Die Buchstaben h bis k erhalten folgende Fassung:

h) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die die EU-Baumusterprüfung für Aufzüge nach Anhang IV Teil B durchgeführt hat, und Nummer der EU-Baumusterprüfbescheinigung, die von dieser notifizierten Stelle ausgestellt wurde;

i) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die die Einzelprüfung für Aufzüge nach Anhang VIII durchgeführt hat;

j) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die die Endabnahme für Aufzüge nach Anhang V durchgeführt hat;

k) gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Kennnummer der notifizierten Stelle, die das vom Montagebetrieb verwendete Qualitätssicherungssystem gemäß dem Konformitätsbewertungsverfahren nach Anhang X, XI oder XII zugelassen hat;“

- (2) Anhang IV wird wie folgt geändert:

  - (a) Teil A wird wie folgt geändert:

(I) In Punkt 2 erhält Buchstabe a folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers und Name, Postanschrift und digitale Kontaktdaten seines Bevollmächtigten, falls dieser den Antrag stellt, sowie Herstellungsort der Sicherheitsbauteile für Aufzüge;“

(II) Nummer 2 Buchstabe e Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen, einschließlich anderer einschlägiger technischer Spezifikationen, vermerkt sein, nach denen insbesondere dann vorgegangen worden ist, wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

(III) Nummer 3 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung darüber, welche harmonisierten Normen, deren Verweise im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung der Lösungen, mit denen den grundlegenden Anforderungen der Nummer 1 dieser Verordnung entsprochen wurde, einschließlich einer Aufstellung darüber, welche sonstigen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

(IV) Nummer 4 Buchstaben c, d und e erhalten folgende Fassung:

„c) Prüfung, ob das (die) repräsentative(n) Muster in Übereinstimmung mit den technischen Unterlagen hergestellt wurde(n), und Feststellung der Teile, die nach den anwendbaren Vorschriften der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen entworfen wurden, und der Teile, die gemäß anderen einschlägigen technischen Spezifikationen entworfen wurden;

d) Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich für ihre Anwendung entschieden hat;

e) Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die vom Hersteller gewählten Lösungen unter Anwendung anderer einschlägiger technischer Spezifikationen ermöglichen, dass das Sicherheitsbauteil für Aufzüge die Bedingungen nach Nummer 1 erfüllt, falls er die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat;“

(V) Absatz 5 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der EU-Baumusterprüfung, die an die Bescheinigung geknüpften Bedingungen und die zur Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

  - (b) Teil B wird wie folgt geändert:

(I) In Punkt 2 erhält Buchstabe a folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Montagebetriebs; sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

(II) Nummer 2 Buchstabe e Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen, einschließlich anderer einschlägiger technischer Spezifikationen, vermerkt sein, nach denen insbesondere dann vorgegangen worden ist, wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

(III) Nummer 3 Buchstabe e erhält folgende Fassung:

„e) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Gesundheits- und Sicherheitsanforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

(IV) Nummer 4 Buchstaben c, d und e erhalten folgende Fassung:

„c) Prüfung des Musteraufzugs darauf, ob er in Übereinstimmung mit den technischen Unterlagen hergestellt wurde, und welche Teile nach den anwendbaren Bestimmungen der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen entworfen wurden und welche Teile in Übereinstimmung mit anderen einschlägigen technischen Spezifikationen entworfen wurden;

d) Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Montagebetrieb sich für ihre Anwendung entschieden hat;

e) Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die vom Montagebetrieb gewählten Lösungen, unter Anwendung anderer einschlägiger technischer Spezifikationen, die entsprechenden wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen dieser Richtlinie erfüllen, falls er die Spezifikationen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat;“

(V) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Montagebetriebs, die Ergebnisse der EU-Baumusterprüfung, die an die Bescheinigung geknüpften Bedingungen und die zur Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

- (3) Anhang V wird wie folgt geändert:

  - (a) Nummer 2 Buchstabe b erhält folgende Fassung:

„b) Auslegung und Herstellung des Aufzugs nach einem Qualitätssicherungssystem gemäß Anhang XI und der EU-Entwurfsprüfbescheinigung, sofern der Entwurf den harmonisierten Normen oder gemeinsamen Spezifikationen nicht vollständig entspricht.“

  - (b) Nummer 3.1 Unterabsatz 3 erhält folgende Fassung:

„Es werden geeignete Kontrollen und Prüfungen gemäß den maßgeblichen harmonisierten Normen oder gemeinsamen Spezifikationen oder gleichwertige Prüfungen durchgeführt, um die Übereinstimmung des Aufzugs mit den wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen nach Anhang I zu kontrollieren.“

  - (c) Nummer 3.2 Buchstabe b erhält folgende Fassung:

„b) Prüfung der in Nummer 3.1 aufgeführten Unterlagen, um zu kontrollieren, ob der Aufzug mit dem Aufzug, der nach einem zugelassenen Qualitätssicherungssystem gemäß Anhang XI entworfen und hergestellt wurde, und, falls der Entwurf die harmonisierten Normen oder gemeinsamen Spezifikationen nicht vollständig erfüllt, mit der EU-Entwurfsprüfbescheinigung übereinstimmt.“

- (4) Anhang VI wird wie folgt geändert:

  - (a) In Punkt 3.1 erhält Buchstabe a folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3.2 Unterabsatz 1 Satz 1 erhält folgende Fassung:

„Im Rahmen des Qualitätssicherungssystems wird jedes Sicherheitsbauteil für Aufzüge geprüft und es werden geeignete Prüfungen gemäß den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen oder gleichwertige Prüfungen durchgeführt, um die Übereinstimmung mit den Bedingungen nach Nummer 1 sicherzustellen.“

  - (c) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Bestandteilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikationen erfüllen, geht sie von der Konformität mit diesen Anforderungen aus.“

- (5) Anhang VII wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3.2 Buchstabe b erhält folgende Fassung:

„b) technische Entwurfsspezifikationen, einschließlich der angewandten Normen, sowie – wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht oder nicht vollständig angewandt werden – die Mittel, mit denen gewährleistet werden soll, dass die Bedingungen nach Nummer 1 erfüllt werden, einschließlich anderer einschlägiger technischer Spezifikationen;“

  - (c) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Bestandteilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikationen erfüllen, geht sie von der Konformität mit diesen Anforderungen aus.“

- (6) Anhang VIII wird wie folgt geändert:

  - (a) Nummer 2.2 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Montagebetriebs sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3 Buchstabe e erhält folgende Fassung:

„e) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Gesundheits- und Sicherheitsanforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

  - (c) Nummer 4 Unterabsatz 1 Satz 1 erhält folgende Fassung:

„Um die Übereinstimmung des Aufzugs mit den wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen des Anhangs I zu kontrollieren, untersucht die vom Montagebetrieb ausgewählte notifizierte Stelle die technischen Unterlagen und den Aufzug und führt Prüfungen gemäß den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen oder gleichwertige Prüfungen durch.“

- (7) Anhang IX wird wie folgt geändert:

  - (a) Punkt 3 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Absatz 4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Eine von der notifizierten Stelle vor Ort entnommene geeignete Stichprobe der fertiggestellten Sicherheitsbauteile für Aufzüge wird untersucht, und es werden geeignete Prüfungen nach Maßgabe der einschlägigen harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen nach Maßgabe anderer einschlägiger technischer Spezifikationen vorgenommen, um die Übereinstimmung der Sicherheitsbauteile mit den Bedingungen nach Nummer 1 zu überprüfen.“

- (8) Anhang X wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Montagebetriebs sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3.2 Absatz 1 erhält folgende Fassung:

„Im Rahmen des Qualitätssicherungssystems wird jeder Aufzug geprüft, und es werden geeignete Prüfungen gemäß einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen oder gleichwertige Prüfungen durchgeführt, um die Übereinstimmung mit den anwendbaren wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen des Anhangs I sicherzustellen.“

  - (c) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Bestandteilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikationen erfüllen, geht sie von der Konformität mit diesen Anforderungen aus.“

- (9) Anhang XI wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Montagebetriebs sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3.2 Buchstabe b erhält folgende Fassung:

„b) technische Konstruktionsspezifikationen, einschließlich der anzuwendenden Normen, sowie – wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht vollständig angewandt werden – die Mittel, einschließlich anderer einschlägiger technischer Spezifikationen, mit denen sichergestellt werden soll, dass die wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen nach Anhang I erfüllt werden;“

  - (c) Nummer 3.3 Nummer 3.3.1 erhält folgende Fassung:

„3.3.1 Entspricht der Entwurf nicht vollständig den harmonisierten Normen oder gemeinsamen Spezifikationen, prüft die notifizierte Stelle, ob der Entwurf im Einklang mit den wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen des Anhangs I steht; ist dies der Fall, stellt sie dem Montagebetrieb eine EU-Entwurfsprüfbescheinigung aus, die die Bedingungen für die Gültigkeit dieser Bescheinigung und die für die Identifizierung des zugelassenen Entwurfs erforderlichen Angaben enthält.“

  - (d) Nummer 3.4 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Bestandteilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikationen erfüllen, geht sie von der Konformität mit diesen Anforderungen aus.“

- (10) Anhang XII wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Montagebetriebs sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Bestandteilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikationen erfüllen, geht sie von einer Übereinstimmung mit diesen Anforderungen aus.“

<a id="annex-ix"></a>
## Anhang IX

Die Anhänge II bis V und VII bis X der Richtlinie 2014/34/EU werden wie folgt geändert:

- (1) Anhang II Nummer 1.0.5 erster Gedankenstrich erhält folgende Fassung:

„— Name, eingetragener Handelsname oder eingetragene Handelsmarke sowie Postanschrift und digitale Kontaktdaten des Herstellers,“

- (2) Anhang III wird wie folgt geändert:

  - (a) In Punkt 3 erhält Buchstabe a folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

  - (b) Nummer 3 Buchstabe c Ziffer iv erhält folgende Fassung:

„iv) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Gesundheits- und Sicherheitsanforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

  - (c) Nummer 4 Nummern 4.1, 4.2 und 4.3 erhalten folgende Fassung:

„4.1 Prüfung der technischen Unterlagen, Prüfung, ob das/die Muster in Übereinstimmung mit den technischen Unterlagen hergestellt wurde/n, und Feststellung, welche Teile nach den geltenden Vorschriften der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen entworfen wurden und welche Teile gemäß anderer einschlägiger technischer Spezifikationen entworfen wurden;

4.2 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich für ihre Anwendung entschieden hat;

4.3 Durchführung bzw. Veranlassung der geeigneten Untersuchungen und Prüfungen, um festzustellen, ob die Lösungen, die von einem Hersteller gewählt wurden, der Lösungen aus anderen einschlägigen technischen Spezifikationen anwendet, die entsprechenden wesentlichen Gesundheits- und Sicherheitsanforderungen dieser Richtlinie erfüllen, falls er die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat;“

  - (d) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

- (3) Anhang IV wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

  - (b) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

- (4) In Anhang V Nummer 4 erhält Nummer 4.1 folgende Fassung:

„4.1 Alle Produkte werden einzeln untersucht, und es werden die entsprechenden Prüfungen nach der/den einschlägigen harmonisierten Norm/en und/oder gemeinsamen Spezifikation(en) und/oder gleichwertige Prüfungen, die in anderen einschlägigen technischen Spezifikationen aufgeführt sind, durchgeführt, um ihre Konformität mit der in dem EU-Baumusterprüfbescheinigung beschriebenen zugelassenen Baumuster und den anwendbaren Anforderungen dieser Richtlinie zu überprüfen.

In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

- (5) Anhang VII wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

  - (b) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

- (6) Anhang VIII Nummer 2 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Gesundheits- und Sicherheitsanforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

- (7) Anhang IX wird wie folgt geändert:

  - (a) Nummer 2.1 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den wesentlichen Gesundheits- und Sicherheitsanforderungen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

  - (b) Nummer 4 Unterabsatz 1 erhält folgende Fassung:

„Eine vom Hersteller gewählte notifizierte Stelle führt die entsprechenden Untersuchungen und Prüfungen nach den einschlägigen harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen, die in anderen einschlägigen technischen Spezifikationen aufgeführt sind, durch oder lässt sie durchführen, um die Konformität des Produkts mit den anwendbaren Anforderungen dieser Richtlinie zu prüfen. In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

- (8) Anhang X wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers und gegebenenfalls seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird:“

<a id="annex-x"></a>
## Anhang X

Die Anhänge III und IV der Richtlinie 2014/35/EU werden wie folgt geändert:

- (1) Anhang III Nummer 2 Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche in Artikel 13 und 14 genannten internationalen oder nationalen Normen oder welche in Artikel 12a genannten gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen bzw. internationalen oder nationalen Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung, mit welchen Lösungen den Sicherheitszielen dieser Richtlinie entsprochen wurde, einschließlich einer Aufstellung, welche anderen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall der teilweisen Anwendung von harmonisierten Normen bzw. von in Artikel 13 und 14 genannten internationalen oder nationalen Normen oder gemeinsamen Spezifikationen ist in den technischen Unterlagen anzugeben, welche Teile angewandt wurden;

- (2) Anhang IV wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

(6) Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird:“

<a id="annex-xi"></a>
## Anhang XI

Die Anhänge Ia und III bis VII der Richtlinie 2014/53/EU werden wie folgt geändert:

- (1) In Anhang Ia Teil II erhält der einleitende Satz folgende Fassung:

„Bei Funkanlagen, die in den Anwendungsbereich von Artikel 3 Absatz 4 Unterabsatz 1 fallen, sind nach den Anforderungen gemäß Artikel 10 Absatz 8 folgende Informationen anzugeben:“

- (2) Anhang III, Modul B: EU-Baumusterprüfung wird wie folgt geändert:

  - (a) Nummer 3 wird wie folgt geändert:

(I) Die Buchstaben a und d erhalten folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

(II) Buchstabe d Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen vermerkt sein, nach denen vorgegangen wurde, insbesondere wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

  - (b) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, die Aspekte der grundlegenden Anforderungen, auf die sich die Prüfung bezieht, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des bewerteten Baumusters erforderlichen Angaben.“

  - (c) Nummer 8 Unterabsatz 3 Satz 1 erhält folgende Fassung:

„Jede notifizierte Stelle unterrichtet die Mitgliedstaaten über die EU-Baumusterprüfbescheinigungen, die sie ausgestellt hat, und/oder über die Ergänzungen dazu, falls harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder gemeinsame Spezifikationen vorliegen und nicht oder nicht vollständig angewandt wurden.“

- (3) Anhang IV wird wie folgt geändert:

  - (a) Nummer 3.1 Buchstabe a erhält folgende Fassung:

„a) Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten;“

  - (b) Nummer 3.2 Buchstabe b erhält folgende Fassung:

„b) technische Konstruktionsspezifikationen, einschließlich der angewandten Normen, sowie – wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt werden – die Mittel, mit denen gewährleistet werden soll, dass die für Funkanlagen geltenden grundlegenden Anforderungen dieser Richtlinie erfüllt werden;“

  - (c) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Bestandteilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, geht sie von einer Konformität mit diesen Anforderungen aus.“

- (4) Anhang V Buchstabe d erhält folgende Fassung:

„d) eine Aufstellung darüber, welche harmonisierten Normen, deren Verweise im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, und, wenn diese harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden, eine Beschreibung der Lösungen, mit denen den grundlegenden Anforderungen des Artikels 3 dieser Verordnung entsprochen wurde, einschließlich einer Aufstellung darüber, welche sonstigen einschlägigen technischen Spezifikationen angewandt worden sind. Im Fall von teilweise angewandten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

- (5) Anhang VI wird wie folgt geändert:

  - (a) Nummer 2 erhält folgende Fassung:

„2. Name, Postanschrift und digitale Kontaktdaten des Herstellers oder seines Bevollmächtigten:“

  - (b) Nummer 6 Satz 1 erhält folgende Fassung:

„Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird.“

- (6) Anhang VII wird gestrichen.

<a id="annex-xii"></a>
## Anhang XII

Die Anhänge I, III und IV der Richtlinie 2014/68/EU werden wie folgt geändert:

- (1) Anhang I wird wie folgt geändert:

  - (a) Nummer 3.1.2 Unterabsatz 5 erhält folgende Fassung:

„Zur Erteilung dieser Zulassungen hat die unabhängige Stelle die in den entsprechenden harmonisierten Normen oder gemeinsamen Spezifikationen vorgesehenen Untersuchungen und Prüfungen oder gleichwertige Untersuchungen und Prüfungen durch zuführen oder diese durchführen zu lassen.“

  - (b) Nummer 4.2 Buchstabe b erster Gedankenstrich erhält folgende Fassung:

„— Verwendung von Werkstoffen entsprechend den harmonisierten Normen oder gemeinsamen Spezifikationen;“

  - (c) Absatz 7 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Werden sie nicht angewandt, einschließlich für den Fall, dass Werkstoffe nicht speziell genannt sind und harmonisierte Normen oder gemeinsame Spezifikationen nicht angewandt werden, so ist vom Hersteller nachzuweisen, dass geeignete Maßnahmen ergriffen wurden, um ein gleichwertiges Gesamtsicherheitsniveau zu erzielen.“

- (2) Anhang III wird wie folgt geändert:

  - (a) Teil 1: Modul A: INTERNE FERTIGUNGSKONTROLLE Nummer 2 vierter Gedankenstrich erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

  - (b) Teil 2: Modul A2: INTERNE FERTIGUNGSKONTROLLE MIT ÜBERWACHTEN DRUCKGERÄTEPRÜFUNGEN IN UNREGELMÄSSIGEN ABSTÄNDEN Nummer 2 vierter Gedankenstrich erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

  - (c) Teil 3: Modul B: EU-BAUMUSTERPRÜFUNG wird wie folgt geändert:

(I) Nummer 3.1 EU-Baumusterprüfung (Baumuster) Nummer 3 wird wie folgt geändert:

      - – Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

      - – Unterabsatz 2 Gedankenstrich 3 Untergedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

      - – Unterabsatz 4 einziger Gedankenstrich Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen vermerkt sein, nach denen vorgegangen wurde, insbesondere wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

(II) Nummer 4.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Sie begutachtet die Werkstoffe, wenn diese nicht den geltenden harmonisierten Normen oder gemeinsamen Spezifikationen oder einer europäischen Werkstoffzulassung für Druckgerätewerkstoffe entsprechen, und überprüft die vom Werkstoffhersteller gemäß Anhang I Nummer 4.3 ausgestellte Bescheinigung.“

(III) Die Nummern 4.2, 4.3 und 4.4 erhalten folgende Fassung:

„4.2 Prüfung, ob das/die Muster in Übereinstimmung mit den technischen Unterlagen hergestellt wurde/n, und Feststellung, welche Teile nach den anwendbaren Vorschriften der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen entworfen wurden und welche Teile unter Zugrundelegung sonstiger technischer Spezifikationen ohne Anwendung der einschlägigen Vorschriften dieser Normen entworfen wurden;

4.3 Durchführung der geeigneten Untersuchungen und erforderlichen Prüfungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich dafür entschieden hat, diese anzuwenden;

4.4 Durchführung der geeigneten Untersuchungen und erforderlichen Prüfungen, um festzustellen, ob die Lösungen, die von einem Hersteller gewählt werden, der sonstige einschlägige technische Spezifikationen anwendet, die entsprechenden wesentlichen Sicherheitsanforderungen der Richtlinie erfüllen, falls er die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat.“

(IV) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Unbeschadet der Nummer 7 muss diese Bescheinigung zehn Jahre lang gültig und verlängerbar sein, und sie muss den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die erforderlichen Daten für die Identifizierung des zugelassenen Baumusters enthalten.“

(V) Nummer 3.2 EU-Baumusterprüfung (Entwurfsmuster) Nummer 3 wird wie folgt geändert:

      - – Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

      - – Unterabsatz 2 Gedankenstrich 3 Untergedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

      - – Unterabsatz 2 Gedankenstrich 4 Satz 2 erhält folgende Fassung:

„In diesen zusätzlichen Nachweisen müssen alle Unterlagen vermerkt sein, nach denen vorgegangen wurde, insbesondere wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt worden sind.“

(VI) Nummer 4.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Sie begutachtet die verwendeten Werkstoffe, wenn diese nicht den geltenden harmonisierten Normen oder gemeinsamen Spezifikationen oder einer europäischen Werkstoffzulassung für Druckgerätewerkstoffe entsprechen.“

(VII) Die Nummern 4.2 und 4.3 erhalten folgende Fassung:

„4.2 Durchführung der geeigneten Untersuchungen, um festzustellen, ob die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen korrekt angewandt worden sind, sofern der Hersteller sich für ihre Anwendung entschieden hat;

4.3 Durchführung der geeigneten Untersuchungen, um festzustellen, ob die vom Hersteller gewählten Lösungen die entsprechenden wesentlichen Sicherheitsanforderungen der Richtlinie erfüllen, falls er die Lösungen aus den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt hat.“

(VIII) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Unbeschadet der Nummer 7 muss diese Bescheinigung zehn Jahre lang gültig und verlängerbar sein, und sie muss den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die erforderlichen Daten für die Identifizierung des zugelassenen Baumusters enthalten.“

  - (d) Teil 4: MODUL C2: KONFORMITÄT MIT DER BAUART AUF DER GRUNDLAGE EINER INTERNEN FERTIGUNGSKONTROLLE MIT ÜBERWACHTEN DRUCKGERÄTEPRÜFUNGEN IN UNREGELMÄSSIGEN ABSTÄNDEN Nummer 3 Unterabsatz 3 erhält folgende Fassung:

„Vor dem Inverkehrbringen entnimmt die notifizierte Stelle vor Ort eine geeignete Stichprobe der fertigen Druckgeräte und untersucht sie; ferner führt sie geeignete Prüfungen entsprechend den einschlägigen Abschnitten der harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen nach sonstigen einschlägigen technischen Spezifikationen durch, um die Konformität der Druckgeräte mit den anwendbaren Anforderungen der Rechtsvorschrift zu prüfen.“

  - (e) Teil 5: MODUL D: KONFORMITÄT MIT DEM BAUMUSTER AUF DER GRUNDLAGE EINER AUF DEN PRODUKTIONSPROZESS BEZOGENEN QUALITÄTSSICHERUNG wird wie folgt geändert:

(I) Nummer 3.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(II) Nummer 3.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (f) Teil 6: MODUL D1: QUALITÄTSSICHERUNG BEZOGEN AUF DEN PRODUKTIONSPROZESS wird wie folgt geändert:

(I) Nummer 2 Unterabsatz 1 Gedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

(II) Nummer 5.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(III) Absatz 5.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei jedem Bestandteil des Qualitätssicherungssystems, der die entsprechende harmonisierte Norm oder gemeinsame Spezifikation erfüllt, wird von der Erfüllung der in Nummer 5.2 genannten Anforderungen ausgegangen.“

  - (g) Teil 7: MODUL E: KONFORMITÄT MIT DER BAUART AUF DER GRUNDLAGE DER QUALITÄTSSICHERUNG BEZOGEN AUF DAS DRUCKGERÄT wird wie folgt geändert:

(I) Nummer 3.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(II) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (h) Teil 8: MODUL E1: QUALITÄTSSICHERUNG VON ENDABNAHME UND PRÜFUNG DER DRUCKGERÄTE wird wie folgt geändert:

(I) Nummer 2 Unterabsatz 1 Gedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

(II) Nummer 5.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(III) Nummer 5.3 Unterabsatz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (i) Teil 9: MODUL F: KONFORMITÄT MIT DER BAUART AUF DER GRUNDLAGE EINER PRÜFUNG DER DRUCKGERÄTE Nummer 4.1 Unterabsatz 1 erhält folgende Fassung:

„Alle Druckgeräte werden einzeln untersucht und dabei geeigneten Prüfungen, wie sie in der (den) einschlägigen harmonisierten Norm(en) oder gemeinsamen Spezifikationen vorgesehen sind, oder gleichwertigen Prüfungen unterzogen, um ihre Übereinstimmung mit der in der EU-Baumusterprüfbescheinigung beschriebenen zugelassenen Bauart und mit den anwendbaren Anforderungen dieser Richtlinie zu überprüfen. In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen durchgeführt werden.“

  - (j) Teil 10: MODUL G: KONFORMITÄT AUF DER GRUNDLAGE EINER EINZELPRÜFUNG wird wie folgt geändert:

(I) Nummer 2 Unterabsatz 3 Gedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in den technischen Unterlagen angegeben.“

(II) Nummer 4 Unterabsatz 1 erhält folgende Fassung:

„Eine vom Hersteller gewählte notifizierte Stelle führt die entsprechenden Untersuchungen und Prüfungen nach den einschlägigen harmonisierten Normen und/oder gemeinsamen Spezifikationen und/oder gleichwertige Prüfungen nach sonstigen einschlägigen technischen Spezifizierungen durch oder lässt sie durchführen, um die Konformität des Druckgeräts mit den anwendbaren Anforderungen dieser Richtlinie zu prüfen. In Ermangelung einer solchen harmonisierten Norm oder gemeinsamen Spezifikation entscheidet die notifizierte Stelle darüber, welche Prüfungen unter Anwendung sonstiger technischer Spezifikationen durchgeführt werden.“

(III) Nummer 4 Unterabsatz 2 Gedankenstrich 2 erhält folgende Fassung:

„— Sie begutachtet die verwendeten Werkstoffe, wenn diese nicht den geltenden harmonisierten Normen oder gemeinsamen Spezifikationen oder einer europäischen Werkstoffzulassung für Druckgerätewerkstoffe entsprechen, und überprüft die vom Werkstoffhersteller gemäß Anhang I Nummer 4.3 ausgestellte Bescheinigung.“

  - (k) Teil 11: MODUL H: KONFORMITÄT AUF DER GRUNDLAGE EINER UMFASSENDEN QUALITÄTSSICHERUNG wird wie folgt geändert:

(I) Nummer 3.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(II) Nummer 3.1 Unterabsatz 2 Gedankenstrich 2 Untergedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden; Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

(III) Nummer 3.2 Unterabsatz 3 Gedankenstrich 2 erhält folgende Fassung:

„— technische Konstruktionsspezifikationen, einschließlich der angewandten Normen, sowie – wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht in vollem Umfang angewandt werden – die Mittel, mit denen gewährleistet werden soll, dass die für Funkanlagen geltenden grundlegenden Anforderungen dieser Richtlinie erfüllt werden,“

(IV) Nummer 3.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

  - (l) Teil 12: MODUL H1: KONFORMITÄT AUF DER GRUNDLAGE EINER UMFASSENDEN QUALITÄTSSICHERUNG MIT ENTWURFSPRÜFUNG wird wie folgt geändert:

(I) Nummer 3.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten,“

(II) Nummer 3.1 Unterabsatz 2 Gedankenstrich 2 Untergedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

(III) Nummer 3.2 Unterabsatz 3 Gedankenstrich 2 erhält folgende Fassung:

„— technische Konstruktionsspezifikationen, einschließlich der angewandten Normen, sowie – wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht vollständig angewandt werden – die Mittel, mit denen gewährleistet werden soll, dass die für die Druckgeräte geltenden wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt werden;“

(IV) Nummer 3.3 Unterabsatz 2 Satz 1 erhält folgende Fassung:

„Bei den Teilen des Qualitätssicherungssystems, die die entsprechenden Spezifikationen der einschlägigen harmonisierten Norm oder gemeinsamen Spezifikation erfüllen, wird von der Erfüllung dieser Anforderungen ausgegangen.“

(V) Nummer 4.2 erster Gedankenstrich erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers,“

(VI) Nummer 4.2 Gedankenstrich 3 Untergedankenstrich 4 erhält folgende Fassung:

„— eine Aufstellung, welche harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder welche gemeinsamen Spezifikationen vollständig oder in Teilen angewandt worden sind, sowie eine Beschreibung, mit welchen Lösungen die wesentlichen Sicherheitsanforderungen dieser Richtlinie erfüllt worden sind, wenn die genannten harmonisierten Normen oder gemeinsamen Spezifikationen nicht angewandt wurden. Im Fall von teilweise angewendeten harmonisierten Normen oder gemeinsamen Spezifikationen werden die Teile, die angewandt wurden, in der technischen Dokumentation angegeben.“

(VII) Nummer 4.2 vierter Gedankenstrich erhält folgende Fassung:

„— die zusätzlichen Nachweise für eine angemessene Lösung durch den technischen Entwurf. Diese zusätzlichen Nachweise enthalten einen Verweis auf sämtliche Dokumente, die zugrunde gelegt wurden, insbesondere wenn die einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen nicht vollständig angewandt wurden, und schließen gegebenenfalls die Ergebnisse von Prüfungen ein, die in einem geeigneten Labor des Herstellers oder in seinem Auftrag und unter seiner Verantwortung in einem anderen Prüflabor durchgeführt wurden.“

(VIII) Nummer 4.3 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Diese Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfungen, etwaige Bedingungen für ihre Gültigkeit und die erforderlichen Daten für die Identifizierung des zugelassenen Entwurfs.“

- (3) Anhang IV wird wie folgt geändert:

  - (a) Punkt 1 erhält folgende Fassung:

„1. Name, Postanschrift und digitale Kontaktdaten des Herstellers und gegebenenfalls seines Bevollmächtigten:“

  - (b) Nummer 6 erhält folgende Fassung:

„6. Angabe der einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen, die zugrunde gelegt wurden, oder Angabe der sonstigen technischen Spezifikationen, für die die Konformität erklärt wird:“

  - (c) Punkt 7 erhält folgende Fassung:

„7. Gegebenenfalls Name, Postanschrift, digitale Kontaktdaten und Nummer der notifizierten Stelle, die die Konformitätsbewertung vorgenommen hat, Nummer der ausgestellten Bescheinigung und Verweis auf die EU-Baumusterprüfbescheinigung (Baumuster), die EU-Baumusterprüfbescheinigung (Entwurfsmuster), die EU-Entwurfsprüfbescheinigung oder die Konformitätsbescheinigung.

<a id="annex-xiii"></a>
## Anhang XIII

Anhang II der Richtlinie 2014/90/EU wird wie folgt geändert:

- (1) Teil I: Modul B: EG-BAUMUSTERPRÜFUNG wird wie folgt geändert:

  - (a) Nummer 3 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“

  - (b) Nummer 6 Unterabsatz 1 Satz 2 erhält folgende Fassung:

„Die Bescheinigung enthält den Namen, die Postanschrift und die digitalen Kontaktdaten des Herstellers, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des zugelassenen Baumusters erforderlichen Angaben.“

- (2) In Teil II: Modul D: KONFORMITÄT MIT DER BAUART AUF DER GRUNDLAGE EINER QUALITÄTSSICHERUNG BEZOGEN AUF DEN PRODUKTIONSPROZESS Nummer 3.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“

- (3) In Teil III: Modul E: KONFORMITÄT MIT DEM BAUMUSTER AUF DER GRUNDLAGE DER QUALITÄTSSICHERUNG BEZOGEN AUF DAS PRODUKT Nummer 3.1 Unterabsatz 2 Gedankenstrich 1 erhält folgende Fassung:

„— Name, Postanschrift und digitale Kontaktdaten des Herstellers sowie, wenn der Antrag vom Bevollmächtigten eingereicht wird, auch dessen Name, Postanschrift und digitale Kontaktdaten“
