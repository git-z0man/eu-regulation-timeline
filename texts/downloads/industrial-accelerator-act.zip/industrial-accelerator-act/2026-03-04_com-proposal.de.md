---
act: industrial-accelerator-act
version: 2026-03-04_com-proposal
stage: com-proposal
language: de
celex: 52026PC0100
title: Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Schaffung eines Rahmens von Maßnahmen zur Beschleunigung der Verstärkung der industriellen Kapazitäten und der Dekarbonisierung in strategischen Sektoren sowie zur Änderung der Verordnungen (EU) 2018/1724, (EU) 2024/1735 und (EU) 2024/3110
retrieved: '2026-09-24'
converter: tools/eurlex2md.py
counts:
  recitals: 81
  articles: 36
  annexes: 4
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52026PC0100
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Schaffung eines Rahmens von Maßnahmen zur Beschleunigung der Verstärkung der industriellen Kapazitäten und der Dekarbonisierung in strategischen Sektoren sowie zur Änderung der Verordnungen (EU) 2018/1724, (EU) 2024/1735 und (EU) 2024/3110

<a id="begr-ndung"></a>
## BEGRÜNDUNG

### 1. KONTEXT DES VORSCHLAGS

#### • Gründe und Ziele des Vorschlags

Diese Begründung ist dem Vorschlag für eine Verordnung zur Schaffung eines Rahmens von Maßnahmen zur Beschleunigung der Verstärkung der industriellen Kapazitäten und der Dekarbonisierung in strategischen Sektoren, der „Verordnung zur industriellen Beschleunigung“, beigefügt.

In der heutigen geopolitischen Landschaft stellt der häufige und gezielte Einsatz wirtschaftlicher Instrumente zum Vorantreiben strategischer Ziele eine ernsthafte Bedrohung für die Resilienz, Wettbewerbsfähigkeit, wirtschaftliche Sicherheit und strategische Autonomie der Union dar. Wie im Draghi-Bericht über die europäische Wettbewerbsfähigkeit hervorgehoben wird, beeinträchtigt die Instrumentalisierung der Abhängigkeiten der EU von Handelspartnern in strategischen Sektoren die Sicherheit, Wettbewerbsfähigkeit und Wirtschaft der EU^(1). Die Fähigkeit der Union, auf Abhängigkeiten von Drittländern zu reagieren und diese zu verringern, liegt in der Stärke ihrer industriellen Basis, ihrer Innovationsfähigkeit und der Integrität des Binnenmarkts.

Wie unter anderem in der Mitteilung der Kommission über den Deal für eine saubere Industrie^(2) dargelegt wird, bietet der Übergang zu einer sauberen und digitalen Wirtschaft eine große Chance zur Stärkung der industriellen Basis der EU. Der globale Wettbewerb, der rasche technologische Wandel, strukturelle Kostennachteile, unfaire globale Marktverzerrungen wie die zunehmende Nutzung ausländischer Subventionen zur Schaffung eines Wettbewerbsvorteils und die Ausnutzung wirtschaftlicher Abhängigkeiten verändern die globalen Wertschöpfungsketten. Gleichzeitig verschärfen die wachsenden geopolitischen Spannungen bestehende Schwachstellen und schaffen neue. Vor diesem Hintergrund muss die EU strategisch handeln, um ihre Resilienz und industrielle Basis sowie ihre langfristige Wettbewerbsfähigkeit zu sichern und weiter zu stärken und um sicherzustellen, dass die Klimawende zu einem Motor des industriellen Wachstums wird.

Das verarbeitende Gewerbe ist von entscheidender Bedeutung für den Erhalt und die Stärkung der langfristigen wirtschaftlichen Resilienz der EU und die Erreichung ihres Ziel der Klimaneutralität. Im Jahr 2024 entfielen 18,3 % der Beschäftigung in der gewerblichen Wirtschaft der EU^(3) und 14,3 % des gesamten BIP der EU^(4) auf das verarbeitende Gewerbe, während es für 26,2 % der Treibhausgasemissionen der EU^(5) verantwortlich war. Trotz seiner anhaltenden wirtschaftlichen Bedeutung ist der Anteil dieses Sektors am BIP in den letzten Jahrzehnten von 17,4 % im Jahr 2000 auf sein derzeitiges Niveau von 14,3 % zurückgegangen^(6). Dieser Rückgang stellt nicht nur eine wirtschaftliche Realität dar, sondern ist ein strategisches Warnsignal mit potenziell strukturellen Auswirkungen auf den Wohlstand und den sozialen Zusammenhalt der EU. Gleichzeitig steht das verarbeitende Gewerbe zunehmend Herausforderungen wie hohen Energiepreisen, globalen Überkapazitäten, hohen Kapital- und Betriebskosten für die Dekarbonisierung und den Einsatz neuer Technologien, einem im Vergleich zu anderen Regionen geringen Investitionsvolumen sowie regulatorischen Hürden gegenüber^(7).

Aus diesem Grund soll mit der Verordnung zur industriellen Beschleunigung sichergestellt werden, dass sich dieser Trend bis 2035 umkehrt und das verarbeitende Gewerbe 20 % des BIP der EU ausmacht. Zu diesem Zweck werden die Genehmigungsverfahren für sämtliche Fertigungsprojekte durch die Verordnung beschleunigt, und es wird ein Instrumentarium bereitgestellt, mit dem der Zugang zum europäischen Binnenmarkt in einer Weise ermöglicht wird, die strategische Abhängigkeiten verhindert, Arbeitsplätze im verarbeitenden Gewerbe schafft, die Dekarbonisierung und die Klimaleistung vorantreibt und jederzeit den Zugang der europäischen Bürgerinnen und Bürger und Unternehmen zu lebenswichtigen Rohstoffen und Produkten sichert.

Um die strategische Autonomie der EU zu erreichen und gleichzeitig die Wettbewerbsfähigkeit der Industrie unter Wahrung der Dekarbonisierungsziele zu erhalten, bedarf es eines soliden Geschäftsszenarios. In diesem Zusammenhang ist die Stärkung der Wettbewerbsfähigkeit bestimmter strategischer Sektoren und Technologien, insbesondere von Netto-Null-Technologien sowie energieintensiven Industrien und der Automobillieferkette, für die Resilienz, die strategische Autonomie und die Klimaziele der EU von entscheidender Bedeutung. Würde es versäumt, wichtige Lieferketten zu sichern und zu diversifizieren, brächte dies erhebliche wirtschaftliche und gesellschaftliche Risiken mit sich, die zu einer potenziellen Störung der öffentlichen Ordnung in der Union führen könnten. Die Verringerung externer Schwachstellen könnte dazu beitragen, unsere Wirtschaft zu stärken, Investitionen anzukurbeln und das Geschäftsszenario für den laufenden tiefgreifenden industriellen Wandel zu unterstützen.

Die unter die Verordnung zur industriellen Beschleunigung fallenden Sektoren – insbesondere energieintensive Industrien, die Fertigung von Netto-Null-Technologien und die Automobilindustrie – machen nur einen begrenzten Anteil der Produktion des verarbeitenden Gewerbes in der EU aus, spielen jedoch eine unverhältnismäßig große strategische Rolle. Zusammengenommen entfallen auf die strategischen Sektoren, auf die die Verordnung zur industriellen Beschleunigung abzielt, rund 15 % der Produktion des verarbeitenden Gewerbes in der EU. Ihre Bedeutung liegt daher weniger in ihrer gesamtwirtschaftlichen Größe als in ihrer zentralen Rolle als vorgelagerte Lieferanten und Voraussetzungen nachgelagerter industrieller Ökosysteme, wie des Bauwesens, der Mobilität, der Energie sowie der Raumfahrt und Verteidigung.

Verzögerte oder unzureichende Fortschritte beim Klimaschutz könnten die wirtschaftlichen und sozialen Auswirkungen des Klimawandels verstärken und sich auf die soziale Stabilität auswirken. Insbesondere in den folgenden Bereichen sind Maßnahmen erforderlich:

Energieintensive Industrien sind eine tragende Säule des Wohlstands in Europa und ein Eckpfeiler der industriellen Basis des Kontinents; bilden die Grundlage für die meisten industriellen Ökosysteme. Dennoch sind die Produktionsmengen in energieintensiven Industrien seit 2021 im Vergleich zu anderen verarbeitenden Sektoren erheblich zurückgegangen^(8). Das Kostengefälle zu anderen Regionen der Welt hat sich vergrößert, und die Einfuhranteile haben insbesondere bei Grundmetallen und Chemikalien zugenommen^(9). Die Kapazitätsauslastung befindet sich nach wie vor auf einem unhaltbar niedrigen Niveau^(10). Für die Dekarbonisierung dieser Industrien sind erhebliche Investitionen erforderlich^(11), doch die Dekarbonisierung schreitet nicht schnell genug voran, um die Klimaziele der EU zu erreichen. Obwohl viele Dekarbonisierungsvorhaben angekündigt wurden und einige im Gange sind, ist seit 2023 mehr als die Hälfte der Projekte noch nicht umgesetzt worden^(12). Die Modernisierung dieser Sektoren ist nicht nur für die Verwirklichung der Klimaziele der EU von grundlegender Bedeutung, sondern auch für die Fähigkeit Europas, industriellen Wertschöpfungsketten Stabilität zu bieten und hochwertige Arbeitsplätze zu schaffen. Unter den energieintensiven Industrien sind Stahl und Zement die größten Emittenten, während auf die chemische Industrie der drittgrößte Anteil an den Treibhausgasemissionen der EU entfällt. Aluminium zeichnet sich ebenfalls durch eine hohe Stromintensität aus und gilt als strategischer Rohstoff, wobei die Nachfrage bis 2050 voraussichtlich um 33 % steigen wird. Gleichzeitig haben diese Industrien in den letzten zehn Jahren in der EU erhebliche Marktanteile verloren. Angesichts ihrer hohen Emissionsintensität und ihrer strategischen Rolle für die Energiewende und den digitalen Wandel gelten diese Industrien als prioritär für die Einführung nachfrageseitiger Maßnahmen. Darüber hinaus zeichnen sie sich durch begrenzte Kostenauswirkungen auf nachgelagerte Wirtschaftszweige aus.

Netto-Null-Technologien stehen hinsichtlich der Wettbewerbsfähigkeit und angesichts erheblicher Schwachstellen in der Lieferkette vor Herausforderungen^(13). Während die Einführung in der EU – und weltweit – voranschreitet, geht bei der Herstellung dieser Technologien der weltweite Marktanteil der EU zurück. Die Fertigung konzentriert sich stark auf China, auf das mehr als 80 % der Fertigungskapazitäten im Bereich Batterien und Photovoltaik entfallen; hierunter fallen auch Solarwechselrichter, die eine wesentliche Funktion in der kritischen Infrastruktur der Union erfüllen. Bei anderen Netto-Null-Technologien wie Wärmepumpen und Geothermie ist die Produktion in der EU in hohem Maße von Bauteilen von Nicht-EU-Lieferanten abhängig. Windkrafttechnologien sind Kostendruck durch Niedrigpreiseinfuhren aus China ausgesetzt, während Technologien zur CO2-Abscheidung beim Transport und der Speicherung von CO2 hinterherhinken. Ohne entschlossenes Handeln besteht die Gefahr, dass die EU gerade in einer Zeit, in der globale Partner ihre Industriestrategien^(14) vorantreiben und ihre industriellen Stärken ausnutzen, noch stärker von eingeführten sauberen Technologien abhängig wird. Gleichzeitig stellen Netto-Null-Technologien eine Quelle der industriellen Stärke der EU dar, und angesichts der von Drittländern unfair subventionierten Überkapazitäten müssten ihnen weltweit gleiche Wettbewerbsbedingungen gewährt werden.

Auch die nachgelagerten Wirtschaftszweige stehen unter Druck. Die Wettbewerbsfähigkeit der europäischen Automobilindustrie – einem Sinnbild für die industrielle Führungsrolle der Union – ist erheblich zurückgegangen, wobei die durchschnittliche Rentabilität der europäischen Automobilzulieferer von 7,4 % im Jahr 2017 auf 5 % im Jahr 2023 gesunken ist und 2024/2025 angekündigt wurde, dass mehr als 100 000 Stellen abgebaut werden sollen^(15). Jüngsten Umfragen zufolge plant die Hälfte der europäischen Automobilzulieferer, ihre Produktionskapazität in der EU in den nächsten Jahren zu verringern. Dieser Rückgang bedroht Hunderttausende von Arbeitsplätzen und die Integrität der industriellen Zukunft Europas.

Vor diesem Hintergrund werden in dem Vorschlag die folgenden drei wesentlichen Teilprobleme thematisiert:

- 1) Schwachstellen in den Lieferketten in strategischen Sektoren und Technologien. Der globale, nicht immer faire Wettbewerb und Abhängigkeiten in der internationalen Wertschöpfungskette untergraben die Fähigkeit Europas, die Produktion in strategischen Sektoren und Technologien zu steigern bzw. zu sichern. Ein Problembereich ist der in der EU bestehende Mangel an technologischem Know-how und Fertigungskompetenz für bestimmte wichtige Netto-Null-Technologien und digitale Technologien. Diese Probleme werden dadurch verschärft, dass in der EU im Hinblick auf ausländische Investitionen, die häufig nicht mit Technologietransfer, der Schaffung von Arbeitsplätzen und der Integration der Wertschöpfungskette einhergehen, ein fragmentierter Ansatz verfolgt wird.

- 2) Begrenzte Nachfrage/fehlende Leitmärkte für europäische CO2-arme Industrieprodukte. Hohe Produktionskosten, unterschiedliche Technologie-Reifegrade und fehlende industrielle Skalierungseffekte schränken die Entwicklung und die Markteinführung CO2-armer Produkte in energieintensiven Industrien ein, wodurch Investitionen in die Dekarbonisierung untergraben oder verzögert werden. Dies wird durch die Herausforderungen bei der Unterscheidung zwischen CO2-armen Industrieprodukten und CO2-intensiven Äquivalenten und die begrenzte Bereitschaft nachgelagerter Sektoren zur Zahlung eines Aufpreises für CO2-arme Produkte noch verstärkt.

- 3) Industrielle Technologien werden nicht in großem Maßstab eingesetzt. Langwierige, fragmentierte Genehmigungsverfahren und solche mit unsicherem Ausgang für Projekte zur Dekarbonisierung der Industrie unter Einschluss von Infrastrukturanbindungen verzögern die Einführung und den umfassenden Einsatz neuer Technologien. Für die Dekarbonisierung industrieller Prozesse ist eine tiefgreifende und kostspielige Transformation von Vermögenswerten und Unternehmenstätigkeiten erforderlich, was erhebliche Investitionen mit sich bringt, die während langwieriger Genehmigungsverfahren möglicherweise blockiert werden. Schwierigkeiten bei der Verringerung des Investitionsrisikos und beim Zugang zu Finanzmitteln stellen einen wichtigen Engpass für Investitionen dar.

Vor diesem Hintergrund wurde im Deal für eine saubere Industrie eine neue Regulierungsinitiative angekündigt, um Engpässe bei Genehmigungen zu beseitigen, Resilienz- und Nachhaltigkeitskriterien einzuführen und Leitmärkte für europäische saubere und widerstandsfähige Industrieprodukte und -technologien zu schaffen.

Mit diesem Vorschlag wird das politische Engagement von Präsidentin von der Leyen erfüllt, die in ihrer Rede zur Lage der Union 2025 eine Verordnung zur industriellen Beschleunigung ankündigte, mit der die Nachfrage nach sauberen und in der EU hergestellten Produkten in strategischen Sektoren und Technologien angekurbelt werden soll. Sie wird auch in der Mitteilung über die Europäische Wirtschaftsstrategie vom 3. Dezember 2025 angekündigt.

Der Legislativvorschlag zielt darauf ab, die langfristige wirtschaftliche Resilienz, den Wohlstand und die strategische Autonomie der EU zu stärken, indem die industrielle Produktion unterstützt und die Dekarbonisierung beschleunigt wird. Er hat folgende Ziele:

- · Nutzung des Zugangs zum Binnenmarkt und dessen Umfangs, um die Nachfrage nach europäischen CO2-armen Industrieprodukten und Netto-Null-Technologien anzukurbeln; hierzu soll unter anderem eine Differenzierung nach CO2-armem Stahl erleichtert werden, um auf diese Weise dessen Wert und Marktgängigkeit zu steigern;

- · Maximierung der Qualität ausländischer Investitionen in der EU und deren Nutzens für den Binnenmarkt in den strategisch wichtigsten Sektoren;

- · großmaßstäbliche Umsetzung von Fertigungsprojekten mittels Beschleunigung und Vereinfachung der Genehmigungen für Fertigungsprojekte sowie mittels Erleichterung der Entwicklung von Industrieclustern in Beschleunigungsgebieten für die industrielle Fertigung (im Folgenden „Beschleunigungsgebiete“).

Zur Erreichung dieser Ziele wird mit dem Vorschlag ein ausgewogener Regulierungsansatz eingeführt, um die Wettbewerbsfähigkeit der Industrie zu verbessern und strategische Abhängigkeiten in Schlüsselsektoren abzumildern bzw. zu verhindern. Der Vorschlag ist auf die Mindestanforderungen beschränkt, die erforderlich sind, um die Probleme, mit denen bestimmte strategische Sektoren derzeit konfrontiert ist, anzugehen, ohne den Markt und die technologische Entwicklung übermäßig einzuschränken oder die Kosten für bestimmte Materialien und Produkte unverhältnismäßig zu erhöhen. Darüber hinaus wird mit dem Vorschlag ein Rahmen zur Straffung der Genehmigungsverfahren und zur Förderung eines koordinierten Ansatzes für Investitionsprojekte in der gesamten Union geschaffen.

#### • Kohärenz mit den bestehenden Vorschriften in diesem Bereich

Der Vorschlag ist eine Reaktion auf den Deal für eine saubere Industrie, den „Kompass für Wettbewerbsfähigkeit der EU“ und die Gemeinsame Mitteilung über die Stärkung der wirtschaftlichen Sicherheit der EU, in denen allesamt anerkannt wird, dass dringend Maßnahmen zur Sicherung der Zukunft der EU als Wirtschaftsmacht, Investitionsziel und Produktionszentrum ergriffen werden müssen. Mit ihm wird der Aktionsplan für die europäische Automobilindustrie umgesetzt, in dem es heißt, dass die öffentliche Unterstützung für die Automobilindustrie von Resilienz- und Nachhaltigkeitskriterien abhängig gemacht werden wird, und in dem gefordert wird, dass die Verordnung zur industriellen Beschleunigung im Einklang mit den internationalen Verpflichtungen der Union die Einhaltung der „Made in EU“-Anforderungen bei Batteriezellen und -bauteilen von Elektrofahrzeugen, die in der EU verkauft werden, fördert.

Mit dem Vorschlag wird auch das am 16. Dezember 2025 angenommene Automobilpaket umgesetzt, in dem unter anderem die Gewährung von Begünstigungen für kleine, bezahlbare Elektrofahrzeuge vorgesehen ist, die vor 2035 in der Union hergestellt wurden, und mit dem das Emissionsreduktionsziel für 2035 geändert wird, wobei die verbleibenden Emissionen durch die Verwendung von in der Union hergestelltem CO2-armem Stahl oder erneuerbaren, CO2-armen Kraftstoffen ausgeglichen werden sollen. Mit diesem Vorschlag^(16) zur Änderung der Verordnung (EU) 2019/631 wird der Kommission die Befugnis übertragen, delegierte Rechtsakte zur Festlegung der Kriterien zu erlassen, nach denen Produkte, die in ihren Anwendungsbereich fallen, als „in der Union hergestellte kleine emissionsfreie Fahrzeuge“ oder „in der Union hergestellter CO2-armer Stahl“ eingestuft werden können. Das Automobilpaket umfasst ferner einen Vorschlag für eine Verordnung über saubere Unternehmensfahrzeuge^(17). Mit diesem Vorschlag wird die finanzielle Unterstützung für Unternehmensfahrzeuge auf emissionsfreie und emissionsarme Unternehmensfahrzeuge beschränkt und die Kommission ermächtigt, delegierte Rechtsakte zu erlassen, in denen die Methode zur Bestimmung der Kriterien für die Einstufung als „in der Europäischen Union hergestellt“ festgelegt wird. Um die Kohärenz zwischen den drei Instrumenten sicherzustellen und Rechtssicherheit zu gewährleisten, enthält diese Verordnung harmonisierte Begriffsbestimmungen für „in der Union hergestellte kleine und erschwingliche Elektrofahrzeuge“, „in der Union hergestellter CO2-armen Stahl“ und „in der Europäischen Union hergestellte Personenkraftwagen und leichte Nutzfahrzeuge für Unternehmen“. Dementsprechend sollten die Vorschläge vom 16. Dezember 2025 zur Gewährleistung der Kohärenz des Rechtsrahmens dahin gehend angepasst werden, dass auf den in dieser Verordnung eingeführten horizontalen Ansatz und nicht auf delegierte Rechtsakte Bezug genommen wird.

Diese Verordnung steht im Einklang mit dem Zollkodex der Union, in dem die nichtpräferenziellen Ursprungsregeln der Union festgelegt sind. Für die Bestimmung des Ursprungs der unter diese Verordnung fallenden Erzeugnisse gelten die nichtpräferenziellen Ursprungsregeln der Union gemäß dem genannten Zollkodex.

#### • Kohärenz mit der Politik der Union in anderen Bereichen

Die Verordnung zur industriellen Beschleunigung trägt zu den Rechtsvorschriften bei, die für die wirtschaftliche Sicherheit, die Wettbewerbsfähigkeit der Industrie und die Dekarbonisierung der EU wichtig sind. Angesichts der Rolle energieintensiver Industrien und Netto-Null-Technologien in vielen Wirtschaftszweigen und industriellen Wertschöpfungsketten sind verschiedene europäische politische Maßnahmen und Rechtsvorschriften von Bedeutung.

Erstens steht die Verordnung zur industriellen Beschleunigung im Einklang mit der Netto-Null-Industrie-Verordnung und ergänzt diese durch die Ausweitung gestraffter Genehmigungsvorschriften wie zentrale Anlaufstellen und einheitliche Fristen auf alle Projekte zur Dekarbonisierung energieintensiver Industrien und die Einführung von „Made in EU“-Anforderungen für einige spezifische Bauteile von Netto-Null-Technologien, um Umgehungen zu verhindern, die Fertigungskapazitäten der EU weiter auszubauen sowie resiliente, wettbewerbsfähige heimische Wertschöpfungsketten aufzubauen.

Zweitens steht der Vorschlag im Einklang mit dem Europäischen Klimagesetz, da er zur Verwirklichung des Ziels der Klimaneutralität beitragen soll, indem Investitionen in die Dekarbonisierung der Industrie und in Netto-Null-Technologien unterstützt werden.

Drittens steht der Vorschlag im Einklang mit den jüngsten Initiativen zur Straffung der Genehmigungsverfahren und zur Steigerung der Wettbewerbsfähigkeit der Automobilindustrie. Insbesondere zielt die Verordnung zur industriellen Beschleunigung darauf ab, die wichtigsten Genehmigungsverfahren insbesondere durch Digitalisierung und die Weiterverwendung von Daten zu straffen. Sie baut auf dem Maßnahmenkatalog auf, der im Rahmen des Vorschlags zur Umweltgenehmigung zur Verfügung gestellt wird und in dieser Verordnung auf die spezifischen Bedürfnisse des Sektors angewendet wird.

Der Vorschlag steht außerdem mit anderen EU-Rechtsvorschriften, mit denen der Übergang der europäischen Industrie zu einer sauberen, kreislauforientierten und klimaneutralen Wirtschaft unterstützt werden soll, im Einklang. So steht die Verordnung zur industriellen Beschleunigung beispielsweise mit künftigen produktspezifischen Umweltvorschriften im Einklang und ergänzt diese. Im Bausektor ergänzt sie die Bauprodukteverordnung, einschließlich der harmonisierten Norm für Treibhausgasemissionen und des geplanten Gütezeichens für CO2-armen Beton. Im Stahlsektor wird der geplante delegierte Rechtsakt zu Stahlerzeugnissen im Rahmen der Ökodesign-Verordnung für nachhaltige Produkte die erforderlichen Aspekte für die Umsetzung der Leitmarktbestimmungen für Stahl enthalten, wobei den unterschiedlichen Dekarbonisierungsmerkmalen der Primär- und Sekundärstahlerzeuger Rechnung getragen und die Kreislaufwirtschaft belohnt wird. Bei der Gestaltung von Kennzeichnungs- und Informationsanforderungen auf der Grundlage von Leistungsschwellen für unterschiedliche Produkte sollten diese Schwellenwerte dem Rezyklatanteil des Industrieprodukts Rechnung tragen, wobei der Schwellenwert gegebenenfalls mit der Erhöhung des Rezyklatanteils in den Produkten sinkt. In ähnlicher Weise ergänzt die Verordnung zur industriellen Beschleunigung die Batterieverordnung, mit der der Rahmen für Umweltziele für die Batterieherstellung in der EU festgelegt wird, sodass der Schwerpunkt der Bestimmungen über den Leitmarkt im Rahmen der Verordnung zur industriellen Beschleunigung auf Made in EU“-Anforderungen liegen kann. Sie ergänzt die künftigen Vorschriften über die Umweltleistung von Photovoltaik-Modulen im Rahmen des Ökodesigns und der Energieverbrauchskennzeichnung, indem die Fertigung konformer Produkte in der EU gefördert wird. Im Hinblick auf die Förderung CO2-armer und biobasierter Lösungen steht die Verordnung im Einklang mit der neuen Bioökonomie-Strategie der EU.

Der Vorschlag steht auch mit den übrigen EU-Klimavorschriften im Einklang. Das EU-Emissionshandelssystem (EU-EHS) ist das wichtigste klimapolitische Instrument zur Verringerung der Treibhausgasemissionen und spielt eine zentrale Rolle bei der Schaffung von Anreizen für Emissionsreduktionen in energieintensiven Industrien und bei der Stromerzeugung. Dieser Vorschlag ergänzt das Preissignal des EU-EHS und unterstützt die Schaffung von Leitmärkten für CO2-arme Industrieprodukte. Darüber hinaus steht er im Einklang mit der Verordnung über das CO2-Grenzausgleichssystem.

Was künftige Initiativen betrifft, so wird der vorgeschlagene Rechtsakt über die Kreislaufwirtschaft die Verordnung zur industriellen Beschleunigung ergänzen, indem das Recycling und der Zugang zu Sekundärrohstoffen gefördert und auch bei energieintensiven Industrieprodukten Abhängigkeiten und Schwachstellen verringert werden. Die Kohärenz zwischen den sektorspezifischen Maßnahmen der Verordnung zur industriellen Beschleunigung und dem übergeordneten Rahmen für die bevorstehende Überarbeitung des Rechtsrahmens für die Vergabe öffentlicher Aufträge wird ebenfalls sichergestellt.

Der Vorschlag trägt den internationalen Verpflichtungen der Union im Bereich der Vergabe öffentlicher Aufträge im Rahmen des WTO-Übereinkommens über das öffentliche Beschaffungswesen und der einschlägigen bilateralen EU-Handelsabkommen Rechnung. Wirtschaftsbeteiligte mit Sitz in Ländern, für die solche Verpflichtungen gelten, können von einem durchsetzbaren Zugang zu bestimmten, in den entsprechenden Erfassungsplänen festgelegten Vergabeverfahren profitieren. Diese Verpflichtungen sind nach Kategorien öffentlicher Auftraggeber wie unter anderem zentralen Regierungsbehörden, subzentralen Behörden, Einrichtungen des öffentlichen Rechts und Versorgungsunternehmen, sowie nach Beschaffungsarten wie Waren, Dienstleistungen und Bauleistungen gegliedert. Ihre Anwendbarkeit hängt daher vom öffentlichen Auftraggeber, der die Auftragsvergabe durchführt, und vom Auftragsgegenstand ab. Darüber hinaus behält sich die Union das Recht vor, allgemeine oder sicherheitsbezogene Ausnahmen anzuwenden.

Infolgedessen wird durch die Beschaffungsverpflichtungen der Union nicht allen Partnern ein einheitlicher oder umfassender Zugang gewährt, und es ist nicht möglich, eine zentrale Liste von Drittländern mit vollständig gesichertem Zugang zum gesamten EU-Beschaffungsmarkt festzulegen. Den öffentlichen Auftraggebern stehen ausführliche Informationen über Beschaffungsverpflichtungen und darüber, welche Lieferanten infrage kommen, zur Verfügung^(18), wodurch die einheitliche Anwendung internationaler Beschaffungsverpflichtungen gefördert und gleichzeitig die Fähigkeit der Union gewahrt wird, ihre in diesem Vorschlag dargelegten politischen Ziele zu verfolgen.

Während in der Verordnung zur industriellen Beschleunigung festgelegt wird, was eine Auftragsvergabe im Rahmen von „Made in Europe“, wovon energieintensive Industrieprodukte, Netto-Null-Technologien und Automobilbauteile erfasst werden, mit sich bringt, wird bei der bevorstehenden Überarbeitung des Rechtsrahmens für die Vergabe öffentlicher Aufträge klargestellt, wie eine solche Auftragsvergabe durchzuführen ist. Insbesondere werden sektorspezifische Anforderungen, die in einschlägigen Rechtsakten festgelegt sind, in einen gemeinsamen Beschaffungsrahmen integriert und umgesetzt und den öffentlichen Auftraggebern in Bezug auf Schlüsselsektoren klare Instrumente an die Hand gegeben, damit hauptsächlich aus europäischen Produkten bestehenden Angeboten Vorrang eingeräumt werden kann. Durch diesen Ansatz werden Kohärenz und Rechtssicherheit sowohl für öffentliche Auftraggeber als auch für Wirtschaftsteilnehmer gewährleistet.

Die vorgeschlagene Verordnung trägt auch den handelspolitischen Schutzinstrumenten der Union Rechnung, einschließlich der kürzlich vorgeschlagenen Maßnahme zur Bewältigung der negativen Auswirkungen globaler Überkapazitäten auf den Stahlmarkt der Union. Darüber hinaus ergänzt sie den bestehenden Rahmen für ausländische Direktinvestitionen, bei dem es um Sicherheit und öffentliche Ordnung geht. Schließlich lässt der Vorschlag die Anwendung der EU-Wettbewerbsvorschriften unberührt.

### 2. RECHTSGRUNDLAGE, SUBSIDIARITÄT UND VERHÄLTNISMÄẞIGKEIT

#### • Rechtsgrundlage

Die geeignete Rechtsgrundlage ist Artikel 114 des Vertrags über die Arbeitsweise der Europäischen Union (im Folgenden „Vertrag“), der es der Union ermöglicht, Harmonisierungsmaßnahmen zu erlassen. In Anbetracht der Komplexität und des transnationalen Charakters der Resilienz und der Dekarbonisierung der Industrie sind solche Maßnahmen erforderlich, um das reibungslose Funktionieren des Binnenmarkts insbesondere für strategische Sektoren sicherzustellen.

Darüber hinaus muss für bestimmte im Rahmen dieser Verordnung eingeführte Maßnahmen Artikel 207 des Vertrags über die gemeinsame Handelspolitik der EU als zusätzliche Rechtsgrundlage herangezogen werden. Die Bestimmungen zu ausländischen Investitionen erstrecken sich auf eine bestimmte Reihe von Sektoren, damit Mindestbedingungen für Investitionen und die Wertschöpfung in der Union gewährleistet werden können. Aus diesem Grund besteht das Ziel dieser Bestimmungen in erster Linie im reibungslosen Funktionieren des Binnenmarkts. Ausländische Direktinvestitionen fallen jedoch ausdrücklich in den Anwendungsbereich der gemeinsamen Handelspolitik der EU.

#### • Subsidiarität (bei nicht ausschließlicher Zuständigkeit)

Wettbewerbsfähigkeit, nachhaltiger Wohlstand, wirtschaftliche Sicherheit und Dekarbonisierung sind für die EU von großer Bedeutung. Die Dekarbonisierung der Industrie kann aufgrund des ganzheitlichen Charakters dieser Herausforderung von keinem Mitgliedstaat allein wirksam bewältigt werden; dazu zählen die Energiemärkte, die Bemühungen zur Eindämmung des Klimawandels und die Notwendigkeit des reibungslosen Funktionierens des Binnenmarkts für energieintensive Industrieprodukte sowie Netto-Null-Technologien. Bei den Herausforderungen für die Wettbewerbsfähigkeit, mit denen die Industrie derzeit konfrontiert ist, besteht die Wahrscheinlichkeit, dass sie die Mitgliedstaaten dazu veranlassen, einseitige Maßnahmen zu ergreifen. Solche Anstrengungen mögen zwar gerechtfertigt sein, aber wenn sie unkoordiniert bleiben, besteht die Gefahr nachteiliger Auswirkungen auf das Funktionieren des Binnenmarkts und einer Fragmentierung des Binnenmarkts, wodurch die EU anfälliger für externe Schocks wird und die Vorteile des Binnenmarkts nicht zum Wohl der lokalen und europäischen Ökosysteme genutzt werden können.

Daher ist nach Artikel 114 AEUV ein harmonisierter Ansatz auf EU-Ebene erforderlich, um das reibungslose Funktionieren des Binnenmarkts zu gewährleisten, die Herausforderungen der Resilienz und der Dekarbonisierung der Industrie zu bewältigen und gleichzeitig die Wettbewerbsfähigkeit der EU zu erhalten. Die in dieser Initiative enthaltenen Maßnahmen wären nicht so wirksam (wenn überhaupt), wenn sie von den Mitgliedstaaten allein umgesetzt würden, da die Herausforderungen, denen sie gelten, den Binnenmarkt betreffen. Sie sind nicht auf einzelne Mitgliedstaaten oder eine Untergruppe von Mitgliedstaaten beschränkt, sondern beziehen sich auf die industrielle Basis der EU und EU-weite Wertschöpfungsketten. Darüber hinaus ist es unwahrscheinlich, dass Maßnahmen allein auf der Ebene der Mitgliedstaaten den Bedürfnissen eng miteinander verflochtener Lieferketten im Binnenmarkt angemessen gerecht werden; auch könnten sie zu einer weiteren Marktfragmentierung und dem Risiko einer Unterbrechung der Lieferketten führen.

Überdies ist der Klimawandel eine grenzüberschreitende Herausforderung, die sowohl Maßnahmen auf internationaler als auch auf EU-Ebene erfordert, um die auf regionaler, nationaler und lokaler Ebene getroffenen Maßnahmen wirksam zu ergänzen und zu verstärken. Die Kosten der Untätigkeit sind europaweit spürbar. Der notwendige industrielle Wandel wird sich auf viele Sektoren in der gesamten EU-Wirtschaft auswirken, weshalb koordinierte Maßnahmen auf EU-Ebene unerlässlich sind, um einen transformativen, gerechten und kosteneffizienten Übergang und eine Aufwärtskonvergenz voranzutreiben. Unkoordinierte nationale Maßnahmen bergen die Gefahr, dass für die Marktteilnehmer unterschiedliche Vorschriften, nicht harmonisierte Verfahren für die Vergabe öffentlicher Aufträge (z. B. im Rahmen der umweltgerechten Vergabe öffentlicher Aufträge) und uneinheitliche Genehmigungsverfahren erlassen werden und letztlich das Funktionieren des Binnenmarkts untergraben wird.

Ohne weitere Maßnahmen der EU dürfte der Status quo fortbestehen, wodurch sich das Risiko erhöht, dass die EU strategische industrielle Kapazitäten und Fähigkeiten verliert, der Binnenmarkt weiter fragmentiert wird und die EU im Hinblick auf Ziele in den Bereichen Umwelt, Digitales, Verteidigung und wirtschaftliche Sicherheit in kritischem Maße von Drittländern abhängig wird. Dies wiederum könnte negative Auswirkungen auf die wirtschaftliche Sicherheit sowie den sozialen und territorialen Zusammenhalt der Union haben, vor allem durch Einflüsse auf die Beschäftigung, die regionale Entwicklung und den gleichberechtigten Zugang zu industriellen Chancen.

Vor diesem Hintergrund sind die vorgeschlagenen Maßnahmen vorrangig auf Bereiche ausgerichtet, in denen aufgrund des Ausmaßes, der Geschwindigkeit und des Umfangs der erforderlichen Anstrengungen ein Tätigwerden auf Unionsebene nachweislich einen Mehrwert bietet – Maßnahmen, die darauf abzielen, das Geschäftsszenario für energieintensive Industrien im Hinblick auf Investitionen in die Dekarbonisierung zu verbessern und die Wettbewerbsfähigkeit strategischer Sektoren und Technologien der EU zu stärken.

Nach Artikel 5 Absatz 3 des Vertrags über die Europäische Union (im Folgenden „EUV“) findet das Subsidiaritätsprinzip in Bereichen Anwendung, die nicht in die ausschließliche Zuständigkeit der Union fallen. In Artikel 3 Absatz 1 Buchstabe e AEUV ist festgelegt, dass die Union im Bereich der gemeinsamen Handelspolitik die ausschließliche Zuständigkeit hat. Artikel 207 Absatz 2 AEUV gehört zur Kategorie der ausschließlichen Zuständigkeit. Daher stellt sich die Frage der Subsidiarität insofern nicht, als Artikel 207 AEUV als zusätzliche Rechtsgrundlage für Maßnahmen zur Durchführung der gemeinsamen Handelspolitik der Union herangezogen wird.

#### • Verhältnismäßigkeit

Die vorgeschlagenen Maßnahmen entsprechen dem Grundsatz der Verhältnismäßigkeit und bieten aufgrund des Ausmaßes, der Dringlichkeit und des Umfangs der erforderlichen Anstrengungen einen nachweisbaren Mehrwert.

Mit den auf die Genehmigung bezogenen Maßnahmen werden die Mitgliedstaaten zur Straffung der Verfahren verpflichtet. Die Digitalisierung der Genehmigungsverfahren wird langfristig zu Zeit- und Kosteneinsparungen sowohl für Behörden als auch für Unternehmen führen und so eine Beschleunigung der umweltfreundlichen Fertigung und ihrer industriellen Einführung in der gesamten EU ermöglichen.

Die Anforderungen in Bezug auf den CO2-Ausstoß und die „Made in EU“-Anforderungen stehen in einem angemessenen Verhältnis zu den industriellen Produktionskapazitäten in Europa und sind so konzipiert, dass sie keine signifikanten Belastungen für die Verwaltungshaushalte der Mitgliedstaaten mit sich bringen. Die Schaffung von Leitmärkten ist von entscheidender Bedeutung für die Steigerung der Wettbewerbsfähigkeit der Schlüsselsektoren und -technologien, wodurch die industrielle Basis der EU gestärkt und die Autonomie in diesen strategischen Sektoren sichergestellt wird.

Verbindliche Bedingungen für ausländische Direktinvestitionen sind erforderlich, damit das Ziel, den Nutzen dieser Investitionen in allen Mitgliedstaaten zu maximieren, die Vorteile des Binnenmarkts zu stärken und den Zugang zum Binnenmarkt wirksam einzusetzen, erreicht werden kann. Dadurch wird sichergestellt, dass Investitionen mit der Entwicklung von Know-how, der Schaffung von Arbeitsplätzen und der Integration der Wertschöpfungskette einhergehen.

Was die Maßnahmen in Bezug auf Beschleunigungsgebiete für die industrielle Fertigung betrifft, so obliegt es den Mitgliedstaaten, solche Gebiete zu ermitteln und auszuweisen, wobei Vorteile geboten werden, die darauf abzielen, bessere und wettbewerbsfähigere Bedingungen für das verarbeitende Gewerbe zu schaffen.

#### • Wahl des Instruments

Eine Verordnung gilt als das am besten geeignete Instrument, da darin Anforderungen festgelegt werden können, die unmittelbar für die nationalen Behörden und die betroffenen Wirtschaftsteilnehmer gelten. Dies wird dazu beitragen, dass die Anforderungen zeitnah und einheitlich umgesetzt werden, was zu mehr Rechtssicherheit führt.

### 3. ERGEBNISSE DER EX-POST-BEWERTUNG, DER KONSULTATION DER INTERESSENTRÄGER UND DER FOLGENABSCHÄTZUNG

#### • Ex-post-Bewertung/Eignungsprüfungen bestehender Rechtsvorschriften

Entfällt.

#### • Konsultation der Interessenträger

Im Einklang mit den Leitlinien für eine bessere Rechtsetzung nahm die Kommission eine umfassende Konsultation der Interessenträger vor, um mithilfe einer Reihe von Methoden, konsultierten Parteien und Instrumenten zuverlässige Informationen zu sammeln. Die Kommission führte mehrere Aktivitäten durch: eine offene Online-Konsultation vom 15. April bis zum 8. Juli 2025 (314 Antworten und 133 beigefügte Positionspapiere), eine Aufforderung zur Stellungnahme für die Folgenabschätzung (295 Antworten), eine gezielte Konsultation, an der Verbände und Unternehmen energieintensiver Industrien teilnehmen konnten (62 Antworten), ein Realitätscheck-Workshop, der Unternehmen energieintensiver Industrien offenstand (40 Teilnehmende), ein Realitätscheck-Workshop zum EU-Gütesiegel für CO2-armen Stahl, der nur Stahlunternehmen offenstand (34 Teilnehmende), ein Realitätscheck-Workshop, der den Mitgliedstaaten (46 Teilnehmende) offenstand und alle drei Realitätschecks umfasste, einschließlich der Möglichkeit, Positionspapiere einzureichen, und eine gezielte Konsultation für das Batterie-Ökosystem und seine nachgelagerten Sektoren (63 Antworten). Die Ergebnisse der öffentlichen Konsultation sind im zusammenfassenden Bericht zusammengefasst, der mit den Antworten auf die Aufforderung zur Stellungnahme auf dem Portal „Ihre Meinung zählt“ veröffentlicht wurde.

Insgesamt führten die Interessenträger als Herausforderungen für die energieintensiven Industrien der EU den Mangel an ausreichend erschwinglichen erneuerbaren Energien, den unlauteren internationalen Wettbewerb, hohe Kapital- und Betriebskosten aufgrund der Dekarbonisierung, die geringe Bereitschaft nachgelagerter Sektoren, Aufpreise für grüne Produkte zu zahlen, komplexe, langwierige Genehmigungsverfahren und Schwierigkeiten beim Zugang zu Finanzmitteln für Dekarbonisierungsvorhaben an.

Für die Idee, Leitmärkte für CO2-arme, in der EU hergestellte Industrieprodukte zu schaffen und zu schützen, erhielt die Kommission breite Unterstützung, da dies ein wichtiger Mechanismus zur Stimulierung der Nachfrage und zur Förderung von Investitionen in die Dekarbonisierung ist. Ebenso waren sich die Interessenträger einig, dass die Schaffung von Leitmärkten dazu dienen wird, die Wettbewerbsfähigkeit der sauberen Technologien und der Automobilindustrie in der EU zu schützen. Sie bestätigten ferner, dass die „Made in EU“-Anforderungen wichtig sind, um sicherzustellen, dass der Markt für Produkte aus CO2-armer Fertigung und sauberen Technologien nicht durch den Wettbewerb außerhalb der EU untergraben wird. Die Mehrheit der Interessenträger aus dem Batteriesektor unterstützte ebenfalls „Made in EU“-Anforderungen in verschiedenen politischen Maßnahmen, sowohl bei der Vergabe öffentlicher Aufträge als auch bei in Verkehr gebrachten Produkten. Die Straffung und Beschleunigung der Genehmigungsverfahren fand große Unterstützung, insbesondere von KMU, die über weniger Ressourcen für die Bewältigung des Verwaltungsaufwands verfügen. Die Interessenträger bewerteten die Bestimmungen für ausländische Investitionen positiv und wiesen darauf hin, dass solche Maßnahmen dringend benötigtes Kapital anziehen und weitere Vorteile mit sich bringen könnten.

#### • Folgenabschätzung

Im Einklang mit den Leitlinien für eine bessere Rechtsetzung stützt sich dieser Verordnungsvorschlag auf eine Folgenabschätzung, in der das Problem und die Teilprobleme analysiert werden, die im Zusammenhang mit der Notwendigkeit stehen, dass die EU-Industrie vor dem globalen Hintergrund der Herausforderungen im Bereich der Wettbewerbsfähigkeit die Dekarbonisierung von Verfahren und Produkten beschleunigt. In der Folgenabschätzung werden mögliche politische Optionen zur Bewältigung von Problemfaktoren ermittelt und deren wahrscheinliche Auswirkungen bewertet. Die Folgenabschätzung wurde so aufgebaut, dass sie die Konsultation der dienststellenübergreifenden Lenkungsgruppe der Kommission zur Verordnung zur industriellen Beschleunigung widerspiegelt.

Der Ausschuss für Regulierungskontrolle gab am 26. September 2025 eine ablehnende Stellungnahme zur Folgenabschätzung ab. Der Ausschuss empfahl,

- · die dynamische Ausgangsbasis auszubauen und das Ausmaß der Verlangsamung der Dekarbonisierungsinvestitionen und das Gefälle bei der Dekarbonisierungsgeschwindigkeit besser zu erläutern,

- · die Analyse der Problemfaktoren, einschließlich der Faktoren im Zusammenhang mit Genehmigungen und ausländischen Direktinvestitionen, zu verbessern und auf dieser Grundlage die allgemeinen und spezifischen Ziele nach der S.M.A.R.T-Methode zu überarbeiten sowie die Maßnahmen zu verbessern,

- · eine eingehendere Analyse der Verfügbarkeit und wirtschaftlichen Tragfähigkeit industrieller Technologien für die Dekarbonisierung und der Nachfrage nach CO2-armen Alternativen, einschließlich Preiselastizität und Substituierbarkeit, durchzuführen,

- · die Kosten-Nutzen-Analyse durch eine bessere Quantifizierung, einschließlich der Verbesserung von Anhang 3, zu verbessern,

- · die Robustheit der Modellierung für die Kosten-Nutzen-Analyse anzuerkennen und über die für die Berechnung verwendeten Annahmen transparent zu berichten.

Alle oben genannten Punkte wurden so weit wie möglich angegangen. Nachdem die überarbeitete Folgenabschätzung erneut vorgelegt wurde, gab der Ausschuss am 20. November 2025 eine befürwortende Stellungnahme mit Vorbehalten ab. In den Vorbehalten wurde darauf hingewiesen, dass die Analyse der erwarteten Auswirkungen des allgemeinen Ziels sowie des Zusammenspiels mit den Auswirkungen auf die wirtschaftliche Sicherheit verbessert werden muss. Ferner wurde festgestellt, dass die Einschränkungen im Zusammenhang mit der Modellierung sowie die Kosten-Nutzen-Berechnungen und die Auswirkungen auf Verbraucher und nachgelagerte Sektoren näher erläutert werden müssen. Auf die Anmerkungen wurde, soweit möglich, im Rahmen einer verbesserten Analyse eingegangen. Die Stellungnahmen des Ausschusses sowie die endgültige Folgenabschätzung und deren Zusammenfassung werden zusammen mit diesem Vorschlag veröffentlicht.

Die Folgenabschätzung stützt sich auf fünf spezifische Ziele, mit denen die ermittelten Problemursachen beseitigt werden sollen. Für jedes spezifische Ziel werden drei politische Optionen auf der Grundlage der Ebene des politischen Eingreifens, des Umfangs, der Effizienz und Kohärenz sowie des Grundsatzes der Verhältnismäßigkeit und des Subsidiaritätsprinzips dargelegt.

Im Rahmen der politischen Option 1 (PO1) ist für alle energieintensiven Sektoren eine Kennzeichnung für die CO2-Intensität vorgesehen. Das Ziel besteht darin, bei der Vergabe öffentlicher Aufträge und für Förderregelungen durch die Einführung von Anforderungen an den CO2-Ausstoß bei energieintensiven Werkstoffen (Stahl, Zement^(19) und Aluminium) in ausgewählten nachgelagerten Sektoren (Automobilindustrie und Bauwesen) Leitmärkte zu schaffen. Ferner wird vorgeschlagen, in Verfahren zur Vergabe öffentlicher Aufträge und öffentlichen Förderregelungen für Batterien, Photovoltaiksysteme und Fahrzeugbauteile „Made in EU“-Mindestanforderungen einzuführen. Im Hinblick auf das Ziel, den Nutzen in Bezug auf ausländische Direktinvestitionen zu maximieren, werden für die Batterielieferkette und möglicherweise für relevante energieintensive Industrien freiwillige Bedingungen für Investitionen oberhalb eines bestimmten Schwellenwerts eingeführt. Zur Straffung der Genehmigungsverfahren wird ein einheitliches digitales Verfahren für alle Genehmigungen vorgeschlagen, das für das gesamte verarbeitende Gewerbe gilt. Zum Schluss wird den Mitgliedstaaten empfohlen, die öffentliche Finanzierung von Projekten in Industriegebieten zu erleichtern.

Die politische Option 2 (PO2) baut auf der ersten Option auf, wobei der Anwendungsbereich und die Anforderungen erweitert werden. Was die Leitmärkte betrifft, so werden im Rahmen der PO2 bei der Vergabe öffentlicher Aufträge und für Förderregelungen Anforderungen an den CO2-Ausstoß und „Made in EU“-Anforderungen für Stahl, Zement und Aluminium eingeführt, die in ausgewählten nachgelagerten Sektoren (Automobilindustrie und Bauwesen) verwendet werden. Die Bedingungen für spezifische Investitionen sind verbindlich und nicht freiwillig. Mit der PO2 wird durch die Einführung zusätzlicher Maßnahmen für energieintensive Industrien die Unterstützung für das Genehmigungsverfahren erhöht. Schließlich werden die Mitgliedstaaten anstatt einer Empfehlung verpflichtet, Industriegebiete auszuweisen. Der Anwendungsbereich der Kennzeichnung wird jedoch dadurch eingeschränkt, dass eine spezifische Kennzeichnung für die CO2-Intensität von Stahl vorgeschrieben wird, die detaillierte Regeln enthält, die später auf andere energieintensive Werkstoffe ausgeweitet werden können.

Mit der politischen Option 3 (PO3) werden die beiden vorstehenden Optionen noch einmal erweitert. Auf den Leitmärkten werden für alle Stahl-, Zement- und Aluminiumerzeugnisse, die zur Verwendung in der Automobilindustrie und im Baugewerbe in Verkehr gebracht werden, Anforderungen an den CO2-Ausstoß und „Made in EU“-Anforderungen eingeführt. Außerdem werden die „Made in EU“-Anforderungen auf alle in Verkehr gebrachten Batterien, Photovoltaiksysteme und wichtigen Fahrzeugbauteile ausgeweitet. In Bezug auf Genehmigungsverfahren werden spezielle Maßnahmen für Industriegebiete eingeführt.

Insgesamt ist die PO2 die bevorzugte Option, da die Ziele durch sie auf die wirksamste und effizienteste Weise erreicht würden. Außerdem hat sie hinsichtlich der Verhältnismäßigkeit positivere Auswirkungen als die beiden anderen Optionen, da darin die Einführung von Anforderungen an den CO2-Ausstoß und „Made in EU“-Anforderungen nur für die Vergabe öffentlicher Aufträge und öffentlicher Unterstützung vorgeschlagen wird, gleichzeitig aber die größte Kohärenz sichergestellt wird. Die PO 2 könnte hauptsächlich mittels Genehmigungsvorschriften (siehe Anhang 4 der Folgenabschätzung) einmalige Nettoreduktionen des Verwaltungsaufwands für Unternehmen um rund 240 Mio. EUR bewirken. Die Kosten-Nutzen-Analyse ergab, dass die PO2 im Jahr 2030 für die Wirtschaft zu einem Nettonutzen von insgesamt rund 8 Mrd. EUR führen wird, obwohl gewisse Anpassungskosten für nachgelagerte Sektoren, die von den Anforderungen an den CO2-Ausstoß und/oder den „Made in EU“-Anforderungen betroffen sind, aufgezeigt wurden. Diese Verluste werden jedoch weitgehend durch langfristige Vorteile in Form von Wertschöpfung, größerer wirtschaftlicher Sicherheit, Resilienz und der Schaffung von Arbeitsplätzen in den strategischen Industriezweigen Europas ausgeglichen, die letztlich für Stabilität und nachhaltigen wirtschaftlichen Wohlstand sorgen. Die PO3 wäre bei der Erreichung bestimmter Ziele, insbesondere in Bezug auf die Bestimmungen über den Leitmarkt, wirksamer, würde jedoch eine unverhältnismäßige Kostensteigerung für die Wirtschaft mit sich bringen.

Unterschiede gegenüber der bevorzugten Option in der Folgenabschätzung

Der Verordnungsvorschlag enthält Maßnahmen, die von der in der Folgenabschätzung vorgestellten bevorzugten politischen Option abweichen, und zwar folgende:

- · Was die Genehmigungsverfahren betrifft, so wurden angesichts der Synergieeffekte, die in Verbindung mit den übrigen Bestimmungen über Beschleunigungsgebiete für die industrielle Fertigung zu erwarten sind, spezifische Maßnahmen für industrielle Fertigungscluster (nämlich die stillschweigende Billigung in Zwischenphasen und die vorrangige Bewertung von Anschlussanträgen) eingeführt, die nicht in der bevorzugten politischen Option enthalten waren.

- · Was den Anwendungsbereich betrifft, so erstrecken sich die Bestimmungen über Verfahren zur Vergabe öffentlicher Aufträge, Auktionen und Förderregelungen auf zusätzliche Netto-Null-Technologien, die in der Folgenabschätzung nicht analysiert wurden. Mit dem Vorschlag werden im Einklang mit dem Ziel, die wirtschaftliche Sicherheit, Resilienz, Nachhaltigkeit und Versorgungssicherheit der EU zu erhöhen, auch „Made in EU“-Anforderungen an Solarthermie, Wärmepumpen, Windkraft, Kernspaltung und Wasserstoff eingeführt. In die Folgenabschätzung wurde hierzu ein eigener Anhang aufgenommen, in dem die wichtigsten Auswirkungen dieser Maßnahmen dargelegt werden. Während Batterien und Photovoltaik schon heute mit einer einzigartigen Kombination aus großen globalen Überkapazitäten und hohen Abhängigkeiten der EU von einzelnen Bezugsquellen konfrontiert sind, sind die anderen betrachteten Netto-Null-Technologien einem intensiven (nicht immer fairen) globalen Wettbewerb ausgesetzt und könnten ähnliche Marktentwicklungen erleben. Daher hat die Kommission die Einführung entsprechender Bestimmungen beschlossen, um potenzielle künftige Versorgungs- und Marktrisiken zu antizipieren und abzumildern.

In Bezug auf Stahl werden die Anforderungen für in der Automobilindustrie und im Baugewerbe verwendeten Stahl im Rahmen der Vergabe öffentlicher Aufträge und von Förderregelungen im Vorschlag auf Kriterien des CO2-Ausstoßes beschränkt (anstatt Anforderungen an den CO2-Ausstoß und den Ursprung in der EU zu kombinieren). Angesichts der kürzlich vorgeschlagenen Handelsmaßnahme zur Eindämmung der negativen handelsbezogenen Auswirkungen globaler Überkapazitäten auf den Stahlmarkt der Union wird die Einführung einer europäischen Präferenz für Stahl nicht für erforderlich erachtet.

- · Für die Zwecke der Einhaltung der Anforderungen an den CO2-Ausstoß gilt Beton als CO2-arm, wenn er die Kriterien für „CO2-armen Beton“ erfüllt, die in den im Rahmen der Bauprodukteverordnung erlassenen Durchführungsmaßnahmen festgelegt sind. Ebenso müssen CO2-arme Stahlerzeugnisse, die im Bauwesen verwendet werden und unter eine harmonisierte technische Spezifikation fallen, der im Rahmen der Bauprodukteverordnung festgelegten Definition des Begriffs „CO2-arm“ entsprechen. Stahlerzeugnisse, die nicht in den Anwendungsbereich der Bauprodukteverordnung fallen, gelten als CO2-arm, wenn sie die Bedingungen für „CO2-armen Stahl“ erfüllen, die in den delegierten Rechtsakten im Rahmen der Ökodesign-Verordnung für nachhaltige Produkte festzulegen sind. Durch diesen Ansatz wird die regulatorische Kohärenz mit den bestehenden produktspezifischen Rechtsvorschriften gewährleistet.

- · Zur Präzisierung des Technologieumfangs enthält der Vorschlag darüber hinaus Änderungen an Artikel 25 der Netto-Null-Industrie-Verordnung über die Vergabe öffentlicher Aufträge, indem nur Technologien einbezogen werden, die üblicherweise öffentlich beschafft werden. Er enthält ferner Änderungen an Artikel 26 der Netto-Null-Industrie-Verordnung, die sich auf Auktionen beziehen. Damit soll der zunehmenden Bedeutung von Auktionen für die Sicherung der Energieversorgung der Union und die Wahrung ihrer technologischen Souveränität Rechnung getragen werden. Der Vorschlag enthält außerdem Änderungen der Artikel 1 und 22 der Bauprodukteverordnung.

- · Der Vorschlag folgt nicht der bevorzugten politischen Option zur Einführung einer freiwilligen Stahlkennzeichnung, mit der Investitionsentscheidungen für CO2-armen Stahl gefördert werden sollen. Stattdessen liegt der Schwerpunkt auf der raschen Umsetzung bestehender Verpflichtungen, z. B. im Rahmen der Ökodesign-Verordnung für nachhaltige Produkte, und auf der Schaffung eines Handelsspielraums, um die Leitmarktbestimmungen durch die Entwicklung freiwilliger Kennzeichnungen für die CO2-armen Leistungsklassen energieintensiver Industrieprodukte zu ergänzen.

All diese Maßnahmen bleiben innerhalb des in der Folgenabschätzung bewerteten Gesamtrahmens und wirken sich nicht wesentlich auf den Vergleich der Optionen aus. Bei sauberen Technologien bedeutet die Ausweitung des Anwendungsbereichs, dass die daraus entstehenden Auswirkungen auf die Strommärkte auch für nachgeschaltete Anwender ein größeres Ausmaß haben könnten. Allerdings gelten auch für andere Netto-Null-Technologien die gleichen Schutzmaßnahme wie diejenigen, die für Batterien und Solarenergie eingehend analysiert wurden.

#### • Effizienz der Rechtsetzung und Vereinfachung

Mit diesem Vorschlag sollen die Auswirkungen von Anforderungen hinsichtlich des Ursprungs in der Union und des c-Ausstoßes sowie von Konditionalitäten für ausländische Direktinvestitionen auf den Verwaltungsaufwand abgemildert werden. Andere Teile, z. B. in Bezug auf Genehmigungsverfahren, bringen für die Wirtschaftsteilnehmer unmittelbar eine Verringerung mit sich.

Die Verwaltungskosten für Unternehmen, die unmittelbar mit dieser Verordnung verbunden sind, dürften durch Effizienzgewinne aufgrund gestraffter Genehmigungsverfahren und langfristige Vorteile im Hinblick auf eine größere Resilienz der Lieferketten ausgeglichen werden. Sie hängen mit Verpflichtungen zum Nachweis der Einhaltung der Bestimmungen über den Leitmarkt für in relevanten nachgelagerten Sektoren tätige Unternehmen zusammen. Was die Konditionalitäten für Investitionen betrifft, so würde die einheitliche Anwendung der Bedingungen in der gesamten Union die Wahl des günstigsten Gerichtsstands und einen Wettlauf nach unten bei der Anziehung ausländischer Investitionen weitgehend verhindern und gleichzeitig die Geschäftsbedingungen harmonisieren und vereinfachen.

Für die Mitgliedstaaten werden zusätzliche Verwaltungskosten im Zusammenhang mit der Überwachung und Umsetzung der Bestimmungen über Leitmärkte bei der Vergabe öffentlicher Aufträge und für Förderregelungen erwartet. Ebenso wird die Umsetzung der Bedingungen für ausländische Investitionen, einschließlich der Festlegung von Vorschriften, der Überwachung und der Verhängung von Sanktionen, zu einer Erhöhung der Verwaltungskosten führen. Auch durch die Genehmigungsvorschriften dürften die Kosten für die Behörden kurzfristig erhöht werden, während Digitalisierung und Vereinfachung andererseits mittel- und langfristig sowohl für die Industrie als auch für die Behörden zu erheblichen Kosten- und Zeiteinsparungen führen werden. Schließlich werden die Ausweisung von Beschleunigungsgebieten sowie die Umsetzung der Vergünstigungen für Industriegebiete mit zusätzlichen Verwaltungskosten für die Mitgliedstaaten verbunden sein, die den Vorteilen für die einzelnen, in den Gebieten tätigen Unternehmen gegenüberstehen.

#### • Grundrechte

Artikel 16 der Charta der Grundrechte der Europäischen Union (im Folgenden „Charta“) sieht die Anerkennung der unternehmerischen Freiheit vor. Die Maßnahmen im Rahmen dieses Vorschlags schaffen Innovationskapazitäten und fördern die Nachfrage nach energieintensiven Industrieerzeugnissen in der Union, wodurch die unternehmerische Freiheit im Einklang mit dem Unionsrecht und den nationalen Rechtsvorschriften und Gepflogenheiten gestärkt werden kann.

### 4. AUSWIRKUNGEN AUF DEN HAUSHALT

Der Vorschlag hat Auswirkungen auf den Haushalt der Kommission. Konkret werden etwa sechs Vollzeitäquivalente pro Jahr für die Umsetzung sowie zusätzliche wiederkehrende Kosten in Höhe von 20 000 EUR pro Abschnitt für die Erweiterung von Anhang 1 der Verordnung über das einheitliche digitale Zugangstor mit den geplanten Genehmigungsbestimmungen und einmalige Kosten in Höhe von 20 000 EUR für Investitionen in das Back-End-System des einheitlichen digitalen Zugangstors erforderlich sein. Um dem breiteren Anwendungsbereich der im Rechtsakt vorgeschlagenen Maßnahmen Rechnung zu tragen, wurden die Zahlen im Vergleich zum Folgenabschätzungsbericht angepasst.

Die Auswirkungen auf den Haushalt bestehen in erster Linie in der Durchführung der Arbeiten, die dafür vorgesehen sind, i) die von den Investitionsbehörden in den Mitgliedstaaten übermittelten Mitteilungen über ausländische Direktinvestitionen zu überprüfen, ii) die Durchsetzung der Verpflichtungen der Mitgliedstaaten in Bezug auf die Bestimmungen über Leitmärkte zu überwachen und iii) die Ausweitung von Anhang II der Verordnung über das einheitliche digitale Zugangstor und des Back-End-System des einheitlichen digitalen Zugangstors zum Zweck der Erfüllung der Genehmigungsbestimmungen umzusetzen.

### 5. WEITERE ANGABEN

#### • Durchführungspläne sowie Monitoring-, Bewertungs- und Berichterstattungsmodalitäten

Die Kommission wird drei Jahre nach Geltungsbeginn der vorgeschlagenen Verordnung die Kohärenz, die Ergebnisse, die Auswirkungen, die Verhältnismäßigkeit und die Subsidiarität bewerten. Nach fünf Jahren wird eine Klausel zur Überprüfung vorgeschlagen, um zu bewerten, ob angesichts der Marktentwicklungen Bestimmungen für Leitmärkte weiterhin erforderlich sind oder ob solche Maßnahmen für andere Sektoren, die für die wirtschaftliche Sicherheit der EU von entscheidender Bedeutung sind, in Betracht gezogen werden sollten. Die vorgeschlagenen Maßnahmen sind als gezielte, zeitlich begrenzte Maßnahmen konzipiert, mit denen der Ausbau der Produktionskapazitäten der Union beschleunigt und die wirtschaftliche Sicherheit nur in strategischen Sektoren erhöht werden soll. Dadurch wird sichergestellt, dass der maßgeschneiderte Ansatz flexibel und evidenzbasiert bleibt und an die sich wandelnden Anforderungen der industriellen Basis Europas angepasst werden kann.

Zur Durchführung der Bewertung stellen die Mitgliedstaaten und die zuständigen nationalen Behörden der Kommission auf deren Ersuchen gegebenenfalls erforderliche, sachdienliche Informationen zur Verfügung.

#### • Ausführliche Erläuterung einzelner Bestimmungen des Vorschlags

In Kapitel I der Verordnung werden die allgemeinen Bestimmungen der Verordnung umrissen, wobei dies deren Gegenstand einschließt, nämlich die Verbesserung des Funktionierens des Binnenmarkts durch die Schaffung eines Rahmens, der den Zugang der Union zu einer sicheren, nachhaltigen und resilienten Versorgung mit relevanten Erzeugnissen des verarbeitenden Gewerbes und ihren Lieferketten sicherstellt; ferner werden der Anwendungsbereich der Verordnung, das Industrialisierungsziel und die für die Zwecke dieser Verordnung erforderlichen Begriffsbestimmungen aufgeführt.

In Kapitel II werden die grundlegenden Voraussetzungen für die industrielle Produktion und die Dekarbonisierung dargelegt. Es enthält Bestimmungen, mit denen gestraffte, effiziente, digitale Genehmigungsverfahren für industrielle Fertigungsprojekte sichergestellt werden. Außerdem werden Bestimmungen über Genehmigungsverfahren für Projekte zur Dekarbonisierung energieintensiver Industrien und Vorhaben für eine klimaneutrale Industrie eingeführt.

In Kapitel III wird ein Rahmen für die Anwendung der Anforderungen an den Ursprung in der Union und den CO2-Ausstoß auf bestimmte Produkte und Dienstleistungen aus strategischen Sektoren im Zusammenhang mit der Vergabe öffentlicher Aufträge und öffentlichen Förderregelungen geschaffen.

Es enthält Anforderungen an CO2-arme Stahlerzeugnisse, Anforderungen an den Ursprung in der Union und Anforderungen an CO2-armen, in bestimmten nachgelagerten Sektoren, d. h. Gebäude, Infrastruktur und Verkehr, verwendeten Beton und Mörtel sowie CO2-armes Aluminium. Ferner werden dort die Anforderungen an den Ursprung in der Union für Fahrzeuge dargelegt. Darüber hinaus wird in diesem Kapitel die Befugnis für die Festlegung nachfrageseitiger Maßnahmen für Erzeugnisse der chemischen Industrie übertragen.

In Kapitel IV wird der Rahmen für die Auferlegung von Bedingungen für ausländische Direktinvestitionen in aufstrebenden strategischen Sektoren mit einem Investitionswert von mehr als 100 Mio. EUR festgelegt. Investitionen dieser Art werden erst dann wirksam, wenn die maßgeblichen Bedingungen vollständig erfüllt sind. Die von den Mitgliedstaaten benannten Investitionsbehörden werden für die Überprüfung und Überwachung der Einhaltung dieser Bedingungen zuständig sein, wobei die Kommission eine koordinierende Rolle spielt.

In Kapitel V wird ein Rahmen für die auf der Grundlage festgelegter Kriterien erfolgende Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung durch die Mitgliedstaaten festgelegt. Mit diesen Gebieten wird der Zweck verfolgt, die Bildung geografischer Cluster für industrielle Tätigkeiten zu erleichtern und günstige Bedingungen für die dort angesiedelten Industriezweige zu fördern. Beschleunigungsgebiete für die industrielle Fertigung werden in Synergie mit anderen Initiativen der Union entwickelt.

In Kapitel VI werden die gemeinsamen Schlussbestimmungen der Verordnung festgelegt, indem Durchführungsbestimmungen, einschließlich Evaluierung, Überwachung, Überprüfung, Ausübung der Befugnisübertragung und Sanktionen, festgelegt werden. Es enthält darüber hinaus Änderungen der Verordnung (EU) 2018/1724 [Verordnung über ein einheitliches digitales Zugangstor], der Verordnung (EU) 2024/1735 [Netto-Null-Industrie-Verordnung], einschließlich Bestimmungen über Ursprungsregeln für Verfahren zur Vergabe öffentlicher Aufträge, Cybersicherheitsanforderungen für die Vergabe öffentlicher Aufträge und strengere Cybersicherheitsbestimmungen für Auktionen und Ursprungsanforderungen für Auktionen und andere Arten der öffentlichen Intervention. Schließlich enthält dieses Kapitel Änderungen der Verordnung (EU) 2024/3110 [Bauprodukteverordnung], um Kohärenz und Synergien mit diesem Vorschlag zu gewährleisten und die Ziele dieses Vorschlags zu unterstützen.

Anhang I enthält die Liste der Sektoren für Beschleunigungsgebiete für die industrielle Fertigung.

In Anhang II werden für bestimmte Erzeugnisse energieintensiver Industrien im Zusammenhang mit Verfahren zur Vergabe öffentlicher Aufträge und öffentlichen Förderregelungen Anforderungen an einen geringen CO2-Gehalt und/oder Anforderungen an den Ursprung in der Union festgelegt.

In Anhang III werden für Verfahren zur Vergabe öffentlicher Aufträge und öffentliche Förderregelungen die Anforderungen an den Ursprung von Fahrzeugen in der Union festgelegt. Außerdem werden die Kriterien festgelegt, nach denen ein kleines emissionsfreies Fahrzeug für die Zwecke von Artikel 5 der Verordnung (EU) 2019/631 als „in der EU hergestellt“ gilt.

Anhang IV enthält die Änderung des Anhangs II der Verordnung (EU) 2018/1724.

(Text von Bedeutung für den EWR)

DAS EUROPÄISCHE PARLAMENT UND DER RAT DER EUROPÄISCHEN UNION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union, insbesondere auf Artikel 114 und Artikel 207 Absatz 2,

auf Vorschlag der Europäischen Kommission,

nach Zuleitung des Entwurfs des Gesetzgebungsakts an die nationalen Parlamente,

nach Stellungnahme des Europäischen Wirtschafts- und Sozialausschusses^(20),

nach Stellungnahme des Ausschusses der Regionen^(21),

gemäß dem ordentlichen Gesetzgebungsverfahren,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Die globale COVID-19-Pandemie, der rechtswidrige und unprovozierte Angriffskrieg Russlands gegen die Ukraine, feindselige wirtschaftliche Handlungen, Cyberangriffe, Einflussnahme aus dem Ausland, die Ausnutzung wirtschaftlicher Abhängigkeiten der Union, die willkürliche Einführung von Handelsmaßnahmen, die zunehmenden Auswirkungen des Klimawandels und die wachsenden geopolitischen Spannungen haben die Schwachstellen der Union offengelegt und stellen eine ernsthafte Bedrohung für die Gesellschaften, Volkswirtschaften und Unternehmen der Union dar. Die wirtschaftliche Sicherheit der Union ist daher untrennbar mit ihrer Fähigkeit verbunden, ihre Resilienz zu stärken und die Risiken, die sich aus wirtschaftlichen Verflechtungen mit feindseligen Drittländern ergeben, zu mindern. Die Union ist entschlossen, ihre wirtschaftliche Sicherheit zu schützen und Bedrohungen für ihre Lieferketten, ihre Infrastruktur und ihre Schlüsseltechnologien sowie den Gefahren, die sich aus der Ausnutzung ihrer wirtschaftlichen Abhängigkeiten ergeben, zu begegnen^(22). Die wirtschaftliche Sicherheit und der soziale Zusammenhalt der Union sind untrennbar mit ihrer Fähigkeit verbunden, ihre Resilienz zu stärken und die Risiken, die sich aus wirtschaftlichen Verflechtungen ergeben, zu mindern. Dies erfordert die Stärkung der Resilienz ihrer Lieferketten sowie den Schutz ihres Binnenmarkts und ihrer industriellen Kapazität bei gleichzeitiger Wahrung des territorialen, sozialen und wirtschaftlichen Zusammenhalts, unter anderem durch die Förderung einer starken, wettbewerbsfähigen industriellen Basis in ausgewählten strategischen Sektoren wie sauberen und digitalen Technologien, energieintensiven Industrien und der Automobilindustrie, damit der Zugang zu strategischen Werkstoffen und Technologien gesichert und hochwertige Arbeitsplätze in der Union erhalten werden.

<a id="rec-2"></a>
(2) In der Europäischen Strategie für wirtschaftliche Sicherheit^(23) und der Mitteilung zur Stärkung der wirtschaftlichen Sicherheit der EU vom 3. Dezember 2025^(24) wird der Weg der Union zur Bewältigung geoökonomischer Spannungen und technologischer Veränderungen klar vorgezeichnet, damit wirtschaftliche Abhängigkeiten in kritischen industriellen Lieferketten, Technologien und Infrastrukturen vermieden werden, die zu lokalen Engpässen führen und die Wettbewerbsfähigkeit, die Wirtschaft und letztlich den sozialen Zusammenhalt der Union bedrohen können.

<a id="rec-3"></a>
(3) Trotz der Ziele der Union in den Bereichen wirtschaftliche Sicherheit, Resilienz, hochwertige Arbeitsplätze und Klimaneutralität sind die Kapazitäten des verarbeitenden Gewerbes in den letzten 20 Jahren zurückgegangen. Der Anteil des verarbeitenden Gewerbes am gesamten BIP ist in der Zeit von 2000 bis 2024 von 17,4 % auf 14,3 % gesunken. Daher ist es notwendig, die wirtschaftliche Resilienz, die Wettbewerbsfähigkeit und die Schaffung von Arbeitsplätzen zu stärken und gleichzeitig sicherzustellen, dass die Klima- und Energieziele der Union erreicht werden. Die Kapazitäten des verarbeitenden Gewerbes sollten bis 2035 mindestens 20 % des Bruttoinlandsprodukts der Union ausmachen. Um zu diesem Ziel beizutragen, sollte die Entwicklung von industriellen Fertigungsprojekten in der Union erleichtert werden.

<a id="rec-4"></a>
(4) Die Herausforderungen, die sich aus der Notwendigkeit einer Dekarbonisierung der Industrie und einer resilienten Industrieproduktion ergeben, sind komplex und reichen über die nationalen Grenzen hinaus. Fragmentierte nationale Maßnahmen zur Bewältigung dieser Herausforderungen könnten das Funktionieren des Binnenmarkts beeinträchtigen. Die von den einzelnen Mitgliedstaaten eingeführten Maßnahmen könnten zu unterschiedlichen Anforderungen an die Marktteilnehmer, uneinheitlichen Beschaffungspraktiken und unterschiedlichen Genehmigungsverfahren in den Mitgliedstaaten führen. Solche Maßnahmen könnten Hindernisse für den grenzüberschreitenden Handel innerhalb der Union und Verzerrungen auf dem Binnenmarkt schaffen, das Vertrauen der Investoren untergraben, die Kosten erhöhen und Investitionsströme innerhalb der Union umlenken. Daher müssen zur Gewährleistung eines reibungslos funktionierenden Binnenmarkts harmonisierte Maßnahmen festgelegt werden.

<a id="rec-5"></a>
(5) Um Rechtssicherheit zu gewährleisten, sollte auf die jüngste Überarbeitung der statistischen Systematik der Wirtschaftszweige in der Europäischen Union (NACE Rev. 2) verwiesen werden. Um die Kohärenz mit den bestehenden Rechtsvorschriften der Union zu gewährleisten und die einheitliche Anwendung dieser Verordnung in der gesamten Union zu ermöglichen, sollten die industrielle Fertigung und die energieintensiven Industrien unter Bezugnahme auf die NACE-Codes^(25) definiert werden.

<a id="rec-6"></a>
(6) Energieintensive Industrien sind eine tragende Säule des Wohlstands in der Union. Sie ermöglichen ein breites Spektrum nachgelagerter Wirtschaftszweige und tragen zur Wirtschaft der Union bei, indem sie Arbeitsplätze schaffen, das Wachstum unterstützen und Innovationen fördern. Allerdings sind sie auch für rund 22,3 % der Treibhausgasemissionen der Union verantwortlich und erfordern erhebliche Investitionen in die Dekarbonisierung, die auch zu einer Verringerung der Umweltverschmutzung führen. Die Kombination aus hohen Energiepreisen, der Notwendigkeit umfangreicher Investitionen in die Dekarbonisierung und unlauterem globalen Wettbewerb führt zu Wettbewerbsnachteilen für energieintensive Industrien; zudem gibt es zunehmend Anzeichen für eine rückläufige industrielle Entwicklung.

<a id="rec-7"></a>
(7) Netto-Null-Technologien sind für die Verwirklichung der Energie- und Klimaziele der Union von entscheidender Bedeutung. Sie spielen eine entscheidende Rolle bei der Senkung der Treibhausgasemissionen und der Ermöglichung der Dekarbonisierung eines breiten Spektrums von Wirtschaftszweigen, einschließlich des Baugewerbes, des Verkehrs und der Industrie. Sie spielen zudem eine entscheidende Rolle bei der Förderung nachhaltiger Energielösungen, indem sie die Dekarbonisierung der Energieversorgung ermöglichen und innovative Lösungen bereitstellen, um den erforderlichen Ausbau und die notwendige Digitalisierung der Stromnetze und des Energiesystems insgesamt zu ermöglichen. Der Sektor für die Fertigung von Netto-Null-Technologien in der Union steht jedoch vor erheblichen Herausforderungen, darunter zunehmender globaler Wettbewerbsdruck und Schwachstellen in der Lieferkette, die die Wettbewerbsfähigkeit und wirtschaftliche Resilienz der Union gefährden.

<a id="rec-8"></a>
(8) Die Bioökonomie ist in der Lage, nachhaltige Biomasse und biobasierte Lösungen für die industrielle Produktion bereitzustellen. In der Mitteilung der Kommission mit dem Titel „Ein strategischer Rahmen für eine wettbewerbsfähige und nachhaltige Bioökonomie in der EU“^(26) werden Leitmärkte wie die Märkte für biobasierte Kunststoffe und Polymere, biobasierte Chemikalien und biobasierte Bauprodukte sowie Leittechnologien genannt, die die strategische Autonomie der Union und die Dekarbonisierung der in dieser Initiative genannten Industriezweige unterstützen können.

<a id="rec-9"></a>
(9) Die Automobilindustrie ist eine tragende Säule der Wirtschaft der Union. Um die klimapolitischen Ziele der Union zu erreichen, hat die europäische Automobilindustrie in den letzten Jahren massiv in die Entwicklung saubererer Fahrzeuge und innovativer Bauteile investiert. Elektrofahrzeuge und Bauteile von Elektrofahrzeugen, darunter Antriebsbatterien, Bauteile des elektrischen Antriebsstrangs und elektronische Systeme, sind wesentliche Technologien, um die Dekarbonisierung des Straßenverkehrs voranzubringen. Infolge des Kostennachteils und des Wandels der Wertschöpfungskette mit einem steigenden Wertanteil für Batterien, Bauteile des elektrischen Antriebsstrangs und Elektronik geht der Unionsanteil an den in der Union hergestellten Fahrzeugen jedoch zurück. Wirksame Maßnahmen können nicht länger aufgeschoben werden, wenn die Gefahr einer Verlagerung der lokalen Erzeugung vermieden werden soll. Ohne solche Maßnahmen würden die derzeitigen Umstände dazu führen, dass bei wichtigen Fahrzeugbauteilen in vollem Umfang auf Drittländer zurückgegriffen werden muss. Dadurch würden die wirtschaftliche Sicherheit und die künftige Resilienz der Union sowie ihre Klimaziele ernsthaft bedroht.

<a id="rec-10"></a>
(10) Die Unvorhersehbarkeit, Komplexität und zuweilen übermäßig lange Dauer nationaler Genehmigungsverfahren beeinträchtigen die Kosteneffizienz der für die Entwicklung industrieller Tätigkeiten erforderlichen Investitionen. Um die wirksame Durchführung industrieller Fertigungstätigkeiten sicherzustellen und zu beschleunigen, sollten die Mitgliedstaaten daher gestraffte und digitalisierte Genehmigungsverfahren anwenden. Eine zuständige Behörde sollte sämtliche Genehmigungsverfahren koordinieren und innerhalb der geltenden Frist eine umfassende Entscheidung treffen.

<a id="rec-11"></a>
(11) Die Einrichtung zentraler Zugangsstellen sollte auf der Grundlage der europäischen Unternehmensbrieftaschen erfolgen, die gemäß dem [Vorschlag für eine Verordnung über die Einrichtung europäischer Unternehmensbrieftaschen^(27)] eingerichtet wurden, da sie Unternehmen eine sichere, standardisierte und interoperable Plattform für die Interaktion mit öffentlichen Stellen bieten. Damit sollte die effiziente und wirksame Einreichung von Anträgen ermöglicht und zugleich ein hohes Maß an Datenschutz, Cybersicherheit und Integrität der Informationen gewährleistet werden. Die europäischen Unternehmensbrieftaschen werden auch die Straffung der getätigten Investitionen und die Vermeidung unnötiger Doppelarbeit ermöglichen, sodass Ressourcen optimal eingesetzt werden können und der Verwaltungsaufwand für Unternehmen verringert werden kann. Bei der Einrichtung zentraler Zugangsstellen sollten so weit wie möglich auch bestehende digitale Infrastrukturen, Kataloge und Bausteine der Union genutzt werden, einschließlich derjenigen, die im Rahmen des technischen Systems zur einmaligen Erfassung und seiner Durchführungsrechtsakte entwickelt wurden. Auf diese Weise werden Komplementarität, Interoperabilität und die effiziente Nutzung öffentlicher Mittel gefördert, während gleichzeitig Überschneidungen mit bestehenden digitalen Lösungen vermieden werden.

<a id="rec-12"></a>
(12) Zur Gewährleistung gestraffter und vereinfachter Genehmigungsverfahren sollte für alle industriellen Fertigungsprojekte mit Ausnahme des verarbeitenden Gewerbes im Rahmen des C12-Codes ein einziger Antrag gestellt werden, der alle erforderlichen Genehmigungen abdeckt. Dies sollte nicht gelten, wenn in Harmonisierungsrechtsvorschriften der Union für industrielle Fertigungsprojekte, beispielsweise Vorschriften gemäß den Verordnungen (EU) 2024/1735^(28) und (EU) 2024/1252^(29) des Europäischen Parlaments und des Rates, spezifische Genehmigungs- oder Lizenzverfahren oder Anforderungen festgelegt sind. Die sektoralen Rechtsvorschriften der Union für Arzneimittel und Medizinprodukte wurden kürzlich einer weiteren Straffung der harmonisierten Vorschriften und Fristen für Zulassungen und Zertifizierungen unterzogen oder befinden sich derzeit in diesem Prozess, wobei bei Bedarf Möglichkeiten zur Beschleunigung des Verfahrens bestehen. Diese Vorschriften sollten daher im Rahmen dieser Initiative nicht als Genehmigungsverfahren betrachtet werden.

<a id="rec-13"></a>
(13) Mit der Verordnung (EU) [202X/XX] vom […]^(30) wird ein gemeinsamer Rahmen für die Beschleunigung von Umweltprüfungen geschaffen, um die Einführung von Schlüsseltechnologien in der Union anzukurbeln, Abhängigkeiten zu verringern und die Wettbewerbsfähigkeit zu stärken. In allen Wirtschaftszweigen sollten die Verfahren im Zusammenhang mit Umweltprüfungen für Pläne, Programme und Projekte beschleunigt und gestrafft werden, wobei gleichzeitig ein hohes Schutzniveau für die menschliche Gesundheit und die Umwelt aufrechterhalten werden sollte. In einigen Sektoren können jedoch noch schnellere Umweltprüfungen erforderlich sein. Um die Kohärenz des Rechtsrahmens für Umweltprüfungen zu gewährleisten und gleichzeitig dem zusätzlichen Beschleunigungsbedarf in bestimmten strategischen Sektoren Rechnung zu tragen, wird mit der Verordnung (EU) [202X/XX] ein spezielles Instrumentarium bereitgestellt, das im Rahmen der vorliegenden Verordnung genutzt werden sollte. Angesichts ihrer wesentlichen Rolle bei der Verwirklichung der Klimaziele der Union und ihres Beitrags zur Resilienz und wirtschaftlichen Sicherheit der Union sollten Projekte zur Dekarbonisierung energieintensiver Industrien, industrielle Fertigungsprojekte in Beschleunigungsgebieten für die industrielle Fertigung und Projekte für Netto-Null-Technologien als strategische Projekte im Sinne der Verordnung (EU) [202X/XX] betrachtet werden und daher von dem mit der genannten Verordnung eingerichteten speziellen Instrumentarium profitieren.

<a id="rec-14"></a>
(14) Die Verordnung (EU) 2024/1735 enthält Bestimmungen zur Straffung der Verwaltungs- und Genehmigungsverfahren für Projekte zur Fertigung von Netto-Null-Technologien. Einige spezifische Bauteile in der Lieferkette von Netto-Null-Technologien werden mittels energieintensiver Herstellungsprozesse produziert. Projekte zur Dekarbonisierung energieintensiver Industrien fallen in den Anwendungsbereich der Verordnung (EU) 2024/1735, wenn in den betreffenden Anlagen Bauteile hergestellt werden, die Teil der Lieferkette einer Netto-Null-Technologie sind. Energieintensive Anlagen, in denen keine in Netto-Null-Technologien verwendeten Bauteile hergestellt werden, sind derzeit jedoch vom Anwendungsbereich der Verordnung (EU) 2024/1735 ausgenommen. Dies birgt das Risiko uneinheitlicher Bedingungen zwischen energieintensiven Industrien und verlangsamt die Dekarbonisierungsanstrengungen. Daher sollten alle Projekte zur Dekarbonisierung energieintensiver Industrien denselben Genehmigungsverfahren unterliegen.

<a id="rec-15"></a>
(15) Die Union sollte einen stärker strategisch ausgerichteten Ansatz verfolgen, indem sie ihr wirtschaftliches Gewicht und den Wert des Zugangs zu ihrem Binnenmarkt nutzt. In diesem Zusammenhang ist der strategische Einsatz öffentlicher Interventionen von entscheidender Bedeutung, damit kritische Abhängigkeiten in der Union verhindert werden. Die Vergabe öffentlicher Aufträge hat ein Volumen von 15 % des BIP der Union. Öffentliche Auftraggeber und Auftraggeber sollten daher gegebenenfalls sicherstellen, dass die wirtschaftliche Sicherheit und Resilienz der Lieferketten durch die Anforderungen an die Vergabe öffentlicher Aufträge gefördert werden. Öffentliche Förderregelungen spielen ebenfalls eine wichtige Rolle bei der Ankurbelung der Nachfrage in nachgelagerten Sektoren, auf die ein erheblicher Anteil der Nachfrage nach bestimmten strategischen Produkten und Technologien entfällt. Begünstigte, die einen größeren Beitrag zur Stärkung der Resilienz der Union und zur Förderung ihrer Dekarbonisierungsziele leisten, sollten daher im Rahmen solcher Regelungen eine bevorzugte Behandlung erhalten. Auktionen sind für die Einführung von Netto-Null-Technologien von entscheidender Bedeutung und sollten so konzipiert sein, dass die Nachfrage nach solchen Technologien, einschließlich Bauteilen aus der Union, gefördert wird.

<a id="rec-16"></a>
(16) Die Union und die Mitgliedstaaten verfügen über ein offenes Investitionsumfeld, das im Vertrag über die Arbeitsweise der Europäischen Union (AEUV) verankert und fester Bestandteil ihrer internationalen Verpflichtungen ist. Zu ihnen zählen Verpflichtungen im Rahmen des Übereinkommens der Welthandelsorganisation über das öffentliche Beschaffungswesen (Government Procurement Agreement, GPA)^(31) sowie bilaterale Handelsabkommen, mit denen Verfahren zur Vergabe öffentlicher Aufträge und andere Formen der öffentlichen Intervention geöffnet werden. Gleichzeitig behält sich die Union das Recht vor, allgemeine oder sicherheitsbezogene Ausnahmen anzuwenden. Die Kommission wird regelmäßig prüfen, ob die Bedingungen für den Ausschluss eines Drittlands aus dem Anwendungsbereich der Bestimmungen, nach denen Inhalte mit Ursprung in Drittländern als gleichwertig mit dem Ursprung in der Union angesehen werden, erfüllt sind, und wird geeignete Maßnahmen ergreifen. Das Ziel der wirtschaftlichen Sicherheit besteht im Schutz und in der Stärkung des Binnenmarkts. Mitgliedstaaten können sich nicht auf die wirtschaftliche Sicherheit berufen, um Investitionen aus anderen Mitgliedstaaten zu unterbinden, an Bedingungen zu knüpfen oder anderweitig zu behindern.

<a id="rec-17"></a>
(17) Die schrittweise Integration der Bewerberländer und potenziellen Bewerberländer in den Binnenmarkt der Union, unter anderem durch ihre stufenweise Beteiligung an der Politik und den Programmen der Union, ist von entscheidender Bedeutung für die Unterstützung ihrer Angleichung an den Besitzstand, die Stärkung ihrer Wettbewerbsfähigkeit, die Förderung ihrer verstärkten Integration in die Wertschöpfungsketten der Union und die Erhöhung der wirtschaftlichen Sicherheit der Union. Diese Verordnung sollte daher dazu beitragen, eine solche schrittweise Integration unter anderem durch die Erleichterung der Teilnahme von Wirtschaftsteilnehmern aus diesen Ländern an unionsweiten Wertschöpfungsketten, an der Vergabe öffentlicher Aufträge der Union sowie an öffentlichen Förderregelungen und Auktionen zu fördern, wo dies angemessen ist und mit den Interessen und Zielen der Union im Einklang steht.

<a id="rec-18"></a>
(18) In Anerkennung der Bedeutung der Fortschritte der Union auf dem Weg zu einer größeren strategischen Autonomie und Resilienz sollte die Union aus Gründen der Kohärenz auch die proaktiven Bemühungen der Partnerländer zur Priorisierung der inländischen Beteiligung an Wirtschaftstätigkeiten, die ähnlich wie die in dieser Verordnung festgelegten Maßnahmen gestaltet sind, anerkennen. Im Zusammenhang mit der Umsetzung der Anforderungen an den Ursprung in der Union innerhalb bestimmter Kategorien öffentlicher Vergabeverfahren und öffentlicher Förderregelungen sollte die Union die inhaltlichen Bedingungen der Partnerländer für strategische, von der Union finanzierte oder unterstützte Investitionen in diesen Partnerländern sorgfältig prüfen und ihr Bestehen akzeptieren. Dieser strategische Ansatz dürfte den beiderseitigen wirtschaftlichen Nutzen steigern, strategische Partnerschaften stärken und mit den übergeordneten Zielen der Union in Bezug auf internationale Partnerschaften in Einklang stehen.

<a id="rec-19"></a>
(19) Wo dies angemessen ist, sollte der Schwerpunkt nachfrageseitiger Maßnahmen auf der Festlegung von Anforderungen an den CO2-Ausstoß in Gebäuden, Infrastrukturen und Kraftfahrzeugen verwendetem Stahl, Zement und Aluminium liegen, da es sich bei diesen Sektoren um die energieintensivsten Industrien handelt. Gezielte unionsweite nachfrageseitige Maßnahmen können dazu beitragen, Leitmärkte für CO2-arme, in der Union hergestellte energieintensive Industrieprodukte zu schaffen und auf diese Weise die Dekarbonisierung unterstützen und zugleich die industrielle Basis der Union stärken.

<a id="rec-20"></a>
(20) Nachgelagerte Sektoren wie das Baugewerbe und die Automobilindustrie, auf die ein großer Teil der Nachfrage nach bestimmten energieintensiven Materialien entfällt, sollten im Rahmen dieser Verordnung bei der Festlegung von Anforderungen an den CO2-Ausstoß, Anforderungen an den Ursprung in der Union oder beidem Vorrang erhalten. Dies ist insbesondere aus dem Grund angemessen, dass diese Sektoren in erheblichem Maße öffentlichen Beschaffungs- und Förderregelungen unterliegen, während der Anteil energieintensiver Inputs am gesamten Herstellungswert relativ gering ist und daher die Auswirkungen etwaiger Preisaufschläge minimal sind.

<a id="rec-21"></a>
(21) Um die regulatorische Kohärenz mit den bestehenden Produktvorschriften der Union sicherzustellen, sollten Stahl, Beton und Aluminium für den Einsatz im Bauwesen im Einklang mit den Anforderungen, die in den gemäß den Verordnungen (EU) 2024/3110^(32) und (EU) 2024/1781^(33) des Europäischen Parlaments und des Rates erlassenen Durchführungsmaßnahmen festgelegt sind, als CO2-arm angesehen werden.

<a id="rec-22"></a>
(22) In der Mitteilung über den Deal für eine saubere Industrie^(34) wurde hervorgehoben, dass Leitmärkte für Industrieprodukte mit niedriger Treibhausgasemissionsintensität geschaffen werden müssen, unter anderem durch die Förderung solcher Produkte auf dem Binnenmarkt mittels Einführung eines Kennzeichnungssystems der Union, bei dem der Stahlsektor den Anfang machen soll. Dies sollte im Zusammenhang mit den Produktvorschriften der Union gesehen werden, in denen bereits Kennzeichnungs- und Informationsanforderungen vorgesehen sind, zu denen auch umfassende, im Rahmen der delegierten Rechtsakte gemäß den Verordnungen (EU) 2024/3110 und (EU) 2024/1781 festzulegende Anforderungen an die Produktkennzeichnung zählen. Angesichts der Bedeutung, die sowohl die Primär- als auch die Sekundärstahlerzeugung für die langfristige Widerstandsfähigkeit der industriellen Basis der Union hat, sollten diese Anforderungen auf Leistungsklassen beruhen, in denen die in verschiedenen Technologiepfaden verfolgten unterschiedlichen Anstrengungen zur Dekarbonisierung berücksichtigt werden, wobei auch die Kreislauffähigkeit belohnt wird und erforderlichenfalls die Schwellenwerte für die Emissionsintensität auf der Grundlage des Prozentsatzes des bei der Produktion verwendeten Metallschrotts für diejenigen Produktkategorien angepasst werden, für die in der Regel die Primärstahlerzeugung erforderlich ist. Für Industrieprodukte, die noch nicht durch einen delegierten Rechtsakt gemäß der Verordnung (EU) 2024/1781 geregelt sind oder noch nicht in dem gemäß der genannten Verordnung angenommenen Arbeitsplan enthalten sind, sollte auch die Möglichkeit bestehen, die gemäß den Verordnungen (EU) 2024/3110 und (EU) 2024/1781 erlassenen delegierten Rechtsakte zu ergänzen, um die Schaffung von Leitmärkten dadurch zu unterstützen, dass Informationen für Investitionsentscheidungen zugunsten von Produkten, denen eine niedrigere Leistungsklasse für die Treibhausgasintensität gewährt wird, bereitgestellt werden. Zu diesem Zweck sollte es möglich sein, freiwillige Klassifizierungssysteme auf der Grundlage der Treibhausgasintensität von Industrieprodukten einzurichten. Um die ökologische Integrität und administrative Machbarkeit zu gewährleisten, ist es wichtig, sich auf bewährte und überwachte Methoden der Emissionserfassung zu stützen. Für inländische Anlagen und Anlagenteile enthält das EU-Emissionshandelssystem (EU-EHS) in Anhang I der Delegierten Verordnung (EU) 2019/331 der Kommission^(35) relevante Produkt-Benchmarks und Systemgrenzen, und in der Durchführungsverordnung (EU) 2018/2066 der Kommission^(36) sind solide Vorschriften für die Emissionserfassung enthalten. Zur Begrenzung des Verwaltungsaufwands für eingeführte Produkte sollte die Verwendung von Daten ermöglicht werden, die bereits im Rahmen des CO2-Grenzausgleichssystems (CBAM) im Einklang mit den gemäß Artikel 7 Absatz 7 Buchstabe a der Verordnung (EU) 2023/956 des Europäischen Parlaments und des Rates^(37) erlassenen Durchführungsbestimmungen überprüft wurden. Um die Treibhausgasintensität eines Industrieprodukts genau widerzuspiegeln, sollten neben den direkten Emissionen, die in der Regel mit den in Anhang I der Richtlinie 2003/87/EG des Europäischen Parlaments und des Rates^(38) genannten Aktivitäten der Anlage verbunden sind, auch die wichtigsten Quellen indirekter Emissionen berücksichtigt werden, einschließlich der Emissionen aus der Erzeugung von Strom, Wasserstoff und Wärme, die im Fertigungsprozess verwendet werden. Zur Sicherstellung der Kohärenz und zur Begrenzung des Verwaltungsaufwands sollten bei den Methoden zur Festlegung der Anforderungen an den CO2-Ausstoß im Rahmen dieser Verordnung die im Rahmen des EU-EHS und des CBAM gemeldeten Emissionsdaten genutzt werden, soweit diese verfügbar und relevant sind.

<a id="rec-23"></a>
(23) Um die Verwirklichung der Ziele dieser Verordnung, insbesondere die Schaffung von Leitmärkten für europäische CO2-arme Industrieprodukte, zu gewährleisten, sollten in Verfahren zur Vergabe öffentlicher Aufträge verbindliche technische Mindestspezifikationen für Anforderungen an den CO2-Ausstoß und den Ursprung in der Union festgelegt werden. Diese Anforderungen sollten für die Beschaffung solcher Produkte im Rahmen öffentlicher Lieferaufträge sowie öffentlicher Bauaufträge, Dienstleistungsaufträge und Konzessionen gelten, wenn diese Produkte für im Rahmen dieser Aufträge durchgeführte Tätigkeiten verwendet werden. Im Einklang mit dem Rahmen für die Vergabe öffentlicher Aufträge sollte bei diesen verbindlichen technischen Mindestspezifikationen vermieden werden, dass der Wettbewerb künstlich eingeschränkt wird und bestimmte Wirtschaftsteilnehmer begünstigt werden. Öffentliche Auftraggeber und Auftraggeber sollten die Verfahren zur Vergabe öffentlicher Aufträge im Einklang mit den Richtlinien 2014/23/EU^(39), 2014/24/EU^(40) und 2014/25/EU^(41) des Europäischen Parlaments und des Rates und den geltenden sektoralen Rechtsvorschriften durchführen. Der Ursprung von Produkten und Bauteilen in der Union sollte im Einklang mit den zollrechtlichen Vorschriften der Union bestimmt werden.

<a id="rec-24"></a>
(24) Um die Durchführbarkeit der Anforderungen zu vertretbaren Kosten sicherzustellen und eine Einschränkung des Wettbewerbs zu vermeiden, müssen die Bedingungen festgelegt werden, unter denen öffentliche Auftraggeber in Ausnahmefällen beschließen können, die Anforderungen an den CO2-Ausstoß und den Ursprung in der Union nicht anzuwenden. Diese Bedingungen sollten sich auf Fälle erstrecken, in denen die Anwendung solcher Anforderungen zu technischen Unvereinbarkeiten beim Betrieb oder bei der Instandhaltung eines Projekts führen würde, beispielsweise Situationen, in denen die Verwendung der betreffenden Produkte die Erfüllung der in der Verordnung (EU) 2024/3110 festgelegten grundlegenden Anforderungen an Bauwerke im Bereich von Gebäuden oder der Infrastruktur gefährden würde. Die in dieser Verordnung festgelegten Anforderungen sollten ausschließlich für Vergabeverfahren gelten, die in den Anwendungsbereich der Richtlinien 2014/23/EU, 2014/24/EU und 2014/25/EU fallen, d. h. für Verfahren, deren geschätzter Wert die in diesen Richtlinien festgelegten Schwellenwerte erreicht oder überschreitet. Dementsprechend sollten für Vergabeverfahren, die nicht unter diese Richtlinien fallen, einschließlich solcher Vergabeverfahren, die unter den geltenden Schwellenwerten liegen, die in dieser Verordnung festgelegten Anforderungen nicht gelten, sodass für die Vergabe von Aufträgen von geringem Wert, die von öffentlichen Auftraggebern, auch auf lokaler Ebene, durchgeführt werden, unverhältnismäßige Verpflichtungen vermieden werden.

<a id="rec-25"></a>
(25) Das am 16. Dezember 2025 angenommene Automobilpaket enthält einen Vorschlag zur Änderung der Verordnung (EU) 2019/631 des Europäischen Parlaments und des Rates^(42), in dem unter anderem die Gewährung von Begünstigungen für kleine, bezahlbare Elektrofahrzeuge vorgesehen ist, die vor 2035 in der Union hergestellt wurden, und mit dem das Emissionsreduktionsziel für 2035 geändert wird, wobei die verbleibenden Emissionen durch die Verwendung von in der Union hergestelltem CO2-armem Stahl oder erneuerbaren, CO2-armen Kraftstoffen ausgeglichen werden sollen. Das Automobilpaket umfasst auch einen [Vorschlag für eine Verordnung über saubere Unternehmensfahrzeuge], mit dem die finanzielle Unterstützung für Unternehmensfahrzeuge auf emissionsfreie und emissionsarme „in der Europäischen Union hergestellte“ Unternehmensfahrzeuge beschränkt wird. Um Rechtssicherheit und Kohärenz mit der Verordnung (EU) 2019/631 in der geänderten Fassung und dem [Vorschlag für eine Verordnung über saubere Unternehmensfahrzeuge] zu gewährleisten, sollten in dieser Verordnung Begriffsbestimmungen für „in der Union hergestellte kleine, bezahlbare Elektrofahrzeuge“, „in der Union hergestellter CO2-armer Stahl“ und „in der Europäischen Union hergestellte Personenkraftwagen und leichte Nutzfahrzeuge für Unternehmen“ festgelegt werden.

<a id="rec-26"></a>
(26) Um die Verfahren zu vereinfachen und den Verwaltungsaufwand zu verringern, sollte die Überprüfung der Einhaltung der in dieser Verordnung festgelegten Anforderungen keine unverhältnismäßige Belastung für Wirtschaftsteilnehmer oder öffentliche Auftraggeber darstellen. Das Überprüfungssystem sollte daher auf einer Eigenerklärung der Wirtschaftsteilnehmer beruhen. Ein solcher Ansatz steht im Einklang mit dem durch die Richtlinie 2014/24/EU geschaffenen allgemeinen Rahmen für die Vergabe öffentlicher Aufträge, insbesondere mit deren Artikel 59, in dem eine Eigenerklärung über die Einhaltung der Vorschriften vorbehaltlich einer späteren Überprüfung des erfolgreichen Bieters vorgesehen ist. Für Fahrzeuge sollten die Hersteller zum Zeitpunkt der Ausstellung der Übereinstimmungsbescheinigung gemäß der Verordnung (EU) 2018/858 des Europäischen Parlaments und des Rates^(43) ein Begleitdokument vorlegen, in dem für die Fahrzeuge bescheinigt wird, dass sie die einschlägigen Anforderungen in Bezug auf den Ursprung in der Union erfüllen. Dieses Dokument sollte einer Eigenerklärung gleichwertig sein und Teil der Unterlagen zum Nachweis der Einhaltung der in dieser Verordnung festgelegten Anforderungen sein.

<a id="rec-27"></a>
(27) Um sicherzustellen, dass die in dieser Verordnung festgelegten Anforderungen auch dann noch angemessen sind, wenn sich die Marktbedingungen, die technologischen Entwicklungen und die klima- und binnenmarktpolitischen Ziele der Union weiterentwickeln, sollte der Kommission die Befugnis übertragen werden, die Anforderungen auf der Grundlage objektiver Kriterien und der Überwachungsergebnisse zu überarbeiten. Bei der Bewertung, ob die Anforderungen hinsichtlich des Ursprungs in der Union, des CO2-Ausstoßes oder beidem überarbeitet werden sollen, sollte die Kommission die Entwicklungen in den einschlägigen Rechtsrahmen berücksichtigen, einschließlich der zollrechtlichen Vorschriften über Ursprungsregeln, des Emissionshandelssystems gemäß der Richtlinie 2003/87/EG, des CO2-Grenzausgleichssystems gemäß der Verordnung (EU) 2023/956 und der handelspolitischen Schutzinstrumente.

<a id="rec-28"></a>
(28) Investitionen, auch von ausländischen Einrichtungen, spielen eine entscheidende Rolle bei der Förderung eines starken Binnenmarkts und des territorialen Zusammenhalts, insbesondere durch die Förderung von Innovation und die Ankurbelung des Wirtschaftswachstums in der Union, die für ihre Wettbewerbsfähigkeit von wesentlicher Bedeutung sind. Unter außergewöhnlichen Umständen besteht jedoch die Gefahr, dass insbesondere große Investitionen aus Drittländern, die eine sehr bedeutende Marktposition in der weltweiten Fertigungskapazität innehaben, zu Störungen bei wichtigen Lieferketten und der Sicherheit aufstrebender strategischer Sektoren, die für die Entwicklung des Binnenmarkts von besonderer Bedeutung sind, führen. Unterschiedliche von den Mitgliedstaaten für solche Investitionen angewendete Bedingungen führen zu einer Fragmentierung des Binnenmarkts, indem ungleiche Bedingungen für Investoren geschaffen werden, die Investitionen ohne echten Mehrwert für die Wirtschaft der Union zulassen, während gleichzeitig ein erhebliches Risiko für die Entwicklung und die Versorgungssicherheit in diesen Sektoren entsteht und ein Anreiz für „Aufsichtsarbitrage“ durch Investoren geschaffen wird. Wenn solche Investitionen ohne Bedingungen getätigt werden dürfen, könnte dies bedeuten, dass die Schaffung von Mehrwert im Zusammenhang mit ausgewählten strategischen Technologien und innovativen Fertigungstätigkeiten außerhalb der Union verbleibt, was sich nachteilig auf die Versorgungssicherheit und die technologische Entwicklung der Union in aufstrebenden strategischen Sektoren auswirkt. Wird der Binnenmarkt bedingungslos solchen umfangreichen Investitionen ausgesetzt, besteht darüber hinaus die Gefahr, dass der für den grünen und den digitalen Wandel und die Verteidigungsfähigkeiten erforderliche technologische Fortschritt der Union infrage gestellt wird. Daher sollte mit den Bestimmungen dieser Verordnung sichergestellt werden, dass solche umfangreichen Investitionen aus Drittländern, die eine besonders bedeutende Marktposition innehaben, nicht zu Störungen der Sicherheit der Versorgung und allgemein der Wirtschaft in der Union führen und dass sie deren technologischen Fortschritt in aufstrebenden strategischen Sektoren sicherstellen. Wird durch solche Investitionen keine ausreichende Beteiligung der Union und kein ausreichender Technologietransfer sichergestellt, beeinträchtigt dies aufgrund des Mangels an unionsinternen Kapazitäten, die von dem Land, in dessen Besitz sich ein erheblicher Anteil der relevanten weltweiten Versorgung befindet, unabhängig sind, die langfristige Versorgungssicherheit aufstrebender strategischer Sektoren. Darüber hinaus wurde festgestellt, dass einige dieser Investitionen keine sinnvolle Beschäftigung von Arbeitnehmern aus der Union beinhalten; dadurch wird die Entwicklung von Kompetenzen, die für die Entwicklung aufstrebender strategischer Sektoren im Binnenmarkt von entscheidender Bedeutung sind, beeinträchtigt.

<a id="rec-29"></a>
(29) Um sicherzustellen, dass der Binnenmarkt für Investitionen attraktiv bleibt und Investitionen einen Mehrwert für die Wirtschaft und die Gesellschaft der Union schaffen, müssen gemeinsame Bedingungen für ausländische Direktinvestitionen in aufstrebende strategische Sektoren des verarbeitenden Gewerbes geschaffen werden. Hierbei sollte es sich um Sektoren des verarbeitenden Gewerbes handeln, die sich durch Innovationspotenzial auszeichnen, bei denen die Einrichtungen der Union nicht an der globalen Innovationsspitze stehen oder sich dieser annähern und in denen eine angemessene Kapazität und Beteiligung der Union gewährleistet werden sollte. Für ausländische Investoren aus einem Drittland, das mehr als 40 % der weltweiten Fertigungskapazitäten in aufstrebenden strategischen Sektoren besitzt, sollten harmonisierte Kriterien gelten. Um die Wirksamkeit der Bestimmungen dieser Verordnung zu gewährleisten, sollte die Kommission die globale Fertigungskapazität dieser Sektoren überwachen und die Ergebnisse veröffentlichen.

<a id="rec-30"></a>
(30) Greenfield-Investitionen liegen vor, wenn der ausländische Investor oder ein Tochterunternehmen eines ausländischen Investors in der Union neue Anlagen oder ein neues Unternehmen in der Union errichtet. Sowohl Greenfield- als auch sogenannte Brownfield-Investitionen in Verbindung mit Übernahmen oder Fusionen sollten in den Anwendungsbereich dieser Verordnung fallen, soweit sie den Erwerb der Kontrolle über ein Ziel oder einen Vermögenswert in der Union beinhalten, da bei beiden die Möglichkeit besteht, dass sie sich auf das reibungslose Funktionieren des Binnenmarkts auswirken.

<a id="rec-31"></a>
(31) Die Überprüfung der Investitionen und der Anwendung der harmonisierten Bedingungen sollte im Einklang mit dieser Verordnung durchgeführt werden. Dabei sollten alle verfügbaren Informationen berücksichtigt und der Grundsatz der Verhältnismäßigkeit gewahrt werden. Darüber hinaus sollten alle Maßnahmen, die von nationalen Behörden oder der Kommission in Bezug auf die Überprüfung ausländischer Investitionen ergriffen werden, mit dem Unionsrecht und insbesondere mit den Artikeln 49 und 63 AEUV im Einklang stehen.

<a id="rec-32"></a>
(32) Ungeachtet des mit der Verordnung (EU) 2019/452 des Europäischen Parlaments und des Rates^(44) eingerichteten Überprüfungsmechanismus sollten daher die Bestimmungen dieser Verordnung für ausländische Direktinvestitionen in aufstrebenden strategischen Sektoren im Einklang mit den in dieser Verordnung festgelegten Schwellenwerten gelten. Darüber hinaus sollten die Bestimmungen dieser Verordnung unbeschadet der wettbewerbsrechtlichen Instrumente der Union gelten, einschließlich der Verordnung (EU) 2022/2560 des Europäischen Parlaments und des Rates^(45) und der Verordnung (EG) Nr. 139/2004 des Rate^(46).

<a id="rec-33"></a>
(33) Bei den Kriterien für ausländische Direktinvestitionen sollten Investitionen in aufstrebende strategische Sektoren in der Union durch Investoren aus Drittländern (im Folgenden „ausländische Investoren“) in der Union berücksichtigt werden. Es könnte jedoch auch erforderlich sein, Investitionen in der Union einzubeziehen, die durch direkt oder indirekt von einer Person oder Einrichtung aus einem Drittland kontrollierte Einrichtungen erfolgen, und zwar unabhängig vom Standort des letztendlichen Eigentümers (im Folgenden „Tochterunternehmen eines ausländischen Investors“), da sie aufgrund der Kontrolle durch das Drittland, das im Besitz eines erheblichen Marktanteils ist, gleichermaßen geeignet sind, das Funktionieren des Binnenmarkts, einschließlich seiner Versorgung und wirtschaftlichen Sicherheit, zu stören. Daher sollten die Investitionsbehörden die Investitionskriterien anwenden, wenn sie für die wirksame Gewährleistung des Schutzes der öffentlichen Sicherheit, der Versorgung, der wirtschaftlichen Sicherheit und der ökologischen Nachhaltigkeit in der Union eindeutig erforderlich sind und wenn sie für den technologischen Fortschritt des Binnenmarkts hinsichtlich des grünen und des digitalen Wandel sowie für Verteidigungszwecke von wesentlicher Bedeutung sind. Darüber hinaus soll die Umgehung der Bestimmungen der Verordnung verhindert werden, wenn nach vernünftigem Ermessen keine alternativen Maßnahmen zur Verfügung stehen. Um die angemessene Anwendung der für Investitionen von Tochterunternehmen eines ausländischen Investors vorgeschriebenen Bedingungen zu gewährleisten, sollte die Kommission die Möglichkeit haben, Meldungen zu prüfen und die Investitionsbehörde aufzufordern, bestimmte Bedingungen vorzuschreiben. Abgesehen von der Überprüfung ausländischer Direktinvestitionen von Tochterunternehmen eines ausländischen Investors gemäß dieser Verordnung sollten Investitionen, die aus anderen Mitgliedstaaten der Union stammen, nicht an Bedingungen geknüpft oder verhindert werden.

<a id="rec-34"></a>
(34) Zwischen dem ausländischen Investor und dem Ziel in der Union muss eine dauerhafte Verbindung sichergestellt werden, unabhängig davon, ob die Investition direkt von einem ausländischen Investor oder über eine in der Union niedergelassene und von einem ausländischen Investor kontrollierte Einrichtung getätigt wird. Dies sollte jedoch nicht für den Erwerb von Wertpapieren eines Unternehmens gelten, die ausschließlich für Finanzanlagen bestimmt sind, ohne dass die Absicht besteht, die Verwaltung oder Kontrolle des Unternehmens zu beeinflussen (Portfolioinvestitionen).

<a id="rec-35"></a>
(35) Umstrukturierungsmaßnahmen innerhalb einer Unternehmensgruppe sowie Investitionen in Finanzinstitute, die in Anwendung eines Abwicklungsinstruments sowie von Abschreibungs- und Umwandlungsbefugnissen erfolgen, sollten nicht in den Anwendungsbereich dieser Verordnung fallen. Interne Umstrukturierungen sollten nur insoweit vom Anwendungsbereich ausgenommen werden, als sie ausschließlich zum Zweck der internen Sanierung eines Ziels in der Union oder der Unternehmensgruppe, zu der das Ziel gehört, durchgeführt werden, ohne dass dies zu Änderungen des wirtschaftlichen Eigentums oder der Kontrolle über das Ziel in der Union führt. Interne Umstrukturierungen sollten insbesondere dann ausgeschlossen werden, wenn sie nicht dazu führen, dass ein neuer ausländischer Investor das Eigentum am Ziel in der Union oder die Kontrolle darüber oder über ein Unternehmen erwirbt, das dieses Ziel in der Union direkt oder indirekt besitzt oder kontrolliert, wenn es zu einer Zunahme der von ausländischen Investoren gehaltenen Anteile kommt oder wenn die Transaktion zusätzliche Rechte für ausländische Investoren zur Folge hat, die zu einer Änderung der tatsächlichen Beteiligung eines oder mehrerer ausländischer Investoren an der Verwaltung oder Kontrolle des Ziels in der Union führen können.

<a id="rec-36"></a>
(36) Die Kriterien für ausländische Direktinvestitionen sollten nur für ausländische Direktinvestitionen in aufstrebende strategische Sektoren gelten, die einen Schwellenwert erreichen, der in der Lage ist, das Funktionieren des Binnenmarkts zu stören. Bei einem Schwellenwert von 100 Mio. EUR sollte davon ausgegangen werden, dass er das reibungslose Funktionieren des Binnenmarkts in aufstrebenden strategischen Sektoren beeinträchtigen könnte. Ohne Einhaltung der harmonisierten Bedingungen würden solche in den Anwendungsbereich dieser Verordnung fallenden ausländischen Direktinvestitionen ein hohes Risiko für die Sicherheit und die ökologische Nachhaltigkeit der Union bergen und gleichzeitig keinen ausreichenden Mehrwert einschließlich der Gewährleistung eines Beitrags der Union zu den Investitionen, der Verbesserung der technologischen Entwicklung der Union, der Beschäftigung von Arbeitnehmern aus der Union und des Beitrags zu den Wertschöpfungsketten der Union für den Binnenmarkt schaffen.

<a id="rec-37"></a>
(37) Zur Sicherstellung der wirksamen Anwendung dieser Verordnung sollte jeder Mitgliedstaat eine Investitionsbehörde benennen, die für die Bewertung der Bedingungen für Investitionen ausländischer Unternehmen in aufstrebenden strategischen Sektoren zuständig ist. Darüber hinaus sollte sie mit den rechtlichen, administrativen und finanziellen Ressourcen ausgestattet werden, damit sie ihre Aufgaben wirksam und unabhängig wahrnehmen kann, wobei die Behörden, die bereits für die Durchführung der Verordnung (EU) 2019/452 zuständig sind, gebührend zu berücksichtigen sind.

<a id="rec-38"></a>
(38) Damit die Mitgliedstaaten die in dieser Verordnung definierten Investitionen wirksam ermitteln können, sollten ausländische Investoren die zuständigen Behörden unterrichten, bevor sie erhebliche Beteiligungen an Unternehmen oder Vermögenswerten in der Union erwerben oder schaffen. Durch die Festlegung eines Schwellenwerts von 30 % für Eigentumsrechte oder andere Rechte, die eine Kontrolle sowohl über Unternehmen als auch über Vermögenswerte begründen, sollte sichergestellt werden, dass der Mechanismus Investitionen erfasst, die sich auf das reibungslose Funktionieren des Binnenmarkts auswirken können.

<a id="rec-39"></a>
(39) Zur Minimierung des Umgehungsrisikos durch fragmentierte oder indirekte Übernahmen, bei denen mehrere ausländische Investoren gemeinsam handeln oder Investitionen über verbundene Unternehmen bzw. mittels komplexer Eigentumsstrukturen getätigt werden, sollte die Investitionsbehörde zum Zweck der Bestimmung des Investitionswerts und der Meldeschwelle deren jeweilige Anteile aggregieren. Die Aggregation sollte auch für bestehende direkte oder indirekte, individuelle oder kollektive Beteiligungen an demselben Unternehmen oder Vermögenswert in der Union gelten, um sicherzustellen, dass aufeinanderfolgende Transaktionen, die zu einem maßgeblichen Einfluss oder einer maßgeblichen Kontrolle führen, ordnungsgemäß gemeldet werden.

<a id="rec-40"></a>
(40) Um die Beteiligung der Union an großen ausländischen Direktinvestitionen aus Drittländern mit bedeutender globaler Stellung sicherzustellen, sollten in dieser Verordnung Grenzen für den Umfang des Eigentums an Unternehmen und Vermögenswerten der Union und der Kontrolle darüber festgelegt werden, die ausländische Investoren erwerben können. Dementsprechend sollten ausländische Investoren weder direkt noch indirekt Beteiligungen von mehr als 49 % des Aktienkapitals, der Stimmrechte oder gleichwertiger Eigentumsanteile an einem Ziel in der Union begründen, erwerben, halten oder ausüben, noch sollten sie gleichwertige Eigentums-, Leasing- oder sonstige Rechte, mit denen die Kontrolle über einen Vermögenswert in der Union übertragen wird, begründen oder erwerben.

<a id="rec-41"></a>
(41) Um sicherzustellen, dass ausländische Investoren und Einrichtungen der Union in aufstrebenden strategischen Sektoren zusammenarbeiten und gleichzeitig eine ausreichende Beteiligung der Partner aus der Union gewährleistet wird, sollten Anforderungen an Joint Ventures vorgeschrieben werden, die auch vertragliche Regelungen umfassen. Ein ausländischer Investor sollte an einem Joint Venture nicht mehr als 49 % des Aktienkapitals, der Stimmrechte oder gleichwertiger Eigentumsanteile oder aber anderer, die Kontrolle begründender Rechte an einem der an dem Joint Venture beteiligten Rechtsträger der Union besitzen. Diese Bedingung sollte zudem zur strategischen Autonomie der Union beitragen und einen Mehrwert für den Binnenmarkt gewährleisten.

<a id="rec-42"></a>
(42) Als Teil der Bedingungen für die Genehmigung einer ausländischen Direktinvestition muss geprüft werden, ob der Technologietransfer zur Verwirklichung der Ziele dieser Verordnung beitragen kann. Zu diesem Zweck sollten die ausländischen Investoren aufgefordert werden, dem Ziel in der Union, dem Joint Venture oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, die für die Ausübung der betreffenden Wirtschaftstätigkeit im Zusammenhang mit der ausländischen Direktinvestition erforderlichen Lizenzen für die einschlägigen Rechte des geistigen Eigentums und das einschlägige Know-how zu erteilen. Ausländische Investoren sollten daher mit dem Ziel in der Union, dem Joint Venture oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, eine oder mehrere geeignete Lizenzvereinbarungen über geistiges Eigentum schließen. Der Anwendungsbereich und die Bedingungen dieser Vereinbarungen, beispielsweise die genauen Rechte des geistigen Eigentums, um die es geht, die Exklusivität der Lizenz, die Laufzeit der Lizenz oder Maßnahmen zur Wahrung der Vertraulichkeit, sollten den Umständen und dem mit dieser Verordnung verfolgten Ziel und der betreffenden Investition angemessen entsprechen. Der ausländische Investor sollte sich verpflichten, die für die betreffende Wirtschaftstätigkeit geeigneten Lizenzen für Rechte des geistigen Eigentums und einschlägiges Know-how zu erteilen. Dies könnte dadurch erreicht werden, dass der Investitionsbehörde eine vertrauliche Beschreibung der wichtigsten Aspekte der möglichen Lizenzvereinbarungen zur Verfügung gestellt wird.

<a id="rec-43"></a>
(43) Besitzt das Ziel in der Union oder die juristische Person, das bzw. die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, vor der ausländischen Investition Rechte des geistigen Eigentums an einer Erfindung, einem Werk oder einem anderen Vermögenswert, der dem Schutz des geistigen Eigentums unterliegt, so sollten diese Rechte des geistigen Eigentums vollständig und ausschließlich unter der Kontrolle des Ziels in der Union oder der juristischen Person, das bzw. die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, verbleiben. Der ausländische Investor darf keine Rechte des geistigen Eigentums geltend machen und keine Tätigkeiten ausüben, die die Fähigkeit des Ziels in der Union oder der juristischen Person, das bzw. die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, zum Besitz oder zur Ausübung der vor der ausländischen Investition erworbenen Rechte des geistigen Eigentums an seinen bzw. ihren Erfindungen, Werken, Handelsmarken, Geschmacksmustern oder anderen relevanten Vermögenswerten beeinträchtigen würden. Ist eine Erfindung, ein Werk oder ein anderer Vermögenswert, der dem Schutz des geistigen Eigentums unterliegt, das Ergebnis einer Zusammenarbeit zwischen dem Ziel in der Union oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, und dem ausländischen Investor oder aber das Ergebnis eines Joint Ventures, so sollten die Rechte des geistigen Eigentums, den jeweiligen Umständen entsprechend, gemeinsames Eigentum des ausländischen Investors, des Ziels in der Union oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, sein. Die Bedingungen für das gemeinschaftliche Eigentum an Rechten des geistigen Eigentums sollten vor der Genehmigung der ausländischen Direktinvestition so weit wie möglich festgelegt und der Investitionsbehörde mitgeteilt werden. Diese Bedingungen sollten Klarstellungen hinsichtlich der Möglichkeit, dass ein Miteigentümer eine Lizenz erteilt und Verletzungsverfahren einleitet, sowie die finanziellen Vereinbarungen hinsichtlich der Anmeldung und Eintragung von Rechten des geistigen Eigentums und Lizenzvereinbarungen umfassen. Im Fall eines Joint Ventures ohne Rechtspersönlichkeit sollten der Investitionsbehörde Klarstellungen in Bezug auf das Eigentum an geistigem Eigentum übermittelt werden.

<a id="rec-44"></a>
(44) Es muss sichergestellt werden, dass das Fachwissen der ausländischen Investoren über die in den Anwendungsbereich dieser Verordnung fallenden großen ausländischen Direktinvestitionen zur Verbesserung der technologischen Entwicklung der Union sowohl innerhalb als auch außerhalb des Ziels in der Union, des Joint Ventures oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, beiträgt. Zu diesem Zweck sollten ausländische Investoren in Forschungs- und Entwicklungsprojekte investieren, die innerhalb der Union durchgeführt werden sollen, wobei sicherzustellen ist, dass die Union von den erzielten Ergebnissen profitiert. Daher muss als Teil der Voraussetzungen für die Genehmigung einer ausländischen Direktinvestition geprüft werden, ob die Forschungs- und Entwicklungsinvestitionen der ausländischen Investoren zur Erreichung dieses Ziels geeignet sind. Investitionen dieser Art könnten Forschungseinrichtungen mit Sitz in der Union zugutekommen, auch im Rahmen gemeinsamer Projekte mit dem Ziel in der Union, dem Joint Venture oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist. Zur Entwicklung oder Durchführung spezifischer Forschungs- und Entwicklungstätigkeiten könnten diese Investitionen auch innerhalb des Ziels in der Union, des Joint Ventures oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, getätigt werden. Diese Investitionen könnten auch in der Schulung von Arbeitnehmern aus der Union oder der direkten oder indirekten finanziellen Unterstützung von Forschungs- und Entwicklungsprojekten innerhalb des Ziels in der Union, des Joint Ventures oder der juristischen Person, die den Vermögenswert in der Union erwirbt oder Eigentümerin des Vermögenswerts in der Union ist, bestehen. Bewertungen im Zusammenhang mit Investitionen in Forschungs- und Entwicklungsvorhaben, die innerhalb der Union durchgeführt werden sollen, sollten die wettbewerbsrechtlichen Instrumente der Union, einschließlich der Verordnungen (EU) 2022/2560 und (EG) Nr. 139/2004, unberührt lassen.

<a id="rec-45"></a>
(45) Um die nachhaltige Integration von Investitionen ausländischer Einrichtungen in den Binnenmarkt und die Entwicklung von Kompetenzen in aufstrebenden strategischen Sektoren zu fördern und einen sinnvollen sozialen Beitrag am Ort der Investition zu gewährleisten, sollte bei solchen Investitionen ein Anteil an Arbeitnehmern aus der Union beschäftigt sein und es sollten geeignete Schulungs- und Kapazitätsaufbaumaßnahmen unter Einbeziehung von Anbietern allgemeiner und beruflicher Bildung sowie der Sozialpartner angeboten werden. Der ausländische Investor sollte sicherstellen, dass die in dieser Verordnung festgelegten Schwellenwerte für sämtliche Kategorien von Arbeitskräften, einschließlich operativer, technischer, aufsichtlicher und leitender Positionen, eingehalten werden.

<a id="rec-46"></a>
(46) Zur Stärkung der Produktionskapazitäten aufstrebender strategischer Sektoren und zur Integration ausländischer Direktinvestitionen in das industrielle Ökosystem der Union sollte in Produkten, die durch solche Investitionen auf dem Unionsmarkt in Verkehr gebracht werden, ein bestimmter Anteil von in der Union hergestellten Inputs enthalten sein.

<a id="rec-47"></a>
(47) Um sicherzustellen, dass ausländische Direktinvestitionen mindestens vier der sechs in dieser Verordnung festgelegten Bedingungen erfüllen, sollte die zuständige Investitionsbehörde jede Meldung prüfen und eine begründete Entscheidung über ihre Genehmigung oder Ablehnung erlassen. Die Investitionsbehörden sollten die Erfüllung der Bedingungen oder gegebenenfalls die Absicht des ausländischen Investors zur Erfüllung der Bedingungen feststellen. Solche Investitionen sollten nicht ohne ausdrückliche Genehmigung der Investitionsbehörde durchgeführt werden. Dementsprechend sollten ausländische Investoren eine Reihe von Bedingungen erfüllen, bevor sie ihre wirtschaftliche Tätigkeit in Bezug auf die betreffende ausländische Direktinvestition aufnehmen. Die Investitionsbehörden sollten ihre Entscheidungen innerhalb eines Zeitrahmens treffen, mit dem sowohl Verfahrenseffizienz als auch Rechtssicherheit gewährleistet wird. Wenn dies aufgrund der Komplexität des Falls oder des Bedarfs an zusätzlichen Informationen gerechtfertigt ist, könnte diese Frist aus berechtigten, hinreichend belegten Gründen verlängert werden.

<a id="rec-48"></a>
(48) Die Mitgliedstaaten sollten die Kommission über eingegangene Mitteilungen unterrichten, damit die Kommission die Investitionslandschaft wirksam überwachen und im gesamten Binnenmarkt einen harmonisierten Investitionsrahmen gewährleisten kann.

<a id="rec-49"></a>
(49) Zur Sicherstellung der horizontalen Anwendung dieser Verordnung im Binnenmarkt sollte die Kommission eine Stellungnahme dazu abgeben können, ob die Investition die in dieser Verordnung festgelegten Bedingungen erfüllt. Diese Stellungnahme sollte öffentlich zugänglich gemacht werden. Beabsichtigt die Investitionsbehörde, in ihrer Entscheidung von der Stellungnahme der Kommission abzuweichen, sollte sie das Genehmigungsverfahren um zwei zusätzliche Monate verlängern, um die Vorbringen der Kommission angemessen bewerten zu können. Bei ihrer Entscheidung sollten die Mitgliedstaaten begründen, in welcher Weise sie die Stellungnahme der Kommission berücksichtigt haben.

<a id="rec-50"></a>
(50) Zur Sicherstellung der horizontalen Anwendung dieser Verordnung auf den Binnenmarkt sollte die Kommission ausländische Direktinvestitionen auf eigene Initiative oder auf Initiative eines von der ausländischen Direktinvestition betroffenen Mitgliedstaats überprüfen können. Dies sollte insbesondere für Investitionen gelten, von denen mehrere Mitgliedstaaten betroffen sind, sowie für Investitionen von hohem Wert und Investitionen, die aufgrund ihrer Auswirkungen auf den Binnenmarkt von besonderer strategischer Bedeutung für die Union sind.

<a id="rec-51"></a>
(51) Die Investitionsbehörden sollten nicht nur zum Zeitpunkt der Meldung der ausländischen Direktinvestition sicherstellen, dass die Bedingungen eingehalten werden, sondern gegebenenfalls auch während ihres gesamten Betriebs, damit eine Maximierung der Vorteile der ausländischen Direktinvestition auf dem Binnenmarkt gewährleistet werden kann.

<a id="rec-52"></a>
(52) Um sicherzustellen, dass die Kriterien für ausländische Direktinvestitionen für die aufstrebenden strategischen Sektoren auch dann noch angemessen sind, wenn sich die Marktbedingungen, die technologischen Entwicklungen und die wettbewerbspolitischen Ziele der Union weiterentwickeln, sollte die Kommission die globalen Fertigungstrends strategischer Sektoren beobachten und die Befugnis haben, Durchführungsrechtsakte zu erlassen, in denen für weitere strategische Sektoren Kriterien hinsichtlich ausländischer Investitionen festgelegt werden. Die Kommission sollte insbesondere den Schwellenwert sowie die Frage bewerten, ob alle in dieser Verordnung genannten Investitionskriterien für die Erreichung der Ziele dieser Verordnung angemessen und erforderlich sind.

<a id="rec-53"></a>
(53) Die Bündelung industrieller Tätigkeiten kann wesentlich dazu beitragen, die Ziele dieser Verordnung zu verwirklichen und bestimmte strategische Sektoren im Binnenmarkt zu stärken. Daher ist es angezeigt, die Entwicklung von Beschleunigungsgebieten für die industrielle Fertigung zu fördern. Diese Gebiete sollten geografisch begrenzt sein, um Industriesymbiosen zu fördern. Bei der Ausweisung solcher Gebiete sollten die Mitgliedstaaten, gegebenenfalls in Zusammenarbeit mit den regionalen Behörden, die industrielle Produktion (insbesondere in bestimmten strategischen Sektoren) und den allgemeinen Entwicklungsstand ihrer Regionen berücksichtigen, wobei der Schwerpunkt auf den weniger entwickelten und den im Übergang befindlichen Regionen liegen sollte. Zur Stärkung der Resilienz, der strategischen Autonomie und der Wettbewerbsfähigkeit der industriellen Basis der Union sollte die Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung darüber hinaus mit strategischen Projekten und anderen Initiativen der Union wie Beschleunigungstälern für Netto-Null-Technologie im Einklang stehen.

<a id="rec-54"></a>
(54) Mit den Maßnahmen zur industriellen Beschleunigung innerhalb dieser Beschleunigungsgebiete sollten angemessene Synergien mit anderen Initiativen der Union angestrebt werden, wobei dies in den Rechtsvorschriften der Union anerkannte strategische Projekte, Beschleunigungstäler für Netto-Null-Technologien und Finanzierungsmöglichkeiten der Union einschließt, damit die strategischen Prioritäten im Binnenmarkt aufeinander abgestimmt und Industrieanlagen profitieren können, die für die strategische Autonomie und Wettbewerbsfähigkeit der Union von entscheidender Bedeutung sind. Diese Vorteile sollten auch für Unternehmen gelten, denen das Wettbewerbsfähigkeitssiegel gemäß der Verordnung (EU) XXXX/[XX]^()^(47) (Europäischer Fonds für Wettbewerbsfähigkeit) zuerkannt wurde, sofern der Mitgliedstaat dies nicht ausdrücklich ausschließt.

<a id="rec-55"></a>
(55) Um eine angemessene Versorgung mit kritischen Rohstoffen für Projekte in den Beschleunigungsgebieten zu ermöglichen, sollte der mit Artikel 35 der Verordnung (EU) 2024/1252 eingerichtete Europäische Ausschuss für kritische Rohstoffe eine Plattform für den Austausch von Informationen über Engpässe in der Lieferkette für kritische Rohstoffe in den Beschleunigungsgebieten bereitstellen. Projekte in einschlägigen Gebieten sollten die Möglichkeit haben, den mit Artikel 25 der Verordnung (EU) 2024/1252 festgelegten Mechanismus für die gemeinsame Beschaffung zu nutzen, um ihre Nachfrage nach strategischen Rohstoffen zu bündeln und ihre Verhandlungsposition gegenüber potenziellen Verkäufern zu stärken, insbesondere wenn sie kleine oder mittlere Unternehmen (KMU) und kleine Midcap-Unternehmen umfassen.

<a id="rec-56"></a>
(56) Eine ausreichende und rechtzeitige Versorgung der Beschleunigungsgebiete mit Energie ist eine grundlegende Voraussetzung für ihren wirksamen Einsatz und für die Entwicklung der Fertigungstätigkeiten. Zuverlässige und genaue Informationen über den künftigen Energiebedarf tragen zu einem kosteneffizienten Netzausbau bei. Die Mitgliedstaaten sollten daher für jedes Beschleunigungsgebiet eine Analyse erstellen, in der der künftige Energiebedarf ermittelt wird. Eine solche Analyse sollte dazu dienen, Informationen für die nationale Netzplanung bereitzustellen und so zu gezielten, vorausschauenden Netzinvestitionen und schnelleren Energieanschlüssen für das Beschleunigungsgebiet beizutragen. Bei der Festlegung des Anwendungsbereichs sollten die Mitgliedstaaten die Verfügbarkeit der einschlägigen Verkehrs- und Netzinfrastruktur berücksichtigen. Die Ergebnisse dieser Bewertungen sollten in die nationalen Netzentwicklungspläne einfließen, um bei der künftigen Netzplanung Punkte, an denen in der Zukunft Energiebedarf bestehen wird, angemessen erfassen zu können.

<a id="rec-57"></a>
(57) Werden Beschleunigungsgebiete für die industrielle Fertigung eingerichtet, so sollte im Rahmen ihrer Ausweisung berücksichtigt werden, dass sie dem Potenzial für den Zugang zu oder der Organisation von Bildungs- und Ausbildungsmöglichkeiten entsprechen, damit die Verfügbarkeit qualifizierter Arbeitskräfte sichergestellt werden kann.

<a id="rec-58"></a>
(58) Um die Entwicklung von Beschleunigungsgebieten für die industrielle Fertigung zu fördern und die Genehmigungsverfahren, die für industrielle Tätigkeiten in diesen Gebieten erforderlich sind, voranzutreiben, sollten die Mitgliedstaaten eine aggregierte Basisgenehmigung einführen, die die besonderen Merkmale jedes ermittelten Beschleunigungsgebiets für die industrielle Fertigung widerspiegelt und auf den Sektor oder die Sektoren des verarbeitenden Gewerbes zugeschnitten ist, die dort eingeführt werden sollen. Diese von den Behörden erteilte aggregierte Basisgenehmigung sollte die üblicherweise für solche Tätigkeiten in dem Beschleunigungsgebiet erforderlichen Genehmigungen abdecken, wobei die gemäß der Richtlinie 2010/75/EU des Europäischen Parlaments und des Rates^(48) erforderlichen anlagenspezifischen Genehmigungen und Netzanschlussgenehmigungen ausgenommen sind. Folglich sollten Projektträger zusätzliche Genehmigungen nur für Tätigkeiten, die nicht unter die aggregierte Basisgenehmigung fallen, sowie erforderlichenfalls Genehmigungen im Rahmen von Umweltprüfungen einholen müssen. Bei Tätigkeiten, die möglicherweise Schutzgebiete der Union und der Mitgliedstaaten beeinträchtigen, sollten die maßgeblichen Genehmigungen erst erteilt werden, nachdem sichergestellt wurde, dass die Tätigkeiten mit den Erhaltungszielen für diese Gebiete vereinbar sind. Durch diesen Ansatz sollten die Genehmigungsverfahren erheblich beschleunigt, der damit verbundene Verwaltungsaufwand verringert und zugleich ein hohes Niveau an Umweltstandards aufrechterhalten werden.

<a id="rec-59"></a>
(59) Um einen Rahmen zu schaffen, mit dem die strategische Autonomie und die wirtschaftliche Sicherheit der Union durch den Zugang zu einer sicheren, nachhaltigen und resilienten Versorgung mit einschlägigen Erzeugnissen des verarbeitenden Gewerbes gewährleistet wird, sollte der Kommission die Befugnis übertragen werden, gemäß Artikel 290 AEUV Rechtsakte in Bezug auf Änderungen an der Liste der Drittländer, deren Inhalt nicht als dem Ursprung in der Union gleichwertig behandelt wird, zu erlassen; dasselbe gilt in Bezug auf die Einführung oder Änderung von Anforderungen an den Ursprung in der Union und den CO2-Ausstoß, unter anderem für zusätzliche Netto-Null-Technologien und für die in den Anhängen II und III aufgeführten Produkte und Dienstleistungen sowie die Festlegung von nachfrageseitigen Maßnahmen auf Unionsebene für Produkte der chemischen Industrie, wobei unter anderem die Empfehlungen der Allianz für kritische Chemikalien, die Ausweitung der Kriterien für ausländische Direktinvestitionen auf weitere aufstrebende strategische Sektoren und die Festlegung gemeinsamer Verfahrensregeln für Kriterien für ausländische Direktinvestitionen zu berücksichtigen sowie Klassifizierungssysteme auf der Grundlage der Treibhausgasintensität von Produkten einzurichten sind. Es ist von besonderer Bedeutung, dass die Kommission im Zuge ihrer Vorbereitungsarbeit angemessene Konsultationen, auch auf der Ebene von Sachverständigen, durchführt, die mit den Grundsätzen in Einklang stehen, die in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung^(49) niedergelegt wurden. Um insbesondere für eine gleichberechtigte Beteiligung an der Vorbereitung delegierter Rechtsakte zu sorgen, erhalten das Europäische Parlament und der Rat alle Dokumente zur gleichen Zeit wie die Sachverständigen der Mitgliedstaaten, und ihre Sachverständigen haben systematisch Zugang zu den Sitzungen der Sachverständigengruppen der Kommission, die mit der Vorbereitung der delegierten Rechtsakte befasst sind.

<a id="rec-60"></a>
(60) Zur Gewährleistung einheitlicher Bedingungen für die Durchführung dieser Verordnung sollten der Kommission in Bezug auf die Festlegung der Methode zur Berechnung des Volumenanteils von Produkten und Bauteilen mit Ursprung in der Union und zur Überprüfung der Einhaltung der in Artikel 15 festgelegten Bedingungen Durchführungsbefugnisse übertragen werden. Diese Befugnisse sollten im Einklang mit der Verordnung (EU) Nr. 182/2011 des Europäischen Parlaments und des Rates^(50) ausgeübt werden.

<a id="rec-61"></a>
(61) Die Kommission sollte diese Verordnung auf der Grundlage der von den Mitgliedstaaten bereitgestellten Informationen bewerten. Gemäß Nummer 22 der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung sollte diese Evaluierung auf den fünf Kriterien der Effizienz, der Effektivität, der Relevanz, der Kohärenz und des Mehrwerts für die Union beruhen. Darüber hinaus sollte sie als Grundlage für die Abschätzung der Folgen möglicher weiterer Maßnahmen dienen.

<a id="rec-62"></a>
(62) Um die Einhaltung der in dieser Verordnung festgelegten Verpflichtungen sicherzustellen, sollten die Mitgliedstaaten gegen Unternehmen, die ihren Verpflichtungen nicht nachkommen, Sanktionen festlegen. Diese Sanktionen sollten unbeschadet und zusätzlich zu den in dieser Verordnung festgelegten spezifischen Sanktionsanforderungen, z. B. für ausländische Direktinvestitionen, gelten. Die Mitgliedstaaten müssen in ihren nationalen Rechtsvorschriften daher wirksame, verhältnismäßige und abschreckende Sanktionen für Verstöße gegen diese Verordnung festlegen. Außerdem müssen die Mitgliedstaaten sicherstellen, dass die Projektträger gegebenenfalls Zugang zu einer verwaltungsrechtlichen oder gerichtlichen Überprüfung nach Maßgabe des nationalen Rechts haben.

<a id="rec-63"></a>
(63) Bei der Überprüfung dieser Verordnung sollte die Kommission prüfen, ob die in den Kapiteln III und IV enthaltenen Bestimmungen geändert werden müssen. Insbesondere sollte sie im Hinblick auf Verkehrssektoren, die für die wirtschaftliche Sicherheit der Union von entscheidender Bedeutung sind, insbesondere den Bau von Schiffen und Schienenfahrzeugen, die Einführung einer gezielten Anforderung bezüglich des Ursprungs in der Union in Erwägung ziehen. Die Kommission sollte ferner die Einführung einer verschärften Überprüfung ausländischer Direktinvestitionen in luftfahrttechnische Produkte und Teile in Erwägung ziehen.

<a id="rec-64"></a>
(64) Die Verordnung (EU) 2018/1724 des Europäischen Parlaments und des Rates^(51), mit der das einheitliche digitale Zugangstor eingerichtet wurde, enthält allgemeine Vorschriften für die Online-Bereitstellung von Informationen, Verfahren und Hilfsdiensten, die für das Funktionieren des Binnenmarkts relevant sind. Damit Unternehmen und Projektträger des verarbeitenden Gewerbes, auch bei grenzüberschreitenden Projekten, ohne unnötigen zusätzlichen Verwaltungsaufwand die Vorteile des Binnenmarkts unmittelbar nutzen können, müssen den zuständigen Behörden im Rahmen des Genehmigungsverfahrens gemäß dieser Verordnung die in Anhang I der Verordnung (EU) 2018/1724 aufgeführten Informationen übermittelt werden. Die entsprechenden Verfahren sind in Anhang II der genannten Verordnung enthalten, um sicherzustellen, dass Projektträger vollständig online abgewickelte Verfahren und die Dienste des technischen Systems zur einmaligen Erfassung in Anspruch nehmen können. Insbesondere sollten Projektträger der verarbeitenden Industrie im Einklang mit Artikel 6 Absatz 1 und Anhang II der Verordnung (EU) 2018/1724 uneingeschränkten Online-Zugang zu allen Verfahren im Zusammenhang mit dem Genehmigungsverfahren haben und diese online abschließen können. Die Verordnung (EU) 2018/1724 sollte daher entsprechend geändert werden —

<a id="rec-65"></a>
(65) Mit der Verordnung (EU) 2024/1735 werden für eine Reihe von Endprodukten mit Netto-Null-Technologien Anforderungen an die Resilienz eingeführt. Diese Anforderungen zielen darauf ab, die Abhängigkeit von einzelnen Lieferdrittländern zu verringern, reichen jedoch nicht aus, um die Wirtschaftszweige der Union in die Lage zu versetzen, das Potenzial des Binnenmarkts auszubauen; zudem bringen sie ein Umgehungsrisiko mit sich. Um diesen Herausforderungen zu begegnen, sollte im Rechtsrahmen daher durch gezielte zusätzliche Maßnahmen sichergestellt werden, dass technologisches Know-how in die Union geholt und dort gehalten wird.

<a id="rec-66"></a>
(66) Die in dieser Verordnung festgelegten Bestimmungen über die Vergabe öffentlicher Aufträge sollten auf den Bestimmungen der Verordnung (EU) 2024/1735 über Resilienz aufbauen und sie durch die Einführung zusätzlicher Anforderungen an Batterie-Energiespeichersysteme, Photovoltaiktechnologien, Wärmepumpen, Onshore- und Offshore-Windenergietechnologien, Elektrolyseure und Technologien für Kernspaltungsenergie ergänzen. Mit diesen zusätzlichen Anforderungen soll sichergestellt werden, dass ein bestimmter Anteil der Produkte und ihrer wichtigsten spezifischen Bauteile ihren Ursprung in der Union hat. Durch diesen Ansatz soll eine ausreichende Diversifizierung gewährleistet werden, wobei gleichzeitig die strategischen Fertigungskapazitäten und die technologische Souveränität in der Union gestärkt werden sollen. Durch das System zur Überprüfung der Einhaltung der Anforderungen sollte der Verwaltungsaufwand begrenzt werden und es sollte mit der gemeinsamen Praxis bei der Vergabe öffentlicher Aufträge sowie mit dem bestehenden System zur Überprüfung der Einhaltung der Vorschriften gemäß der Verordnung (EU) 2024/1735 im Einklang stehen. Es sollte sich daher auf eine Eigenerklärung der Wirtschaftsteilnehmer stützen.

<a id="rec-67"></a>
(67) Neben der Ergänzung der Bestimmungen der Verordnung (EU) 2024/1735 über die Vergabe öffentlicher Aufträge sollten diese darüber hinaus durch diese Verordnung geändert werden, um für mehr Rechtssicherheit zu sorgen. Der Anwendungsbereich von Artikel 25 der Verordnung (EU) 2024/1735 sollte auf diejenigen Netto-Null-Technologien beschränkt werden, für die voraussichtlich öffentliche Aufträge in einem relevanten Umfang vergeben werden; dadurch wird die Klarheit der Bestimmung verbessert.

<a id="rec-68"></a>
(68) Um dem gleichen politischen Ziel gerecht zu werden, das bei Auktionen für erneuerbare Energie gemäß der Verordnung (EU) 2024/1735 verfolgt wird, sollten mit dieser Verordnung die zusätzlichen Anforderungen an den Ursprung in der Union auf Auktionen für bestimmte Technologien im Bereich der erneuerbaren Energien ausgeweitet werden, um zur Stärkung der industriellen Basis der Union beizutragen und die Resilienz der Lieferketten für Netto-Null-Technologien sicherzustellen. Um den besonderen Merkmalen von Auktionen für erneuerbare Energie Rechnung zu tragen, sollten die zusätzlichen Anforderungen für jene Netto-Null-Technologien gelten, die im Rahmen von Auktionen besonders relevant sind, d. h. für Batterie-Energiespeichersysteme, Photovoltaiktechnologien, Elektrolyseure sowie On- und Offshore-Windtechnologien. Gelten für Auktionen Anforderungen an den Ursprung in der Union, so sollten andere Bestimmungen, in denen ähnliche Anforderungen an öffentliche Förderregelungen festgelegt sind, für diese Auktionen nicht gelten.

<a id="rec-69"></a>
(69) Um die Wirksamkeit des Rahmens zu erhöhen und dem in jüngster Zeit verzeichneten Anstieg geopolitischer Risiken und globaler Marktverzerrungen Rechnung zu tragen, sollte der Anteil der unter die Anforderungen fallenden Auktionen erhöht und eine höhere Kostenschwelle für das Opt-out von diesen Anforderungen festgelegt werden. Dadurch sollte auch eine übermäßige Inanspruchnahme von Ausnahmeregelungen verhindert und ein wirksamer Anreiz geschaffen werden, die Produktion von Technologien für erneuerbare Energien in der Union anzukurbeln.

<a id="rec-70"></a>
(70) Unternehmen und Haushalte bilden einen wesentlichen Teil der Nachfrage nach Netto-Null-Technologien in der Union. Öffentliche Förderprogramme, mit denen die Verbrauchernachfrage nach solchen Produkten angekurbelt werden soll, sind wichtige Instrumente zur Stärkung der wirtschaftlichen Sicherheit der Union und zur Beschleunigung des grünen Wandels. Um auf den Bestimmungen der Verordnung (EU) 2024/1735 zur Resilienz aufbauen zu können, müssen diese Bestimmungen durch die Einführung zusätzlicher Anforderungen an Batterie-Energiespeichersysteme, Photovoltaiktechnologien und Wärmepumpen ergänzt werden. Mit diesen zusätzlichen Anforderungen soll sichergestellt werden, dass bestimmte wichtigste spezifische Bauteile und in einigen Fällen das gesamte Enderzeugnis ihren Ursprung in der Union haben. Dieser Ansatz steht im Einklang mit dem allgemeinen Ziel von Förderprogrammen, gesellschaftlich wünschenswerte Ergebnisse zu fördern, um Fortschritte bei der Verwirklichung der Ziele der europäischen Säule sozialer Rechte sowie der Umwelt- und Klimaziele zu erzielen. Darüber hinaus soll mit diesem Ansatz eine ausreichende Diversifizierung sichergestellt und gleichzeitig die strategische Fertigungskapazität und die technologische Souveränität in der Union gestärkt werden. Die für Förderregelungen zuständigen Behörden sollten die Möglichkeit haben, entweder die Förderfähigkeit im Rahmen der Regelung von der Erfüllung der Anforderungen abhängig zu machen oder einen zusätzlichen finanziellen Ausgleich zu gewähren, wenn die Anforderungen erfüllt sind. Im letzteren Fall sollte der zusätzliche finanzielle Ausgleich eine Anreizwirkung haben. Handelt es sich jedoch um eine staatliche Beihilfe, so sollte der zusätzliche finanzielle Ausgleich die geltende Beihilfehöchstintensität nicht überschreiten.

<a id="rec-71"></a>
(71) Die Art und Weise, wie Energie erzeugt, verteilt und verbraucht wird, wird weiterhin durch digitale Technologien verändert. Diese digitale Entwicklung bietet zwar beispiellose Chancen, hat aber auch zu Komplexität und Interdependenz innerhalb moderner Energiesysteme geführt, die nun einer wachsenden Zahl von Cyberbedrohungen ausgesetzt sind. Durch die Integration digitaler Technologien in Energiesysteme wird die Angriffsfläche für böswillige Akteure, die Schwachstellen ausnutzen können, um den Betrieb zu stören, sensible Daten zu stehlen oder die Energiemärkte zu manipulieren, erhöht. Solche Störungen gefährden nicht nur die Sicherheit und Stabilität der Energieinfrastruktur der EU und die kontinuierliche Energieversorgung, sondern haben auch Kaskadeneffekte auf alle Wirtschaftszweige, die auf stabile Energie-Inputs angewiesen sind. Darüber hinaus könnten Störungen des Energiesystems das Vertrauen der Investoren untergraben und Investitionen in wesentliche Modernisierungs- und Dekarbonisierungsvorhaben verhindern. Daher ist die Gewährleistung der Cybersicherheit dieser Systeme von entscheidender Bedeutung für die Gewährleistung der wirtschaftlichen Sicherheit, die Aufrechterhaltung des Vertrauens und die Stärkung der Resilienz gegenüber künftigen Herausforderungen.

<a id="rec-72"></a>
(72) Um ein hohes Maß an Cybersicherheit zu gewährleisten, muss verhindert werden, dass Hochrisikoanbieter, die im Einklang mit [dem Vorschlag für einen überarbeiteten Rechtsakt zur Cybersicherheit] ermittelt wurden, an Bieter bei Auktionen für erneuerbare Energien, an Bieter in Verfahren zur Vergabe öffentlicher Aufträge und für Endprodukte, die durch staatliche Eingriffe im Anwendungsbereich dieser Verordnung gefördert werden, kritische Bauteile liefern.

<a id="rec-73"></a>
(73) Darüber hinaus sollten die Cybersicherheitsbestimmungen des Artikels 26 der Verordnung (EU) 2024/1735 nicht nur für 30 % der Auktionen für erneuerbare Energie, sondern für alle Auktionen dieser Art gelten, da die Cybersicherheit für die Stabilität und Integrität des Energiesystems der Union insgesamt von wesentlicher Bedeutung ist. Besteht auch nur bei einem Element der Cybersicherheit eines Energiesystems eine Lücke, könnte dies die Stabilität des gesamten Systems gefährden. Zusätzlich zu dem hohen Cybersicherheitsniveau, das in kritischen Sektoren durch die Richtlinie (EU) 2022/2555 und bei Produkten mit digitalen Elementen mit der Verordnung (EU) 2024/2847 sichergestellt wird, dürfte die Ausweitung des Anwendungsbereichs der Cybersicherheitsanforderungen der Verordnung (EU) 2024/1735 auf alle Auktionen für erneuerbare Energie die Schwachstellen des Energiesystems der Union weiter verringern und zur Sicherung der Stabilität in den Bereichen Energie und Wirtschaft beitragen.

<a id="rec-74"></a>
(74) Die Anwendung der Anforderungen an den Ursprung in der Union und die Cybersicherheit auf Netto-Null-Technologien sollte die in der Verordnung (EU) 2024/1735 festgelegten Anforderungen an Nachhaltigkeit und Resilienz ergänzen. Sie sollten daher in die genannte Verordnung aufgenommen werden, um Kohärenz zu gewährleisten und die Umsetzung durch die zuständigen Behörden zu vereinfachen.

<a id="rec-75"></a>
(75) Im Einklang mit den Maßnahmen für die Vergabe öffentlicher Aufträge, Auktionen und öffentliche Förderregelungen sollte die vorliegende Verordnung auch die Verordnung (EU) 2024/1735 ergänzen, indem in Bezug auf die von Mitgliedstaaten geleistete Unterstützung für den Bau von Kernkraftwerken und die Herstellung von Wasserstoffelektrolyseuren Anforderungen an den Ursprung in der Union aufgenommen werden. Für die Sicherung der langfristigen Souveränität der Union, der Energieversorgungssicherheit und der Resilienz des Sektors ist es entscheidend, dass bei neuen Kernkraftwerken – sowohl Großreaktoren als auch kleinen modularen Reaktoren – Technologien und Bauteilen aus der Union möglichst Vorrang eingeräumt wird und gleichzeitig die höchsten Qualitätsstandards aufrechterhalten werden. Durch eine solche Strategie werden nicht nur die heimischen Fähigkeiten gestärkt, sondern darüber hinaus die Union als zuverlässiger, wettbewerbsfähiger Akteur auf dem globalen Nuklearmarkt positioniert. Um jedoch Risiken im Zusammenhang mit Abhängigkeiten von bestimmten Technologien zu vermeiden, sollten die Anforderungen an den Ursprung von Kernkraftwerken in der Union nur für Neubauten gelten und Modernisierungen sowie Laufzeitverlängerungen bestehender Kernkraftwerke ausgenommen werden.

<a id="rec-76"></a>
(76) Die Verordnung (EU) 2024/1735 sollte daher entsprechend geändert werden.

<a id="rec-77"></a>
(77) Wasserstoff ist in vielen industriellen Anwendungen ein wichtiger Energieträger für die Energiewende und trägt entscheidend dazu bei, den Übergang zu saubereren Energiesystemen voranzutreiben. Um dem Aufkommen von Elektrolyseuren im Gigawatt-Maßstab in der Union Rechnung zu tragen, ist ein abgestimmtes, verstärktes Fördersystem unerlässlich.

<a id="rec-78"></a>
(78) In Fällen, in denen nach den Anforderungen hinsichtlich des Ursprungs in der Union eine bestimmte Anzahl von Bauteilen ihren Ursprung in der Union haben muss, ohne dass in den Ursprungsanforderungen angegeben ist, welche Bauteile dies genau betrifft, sollte die Wahl den Wirtschaftsteilnehmern überlassen bleiben. Dies gewährleistet einen ausreichenden Wettbewerb zwischen den Lieferanten der benötigten Bauteile und ermöglicht es den Wirtschaftsteilnehmern, bei der Erfüllung der Voraussetzungen die kosteneffizienteste Wahl zu treffen.

<a id="rec-79"></a>
(79) Mit der Verordnung (EU) 2024/3110 wird der Kommission die Befugnis übertragen, delegierte Rechtsakte zur Festlegung von Anforderungen an die Kennzeichnung der ökologischen Nachhaltigkeit für bestimmte Produktkategorien und -familien von Bauprodukten zu erlassen, sofern das Produkt in der Regel von Verbrauchern gewählt wird und während seines gesamten Lebenszyklus keine unterschiedliche Umweltleistung in Abhängigkeit von der Montage aufweist. Diese strengen Bedingungen sollten aufgehoben werden, damit die Kommission Anforderungen an die Kennzeichnung von Bauprodukten auf der Grundlage ihrer CO2-Intensität festlegen kann, und zwar auch für solche Produkte, die in der Regel nicht an Endverbraucher verkauft werden. Die Verordnung (EU) 2024/3110 sollte daher entsprechend geändert werden.

<a id="rec-80"></a>
(80) Soweit es sich bei einer der in dieser Verordnung vorgesehenen Maßnahmen um eine staatliche Beihilfe handelt, gelten die Bestimmungen über solche Maßnahmen unbeschadet der Anwendung der Artikel 107 und 108 AEUV.

<a id="rec-81"></a>
(81) Da das Ziel dieser Verordnung, nämlich die Förderung einer resilienten und dekarbonisierten Industrieproduktion, von den Mitgliedstaaten nicht ausreichend verwirklicht werden kann und vielmehr wegen des Umfangs oder der Wirkungen der Maßnahme auf Unionsebene besser zu verwirklichen ist, kann die Union im Einklang mit dem in Artikel 5 des Vertrags über die Europäische Union verankerten Subsidiaritätsprinzip tätig werden. Entsprechend dem in demselben Artikel genannten Grundsatz der Verhältnismäßigkeit geht diese Verordnung nicht über das für die Verwirklichung dieses Ziels erforderliche Maß hinaus —

HABEN FOLGENDE VERORDNUNG ERLASSEN:

<a id="chapter-i"></a>
## Kapitel I – ALLGEMEINE BESTIMMUNGEN

<a id="art-1"></a>
### Artikel 1 – Gegenstand und Anwendungsbereich

(1) Mit dieser Verordnung soll das Funktionieren des Binnenmarkts verbessert werden, indem ein Rahmen geschaffen wird, mit dem die Entwicklung, Wettbewerbsfähigkeit und Resilienz des verarbeitenden Gewerbes in der Union unterstützt werden, wobei der Schwerpunkt auf ausgewählten strategischen Sektoren liegt, während gleichzeitig ein Beitrag zum Klimaziel der Union, zur wirtschaftlichen Sicherheit sowie zur Schaffung hochwertiger Arbeitsplätze, ihrem Erhalt und dem Übergang zu ihnen geleistet wird.

(2) Um das in Absatz 1 genannte allgemeine Ziel zu erreichen, werden in dieser Verordnung Maßnahmen festgelegt, die auf Folgendes abzielen:

  - a) Beschleunigung der Genehmigungsverfahren für industrielle Fertigungsprojekte, darunter Projekte zur Dekarbonisierung energieintensiver Industrien;

  - b) Schaffung eines Leitmarkts für bestimmte Produkte in strategischen Sektoren, indem im Zusammenhang mit der Vergabe öffentlicher Aufträge und öffentlichen Förderregelungen Anforderungen hinsichtlich des Ursprungs in der Union und/oder Anforderungen an den CO2-Ausstoß festgelegt werden;

  - c) Festlegung von Bedingungen für ausländische Direktinvestitionen in aufstrebenden strategischen Sektoren;

  - d) Sicherstellung der Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung durch die Mitgliedstaaten zwecks Förderung industrieller Tätigkeiten.

<a id="art-2"></a>
### Artikel 2 – Industrialisierungsziel

  Die Union und die Mitgliedstaaten bemühen sich, dass das verarbeitende Gewerbe in der Union bis 2035 mindestens 20 % des Bruttoinlandsprodukts der Union ausmacht.

<a id="art-3"></a>
### Artikel 3 – Begriffsbestimmungen

  Für die Zwecke dieser Verordnung bezeichnet der Ausdruck

- 1. „industrielles Fertigungsprojekt“ den Bau, den Umbau oder die Ausweitung eines Industrieareals, das für die Ausübung einer wirtschaftlichen Tätigkeit bestimmt ist, die unter dem NACE-Code C (verarbeitendes Gewerbe), mit Ausnahme des NACE-Codes C12, eingereiht ist;

- 2. „energieintensive Industrien“ die in Anhang I Nummer 1 aufgeführten Industrien;

- 3. „Projekte zur Dekarbonisierung energieintensiver Industrien“ den Bau oder die Umwandlung der gewerblichen Anlage eines energieintensiven Betriebs im Sinne von Artikel 17 Absatz 1 Buchstabe a der Richtlinie 2003/96/EG des Rates^(52) in den in Anhang I Nummer 1 der genannten Verordnung aufgeführten energieintensiven Industrien, durch die die in CO2-Äquivalent gemessenen Emissionsraten industrieller Verfahren erheblich und dauerhaft gesenkt werden sollen, soweit dies technisch machbar ist;

- 4. „Genehmigungsverfahren“ ein Verfahren, das alle einschlägigen Genehmigungen für den Bau, die Ausweitung, die Umwandlung und den Betrieb von industriellen Fertigungsprojekten abdeckt, einschließlich Baugenehmigungen, chemikalienbezogene Genehmigungen und Netzanschlussgenehmigungen im Sinne des Artikels 1 [des Vorschlags für eine Richtlinie zur Änderung der Richtlinien (EU) 2018/2001, (EU) 2019/944 und (EU) 2024/1788 im Hinblick auf die Beschleunigung der Genehmigungsverfahren^(53)] sowie erforderlichenfalls Umweltprüfungen und -genehmigungen, und das alle Anträge und Verfahren von der Bestätigung der Vollständigkeit des Antrags bis zur Mitteilung der umfassenden Entscheidung über das Ergebnis des Verfahrens umfasst;

- 5. „umfassende Entscheidung“ die von einer Behörde oder mehreren Behörden eines Mitgliedstaats getroffene Entscheidung oder Reihe von Entscheidungen darüber, ob ein Projektträger die Genehmigung für den Bau, die Ausweitung, die Umwandlung oder den Betrieb eines industriellen Fertigungsprojekts erteilt wird;

- 6. „Auftrag“ öffentliche Aufträge im Sinne des Artikels 2 Absatz 1 Nummer 5 der Richtlinie 2014/24/EU^(54), Liefer-, Bau- und Dienstleistungsaufträge im Sinne des Artikels 2 Nummer 1 der Richtlinie 2014/25/EU^(55) und Konzessionen im Sinne des Artikels 5 Nummer 1 der Richtlinie 2014/23/EU;

- 7. „öffentlicher Auftraggeber“ einen öffentlichen Auftraggeber im Sinne des Artikels 6 der Richtlinie 2014/23/EU, des Artikels 2 Absatz 1 Nummer 1 der Richtlinie 2014/24/EU und des Artikels 3 der Richtlinie 2014/25/EU;

- 8. „Auftraggeber“ einen Auftraggeber im Sinne des Artikels 7 der Richtlinie 2014/23/EU und des Artikels 4 der Richtlinie 2014/25/EU;

- 9. „Wirtschaftsteilnehmer“ den Hersteller, den Bevollmächtigten, den Einführer, den Vertreiber, den Händler und den Fulfilment-Dienstleister und für die Zwecke von Verfahren zur Vergabe öffentlicher Aufträge einen Wirtschaftsteilnehmer im Sinne des Artikels 5 Nummer 2 der Richtlinie 2014/23/EU, des Artikels 2 Absatz 1 Nummer 10 der Richtlinie 2014/24/EU und des Artikels 2 Nummer 6 der Richtlinie 2014/25/EU;

- 10. „Verfahren zur Vergabe öffentlicher Aufträge“ eines der folgenden Verfahren:

  - a) ein Verfahren zur Vergabe von Bau- oder Dienstleistungskonzessionen nach der Richtlinie 2014/23/EU;

  - b) alle Arten von Vergabeverfahren nach der Richtlinie 2014/24/EU für den Abschluss eines öffentlichen Auftrags oder nach der Richtlinie 2014/25/EU für den Abschluss eines Liefer-, Bauleistungs- und Dienstleistungsauftrags;

- 11. „Treibhausgasintensität“ die Emissionen (gemessen in Tonnen CO2-Äquivalent), die bei der Herstellung der in Artikel 10 Absatz 2 genannten Industrieprodukte freigesetzt werden;

- 12. „Hersteller“ jede natürliche oder juristische Person, die ein Produkt herstellt bzw. entwickeln oder herstellen lässt und dieses unter ihrem eigenen Namen oder ihrer eigenen Marke vermarktet;

- 13. „Systemgrenze“ die Gruppe chemischer oder physikalischer Vorgänge, die in die Berechnung der Treibhausgasintensität von Produkten einbezogen werden;

- 14. „Vorläuferstoff“ jedes Vormaterial für ein Herstellungsverfahren, das Teil der Systemgrenzen ist;

- 15. „chemische Industrie“ Tätigkeiten, die nach NACE Rev. 2 unter dem Code C20 (Herstellung von chemischen Erzeugnissen) eingereiht sind und von in der Union niedergelassenen Herstellern ausgeübt werden;

- 16. „nachhaltige Kohlenstoffquellen“ Biomasse, die den in Artikel 29 der Richtlinie (EU) 2018/2001 festgelegten Nachhaltigkeitskriterien entspricht, sowie Abfälle und Kohlenstoff aus der CO2-Abscheidung;

- 17. „Stoff“ einen Stoff im Sinne des Artikels 2 Nummer 7 der Verordnung (EG) Nr. 1272/2008;

- 18. „Gemisch“ ein Gemisch im Sinne des Artikels 2 Nummer 8 der Verordnung (EG) Nr. 1272/2008;

- 19. „auf dem Markt bereitgestellt“ jede entgeltliche oder unentgeltliche Abgabe eines Produkts zum Vertrieb, Verbrauch oder zur Verwendung auf dem Unionsmarkt im Rahmen einer Geschäftstätigkeit;

- 20. „Brennstoffzellenfahrzeug“ oder „FCV“ (Fuel Cell Vehicle) ein Fahrzeug, dessen Antriebsstrang ausschließlich Energiewandler, die chemische Energie (Einspeisung) in elektrische Energie (abgegebene Leistung) oder umgekehrt umwandeln, und elektrische Maschinen als Antriebsenergiewandler enthält;

- 21. „Kraftfahrzeug“ Fahrzeuge der Klassen M und N im Sinne des Artikels 4 Absatz 1 Buchstaben a und b der Verordnung (EU) 2018/858 des Europäischen Parlaments und des Rates^(56);

- 22. „extern aufladbares Hybridelektrofahrzeug“ oder „OVC-HEV“ (Off-Vehicle Charging Hybrid Electric Vehicle) ein Fahrzeug, das mit einem Antriebsstrang ausgerüstet ist, der mindestens zwei verschiedene Arten von Antriebsenergiewandlern enthält, wobei einer der Antriebsenergiewandler eine elektrische Maschine ist, die durch eine externe Quelle aufgeladen werden kann;

- 23. „reines Elektrofahrzeug“ oder „PEV“ (Pure Electric Vehicle) ein Fahrzeug, dessen Antriebsstrang ausschließlich elektrische Maschinen als Antriebsenergiewandler und ausschließlich wiederaufladbare Speichersysteme für elektrische Energie als Antriebsenergiespeichersysteme enthält;

- 24. „wichtigste spezifische Bauteile“ die wichtigsten spezifischen Bauteile, wie sie im Anhang der Durchführungsverordnung (EU) 2025/1178 der Kommission^(57) aufgeführt sind;

- 25. „Fahrzeugantriebsbatterie“ eine Elektrofahrzeugbatterie, die speziell auf die Lieferung elektrischer Energie für die Traktion ausgelegt ist, im Sinne des Artikels 3 Nummer 14 der Verordnung (EU) 2023/1542^(58);

- 26. „Bauteile des elektrischen Antriebsstrangs“ Leistungselektronik, elektrische Antriebsmotoren und elektrische Achsen für den Verkehr sowie deren Bauteile, Rotoren und Statoren;

- 27. „wichtigste elektronische Systeme“ fortschrittliche Fahrerassistenzsysteme (einschließlich Lasererfassung und Entfernungsmessung, Radarsysteme, Sensoren, Kameras, Motorsteuergeräte und Integrationsplattformen), zentrale Recheneinheiten, drahtlose Zugangssysteme, Fahrzeug-Infotainment-Haupteinheiten und Fahrwerkselektronik;

- 28. „Fahrzeugbauteil“ jeden Teil eines Fahrzeugs, auch verarbeitete Materialien;

- 29. „montiert“ ein Fahrzeug, das die Endmontage durchlaufen hat;

- 30. „Fahrzeughersteller“ eine natürliche oder juristische Person, die für alle Aspekte der Typgenehmigung eines Fahrzeugs, Systems, Bauteils oder einer selbstständigen technischen Einheit oder für die Fahrzeug-Einzelgenehmigung oder das Autorisierungsverfahren für Teile und Ausrüstungen, für die Gewährleistung der Übereinstimmung der Produktion und für die Angelegenheiten der Marktüberwachung im Zusammenhang mit diesem Fahrzeug, Bauteil, dieser selbstständigen technischen Einheit, diesem Teil und dieser Ausrüstung verantwortlich ist, und zwar unabhängig davon, ob diese Person unmittelbar an allen Phasen der Konstruktion und des Baus des Fahrzeugs, Systems, Bauteils oder der selbstständigen technischen Einheit beteiligt ist;

- 31. „ausländische Direktinvestition“ eine Investition, einschließlich Greenfield-Investitionen, in ein Ziel in der Union oder einen Vermögenswert in der Union durch einen ausländischen Investor oder dessen Tochtergesellschaft, die auf die Schaffung oder Aufrechterhaltung dauerhafter und direkter Beziehungen zwischen dem ausländischen Investor und dem Unternehmer oder Unternehmen, für den bzw. das das Kapital zur Verfügung gestellt wird, oder auf die Nutzung eines Vermögenswerts in der Union abzielt, um eine wirtschaftliche Tätigkeit in einem Mitgliedstaat auszuüben, einschließlich Investitionen, die eine effektive Beteiligung an der Verwaltung oder Kontrolle eines Unternehmens ermöglichen, das eine wirtschaftliche Tätigkeit ausübt;

- 32. „ausländischer Investor“ eine natürliche Person aus einem Drittstaat, die nicht die Staatsangehörigkeit eines Mitgliedstaats besitzt, oder ein Unternehmen aus einem Drittstaat, die bzw. das eine ausländische Direktinvestition plant oder getätigt hat;

- 33. „Tochterunternehmen eines ausländischen Investors“ ein Unternehmen, das unabhängig vom Ort seiner Niederlassung direkt oder indirekt von einem ausländischen Investor kontrolliert wird;

- 34. „Ziel in der Union“ ein Unternehmen, das nach den Rechtsvorschriften eines Mitgliedstaats gegründet wurde;

- 35. „Vermögenswert in der Union“ einen unbeweglichen Vermögenswert, der zur Herstellung von Produkten im Gebiet der Union verwendet wird oder verwendet werden soll;

- 36. „Arbeitnehmer aus der Union“ jede natürliche Person, die über einen Arbeitsvertrag im Sinne des geltenden Rechts, der Tarifverträge oder der Gepflogenheiten eines Mitgliedstaats verfügt oder in einem entsprechenden Beschäftigungsverhältnis steht und entweder Unionsbürger ist oder Drittstaatsangehöriger, der sich zum Zeitpunkt der Einstellung rechtmäßig in einem Mitgliedstaat aufhält und über eine gültige Arbeitserlaubnis verfügt;

- 37. „Portfolioinvestition“ den Erwerb von Wertpapieren von Unternehmen, die ausschließlich für Finanzanlagen bestimmt sind, ohne dass die Absicht besteht, die Verwaltung oder Kontrolle des Unternehmens zu beeinflussen;

- 38. „Umsatz“ die von einem Unternehmen im Sinne des Artikels 5 Absatz 1 der Verordnung (EG) Nr. 139/2004 des Rates^(59) erzielten Umsätze;

- 39. „Aktivmaterialien“ Materialien, deren chemische Reaktion elektrische Energie erzeugt, wenn sich die Batteriezelle entlädt, oder elektrische Energie speichert, wenn die Batterie geladen wird;

- 40. „Elektrofahrzeugbatterie“ eine Elektrofahrzeugbatterie im Sinne des Artikels 3 Absatz 1 Nummer 14 der Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates^(60);

- 41. „Lieferant“ einen in der Union ansässigen Hersteller, den Bevollmächtigten eines nicht in der Union ansässigen Herstellers oder einen Einführer, der ein Produkt auf dem Unionsmarkt in Verkehr bringt.

<a id="chapter-ii"></a>
## Kapitel II – GRUNDLEGENDE VORAUSSETZUNGEN FÜR DIE INDUSTRIELLE FERTIGUNG UND DIE DEKARBONISIERUNG

<a id="art-4"></a>
### Artikel 4 – Zentrale Zugangspunkte

(1) Die Mitgliedstaaten richten auf nationaler Ebene einen zentrale Zugangspunkt ein, über den Projektträger den in Artikel 5 Absatz 1 genannten Sammelantrag für industrielle Fertigungsprojekte einreichen können.

(2) Die zentralen Zugangspunkte weisen die Genehmigungsanträge automatisch der zuständigen Behörde zu, informieren den Antragsteller über sämtliche Schritte des Genehmigungsverfahrens, den Stand des Verfahrens und die Entscheidungen der zuständigen Behörden und geben dem Antragsteller die Möglichkeit, die Einhaltung der geltenden Fristen zu überprüfen. Zu diesem Zweck verwenden die zentralen Zugangspunkte die gemäß [dem Vorschlag für eine Verordnung über die Einrichtung europäischer Unternehmensbrieftaschen] eingerichteten europäischen Unternehmensbrieftaschen.

    Durch die Nutzung von europäischen Unternehmensbrieftaschen ermöglichen die zentralen Zugangspunkte Folgendes:

  - a) Interoperabilität und automatisierten Datenaustausch zwischen den zuständigen Behörden;

  - a) Weiterverwendung von Daten und Dokumenten, die sich bereits im Besitz von Behörden befinden;

  - b) ein hohes Maß an Cybersicherheit und Informationsintegrität;

  - c) Transparenz und Rechenschaftspflicht im Genehmigungsverfahren.

(3) Bei der Einrichtung der zentralen Zugangspunkte nutzen die Mitgliedstaaten gegebenenfalls die bestehenden digitalen Infrastrukturen, Kataloge und Bausteine der Union, die durch das Unionsrecht festgelegt sind.

<a id="art-5"></a>
### Artikel 5 – Genehmigungsverfahren

(1) Die Mitgliedstaaten richten ein einheitliches Genehmigungsverfahren auf der Grundlage von Sammelanträgen ein, die sämtliche für industrielle Fertigungsprojekte erforderlichen Genehmigungen abdecken.

(2) Die Mitgliedstaaten benennen eine zuständige Behörde, die das in Absatz 1 genannte Genehmigungsverfahren koordiniert, um die Annahme und den Erlass einer umfassenden Entscheidung innerhalb der geltenden Frist sicherzustellen.

(3) Spätestens 45 Tage nach Eingang des Genehmigungsantrags für industrielle Fertigungsprojekte bestätigt die zuständige Behörde entweder, dass der Antrag vollständig ist, oder sie fordert die zur Bearbeitung des Antrags erforderlichen fehlenden Informationen an.

    Wird der Antrag nach Übermittlung der fehlenden Informationen weiterhin als unvollständig erachtet, so kann die zuständige Behörde innerhalb von 30 Tagen nach Übermittlung der fehlenden Informationen die Informationen, die weiterhin fehlen, ein zweites Mal anfordern. Die zuständige Behörde darf keine Informationen in Bereichen anfordern, die nicht Gegenstand der ersten Anforderung zusätzlicher Informationen sind, und sie darf zusätzliche Informationen nur insoweit anfordern, wie dies zur Ergänzung der fehlenden Informationen erforderlich ist.

(4) Die Bestimmungen des vorliegenden Artikels finden keine Anwendung, wenn in anderen Rechtsakten der Union Vorschriften zur Straffung der Verwaltungs- und Genehmigungsverfahren für bestimmte Sektoren des verarbeitenden Gewerbes festgelegt sind.

<a id="art-6"></a>
### Artikel 6 – Projekte zur Dekarbonisierung energieintensiver Industrien

(1) Auf sämtliche Projekte zur Dekarbonisierung energieintensiver Industrien findet Kapitel II Abschnitt II der Verordnung (EU) 2024/1735 Anwendung.

(2) Für die Zwecke [des Artikels 14 des Vorschlags für eine Verordnung zur Beschleunigung von Umweltprüfungen] gelten sämtliche Projekte zur Dekarbonisierung energieintensiver Industrien als strategische Projekte, die zur Resilienz und Dekarbonisierung oder Ressourceneffizienz beitragen. Es gelten die Nummern I, II und III des Anhangs der genannten Verordnung.

<a id="chapter-iii"></a>
## Kapitel III – STÄRKUNG DER STRATEGISCHEN INDUSTRIELLEN WERTSCHÖPFUNGSKETTEN DER UNION

<a id="art-7"></a>
### Artikel 7 – Ursprung in der Union

(1) Für die Zwecke des vorliegenden Kapitels bezeichnet der Ausdruck „Inhalte mit Ursprung in der Union“ Inhalte, die aus der Union stammen.

(2) Die Bestimmung des Ursprungs von Produkten und Bauteilen erfolgt im Einklang mit der Verordnung (EU) Nr. 952/2013 des Europäischen Parlaments und des Rates.

<a id="art-8"></a>
### Artikel 8 – Gleichwertigkeit von Inhalten hinsichtlich des Ursprungs in der Union bei der Vergabe öffentlicher Aufträge

(1) In Bezug auf die in Artikel 11 genannten Anforderungen hinsichtlich des Ursprungs in der Union gelten Inhalte mit Ursprung in Drittländern, mit denen die Union ein Abkommen zur Errichtung einer Freihandelszone oder Zollunion geschlossen hat oder die Vertragsparteien des Übereinkommens über das öffentliche Beschaffungswesen sind, sofern einschlägige Verpflichtungen der Union im Rahmen dieses Abkommens bestehen, als Inhalte mit Ursprung in der Union.

(2) Die Kommission erlässt delegierte Rechtsakte gemäß Artikel 30, um ein Drittland auf der Grundlage eines der folgenden Kriterien ganz oder teilweise vom Anwendungsbereich des Absatzes 1 auszunehmen:

  - a) Das betreffende Drittland hat in Bezug auf einen der in Anhang I aufgeführten Sektoren keine Inländerbehandlung für Produkte oder Einrichtungen aus der Union im Rahmen der in Absatz 1 genannten Abkommen gewährt;

  - b) eine solche Ausnahme ist gerechtfertigt, um Abhängigkeiten oder sonstige Entwicklungen zu vermeiden, die die Versorgungssicherheit der Union bei den betreffenden Produkten gefährden könnten;

  - c) eine solche Ausnahme ist aufgrund einer anderen Ausnahme gemäß dem geltenden Abkommen gerechtfertigt.

<a id="art-9"></a>
### Artikel 9 – Gleichwertigkeit von Inhalten hinsichtlich des Ursprungs in der Union bei anderen Formen der öffentlichen Intervention

(1) In Bezug auf die in Artikel 12 genannten Anforderungen hinsichtlich des Ursprungs in der Union gelten Inhalte mit Ursprung in Drittländern, mit denen die Union ein Abkommen zur Errichtung einer Freihandelszone oder Zollunion geschlossen hat, als Inhalte mit Ursprung in der Union.

(2) Die Kommission erlässt delegierte Rechtsakte gemäß Artikel 30, um ein Drittland auf der Grundlage eines der folgenden Kriterien ganz oder teilweise vom Anwendungsbereich des Absatzes 1 auszunehmen:

  - a) Das betreffende Drittland hat in Bezug auf einen der in Anhang I aufgeführten Sektoren keine Inländerbehandlung für Produkte oder Einrichtungen aus der Union im Rahmen der in Absatz 1 genannten Abkommen gewährt;

  - b) eine solche Ausnahme ist gerechtfertigt, um Abhängigkeiten oder sonstige Entwicklungen zu vermeiden, die die Versorgungssicherheit der Union bei den betreffenden Produkten gefährden könnten;

  - c) eine solche Ausnahme ist aufgrund einer anderen Ausnahme gemäß dem geltenden Abkommen gerechtfertigt.

<a id="art-10"></a>
### Artikel 10 – CO2-arme Produkte

(1) Für die Zwecke des vorliegenden Kapitels gilt ein unter Anhang II fallendes Produkt als CO2-arm, wenn es den Anforderungen der folgenden delegierten Rechtsakte entspricht:

  - a) Bauprodukte im Sinne der Verordnung (EU) 2024/3110, die einer harmonisierten technischen Spezifikation oder einer europäischen technischen Bewertung unterliegen, wenn sie den Anforderungen der gemäß Artikel 5 Absatz 5 oder Artikel 22 Absatz 9 der Verordnung (EU) 2024/3110 erlassenen delegierten Rechtsakte unterliegen;

  - b) alle anderen Produkte, wenn sie den Anforderungen der delegierten Rechtsakte, die gemäß Artikel 4 der Verordnung (EU) 2024/1781 erlassen wurden, soweit zutreffend, unterliegen.

(2) Um die Schaffung von Leitmärkten durch fundierte Investitionsentscheidungen zugunsten von Produkten mit einer niedrigeren Leistungsklasse für die Treibhausgasintensität zu unterstützen, wird der Kommission die Befugnis übertragen, gemäß Artikel 30 delegierte Rechtsakte zu erlassen, um diese Verordnung durch die Einrichtung freiwilliger Klassifizierungssysteme auf der Grundlage der Treibhausgasintensität für Produkte zu ergänzen, die im Rahmen der in Anhang I der Richtlinie 2003/87/EG aufgeführten Tätigkeiten hergestellt werden (im Folgenden „Industrieprodukte“), wenn diese Produkte in der Union in Verkehr gebracht werden, soweit diese Produkte nicht bereits durch einen delegierten Rechtsakt gemäß der Verordnung (EU) 2024/1781 geregelt oder in den gemäß der genannten Verordnung angenommenen Arbeitsplänen enthalten sind.

    Die Emissionen und alle anderen einschlägigen Daten, die für die Berechnung der Treibhausgasintensität herangezogen werden, werden von Prüfstellen geprüft, die gemäß der Durchführungsverordnung (EU) 2018/2067 der Kommission^(61) oder gegebenenfalls gemäß den nach Artikel 18 der Verordnung (EU) 2023/956 des Europäischen Parlaments und des Rates erlassenen delegierten Rechtsakten akkreditiert sind. Die Überwachung der Emissionen erfolgt im Einklang mit den Vorschriften in Kapitel III der Durchführungsverordnung (EU) 2018/2066 der Kommission sowie den in Anhang VII der Delegierten Verordnung (EU) 2019/331 festgelegten Datenüberwachungsmethoden und Qualitätsanforderungen. Bei eingeführten Produkten können die Emissionen gemäß Anhang IV der Verordnung (EU) 2023/956 sowie gemäß den Datenüberwachungsmethoden und Qualitätsanforderungen überwacht werden, die in den Durchführungsrechtsakten festgelegt sind, die gemäß Artikel 7 Absatz 7 Buchstabe a der Verordnung (EU) 2023/956 erlassen wurden, sofern darin ein gleichwertiger Datensatz vorgesehen ist.

    In diesen delegierten Rechtsakten ist gegebenenfalls Folgendes festgelegt:

  - a) die Produkte, für die Hersteller eine Kennzeichnung der Treibhausgasintensität beantragen können;

  - b) die relevanten Systemgrenzen, die Emissionen aus dem industriellen Fertigungsprozess, Emissionen aus relevanten Vorläuferstoffen und Emissionen aus dem Stromverbrauch umfassen. Diese Emissionen werden unabhängig davon berücksichtigt, ob sie in der Anlage des Herstellers oder in anderen Anlagen entstehen, wobei zu berücksichtigen ist, dass bestimmte Vorläuferstoffe aus anderen Anlagen bezogen werden können;

  - c) die Methode zur Berechnung der Treibhausgasintensität des Produkts;

  - d) die Einstufung nach Leistungsklassen;

  - e) ergänzende Vorschriften zur Verwaltung der Kennzeichnung, einschließlich der zuständigen Stellen;

  - f) ergänzende Vorschriften zur Akkreditierung, Überwachung und Überprüfung.

    Bei der Ausarbeitung dieser Vorschriften berücksichtigt die Kommission mindestens Folgendes:

  - a) die aktuellsten anwendbaren Produkt-Benchmarks im Sinne der Richtlinie 2003/87/EG;

  - b) Daten, die bereits im Rahmen des EU-EHS und des CBAM verfügbar sind;

  - c) neue Unionsvorschriften zur Anrechnung von Emissionen, einschließlich solcher aus dem Stromverbrauch, aus CO2-armen Kraftstoffen und aus erneuerbaren Kraftstoffen nicht biogenen Ursprungs;

  - d) aufstrebende CO2-arme Produktionstechnologien sowie das geschätzte Emissionsminderungspotenzial dieser Technologien;

  - e) die Notwendigkeit, für alle Produktionswege Anreize für die Verwendung recycelter Materialien zu schaffen;

  - f) die Angleichung an die Ziele der Klimaneutralität, wie sie in der Verordnung (EU) 2021/1119 des Europäischen Parlaments und des Rates^(62) festgelegt sind.

<a id="art-11"></a>
### Artikel 11 – Vergabe öffentlicher Aufträge

(1) Öffentliche Auftraggeber und Auftraggeber schließen solche Angebote von den in Anhang II Teil I und Anhang III Teil I genannten Vergabeverfahren aus, die von Wirtschaftsteilnehmern eingereicht werden, die im Eigentum oder unter der Kontrolle einer Einrichtung stehen, die in einem Drittland niedergelassen ist, das kein internationales Abkommen mit der Union geschlossen hat, das den Zugang zu diesen Vergabeverfahren garantiert.

(2) Bei den in Anhang II Teil I und Anhang III Teil I genannten Verfahren zur Vergabe öffentlicher Aufträge wenden öffentliche Auftraggeber und Auftraggeber die darin festgelegten Anforderungen hinsichtlich des Ursprungs in der Union und des CO2-Ausstoßes gemäß den Artikeln 8 und 10 an.

(3) Öffentliche Auftraggeber und Auftraggeber können beschließen, die Anforderungen der Anhänge II und III nicht anzuwenden, wenn eine der folgenden Bedingungen erfüllt ist:

  - a) Die benötigten Produkte oder Dienstleistungen können nur von einem spezifischen Wirtschaftsteilnehmer geliefert werden, es gibt keine vernünftige Alternative oder Ersatzlösung und der fehlende Wettbewerb ist nicht das Ergebnis einer künstlichen Einschränkung der Parameter des Verfahrens zur Vergabe öffentlicher Aufträge;

  - b) es wurden keine geeigneten Angebote oder keine geeigneten Teilnahmeanträge eingereicht, auch nicht bei einem ähnlichen früheren Verfahren zur Vergabe öffentlicher Aufträge, das von demselben öffentlichen Auftraggeber oder Auftraggeber in den zwei Jahren vor Beginn des geplanten neuen Vergabeverfahrens eingeleitet wurde;

  - c) ihre Anwendung würde den öffentlichen Auftraggeber oder den Auftraggeber dazu verpflichten, Waren, Dienstleistungen oder Bauleistungen zu erwerben, die unverhältnismäßige Kosten verursachen würden, oder zu technischer Inkompatibilität bei Betrieb und Wartung führen. Kostenunterschiede, die auf der Grundlage von objektiven und transparenten Daten auf über 25 % geschätzt werden, können von öffentlichen Auftraggebern und Auftraggebern als unverhältnismäßig angesehen werden.

(4) Öffentliche Auftraggeber und Auftraggeber verlangen von Wirtschaftsteilnehmern, die Produkte anbieten oder Dienstleistungen erbringen, eine Eigenerklärung oder ein gleichwertiges Dokument zum Nachweis der Erfüllung der in diesem Artikel festgelegten Anforderungen.

<a id="art-12"></a>
### Artikel 12 – Andere Formen der öffentlichen Intervention

(1) Unbeschadet der Artikel 107 und 108 AEUV gestalten die Mitgliedstaaten staatliche Förderregelungen so, dass sie im Einklang mit den Artikeln 9 und 10 und unbeschadet des Artikels 13 zu dem Ziel beitragen, die strategischen industriellen Wertschöpfungsketten der Union durch die in Anhang II Teil II bzw. Anhang III Teil II festgelegten Anforderungen hinsichtlich des Ursprungs in der Union und/oder des CO2-Ausstoßes zu stärken.

    Die Mitgliedstaaten wenden die in Unterabsatz 1 genannten Anforderungen auf staatliche Förderregelungen an, auf die mindestens 45 % der gesamten nationalen Mittel entfallen, die für die unter Anhang II Teil II fallenden staatlichen Förderregelungen bereitgestellt werden, sowie auf staatliche Förderregelungen, auf die 100 % der gesamten nationalen Mittel entfallen, die für die unter Anhang III Teil II fallenden staatlichen Förderregelungen bereitgestellt werden.

(2) Bei der Konzeption und Umsetzung einer staatlichen Förderregelung, die unter Anhang II Teil II bzw. Anhang III Teil II fällt, bewertet die zuständige Behörde den Beitrag von Produkten und Technologien zu dem darin festgelegten Gesamtziel auf der Grundlage eines offenen, diskriminierungsfreien und transparenten Verfahrens.

(3) Die zuständige Behörde kann weiterhin Förderregelungen anwenden, die den Anforderungen in Anhang II Teil II bzw. Anhang III Teil II ganz oder teilweise nicht entsprechen, wenn die Anwendung dieser Anforderungen

  - a) aufgrund der Nichtverfügbarkeit der benötigten Bauteile oder Endprodukte zu erheblichen Verzögerungen führen würde. Verzögerungen, die auf der Grundlage objektiver, transparenter und überprüfbarer Daten auf mehr als sieben Monate geschätzt werden, können als erheblich angesehen werden;

  - b) unverhältnismäßige Kosten verursachen würde. Unverhältnismäßige Kosten liegen vor, wenn auf der Grundlage objektiver, transparenter und überprüfbarer Daten davon ausgegangen werden kann, dass sich die Kosten des zugrunde liegenden Endprodukts oder der zugrunde liegenden Technologie durch die Einhaltung der Vorschriften um mehr als 30 % erhöhen.

<a id="art-13"></a>
### Artikel 13 – Finanzielle Unterstützung für Unternehmensfahrzeuge

  Für die Zwecke des Artikels 4 [des Vorschlags für eine Verordnung vom 16. Dezember 2025 über saubere Unternehmensfahrzeuge] muss das Kriterium „in der Europäischen Union hergestellt“ für die Gewährung finanzieller Unterstützung für den Einsatz von Personenkraftwagen und leichten Nutzfahrzeugen durch Unternehmen mit den in Anhang III Teil II der vorliegenden Verordnung festgelegten Kriterien übereinstimmen.

  Das Kriterium „in der Europäischen Union hergestellt“ gilt als gleichwertig mit dem in Artikel 7 der vorliegenden Verordnung genannten Kriterium „Ursprung in der Union“.

<a id="art-14"></a>
### Artikel 14 – Gutschriften für die Einhaltung von CO2-Emissionsnormen

(1) Für die Zwecke des Artikels 5 Absätze 1 und 2 der Verordnung (EU) 2019/631 [in der durch den Vorschlag für eine Verordnung vom 16. Dezember 2025 zur Änderung der Verordnung (EU) 2019/631 in Bezug auf CO2-Emissionsnormen für neue leichte Nutzfahrzeuge und die Fahrzeugkennzeichnung geänderten Fassung] muss das Kriterium „in der Europäischen Union hergestellt“ für kleine emissionsfreie Fahrzeuge mit den in Anhang III Teil III der vorliegenden Verordnung festgelegten Kriterien übereinstimmen.

    Das Kriterium „in der Europäischen Union hergestellt“ gilt als gleichwertig mit dem in Artikel 7 der vorliegenden Verordnung genannten Kriterium „Ursprung in der Union“.

(2) Für die Zwecke des Artikels 5b der Verordnung (EU) 2019/631 [in der durch den Vorschlag für eine Verordnung vom 16. Dezember 2025 zur Änderung der Verordnung (EU) 2019/631 in Bezug auf CO2-Emissionsnormen für neue leichte Nutzfahrzeuge und die Fahrzeugkennzeichnung geänderten Fassung] ist der Ausdruck „in der EU hergestellter kohlenstoffarmer Stahl“ wie folgt zu verstehen:

  - a) „kohlenstoffarm“ stimmt mit den Bedingungen in Artikel 10 Absatz 1 der vorliegenden Verordnung überein;

  - b) „in der EU hergestellt“ ist gleichwertig mit dem in Artikel 7 der vorliegenden Verordnung genannten Kriterium „Ursprung in der Union“.

<a id="art-15"></a>
### Artikel 15 – Bescheinigung der Übereinstimmung eines Fahrzeugs mit den Anforderungen hinsichtlich des Ursprungs in der Union

  Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach Inkrafttreten dieser Verordnung] legen die Hersteller bei der Ausstellung einer Übereinstimmungsbescheinigung gemäß den Artikeln 36 und 37 der Verordnung (EU) 2018/858 für Fahrzeuge, die den einschlägigen Anforderungen hinsichtlich des Ursprungs in der Union gemäß Anhang III der vorliegenden Verordnung entsprechen, ein Begleitdokument vor, mit dem die Übereinstimmung des Fahrzeugs bescheinigt wird.

<a id="art-16"></a>
### Artikel 16 – Übertragung von Befugnissen

(1) Der Kommission wird die Befugnis übertragen, gemäß Artikel 30 delegierte Rechtsakte zur Ergänzung der vorliegenden Verordnung um die Festlegung von nachfrageseitigen Maßnahmen auf Unionsebene für Produkte der chemischen Industrie zu erlassen, mit dem Ziel, folgende Tätigkeiten zu fördern:

  - a) die Herstellung und den Verkauf von Stoffen und Gemischen mit Ursprung in der Union, die aus nachhaltigen Kohlenstoffquellen gewonnen werden;

  - b) die Verwendung von aus nachhaltigen Kohlenstoffquellen gewonnenen Stoffen und Gemischen mit Ursprung in der Union in Produkten, die auf dem Markt bereitgestellt werden.

    Bei der Ausarbeitung der delegierten Rechtsakte sollte die Kommission Folgendes berücksichtigen:

  - a) den Beitrag der Anforderungen zum Ziel der Union hinsichtlich wirtschaftlicher Sicherheit, Resilienz und Klimaneutralität, wie in der Verordnung (EU) 2021/1119 festgelegt;

  - b) die durch Überwachungstätigkeiten festgestellte Marktlage auf Unionsebene, einschließlich rückläufiger Anteile am Unionsmarkt und einer Unterauslastung der Produktionskapazitäten des Wirtschaftszweigs der Union;

  - c) die Auswirkungen der Festlegung solcher Maßnahmen auf die allgemeine Wettbewerbsfähigkeit und die Treibhausgasemissionen der betreffenden Sektoren, auf die Kosten für nachgelagerte Verbraucher und für kleine und mittlere Unternehmen sowie auf die öffentlichen Haushalte.

(2) Der Kommission wird die Befugnis übertragen, gemäß Artikel 30 delegierte Rechtsakte zur Änderung von Anhang II und/oder Anhang III in Bezug auf die Anforderungen hinsichtlich des Ursprungs in der Union und/oder die Anforderungen an den CO2-Ausstoß für die dort genannten Produkte zu erlassen, wobei folgende Aspekte zu berücksichtigen sind:

  - a) die durch Überwachungstätigkeiten festgestellte Marktlage auf Unionsebene, einschließlich rückläufiger Anteile am Unionsmarkt und einer Unterauslastung der Produktionskapazitäten des Wirtschaftszweigs der Union;

  - b) der technologische Fortschritt;

  - c) der Beitrag der Anforderungen zum Ziel der Union hinsichtlich öffentlicher Ordnung, wirtschaftlicher Sicherheit, Resilienz und Klimaneutralität, wie in der Verordnung (EU) 2021/1119 festgelegt;

  - d) die Nachfrage nach den entsprechenden Produkten oder Technologien, die durch das Wachstum der nachgelagerten Sektoren angetrieben wird;

  - e) der Anteil des Produkts oder der Technologie am Gesamtproduktionswert des nachgelagerten Sektors;

  - f) die Auswirkungen der Festlegung von Anforderungen hinsichtlich des Ursprungs in der Union und/oder des CO2-Ausstoßes auf die allgemeine Wettbewerbsfähigkeit und die Treibhausgasemissionen der betreffenden Sektoren sowie auf die Kosten für nachgelagerte Verbraucher, kleine und mittlere Unternehmen und die öffentlichen Haushalte.

(3) Der Kommission wird die Befugnis übertragen, gemäß Artikel 31 Absatz 2 Durchführungsrechtsakte zur Festlegung der Methode zur Berechnung des mengenmäßigen Anteils von Produkten und Bauteilen mit Ursprung in der Union gemäß der Verordnung (EU) Nr. 952/2013 und gegebenenfalls zur Festlegung der Verwendung standardisierter Muster für Konformitätsbescheinigungen zu erlassen.

    In den in Unterabsatz 1 genannten Durchführungsrechtsakten können auch die Methoden und Verfahren festgelegt werden, die von den jeweils zuständigen nationalen Behörden, einschließlich öffentlicher Auftraggeber und Auftraggeber, anzuwenden sind, um die Einhaltung der in der vorliegenden Verordnung festgelegten Anforderungen zu überprüfen und gegebenenfalls digitale Instrumente für die Zwecke der Berechnung, der Überprüfung und des Nachweises der Einhaltung zu nutzen.

<a id="chapter-iv"></a>
## Kapitel IV – BEITRAG AUSLÄNDISCHER INVESTITIONEN

<a id="art-17"></a>
### Artikel 17 – Anwendungsbereich

(1) Dieses Kapitel gilt für ausländische Direktinvestitionen im Wert von mehr als 100 Mio. EUR in den in Absatz 2 genannten aufstrebenden strategischen Sektoren des verarbeitenden Gewerbes, sofern mehr als 40 % der globalen Fertigungskapazität in dem Drittland liegen, dessen Staatsangehörigkeit der ausländische Investor besitzt oder – wenn es sich bei dem ausländischen Investor um ein Unternehmen handelt – in dem das Unternehmen niedergelassen ist.

    Solche Investitionen dürfen nur durchgeführt werden, wenn sie von der in Artikel 19 genannten Investitionsbehörde oder der Europäischen Kommission gemäß den Bestimmungen dieses Kapitels ausdrücklich genehmigt wurden.

(2) Dieses Kapitel gilt für ausländische Direktinvestitionen in das verarbeitende Gewerbe in einem der folgenden aufstrebenden strategischen Sektoren:

  - a) Batterietechnologien und ihre Wertschöpfungskette für Batterie-Energiespeichersysteme;

  - b) reine Elektrofahrzeuge, extern aufladbare Hybridelektrofahrzeuge und Elektrofahrzeuge mit Brennstoffzellenantrieb, einschließlich Bauteilen im Zusammenhang mit der Elektrifizierung und Digitalisierung;

  - c) Photovoltaiktechnologien;

  - d) Gewinnung, Verarbeitung und Recycling kritischer Rohstoffe.

(3) Dieses Kapitel gilt nicht für

  - a) Investoren und Investitionen, die unter geltende oder von der Union vorläufig angewandte Wirtschaftspartnerschafts- und Freihandelsabkommen fallen, soweit im Rahmen dieser Abkommen einschlägige Verpflichtungen eingegangen wurden, einschließlich Investitionen, die von den in der Union ansässigen Tochtergesellschaften solcher ausländischer Investoren getätigt werden;

  - b) Investitionen, die auf die Erbringung von Dienstleistungen abzielen, einschließlich Investitionen, die von den in der Union ansässigen Tochtergesellschaften der Investoren getätigt werden;

  - c) Portfolioinvestitionen.

<a id="art-18"></a>
### Artikel 18 – Kriterien für ausländische Direktinvestitionen mit Wertschöpfung

(1) Die Mitgliedstaaten benennen bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = ein Monat nach Inkrafttreten dieser Verordnung] eine Investitionsbehörde, die mit der Überprüfung ausländischer Direktinvestitionen und der Umsetzung der Bestimmungen dieses Kapitels betraut ist.

    Die Mitgliedstaaten statten diese Investitionsbehörde mit den erforderlichen Ressourcen sowie den rechtlichen und administrativen Mitteln zur Wahrnehmung der in dieser Verordnung festgelegten Aufgaben aus.

(2) Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = 12 Monate nach Inkrafttreten dieser Verordnung] genehmigen die Investitionsbehörden nur noch ausländische Direktinvestitionen, die direkt von ausländischen Investoren getätigt werden und mindestens vier der folgenden sechs Bedingungen erfüllen:

  - a) Beteiligungen, die mehr als 49 % des Aktienkapitals, der Stimmrechte oder gleichwertiger Beteiligungen an einem Ziel in der Union ausmachen, oder gleichwertige Eigentums-, Pacht- oder sonstige Rechte, die die Kontrolle über einen Vermögenswert in der Union begründen, werden vom ausländischen Investor nicht erworben, gehalten oder ausgeübt;

  - b) der ausländische Investor tätigt die Direktinvestition über ein Joint Venture mit einem oder mehreren in der Union ansässigen Unternehmen, wobei der ausländische Investor nicht mehr als 49 % des Aktienkapitals, der Stimmrechte oder gleichwertiger Beteiligungen oder anderer Rechte hält, die die Kontrolle über eines der an dem Joint Venture beteiligten in der Union ansässigen Unternehmen begründen. Solche Joint Ventures werden so strukturiert, dass eine wirksame Beteiligung der Partner aus der Union an Verwaltung, Technologietransfer und Kapazitätsaufbau gewährleistet ist;

  - c) der ausländische Investor hat eine Vereinbarung über die Lizenzierung seiner Rechte des geistigen Eigentums und seines Know-hows zugunsten des Ziels in der Union oder des Vermögenswerts in der Union geschlossen, damit dieses bzw. dieser seine wirtschaftlichen Tätigkeiten im Zusammenhang mit der ausländischen Direktinvestition ausüben kann. Alle Rechte des geistigen Eigentums oder Vermögenswerte, die vom Ziel in der Union oder der juristischen Person, die Eigentümerin des Vermögenswerts in der Union ist, vor der ausländischen Investition oder ohne Mitwirkung des ausländischen Investors entwickelt wurden, stehen vollständig und ausschließlich im Eigentum des Ziels in der Union oder der juristischen Person, die Eigentümerin des Vermögenswerts in der Union ist. Alle Rechte des geistigen Eigentums oder Vermögenswerte, die entweder in diesem Zusammenhang im Rahmen einer Zusammenarbeit mit den sonstigen Vermögenswerten des ausländischen Investors entstanden sind oder – im Falle von Buchstabe b – vom Joint Venture entwickelt wurden, stehen im gemeinsamen Eigentum des ausländischen Investors und des Ziels in der Union, des Joint Ventures im Sinne des Buchstabens b oder der juristischen Person, die Eigentümerin des Vermögenswerts in der Union ist;

  - d) der ausländische Investor wendet jährlich einen Betrag in Höhe von mindestens 1 % des Bruttojahresumsatzes des Ziels in der Union oder des durch den Vermögenswert in der Union erzielten Bruttojahresumsatzes für Forschungs- und Entwicklungsausgaben in der Union auf, wobei dieser Betrag im Verhältnis zum Kontrollanteil des ausländischen Investors anzuwenden ist;

  - e) mindestens 50 % der im Zusammenhang mit der ausländischen Direktinvestition beschäftigten Arbeitskräfte bestehen zum Zeitpunkt der Investition und während des gesamten Betriebs aus Arbeitnehmern aus der Union, und zwar in allen Kategorien der Belegschaft, einschließlich operativer, technischer, aufsichtlicher und leitender Positionen. Dies geht mit angemessenen Schulungen und kapazitätsbildenden Maßnahmen einher. Wird ein Ziel in der Union oder ein Vermögenswert in der Union erworben, das bzw. der bereits vor der Investition Fertigungstätigkeiten ausübte, auch nach einer Insolvenz, so wird dem Erhalt der bestehenden Belegschaft bzw. der Wiedereinstellung früherer Arbeitskräfte gemäß den nationalen Rechtsvorschriften und geltenden Tarifverträgen Vorrang eingeräumt. Für den Fall, dass der ausländische Investor, das Ziel in der Union oder der Vermögenswert in der Union ungeachtet des Artikels 107 AEUV öffentliche Mittel erhält, verpflichtet sich der ausländische Investor, das Ziel in der Union oder der Vermögenswert in der Union, die Zahl der Arbeitnehmer aus der Union für einen Zeitraum von fünf Jahren nicht zu verringern; andernfalls werden die gewährten Mittel von den zuständigen nationalen Behörden zurückgefordert;

  - f) im Zusammenhang mit der ausländischen Direktinvestition erstellt und veröffentlicht der ausländische Investor auf seiner Website eine Strategie zur Verbesserung der Wertschöpfungsketten der Union und zur Priorisierung des Bezugs von Inputs für die Fertigungstätigkeit aus der Union und bemüht sich, mindestens 30 % der Inputs, die für die in der Union in Verkehr gebrachten Produkte verwendet werden, aus der Union zu beziehen.

(3) Die ausländische Direktinvestition muss die Bedingung nach Absatz 2 Buchstabe e erfüllen, damit sie von der Investitionsbehörde gemäß Absatz 2 genehmigt wird.

(4) Die Investitionsbehörden können einige oder alle der in Absatz 2 genannten Bedingungen auf Direktinvestitionen anwenden, die von einem Tochterunternehmen eines ausländischen Investors innerhalb der Union getätigt werden, sofern dies zur Erreichung der Ziele dieser Verordnung unerlässlich ist, wenn

  - a) eine Umgehung dieser Verordnung durch den ausländischen Investor verhindert werden soll oder

  - b) wenn nach vernünftigem Ermessen keine alternativen, die Direktinvestitionen innerhalb der Union weniger beschränkenden Maßnahmen, einschließlich von dem ausländischen Investor oder seinem Tochterunternehmen vorgeschlagenen Verpflichtungen, zur Verfügung stehen, um die Ziele der Verordnung zu erreichen.

(5) Die Kommission erlässt bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach Inkrafttreten dieser Verordnung] einen Durchführungsrechtsakt mit detaillierten Vorschriften für die Überprüfung der Einhaltung der in Absatz 2 festgelegten Bedingungen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 31 Absatz 3 genannten Prüfverfahren erlassen.

<a id="art-19"></a>
### Artikel 19 – Anmeldung geplanter ausländischer Direktinvestitionen

(1) Der ausländische Investor meldet jede geplante Direktinvestition im Anwendungsbereich des Artikels 17, die zu einer Kontrolle über das Ziel in der Union oder den Vermögenswert in der Union gemäß Absatz 3 führen würde, bei der Investitionsbehörde des Mitgliedstaats an, in dem sich das Ziel in der Union oder der Vermögenswert in der Union befindet.

    Die Anmeldung enthält alle Informationen, die erforderlich sind, damit die Investitionsaufsichtsbehörde die Überprüfung der Investition gemäß Artikel 20 durchführen kann.

(2) Bei der Feststellung, ob der Investitionswert den in Artikel 17 Absatz 1 festgelegten Schwellenwert erreicht, werden nur frühere Investitionen des ausländischen Investors in dasselbe Ziel in der Union oder denselben Vermögenswert in der Union berücksichtigt, die der ausländische Investor ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = Datum des Inkrafttretens dieser Verordnung] getätigt hat.

(3) Ausländische Investoren gelten als kontrollierend, wenn die betreffende Investition einen der folgenden Schwellenwerte erreicht:

  - a) mindestens 30 % des Aktienkapitals oder der Stimmrechte an einem Ziel in der Union;

  - b) mindestens 30 % des Eigentums an einem Vermögenswert in der Union sowie der Pacht- oder sonstigen Rechte, die die Kontrolle über einen Vermögenswert in der Union begründen.

(4) In Fällen, in denen der Erwerb oder die Niederlassung einer Investition durch einen ausländischen Investor dazu führt, dass ausländische Investoren gemeinsam mehr als die in Absatz 3 festgelegten Eigentums- oder Kontrollschwellen halten, wird der Erwerb oder die Niederlassung angemeldet.

(5) Bei der Berechnung, ob einer der in Absatz 3 festgelegten Schwellenwerte erreicht wurde, werden die direkt oder indirekt gehaltenen aggregierten Beteiligungen, auch über verbundene Unternehmen, Beteiligungsketten oder gemeinsam handelnde ausländische Investoren, berücksichtigt.

(6) Befinden sich die betreffenden Ziele oder Vermögenswerte in der Union in mehr als einem Mitgliedstaat, so übermittelt der ausländische Investor am selben Tag eine Anmeldung unter Bezugnahme auf die anderen Anmeldungen an die zuständigen Investitionsbehörden aller betroffenen Mitgliedstaaten sowie an die Kommission. Die betroffenen Mitgliedstaaten koordinieren die Prüfung dieser Anmeldungen und einigen sich mit den anderen betreffenden Mitgliedstaaten sowie mit der Kommission auf die aufzuerlegenden Bedingungen.

    Die Kommission beschließt, welche Bedingungen auf die ausländische Direktinvestition anzuwenden sind, falls zwischen den betreffenden Mitgliedstaaten keine Einigung erzielt wird.

    Gemäß Unterabsatz 1 angemeldete ausländische Direktinvestitionen erfüllen in allen betroffenen Mitgliedstaaten die in Artikel 18 festgelegten Bedingungen.

<a id="art-20"></a>
### Artikel 20 – Überprüfung und Genehmigung

(1) Die Investitionsbehörde entscheidet innerhalb von 30 Tagen nach Eingang der Mitteilung über die Zulässigkeit der Mitteilung gemäß den Artikeln 17 und 19. Diese Frist kann um weitere 15 Tage verlängert werden, wenn die Investitionsbehörde zufriedenstellend nachweist, dass eine Verlängerung aufgrund der Umstände gerechtfertigt ist.

    Entscheidet die Investitionsbehörde, dass eine Anmeldung zulässig ist, so leitet sie die vollständige Anmeldung einschließlich aller eingegangenen Unterlagen unverzüglich an die Kommission weiter.

(2) Innerhalb von 30 Tagen nach Erhalt der Anmeldung kann die Kommission schriftlich dazu Stellung nehmen, ob die ausländische Direktinvestition in den Anwendungsbereich der Artikel 17 und 19 fällt, ob sie die in Artikel 18 Absatz 2 festgelegten Bedingungen erfüllt und ob sie von der Investitionsbehörde genehmigt werden sollte oder nicht.

    Gibt die Kommission eine schriftliche Stellungnahme ab, so übermittelt sie diese unverzüglich der Investitionsbehörde. Die Kommission kann die schriftliche Stellungnahme unter gebührender Berücksichtigung der Vertraulichkeit an die Investitionsbehörden anderer Mitgliedstaaten weiterleiten oder auf ihrer offiziellen Website veröffentlichen.

(3) Sobald die Stellungnahme der Kommission eingegangen oder die in Absatz 2 genannte Frist abgelaufen ist, und spätestens 60 Tage – bzw. 75 Tage, falls die Frist gemäß Absatz 1 verlängert wurde – nach Eingang der Anmeldung erlässt die Investitionsbehörde eine begründete Entscheidung über die Genehmigung bzw. Ablehnung der ausländischen Direktinvestition. Die Investitionsbehörde genehmigt die ausländische Direktinvestition, wenn vier der sechs in Artikel 18 genannten Bedingungen erfüllt sind. Die Frist für den Erlass der begründeten Entscheidung kann um weitere 30 Tage verlängert werden, wenn die Investitionsbehörde zufriedenstellend nachweist, dass eine Verlängerung aufgrund der Umstände gerechtfertigt ist.

    Die Investitionsbehörde teilt der Kommission die begründete Entscheidung innerhalb von drei Tagen nach ihrem Erlass mit.

(4) Erlässt die Investitionsbehörde eine Entscheidung, die hinsichtlich der Übereinstimmung der ausländischen Direktinvestition mit den in Artikel 18 festgelegten Bedingungen von der Stellungnahme der Kommission abweicht, so prüft die Investitionsbehörde die Anmeldung innerhalb einer zusätzlichen Frist von zwei Monaten eingehender, und die Entscheidung tritt erst nach Ablauf dieser Frist in Kraft.

    Die Investitionsbehörde legt in ihrer gemäß Absatz 3 erlassenen begründeten Entscheidung dar, inwiefern die Stellungnahme der Kommission berücksichtigt wurde.

(5) Im Hinblick auf die Überprüfung der fortdauernden Erfüllung der in Artikel 18 festgelegten Bedingungen erlegt die Investitionsbehörde dem betreffenden Investor in ihrer Entscheidung über die Genehmigung der Investition Berichtspflichten auf.

(6) Jede Partei, gegen die eine Entscheidung nach Absatz 1 oder Absatz 3 ergangen ist, hat das Recht, gegen diese Entscheidung Rechtsmittel einzulegen.

<a id="art-21"></a>
### Artikel 21 – Überprüfung ausländischer Direktinvestitionen durch die Kommission

(1) Im Anschluss an die in Artikel 19 Absatz 1 genannte Anmeldung kann die Kommission beschließen, die ausländische Direktinvestition zu prüfen, und zwar

  - a) von sich aus, wenn die ausländische Direktinvestition das Potenzial hat, die Wertschöpfung auf dem Unionsmarkt erheblich zu beeinflussen,

  - b) auf Ersuchen der für die Bearbeitung der Anmeldung zuständigen Investitionsbehörde oder einer Investitionsbehörde eines anderen Mitgliedstaats, in dessen Hoheitsgebiet die betreffende ausländische Direktinvestition erhebliche Auswirkungen hätte, oder

  - c) von sich aus, wenn der Wert der ausländischen Direktinvestition 1 Mrd. EUR übersteigt.

(2) Für die Zwecke des Absatzes 1 wird in jedem der folgenden Fälle davon ausgegangen, dass die ausländische Direktinvestition das Potenzial hat, die Wertschöpfung im Binnenmarkt erheblich zu beeinflussen:

  - a) Sie ist für den Binnenmarkt von besonderer strategischer Bedeutung;

  - b) sie hat erhebliche wirtschaftliche Auswirkungen im Hoheitsgebiet von mehr als einem Mitgliedstaat;

  - c) sie birgt ein hohes Risiko, dass die Versorgungssicherheit des betreffenden aufstrebenden strategischen Sektors oder der damit verbundenen Wertschöpfungsketten in der Union oder die Sicherheit in mehr als einem Mitgliedstaat beeinträchtigt wird;

  - d) sie birgt ein hohes Risiko nachteiliger Umweltauswirkungen in mehr als einem Mitgliedstaat;

  - e) sie ist im Vergleich zu anderen Investitionen in dem betreffenden aufstrebenden strategischen Sektor von besonders hohem Wert.

(3) Im Anschluss an die in Artikel 19 Absatz 1 genannte Anmeldung kann die Kommission beschließen, die Investition einer Prüfung gemäß Artikel 18 Absatz 4 zu unterziehen. Die Kommission kann die Prüfung von sich aus oder auf Ersuchen der für die Bearbeitung der Anmeldung zuständigen Investitionsbehörde oder einer Investitionsbehörde eines anderen Mitgliedstaats, in dessen Hoheitsgebiet die betreffende ausländische Direktinvestition erhebliche Auswirkungen hätte, durchführen.

    Auf der Grundlage der Ergebnisse ihrer Prüfung kann die Kommission von der Investitionsbehörde verlangen, einige oder alle der in Artikel 18 Absatz 2 genannten Bedingungen in verhältnismäßiger Weise anzuwenden oder nicht anzuwenden.

(4) Beschließt die Kommission, die ausländische Direktinvestition gemäß diesem Artikel zu prüfen, so gelten die Bestimmungen des Artikels 18 entsprechend ab dem Zeitpunkt ihres Beschlusses zur Durchführung der Prüfung.

<a id="art-22"></a>
### Artikel 22 – Überwachung und Durchsetzung durch die Investitionsbehörde

(1) Die Investitionsbehörde führt eine regelmäßige Überwachung der ausländischen Direktinvestition durch, um sicherzustellen, dass diese fortdauernd die in Artikel 18 festgelegten Bedingungen erfüllt. Zu diesem Zweck erstattet der ausländische Investor der Investitionsbehörde regelmäßig Bericht über die Einhaltung der Bedingungen.

(2) Auf Ersuchen der Kommission übermittelt die Investitionsbehörde der Kommission die gemäß Absatz 1 vorgelegten Berichte des Investors zusammen mit ihrer eigenen Bewertung jedes Berichts.

(3) Die Investitionsbehörde legt Sanktionen für Verstöße gegen die Bestimmungen dieses Kapitels fest, insbesondere für Fälle, in denen ausländische Investoren oder Investitionen Folgendes nicht erfüllen:

  - a) die Meldeanforderungen gemäß Artikel 19;

  - b) die Bedingungen gemäß Artikel 18;

  - c) die Überwachungspflichten gemäß dem vorliegenden Artikel.

4) Die von der Investitionsbehörde festgesetzten Strafzahlungen betragen im Falle eines Verstoßes gemäß Absatz 3 Buchstabe a nicht weniger als 5 % des durchschnittlichen täglichen Gesamtumsatzes des Unternehmens des ausländischen Investors.

    Handelt es sich bei dem ausländischen Investor um eine Privatperson, verhängt die Investitionsbehörde im Falle eines Verstoßes gemäß Absatz 3 Buchstabe a eine Strafzahlung in Höhe von mindestens 5 % des Investitionswerts.

    Die von der Investitionsbehörde festgesetzten Strafzahlungen müssen wirksam sein und in einem angemessenen Verhältnis zu den in Absatz 3 genannten Verstößen stehen.

    Die Investitionsbehörde unterrichtet die Kommission unverzüglich über jeden Verstoß gemäß Absatz 3 und über die in der Folge verhängten Sanktionen.

<a id="art-23"></a>
### Artikel 23 – Überwachung durch die Kommission

(1) Für die Zwecke des Artikels 17 überwacht die Kommission die globale Fertigungskapazität für jeden der aufstrebenden strategischen Sektoren und baut dabei auf bestehenden Überwachungstätigkeiten auf, die insbesondere gemäß der Verordnung (EU) 2024/1735 durchgeführt werden.

(2) Die Kommission stellt für jeden der in Artikel 17 Absatz 2 genannten aufstrebenden strategischen Sektoren aktualisierte Informationen über das letzte Jahr, für das Daten vorliegen, bereit und veröffentlicht diese.

    Beschließt die Kommission, die ausländische Direktinvestition gemäß Artikel 21 zu überprüfen, kann sie per Beschluss Sanktionen verhängen, wenn der ausländische Investor in seiner Anmeldung falsche oder irreführende Angaben macht oder wenn er die Informationen, die die Kommission benötigt, um ihrer Überprüfungspflicht nachzukommen, nicht vorlegt.

    Die von der Kommission verhängten Sanktionen dürfen 5 % des durchschnittlichen Tagesumsatzes des ausländischen Investors oder – wenn es sich bei dem ausländischen Investor um eine Privatperson handelt – 5 % des Investitionswerts nicht übersteigen.

<a id="art-24"></a>
### Artikel 24 – Übertragung von Befugnissen

(1) Der Kommission wird die Befugnis übertragen, gemäß Artikel 30 der vorliegenden Verordnung delegierte Rechtsakte zu erlassen, um die Liste der aufstrebenden strategischen Sektoren, die unter dieses Kapitel fallen, um Sektoren zu ergänzen, die für die wirtschaftliche Sicherheit der Union von entscheidender Bedeutung sind, einschließlich der in Artikel 4 Absatz 1 Buchstaben b, d, e, g, h, j, k, n, p und s der Verordnung (EU) 2024/1735 genannten Netto-Null-Technologien, der in Artikel 4 Absatz 1 Buchstabe i der Verordnung (EU) 2024/1735 genannten Technologien für den Kernbrennstoffkreislauf und der in Artikel 4 Absatz 1 Buchstabe r der Verordnung (EU) 2024/1735 genannten Elektroantriebstechnologien für den Verkehr, wobei digitale Technologien, künstliche Intelligenz, Quantentechnologien und Halbleiter ausgenommen sind.

    Diese delegierten Rechtsakte lassen andere Rechtsakte der Union zur Festlegung von Investitionskriterien für diese Sektoren unberührt.

(2) Den in Absatz 1 genannten delegierten Rechtsakten liegt Folgendes zugrunde:

  - a) die Bewertung der Frage, ob durch eine Änderung der Liste aufstrebender strategischer Sektoren Investoren in unangemessener Weise davon abgeschreckt oder abgehalten würden, ausländische Direktinvestitionen in der Union zu tätigen;

  - b) die Anzahl der ausländischen Direktinvestitionen in dem betreffenden Sektor unter Berücksichtigung ihres Beitrags zur Versorgungssicherheit der Union und ihres Mehrwerts für die Wirtschaft der Union;

  - c) die Marktlage und -bedingungen, einschließlich Störungen der Lieferkette, auf Unionsebene;

  - d) technologische Entwicklungen und die Wettbewerbsfähigkeit der Union in dem betreffenden Sektor im Vergleich zu Drittländern;

  - e) die Abhängigkeit in der Lieferkette in dem betreffenden Sektor von einem oder mehreren Ländern.

(3) In den gemäß Absatz 1 erlassenen delegierten Rechtsakten ist Folgendes festgelegt:

  - a) der in Artikel 17 Absatz 1 genannte Schwellenwert für jeden dieser zusätzlichen Sektoren;

  - b) ob die in Artikel 18 genannten Investitionsbedingungen angemessen und erforderlich sind, um die Ziele dieser Verordnung in Bezug auf den betreffenden Sektor zu erreichen, und, falls dies nicht der Fall ist, welche dieser Kriterien anzuwenden sind.

<a id="chapter-v"></a>
## Kapitel V – BESCHLEUNIGUNGSGEBIETE FÜR DIE INDUSTRIELLE FERTIGUNG

<a id="art-25"></a>
### Artikel 25 – Ausweisung nationaler Beschleunigungsgebiete für die industrielle Fertigung

(1) Die Mitgliedstaaten weisen bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = 12 Monate nach Inkrafttreten dieser Verordnung] mindestens ein Beschleunigungsgebiet für die industrielle Fertigung in ihrem Hoheitsgebiet aus, um industrielle Fertigungsprojekte in einem oder mehreren der in Anhang I aufgeführten strategischen Sektoren zu bündeln.

(2) Die Ausweisung der Beschleunigungsgebiete für die industrielle Fertigung durch die Mitgliedstaaten erfolgt per Beschluss, und zwar auf der Grundlage der folgenden Faktoren:

  - a) der Auswirkungen der Produktion im Beschleunigungsgebiet für die industrielle Fertigung auf die Versorgungssicherheit der Union in den in Anhang I aufgeführten strategischen Sektoren;

  - b) des Potenzials des Beschleunigungsgebiets für die industrielle Fertigung zur Unterstützung des Aufbaus von Produktionskapazitäten in den in Anhang I aufgeführten strategischen Sektoren, zur Stärkung der Wertschöpfungsketten und des Innovationspotenzials der Union, um nachhaltige industrielle Tätigkeiten im verarbeitenden Gewerbe, einschließlich Dekarbonisierung und kreislauforientierter Geschäftspraktiken, voranzutreiben, sowie zur Förderung des Funktionierens des Binnenmarkts, im Einklang mit strategischen Projekten und anderen Initiativen, einschließlich Beschleunigungstälern für Netto-Null-Technologien, die gemäß anderen Rechtsvorschriften der Union durchgeführt werden;

  - c) der Anzahl der KMU und kleinen Midcap-Unternehmen, die innerhalb des Beschleunigungsgebiets für die industrielle Fertigung von den Bestimmungen dieses Kapitels profitieren würden;

  - d) des Entwicklungsstands der Regionen des Mitgliedstaats, einschließlich der am wenigsten entwickelten Gebiete, der Regionen im Umbruch und der Regionen, die einen industriellen Wandel durchlaufen.

(3) Bei der Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung verfahren die Mitgliedstaaten wie folgt:

  - a) Sie legen einen klaren geografischen Geltungsbereich für das Beschleunigungsgebiet fest;

  - b) sie bevorzugen Standorte, an denen die Durchführung von Projekten zur industriellen Fertigung in einem bestimmten Sektor oder in bestimmten Sektoren voraussichtlich keine nennenswerten Auswirkungen auf die Umwelt haben wird;

  - c) sie bevorzugen Standorte außerhalb von Natura-2000-Gebieten und außerhalb von Gebieten, die im Rahmen nationaler Programme zum Schutz der Natur und der biologischen Vielfalt ausgewiesen wurden, sowie außerhalb von anderen Gebieten, die auf der Grundlage von Sensibilitätskarten ausgewiesen wurden, und außerhalb von Schutzgebieten gemäß Artikel 6 der Richtlinie 2000/60/EG;

  - d) sie tragen den Klimarisiken in den ausgewiesenen Gebieten Rechnung;

  - e) sie bevorzugen künstliche und bebaute Flächen, Industrieareale und Industriebrachen sowie bereits im Rahmen anderer Rechtsvorschriften der Union ermittelte strategische Projekte.

(4) Bei der Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung berücksichtigen die Mitgliedstaaten gegebenenfalls folgende Aspekte:

  - a) den Infrastrukturbedarf des Beschleunigungsgebiets;

  - b) den Finanzierungsbedarf des verarbeitenden Gewerbes im Beschleunigungsgebiet und die Möglichkeit, das verarbeitende Gewerbe im Beschleunigungsgebiet gegebenenfalls im Einklang mit den geltenden Vorschriften über staatliche Beihilfen zu unterstützen;

  - c) die Anforderungen an die Lieferkette innerhalb des Beschleunigungsgebiets und die wesentlichen Materialien, insbesondere Sekundärmaterialien, die für die Fertigungstätigkeiten erforderlich sind;

  - d) die Machbarkeit einer Anbindung des Beschleunigungsgebiets an eine ausreichende Versorgung mit CO2-armer Energie zwecks Beschleunigung der industriellen Fertigungstätigkeit;

  - e) den Qualifikationsbedarf, den Fachkräftemangel und Beschäftigungstrends sowie Unterstützungsmaßnahmen zur Gewährleistung einer angemessenen Umschulung und Weiterqualifizierung der lokalen Arbeitskräfte;

  - f) gegebenenfalls die Notwendigkeit der Beseitigung von Schadstoffen im Beschleunigungsgebiet, um die Aufnahme neuer industrieller Tätigkeiten zu erleichtern;

  - g) den Forschungs- und Innovationsbedarf zur Beschleunigung der industriellen Fertigungstätigkeit in dem Gebiet;

  - h) einschlägige standortspezifische Informationen, die von der Industrie öffentlich zugänglich gemacht werden, einschließlich Unternehmensplänen für die Klimawende, der entsprechenden Ziele und Maßnahmen, des Investitionsbedarf und der erforderlichen unterstützenden politischen Rahmenbedingungen.

(5) Vor ihrer Annahme werden die Pläne oder Programme zur Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung einer Umweltprüfung gemäß der Richtlinie 2001/42/EG des Europäischen Parlaments und des Rates^(63) und – wenn mit erheblichen Auswirkungen auf Natura-2000-Gebiete zu rechnen ist – der Verträglichkeitsprüfung gemäß Artikel 6 Absatz 3 der Richtlinie 92/43/EWG des Rates^(64) und gegebenenfalls der einschlägigen Prüfung zur Einhaltung von Artikel 4 Absatz 7 der Richtlinie 2000/60/EG des Europäischen Parlaments und des Rates^(65) unterzogen.

(6) Die Mitgliedstaaten unterrichten die Kommission innerhalb von 30 Tagen nach Annahme des entsprechenden Beschlusses über die Ausweisung eines Beschleunigungsgebiets für die industrielle Fertigung.

<a id="art-26"></a>
### Artikel 26 – Grundlegende Voraussetzungen

Die Mitgliedstaaten ergreifen gegebenenfalls folgende Maßnahmen, um die Entwicklung von Beschleunigungsgebieten für die industrielle Fertigung zu erleichtern:

  - a) Erleichterung der Finanzierung von Projekten in den Beschleunigungsgebieten durch Sicherstellung der Koordinierung zwischen den Behörden und Straffung der internen Verfahren in Synergie mit Unionsprogrammen und gegebenenfalls im Einklang mit den geltenden Vorschriften über staatliche Beihilfen, wobei die Beteiligung von KMU und kleinen Midcap-Unternehmen zu berücksichtigen ist;

  - b) Förderung von Investitionen in Forschung und Innovation, um das Innovationspotenzial sowie die Wettbewerbsfähigkeit und die technologische Führungsrolle der Union in den Beschleunigungsgebieten zu beschleunigen;

  - c) Durchführung und mindestens alle drei Jahre Überprüfung einer umfassenden Analyse des Energiebedarfs jedes Beschleunigungsgebiets und Ermittlung der erforderlichen Energieinfrastrukturkapazität für das ordnungsgemäße Funktionieren und die Entwicklung industrieller Fertigungsprojekte im Beschleunigungsgebiet.

      Eine solche Analyse wird zumindest bei der Ausweisung des Beschleunigungsgebiets für die industrielle Fertigung sowie für die Etappenziele 2030, 2040 und 2050 durchgeführt, um die Übereinstimmung mit den Dekarbonisierungspfad der Union sicherzustellen;

  - d) Sicherstellung, dass die von den Übertragungsnetzbetreibern gemäß Artikel 51 der Richtlinie (EU) 2019/944 des Europäischen Parlaments und des Rates^(66) und den Verteilernetzbetreibern gemäß Artikel 32 der Richtlinie (EU) 2019/944 aufgestellten Netzentwicklungspläne der gemäß Buchstabe c des vorliegenden Absatzes erstellten Analyse gebührend Rechnung tragen, wobei das Potenzial vorgezogener Investitionen zur Deckung des künftigen Netzbedarfs zu berücksichtigen ist;

  - e) Austausch von Informationen über relevante Lieferketten, Ermittlung potenzieller Engpässe und Stärkung der Koordinierung zwischen Beschleunigungsgebieten in Fragen kritischer Rohstoffe im Rahmen des durch Artikel 35 der Verordnung (EU) 2024/1252 eingerichteten Europäischen Ausschusses für kritische Rohstoffe;

  - f) Förderung von Unternehmen in den Beschleunigungsgebieten und gegebenenfalls Erleichterung ihrer Teilnahme an dem durch Artikel 25 der Verordnung (EU) 2024/1252 eingerichteten Mechanismus für die gemeinsame Beschaffung, unter anderem durch die Bereitstellung von Leitlinien, Unterstützung und Informationen, um eine wirksame Beteiligung zu gewährleisten;

  - g) Unterstützung der Entwicklung und Verfügbarkeit hoch qualifizierter Arbeitskräfte und Bereitstellung geeigneter Ausbildungs- und Lehrstellenangebote, um so zu hochwertigen Arbeitsplätzen innerhalb der Beschleunigungsgebiete beizutragen;

  - h) Austausch von Informationen über die erforderlichen Kompetenzen, den möglichen Mangel an diesen Kompetenzen und bewährte Verfahren, die in den Beschleunigungsgebieten angewandt werden, im Rahmen der durch die Mitteilung der Kommission COM(2020) 102^(67) eingesetzten Expertengruppe des Industrieforums;

  - i) Schaffung von Synergien und Förderung der durch den Kompetenzpakt^(68) oder von den in den Beschleunigungsgebieten ansässigen Unternehmen gebotenen Vorteile, wobei groß angelegten Kompetenzpartnerschaften und regionalen Kompetenzpartnerschaften im Rahmen des Kompetenzpakts besondere Aufmerksamkeit zu widmen ist.

<a id="art-27"></a>
### Artikel 27 – Genehmigungsverfahren für Beschleunigungsgebiete

(1) Für jedes ausgewiesene Beschleunigungsgebiet für die industrielle Fertigung erstellen und erteilen die Mitgliedstaaten eine aggregierte Basisgenehmigung, mit der industrielle Tätigkeiten in dem betreffenden Gebiet genehmigt werden. Diese aggregierte Basisgenehmigung umfasst die Genehmigungen und behördlichen Zulassungen, die für die industriellen Fertigungsprojekte innerhalb des Beschleunigungsgebiets erforderlich sind, mit Ausnahme anlagenspezifischer Genehmigungen.

(2) Vor Erteilung der in Absatz 1 genannten aggregierten Basisgenehmigung führen die Mitgliedstaaten alle erforderlichen Prüfungen durch, einschließlich der einschlägigen Umweltprüfungen, Planungsverfahren und Bewertungen, die auf der Ebene des Beschleunigungsgebiets gelten. Die Mitgliedstaaten berücksichtigen die gemäß Artikel 25 Absatz 5 durchgeführte Bewertung.

(3) Für industrielle Fertigungsprojekte, die in einem Beschleunigungsgebiet für die industrielle Fertigung angesiedelt sind, müssen nur solche zusätzlichen Genehmigungen oder Zulassungen eingeholt werden, die nicht in den Geltungsbereich der aggregierten Basisgenehmigung gemäß Absatz 1 fallen.

(4) Alle industriellen Fertigungsprojekte, die in einem Beschleunigungsgebiet angesiedelt sind, gelten für die Zwecke [des Artikels 14 des Vorschlags für eine Verordnung zur Beschleunigung von Umweltprüfungen] als strategische Projekte, die zu Resilienz und Dekarbonisierung oder Ressourceneffizienz beitragen. Es gelten die Nummern 1, 2 und 3 des Anhangs der genannten Verordnung.

<a id="chapter-vi"></a>
## Kapitel VI – SCHLUSSBESTIMMUNGEN

<a id="art-28"></a>
### Artikel 28 – Evaluierung

  Bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = zwei Jahre nach Inkrafttreten dieser Verordnung] und danach alle drei Jahre nimmt die Kommission eine Evaluierung dieser Verordnung sowie ihres Beitrags zum Funktionieren des Binnenmarkts vor. Bei der Evaluierung wird Folgendes berücksichtigt:

  - a) die Fortschritte bei der Verwirklichung der in Artikel 1 genannten Ziele, insbesondere in Bezug auf Resilienz, wirtschaftliche Sicherheit und Dekarbonisierung der industriellen Fertigung;

  - b) die Fortschritte bei der Verwirklichung des Industrialisierungsziels gemäß Artikel 2 unter Berücksichtigung der Herausforderungen und Chancen im Binnenmarkt und auf den Weltmärkten;

  - c) die damit verbundenen Verwaltungskosten, die wirtschaftlichen Auswirkungen auf nachgelagerte Sektoren sowie kleine und mittlere Unternehmen und die Auswirkungen auf die öffentlichen Haushalte.

<a id="art-29"></a>
### Artikel 29 – Überprüfung

  Bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] überprüft die Kommission, ob eine Änderung der Kapitel III und IV erforderlich ist. Die Kommission kann einen Gesetzgebungsvorschlag zur Aufhebung oder Änderung dieser Verordnung vorlegen. Diese Überprüfung wird nach der ersten Überprüfung regelmäßig alle zwei Jahre durchgeführt.

  Bei der Durchführung ihrer Überprüfung widmet die Kommission der Wirksamkeit dieser Verordnung und dem Fortbestehen der Umstände, die den Erlass dieser Verordnung gerechtfertigt haben, sowie der Notwendigkeit, Anforderungen hinsichtlich des Ursprungs in der Union für Produkte aus bestimmten Sektoren einzuführen, die für die wirtschaftliche Sicherheit der Union von entscheidender Bedeutung sind, insbesondere für den Bau von Schiffen und Schienenfahrzeugen, besondere Aufmerksamkeit.

<a id="art-30"></a>
### Artikel 30 – Ausübung der Befugnisübertragung

(1) Die Befugnis zum Erlass delegierter Rechtsakte wird der Kommission unter den in diesem Artikel festgelegten Bedingungen übertragen.

(2) Die Befugnis zum Erlass delegierter Rechtsakte gemäß den Artikeln 8, 9, 10, 16 und 24 wird der Kommission auf unbestimmte Zeit ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = Datum des Inkrafttretens dieser Verordnung] übertragen.

(3) Die Befugnisübertragung gemäß den Artikeln 8, 9, 10, 16 und 24 kann vom Europäischen Parlament oder vom Rat jederzeit widerrufen werden. Der Beschluss über den Widerruf beendet die Übertragung der in diesem Beschluss angegebenen Befugnis. Er wird am Tag nach seiner Veröffentlichung im Amtsblatt der Europäischen Union oder zu einem im Beschluss über den Widerruf angegebenen späteren Zeitpunkt wirksam. Die Gültigkeit von delegierten Rechtsakten, die bereits in Kraft sind, wird von dem Beschluss über den Widerruf nicht berührt.

(4) Vor dem Erlass eines delegierten Rechtsakts konsultiert die Kommission die von den einzelnen Mitgliedstaaten benannten Sachverständigen im Einklang mit den in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung enthaltenen Grundsätzen.

(5) Sobald die Kommission einen delegierten Rechtsakt erlässt, übermittelt sie ihn gleichzeitig dem Europäischen Parlament und dem Rat.

(6) Ein delegierter Rechtsakt, der gemäß den Artikeln 8, 9, 10, 16 und 24 erlassen wurde, tritt nur in Kraft, wenn weder das Europäische Parlament noch der Rat innerhalb einer Frist von zwei Monaten nach Übermittlung dieses Rechtsakts an das Europäische Parlament und den Rat Einwände erhoben haben oder wenn vor Ablauf dieser Frist das Europäische Parlament und der Rat beide der Kommission mitgeteilt haben, dass sie keine Einwände erheben werden. Auf Initiative des Europäischen Parlaments oder des Rates wird diese Frist um zwei Monate verlängert.

<a id="art-31"></a>
### Artikel 31 – Ausschussverfahren

(1) Die Kommission wird von einem Ausschuss unterstützt. Dieser Ausschuss ist ein Ausschuss im Sinne der Verordnung (EU) Nr. 182/2011.

(2) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 4 der Verordnung (EU) Nr. 182/2011.

(3) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 5 der Verordnung (EU) Nr. 182/2011.

<a id="art-32"></a>
### Artikel 32 – Sanktionen

  Die Mitgliedstaaten erlassen Vorschriften über Sanktionen, die bei Verstößen gegen die Bestimmungen dieser Verordnung zu verhängen sind, und treffen alle zu ihrer Durchsetzung erforderlichen Maßnahmen. Die vorgesehenen Sanktionen müssen wirksam, verhältnismäßig und abschreckend sein. Die Mitgliedstaaten teilen der Kommission diese Vorschriften und Maßnahmen unverzüglich mit und melden ihr unverzüglich alle diesbezüglichen Änderungen.

<a id="art-33"></a>
### Artikel 33 – Änderungen der Verordnung (EU) Nr. 2018/1724

  Die Anhänge I und II der Verordnung (EU) 2018/1724 werden gemäß Anhang V der vorliegenden Verordnung geändert.

<a id="art-34"></a>
### Artikel 34 – Änderungen der Verordnung (EU) Nr. 2024/1735

  Die Verordnung (EU) 2024/1735 wird wie folgt geändert:

- 1. In Artikel 3 werden die folgenden Nummern 34, 35 und 36 angefügt:

  - a) „34. ‚Industriebatterie‘ eine Industriebatterie im Sinne des Artikels 3 Absatz 1 Nummer 13 der Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates*;“

  - b) „35. ‚stationäres Batterie-Energiespeichersystem‘ ein stationäres Batterie-Energiespeichersystem im Sinne des Artikels 3 Absatz 1 Nummer 15 der Verordnung (EU) 2023/1542;“

  - c) „36. ‚hydronische Wärmepumpe‘ ein Raumheizgerät, das zur Wärmeerzeugung und Raumheizung Umgebungswärme aus Luft, Wasser oder Boden und/oder Abwärme nutzt.“

  - ___

  - * Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates vom 12. Juli 2023 über Batterien und Altbatterien, zur Änderung der Richtlinie 2008/98/EG und der Verordnung (EU) 2019/1020 und zur Aufhebung der Richtlinie 2006/66/EG (ABl. L 191 vom 28.7.2023, S. 1), ELI: http://data.europa.eu/eli/reg/2023/1542/oj).

- 2. In Artikel 9 wird folgender Absatz 14 angefügt:

„(14) Alle Projekte zur Fertigung von Netto-Null-Technologien gelten für die Zwecke des Artikels 14 Absatz 1 [des Vorschlags für eine Verordnung zur Beschleunigung von Umweltprüfungen] als strategische Projekte, die zu Resilienz und Dekarbonisierung oder Ressourceneffizienz beitragen.“

- 3. Artikel 25 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

  - „(1) Bei Verfahren zur Vergabe öffentlicher Aufträge, die in den Anwendungsbereich der Richtlinien 2014/23/EU, 2014/24/EU oder 2014/25/EU fallen, wenden öffentliche Auftraggeber und Auftraggeber verbindliche Mindestanforderungen an die ökologische Nachhaltigkeit an, die in dem in Absatz 5 des vorliegenden Artikels genannten Durchführungsrechtsakt festgelegt werden, wenn die in Artikel 4 Absatz 1 Buchstaben a bis d, h und i dieser Verordnung aufgeführten Netto-Null-Technologien Teil der Aufträge sind oder wenn Bauaufträge oder Baukonzessionen eine der genannten Technologien umfassen.“

  - b) Absatz 7 Unterabsatz 1 erhält folgende Fassung:

  - „Der Beitrag des Angebots zur Resilienz wird bei den in Absatz 1 genannten Verfahren zur Vergabe öffentlicher Aufträge, von Bauaufträgen und Baukonzessionen gemäß dem vorliegenden Absatz berücksichtigt.“

  - c) Absatz 7 Buchstabe a erhält folgende Fassung:

  - „a) eine Verpflichtung, dass für die Laufzeit des Auftrags nicht mehr als 50 % des Wertes des spezifischen Endprodukts mit Netto-Null-Technologien gemäß diesem Absatz aus jedem einzelnen Drittland geliefert werden, wie von der Kommission vorgesehen;“.

  - d) Absatz 7 Buchstabe b erhält folgende Fassung:

  - „b) eine Verpflichtung für die Laufzeit des Auftrags, dass – wie von der Kommission vorgesehen – nicht mehr als 50 % des Werts aller wichtigsten spezifischen Bauteile der spezifischen Netto-Null-Technologie gemäß diesem Absatz zusammengenommen direkt von einem erfolgreichen Auftragnehmer oder von einem Unterauftragnehmer aus jedem einzelnen Drittland geliefert oder bereitgestellt werden;“

- 4. Folgender Artikel 25a wird eingefügt:

**„Artikel 25a – Ursprungsanforderungen bei Verfahren zur Vergabe öffentlicher Aufträge**

(1) Was die in Anhang II genannten Verfahren zur Vergabe öffentlicher Aufträge betrifft, so schließen öffentliche Auftraggeber und Auftraggeber solche Angebote von diesen Vergabeverfahren aus, die von Wirtschaftsteilnehmern eingereicht werden, die im Eigentum oder unter der Kontrolle einer Einrichtung stehen, die in einem Drittland niedergelassen ist, das kein internationales Abkommen mit der Union geschlossen hat, das den Zugang zu diesen Vergabeverfahren garantiert.

(2) Was die in Anhang II genannten Verfahren zur Vergabe öffentlicher Aufträge betrifft, so wenden öffentliche Auftraggeber und Auftraggeber die darin festgelegten Anforderungen hinsichtlich des Ursprungs in der Union an. Die Anforderungen in Bezug auf bestimmte wichtigste spezifische Bauteile gelten nur insoweit, als diese Bauteile im Endprodukt enthalten sind.

(3) Öffentliche Auftraggeber und Auftraggeber können beschließen, eine oder mehrere der in Anhang II genannten Anforderungen nicht anzuwenden, wenn eine der folgenden Bedingungen erfüllt ist:

  - a) Die benötigten Produkte können nur von einem spezifischen Wirtschaftsteilnehmer geliefert werden, es gibt keine vernünftige Alternative oder Ersatzlösung, und der fehlende Wettbewerb ist nicht das Ergebnis einer künstlichen Einschränkung der Parameter des Verfahrens zur Vergabe öffentlicher Aufträge;

  - b) es wurden keine geeigneten Angebote oder keine geeigneten Teilnahmeanträge eingereicht, auch nicht bei einem ähnlichen früheren Verfahren zur Vergabe öffentlicher Aufträge, das von demselben öffentlichen Auftraggeber oder Auftraggeber in den zwei Jahren vor Beginn des geplanten neuen Vergabeverfahrens eingeleitet wurde;

  - c) ihre Anwendung würde den öffentlichen Auftraggeber oder den Auftraggeber dazu verpflichten, Waren, Dienstleistungen oder Bauleistungen zu erwerben, die unverhältnismäßige Kosten verursachen würden, oder zu technischer Inkompatibilität bei Betrieb und Wartung führen. Kostenunterschiede, die auf der Grundlage von objektiven und transparenten Daten auf über 25 % geschätzt werden, können von öffentlichen Auftraggebern und Auftraggebern als unverhältnismäßig angesehen werden;

  - d) ihre Anwendung würde aufgrund der Nichtverfügbarkeit der benötigten Bauteile oder Endprodukte zu erheblichen Verzögerungen bei der Fertigstellung des Projekts führen. Verzögerungen, die auf der Grundlage objektiver, transparenter und überprüfbarer Daten auf mehr als sieben Monate geschätzt werden, können als erheblich angesehen werden.

(4) Öffentliche Auftraggeber verlangen von Wirtschaftsteilnehmern, die Produkte anbieten, die in den Anwendungsbereich dieses Artikels fallen, eine Eigenerklärung oder ein gleichwertiges Dokument zum Nachweis der Erfüllung der in diesem Artikel festgelegten Anforderungen.“

- 5. Artikel 26 wird wie folgt geändert:

  - a) Die Überschrift erhält folgende Fassung: „Auktionen für Netto-Null-Technologien“.

  - b) Absatz 1 wird wie folgt geändert:

    - Der einleitende Teil erhält folgende Fassung:

    - „Bei der Gestaltung von Auktionen für die in Artikel 4 Absatz 1 Buchstaben a bis g, i und j aufgeführten Netto-Null-Technologien nehmen die Mitgliedstaaten Folgendes auf:“

    - Unter Buchstabe a wird folgende Ziffer iv angefügt:

    - „iv) Hochrisikoanbieter im Sinne des Artikels 2 Nummer 39 der Verordnung xxxx/xxxx [Cybersicherheitsverordnung 2]: Bei Auktionen, die Steuerungssysteme, Verwaltungskontrollsysteme, Überwachungs- und Datenerfassungssysteme, Fernzugriffssysteme oder Firewalls umfassen, dürfen Lieferanten, die als Hochrisikoanbieter im Sinne der Verordnung xxxx/xxxx [Cybersicherheitsverordnung 2] eingestuft wurden, nicht an den folgenden Prozessen beteiligt sein:

      - 1. Lieferung dieser Produkte oder Systeme;

      - 2. Entwurf, Entwicklung oder Herstellung dieser Produkte oder Systeme;

      - 3. Verwaltung, Steuerung oder Betrieb dieser Produkte oder Systeme;

      - 4. Entwicklung, Instandhaltung, Betrieb oder Aktualisierung ihrer Software.“

    - Buchstabe b erhält folgende Fassung: „Vorqualifikations- oder Zuschlagskriterien gemäß den Absätzen 2 und 2a.“

  - c) Folgender Absatz 2a wird eingefügt: „2a. Umfasst der Gegenstand der Auktionen Netto-Null-Technologien, die in Anhang II aufgeführt sind, so nehmen die Mitgliedstaaten die in Anhang II festgelegten Vorqualifikations- oder Zuschlagskriterien auf. Die Anforderungen in Bezug auf bestimmte wichtigste spezifische Bauteile gelten nur insoweit, als diese Bauteile im Endprodukt enthalten sind.“

  - d) Absatz 3 Unterabsatz 1 erhält folgende Fassung: „Der Kommission wird die Befugnis übertragen, einen Durchführungsrechtsakt zu erlassen, in dem die in Absatz 1 Buchstabe a Ziffern i, ii und iii sowie in Absatz 2 genannten Vorqualifikations- und Zuschlagskriterien weiter präzisiert werden.“

  - e) Absatz 4 erhält folgende Fassung: „(4) Die Mitgliedstaaten weisen jedem der in den Absätzen 2 und 2a genannten Kriterien, wenn sie als Zuschlagskriterien angewandt werden, eine Mindestgewichtung in Höhe von 5 % und eine kombinierte Gewichtung zwischen 15 % und 30 % der Zuschlagskriterien zu. Dies gilt unbeschadet der Möglichkeit, die in Absatz 2 Unterabsatz 4 genannten Kriterien stärker zu gewichten, und steht im Einklang mit etwaigen Beschränkungen für nicht preisbezogene Kriterien, die in den Vorschriften über staatliche Beihilfen festgelegt sind.“

  - f) Absatz 5 erhält folgende Fassung: „(5) Die Mitgliedstaaten sind nicht verpflichtet, eines oder mehrere der Vorqualifikations- und Zuschlagskriterien gemäß Absatz 1 Buchstabe a Ziffern i, ii und iii und Absatz 1 Buchstabe b anzuwenden, wenn die Anwendung dieser Kriterien unverhältnismäßige Kosten verursachen oder aufgrund der Nichtverfügbarkeit der benötigten Bauteile oder Endprodukte zu erheblichen Verzögerungen führen würde. Kostenunterschiede, die auf der Grundlage von objektiven und überprüfbaren Daten auf über 20 % je Auktion geschätzt werden, können von den Mitgliedstaaten als unverhältnismäßig angesehen werden. Verzögerungen, die auf der Grundlage objektiver, transparenter und überprüfbarer Daten auf mehr als sieben Monate geschätzt werden, können als erheblich angesehen werden.“

  - g) Absatz 7 erhält folgende Fassung: „(7) Die Absätze 1 bis 5 gelten für mindestens 40 % des jährlichen Auktionsvolumens pro Mitgliedstaat oder alternativ für mindestens 8 Gigawatt pro Jahr und Mitgliedstaat. Absatz 1 Buchstabe a Ziffern ii und iv gilt für 100 % des Auktionsvolumens pro Mitgliedstaat.“

  - h) In Absatz 8 erhält der einführende Wortlaut folgende Fassung: „Bis zum 31. Dezember 2027 führt die Kommission eine umfassende Bewertung der Anwendung der in Absatz 2 genannten Kriterien und ihrer Auswirkungen auf den beschleunigten Einsatz von Technologien für erneuerbare Energien durch. Bis zum 31. Dezember 2029 und danach alle zwei Jahre führt die Kommission eine umfassende Bewertung der Anwendung der in den Absätzen 2 und 2a genannten Kriterien und ihrer Auswirkungen auf den beschleunigten Einsatz von Technologien für erneuerbare Energien durch. Die Kommission bewertet insbesondere die Auswirkungen der Kriterien auf“.

- 6. Die folgenden Artikel 28a bis 28h werden eingefügt:

**„Artikel 28a – Ursprungsanforderungen bei anderen Formen der öffentlichen Intervention**

(1) Unbeschadet der Artikel 107 und 108 AEUV umfassen die in Anhang II genannten Förderregelungen die dort festgelegten Anforderungen. Die Anforderungen in Bezug auf bestimmte wichtigste spezifische Bauteile gelten nur insoweit, als diese Bauteile im Endprodukt enthalten sind.

(2) Bei der Konzeption und Umsetzung eines Programms gemäß Absatz 1 bewertet die Behörde die Erfüllung der Voraussetzungen auf der Grundlage eines offenen, diskriminierungsfreien und transparenten Verfahrens.

(3) Wird ein zusätzlicher finanzieller Ausgleich gewährt, so darf dieser 15 % der Kosten des Endprodukts für den Verbraucher, gegebenenfalls einschließlich der Transport- und Installationskosten, nicht übersteigen, mit Ausnahme von Programmen für Bürgerinnen und Bürger, die in Energiearmut im Sinne des Artikels 2 Nummer 1 der Verordnung (EU) 2023/955 des Europäischen Parlaments und des Rates (57) leben und für die die Obergrenze bei 20 % liegt.

**Artikel 28b – Beschränkungen für Hochrisikoanbieter bei anderen Formen der öffentlichen Intervention**

  Bei Förderregelungen, die in den Anwendungsbereich der Artikel 28 und 28a fallen und die Steuerungssysteme, Verwaltungskontrollsysteme, Überwachungs- und Datenerfassungssysteme, Fernzugriffssysteme oder Firewalls umfassen, gestalten die Mitgliedstaaten diese Regelungen so, dass Begünstigte nur dann für die Regelung infrage kommen, wenn Lieferanten, die als Hochrisikoanbieter im Sinne der Verordnung xxxx/xxxx [Cybersicherheitsverordnung 2] eingestuft wurden, nicht an den folgenden Prozessen beteiligt sind:

  - a) Lieferung dieser Produkte oder Systeme;

  - b) Entwurf, Entwicklung oder Herstellung dieser Produkte oder Systeme;

  - c) Verwaltung, Steuerung oder Betrieb dieser Produkte oder Systeme;

  - d) Entwicklung, Instandhaltung, Betrieb oder Aktualisierung ihrer Software.

**Artikel 28c – Anforderungen hinsichtlich des Ursprungs in der Union bei der Förderung des Baus und der Herstellung von Netto-Null-Technologien durch die Mitgliedstaaten**

(1) Unbeschadet der Artikel 107 und 108 AEUV und im Einklang mit den internationalen Verpflichtungen der Union stellen die Mitgliedstaaten bei der Förderung des Baus oder der Fertigung der in Anhang II dieser Verordnung genannten Endprodukte mit Netto-Null-Technologien sicher, dass die in dem genannten Anhang festgelegten Anforderungen hinsichtlich des Ursprungs in der Union erfüllt sind. Die Anforderungen in Bezug auf bestimmte wichtigste spezifische Bauteile gelten nur insoweit, als diese Bauteile im Endprodukt enthalten sind.

(2) Die Mitgliedstaaten können beschließen, eine oder mehrere der in Absatz 1 genannten Anforderungen nicht anzuwenden, wenn eine der folgenden Bedingungen erfüllt ist:

  - a) Die benötigten Bauteile können nur von einem spezifischen Wirtschaftsteilnehmer geliefert werden, es gibt keine vernünftige Alternative oder Ersatzlösung, und der fehlende Wettbewerb ist nicht das Ergebnis einer künstlichen Einschränkung der Parameter des Verfahrens zur Vergabe öffentlicher Aufträge;

  - b) ihre Anwendung würde unverhältnismäßige Kosten verursachen oder zu technischer Inkompatibilität bei Betrieb und Wartung führen. Kostenunterschiede, die auf der Grundlage von objektiven und transparenten Daten auf über 25 % geschätzt werden, können als unverhältnismäßig angesehen werden;

  - c) ihre Anwendung würde das Projekt gefährden oder aufgrund der Nichtverfügbarkeit der benötigten Bauteile oder Endprodukte zu erheblichen Verzögerungen bei der Fertigstellung des Projekts führen. Verzögerungen, die auf der Grundlage objektiver, transparenter und überprüfbarer Daten auf mehr als sieben Monate geschätzt werden, können als erheblich angesehen werden.

(3) Unbeschadet der Artikel 107 und 108 AEUV und im Einklang mit den internationalen Verpflichtungen der Union stellen die Mitgliedstaaten bei der Förderung der Fertigung der in Anhang II der vorliegenden Verordnung genannten Endprodukte mit Netto-Null-Technologien, die Steuerungssysteme, Verwaltungskontrollsysteme, Überwachungs- und Datenerfassungssysteme, Fernzugriffssysteme oder Firewalls umfassen, sicher, dass Lieferanten, die als Hochrisikoanbieter im Sinne der Verordnung xxxx/xxxx [Cybersicherheitsverordnung 2] eingestuft wurden, nicht an den folgenden Prozessen beteiligt sind:

  - a) Lieferung dieser Produkte oder Systeme;

  - b) Entwurf, Entwicklung oder Herstellung dieser Produkte oder Systeme;

  - c) Verwaltung, Steuerung oder Betrieb dieser Produkte oder Systeme;

  - d) Entwicklung, Instandhaltung, Betrieb oder Aktualisierung ihrer Software.

**Artikel 28d – Ursprung in der Union**

(1) Für die Zwecke der Artikel 25a, 26, 28a und 28c bezeichnet der Ausdruck „Inhalte mit Ursprung in der Union“ Inhalte, die aus der Union stammen.

(2) Die Bestimmung des Ursprungs von Produkten und Bauteilen erfolgt im Einklang mit der Verordnung (EU) Nr. 952/2013 des Europäischen Parlaments und des Rates.

**Artikel 28e**

**Gleichwertigkeit von Inhalten hinsichtlich des Ursprungs in der Union bei der Vergabe öffentlicher Aufträge**

(1) In Bezug auf die in Artikel 25a genannten Anforderungen hinsichtlich des Ursprungs in der Union gelten Inhalte mit Ursprung in Drittländern, mit denen die Union ein Abkommen zur Errichtung einer Freihandelszone oder Zollunion geschlossen hat oder die Vertragsparteien des Übereinkommens über das öffentliche Beschaffungswesen sind, sofern einschlägige Verpflichtungen der Union im Rahmen dieses Abkommens bestehen, als Inhalte mit Ursprung in der Union.

(2) Die Kommission erlässt delegierte Rechtsakte gemäß Artikel 44, um ein Drittland auf der Grundlage eines der folgenden Kriterien ganz oder teilweise vom Anwendungsbereich des Absatzes 1 auszunehmen:

  - e) Das betreffende Drittland hat in Bezug auf eine der in Artikel 4 Nummer 1 aufgeführten Netto-Null-Technologien keine Inländerbehandlung für Produkte oder Unternehmen aus der Union im Rahmen der in Absatz 1 genannten Abkommen gewährt;

  - f) eine solche Ausnahme ist gerechtfertigt, um Abhängigkeiten oder sonstige Entwicklungen zu vermeiden, die die Versorgungssicherheit der Union bei den betreffenden Produkten gefährden könnten;

  - g) eine solche Ausnahme ist aufgrund einer anderen Ausnahme gemäß dem geltenden Abkommen gerechtfertigt.

**Artikel 28f**

**Gleichwertigkeit von Inhalten hinsichtlich des Ursprungs in der Union bei Auktionen**

(1) In Bezug auf die in Artikel 26 genannten Anforderungen hinsichtlich des Ursprungs in der Union gelten Inhalte mit Ursprung in Drittländern, mit denen die Union ein Abkommen zur Errichtung einer Freihandelszone oder Zollunion geschlossen hat, als Inhalte mit Ursprung in der Union.

(2) Die Kommission erlässt delegierte Rechtsakte gemäß Artikel 44, um ein Drittland auf der Grundlage eines der folgenden Kriterien ganz oder teilweise vom Anwendungsbereich des Absatzes 1 auszunehmen:

  - h) Das betreffende Drittland hat in Bezug auf eine der in Artikel 4 Nummer 1 aufgeführten Netto-Null-Technologien keine Inländerbehandlung für Produkte oder Unternehmen aus der Union im Rahmen der in Absatz 1 genannten Abkommen gewährt;

  - i) eine solche Ausnahme ist gerechtfertigt, um Abhängigkeiten oder sonstige Entwicklungen zu vermeiden, die die Versorgungssicherheit der Union bei den betreffenden Produkten gefährden könnten;

  - j) eine solche Ausnahme ist aufgrund einer anderen Ausnahme gemäß dem geltenden Abkommen gerechtfertigt.

**Artikel 28g**

**Gleichwertigkeit von Inhalten hinsichtlich des Ursprungs in der Union bei anderen Formen der öffentlichen Intervention**

(1) In Bezug auf die in Artikel 28a genannten Anforderungen hinsichtlich des Ursprungs in der Union gelten Inhalte mit Ursprung in Drittländern, mit denen die Union ein Abkommen zur Errichtung einer Freihandelszone oder Zollunion geschlossen hat, als Inhalte mit Ursprung in der Union.

(2) Die Kommission erlässt delegierte Rechtsakte gemäß Artikel 44, um ein Drittland auf der Grundlage eines der folgenden Kriterien ganz oder teilweise vom Anwendungsbereich des Absatzes 1 auszunehmen:

  - k) Das betreffende Drittland hat in Bezug auf eine der in Artikel 4 Nummer 1 aufgeführten Netto-Null-Technologien keine Inländerbehandlung für Produkte oder Unternehmen aus der Union im Rahmen der in Absatz 1 genannten Abkommen gewährt;

  - l) eine solche Ausnahme ist gerechtfertigt, um Abhängigkeiten oder sonstige Entwicklungen zu vermeiden, die die Versorgungssicherheit der Union bei den betreffenden Produkten gefährden könnten;

  - m) eine solche Ausnahme ist aufgrund einer anderen Ausnahme gemäß dem geltenden Abkommen gerechtfertigt.

**Artikel 28h – Befugnisübertragung**

(1) Der Kommission wird die Befugnis übertragen, gemäß Artikel 44 delegierte Rechtsakte zur Änderung der in Anhang II festgelegten Anforderungen hinsichtlich des Ursprung in der Union zu erlassen, wobei folgende Aspekte zu berücksichtigen sind:

  - a) die Marktlage auf Unionsebene, einschließlich rückläufiger Marktanteile in der Union und einer Unterauslastung der Produktionskapazitäten des Wirtschaftszweigs der Union;

  - b) der Beitrag der Anforderungen zum Ziel der Union hinsichtlich öffentlicher Ordnung, wirtschaftlicher Sicherheit, Resilienz und Klimaneutralität, wie in der Verordnung (EU) 2021/1119 festgelegt;

  - c) der technologische Fortschritt;

  - d) die Nachfrage nach den einschlägigen Netto-Null-Technologien;

  - e) die Auswirkungen der Festlegung von Anforderungen hinsichtlich des Ursprungs in der Union auf die allgemeine Wettbewerbsfähigkeit und die Treibhausgasemissionen der betreffenden Sektoren.

(2) Der Kommission wird die Befugnis übertragen, delegierte Rechtsakte zu erlassen, um Anhang II durch Anforderungen hinsichtlich des Ursprungs in der Union für zusätzliche spezifische Endprodukte mit Netto-Null-Technologien gemäß Artikel 4 Absatz 1 Buchstaben g, h, j, k, n, p und s sowie solarthermische Technologien gemäß Artikel 4 Absatz 1 Buchstabe a, Technologien für den Kernbrennstoffkreislauf gemäß Artikel 4 Absatz 1 Buchstabe i und Elektroantriebstechnologien für den Verkehr gemäß Artikel 4 Absatz 1 Buchstabe r zu ergänzen, die gemäß den Artikeln 25a, 26, 28a und 28c erforderlich sind. Dabei berücksichtigt die Kommission Folgendes:

  - a) die durch Überwachungstätigkeiten festgestellte Marktlage auf Unionsebene, einschließlich rückläufiger Marktanteile in der Union und einer Unterauslastung der Produktionskapazitäten des Wirtschaftszweigs der Union;

  - b) den Beitrag der Anforderungen zum Ziel der Union hinsichtlich öffentlicher Ordnung, wirtschaftlicher Sicherheit, Resilienz und Klimaneutralität;

  - c) die Auswirkungen der Festlegung von Anforderungen hinsichtlich des Ursprungs in der Union und/oder des CO2-Ausstoßes auf die allgemeine Wettbewerbsfähigkeit und die Treibhausgasemissionen der betreffenden Sektoren, auf die nachgelagerten Kosten für Verbraucher und für kleine und mittlere Unternehmen sowie auf die öffentlichen Haushalte;

  - d) die Nachfrage nach den einschlägigen Produkten oder Technologien.

1. In den in Absatz 2 genannten delegierten Rechtsakten ist Folgendes festgelegt:

  - a) die Produkte und Bauteile, für die die Mindestanforderungen hinsichtlich des Ursprung in der Union gelten;

  - b) der Anwendungsbereich der Mindestanforderungen hinsichtlich des Ursprungs in der Union.“

- 7. Artikel 42 wird wie folgt geändert:

  - a) Folgender Absatz 2a wird eingefügt:

  - „2a. Die Mitgliedstaaten, Behörden, öffentlichen Auftraggeber und Beschaffungsstellen, die Kapitel IV dieser Verordnung anwenden, erstatten gemäß den Bestimmungen dieses Kapitels Bericht über die Anwendung von Ausnahmen.“

  - b) Absatz 3 erhält folgende Fassung:

  - „(3) Wenn die in den Absätzen 2 und 2a genannten Daten nicht bereits Bestandteil der nationalen Energie- und Klimapläne sind oder sich nicht mit den Elementen der nationalen Energie- und Klimapläne im Einklang befinden, übermittelt jeder Mitgliedstaat der Kommission bis zum 15. März 2027 und danach alle drei Jahre einen Bericht mit diesen Daten.“

- 8. Folgender Anhang II wird angefügt:

„ANHANG II Anforderungen hinsichtlich des Ursprungs in der Union für Netto-Null-Technologien

  Teil I – Vergabe öffentlicher Aufträge

1. Im Einklang mit Artikel 25a enthalten die Vergabedokumente bei Verfahren zur Vergabe öffentlicher Aufträge, die nach Inkrafttreten dieser Verordnung veröffentlicht werden und in den Anwendungsbereich der Richtlinien 2014/23/EU, 2014/24/EU bzw. 2014/25/EU fallen und bei denen Aufträge, Bauaufträge oder Baukonzessionen die Beschaffung der folgenden Netto-Null-Technologien umfassen, die nachstehend aufgeführten Anforderungen:

  - a) Batterie-Energiespeichersysteme:

    - Vom [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt für Batterie-Energiespeichersysteme, dass diese ihren Ursprung in der Union haben und bei Projekten mit einer Batterie-Energiespeicherung von mehr als einer Megawattstunde ein Batteriemanagementsystem mit Ursprung in der Union enthalten müssen.

    - Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt für Batterie-Energiespeichersysteme, dass diese ihren Ursprung in der Union haben und Batteriezellen, ein Batteriemanagementsystem sowie ein zusätzliches wichtigstes spezifisches Bauteil mit Ursprung in der Union enthalten müssen.

  - b) Photovoltaiktechnologien: Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt für Photovoltaik-Wechselrichter und Photovoltaik-Zellen oder Gleichwertiges, dass diese ihren Ursprung in der Union haben müssen.

  - c) Hydronische Wärmepumpen: Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt für hydronische Wärmepumpen, dass diese ihren Ursprung in der Union haben müssen.

  - d) Technologien für Onshore- und Offshore-Windkraft:

    - Vom [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt, dass ein wichtigstes spezifisches Bauteil seinen Ursprung in der Union haben muss.

    - Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt, dass zwei wichtigste spezifische Bauteile ihren Ursprung in der Union haben müssen.

  - e) Kernspaltungstechnolgien:

    - Für Verfahren zur Vergabe öffentlicher Aufträge, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = vier Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden und bei denen Bauaufträge oder Baukonzessionen den Bau eines neuen Kernkraftwerks, einschließlich kleiner modularer Kernreaktoren, umfassen, gilt, dass mindestens zwei wichtigste spezifische Bauteile ihren Ursprung in der Union haben müssen.

    - Für Verfahren zur Vergabe öffentlicher Aufträge, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden und bei denen Bauaufträge oder Baukonzessionen den Bau eines neuen Kernkraftwerks, einschließlich kleiner modularer Kernreaktoren, umfassen, gilt, dass mindestens drei wichtigste spezifische Bauteile ihren Ursprung in der Union haben müssen.

    - Diese Anforderungen gelten nicht für Forschungs-, Entwicklungs- und Innovationsprojekte, einschließlich der erstmaligen industriellen Inbetriebnahme von Kernkraftwerken.

  Teil II – Auktionen

  Umfasst der Gegenstand der Auktionen die im Folgenden genannten Netto-Null-Technologien, nehmen die Mitgliedstaaten gemäß Artikel 26 die nachstehenden Vorqualifikations- oder Zuschlagskriterien auf:

  - a) Batterie-Energiespeichersysteme:

    - Bei Auktionen, die vom [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden, gilt für Batterie-Energiespeichersysteme, dass diese ihren Ursprung in der Union haben und bei Projekten mit einer Batterie-Energiespeicherung von mehr als einer Megawattstunde ein Batteriemanagementsystem mit Ursprung in der Union enthalten müssen.

    - Bei Auktionen, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden, gilt für Batterie-Energiespeichersysteme, dass diese ihren Ursprung in der Union haben und Batteriezellen, ein Batteriemanagementsystem sowie ein zusätzliches wichtigstes spezifisches Bauteil mit Ursprung in der Union enthalten müssen.

  - b) Photovoltaiktechnologien: Bei Auktionen, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden, gilt für Photovoltaik-Wechselrichter und Photovoltaik-Zellen oder Gleichwertiges, dass diese ihren Ursprung in der Union haben müssen.

  - c) Wasserstofftechnologien:

    - Bei Auktionen, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] veröffentlicht werden, gilt für Elektrolyseure zur Erzeugung von Wasserstoff, dass diese ihren Ursprung in der Union haben müssen; zudem müssen der Elektrolyseblock sowie ein zusätzliches wichtigstes spezifisches Bauteil ihren Ursprung in der Union haben.

    - Bei Auktionen, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden, gilt für Elektrolyseure zur Erzeugung von Wasserstoff, dass diese ihren Ursprung in der Union haben müssen; zudem müssen der Elektrolyseblock sowie zwei zusätzliche wichtigste spezifische Bauteile ihren Ursprung in der Union haben.

  - d) Technologien für Onshore- und Offshore-Windkraft:

    - Bei Auktionen, die vom [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] bis zum [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] veröffentlicht werden, gilt für Windkraftanlagen, dass ein wichtigstes spezifisches Bauteil seinen Ursprung in der Union haben muss.

    - Bei Auktionen, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] gilt für Windkraftanlagen, dass zwei wichtigste spezifische Bauteile ihren Ursprung in der Union haben müssen.

  Teil III – Andere Formen der öffentlichen Intervention

  Wenn die Mitgliedstaaten, regionalen oder lokalen Behörden, Einrichtungen des öffentlichen Rechts oder Verbände, die aus einer oder mehreren solcher Behörden oder einer oder mehreren solcher Einrichtungen des öffentlichen Rechts bestehen, beschließen, neue Regelungen einzurichten oder bestehende Regelungen zu aktualisieren, die Haushalten oder Unternehmen zugutekommen, die die Nachfrage nach den in diesem Absatz aufgeführten Endprodukten mit Netto-Null-Technologien unterstützen, gestalten sie die Regelungen gemäß Artikel 28b so, dass sichergestellt ist, dass die Begünstigten nur für die Regelung oder einen zusätzlichen finanziellen Ausgleich infrage kommen, wenn die nachstehenden Anforderungen erfüllt sind:

  - a) Batterie-Energiespeichersysteme:

    - Bei Regelungen, die zwischen dem [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] und dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] eingerichtet oder aktualisiert werden, gilt für Batterie-Energiespeichersysteme, dass diese ihren Ursprung in der Union haben und bei Projekten mit einer Batterie-Energiespeicherung von mehr als einer Megawattstunde ein Batteriemanagementsystem mit Ursprung in der Union enthalten müssen.

    - Bei Regelungen, die ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] eingerichtet oder aktualisiert werden, gilt für Batterie-Energiespeichersysteme, dass diese ihren Ursprung in der Union haben und Batteriezellen, ein Batteriemanagementsystem sowie ein zusätzliches wichtigstes spezifisches Bauteil mit Ursprung in der Union enthalten müssen.

  - b) Photovoltaiktechnologien: Bei Regelungen, die ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] eingerichtet oder aktualisiert werden, gilt für Photovoltaik-Wechselrichter und Photovoltaik-Zellen oder Gleichwertiges, dass diese ihren Ursprung in der Union haben müssen.

  - c) Hydronische Wärmepumpen: Bei Regelungen, die ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] eingerichtet oder aktualisiert werden, gilt für hydronische Wärmepumpen, dass diese ihren Ursprung in der Union haben müssen.

  Teil IV – Unterstützung der Mitgliedstaaten für den Bau oder die Fertigung von Netto-Null-Technologien

  Im Einklang mit Artikel 28c stellen die Mitgliedstaaten bei der Förderung des Baus oder der Herstellung der folgenden Endprodukte mit Netto-Null-Technologien sicher, dass die nachstehenden Anforderungen hinsichtlich des Ursprungs in der Union erfüllt sind:

  - a) Wasserstofftechnologien:

    - Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = ein Jahr nach Inkrafttreten dieser Verordnung] stellen die Mitgliedstaaten bei der Einrichtung neuer Förderregelungen für Investitionen in die Förderung der Kapazitäten zur Fertigung von Elektrolyseuren sicher, dass der Elektrolyseur sowie die Elektrolyseblöcke und mindestens ein wichtigstes spezifisches Bauteil des Elektrolyseurs ihren Ursprung in der Union haben.

    - Ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung] stellen die Mitgliedstaaten bei der Einrichtung neuer Förderregelungen für Investitionen in die Förderung der Kapazitäten zur Fertigung von Elektrolyseuren sicher, dass der Elektrolyseur sowie die Elektrolyseblöcke und mindestens zwei wichtigste spezifische Bauteile des Elektrolyseurs ihren Ursprung in der Union haben.

  - b) Nukleartechnologien:

    - Bei Projekten, für die der Förderantrag nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = vier Jahre nach Inkrafttreten dieser Verordnung] gestellt wird, stellen die Mitgliedstaaten bei der Förderung des Baus eines neuen Kernkraftwerks, einschließlich kleiner modularer Kernreaktoren, sicher, dass mindestens zwei wichtigste spezifische Bauteile des Endprodukts mit Kernspaltungstechnologie ihren Ursprung in der Union haben.

    - Bei Projekten, für die der Förderantrag nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Jahre nach Inkrafttreten dieser Verordnung] gestellt wird, stellen die Mitgliedstaaten bei der Förderung des Baus eines neuen Kernkraftwerks, einschließlich kleiner modularer Kernreaktoren, sicher, dass mindestens drei wichtigste spezifische Bauteile des Endprodukts mit Kernspaltungstechnologie ihren Ursprung in der Union haben.

    - Diese Anforderungen gelten nicht für Forschungs-, Entwicklungs- und Innovationsprojekte, einschließlich der erstmaligen industriellen Inbetriebnahme von Kernkraftwerken.“

<a id="art-35"></a>
### Artikel 35 – Änderungen der Verordnung (EU) Nr. 2024/3110

  Artikel 22 Absatz 9 Unterabsatz 1 der Verordnung (EU) 2024/3110 erhält folgende Fassung:

    „Um Transparenz für die Nutzer sicherzustellen und nachhaltige Produkte zu fördern, wird der Kommission die Befugnis übertragen, gemäß Artikel 89 delegierte Rechtsakte zur Ergänzung dieser Verordnung zu erlassen, um spezifische Anforderungen an die Kennzeichnung der ökologischen Nachhaltigkeit für bestimmte Produktfamilien und -kategorien festzulegen.“

<a id="art-36"></a>
### Artikel 36 – Inkrafttreten und Geltungsbeginn

  Diese Verordnung tritt am Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

  Die Artikel 4 und 5 gelten ab dem [Amt für Veröffentlichungen, bitte Datum einfügen = [ein] Jahr nach dem Datum des Inkrafttretens der vorliegenden Verordnung].

Diese Verordnung ist in allen ihren Teilen verbindlich und gilt gemäß den Verträgen unmittelbar in den Mitgliedstaaten.

Geschehen zu Brüssel am

Im Namen des Europäischen Parlaments Im Namen des Rates

Die Präsidentin Der Präsident/Die Präsidentin

<a id="finanz-und-digitalbogen-zu-rechtsakten"></a>
## FINANZ- UND DIGITALBOGEN ZU RECHTSAKTEN

### 1. RAHMEN DES VORSCHLAGS/DER INITIATIVE

#### 1.1. Bezeichnung des Vorschlags/der Initiative

    VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Schaffung eines Rahmens von Maßnahmen zur Beschleunigung der Verstärkung der industriellen Kapazitäten und der Dekarbonisierung in strategischen Sektoren sowie zur Änderung der Verordnungen (EU) 2018/1724, (EU) 2024/1735 und (EU) 2024/3110 („Verordnung zur industriellen Beschleunigung“)

#### 1.2. Politikbereich(e)

    Binnenmarkt, Wettbewerbsfähigkeit, Klima

#### 1.3. Ziel(e)

##### 1.3.1. Allgemeine(s) Ziel(e)

    Das allgemeine Ziel besteht darin, die dekarbonisierte und resiliente industrielle Fertigung im verarbeitenden Gewerbe der EU zu fördern, wobei energieintensiven Industrien und sauberen Technologien angesichts ihres Beitrags zur Wettbewerbsfähigkeit, wirtschaftlichen Sicherheit und zum nachhaltigen Wirtschaftswachstum in Europa im Einklang mit den Zielen des Deals für eine saubere Industrie besonderes Augenmerk gilt.

##### 1.3.2. Einzelziel(e)

    Einzelziel Nr. 1

    Erleichterung der Differenzierung nach CO2-armen Industrieprodukten, um ihren Wert und ihre Marktfähigkeit zu steigern

    Einzelziel Nr. 2

    Ankurbelung der Nachfrage nach europäischen CO2-armen Produkten und sauberen Technologien

    Einzelziel Nr. 3

    Maximierung der Qualität und des Nutzens ausländischer Investitionen in der EU

    Einzelziel Nr. 4

    Beschleunigung und Vereinfachung der Genehmigungen für die Dekarbonisierung der Industrie

    Einzelziel Nr. 5

    Erhöhung der Zahl der Investitionsprojekte in Industriegebieten

##### 1.3.3. Erwartete Ergebnisse und Auswirkungen

    Bitte geben Sie an, wie sich der Vorschlag/die Initiative auf die Begünstigten/Zielgruppen auswirken sollte.

    Wirtschaftliche Auswirkungen

    Durch die Einführung einer harmonisierten Kennzeichnung für CO2-arme Industrieprodukte und eines entsprechenden Überprüfungsmechanismus wird die Markttransparenz verbessert, sodass Hersteller einen Mehrwert aus einer umweltfreundlicheren Produktion erzielen können und ein Wettbewerb gefördert wird, der sich an der Leistung und nicht allein an den Kosten orientiert. Eine solche Kennzeichnung wird zudem dazu beitragen, neue Geschäftsmöglichkeiten für EU-Hersteller zu schaffen, die Preisdifferenzierung auf den internationalen Märkten zu verbessern und private Investitionen in CO2-arme Technologien anzuziehen.

    Durch die Erhöhung des Anteils von in der EU hergestellten CO2-armen Produkten am Binnenverbrauch wird die Maßnahme die Nachfrage auf dem europäischen Markt ankurbeln, die Wettbewerbsfähigkeit der Industrie stärken und die Abhängigkeit von CO2-intensiven oder eingeführten Alternativen verringern. Durch die Schaffung von Leitmärkten für CO2-armen Stahl, Zement und saubere Technologien werden schneller Größenvorteile erzielt und weitere Investitionen angeregt.

    Die Förderung von Joint Ventures und strategischen Partnerschaften, die einen europäischen Mehrwert schaffen, wird zur Stärkung des Wissenstransfers, der industriellen Innovationen und der technologischen Souveränität beitragen. Ein weiterer positiver Effekt sind eine verbesserte Sicherheit der Lieferketten, diversifizierte Bezugsquellen für Inputs und eine erhöhte Resilienz der industriellen Ökosysteme der EU.

    Durch die Verkürzung der Genehmigungsfristen lassen sich Projektverzögerungen verringern und die Finanzierungskosten senken, was ein besseres Investitionsklima für die Dekarbonisierung der Industrie zur Folge hat. Schnellere Genehmigungen tragen dazu bei, den Aufbau von Infrastrukturen für saubere Energie, die Errichtung von Anlagen zur CO2-Abscheidung und die Einrichtung von Elektrifizierungsprojekten zu beschleunigen, wodurch wiederum die industrielle Produktivität und die regionale Entwicklung angekurbelt werden.

    Durch die Förderung einer größeren Zahl von endgültigen Investitionsentscheidungen in Industriegebieten wird es möglich, die Kapitalbildung voranzutreiben, bestehende Anlagen zu modernisieren und zusätzliche private Finanzmittel anzuziehen. Durch die Konzentration von Investitionen auf Industriecluster werden Größenvorteile erzielt, und die regionale Wettbewerbsfähigkeit wird gestärkt.

    Soziale Auswirkungen

    Durch die Kennzeichnung der Treibhausgasintensität von Industrieprodukten wird das Vertrauen von Verbrauchern und Einkäufern in CO2-arme Produkte gestärkt und damit ein Beitrag zu qualifizierten Arbeitsplätzen in den Bereichen Überprüfung, Prüfung und Zertifizierung geleistet. Durch die Belohnung von Innovationen wird die Kennzeichnung dazu beitragen, hochwertige Arbeitsplätze in der Industrie zu erhalten und Weiterqualifizierung und Umschulung in allen Lieferketten des verarbeitenden Gewerbes zu fördern.

    Die steigende Nachfrage in der EU wird dazu beitragen, in Industrieregionen, die auf CO2-arme Industriezweige umstellen, hochwertige Arbeitsplätze zu erhalten und zu schaffen. Außerdem wird der regionale Zusammenhalt gestärkt, indem die Reindustrialisierung in den betroffenen Gebieten gefördert wird, während gleichzeitig die Anpassungskosten für die Arbeitnehmer durch stabile Produktionsaussichten abgefedert werden.

    Durch hochwertige ausländische Investitionen und Partnerschaften werden neue Beschäftigungsmöglichkeiten geschaffen, insbesondere in der fortgeschrittenen Herstellung und in forschungsintensiven Segmenten. Diese Investitionen und Partnerschaften werden auch die Zusammenarbeit zwischen Unternehmen aus der EU und aus Nicht-EU-Ländern stärken sowie die Ausbildung der Arbeitskräfte und den Austausch von Kompetenzen fördern

    Durch mehr Transparenz und verbesserte digitale Instrumente wird das Vertrauen der Bürgerinnen und Bürger erhöht, und ihre Beteiligung an lokalen Industrieprojekten wird gestärkt.

    Eine verstärkte industrielle Tätigkeit an bestehenden Standorten wird für stabile Arbeitsplätze sorgen und die lokalen Lieferketten stärken, während soziale Verwerfungen durch die Nutzung von Brachflächen und die Einbindung der vorhandenen Kompetenzen der Arbeitskräfte auf ein Minimum reduziert werden. Durch die Bildung von Industrieclustern werden die regionale Konvergenz und Resilienz gefördert.

    Ökologische Auswirkungen

    Ein zuverlässiger und vergleichbarer Kennzeichnungsrahmen wird Anreize für die Verringerung der Treibhausgasemissionen in allen industriellen Wertschöpfungsketten schaffen. Durch einen solchen Rahmen wird die kontinuierliche Verbesserung der Produktgestaltung, des Materialverbrauchs und der Energieeffizienz gefördert und die Industrie dabei unterstützt, das Ziel der Klimaneutralität zu erreichen.

    Durch die Einführung von Anforderungen an den CO2-Ausstoß und die damit einhergehende stärkere Verbreitung von CO2-armen Produkten wird es zu erheblichen Emissionsminderungen im Bau- und Verkehrssektor kommen. Dieser nachfrageorientierte Ansatz ergänzt angebotsseitige Innovationen und beschleunigt die allgemeine Dekarbonisierung der europäischen Wirtschaft.

    Kürzere und besser vorhersehbare Genehmigungsverfahren werden die Einführung CO2-armer Technologien und umweltfreundlicher Modernisierungsmaßnahmen beschleunigen, wodurch Emissionsminderungen früher erzielt werden können und ein Beitrag zu den klimapolitischen Zwischenzielen der EU geleistet wird.

    Durch die Konzentration neuer Projekte in Industriegebieten wird mit der Maßnahme eine effiziente Nutzung von Energie und natürlichen Ressourcen gefördert und die gemeinsame Nutzung von Infrastruktur für die CO2-Abscheidung, erneuerbare Energien und Abfallverwertung wird ermöglicht. Mit diesem Ansatz wird industrielles Wachstum mit Umweltschutz und den Prinzipien der Kreislaufwirtschaft in Einklang gebracht.

##### 1.3.4. Leistungsindikatoren

    Bitte geben Sie an, anhand welcher Indikatoren die Fortschritte und Ergebnisse verfolgt werden sollen.

    Die Anzahl der vergebenen Kennzeichnungen für CO2-arme Industrieprodukte wird Aufschluss darüber geben, welche Fortschritte bei der Schaffung eines zuverlässigen und transparenten Rahmens, der es Herstellern ermöglicht, ihre Produkte anhand ihrer CO2-Bilanz von anderen abzuheben, erzielt wurden. Sie wird als Indikator dafür dienen, welche Fortschritte die EU dabei erzielt hat, CO2-arme Industrieprodukte auf dem Markt sichtbar, überprüfbar und vergleichbar zu machen und so ihre Wettbewerbsfähigkeit und Wertschöpfung zu stärken.

    Am Anteil der CO2-armen EU-Produktion am EU-Verbrauch für die betreffenden Produkte wird sich der Anteil sauberer, in der EU hergestellter Materialien an der Gesamtnachfrage in der EU ablesen lassen. Dieser Anteil wird Aufschluss darüber geben, ob nachfrageseitige Maßnahmen, z. B. Vergabe öffentlicher Aufträge, Investitionsanreize und Kriterien hinsichtlich des Inhalts mit Ursprung in der EU, wirksam sind, wenn es darum geht, die Verbreitung CO2-armer, in Europa hergestellter Produkte zu fördern. Ein wachsender Anteil wird ein Zeichen für die Entstehung starker EU-Leitmärkte für umweltfreundliche Industriegüter sowie für eine geringere Abhängigkeit von CO2-intensiven Einfuhren sein.

    Die Anzahl der Joint Ventures in einschlägigen Sektoren, die einen europäischen Mehrwert schaffen und einen Beitrag zu Innovation und industrieller Resilienz leisten, wird das Ausmaß hochwertiger industrieller Partnerschaften zwischen Akteuren aus der EU und aus Nicht-EU-Ländern widerspiegeln, die zu Technologietransfer, Innovation und sicheren Lieferketten beitragen. Dies wird als Indikator für den Erfolg der Verordnung zur industriellen Beschleunigung bei der Anziehung nachhaltiger, „hochwertiger“ ausländischer Investitionen und bei der Förderung von Kooperationen dienen, die die industrielle Basis der EU stärken. Eine steigende Anzahl an Joint Ventures wird ein Zeichen für ein resilienteres und innovativeres industrielles Ökosystem sein, das einen größeren Mehrwert in Europa schafft.

    Die durchschnittliche Genehmigungszeit für Projekte zur Dekarbonisierung der Industrie wird Aufschluss über die Effizienz der Verwaltungsverfahren in den einzelnen Mitgliedstaaten geben. Sie wird als Messgröße dafür dienen, wie lange die zuständigen Behörden für die Bearbeitung und Genehmigung von Anträgen für Projekte zur Dekarbonisierung der Industrie, einschließlich Netzanschlüssen und Anschlüssen für saubere Energie, benötigen. Eine Verkürzung der durchschnittlichen Genehmigungszeiten wird ein Beleg dafür sein, dass die im Rahmen der Verordnung zur industriellen Beschleunigung eingeführten Maßnahmen zur Straffung, Koordinierung und Digitalisierung wirksam dazu beitragen, Investitionen zu beschleunigen und bürokratische Hürden für Unternehmen abzubauen.

    Die Anzahl der in den einschlägigen Industrien getroffenen endgültigen Investitionsentscheidungen wird als direkter Indikator für die Investitionsdynamik und das Vertrauen der Unternehmen in den industriellen Wandel in der EU dienen. An ihr wird sich ablesen lassen, in welchem Umfang Unternehmen Kapital für neue oder modernisierte Dekarbonisierungsprojekte bereitstellen, insbesondere in bestehenden Industriegebieten und Clustern. Steigt die Anzahl getroffener endgültiger Investitionsentscheidungen, wird dies als Zeichen dafür gesehen werden können, dass sich der durch die Verordnung zur industriellen Beschleunigung geschaffene Rahmen in konkreten Projekten niederschlägt, die zur Schaffung von Arbeitsplätzen, zur regionalen Reindustrialisierung und zur schnelleren Verbreitung sauberer Technologien in ganz Europa beitragen.

#### 1.4. Der Vorschlag/Die Initiative betrifft

     eine neue Maßnahme

     eine neue Maßnahme im Anschluss an ein Pilotprojekt/eine vorbereitende Maßnahme^(69)

     die Verlängerung einer bestehenden Maßnahme

     die Zusammenführung mehrerer Maßnahmen oder die Neuausrichtung mindestens einer Maßnahme

#### 1.5. Begründung des Vorschlags/der Initiative

##### 1.5.1. Kurz- oder langfristig zu deckender Bedarf, einschließlich einer detaillierten Zeitleiste für die Durchführung der Initiative

    Der Vorschlag trägt der dringenden Notwendigkeit Rechnung, die Dekarbonisierung der Industrie zu beschleunigen und die Wettbewerbsfähigkeit des verarbeitenden Gewerbes in Europa vor dem Hintergrund des globalen technologischen Wettbewerbs und des steigenden Investitionsbedarfs zu stärken. Ziel der Initiative ist es, Hindernisse zu beseitigen, die Investitionen in eine CO2-arme und resiliente Industrieproduktion bremsen, und die Integrität des Binnenmarkts bei seinem Übergang zur Klimaneutralität zu gewährleisten.

##### 1.5.2. Mehrwert aufgrund des Tätigwerdens der EU (kann sich aus unterschiedlichen Faktoren ergeben, z. B. Vorteile durch Koordinierung, Rechtssicherheit, größere Wirksamkeit oder Komplementarität). Für die Zwecke dieses Abschnitts bezeichnet der Ausdruck „Mehrwert aufgrund des Tätigwerdens der EU“ den Wert, der sich aus dem Tätigwerden der EU ergibt und den Wert ergänzt, der andernfalls allein von den Mitgliedstaaten geschaffen worden wäre.

    Gründe für Maßnahmen auf EU-Ebene (ex ante)

    Die Herausforderungen im Zusammenhang mit der Dekarbonisierung und Resilienz der Industrie machen nicht an Landesgrenzen Halt. Unterschiedliche Definitionen CO2-armer Produkte, unkoordinierte Maßnahmen auf der Nachfrageseite und uneinheitliche Genehmigungsverfahren bergen die Gefahr einer Fragmentierung des Binnenmarkts und einer Schwächung der industriellen Basis Europas. Nur durch ein koordiniertes Vorgehen auf EU-Ebene können gleiche Wettbewerbsbedingungen gewährleistet, die Umlenkung von Investitionen verhindert und sichergestellt werden, dass sich Klimapolitik und Industriepolitik gegenseitig verstärken. Die Verordnung stützt sich auf Artikel 114 AEUV, um das Funktionieren des Binnenmarkts zu erhalten, und gegebenenfalls auf Artikel 207 AEUV, um Kohärenz bei Maßnahmen im Zusammenhang mit ausländischen Investitionen zu gewährleisten.

    Erwarteter EU-Mehrwert (ex post)

    Ein Tätigwerden auf EU-Ebene wird durch Größenvorteile, niedrigere Transaktionskosten und mehr Rechtssicherheit für Investoren und Behörden dauerhafte Vorteile mit sich bringen. Es wird dazu beitragen, Europas Fähigkeit zur Herstellung CO2-armer Produkte zu stärken, nachhaltige Investitionen anzuziehen und die Umsetzung von Projekten zu beschleunigen. Durch harmonisierte Kriterien, gemeinsame digitale Instrumente und einheitliche Genehmigungsgrundsätze wird der Verwaltungsaufwand verringert, während gleichzeitig einheitliche Marktbedingungen in allen Mitgliedstaaten geschaffen werden.

##### 1.5.3. Aus früheren ähnlichen Maßnahmen gewonnene Erkenntnisse

    Die Erfahrungen mit der Netto-Null-Industrie-Verordnung, der Verordnung zu kritischen Rohstoffen und der Ökodesign-Verordnung für nachhaltige Produkte zeigen, dass gezielte Binnenmarktinstrumente, bei denen einheitliche Begriffsbestimmungen, nachfrageseitige Anreize und Verwaltungsvereinfachungen kombiniert werden, zu einer messbaren Beschleunigung der Investitionen führen. Diese Präzedenzfälle belegen die Wirksamkeit klarer Regelungsrahmen und einer strukturierten Koordinierung zwischen der Kommission und den Mitgliedstaaten. Im Rahmen der Verordnung zur industriellen Beschleunigung werden diese Erkenntnisse gezielt auf energieintensive Industrien und die Herstellung von Technologien für saubere Energie sowie auf Fahrzeugbauteile angewandt, um die Kohärenz mit bestehenden Instrumenten zu gewährleisten und regulatorische Überschneidungen zu vermeiden.

##### 1.5.4. Vereinbarkeit mit dem Mehrjährigen Finanzrahmen sowie mögliche Synergieeffekte mit anderen geeigneten Instrumenten

    Der Vorschlag steht voll und ganz im Einklang mit dem Mehrjährigen Finanzrahmen 2021-2027 und wird durch bestehende Unionsprogramme umgesetzt. Es werden Synergien mit dem Innovationsfonds, dem Programm „InvestEU“, dem Programm „Horizont Europa“, der Fazilität Connecting Europe für Energie, den Fonds der Kohäsionspolitik und dem Instrument für technische Unterstützung erwartet. Die Initiative ergänzt den Deal für eine saubere Industrie, die Verordnung zu kritischen Rohstoffen und den Europäischen Fonds für Wettbewerbsfähigkeit, ohne dass neue Mittelzuweisungen oder finanzielle Verpflichtungen über die bestehenden Mittel hinaus geschaffen werden.

##### 1.5.5. Bewertung der verschiedenen verfügbaren Finanzierungsoptionen, einschließlich der Möglichkeiten für eine Umschichtung

    Die Finanzierung wird vollständig durch Umschichtungen aus anderen Programmen sichergestellt. Unbeschadet des Ausgangs der Verhandlungen über den nächsten MFR handelt es sich bei den ab 2028 vorgesehenen Mitteln lediglich um Richtwerte.

#### 1.6. Laufzeit der vorgeschlagenen Maßnahme/der Initiative und Dauer der finanziellen Auswirkungen

     Befristete Laufzeit

    - –  Laufzeit: [TT.MM.]JJJJ bis [TT.MM.]JJJJ

    - –  Finanzielle Auswirkungen auf die Mittel für Verpflichtungen von JJJJ bis JJJJ und auf die Mittel für Zahlungen von JJJJ bis JJJJ

     Unbefristete Laufzeit

  - – Anlaufphase von JJJJ bis JJJJ

  - – Anschließend reguläre Umsetzung

    Die Verordnung tritt 2027 in Kraft und bleibt über das Jahr 2030 hinaus gültig, wobei alle fünf Jahre eine Überprüfung vorgenommen wird, um die Fortschritte und die Übereinstimmung mit den Zielen der Union in den Bereichen Klima und wirtschaftliche Sicherheit zu bewerten.

#### 1.7. Vorgeschlagene Haushaltsvollzugsart(en)

     Direkte Mittelverwaltung durch die Kommission

    - –  über ihre Dienststellen, einschließlich ihres Personals in den EU-Delegationen

    - –  über Exekutivagenturen

     Geteilte Mittelverwaltung mit Mitgliedstaaten

     Indirekte Mittelverwaltung durch Übertragung von Haushaltsvollzugsaufgaben an:

    - –  Drittländer oder die von ihnen benannten Einrichtungen

    - –  internationale Einrichtungen und deren Agenturen (bitte angeben)

    - –  die Europäische Investitionsbank und den Europäischen Investitionsfonds

    - –  Einrichtungen im Sinne der Artikel 70 und 71 der Haushaltsordnung

    - –  öffentlich-rechtliche Körperschaften

    - –  privatrechtliche Einrichtungen, die im öffentlichen Auftrag tätig werden, sofern ihnen ausreichende finanzielle Garantien bereitgestellt werden

    - –  privatrechtliche Einrichtungen eines Mitgliedstaats, die mit der Einrichtung einer öffentlich-privaten Partnerschaft betraut werden und denen ausreichende finanzielle Garantien bereitgestellt werden

    - –  Einrichtungen oder Personen, die mit der Durchführung bestimmter Maßnahmen im Bereich der Gemeinsamen Außen- und Sicherheitspolitik im Rahmen des Titels V des Vertrags über die Europäische Union betraut und die in dem maßgeblichen Basisrechtsakt benannt sind

    - – in einem Mitgliedstaat ansässige Einrichtungen, die dem Privatrecht eines Mitgliedstaats oder dem Unionsrecht unterliegen und im Einklang mit sektorspezifischen Vorschriften für die Betrauung mit der Ausführung von Unionsmitteln oder mit der Erteilung von Haushaltsgarantien in Betracht kommen, insofern diese Einrichtungen von öffentlich-rechtlichen Körperschaften oder von privatrechtlichen, im öffentlichen Auftrag tätig werdenden Einrichtungen kontrolliert und von den Kontrollstellen mit angemessenen finanziellen Garantien mit gesamtschuldnerischer Haftung oder gleichwertigen finanziellen Garantien ausgestattet werden, die bei jeder Maßnahme auf den Höchstbetrag der Unionsunterstützung begrenzt sein können.

### 2. VERWALTUNGSMAẞNAHMEN

#### 2.1. Überwachung und Berichterstattung

    Dieser Finanzbogen umfasst Personalausgaben. Es gelten die Standardvorschriften für diese Art von Ausgaben. Die Kommission wird die Leistungen, Ergebnisse und Auswirkungen dieses Vorschlags alle drei Jahre nach seinem Inkrafttreten bewerten. Im Rahmen der Bewertung wird der Beitrag dieser Verordnung zum Funktionieren des Binnenmarkts, einschließlich der in Artikel 1 genannten Ziele, insbesondere in Bezug auf Resilienz, wirtschaftliche Sicherheit und Dekarbonisierung der industriellen Fertigung, untersucht.

#### 2.2. Verwaltungs- und Kontrollsystem(e)

##### 2.2.1. Begründung der Haushaltsvollzugsart(en), des Durchführungsmechanismus/der Durchführungsmechanismen für die Finanzierung, der Zahlungsmodalitäten und der Kontrollstrategie, wie vorgeschlagen

    Die Initiative wird direkt von der Kommission verwaltet. Angesichts des begrenzten Umfangs der Ausgaben der Union, die sich auf übliche Verwaltungs- und Überwachungskosten beschränken, ist dies der am besten geeignete Ansatz. Durch die Anwendung etablierter interner Verfahren werden wirksame und effiziente Kontrollen, niedrige Fehlerquoten, eine rasche Bearbeitung von Vorgängen und minimale Kontrollkosten gewährleistet.

##### 2.2.2. Angaben zu den ermittelten Risiken und dem/den zu deren Eindämmung eingerichteten System(en) der internen Kontrolle

    Insgesamt fallen bei dieser Initiative Personalausgaben an. Es gelten die Standardvorschriften für diese Art von Ausgaben.

    Bei den meisten Aspekten der Initiative werden etablierte Verfahren für die Zusammenarbeit mit Interessenträgern, beispielsweise über das Industrieforum, sowie zur Umsetzung von Überwachungspflichten befolgt. Das größte operationelle Risiko ist die unzureichende Verwaltungskapazität zur Umsetzung der in der Verordnung vorgesehenen Arbeitspläne und Überwachungstätigkeiten.

    Diesem Vorschlag ist ein Folgenabschätzungsbericht beigefügt, der die Analysen enthält, die dem gewählten politischen Ansatz zugrunde liegen. Die Vorbereitung der Initiative umfasste auch eine öffentliche Konsultation sowie gezielte Konsultationen von Interessenträgern aus der Industrie, der Mitgliedstaaten und von Handelsverbänden, wodurch die Zusammenstellung einschlägiger Daten, Informationen und Rückmeldungen sichergestellt wurde. Dennoch können während der Durchführung unbeabsichtigte Folgen oder unvorhergesehene Auswirkungen auftreten. Diese werden im Rahmen der in der Verordnung festgelegten Überwachungsverfahren ermittelt, sodass die Kommission angemessen und rechtzeitig darauf reagieren kann.

##### 2.2.3. Schätzung und Begründung der Kosteneffizienz der Kontrollen (Verhältnis zwischen den Kontrollkosten und dem Wert der betreffenden verwalteten Mittel) sowie Bewertung des erwarteten Ausmaßes des Fehlerrisikos (bei Zahlung und beim Abschluss)

    Die Initiative ist mit begrenzten Verwaltungsausgaben verbunden. Es gelten die üblichen Kontrollverfahren der Kommission. Da keine Förderprogramme oder mehrschichtigen Durchführungsmechanismen geschaffen werden, bleiben die Kontrolltätigkeiten unkompliziert und kosteneffizient.

    Die Kontrollen werden vollständig im Rahmen der direkten Mittelverwaltung durchgeführt, wobei standardmäßige Ex-post-Prüfungen innerhalb des internen Kontrollrahmens der Kommission zum Einsatz kommen. Dadurch wird ein angemessenes Gleichgewicht zwischen dem Kontrollaufwand und dem begrenzten Wert der verwalteten Mittel gewährleistet.

    Angesichts des vereinfachten Aufbaus und des Fehlens von mit einem hohen Risiko verbundenen Finanzvorgängen ist die erwartete Fehlerquote bei Zahlung und beim Abschluss niedrig und liegt deutlich unter der Wesentlichkeitsschwelle. Das Kontrollsystem bietet daher ein hohes Maß an Sicherheit zu verhältnismäßigen Kosten.

#### 2.3. Prävention von Betrug und Unregelmäßigkeiten

    Im Rahmen der Initiative werden keine Finanzierungsprogramme oder finanziellen Förderregelungen eingerichtet. Sie stützt sich daher auf den bestehenden internen Kontrollrahmen und die Betrugsbekämpfungsstrategie der Kommission. Es gelten die üblichen Präventions- und Aufdeckungsmaßnahmen, einschließlich risikobasierter interner Kontrollen, Aufgabentrennung und festgelegter Arbeitsabläufe für Verwaltungsausgaben.

    Die Kommission sorgt dafür, dass geeignete Vorkehrungen getroffen werden, damit bei der Wahrnehmung der Aufgaben, die sich aus dieser Verordnung ergeben, die finanziellen Interessen der EU gewahrt werden.

    Wie bei allen von der Kommission verwalteten Maßnahmen können das Europäische Amt für Betrugsbekämpfung (OLAF) und die Europäische Staatsanwaltschaft (EUStA) ihre Befugnisse zur Untersuchung von Betrug, Korruption oder sonstigen rechtswidrigen Handlungen zum Nachteil der finanziellen Interessen der EU gemäß ihren jeweiligen Rechtsgrundlagen ausüben. Der Europäische Rechnungshof behält seine üblichen Prüfungsbefugnisse in Bezug auf die Ausgaben der Kommission.

### 3. GESCHÄTZTE FINANZIELLE AUSWIRKUNGEN DES VORSCHLAGS/DER INITIATIVE

#### 3.1. Betroffene Rubrik(en) des Mehrjährigen Finanzrahmens und Ausgabenlinie(n) im Haushaltsplan

  - Bestehende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM^(70) | von EFTA-Ländern^(71) | von Kandidatenländern und potenziellen Kandidaten^(72) | von anderen Drittländern | andere zweckgebundene Einnahmen |
| 1 | 03 02 01 02 | GM/NGM | Ja | Nein | Nein | Nein |
| 7 | 20 01 02 01 | NGM | Nein | Nein | Nein | Nein |

  - Neu zu schaffende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM | von EFTA-Ländern | von Kandidatenländern und potenziellen Kandidaten | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | Nicht zutreffend |  |  |  |  |  |

#### 3.2. Geschätzte finanzielle Auswirkungen des Vorschlags auf die Mittel

##### 3.2.1. Übersicht über die geschätzten Auswirkungen auf die operativen Mittel

  - –  Für den Vorschlag/die Initiative werden keine operativen Mittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden operativen Mittel benötigt:

##### 3.2.1.1. Mittel aus dem verabschiedeten Haushaltsplan

| Rubrik des Mehrjährigen Finanzrahmens | 1 | „Binnenmarkt, Innovation und Digitales“ |
| --- | --- | --- |

in Mio. EUR (3 Dezimalstellen)

| GD GROW | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT | MFR 2028-2034 INSGESAMT^(73) |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |  |
| 03 02 01 02 | Verpflichtungen | (1a) | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
|  | Zahlungen | (2a) | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
| Mittel INSGESAMT für GD GROW | Verpflichtungen | =1a+1b | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
|  | Zahlungen | =2a+2b | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |

in Mio. EUR (3 Dezimalstellen)

| GD GROW | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT MFR 2028-2034^(74) |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |  |  |  |
| 03 02 01 02 | Verpflichtungen | (1a) | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |
|  | Zahlungen | (2a) | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |
| Mittel INSGESAMT für GD GROW | Verpflichtungen | =1a+1b | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |
|  | Zahlungen | =2a+2b | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT | MFR 2028-2034 INSGESAMT^(75) |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK 1 | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT MFR 2028-2034^(76) |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |
| Operative Mittel INSGESAMT (einschließlich des Beitrags an die dezentrale Agentur) | Verpflichtungen | (4) | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |
|  | Zahlungen | (5) | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK 1 | Verpflichtungen | = 4+6 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |

in Mio. EUR (3 Dezimalstellen)

|  |  |  |  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT | MFR 2028-2034 INSGESAMT^(77) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | 2024 | 2025 | 2026 | 2027 |  |  |
| • Operative Mittel INSGESAMT (alle operativen Rubriken) | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |  |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |  |
| • Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT (alle operativen Rubriken) | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 6 | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |  |
| des Mehrjährigen Finanzrahmens (Referenzbetrag) | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |  |

in Mio. EUR (3 Dezimalstellen)

|  |  |  |  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT MFR 2028-2034^(78) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| • Operative Mittel INSGESAMT (alle operativen Rubriken) | Verpflichtungen | (4) | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |  |
|  | Zahlungen | (5) | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |  |
| • Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT (alle operativen Rubriken) | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| Mittel INSGESAMT unter den Rubriken 1 bis 6 | Verpflichtungen | = 4+6 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |  |
| des Mehrjährigen Finanzrahmens (Referenzbetrag) | Zahlungen | = 5+6 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,020 | 0,140 |  |

| Rubrik des Mehrjährigen Finanzrahmens | 7 |  |
| --- | --- | --- |

in Mio. EUR (3 Dezimalstellen)

| GD GROW | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT | MFR 2028-2034 INSGESAMT^(79) |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
|  Personalausgaben | 0,000 | 0,000 | 0,000 | 1,164 | 1,164 | 8,148 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD GROW INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 1,164 | 1,164 | 8,148 |
| Mittel INSGESAMT unter der RUBRIK 7 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 0,000 | 0,000 | 0,000 | 1,164 | 1,164 | 8,148 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT | MFR 2028-2034 INSGESAMT^(80) |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 7 | Verpflichtungen | 0,000 | 0,000 | 0,000 | 1,204 | 1,204 | 8,288 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 0,000 | 0,000 | 0,000 | 1,204 | 1,204 | 8,288 |

| Rubrik des Mehrjährigen Finanzrahmens | 7 | „Verwaltungsausgaben“[1] |
| --- | --- | --- |

in Mio. EUR (3 Dezimalstellen)

| GD GROW | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT MFR 2028-2034^(81) |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
|  Personalausgaben | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 8,148 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD GROW INSGESAMT | Mittel | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 8,148 |

| Mittel INSGESAMT unter der RUBRIK 7 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 8,148 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT MFR 2028-2034^(82) |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 7 | Verpflichtungen | 1,184 | 1,184 | 1,184 | 1,184 | 1,184 | 1,184 | 1,184 | 8,288 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 1,184 | 1,184 | 1,184 | 1,184 | 1,184 | 1,184 | 1,184 | 8,288 |

##### 3.2.2. Geschätzter Output, der mit operativen Mitteln finanziert wird (nicht auszufüllen im Fall dezentraler Agenturen)

Mittel für Verpflichtungen, in Mio. EUR (3 Dezimalstellen)

| Ziele und Outputs angeben  |  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Bei länger andauernden Auswirkungen bitte weitere Spalten einfügen (siehe 1.6) | GESAMT- |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art^(83) | Durchschnittskosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Gesamtzahl | Gesamtkosten |
| EINZELZIEL Nr. 1^(84)… |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 1 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 |  |  |
| EINZELZIEL Nr. 2... |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 2 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 |  |  |
| INSGESAMT | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 |  |  |

| Ziele und Outputs angeben |  |  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028-2034^(85) | POST | GESAMT- |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 | GESAMT- |  |  |  |  |  |  |  |  |  |  |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art | Durchschnittskosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten |
| EINZELZIEL Nr. 1… |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0 | 0,000 |  |  | 0 | 0,000 |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0 | 0,000 |  |  | 0 | 0,000 |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0 | 0,000 |  |  | 0 | 0,000 |
| Zwischensumme für Einzelziel Nr. 1 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 |  |  |
| EINZELZIEL Nr. 2... |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0 | 0,000 |  |  | 0 | 0,000 |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0 | 0,000 |  |  | 0 | 0,000 |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 0 | 0,000 |  |  | 0 | 0,000 |
| Zwischensumme für Einzelziel Nr. 2 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 |  |  |
| INSGESAMT | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 | 0 | 0,000 |  |  |

##### 3.2.3. Übersicht über die geschätzten Auswirkungen auf die Verwaltungsmittel

  - –  Für den Vorschlag/die Initiative werden keine Verwaltungsmittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden Verwaltungsmittel benötigt:

#####  3.2.3.1. Mittel aus dem verabschiedeten Haushaltsplan

in Mio. EUR (3 Dezimalstellen)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | 2021-2027 INSGESAMT | 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
| RUBRIK 7 |  |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 1,164 | 1,164 | 8,148 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 1,164 | 1,164 | 8,148 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 1,164 | 1,164 | 8,148 |

Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

in Mio. EUR (3 Dezimalstellen)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | POST | GESAMTSUMME |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 |  |
| RUBRIK 7 |  |  |  |  |  |  |  |  |  |  |
| Personalausgaben | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 8,148 | 0,000 | 8,148 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 8,148 | 0,000 | 8,148 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 1,164 | 8,148 | 0,000 | 8,148 |

Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

##### 3.2.4. Geschätzter Personalbedarf

  - –  Für den Vorschlag/die Initiative wird kein Personal benötigt.

  - –  Für den Vorschlag/die Initiative wird das folgende Personal benötigt:

##### 3.2.4.1. Finanziert aus dem verabschiedeten Haushalt

Schätzung in Vollzeitäquivalenten (VZÄ)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
|  Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |  |  |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 0 | 0 | 0 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| • Externes Personal (in VZÄ) |  |  |  |  |  |  |  |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 0 | 0 | 0 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 |  |

Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt. Der Personalbedarf wird durch Bedienstete der GD gedeckt, die bereits der Verwaltung der Maßnahme zugeordnet sind und/oder innerhalb der betroffenen Dienststellen der Kommission umgeschichtet wurden.

    Für die Durchführung des Vorschlags benötigtes Personal (in VZÄ):

|  | Personal aus den Dienststellen der Kommission | Zusatzpersonal (ausnahmsweise)* |  |  |
| --- | --- | --- | --- | --- |
|  |  | Zu finanzieren aus Rubrik 7 oder Forschung | Zu finanzieren aus einer Haushaltslinie für administrative Unterstützung | Zu finanzieren aus Gebühren |
| Planstellen | 6 |  | Nicht zutreffend |  |
| Externes Personal (VB, ANS, LAK) |  |  |  |  |

    Beschreibung der Aufgaben, die ausgeführt werden sollen durch:

| Beamte und Zeitbedienstete | Für die Ausführung der im Vorschlag vorgesehenen Aufgaben im Bereich Leitmärkte und Überprüfung ausländischer Direktinvestitionen wird zusätzliches Personal (entsprechend sechs VZÄ) benötigt. Die sechs VZÄ werden innerhalb der für die Durchführung zuständigen Generaldirektion umgeschichtet. |
| --- | --- |
| Externes Personal |  |

##### 3.2.5. Einschätzung der Auswirkungen auf die Investitionen im Zusammenhang mit digitalen Technologien

| Mittel INSGESAMT für Digitales und IT | Jahr | Jahr | Jahr | Jahr | MFR 2021-2027 INSGESAMT | MFR 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- |
|  | 2024 | 2025 | 2026 | 2027 |  |  |
| RUBRIK 7 |  |  |  |  |  |  |
| IT-Ausgaben (intern) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |  |
| IT-Ausgaben zur Politikunterstützung für operationelle Programme | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,040 | 0,040 | 0,140 |

##### 3.2.6. Vereinbarkeit mit dem derzeitigen Mehrjährigen Finanzrahmen

    Der Vorschlag/Die Initiative

  - –  kann durch Umschichtungen innerhalb der entsprechenden Rubrik des Mehrjährigen Finanzrahmens (MFR) in voller Höhe finanziert werden.

  - –  erfordert die Inanspruchnahme des verbleibenden Spielraums unter der einschlägigen Rubrik des MFR und/oder den Einsatz der besonderen Instrumente im Sinne der MFR-Verordnung.

  - –  erfordert eine Änderung des MFR.

##### 3.2.7. Beiträge Dritter

    Der Vorschlag/Die Initiative

  - –  sieht keine Kofinanzierung durch Dritte vor.

  - –  sieht folgende Kofinanzierung durch Dritte vor:

Mittel in Mio. EUR (3 Dezimalstellen)

|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Jahr 2032 | Jahr 2033 | Jahr 2034 | Insgesamt |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kofinanzierende Einrichtung |  |  |  |  |  |  |  |  |  |  |  |  |
| Kofinanzierung INSGESAMT |  |  |  |  |  |  |  |  |  |  |  |  |

3.3. Geschätzte Auswirkungen auf die Einnahmen

  - –  Der Vorschlag/Die Initiative wirkt sich nicht auf die Einnahmen aus.

  - –  Der Vorschlag/Die Initiative wirkt sich auf die Einnahmen aus, und zwar

- –  auf die Eigenmittel

- –  auf die übrigen Einnahmen

- –  Bitte geben Sie an, ob die Einnahmen bestimmten Ausgabenlinien zugeordnet sind.

in Mio. EUR (3 Dezimalstellen)

| Einnahmenlinie: | Für das laufende Haushaltsjahr zur Verfügung stehende Mittel | Auswirkungen des Vorschlags/der Initiative^(86) |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Jahr 2032 | Jahr 2033 | Jahr 2034 |
| Artikel …. |  |  |  |  |  |  |  |  |  |  |  |  |

### 4. Digitale Aspekte

#### 4.1. Anforderungen von digitaler Relevanz

Wenn festgestellt wird, dass die Initiative keine Anforderungen von digitaler Relevanz aufweist:

Begründung, warum keine digitalen Mittel genutzt werden können, um die Umsetzung der Strategie zu verbessern, und warum das Prinzip „standardmäßig digital“ nicht anwendbar ist.

| Nicht zutreffend |
| --- |

Ansonsten:

Allgemeine Beschreibung der Anforderungen von digitaler Relevanz und der damit verbundenen Kategorien (Daten, Digitalisierung und Automatisierung von Prozessen, digitale Lösungen und/oder digitale öffentliche Dienste)

| Anforderung | Beschreibung der Anforderung | Von der Anforderung betroffene(r) oder betreffende(r) Akteur(e) | Verfahren auf übergeordneter Ebene | Kategorien |
| --- | --- | --- | --- | --- |
| Artikel 4 | Einrichtung eines zentralen Zugangspunkts auf nationaler Ebene, der alle zuständigen Behörden miteinander verbindet, um sicherzustellen, dass Genehmigungsverfahren für industrielle Fertigungsprojekte vollständig digital abgewickelt werden. | Mitgliedstaaten Zuständige nationale Behörden Wirtschaftsteilnehmer | Erteilung von Genehmigungen | Daten Digitale Lösung Digitale öffentliche Dienste Prozessdigitalisierung und -automatisierung |
| Artikel 5 | Koordinierung der nationalen Genehmigungsverfahren, um einen zentralen Zugangspunkt für die Genehmigung industrieller Fertigungsprojekte zu ermöglichen. | Mitgliedstaaten Zuständige nationale Behörden | Erteilung von Genehmigungen | Daten Prozessdigitalisierung und -automatisierung |
| Artikel 6 | Ausweitung der Anwendung gestraffter Verwaltungs- und Genehmigungsverfahren im Sinne der Verordnung (EU) 2024/1735 auf Projekte zur Dekarbonisierung energieintensiver Industrien | Mitgliedstaaten Zuständige nationale Behörden | Erteilung von Genehmigungen | Prozessdigitalisierung und -automatisierung |
| Artikel 20 | Überwachung und Veröffentlichung der globalen Fertigungskapazität für aufstrebende strategische Sektoren | Europäische Kommission | Überwachung | Daten |
| Artikel 16 | Anmeldung geplanter Direktinvestitionen durch ausländische Investoren. | Wirtschaftsteilnehmer Mitgliedstaaten | Anmeldungen | Daten |
| Artikel 17 | Überprüfungs- und Genehmigungsverfahren für die Anmeldung geplanter Direktinvestitionen | Mitgliedstaaten Europäische Kommission | Anmeldungen | Prozessdigitalisierung und -automatisierung |
| Artikel 19-20 | Überwachung der Einhaltung der Anforderungen in Bezug auf ausländische Investitionen | Zuständige nationale Behörden Europäische Kommission | Berichterstattung | Daten |
| Artikel 22 | Mitteilung der von den Mitgliedstaaten ausgewiesenen Beschleunigungsgebiete für die industrielle Fertigung, einschließlich der erforderlichen Prüfungen | Mitgliedstaaten Europäische Kommission | Anmeldungen | Daten |
| Artikel 24 | Einführung einer aggregierten Basisgenehmigung, mit der industrielle Tätigkeiten in ausgewiesenen Beschleunigungsgebieten genehmigt werden | Mitgliedstaaten Zuständige nationale Behörden | Erteilung von Genehmigungen | Prozessdigitalisierung und -automatisierung |
| Artikel 37 | Erweiterung der Liste der Informationsbereiche, die für Bürgerinnen und Bürger und Unternehmen bei der Ausübung ihrer Binnenmarktrechte gemäß der Verordnung (EU) 2018/1724 relevant sind, durch Informationen über Genehmigungsverfahren, wobei Lösungen im Rahmen des einheitlichen digitalen Zugangstors wirksam genutzt werden | Europäische Kommission Mitgliedstaaten Zuständige nationale Behörden Wirtschaftsteilnehmer Bürgerinnen und Bürger | Informationsaustausch | Daten Prozessdigitalisierung und -automatisierung Digitale öffentliche Dienste |

#### 4.2. Daten

Allgemeine Beschreibung der erfassten Daten

| Art der Daten | Anforderung(en) | Standard und/oder Spezifikation (falls zutreffend) |
| --- | --- | --- |
| Anträge auf Genehmigungen für industrielle Fertigungsprojekte | Artikel 4, Artikel 5 | Der Kommission wird die Befugnis übertragen, Durchführungsrechtsakte zur Festlegung der technischen Standards zu erlassen, die erforderlich sind, um die Interoperabilität der nationalen zentralen Zugangspunkte zu gewährleisten. |
| Daten zur globalen Fertigungskapazität für aufstrebende strategische Sektoren | Artikel 20 | Die Kommission stellt für jeden der aufstrebenden strategischen Sektoren aktualisierte Informationen über das letzte Jahr, für das Daten vorliegen, bereit und veröffentlicht diese. |
| Anmeldung geplanter Investitionen durch ausländische Investoren | Artikel 16 | Nicht zutreffend |
| Berichte über die Einhaltung der Anforderungen in Bezug auf ausländische Investitionen | Artikel 19-20 | Nicht zutreffend |
| Meldung der ausgewiesenen Beschleunigungsgebiete für die industrielle Fertigung | Artikel 22 | Nicht zutreffend |

Vereinbarkeit mit der europäischen Datenstrategie

Erläuterung, inwiefern die Anforderung(en) mit der Europäischen Datenstrategie vereinbar ist/sind.

| Diese Gesetzgebungsinitiative steht im Einklang mit der Nutzung privater Daten durch staatliche Behörden (Business-to-Government – B2G), um faktengestützte politische Entscheidungen zu gewährleisten. Das digitale Genehmigungssystem wird so konzipiert, dass die Interoperabilität und der automatisierte Datenaustausch zwischen den zuständigen Behörden, die Weiterverwendung von Daten und Dokumenten, die sich bereits im Besitz von Behörden befinden, ein hohes Maß an Cybersicherheit und Informationsintegrität sowie Transparenz und Rechenschaftspflicht im Genehmigungsverfahren gewährleistet sind. |
| --- |

Vereinbarkeit mit dem Grundsatz der einmaligen Erfassung

Erläuterung, inwiefern der Grundsatz der einmaligen Erfassung berücksichtigt wurde und inwiefern die Möglichkeit der Weiterverwendung vorhandener Daten geprüft wurde.

| Die Weiterverwendung von Daten, die sich bereits im Besitz von Behörden befinden, ist gewährleistet. Die Genehmigungsverfahren werden in den Anwendungsbereich des einheitlichen digitalen Zugangstors und des Systems zur einmaligen Erfassung aufgenommen. Der Grundsatz der einmaligen Erfassung wird in diesem Fall eingehalten, um den Verwaltungsaufwand für die im Binnenmarkt tätigen Akteure so gering wie möglich zu halten. Die Mitgliedstaaten und die Kommission gewährleisten den Schutz vertraulicher Geschäftsinformationen. |
| --- |

Erläuterung, inwiefern neu geschaffene Daten auffindbar, zugänglich, interoperabel und wiederverwendbar sind und hohen Standards entsprechen.

| Die Kommission legt im Wege von Durchführungsrechtsakten detaillierte Vorschriften, technische Normen und Verfahren fest, die erforderlich sind, um die Interoperabilität, die Sicherheit und das wirksame Funktionieren der digitalen Genehmigungssysteme zu gewährleisten. |
| --- |

Datenströme

Allgemeine Beschreibung der Datenströme

| Art der Daten | Anforderung(en) | Akteur, der die Daten bereitstellt | Akteur, der die Daten empfängt | Auslöser für den Datenaustausch | Häufigkeit (falls zutreffend) |
| --- | --- | --- | --- | --- | --- |
| Genehmigungsanträge | Artikel 4 | Wirtschaftsteilnehmer | Zuständige nationale Behörde | Erforderlich für Genehmigungsanträge | Nicht zutreffend |
| Anmeldung geplanter Investitionen durch ausländische Investoren | Artikel 16 | Wirtschaftsteilnehmer | Zuständige nationale Behörde | Bei der Absicht, eine Investition zu tätigen | Nicht zutreffend |
| Berichte über die Einhaltung der Anforderungen in Bezug auf ausländische Investitionen | Artikel 19-20 | Zuständige nationale Behörde | Europäische Kommission | Auf Verlangen | Nicht zutreffend |
| Beschluss über die Ausweisung von Beschleunigungsgebieten für die industrielle Fertigung | Artikel 22 | Mitgliedstaat | Europäische Kommission | Annahme des Beschlusses | Nicht zutreffend |

#### 4.3. Digitale Lösungen

Bitte geben Sie für jede digitale Lösung die sie betreffende(n) Anforderung(en) von digitaler Relevanz, eine Beschreibung der vorgeschriebenen Funktionalität der digitalen Lösung, die Stelle, die dafür zuständig sein wird, und andere relevante Aspekte wie Wiederverwendbarkeit und Zugänglichkeit an. Erläutern Sie bitte abschließend, ob bei der digitalen Lösung der Einsatz von KI-Technologien vorgesehen ist.

| Digitale Lösung | Anforderung(en) | Wichtigste vorgeschriebene Funktionen | Zuständige Stelle | Inwiefern wird Zugänglichkeit gewährleistet? | Wie wird die Wiederverwendbarkeit berücksichtigt? | Einsatz von KI-Technologien (falls zutreffend) |
| --- | --- | --- | --- | --- | --- | --- |
| Digitales Genehmigungssystem | Artikel 4 | Die Genehmigungsverfahren für industrielle Fertigungsprojekte werden vollständig digital abgewickelt. Das System bietet eine einzige Benutzerschnittstelle, die die Interaktion mit den einschlägigen öffentlichen Diensten ermöglicht. Das digitale Genehmigungssystem ermöglicht die papierlose Einreichung, Nachverfolgung und Entscheidung von Genehmigungsanträgen. | Mitgliedstaaten Zuständige nationale Behörden | Das digitale Genehmigungssystem ermöglicht die papierlose Einreichung, Nachverfolgung und Entscheidung von Genehmigungsanträgen und ist so konzipiert, dass die Benutzerfreundlichkeit und Zugänglichkeit für alle Antragsteller, einschließlich Menschen mit Behinderungen, gewährleistet ist. | Das digitale Genehmigungssystem ermöglicht die papierlose Einreichung, Nachverfolgung und Entscheidung von Genehmigungsanträgen und ist so konzipiert, dass die Weiterverwendung von Daten und Dokumenten, die sich bereits im Besitz von Behörden befinden, gewährleistet ist. | // |

Für jede digitale Lösung Erläuterung, inwiefern diese mit geltenden digitalen Strategien und Rechtsvorschriften im Einklang steht.

Digitales Genehmigungssystem

| Digitale und/oder sektorspezifische Strategien (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Nicht zutreffend |
| EU-Rahmen für Cybersicherheit | Das nationale digitale Genehmigungssystem ist so konzipiert, dass ein hohes Maß an Datenschutz, Cybersicherheit und Informationsintegrität gewährleistet ist. |
| eIDAS | // |
| Einheitliches digitales Zugangstor und IMI | Die Verordnung über das einheitliche digitale Zugangstor wird dahin gehend geändert, dass Informationen über Genehmigungsverfahren für industrielle Fertigungsprojekte und Verfahren im Zusammenhang mit industriellen Fertigungsprojekten in ihren Anwendungsbereich aufgenommen werden. |
| Sonstige | System zur einmaligen Erfassung |

#### 4.4. Interoperabilitätsbewertung

Allgemeine Beschreibung der von den Anforderungen betroffenen digitalen öffentlichen Dienste

| Digitaler öffentlicher Dienst oder Kategorie digitaler öffentlicher Dienste | Beschreibung | Anforderung(en) | Lösung(en) für ein interoperables Europa (NICHT ZUTREFFEND) | Andere Interoperabilitätslösung(en) |
| --- | --- | --- | --- | --- |
| Digitales Genehmigungssystem Kategorie digitaler öffentlicher Dienste nach COFOG 04.7.4 | Die Mitgliedstaaten richten ein nationales digitales Genehmigungssystem ein, das alle zuständigen Behörden miteinander verbindet, um sicherzustellen, dass Genehmigungsverfahren für industrielle Fertigungsprojekte vollständig digital abgewickelt werden. | Artikel 4 | // | System zur einmaligen Erfassung |

Bewerten Sie die Auswirkungen der Anforderung(en) auf die grenzüberschreitende Interoperabilität.

Digitaler öffentlicher Dienst #1: Digitales Genehmigungssystem

| Bewertung | Maßnahme(n) | Mögliche verbleibende Hindernisse (falls zutreffend) |
| --- | --- | --- |
| Organisatorische Maßnahmen für eine reibungslose grenzüberschreitende Erbringung digitaler öffentlicher Dienste | Die Mitgliedstaaten sind für die Entwicklung, den Betrieb, die Instandhaltung, die Sicherheit und die Überwachung ihrer digitalen Genehmigungssysteme zuständig. Bei der Umsetzung der digitalen Genehmigungssysteme sollten so weit wie möglich bestehende digitale Infrastrukturen, Kataloge und Bausteine der Union genutzt werden, auch solche, die im Rahmen des technischen Systems zur einmaligen Erfassung und der zugehörigen Durchführungsrechtsakte entwickelt wurden. Auf diese Weise werden Komplementarität, Interoperabilität und die effiziente Nutzung öffentlicher Mittel gefördert, während gleichzeitig Überschneidungen mit bestehenden digitalen Lösungen vermieden werden. | Es können zusätzliche organisatorische Maßnahmen auf nationaler Ebene erforderlich sein, um eine angemessene Einbeziehung der für Einzelgenehmigungen zuständigen Behörden zu gewährleisten. |
| Maßnahmen, die ergriffen wurden, um ein gemeinsames Verständnis der Daten zu gewährleisten | Die Kommission legt im Wege von Durchführungsrechtsakten detaillierte Vorschriften, technische Normen und Verfahren fest, die erforderlich sind, um die Interoperabilität, die Sicherheit und das wirksame Funktionieren der digitalen Genehmigungssysteme zu gewährleisten. Die Genehmigungsverfahren werden in den Anwendungsbereich des einheitlichen digitalen Zugangstors und des Systems zur einmaligen Erfassung aufgenommen. |  |
| Verwendung gemeinsam vereinbarter offener technischer Spezifikationen und Standards | Die Kommission legt im Wege von Durchführungsrechtsakten detaillierte Vorschriften, technische Normen und Verfahren fest, die erforderlich sind, um die Interoperabilität, die Sicherheit und das wirksame Funktionieren der digitalen Genehmigungssysteme zu gewährleisten. |  |

#### 4.5. Unterstützungsmaßnahmen für die digitale Umsetzung

Bitte füllen Sie für jede Unterstützungsmaßnahmen für die digitale Umsetzung die nachstehende Tabelle aus:

| Beschreibung der Maßnahme | Anforderung(en) | Rolle der Kommission (falls zutreffend) | Zu beteiligende Akteure (falls zutreffend) | Voraussichtlicher Zeitplan (falls zutreffend) |
| --- | --- | --- | --- | --- |
| Durchführungsrechtsakte | Artikel 4, 13, 31 | Durchführungsrechtsakte | Europäische Kommission |  |

^(1) Gemeinsame Mitteilung über die Stärkung der wirtschaftlichen Sicherheit in der EU , JOIN(2025) 977 final.

^(2) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Der Deal für eine saubere Industrie: Ein gemeinsamer Fahrplan für Wettbewerbsfähigkeit und Dekarbonisierung (COM(2025) 85 final vom 26.2.2025.

^(3) Eurostat, Unternehmen nach detaillierter NACE Rev. 2 Tätigkeit und besonderen Tätigkeitsaggregaten [sbs_ovw_act__custom_20259000] , zuletzt aktualisiert am 8. Dezember 2025, DOI: 10.2908/sbs_ovw_act.

^(4) Eurostat, Bruttowertschöpfung und Einkommen nach wichtigsten Wirtschaftsbereichen (NACE Rev. 2) [nama_10_a10__custom_20259318] , zuletzt aktualisiert am 20. Februar 2026, DOI: 10.2908/nama_10_a10.

^(5) Eurostat, Luftemissionsrechnungen nach NACE Rev. 2 Tätigkeit [env_ac_ainah_r2__custom_20259376] , zuletzt aktualisiert am 28. November 2025, DOI: 10.2908/env_ac_ainah_r2.

^(6) Eurostat, Bruttowertschöpfung und Einkommen nach wichtigsten Wirtschaftsbereichen (NACE Rev. 2) [nama_10_a10__custom_20259318] , zuletzt aktualisiert am 20. Februar 2026, DOI: 10.2908/nama_10_a10.

^(7) Draghi, M. (2024). The future of European competitiveness – In-depth analysis and recommendations (Part B) .

^(8) Interne Analyse der Europäischen Kommission, siehe Folgenabschätzungsbericht.

^(9) Arbeitsunterlage der OECD: A comprehensive overview of the Energy Intensive Industries ecosystem , 2025/09.

^(10) Ein europäischer Aktionsplan für Stahl und Metalle (COM(2025) 125 final vom 19. März 2025).

^(11) Bis 2040 werden für die chemische Industrie, die Grundmetallindustrie, die Industrie für nichtmetallische Mineralien sowie die Zellstoff- und Papierindustrie rund 500 Mrd. EUR benötigt – Draghi, M. (2024). The future of European competitiveness – In-depth analysis and recommendations (Part B) , S. 99, und Arbeitsunterlage der Kommissionsdienststellen , Folgenabschätzungsbericht, Europas Klimaziel für 2040 und Weg zur Klimaneutralität bis 2050 für eine nachhaltige, gerechte und wohlhabende Gesellschaft, Teil 3, S. 164-167.

^(12) Analyse der JRC, siehe Folgenabschätzungsbericht.

^(13) Bericht über die Fortschritte bei der Wettbewerbsfähigkeit im Bereich der Technologien für saubere Energie (COM(2025) 74 final vom 26. Februar 2025).

^(14) BloombergNEF, New Energy Outlook.

^(15) European automotive industry: What it takes to regain competitiveness , McKinsey, 10. März 2025.

^(16) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Änderung der Verordnung (EU) 2019/631 in Bezug auf CO2-Emissionsnormen für neue leichte Nutzfahrzeuge und die Fahrzeugkennzeichnung sowie zur Aufhebung der Richtlinie 1999/94/EG.

^(17) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates über saubere Unternehmensfahrzeuge

^(18) Ausführliche Informationen sind über das Instrument „ Procurement for Buyers “ der Europäischen Kommission auf dem Portal Access2Markets verfügbar und helfen den Auftraggebern in der EU dabei, auf der Grundlage der Bestimmungen des WTO-Übereinkommens über das öffentliche Beschaffungswesen (GPA) und bilateraler EU-Handelsabkommen herauszufinden, welche Bieter für die Teilnahme an Verfahren zur Vergabe öffentlicher Aufträge in den EU-Mitgliedstaaten infrage kommen.

^(19) Für die Leitmarktmaßnahmen im Zusammenhang mit Zement werden die Anforderungen auf der Ebene von Beton und Mörtel festgelegt, da es sich dabei um die im Baugewerbe verwendeten relevanten Endprodukte handelt.

^(20) […]

^(21) […]

^(22) https://www.consilium.europa.eu/de/policies/european-economic-security/.

^(23) Gemeinsame Mitteilung an das Europäische Parlament, den Europäischen Rat und den Rat über eine „Europäische Strategie für wirtschaftliche Sicherheit“ (JOIN(2023) 20 final).

^(24) Gemeinsame Mitteilung an das Europäische Parlament und den Rat „Stärkung der wirtschaftlichen Sicherheit der EU“ (JOIN(2025) 977 final).

^(25) Mit Ausnahme des NACE-Codes C12, E-Liquids zur Verwendung in Verdampfungsgeräten und nikotinhaltigen Erzeugnissen unter C20.59 und Herstellung von elektronischen Zigaretten und Tabakerhitzern unter C32.99 (es sei denn, sie sind als Arzneimittel zugelassen oder als Medizinprodukte zertifiziert).

^(26) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen, „Ein strategischer Rahmen für eine wettbewerbsfähige und nachhaltige Bioökonomie in der EU “ (COM(2025) 960).

^(27) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates über die Einrichtung europäischer Unternehmensbrieftaschen (COM(2025) 838 final).

^(28) Verordnung (EU) 2024/1735 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Ökosystems der Fertigung von Netto-Null-Technologien und zur Änderung der Verordnung (EU) 2018/1724 (ABl. L, 2024/1735, 28.6.2024, ELI: http://data.europa.eu/eli/reg/2024/1735/oj).

^(29) Verordnung (EU) 2024/1252 des Europäischen Parlament und des Rates vom 11. April 2024 zur Schaffung eines Rahmens zur Gewährleistung einer sicheren und nachhaltigen Versorgung mit kritischen Rohstoffen und zur Änderung der Verordnungen (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1724 und (EU) 2019/1020 (ABl. L, 2024/1252, 3.5.2024, ELI: http://data.europa.eu/eli/reg/2024/1252/oj).

^(30) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates über die Beschleunigung von Umweltprüfungen (COM(2025) 984 final vom 10.12.2025).

^(31) Welthandelsorganisation (WTO), Übereinkommen über das öffentliche Beschaffungswesen 2012, abrufbar unter https://www.wto.org/english/docs_e/legal_e/rev-gpr-94_01_e.pdf .

^(32) Verordnung (EU) 2024/3110 des Europäischen Parlaments und des Rates vom 27. November 2024 zur Festlegung harmonisierter Vorschriften für die Vermarktung von Bauprodukten und zur Aufhebung der Verordnung (EU) Nr. 305/2011 (ABl. L, 2024/3110, 18.12.2024, ELI: http://data.europa.eu/eli/reg/2024/3110/oj ).

^(33) Verordnung (EU) 2024/1781 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Schaffung eines Rahmens für die Festlegung von Ökodesign-Anforderungen für nachhaltige Produkte, zur Änderung der Richtlinie (EU) 2020/1828 und der Verordnung (EU) 2023/1542 und zur Aufhebung der Richtlinie 2009/125/EG (ABl. L, 2024/1781, 28.6.2024, ELI: http://data.europa.eu/eli/reg/2024/1781/oj ).

^(34) Mitteilung der Kommission an das Europäische Parlament, den Europäischen Rat, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Ein Industrieplan zum Grünen Deal für das klimaneutrale Zeitalter (COM(2023) 62 final vom 1.2.2023).

^(35) Delegierte Verordnung (EU) 2019/331 der Kommission vom 19. Dezember 2018 zur Festlegung EU-weiter Übergangsvorschriften zur Harmonisierung der kostenlosen Zuteilung von Emissionszertifikaten gemäß Artikel 10a der Richtlinie 2003/87/EG des Europäischen Parlaments und des Rates (ABl. L 59 vom 27.2.2019, S. 8, ELI: http://data.europa.eu/eli/reg_del/2019/331/oj ).

^(36) Durchführungsverordnung (EU) 2018/2066 der Kommission vom 19. Dezember 2018 über die Überwachung von und die Berichterstattung über Treibhausgasemissionen gemäß der Richtlinie 2003/87/EG des Europäischen Parlaments und des Rates und zur Änderung der Verordnung (EU) Nr. 601/2012 der Kommission (ABl. L 334 vom 31.12.2018, S. 1, ELI: http://data.europa.eu/eli/reg_impl/2018/2066/oj ).

^(37) Verordnung (EU) 2023/956 des Europäischen Parlaments und des Rates vom 10. Mai 2023 zur Schaffung eines CO2-Grenzausgleichssystems (ABl. L 130 vom 16.5.2023, S. 52, ELI: http://data.europa.eu/eli/reg/2023/956/oj ).

^(38) Richtlinie 2003/87/EG des Europäischen Parlaments und des Rates vom 13. Oktober 2003 über ein System für den Handel mit Treibhausgasemissionszertifikaten in der Gemeinschaft und zur Änderung der Richtlinie 96/61/EG des Rates (ABl. L 275 vom 25.10.2003, S. 32, ELI: http://data.europa.eu/eli/dir/2003/87/oj ).

^(39) Richtlinie 2014/23/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die Konzessionsvergabe (ABl. L 94 vom 28.3.2014, S. 1, ELI: http://data.europa.eu/eli/dir/2014/23/oj ).

^(40) Richtlinie 2014/24/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die öffentliche Auftragsvergabe und zur Aufhebung der Richtlinie 2004/18/EG (ABl. L 94 vom 28.3.2014, S. 65, ELI: http://data.europa.eu/eli/dir/2014/24/oj ).

^(41) Richtlinie 2014/25/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die Vergabe von Aufträgen durch Auftraggeber im Bereich der Wasser-, Energie- und Verkehrsversorgung sowie der Postdienste und zur Aufhebung der Richtlinie 2004/17/EG (ABl. L 94 vom 28.3.2014, S. 243).

^(42) Verordnung (EU) 2019/631 des Europäischen Parlaments und des Rates vom 17. April 2019 zur Festsetzung von CO2-Emissionsnormen für neue Personenkraftwagen und für neue leichte Nutzfahrzeuge und zur Aufhebung der Verordnungen (EG) Nr. 443/2009 und (EU) Nr. 510/2011 (ABl. L 111 vom 25.4.2019, S. 13, ELI: http://data.europa.eu/eli/reg/2019/631/oj).

^(43) Verordnung (EU) 2018/858 des Europäischen Parlaments und des Rates vom 30. Mai 2018 über die Genehmigung und die Marktüberwachung von Kraftfahrzeugen und Kraftfahrzeuganhängern sowie von Systemen, Bauteilen und selbstständigen technischen Einheiten für diese Fahrzeuge, zur Änderung der Verordnungen (EG) Nr. 715/2007 und (EG) Nr. 595/2009 und zur Aufhebung der Richtlinie 2007/46/EG (ABl. L 151 vom 14.6.2018, S. 1, ELI: http://data.europa.eu/eli/reg/2018/858/oj).

^(44) Verordnung (EU) 2019/452 des Europäischen Parlaments und des Rates vom 19. März 2019 zur Schaffung eines Rahmens für die Überprüfung ausländischer Direktinvestitionen in der Union (ABl. L 79I vom 21.3.2019, S. 1, ELI: http://data.europa.eu/eli/reg/2019/452/oj ).

^(45) Verordnung (EU) 2022/2560 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über den Binnenmarkt verzerrende drittstaatliche Subventionen (ABl. L 330 vom 23.12.2022, S. 1, ELI: http://data.europa.eu/eli/reg/2022/2560/oj).

^(46) Verordnung (EG) Nr. 139/2004 des Rates vom 20. Januar 2004 über die Kontrolle von Unternehmenszusammenschlüssen (ABl. L 24 vom 29.1.2004, S. 1, ELI: http://data.europa.eu/eli/reg/2004/139/oj).

^(47) Proposal for a Regulation of the European Parliament and of the Council on establishing the European Competitiveness Fund ('ECF’), including the specific programme for defence research and innovation activities, repealing Regulations (EU) 2021/522, (EU) 2021/694, (EU) 2021/697, (EU) 2021/783, repealing provisions of Regulations (EU) 2021/696, (EU) 2023/588, and amending Regulation (EU) [EDIP] (COM/2025/555 final vom 16.7.2025).

^(48) Richtlinie 2010/75/EU des Europäischen Parlaments und des Rates vom 24. November 2010 über Industrieemissionen (integrierte Vermeidung und Verminderung der Umweltverschmutzung) (ABl. L 334 vom 17.12.2010, S. 17, ELI: http://data.europa.eu/eli/dir/2010/75/oj).

^(49) ABl. L 123 vom 12.5.2016, S. 1, http://data.europa.eu/eli/agree_interinstit/2016/512/oj.

^(50) Verordnung (EU) Nr. 182/2011 des Europäischen Parlaments und des Rates vom 16. Februar 2011 zur Festlegung der allgemeinen Regeln und Grundsätze, nach denen die Mitgliedstaaten die Wahrnehmung der Durchführungsbefugnisse durch die Kommission kontrollieren (ABl. L 55 vom 28.2.2011, S. 13, ELI: http://data.europa.eu/eli/reg/2011/182/oj ).

^(51) Verordnung (EU) 2018/1724 des Europäischen Parlaments und des Rates vom 2. Oktober 2018 über die Einrichtung eines einheitlichen digitalen Zugangstors zu Informationen, Verfahren, Hilfs- und Problemlösungsdiensten und zur Änderung der Verordnung (EU) Nr. 1024/2012 (ABl. L 295 vom 21.11.2018, S. 1, ELI: http://data.europa.eu/eli/reg/2018/1724/oj ).

^(52) Richtlinie 2003/96/EG des Rates vom 27. Oktober 2003 zur Restrukturierung der gemeinschaftlichen Rahmenvorschriften zur Besteuerung von Energieerzeugnissen und elektrischem Strom (ABl. L 283 vom 31.10.2003, S. 51, ELI: http://data.europa.eu/eli/dir/2003/96/oj ).

^(53) Vorschlag für eine Richtlinie des Europäischen Parlaments und des Rates zur Änderung der Richtlinien (EU) 2018/2001, (EU) 2019/944 und (EU) 2024/1788 im Hinblick auf die Beschleunigung der Genehmigungsverfahren (2025/0400 (COD)).

^(54) Richtlinie 2014/24/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die öffentliche Auftragsvergabe und zur Aufhebung der Richtlinie 2004/18/EG (ABl. L 94 vom 28.3.2014, S. 65, ELI: http://data.europa.eu/eli/dir/2014/24/oj ).

^(55) Richtlinie 2014/25/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die Vergabe von Aufträgen durch Auftraggeber im Bereich der Wasser-, Energie- und Verkehrsversorgung sowie der Postdienste und zur Aufhebung der Richtlinie 2004/17/EG (ABl. L 94 vom 28.3.2014, S. 243, ELI: http://data.europa.eu/eli/dir/2014/25/oj ).

^(56) Verordnung (EU) 2018/858 des Europäischen Parlaments und des Rates vom 30. Mai 2018 über die Genehmigung und die Marktüberwachung von Kraftfahrzeugen und Kraftfahrzeuganhängern sowie von Systemen, Bauteilen und selbstständigen technischen Einheiten für diese Fahrzeuge, zur Änderung der Verordnungen (EG) Nr. 715/2007 und (EG) Nr. 595/2009 und zur Aufhebung der Richtlinie 2007/46/EG (ABl. L 151 vom 14.6.2018, S. 1, ELI: http://data.europa.eu/eli/reg/2018/858/oj).

^(57) Durchführungsverordnung (EU) 2025/1178 der Kommission vom 23. Mai 2025 zur Festlegung von Vorschriften für die Anwendung der Verordnung (EU) 2024/1735 des Europäischen Parlaments und des Rates hinsichtlich der Liste der Endprodukte mit Netto-Null-Technologien und ihrer wichtigsten spezifischen Bauteile für die Zwecke der Bewertung des Beitrags zur Resilienz (ABl. L, 2025/1178, 18.6.2025, ELI: http://data.europa.eu/eli/reg_impl/2025/1178/oj).

^(58) Verordnung (EG) Nr. 139/2004 des Rates vom 20. Januar 2004 über die Kontrolle von Unternehmenszusammenschlüssen ( ABl. L 24 vom 29.1.2004, S. 1 ).

^(59) Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates vom 12. Juli 2023 über Batterien und Altbatterien, zur Änderung der Richtlinie 2008/98/EG und der Verordnung (EU) 2019/1020 und zur Aufhebung der Richtlinie 2006/66/EG (ABl. L 191 vom 28.7.2023, S. 1, ELI: http://data.europa.eu/eli/reg/2023/1542/oj).

^(60) Durchführungsverordnung (EU) 2018/2067 der Kommission vom 19. Dezember 2018 über die Prüfung von Daten und die Akkreditierung von Prüfstellen gemäß der Richtlinie 2003/87/EG des Europäischen Parlaments und des Rates (ABl. L 334 vom 31.12.2018, S. 94, ELI: http://data.europa.eu/eli/reg_impl/2018/2067/oj ).

^(61) Verordnung (EU) 2021/1119 des Europäischen Parlaments und des Rates vom 30. Juni 2021 zur Schaffung des Rahmens für die Verwirklichung der Klimaneutralität und zur Änderung der Verordnungen (EG) Nr. 401/2009 und (EU) 2018/1999 („Europäisches Klimagesetz“) (ABl. L 243 vom 9.7.2021, S. 1, ELI: http://data.europa.eu/eli/reg/2021/1119/oj).

^(62) Richtlinie 2001/42/EG des Europäischen Parlaments und des Rates vom 27. Juni 2001 über die Prüfung der Umweltauswirkungen bestimmter Pläne und Programme (ABl. L 197 vom 21.7.2001, S. 30, ELI: http://data.europa.eu/eli/dir/2001/42/oj).

^(63) Richtlinie 92/43/EWG des Rates vom 21. Mai 1992 zur Erhaltung der natürlichen Lebensräume sowie der wildlebenden Tiere und Pflanzen (ABl. L 206 vom 22.7.1992, S. 7, ELI: http://data.europa.eu/eli/dir/1992/43/oj).

^(64) Richtlinie 2000/60/EG des Europäischen Parlaments und des Rates vom 23. Oktober 2000 zur Schaffung eines Ordnungsrahmens für Maßnahmen der Gemeinschaft im Bereich der Wasserpolitik (ABl. L 327 vom 22.12.2000, S. 1, ELI: http://data.europa.eu/eli/dir/2000/60/oj).

^(65) Richtlinie (EU) 2019/944 des Europäischen Parlaments und des Rates vom 5. Juni 2019 mit gemeinsamen Vorschriften für den Elektrizitätsbinnenmarkt und zur Änderung der Richtlinie 2012/27/EU (ABl. L 158 vom 14.6.2019, S. 125, ELI: http://data.europa.eu/eli/dir/2019/944/oj).

^(66) Mitteilung der Kommission an das Europäische Parlament, den Europäischen Rat, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Eine neue Industriestrategie für Europa (COM(2020) 102 final).

^(67) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Europäische Kompetenzagenda für nachhaltige Wettbewerbsfähigkeit, soziale Gerechtigkeit und Resilienz (COM(2020) 274 final).

^(68) Im Sinne des Artikels 58 Absatz 2 Buchstabe a oder b der Haushaltsordnung.

^(69) GM = Getrennte Mittel/NGM = Nichtgetrennte Mittel.

^(70) EFTA: Europäische Freihandelsassoziation.

^(71) Kandidatenländer und gegebenenfalls potenzielle Kandidaten des Westbalkans.

^(72) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(73) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(74) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(75) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(76) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(77) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(78) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(79) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(80) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(81) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(82) Outputs sind Produkte, die geliefert, und Dienstleistungen, die erbracht werden (z. B. Zahl der Austauschstudenten, gebaute Straßenkilometer usw.).

^(83) Wie in Abschnitt 1.3.2 „Einzelziel(e)“

^(84) Bei den Zahlen in den vorstehenden Tabellen handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

^(85) Bei den traditionellen Eigenmitteln (Zölle, Zuckerabgaben) sind die Beträge netto, d. h. abzüglich 20 % für Erhebungskosten, anzugeben.

<a id="annex-i"></a>
## Anhang I – Strategische Sektoren für Beschleunigungsgebiete für die industrielle Fertigung

1. Energieintensive Industrien;

  - a) Herstellung von Papier, Pappe und Waren, wie unter NACE-Code C17 klassifiziert;

  - b) Kokerei und Mineralölverarbeitung, wie unter NACE-Code C19 klassifiziert;

  - c) Herstellung von chemischen Erzeugnissen, wie unter NACE-Code C20 klassifiziert;

  - d) Herstellung von Gummi- und Kunststoffwaren, wie unter NACE-Code C22 klassifiziert;

  - e) Herstellung von Glas und Glaswaren, Keramik, Verarbeitung von Steinen und Erden, wie unter NACE-Code C23 klassifiziert;

  - f) Metallerzeugung und -bearbeitung, wie unter NACE-Code C24 klassifiziert.

2. Automobilindustrie Herstellung von Kraftwagen und Kraftwagenteilen, wie unter NACE-Code C29 klassifiziert;

3. Netto-Null-Technologien gemäß Artikel 4 Absatz 1 der Verordnung (EU) 2024/1735;

<a id="annex-ii"></a>
## Anhang II – Anforderungen in Bezug auf den CO2-Ausstoß und den Ursprung in der Union an energieintensive Industrien

####  Teil I – Verfahren zur Vergabe öffentlicher Aufträge

Im Rahmen von öffentlichen Vergabeverfahren, die am oder nach dem 1. Januar 2029 eingeleitet werden und in den Anwendungsbereich der Richtlinien 2014/23/EU, 2014/24/EU oder 2014/25/EU fallen, müssen die öffentlichen Auftraggeber, sofern die Aufträge, Bauaufträge oder Baukonzessionen die Beschaffung von Produkten aus energieintensiven Industrien umfassen, folgende Mindestanteile vorschreiben:

  - a) Bei Stahl und Erzeugnissen, deren Leistung hauptsächlich von Stahl abhängt und die zur Verwendung in Gebäuden, Infrastruktureinrichtungen und Kraftfahrzeugen für zivile Zwecke bestimmt sind, müssen mindestens 25 % der Gesamtmenge des verwendeten Stahls CO2-arm sein;

  - b) bei Beton und Mörtel sowie Produkten, deren Leistung hauptsächlich von Beton und Mörtel abhängt und die zur Verwendung in Gebäuden und Infrastruktureinrichtungen für zivile Zwecke bestimmt sind, müssen mindestens 5 % der Gesamtmenge des verwendeten Betons und Mörtels, einschließlich der zu ihrer Herstellung verwendeten Klinker und des Zements, CO2-arm sein und ihren Ursprung in der Union haben;

  - c) bei Aluminium und Produkten, deren Leistung hauptsächlich von Aluminium abhängt und die zur Verwendung in Gebäuden, Infrastruktureinrichtungen und Kraftfahrzeugen für zivile Zwecke bestimmt sind, müssen mindestens 25 % der Gesamtmenge des verwendeten Aluminiums CO2-arm sein und ihren Ursprung in der Union haben.

####  Teil II – Andere Formen der öffentlichen Intervention

Bei Regelungen, die am oder nach dem 1. Januar 2029 eingeführt oder aktualisiert werden, die Privathaushalten oder Unternehmen zugutekommen und die in erster Linie darauf abzielen, den Bau oder die Renovierung von Gebäuden für Wohn- und Geschäftszwecke und von Infrastruktur sowie das Leasing und den Kauf von Kraftfahrzeugen für zivile Zwecke zu fördern, stellen die Mitgliedstaaten, regionalen oder lokalen Behörden, öffentlich-rechtlichen Körperschaften oder Verbände, die aus einer oder mehreren solcher Behörden oder einer oder mehreren solcher öffentlich-rechtlichen Körperschaften bestehen, sicher, dass nur Begünstigte förderfähig sind, die die folgenden Mindestanforderungen erfüllen.

  - a) Bei Stahl und Erzeugnissen, deren Leistung in erster Linie von Stahl abhängt, müssen mindestens 25 % der Gesamtmenge des Stahls, der in dem geförderten Produkt oder Projekt verwendet wird, CO2-arm sein;

  - b) bei Beton und Mörtel sowie Produkten, deren Leistung in erster Linie von Beton und Mörtel abhängt, müssen mindestens 5 % der Gesamtmenge des in dem geförderten Produkt oder Projekt verwendeten Betons und Mörtels, einschließlich der zu ihrer Herstellung verwendeten Klinker und des Zements, CO2-arm sein und ihren Ursprung in der Union haben;

  - c) bei Aluminium und Produkten, deren Leistung in erster Linie von Aluminium abhängt, müssen mindestens 25 % der Gesamtmenge des in dem geförderten Produkt oder Projekt verwendeten Aluminiums CO2-arm sein und ihren Ursprung in der Union haben.

<a id="annex-iii"></a>
## Anhang III – Anforderungen an den Ursprung von Fahrzeugen in der Union

####  Teil I – Verfahren zur Vergabe öffentlicher Aufträge für Elektrofahrzeuge

Neue reine Elektrofahrzeuge (PEV), extern aufladbare Hybridelektrofahrzeuge (OVC-HEV) oder Brennstoffzellenfahrzeuge (FCV), die im Rahmen von Kauf-, Leasing-, Miet- oder Mietkaufverträgen in Verfahren zur Vergabe öffentlicher Aufträge, die in den Anwendungsbereich der Richtlinie 2014/24/EU oder der Richtlinie 2014/25/EU fallen, erworben werden und am oder nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach Inkrafttreten dieser Verordnung] in Betrieb genommen werden, müssen die in diesem Anhang festgelegten Anforderungen an den Ursprung in der Union erfüllen.

Neue PEV, OVC-HEV und FCV, die für die Erbringung von Dienstleistungen verwendet werden, deren Aufträge im Rahmen von in den Anwendungsbereich der Richtlinie 2014/24/EU oder der Richtlinie 2014/25/EU fallenden Verfahren zur Vergabe öffentlicher Aufträge vergeben wurden, müssen die in diesem Anhang festgelegten Anforderungen an den Ursprung in der Union erfüllen.

Die in den Unterabsätzen 1 und 2 genannten Fahrzeuge müssen die folgenden Anforderungen an den Ursprung in der Union erfüllen:

  - a) Das Fahrzeug ist innerhalb der Union montiert worden;

  - b) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Fahrzeugbauteile – ohne die Fahrzeugbatterie – mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Bauteile – ohne die Batterie – beträgt mindestens 70 %;

  - c) die Antriebsbatterie des Fahrzeugs enthält mindestens drei wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, mit Ursprung in der Union;

  - d) die Antriebsbatterie des Fahrzeugs enthält mindestens fünf wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, das aktive Kathodenmaterial und das Batteriemanagementsystem, mit Ursprung in der Union;

  - e) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Bauteile des elektrischen Antriebsstrangs mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Bauteile des elektrischen Antriebsstrangs beträgt mindestens 50 %;

  - f) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der wichtigsten elektronischen Systeme mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller wichtigsten elektronischen Systeme beträgt mindestens 50 %.

Die Anforderungen gemäß den Buchstaben d, e und f gelten ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung].

Abweichend von den vorstehend genannten Anforderungen müssen kleine Elektrofahrzeuge der Unterklasse M1E im Sinne der Verordnung (EU) 2018/858 die folgenden Anforderungen an den Ursprung in der Union erfüllen:

1. Das Fahrzeug ist innerhalb der Union montiert worden;

2. ferner muss eines der beiden folgenden Kriterien erfüllt sein:

  - a) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Fahrzeugbauteile – ohne die Fahrzeugbatterie – mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Fahrzeugbauteile – ohne die Batterie – beträgt 70 % oder mehr oder

  - b) die Antriebsbatterie des Fahrzeugs enthält mindestens drei wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, mit Ursprung in der Union.

Auf Antrag eines Fahrzeugherstellers können alle PEV, OVC-HEV oder FCV dieses Fahrzeugherstellers für einen Zeitraum von zwölf Monaten als mit den Anforderungen an den Ursprung in der Union konform angesehen werden, wenn der Hersteller nachweist, dass die Gesamtzahl aller PEV-, OVC-HEC- oder FCV-Fahrzeuge, die den Anforderungen an den Ursprung in der Union entsprechen und von diesem Fahrzeughersteller in dem Zeitraum zwischen dem 1. Januar und dem 31. Dezember des Vorjahres (einschließlich) montiert wurden, mindestens 85 % der Gesamtzahl der PEV, OVC-HEV oder FCV desselben Fahrzeugherstellers entspricht, die in demselben Zeitraum in der Union zugelassen wurden.

Betreffen die Verfahren zur Vergabe öffentlicher Aufträge Dienstleistungsaufträge gemäß Unterabsatz 2, so wird davon ausgegangen, dass Fahrzeuge, die bereits in der Union zugelassen sind, die Anforderungen dieses Anhangs bis zum 31. Dezember 2035 erfüllen.

####  Teil II – Andere Formen der öffentlichen Intervention und der finanziellen Unterstützung für Unternehmensfahrzeuge

Bei Regelungen, die nach dem [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach Inkrafttreten dieser Verordnung] eingeführt oder aktualisiert wurden und den Kauf, das Leasing, die Anmietung oder den Mietkauf neuer PEV, OVC-HEV oder FCV fördern, stellen die Mitgliedstaaten, regionalen oder lokalen Behörden, öffentlich-rechtlichen Körperschaften oder Verbände, die aus einer oder mehreren solcher Behörden oder einer oder mehreren solcher öffentlich-rechtlichen Körperschaften bestehen, sicher, dass im Rahmen der Regelung nur Fahrzeuge förderfähig sind, die die folgenden Mindestanforderungen an den Ursprung in der Union erfüllen.

Für die Zwecke der Berücksichtigung von in der Europäischen Union hergestellten Unternehmensfahrzeugen und leichten Nutzfahrzeugen gemäß Artikel 4 des [Vorschlags vom 16. Dezember 2025 für eine Verordnung über saubere Unternehmensfahrzeuge] gelten die folgenden Anforderungen.

  - a) Das Fahrzeug ist innerhalb der Union montiert worden;

  - b) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Fahrzeugbauteile – ohne die Fahrzeugbatterie – mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Fahrzeugbauteile – ohne die Batterie – beträgt 70 % oder mehr;

  - c) die Antriebsbatterie des Fahrzeugs enthält mindestens drei wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, mit Ursprung in der Union;

  - d) die Antriebsbatterie des Fahrzeugs enthält mindestens fünf wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, das aktive Kathodenmaterial und das Batteriemanagementsystem, mit Ursprung in der Union;

  - e) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Bauteile des elektrischen Antriebsstrangs mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Bauteile des elektrischen Antriebsstrangs beträgt mindestens 50 %;

  - f) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der wichtigsten elektronischen Systeme mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller wichtigsten elektronischen Systeme beträgt mindestens 50 %.

Die Anforderungen gemäß den Buchstaben d, e und f gelten ab dem [Amt für Veröffentlichungen: bitte Datum einfügen = drei Jahre nach Inkrafttreten dieser Verordnung].

Abweichend von den vorstehend genannten Anforderungen müssen kleine Elektrofahrzeuge der Unterklasse M1E im Sinne der Verordnung (EU) 2018/858 die folgenden Anforderungen an den Ursprung in der Union erfüllen:

1. Das Fahrzeug ist innerhalb der Union montiert worden;

2. ferner muss eines der beiden folgenden Kriterien erfüllt sein:

  - a) Das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Fahrzeugbauteile – ohne die Fahrzeugbatterie – mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Fahrzeugbauteile – ohne die Batterie – beträgt 70 % oder mehr oder

  - b) die Antriebsbatterie des Fahrzeugs enthält mindestens drei wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, mit Ursprung in der Union.

Auf Antrag eines Fahrzeugherstellers können alle PEV, OVC-HEV oder FCV dieses Fahrzeugherstellers für einen Zeitraum von zwölf Monaten als konform mit den Anforderungen an den Ursprung in der Union angesehen werden, wenn der Hersteller nachweist, dass alle PEV, OVC-HEV oder FCV, die den Anforderungen an den Ursprung in der Union entsprechen und von diesem Fahrzeughersteller in dem Zeitraum zwischen dem 1. Januar und dem 31. Dezember (einschließlich) des Vorjahres montiert wurden, mindestens 85 % der Gesamtzahl der PEV, OVC-HEV oder FCV desselben Fahrzeugherstellers ausmachen, die in demselben Zeitraum in der Union zugelassen wurden.

####  Teil III – Begünstigungen für kleine emissionsfreie Fahrzeuge

Für die Zwecke der Einstufung von Fahrzeugen als „in der EU hergestellt“ gemäß Artikel 5 der Verordnung (EU) 2019/631 [in der durch den Vorschlag vom 16. Dezember 2025 für eine Verordnung zur Änderung der Verordnung (EU) 2019/631 in Bezug auf CO2-Emissionsnormen für neue leichte Nutzfahrzeuge und die Kennzeichnung von Fahrzeugen geänderten Fassung] gelten die folgenden Kriterien:

1. Das Fahrzeug ist innerhalb der Union montiert worden;

2. ferner muss eines der beiden folgenden Kriterien erfüllt sein:

  - a) das Verhältnis zwischen dem Ab-Werk-Gesamtpreis der Fahrzeugbauteile – ohne die Fahrzeugbatterie – mit Ursprung in der Union und dem Ab-Werk-Gesamtpreis aller Fahrzeugbauteile – ohne die Batterie – beträgt 70 % oder mehr oder

  - b) die Antriebsbatterie des Fahrzeugs enthält mindestens drei wichtigste spezifische Batteriebauteile, darunter die Batteriezellen, mit Ursprung in der Union.

<a id="annex-iv"></a>
## Anhang IV – Änderung der Verordnung (EU) 2018/1724

Die Anhänge I und II werden wie folgt geändert:

1. Anhang I wird wie folgt geändert:

  - a) In der Tabelle „Informationsbereiche im Zusammenhang mit Unternehmen“ wird die folgende Zeile „Genehmigungsverfahren“ vor der Zeile „AJ. Projekte im Bereich kritische Rohstoffe“ eingefügt:

| „Genehmigungsverfahren | Informationen über Genehmigungsverfahren für industrielle Fertigungsprojekte, einschließlich Projekten zur Fertigung von Netto-Null-Technologien und Projekten im Bereich kritische Rohstoffe“; |
| --- | --- |

  - b) in der Zeile „R. Projekte zur Fertigung von Netto-Null-Technologien“ wird Nummer 1 in der zweiten Spalte gestrichen;

  - c) in Zeile „AJ. Projekte im Bereich kritische Rohstoffe“ wird Nummer 2 in der zweiten Spalte gestrichen;

2. Anhang II wird wie folgt geändert:

  - a) die Zeile „Gründung, Führung und Schließung eines Unternehmens“ wird wie folgt geändert:

    - a) In der zweiten Spalte wird folgender Unterabsatz 2 angefügt:

        „Genehmigung zur Ausübung einer Geschäftstätigkeit, einschließlich Verfahren im Zusammenhang mit allen einschlägigen Genehmigungen für den Bau und den Betrieb von Projekten im Bereich kritische Rohstoffe^(1), Verfahren für alle einschlägigen Genehmigungen für den Bau, den Ausbau, die Umwandlung und den Betrieb von Projekten zur Fertigung von Netto-Null-Technologien^(2) und Verfahren im Zusammenhang mit industriellen Fertigungsprojekten“;

    - b) in der dritten Spalte wird folgender Unterabsatz 2 angefügt:

        „Bestätigung des Antrags auf Genehmigung einer Geschäftstätigkeit sowie aller Ergebnisse im Zusammenhang mit Verfahren betreffend Projekte im Bereich kritische Rohstoffe, Projekte zur Fertigung von Netto-Null-Technologien und industrielle Fertigungsprojekte (von der Bestätigung der Vollständigkeit des Antrags bis zur Mitteilung der umfassenden Entscheidung über das Ergebnis des Verfahrens, auch durch die benannte Kontaktstelle)“;

  - b) die Zeilen „Projekte im Bereich kritische Rohstoffe“ und „Projekte zur Fertigung von Netto-Null-Technologien“ werden gestrichen.

^(1) Verfahren, das alle einschlägigen Genehmigungen für den Bau und den Betrieb von Projekten im Bereich kritische Rohstoffe umfasst, einschließlich Baugenehmigungen, chemikalienbezogene Genehmigungen und Netzanschlussgenehmigungen sowie Umweltverträglichkeitsprüfungen und -genehmigungen, sofern diese erforderlich sind, und das alle Anträge und Verfahren von der Bestätigung der Vollständigkeit des Antrags bis zur Mitteilung der umfassenden Entscheidung über das Ergebnis des Verfahrens durch die gemäß Artikel 9 der Verordnung (EU) 2024/1252 eingerichtete zuständige zentrale Anlaufstelle umfasst.

^(2) Verfahren für alle einschlägigen Genehmigungen für den Bau, den Ausbau, die Umwandlung und den Betrieb von Projekten zur Fertigung von Netto-Null-Technologien und strategischen Projekten für Netto-Null-Technologien, einschließlich Baugenehmigungen, chemikalienbezogene Genehmigungen und Netzanschlussgenehmigungen sowie Umweltprüfungen und -genehmigungen sofern erforderlich, die alle administrativen Anträge und Verfahren umfassen.
