---
act: machinery-directive
version: 2026-05-30_consolidated
stage: consolidated
language: en
celex: 02006L0042-20260530
title: DIRECTIVE 2006/42/EC OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 17 May 2006 on machinery, and amending Directive 95/16/EC (recast)
retrieved: '2026-11-15'
converter: tools/eurlex2md.py
counts:
  recitals: 0
  articles: 34
  annexes: 12
official_source: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:02006L0042-20260530
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# DIRECTIVE 2006/42/EC OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 17 May 2006 on machinery, and amending Directive 95/16/EC (recast)

02006L0042 — EN — 30.05.2026 — 006.001

This text is meant purely as a documentation tool and has no legal effect. The Union's institutions do not assume any liability for its contents. The authentic versions of the relevant acts, including their preambles, are those published in the Official Journal of the European Union and available in EUR-Lex. Those official texts are directly accessible through the links embedded in this document

Amended by:

- ►M1 REGULATION (EC) No 596/2009 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 18 June 2009 (OJ L 188, p. 14, 18.7.2009)

- ►M2 DIRECTIVE 2009/127/EC OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 21 October 2009 (OJ L 310, p. 29, 25.11.2009)

- ►M3 REGULATION (EU) No 167/2013 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 5 February 2013 (OJ L 60, p. 1, 2.3.2013)

- ►M4 DIRECTIVE 2014/33/EU OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 26 February 2014 (OJ L 96, p. 251, 29.3.2014)

- ►M5 REGULATION (EU) 2019/1243 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 20 June 2019 (OJ L 198, p. 241, 25.7.2019)

- ►M6 DIRECTIVE (EU) 2024/2749 OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL of 9 October 2024 (OJ L 2749, p. 1, 8.11.2024)

Corrected by:

▼B

<a id="art-1"></a>
### Article 1 – Scope

1. This Directive applies to the following products:

- (a) machinery;

- (b) interchangeable equipment;

- (c) safety components;

- (d) lifting accessories;

- (e) chains, ropes and webbing;

- (f) removable mechanical transmission devices;

- (g) partly completed machinery.

2. The following are excluded from the scope of this Directive:

- (a) safety components intended to be used as spare parts to replace identical components and supplied by the manufacturer of the original machinery;

- (b) specific equipment for use in fairgrounds and/or amusement parks;

- (c) machinery specially designed or put into service for nuclear purposes which, in the event of failure, may result in an emission of radioactivity;

- (d) weapons, including firearms;

- (e) the following means of transport:

  ▼M3

  - — agricultural and forestry tractors, with the exclusion of machinery mounted on those vehicles,

  ▼B

  - — motor vehicles and their trailers covered by Council Directive 70/156/EEC of 6 February 1970 on the approximation of the laws of the Member States relating to the type-approval of motor vehicles and their trailers ^(1), with the exclusion of machinery mounted on these vehicles,

  - — vehicles covered by Directive 2002/24/EC of the European Parliament and of the Council of 18 March 2002 relating to the type-approval of two or three-wheel motor vehicles ^(2), with the exclusion of machinery mounted on these vehicles,

  - — motor vehicles exclusively intended for competition, and

  - — means of transport by air, on water and on rail networks with the exclusion of machinery mounted on these means of transport;

- (f) seagoing vessels and mobile offshore units and machinery installed on board such vessels and/or units;

- (g) machinery specially designed and constructed for military or police purposes;

- (h) machinery specially designed and constructed for research purposes for temporary use in laboratories;

- (i) mine winding gear;

- (j) machinery intended to move performers during artistic performances;

- (k) electrical and electronic products falling within the following areas, insofar as they are covered by Council Directive 73/23/EEC of 19 February 1973 on the harmonisation of the laws of Member States relating to electrical equipment designed for use within certain voltage limits ^(3):

  - — household appliances intended for domestic use,

  - — audio and video equipment,

  - — information technology equipment,

  - — ordinary office machinery,

  - — low-voltage switchgear and control gear,

  - — electric motors;

- (l) the following types of high-voltage electrical equipment:

  - — switch gear and control gear,

  - — transformers.

<a id="art-2"></a>
### Article 2 – Definitions

For the purposes of this Directive, ‘machinery’ designates the products listed in Article 1(1)(a) to (f).

The following definitions shall apply:

- (a) ‘machinery’ means:

  - — an assembly, fitted with or intended to be fitted with a drive system other than directly applied human or animal effort, consisting of linked parts or components, at least one of which moves, and which are joined together for a specific application,

  - — an assembly referred to in the first indent, missing only the components to connect it on site or to sources of energy and motion,

  - — an assembly referred to in the first and second indents, ready to be installed and able to function as it stands only if mounted on a means of transport, or installed in a building or a structure,

  - — assemblies of machinery referred to in the first, second and third indents or partly completed machinery referred to in point (g) which, in order to achieve the same end, are arranged and controlled so that they function as an integral whole,

  - — an assembly of linked parts or components, at least one of which moves and which are joined together, intended for lifting loads and whose only power source is directly applied human effort;

- (b) ‘interchangeable equipment’ means a device which, after the putting into service of machinery or of a tractor, is assembled with that machinery or tractor by the operator himself in order to change its function or attribute a new function, in so far as this equipment is not a tool;

- (c) ‘safety component’ means a component:

  - — which serves to fulfil a safety function,

  - — which is independently placed on the market,

  - — the failure and/or malfunction of which endangers the safety of persons, and

  - — which is not necessary in order for the machinery to function, or for which normal components may be substituted in order for the machinery to function.

  ▼M5

  An indicative list of safety components is set out in Annex V;

  ▼B

- (d) ‘lifting accessory’ means a component or equipment not attached to the lifting machinery, allowing the load to be held, which is placed between the machinery and the load or on the load itself, or which is intended to constitute an integral part of the load and which is independently placed on the market; slings and their components are also regarded as lifting accessories;

- (e) ‘chains, ropes and webbing’ means chains, ropes and webbing designed and constructed for lifting purposes as part of lifting machinery or lifting accessories;

- (f) ‘removable mechanical transmission device’ means a removable component for transmitting power between self-propelled machinery or a tractor and another machine by joining them at the first fixed bearing. When it is placed on the market with the guard it shall be regarded as one product;

- (g) ‘partly completed machinery’ means an assembly which is almost machinery but which cannot in itself perform a specific application. A drive system is partly completed machinery. Partly completed machinery is only intended to be incorporated into or assembled with other machinery or other partly completed machinery or equipment, thereby forming machinery to which this Directive applies;

- (h) ‘placing on the market’ means making available for the first time in the Community machinery or partly completed machinery with a view to distribution or use, whether for reward or free of charge;

- (i) ‘manufacturer’ means any natural or legal person who designs and/or manufactures machinery or partly completed machinery covered by this Directive and is responsible for the conformity of the machinery or the partly completed machinery with this Directive with a view to its being placed on the market, under his own name or trademark or for his own use. In the absence of a manufacturer as defined above, any natural or legal person who places on the market or puts into service machinery or partly completed machinery covered by this Directive shall be considered a manufacturer;

- (j) ‘authorised representative’ means any natural or legal person established in the Community who has received a written mandate from the manufacturer to perform on his behalf all or part of the obligations and formalities connected with this Directive;

- (k) ‘putting into service’ means the first use, for its intended purpose, in the Community, of machinery covered by this Directive;

- (l) ‘harmonised standard’ means a non-binding technical specification adopted by a standardisation body, namely the European Committee for Standardisation (CEN), the European Committee for Electrotechnical Standardisation (CENELEC) or the European Telecommunications Standards Institute (ETSI), on the basis of a remit issued by the Commission in accordance with the procedures laid down in Directive 98/34/EC of the European Parliament and of the Council of 22 June 1998 laying down a procedure for the provision of information in the field of technical standards and regulations and of rules on Information Society services ^(4);

▼M2

- (m) ‘essential health and safety requirements’ means mandatory provisions relating to the design and construction of the products subject to this Directive to ensure a high level of protection of the health and safety of persons and, where appropriate, of domestic animals and property and, where applicable, of the environment.

  The essential health and safety requirements are set out in Annex I. Essential health and safety requirements for the protection of the environment are applicable only to the machinery referred to in section 2.4 of that Annex;

▼M6

- (n) ‘crisis-relevant goods’ means crisis-relevant goods as defined in Article 3, point (6), of Regulation (EU) 2024/2747 of the European Parliament and of the Council ^(5);

- (o) ‘internal market emergency mode’ means internal market emergency mode as defined in Article 3, point (3), of Regulation (EU) 2024/2747.

▼B

<a id="art-3"></a>
### Article 3 – Specific Directives

Where, for machinery, the hazards referred to in Annex I are wholly or partly covered more specifically by other Community Directives, this Directive shall not apply, or shall cease to apply, to that machinery in respect of such hazards from the date of implementation of those other Directives.

<a id="art-4"></a>
### Article 4 – Market surveillance

▼M2

1. Member States shall take all appropriate measures to ensure that machinery may be placed on the market and/or put into service only if it satisfies the relevant provisions of this Directive and does not endanger the health and safety of persons and, where appropriate, domestic animals and property and, where applicable, the environment, when properly installed and maintained and used for its intended purpose or under reasonably foreseeable conditions.

▼B

2. Member States shall take all appropriate measures to ensure that partly completed machinery can be placed on the market only if it satisfies the relevant provisions of this Directive.

3. Member States shall institute or appoint the competent authorities to monitor the conformity of machinery and partly completed machinery with the provisions set out in paragraphs 1 and 2.

4. Member States shall define the tasks, organisation and powers of the competent authorities referred to in paragraph 3 and shall notify the Commission and other Member States thereof and also of any subsequent amendment.

<a id="art-5"></a>
### Article 5 – Placing on the market and putting into service

1. Before placing machinery on the market and/or putting it into service, the manufacturer or his authorised representative shall:

- (a) ensure that it satisfies the relevant essential health and safety requirements set out in Annex I;

- (b) ensure that the technical file referred to in Annex VII, part A is available;

- (c) provide, in particular, the necessary information, such as instructions;

- (d) carry out the appropriate procedures for assessing conformity in accordance with Article 12;

- (e) draw up the EC declaration of conformity in accordance with Annex II, part 1, Section A and ensure that it accompanies the machinery;

- (f) affix the CE marking in accordance with Article 16.

2. Before placing partly completed machinery on the market, the manufacturer or his authorised representative shall ensure that the procedure referred to in Article 13 has been completed.

3. For the purposes of the procedures referred to in Article 12, the manufacturer or his authorised representative shall have, or shall have access to, the necessary means of ensuring that the machinery satisfies the essential health and safety requirements set out in Annex I.

4. Where machinery is also the subject of other Directives relating to other aspects and providing for the affixing of the CE marking, the marking shall indicate that the machinery also conforms to the provisions of those other Directives.

However, where one or more of those Directives allow the manufacturer or his authorised representative to choose, during a transitional period, the system to be applied, the CE marking shall indicate conformity only to the provisions of those Directives applied by the manufacturer or his authorised representative. Particulars of the Directives applied, as published in the Official Journal of the European Union, shall be given on the EC declaration of conformity.

<a id="art-6"></a>
### Article 6 – Freedom of movement

1. Member States shall not prohibit, restrict or impede the placing on the market and/or putting into service in their territory of machinery which complies with this Directive.

2. Member States shall not prohibit, restrict or impede the placing on the market of partly completed machinery where the manufacturer or his authorised representative makes a declaration of incorporation, referred to in Annex II, part 1, Section B, stating that it is to be incorporated into machinery or assembled with other partly completed machinery to form machinery.

3. At trade fairs, exhibitions, demonstrations, and such like, Member States shall not prevent the showing of machinery or partly completed machinery which does not conform to this Directive, provided that a visible sign clearly indicates that it does not conform and that it will not be made available until it has been brought into conformity. Furthermore, during demonstrations of such non-conforming machinery or partly completed machinery, adequate safety measures shall be taken to ensure the protection of persons.

<a id="art-7"></a>
### Article 7 – Presumption of conformity and harmonised standards

1. Member States shall regard machinery bearing the CE marking and accompanied by the EC declaration of conformity, the content of which is set out in Annex II, part 1, Section A, as complying with the provisions of this Directive.

2. Machinery manufactured in conformity with a harmonised standard, the references to which have been published in the Official Journal of the European Union, shall be presumed to comply with the essential health and safety requirements covered by such a harmonised standard.

3. The Commission shall publish in the Official Journal of the European Union the references of the harmonised standards.

4. Member States shall take the appropriate measures to enable the social partners to have an influence at national level on the process of preparing and monitoring the harmonised standards.

▼M1

<a id="art-8"></a>
### Article 8 – Specific measures

▼M5

1. The Commission is empowered to adopt delegated acts in accordance with Article 21a amending Annex V to update the indicative list of safety components.

▼M1

2. The Commission, acting in accordance with the advisory procedure referred to in Article 22(2), may take any appropriate measure connected with the practical application of this Directive, including measures necessary to ensure cooperation of Member States with each other and with the Commission, as provided for in Article 19(1).

▼B

<a id="art-9"></a>
### Article 9 – Specific measures to deal with potentially hazardous machinery

1. When, in accordance with the procedure referred to in Article 10, the Commission considers that a harmonised standard does not entirely satisfy the essential health and safety requirements which it covers and which are set out in Annex I, the Commission may, in accordance with paragraph 3 of this Article, take measures requiring Member States to prohibit or restrict the placing on the market of machinery with technical characteristics presenting risks due to the shortcomings in the standard or to make such machinery subject to special conditions.

When, in accordance with the procedure referred to in Article 11, the Commission considers that a measure taken by a Member State is justified, the Commission may, in accordance with paragraph 3 of this Article, take measures requiring Member States to prohibit or restrict the placing on the market of machinery presenting the same risk by virtue of its technical characteristics or to make such machinery subject to special conditions.

2. Any Member State may request the Commission to examine the need for the adoption of the measures referred to in paragraph 1.

▼M1

►M2

In the cases referred to in paragraph 1, the Commission shall consult the Member States and other interested parties, indicating the measures it intends to take in order to ensure, at Community level, a high level of protection of the health and safety of persons and, where appropriate, of domestic animals and property and, where applicable, of the environment.

◄

▼M5

Taking due account of the results of that consultation, the Commission shall adopt the necessary measures by implementing acts. Those implementing acts shall be adopted in accordance with the procedure referred to in Article 22(3).

▼B

<a id="art-10"></a>
### Article 10 – Procedure for disputing a harmonised standard

Where a Member State or the Commission considers that a harmonised standard does not entirely satisfy the essential health and safety requirements which it covers and which are set out in Annex I, the Commission or the Member State shall bring the matter before the committee set up by Directive 98/34/EC, setting out the reasons therefor. The committee shall deliver an opinion without delay. In the light of the committee's opinion, the Commission shall decide to publish, not to publish, to publish with restriction, to maintain, to maintain with restriction or to withdraw the references to the harmonised standard concerned in the Official Journal of the European Union.

<a id="art-11"></a>
### Article 11 – Safeguard clause

▼M2

1. Where a Member State ascertains that machinery covered by this Directive, bearing the CE marking, accompanied by the EC declaration of conformity and used in accordance with its intended purpose or under reasonably foreseeable conditions, is liable to endanger the health or safety of persons or, where appropriate, domestic animals or property or, where applicable, the environment, it shall take all appropriate measures to withdraw such machinery from the market, to prohibit the placing on the market and/or putting into service of such machinery or to restrict the free movement thereof.

▼B

2. The Member State shall immediately inform the Commission and the other Member States of any such measure, indicating the reasons for its decision and, in particular, whether the non-conformity is due to:

- (a) failure to satisfy the essential requirements referred to in Article 5(1)(a);

- (b) incorrect application of the harmonised standards referred to in Article 7(2);

- (c) shortcomings in the harmonised standards themselves referred to in Article 7(2).

3. The Commission shall enter into consultation with the parties concerned without delay.

The Commission shall consider, after this consultation, whether or not the measures taken by the Member State are justified, and it shall communicate its decision to the Member State which took the initiative, the other Member States, and the manufacturer or his authorised representative.

4. Where the measures referred to in paragraph 1 are based on a shortcoming in the harmonised standards and if the Member State which instigated the measures maintains its position, the Commission or the Member State shall initiate the procedure referred to in Article 10.

5. Where machinery does not conform and bears the CE marking, the competent Member State shall take appropriate action against whomsoever has affixed the marking and shall so inform the Commission. The Commission shall inform the other Member States.

6. The Commission shall ensure that Member States are kept informed of the progress and outcome of the procedure.

<a id="art-12"></a>
### Article 12 – Procedures for assessing the conformity of machinery

1. The manufacturer or his authorised representative shall, in order to certify the conformity of machinery with the provisions of this Directive, apply one of the procedures for assessment of conformity described in paragraphs 2, 3 and 4.

2. Where the machinery is not referred to in Annex IV, the manufacturer or his authorised representative shall apply the procedure for assessment of conformity with internal checks on the manufacture of machinery provided for in Annex VIII.

3. Where the machinery is referred to in Annex IV and manufactured in accordance with the harmonised standards referred to in Article 7(2), and provided that those standards cover all of the relevant essential health and safety requirements, the manufacturer or his authorised representative shall apply one of the following procedures:

- (a) the procedure for assessment of conformity with internal checks on the manufacture of machinery, provided for in Annex VIII;

- (b) the EC type-examination procedure provided for in Annex IX, plus the internal checks on the manufacture of machinery provided for in Annex VIII, point 3;

- (c) the full quality assurance procedure provided for in Annex X.

4. Where the machinery is referred to in Annex IV and has not been manufactured in accordance with the harmonised standards referred to in Article 7(2), or only partly in accordance with such standards, or if the harmonised standards do not cover all the relevant essential health and safety requirements or if no harmonised standards exist for the machinery in question, the manufacturer or his authorised representative shall apply one of the following procedures:

- (a) the EC type-examination procedure provided for in Annex IX, plus the internal checks on the manufacture of machinery provided for in Annex VIII, point 3;

- (b) the full quality assurance procedure provided for in Annex X.

<a id="art-13"></a>
### Article 13 – Procedure for partly completed machinery

1. The manufacturer of partly completed machinery or his authorised representative shall, before placing it on the market, ensure that:

- (a) the relevant technical documentation described in Annex VII, part B is prepared;

- (b) assembly instructions described in Annex VI are prepared;

- (c) a declaration of incorporation described in Annex II, part 1, Section B has been drawn up.

2. The assembly instructions and the declaration of incorporation shall accompany the partly completed machinery until it is incorporated into the final machinery and shall then form part of the technical file for that machinery.

<a id="art-14"></a>
### Article 14 – Notified bodies

1. Member States shall notify the Commission and the other Member States of the bodies which they have appointed to carry out the assessment of conformity for placing on the market referred to in Article 12(3) and (4), together with the specific conformity assessment procedures and categories of machinery for which these bodies have been appointed and the identification numbers assigned to them beforehand by the Commission. Member States shall notify the Commission and other Member States of any subsequent amendment.

2. The Member States shall ensure that the notified bodies are monitored regularly to check that they comply at all times with the criteria set out in Annex XI. The notified body shall provide all relevant information on request, including budgetary documents, to enable the Member States to ensure that the requirements of Annex XI are met.

3. Member States shall apply the criteria set out in Annex XI in assessing the bodies to be notified and the bodies already notified.

4. The Commission shall publish in the Official Journal of the European Union, for information, a list of the notified bodies and their identification numbers and the tasks for which they have been notified. The Commission shall ensure that this list is kept up to date.

5. Bodies meeting the assessment criteria laid down in the relevant harmonised standards, the references of which shall be published in the Official Journal of the European Union, shall be presumed to fulfil the relevant criteria.

6. If a notified body finds that relevant requirements of this Directive have not been met or are no longer met by the manufacturer or that an EC type-examination certificate or the approval of a quality assurance system should not have been issued, it shall, taking account of the principle of proportionality, suspend or withdraw the certificate or the approval issued or place restrictions on it, giving detailed reasons, unless compliance with such requirements is ensured by the implementation of appropriate corrective measures by the manufacturer. In the event of suspension or withdrawal of the certificate or the approval or of any restriction placed on it, or in cases where intervention by the competent authority may prove necessary, the notified body shall inform the competent authority pursuant to Article 4. The Member State shall inform the other Member States and the Commission without delay. An appeal procedure shall be available.

7. The Commission shall provide for the organisation of an exchange of experience between the authorities responsible for appointment, notification and monitoring of notified bodies in the Member States, and the notified bodies, in order to coordinate the uniform application of this Directive.

8. A Member State which has notified a body shall immediately withdraw its notification if it finds:

- (a) that the body no longer meets the criteria set out in Annex XI; or

- (b) that the body seriously fails to fulfil its responsibilities.

The Member State shall immediately inform the Commission and the other Member States accordingly.

<a id="art-15"></a>
### Article 15 – Installation and use of machinery

This Directive shall not affect Member States' entitlement to lay down, in due observance of Community law, such requirements as they may deem necessary to ensure that persons, and in particular workers, are protected when using machinery, provided that this does not mean that such machinery is modified in a way not specified in this Directive.

<a id="art-16"></a>
### Article 16 – CE marking

1. The CE conformity marking shall consist of the initials ‘CE’ as shown in Annex III.

2. The CE marking shall be affixed to the machinery visibly, legibly and indelibly in accordance with Annex III.

3. The affixing on machinery of markings, signs and inscriptions which are likely to mislead third parties as to the meaning or form of the CE marking, or both, shall be prohibited. Any other marking may be affixed to the machinery provided that the visibility, legibility and meaning of the CE marking is not thereby impaired.

<a id="art-17"></a>
### Article 17 – Non-conformity of marking

1. Member States shall consider the following marking not to conform:

- (a) the affixing of the CE marking pursuant to this Directive on products not covered by this Directive;

- (b) the absence of the CE marking and/or the absence of the EC declaration of conformity for machinery;

- (c) the affixing on machinery of a marking, other than the CE marking, which is prohibited under Article 16(3).

2. Where a Member State ascertains that marking does not conform to the relevant provisions of this Directive, the manufacturer or his authorised representative shall be obliged to make the product conform and to put an end to the infringement under conditions fixed by that Member State.

3. Where non-conformity persists, the Member State shall take all appropriate measures to restrict or prohibit the placing on the market of the product in question or to ensure that it is withdrawn from the market in accordance with the procedure laid down in Article 11.

<a id="art-18"></a>
### Article 18 – Confidentiality

1. Without prejudice to existing national provisions and practices in the area of confidentiality, Members States shall ensure that all parties and persons concerned by the application of this Directive are required to treat as confidential information obtained in the execution of their tasks. More particularly business, professional and trade secrets shall be treated as confidential, unless the divulging of such information is necessary in order to protect the health and safety of persons.

2. The provisions of paragraph 1 shall not affect the obligations of the Member States and the notified bodies with regard to mutual exchange of information and the issuing of warnings.

3. Any decisions taken by the Member States and by the Commission in accordance with Articles 9 and 11 shall be published.

<a id="art-19"></a>
### Article 19 – Cooperation between Member States

1. Member States shall take the appropriate measures to ensure that the competent authorities referred to in Article 4(3) cooperate with each other and with the Commission and transmit to each other the information necessary to enable this Directive to be applied uniformly.

2. The Commission shall provide for the organisation of an exchange of experience between the competent authorities responsible for market surveillance in order to coordinate the uniform application of this Directive.

<a id="art-20"></a>
### Article 20 – Legal remedies

Any measure taken pursuant to this Directive which restricts the placing on the market and/or putting into service of any machinery covered by this Directive shall state the exact grounds on which it is based. Such a measure shall be notified as soon as possible to the party concerned, who shall at the same time be informed of the legal remedies available to him under the laws in force in the Member State concerned and of the time limits to which such remedies are subject.

<a id="art-21"></a>
### Article 21 – Dissemination of information

The Commission shall take the necessary measures for appropriate information concerning the implementation of this Directive to be made available.

▼M5

<a id="art-21a"></a>
### Article 21a – Exercise of the delegation

1. The power to adopt delegated acts is conferred on the Commission subject to the conditions laid down in this Article.

2. The power to adopt delegated acts referred to in Article 8(1) shall be conferred on the Commission for a period of five years from 26 July 2019. The Commission shall draw up a report in respect of the delegation of power not later than nine months before the end of the five-year period. The delegation of power shall be tacitly extended for periods of an identical duration, unless the European Parliament or the Council opposes such extension not later than three months before the end of each period.

3. The delegation of power referred to in Article 8(1) may be revoked at any time by the European Parliament or by the Council. A decision to revoke shall put an end to the delegation of the power specified in that decision. It shall take effect the day following the publication of the decision in the Official Journal of the European Union or at a later date specified therein. It shall not affect the validity of any delegated acts already in force.

4. Before adopting a delegated act, the Commission shall consult experts designated by each Member State in accordance with the principles laid down in the Interinstitutional Agreement of 13 April 2016 on Better Law-Making ^(6).

5. As soon as it adopts a delegated act, the Commission shall notify it simultaneously to the European Parliament and to the Council.

6. A delegated act adopted pursuant to Article 8(1) shall enter into force only if no objection has been expressed either by the European Parliament or the Council within a period of three months of notification of that act to the European Parliament and the Council or if, before the expiry of that period, the European Parliament and the Council have both informed the Commission that they will not object. That period shall be extended by two months at the initiative of the European Parliament or of the Council.

▼M6

<a id="art-21b"></a>
### Article 21b – Application of emergency procedures

1. Member States shall ensure that measures taken to transpose Articles 21c to 21f of this Directive apply only if the Commission has adopted an implementing act pursuant to Article 28 of Regulation (EU) 2024/2747 with respect to machinery covered by this Directive.

2. Member States shall ensure that measures taken to transpose Articles 21c to 21f of this Directive apply only to machinery which has been designated as crisis-relevant goods pursuant to Article 18(4) of Regulation (EU) 2024/2747.

3. Member States shall ensure that measures taken to transpose Articles 21c to 21f of this Directive apply only during the internal market emergency mode that has been activated in accordance with Article 18 of Regulation (EU) 2024/2747.

However, Article 21d(7) of this Directive shall apply during the internal market emergency mode and after its expiry or deactivation.

4. The Commission may adopt implementing acts regarding the corrective or restrictive actions to be taken, the procedures to be followed and the specific labelling and traceability requirements with respect to machinery placed on the market or put into service in accordance with Articles 21d and 21e. Those implementing acts shall be adopted in accordance with the examination procedure referred to in Article 22(3).

<a id="art-21c"></a>
### Article 21c – Prioritisation of the conformity assessment of machinery designated as crisis-relevant goods

1. This Article applies to machinery listed in the implementing act referred to in Article 21b(1) that is subject to the conformity assessment procedures referred to in Article 12 that require the mandatory involvement of a notified body.

2. The notified bodies shall make best efforts to process as a matter of priority all applications for a conformity assessment of machinery referred to in paragraph 1 of this Article, irrespective of whether those applications have been lodged before or after the activation of the emergency procedures pursuant to Article 21b.

3. The prioritisation of applications for a conformity assessment of machinery pursuant to paragraph 2 shall not result in additional disproportionate costs for the manufacturers who have lodged those applications.

4. The notified bodies shall make reasonable efforts to increase their testing capacities for machinery referred to in paragraph 1 in respect of which they have been notified.

<a id="art-21d"></a>
### Article 21d – Derogation from the conformity assessment procedures requiring the mandatory involvement of a notified body

1. By way of derogation from Article 12, a Member State may authorise, on a duly justified request from an economic operator, the placing on the market or putting into service within the territory of that Member State, of specific machinery listed in the implementing act referred to in Article 21b(1) and for which the conformity assessment procedures referred to in Article 12 that require the mandatory involvement of a notified body have not been carried out but for which the compliance with all the applicable essential health and safety requirements laid down in this Directive has been demonstrated in accordance with procedures referred to in that authorisation.

2. The Member State shall immediately inform the Commission and the other Member States of any authorisation granted in accordance with paragraph 1 of this Article. Provided that the requirements set out in the authorisation ensure the conformity with the applicable essential health and safety requirements set out in Annex I, the Commission shall adopt, without delay, an implementing act extending the validity of the authorisation granted by a Member State in accordance with paragraph 1 of this Article to the territory of the whole Union and shall set out the conditions under which the specific machinery may be placed on the market or put into service. When preparing the draft implementing act, the Commission may request national market surveillance authorities to provide relevant information or comments regarding the technical assessment that served as the basis for the authorisation referred to in paragraph 1 of this Article. The implementing act shall be adopted in accordance with the examination procedure referred to in Article 22(3).

The machinery subject to the extension of validity referred to in the first subparagraph shall bear the information that it is placed on the market or put into service as a ‘crisis-relevant good’. The implementing act referred to in the first subparagraph shall specify the content and presentation of that information. That information, as well as any labelling, shall be clear, understandable and intelligible and, where relevant, in a language which can be easily understood by consumers and other end-users, as determined by the Member State concerned.

3. On duly justified imperative grounds of urgency relating to the need to preserve the health and safety of persons, the Commission shall adopt immediately applicable implementing acts in accordance with the procedure referred to in Article 22(4).

4. As long as an implementing act as referred to in paragraph 2 or 3 is not adopted, the authorisation granted by a competent national authority in one Member State shall be valid only on the territory of that Member State, and on the territories of any other Member States whose competent national authorities have recognised the validity of that authorisation before the adoption of such an implementing act. Member States shall inform the Commission and the other Member States of any decision to recognise the validity of that authorisation.

5. Manufacturers of machinery subject to the authorisation procedure referred to in paragraph 1 shall declare on their sole responsibility that the machinery concerned complies with all the applicable essential health and safety requirements set out in Annex I and shall be responsible for the fulfilment of all the conformity assessment procedures indicated by the competent national authority.

6. Any authorisation issued pursuant to paragraph 1 shall set out the conditions and requirements under which the machinery may be placed on the market or put into service. Such authorisations shall set out at least the following:

- (a) a description of the procedures, by means of which compliance with the applicable essential health and safety requirements set out in Annex I to this Directive was successfully demonstrated;

- (b) any specific requirements regarding the traceability of the machinery concerned;

- (c) an end date of validity of the authorisation, which cannot go beyond the last day of the period for which the internal market emergency mode has been activated in accordance with Article 18 of Regulation (EU) 2024/2747;

- (d) any specific requirements regarding the need to ensure a continuous conformity assessment with respect to the machinery concerned;

- (e) measures to be taken upon expiry or deactivation of the internal market emergency mode with respect to the machinery concerned that has been placed on the market or put into service.

7. By way of derogation from Articles 6 and 16, machinery for which an authorisation has been granted in accordance with paragraph 1 of this Article shall not bear the CE marking and Article 6 shall not apply.

8. The market surveillance authorities of a Member State where an authorisation pursuant to paragraphs 1, 2 and 4 of this Article is valid shall be entitled, with respect to such machinery, to take all corrective and restrictive actions at national level provided for under Regulation (EU) 2019/1020 of the European Parliament and of the Council ^(7) and under this Directive. They shall immediately inform the Commission and the market surveillance authorities of all other Member States of these actions.

9. The use of the authorisation procedure set out in paragraphs 1 to 4 of this Article shall not affect the application on the territory of the Member State concerned of the relevant conformity assessment procedures laid down in Article 12.

<a id="art-21e"></a>
### Article 21e – Presumption of conformity based on standards and common specifications

1. Where machinery has been designated as crisis-relevant goods, the Commission is empowered to adopt implementing acts listing appropriate standards or establishing common specifications for such machinery to cover the relevant essential health and safety requirements set out in Annex I to this Directive in the following cases:

- (a) where a reference to harmonised standards covering the relevant essential health and safety requirements set out in Annex I to this Directive has not been published in the Official Journal of the European Union in accordance with Regulation (EU) No 1025/2012 of the European Parliament and of the Council ^(8) and no such reference is expected to be published within a reasonable period; or

- (b) where severe disruptions to the functioning of the internal market, which led to the activation of the internal market emergency mode in accordance with Article 18 of Regulation (EU) 2024/2747, significantly restrict the possibilities of manufacturers to make use of the harmonised standards that cover the relevant essential health and safety requirements set out in Annex I to this Directive and the references of which have already been published in the Official Journal of the European Union in accordance with Regulation (EU) No 1025/2012.

2. The implementing acts referred to in paragraph 1 shall set out the most appropriate alternative technical solution for the purposes of providing a presumption of conformity in accordance with paragraph 5. To that end, references of European standards or references of relevant applicable national or international standards may be published in those implementing acts or, if there is no European standard or relevant applicable national or international standard, common specifications may be established by those implementing acts.

3. The implementing acts referred to in paragraph 1 of this Article shall be adopted in accordance with the examination procedure referred to in Article 22(3) and shall apply until the last day of the period during which the internal market emergency mode is activated, unless such implementing acts are amended or repealed in accordance with paragraph 7 of this Article.

4. Before preparing the draft implementing act referred to in paragraph 1 of this Article, the Commission shall inform the committee referred to in Article 22 of Regulation (EU) No 1025/2012 that it considers that the conditions in paragraph 1 of this Article have been fulfilled. When preparing that draft implementing act, the Commission shall take into account the views of relevant bodies or expert groups established under this Directive and shall duly consult all relevant stakeholders.

5. Without prejudice to Article 7, machinery that is in conformity with the standards or common specifications referred to in paragraph 1 of this Article, or parts thereof, shall be presumed to be in conformity with the relevant essential health and safety requirements set out in Annex I that are covered by those standards, common specifications or parts thereof. From the day following the expiry or deactivation of the internal market emergency mode, it shall no longer be possible for manufacturers to rely on the presumption of conformity provided by the standards or the common specifications referred to in the implementing acts referred to in paragraph 1 of this Article.

6. By way of derogation from Article 21b(3), first subparagraph, unless there is sufficient reason to believe that the machinery covered by the standards or common specifications referred to in paragraph 1 of this Article presents a risk to the health or safety of persons, the machinery that is in conformity with those standards or common specifications and which has been placed on the market or put into service shall be deemed to be in conformity with the relevant essential health and safety requirements set out in Annex I after the expiry or repeal of an implementing act adopted pursuant to paragraph 3 of this Article and after the expiry or deactivation of the internal market emergency mode.

7. When a Member State considers that a standard or common specification as referred to in paragraph 1 does not entirely satisfy the relevant essential health and safety requirements set out in Annex I, it shall inform the Commission thereof by submitting a detailed explanation. The Commission shall assess that detailed explanation and may, if appropriate, amend or repeal the implementing act listing the standard or establishing the common specification in question.

<a id="art-21f"></a>
### Article 21f – Prioritisation of market surveillance activities and mutual assistance among authorities

1. Member States shall prioritise the market surveillance activities for machinery listed in the implementing act referred to in Article 21b(1) of this Directive. The Commission shall facilitate coordination of such prioritisation efforts through the Union Product Compliance Network established under Article 29 of Regulation (EU) 2019/1020.

2. The market surveillance authorities of the Member States shall ensure that best efforts are made to provide assistance to other market surveillance authorities during an internal market emergency mode, including by mobilising and dispatching expert teams to temporarily reinforce the staff of market surveillance authorities requesting assistance or by providing logistical support, such as the reinforcement of the testing capacity for machinery listed in the implementing act referred to in Article 21b(1).

▼B

<a id="art-22"></a>
### Article 22 – Committee

1. The Commission shall be assisted by a committee, hereinafter referred to as the ‘Committee’.

2. Where reference is made to this paragraph, Articles 3 and 7 of Decision 1999/468/EC shall apply, having regard to the provisions of Article 8 thereof.

▼M5

3. Where reference is made to this paragraph, Article 5 of Regulation (EU) No 182/2011 of the European Parliament and of the Council ^(9) shall apply.

▼M6

4. Where reference is made to this paragraph, Article 8 of Regulation (EU) No 182/2011, in conjunction with Article 5 thereof, shall apply.

▼M1 —————

▼B

<a id="art-23"></a>
### Article 23 – Penalties

Member States shall lay down the rules on penalties applicable to infringements of the national provisions adopted pursuant to this Directive and shall take all measures necessary to ensure that they are implemented. The penalties provided for must be effective, proportionate and dissuasive. Member States shall notify those provisions to the Commission by 29 June 2008 and shall notify it without delay of any subsequent amendment affecting them.

▼M4 —————

▼B

<a id="art-25"></a>
### Article 25 – Repeal

▼C1

Directive 98/37/EC is hereby repealed as from 29 December 2009.

▼B

References made to the repealed Directive shall be construed as being made to this Directive and should be read in accordance with the correlation table in Annex XII.

<a id="art-26"></a>
### Article 26 – Transposition

1. Member States shall adopt and publish the provisions necessary to comply with this Directive by 29 June 2008 at the latest. They shall forthwith inform the Commission thereof.

They shall apply those provisions with effect from 29 December 2009.

When Member States adopt those provisions, they shall contain a reference to this Directive or shall be accompanied by such reference on the occasion of their official publication. Member States shall determine how such reference is to be made.

2. Member States shall communicate to the Commission the text of the provisions of national law which they adopt in the field covered by this Directive, together with a table showing how the provisions of this Directive correspond to the national provisions adopted.

<a id="art-27"></a>
### Article 27 – Derogation

Until 29 June 2011 Member States may allow the placing on the market and the putting into service of portable cartridge-operated fixing and other impact machinery which are in conformity with the national provisions in force upon adoption of this Directive.

<a id="art-28"></a>
### Article 28 – Entry into force

This Directive shall enter into force on the 20th day following its publication in the Official Journal of the European Union.

<a id="art-29"></a>
### Article 29 – Addressees

This Directive is addressed to the Member States.

<a id="annex-i"></a>
## Annex I – Essential health and safety requirements relating to the the design and construction of machinery

### GENERAL PRINCIPLES

1. The manufacturer of machinery or his authorised representative must ensure that a risk assessment is carried out in order to determine the health and safety requirements which apply to the machinery. The machinery must then be designed and constructed taking into account the results of the risk assessment.

By the iterative process of risk assessment and risk reduction referred to above, the manufacturer or his authorised representative shall:

- — determine the limits of the machinery, which include the intended use and any reasonably foreseeable misuse thereof,

- — identify the hazards that can be generated by the machinery and the associated hazardous situations,

- — estimate the risks, taking into account the severity of the possible injury or damage to health and the probability of its occurrence,

- — evaluate the risks, with a view to determining whether risk reduction is required, in accordance with the objective of this Directive,

- — eliminate the hazards or reduce the risks associated with these hazards by application of protective measures, in the order of priority established in section 1.1.2(b).

2. The obligations laid down by the essential health and safety requirements only apply when the corresponding hazard exists for the machinery in question when it is used under the conditions foreseen by the manufacturer or his authorised representative or in foreseeable abnormal situations. In any event, the principles of safety integration referred to in section 1.1.2 and the obligations concerning marking of machinery and instructions referred to in sections 1.7.3 and 1.7.4 apply.

3. The essential health and safety requirements laid down in this Annex are mandatory; However, taking into account the state of the art, it may not be possible to meet the objectives set by them. In that event, the machinery must, as far as possible, be designed and constructed with the purpose of approaching these objectives.

▼M2

4. This Annex is organised in several parts. The first one is of general scope and applicable to all kinds of machinery. The other parts refer to certain kinds of more specific hazards. Nevertheless, it is essential to examine the whole of this Annex in order to be sure of meeting all the relevant essential requirements. When machinery is being designed, the requirements of the general part and the requirements of one or more of the other parts shall be taken into account, depending on the results of the risk assessment carried out in accordance with point 1 of these General Principles. Essential health and safety requirements for the protection of the environment are applicable only to the machinery referred to in section 2.4.

▼B

#### 1. ESSENTIAL HEALTH AND SAFETY REQUIREMENTS

#### 1.1. GENERAL REMARKS

#### 1.1.1. Definitions

For the purpose of this Annex:

- (a) ‘hazard’ means a potential source of injury or damage to health;

- (b) ‘danger zone’ means any zone within and/or around machinery in which a person is subject to a risk to his health or safety;

- (c) ‘exposed person’ means any person wholly or partially in a danger zone;

- (d) ‘operator’ means the person or persons installing, operating, adjusting, maintaining, cleaning, repairing or moving machinery;

- (e) ‘risk’ means a combination of the probability and the degree of an injury or damage to health that can arise in a hazardous situation;

- (f) ‘guard’ means a part of the machinery used specifically to provide protection by means of a physical barrier;

- (g) ‘protective device’ means a device (other than a guard) which reduces the risk, either alone or in conjunction with a guard;

- (h) ‘intended use’ means the use of machinery in accordance with the information provided in the instructions for use;

- (i) ‘reasonably foreseeable misuse’ means the use of machinery in a way not intended in the instructions for use, but which may result from readily predictable human behaviour.

#### 1.1.2. Principles of safety integration

- (a) Machinery must be designed and constructed so that it is fitted for its function, and can be operated, adjusted and maintained without putting persons at risk when these operations are carried out under the conditions foreseen but also taking into account any reasonably foreseeable misuse thereof.

  The aim of measures taken must be to eliminate any risk throughout the foreseeable lifetime of the machinery including the phases of transport, assembly, dismantling, disabling and scrapping.

- (b) In selecting the most appropriate methods, the manufacturer or his authorised representative must apply the following principles, in the order given:

  - — eliminate or reduce risks as far as possible (inherently safe machinery design and construction),

  - — take the necessary protective measures in relation to risks that cannot be eliminated,

  - — inform users of the residual risks due to any shortcomings of the protective measures adopted, indicate whether any particular training is required and specify any need to provide personal protective equipment.

- (c) When designing and constructing machinery and when drafting the instructions, the manufacturer or his authorised representative must envisage not only the intended use of the machinery but also any reasonably foreseeable misuse thereof.

  The machinery must be designed and constructed in such a way as to prevent abnormal use if such use would engender a risk. Where appropriate, the instructions must draw the user's attention to ways — which experience has shown might occur — in which the machinery should not be used.

- (d) Machinery must be designed and constructed to take account of the constraints to which the operator is subject as a result of the necessary or foreseeable use of personal protective equipment.

- (e) Machinery must be supplied with all the special equipment and accessories essential to enable it to be adjusted, maintained and used safely.

#### 1.1.3. Materials and products

The materials used to construct machinery or products used or created during its use must not endanger persons' safety or health. In particular, where fluids are used, machinery must be designed and constructed to prevent risks due to filling, use, recovery or draining.

#### 1.1.4. Lighting

Machinery must be supplied with integral lighting suitable for the operations concerned where the absence thereof is likely to cause a risk despite ambient lighting of normal intensity.

Machinery must be designed and constructed so that there is no area of shadow likely to cause nuisance, that there is no irritating dazzle and that there are no dangerous stroboscopic effects on moving parts due to the lighting.

Internal parts requiring frequent inspection and adjustment, and maintenance areas must be provided with appropriate lighting.

#### 1.1.5. Design of machinery to facilitate its handling

Machinery, or each component part thereof, must:

- — be capable of being handled and transported safely,

- — be packaged or designed so that it can be stored safely and without damage.

During the transportation of the machinery and/or its component parts, there must be no possibility of sudden movements or of hazards due to instability as long as the machinery and/or its component parts are handled in accordance with the instructions.

Where the weight, size or shape of machinery or its various component parts prevents them from being moved by hand, the machinery or each component part must:

- — either be fitted with attachments for lifting gear, or

- — be designed so that it can be fitted with such attachments, or

- — be shaped in such a way that standard lifting gear can easily be attached.

Where machinery or one of its component parts is to be moved by hand, it must:

- — either be easily moveable, or

- — be equipped for picking up and moving safely.

Special arrangements must be made for the handling of tools and/or machinery parts which, even if lightweight, could be hazardous.

#### 1.1.6. Ergonomics

Under the intended conditions of use, the discomfort, fatigue and physical and psychological stress faced by the operator must be reduced to the minimum possible, taking into account ergonomic principles such as:

- — allowing for the variability of the operator's physical dimensions, strength and stamina,

- — providing enough space for movements of the parts of the operator's body,

- — avoiding a machine-determined work rate,

- — avoiding monitoring that requires lengthy concentration,

- — adapting the man/machinery interface to the foreseeable characteristics of the operators.

#### 1.1.7. Operating positions

The operating position must be designed and constructed in such a way as to avoid any risk due to exhaust gases and/or lack of oxygen.

If the machinery is intended to be used in a hazardous environment presenting risks to the health and safety of the operator or if the machinery itself gives rise to a hazardous environment, adequate means must be provided to ensure that the operator has good working conditions and is protected against any foreseeable hazards.

Where appropriate, the operating position must be fitted with an adequate cabin designed, constructed and/or equipped to fulfil the above requirements. The exit must allow rapid evacuation. Moreover, when applicable, an emergency exit must be provided in a direction which is different from the usual exit.

#### 1.1.8. Seating

Where appropriate and where the working conditions so permit, work stations constituting an integral part of the machinery must be designed for the installation of seats.

If the operator is intended to sit during operation and the operating position is an integral part of the machinery, the seat must be provided with the machinery.

The operator's seat must enable him to maintain a stable position. Furthermore, the seat and its distance from the control devices must be capable of being adapted to the operator.

If the machinery is subject to vibrations, the seat must be designed and constructed in such a way as to reduce the vibrations transmitted to the operator to the lowest level that is reasonably possible. The seat mountings must withstand all stresses to which they can be subjected. Where there is no floor beneath the feet of the operator, footrests covered with a slip-resistant material must be provided.

#### 1.2. CONTROL SYSTEMS

#### 1.2.1. Safety and reliability of control systems

Control systems must be designed and constructed in such a way as to prevent hazardous situations from arising. Above all, they must be designed and constructed in such a way that:

- — they can withstand the intended operating stresses and external influences,

- — a fault in the hardware or the software of the control system does not lead to hazardous situations,

- — errors in the control system logic do not lead to hazardous situations,

- — reasonably foreseeable human error during operation does not lead to hazardous situations.

Particular attention must be given to the following points:

- — the machinery must not start unexpectedly,

- — the parameters of the machinery must not change in an uncontrolled way, where such change may lead to hazardous situations,

- — the machinery must not be prevented from stopping if the stop command has already been given,

- — no moving part of the machinery or piece held by the machinery must fall or be ejected,

- — automatic or manual stopping of the moving parts, whatever they may be, must be unimpeded,

- — the protective devices must remain fully effective or give a stop command,

- — the safety-related parts of the control system must apply in a coherent way to the whole of an assembly of machinery and/or partly completed machinery.

For cable-less control, an automatic stop must be activated when correct control signals are not received, including loss of communication.

#### 1.2.2. Control devices

Control devices must be:

- — clearly visible and identifiable, using pictograms where appropriate,

- — positioned in such a way as to be safely operated without hesitation or loss of time and without ambiguity,

- — designed in such a way that the movement of the control device is consistent with its effect,

- — located outside the danger zones, except where necessary for certain control devices such as an emergency stop or a teach pendant,

- — positioned in such a way that their operation cannot cause additional risk,

- — designed or protected in such a way that the desired effect, where a hazard is involved, can only be achieved by a deliberate action,

- — made in such a way as to withstand foreseeable forces; particular attention must be paid to emergency stop devices liable to be subjected to considerable forces.

Where a control device is designed and constructed to perform several different actions, namely where there is no one-to-one correspondence, the action to be performed must be clearly displayed and subject to confirmation, where necessary.

Control devices must be so arranged that their layout, travel and resistance to operation are compatible with the action to be performed, taking account of ergonomic principles.

Machinery must be fitted with indicators as required for safe operation. The operator must be able to read them from the control position.

From each control position, the operator must be able to ensure that no-one is in the danger zones, or the control system must be designed and constructed in such a way that starting is prevented while someone is in the danger zone.

If neither of these possibilities is applicable, before the machinery starts, an acoustic and/or visual warning signal must be given. The exposed persons must have time to leave the danger zone or prevent the machinery starting up.

If necessary, means must be provided to ensure that the machinery can be controlled only from control positions located in one or more predetermined zones or locations.

Where there is more than one control position, the control system must be designed in such a way that the use of one of them precludes the use of the others, except for stop controls and emergency stops.

When machinery has two or more operating positions, each position must be provided with all the required control devices without the operators hindering or putting each other into a hazardous situation.

#### 1.2.3. Starting

It must be possible to start machinery only by voluntary actuation of a control device provided for the purpose.

The same requirement applies:

- — when restarting the machinery after a stoppage, whatever the cause,

- — when effecting a significant change in the operating conditions.

However, the restarting of the machinery or a change in operating conditions may be effected by voluntary actuation of a device other than the control device provided for the purpose, on condition that this does not lead to a hazardous situation.

For machinery functioning in automatic mode, the starting of the machinery, restarting after a stoppage, or a change in operating conditions may be possible without intervention, provided this does not lead to a hazardous situation.

Where machinery has several starting control devices and the operators can therefore put each other in danger, additional devices must be fitted to rule out such risks. If safety requires that starting and/or stopping must be performed in a specific sequence, there must be devices which ensure that these operations are performed in the correct order.

#### 1.2.4. Stopping

#### 1.2.4.1. Normal stop

Machinery must be fitted with a control device whereby the machinery can be brought safely to a complete stop.

Each workstation must be fitted with a control device to stop some or all of the functions of the machinery, depending on the existing hazards, so that the machinery is rendered safe.

The machinery's stop control must have priority over the start controls.

Once the machinery or its hazardous functions have stopped, the energy supply to the actuators concerned must be cut off.

#### 1.2.4.2. Operational stop

Where, for operational reasons, a stop control that does not cut off the energy supply to the actuators is required, the stop condition must be monitored and maintained.

#### 1.2.4.3. Emergency stop

Machinery must be fitted with one or more emergency stop devices to enable actual or impending danger to be averted.

The following exceptions apply:

- — machinery in which an emergency stop device would not lessen the risk, either because it would not reduce the stopping time or because it would not enable the special measures required to deal with the risk to be taken,

- — portable hand-held and/or hand-guided machinery.

The device must:

- — have clearly identifiable, clearly visible and quickly accessible control devices,

- — stop the hazardous process as quickly as possible, without creating additional risks,

- — where necessary, trigger or permit the triggering of certain safeguard movements.

Once active operation of the emergency stop device has ceased following a stop command, that command must be sustained by engagement of the emergency stop device until that engagement is specifically overridden; it must not be possible to engage the device without triggering a stop command; it must be possible to disengage the device only by an appropriate operation, and disengaging the device must not restart the machinery but only permit restarting.

The emergency stop function must be available and operational at all times, regardless of the operating mode.

Emergency stop devices must be a back-up to other safeguarding measures and not a substitute for them.

#### 1.2.4.4. Assembly of machinery

In the case of machinery or parts of machinery designed to work together, the machinery must be designed and constructed in such a way that the stop controls, including the emergency stop devices, can stop not only the machinery itself but also all related equipment, if its continued operation may be dangerous.

#### 1.2.5. Selection of control or operating modes

The control or operating mode selected must override all other control or operating modes, with the exception of the emergency stop.

If machinery has been designed and constructed to allow its use in several control or operating modes requiring different protective measures and/or work procedures, it must be fitted with a mode selector which can be locked in each position. Each position of the selector must be clearly identifiable and must correspond to a single operating or control mode.

The selector may be replaced by another selection method which restricts the use of certain functions of the machinery to certain categories of operator.

If, for certain operations, the machinery must be able to operate with a guard displaced or removed and/or a protective device disabled, the control or operating mode selector must simultaneously:

- — disable all other control or operating modes,

- — permit operation of hazardous functions only by control devices requiring sustained action,

- — permit the operation of hazardous functions only in reduced risk conditions while preventing hazards from linked sequences,

- — prevent any operation of hazardous functions by voluntary or involuntary action on the machine's sensors.

If these four conditions cannot be fulfilled simultaneously, the control or operating mode selector must activate other protective measures designed and constructed to ensure a safe intervention zone.

In addition, the operator must be able to control operation of the parts he is working on from the adjustment point.

#### 1.2.6. Failure of the power supply

The interruption, the re-establishment after an interruption or the fluctuation in whatever manner of the power supply to the machinery must not lead to dangerous situations.

Particular attention must be given to the following points:

- — the machinery must not start unexpectedly,

- — the parameters of the machinery must not change in an uncontrolled way when such change can lead to hazardous situations,

- — the machinery must not be prevented from stopping if the command has already been given,

- — no moving part of the machinery or piece held by the machinery must fall or be ejected,

- — automatic or manual stopping of the moving parts, whatever they may be, must be unimpeded,

- — the protective devices must remain fully effective or give a stop command.

#### 1.3. PROTECTION AGAINST MECHANICAL HAZARDS

#### 1.3.1. Risk of loss of stability

Machinery and its components and fittings must be stable enough to avoid overturning, falling or uncontrolled movements during transportation, assembly, dismantling and any other action involving the machinery.

If the shape of the machinery itself or its intended installation does not offer sufficient stability, appropriate means of anchorage must be incorporated and indicated in the instructions.

#### 1.3.2. Risk of break-up during operation

The various parts of machinery and their linkages must be able to withstand the stresses to which they are subject when used.

The durability of the materials used must be adequate for the nature of the working environment foreseen by the manufacturer or his authorised representative, in particular as regards the phenomena of fatigue, ageing, corrosion and abrasion.

The instructions must indicate the type and frequency of inspections and maintenance required for safety reasons. They must, where appropriate, indicate the parts subject to wear and the criteria for replacement.

Where a risk of rupture or disintegration remains despite the measures taken, the parts concerned must be mounted, positioned and/or guarded in such a way that any fragments will be contained, preventing hazardous situations.

Both rigid and flexible pipes carrying fluids, particularly those under high pressure, must be able to withstand the foreseen internal and external stresses and must be firmly attached and/or protected to ensure that no risk is posed by a rupture.

Where the material to be processed is fed to the tool automatically, the following conditions must be fulfilled to avoid risks to persons:

- — when the workpiece comes into contact with the tool, the latter must have attained its normal working condition,

- — when the tool starts and/or stops (intentionally or accidentally), the feed movement and the tool movement must be coordinated.

#### 1.3.3. Risks due to falling or ejected objects

Precautions must be taken to prevent risks from falling or ejected objects.

#### 1.3.4. Risks due to surfaces, edges or angles

Insofar as their purpose allows, accessible parts of the machinery must have no sharp edges, no sharp angles and no rough surfaces likely to cause injury.

#### 1.3.5. Risks related to combined machinery

Where the machinery is intended to carry out several different operations with manual removal of the piece between each operation (combined machinery), it must be designed and constructed in such a way as to enable each element to be used separately without the other elements constituting a risk for exposed persons.

For this purpose, it must be possible to start and stop separately any elements that are not protected.

#### 1.3.6. Risks related to variations in operating conditions

Where the machinery performs operations under different conditions of use, it must be designed and constructed in such a way that selection and adjustment of these conditions can be carried out safely and reliably.

#### 1.3.7. Risks related to moving parts

The moving parts of machinery must be designed and constructed in such a way as to prevent risks of contact which could lead to accidents or must, where risks persist, be fitted with guards or protective devices.

All necessary steps must be taken to prevent accidental blockage of moving parts involved in the work. In cases where, despite the precautions taken, a blockage is likely to occur, the necessary specific protective devices and tools must, when appropriate, be provided to enable the equipment to be safely unblocked.

The instructions and, where possible, a sign on the machinery shall identify these specific protective devices and how they are to be used.

#### 1.3.8. Choice of protection against risks arising from moving parts

Guards or protective devices designed to protect against risks arising from moving parts must be selected on the basis of the type of risk. The following guidelines must be used to help to make the choice.

#### 1.3.8.1. Moving transmission parts

Guards designed to protect persons against the hazards generated by moving transmission parts must be:

- — either fixed guards as referred to in section 1.4.2.1, or

- — interlocking movable guards as referred to in section 1.4.2.2.

Interlocking movable guards should be used where frequent access is envisaged.

#### 1.3.8.2. Moving parts involved in the process

Guards or protective devices designed to protect persons against the hazards generated by moving parts involved in the process must be:

- — either fixed guards as referred to in section 1.4.2.1, or

- — interlocking movable guards as referred to in section 1.4.2.2, or

- — protective devices as referred to in section 1.4.3, or

- — a combination of the above.

However, when certain moving parts directly involved in the process cannot be made completely inaccessible during operation owing to operations requiring operator intervention, such parts must be fitted with:

- — fixed guards or interlocking movable guards preventing access to those sections of the parts that are not used in the work, and

- — adjustable guards as referred to in section 1.4.2.3 restricting access to those sections of the moving parts where access is necessary.

#### 1.3.9. Risks of uncontrolled movements

When a part of the machinery has been stopped, any drift away from the stopping position, for whatever reason other than action on the control devices, must be prevented or must be such that it does not present a hazard.

#### 1.4. REQUIRED CHARACTERISTICS OF GUARDS AND PROTECTIVE DEVICES

#### 1.4.1. General requirements

Guards and protective devices must:

- — be of robust construction,

- — be securely held in place,

- — not give rise to any additional hazard,

- — not be easy to by-pass or render non-operational,

- — be located at an adequate distance from the danger zone,

- — cause minimum obstruction to the view of the production process, and

- — enable essential work to be carried out on the installation and/or replacement of tools and for maintenance purposes by restricting access exclusively to the area where the work has to be done, if possible without the guard having to be removed or the protective device having to be disabled.

In addition, guards must, where possible, protect against the ejection or falling of materials or objects and against emissions generated by the machinery.

#### 1.4.2. Special requirements for guards

#### 1.4.2.1. Fixed guards

Fixed guards must be fixed by systems that can be opened or removed only with tools.

Their fixing systems must remain attached to the guards or to the machinery when the guards are removed.

Where possible, guards must be incapable of remaining in place without their fixings.

#### 1.4.2.2. Interlocking movable guards

Interlocking movable guards must:

- — as far as possible remain attached to the machinery when open,

- — be designed and constructed in such a way that they can be adjusted only by means of an intentional action.

Interlocking movable guards must be associated with an interlocking device that:

- — prevents the start of hazardous machinery functions until they are closed and

- — gives a stop command whenever they are no longer closed.

Where it is possible for an operator to reach the danger zone before the risk due to the hazardous machinery functions has ceased, movable guards must be associated with a guard locking device in addition to an interlocking device that:

- — prevents the start of hazardous machinery functions until the guard is closed and locked, and

- — keeps the guard closed and locked until the risk of injury from the hazardous machinery functions has ceased.

Interlocking movable guards must be designed in such a way that the absence or failure of one of their components prevents starting or stops the hazardous machinery functions.

#### 1.4.2.3. Adjustable guards restricting access

Adjustable guards restricting access to those areas of the moving parts strictly necessary for the work must be:

- — adjustable manually or automatically, depending on the type of work involved, and

- — readily adjustable without the use of tools.

#### 1.4.3. Special requirements for protective devices

Protective devices must be designed and incorporated into the control system in such a way that:

- — moving parts cannot start up while they are within the operator's reach,

- — persons cannot reach moving parts while the parts are moving, and

- — the absence or failure of one of their components prevents starting or stops the moving parts.

Protective devices must be adjustable only by means of an intentional action.

#### 1.5. RISKS DUE TO OTHER HAZARDS

#### 1.5.1. Electricity supply

Where machinery has an electricity supply, it must be designed, constructed and equipped in such a way that all hazards of an electrical nature are or can be prevented.

The safety objectives set out in Directive 73/23/EEC shall apply to machinery. However, the obligations concerning conformity assessment and the placing on the market and/or putting into service of machinery with regard to electrical hazards are governed solely by this Directive.

#### 1.5.2. Static electricity

Machinery must be designed and constructed to prevent or limit the build-up of potentially dangerous electrostatic charges and/or be fitted with a discharging system.

#### 1.5.3. Energy supply other than electricity

Where machinery is powered by source of energy other than electricity, it must be so designed, constructed and equipped as to avoid all potential risks associated with such sources of energy.

#### 1.5.4. Errors of fitting

Errors likely to be made when fitting or refitting certain parts which could be a source of risk must be made impossible by the design and construction of such parts or, failing this, by information given on the parts themselves and/or their housings. The same information must be given on moving parts and/or their housings where the direction of movement needs to be known in order to avoid a risk.

Where necessary, the instructions must give further information on these risks.

Where a faulty connection can be the source of risk, incorrect connections must be made impossible by design or, failing this, by information given on the elements to be connected and, where appropriate, on the means of connection.

#### 1.5.5. Extreme temperatures

Steps must be taken to eliminate any risk of injury arising from contact with or proximity to machinery parts or materials at high or very low temperatures.

The necessary steps must also be taken to avoid or protect against the risk of hot or very cold material being ejected.

#### 1.5.6. Fire

Machinery must be designed and constructed in such a way as to avoid any risk of fire or overheating posed by the machinery itself or by gases, liquids, dust, vapours or other substances produced or used by the machinery.

#### 1.5.7. Explosion

Machinery must be designed and constructed in such a way as to avoid any risk of explosion posed by the machinery itself or by gases, liquids, dust, vapours or other substances produced or used by the machinery.

Machinery must comply, as far as the risk of explosion due to its use in a potentially explosive atmosphere is concerned, with the provisions of the specific Community Directives.

#### 1.5.8. Noise

Machinery must be designed and constructed in such a way that risks resulting from the emission of airborne noise are reduced to the lowest level, taking account of technical progress and the availability of means of reducing noise, in particular at source.

The level of noise emission may be assessed with reference to comparative emission data for similar machinery.

#### 1.5.9. Vibrations

Machinery must be designed and constructed in such a way that risks resulting from vibrations produced by the machinery are reduced to the lowest level, taking account of technical progress and the availability of means of reducing vibration, in particular at source.

The level of vibration emission may be assessed with reference to comparative emission data for similar machinery.

#### 1.5.10. Radiation

Undesirable radiation emissions from the machinery must be eliminated or be reduced to levels that do not have adverse effects on persons.

Any functional ionising radiation emissions must be limited to the lowest level which is sufficient for the proper functioning of the machinery during setting, operation and cleaning. Where a risk exists, the necessary protective measures must be taken.

Any functional non-ionising radiation emissions during setting, operation and cleaning must be limited to levels that do not have adverse effects on persons.

#### 1.5.11. External radiation

Machinery must be designed and constructed in such a way that external radiation does not interfere with its operation.

#### 1.5.12. Laser radiation

Where laser equipment is used, the following should be taken into account:

- — laser equipment on machinery must be designed and constructed in such a way as to prevent any accidental radiation,

- — laser equipment on machinery must be protected in such a way that effective radiation, radiation produced by reflection or diffusion and secondary radiation do not damage health,

- — optical equipment for the observation or adjustment of laser equipment on machinery must be such that no health risk is created by laser radiation.

#### 1.5.13. Emissions of hazardous materials and substances

Machinery must be designed and constructed in such a way that risks of inhalation, ingestion, contact with the skin, eyes and mucous membranes and penetration through the skin of hazardous materials and substances which it produces can be avoided.

Where a hazard cannot be eliminated, the machinery must be so equipped that hazardous materials and substances can be contained, evacuated, precipitated by water spraying, filtered or treated by another equally effective method.

Where the process is not totally enclosed during normal operation of the machinery, the devices for containment and/or evacuation must be situated in such a way as to have the maximum effect.

#### 1.5.14. Risk of being trapped in a machine

Machinery must be designed, constructed or fitted with a means of preventing a person from being enclosed within it or, if that is impossible, with a means of summoning help.

#### 1.5.15. Risk of slipping, tripping or falling

Parts of the machinery where persons are liable to move about or stand must be designed and constructed in such a way as to prevent persons slipping, tripping or falling on or off these parts.

Where appropriate, these parts must be fitted with handholds that are fixed relative to the user and that enable them to maintain their stability.

#### 1.5.16. Lightning

Machinery in need of protection against the effects of lightning while being used must be fitted with a system for conducting the resultant electrical charge to earth.

#### 1.6. MAINTENANCE

#### 1.6.1. Machinery maintenance

Adjustment and maintenance points must be located outside danger zones. It must be possible to carry out adjustment, maintenance, repair, cleaning and servicing operations while machinery is at a standstill.

If one or more of the above conditions cannot be satisfied for technical reasons, measures must be taken to ensure that these operations can be carried out safely (see section 1.2.5).

In the case of automated machinery and, where necessary, other machinery, a connecting device for mounting diagnostic fault-finding equipment must be provided.

Automated machinery components which have to be changed frequently must be capable of being removed and replaced easily and safely. Access to the components must enable these tasks to be carried out with the necessary technical means in accordance with a specified operating method.

#### 1.6.2. Access to operating positions and servicing points

Machinery must be designed and constructed in such a way as to allow access in safety to all areas where intervention is necessary during operation, adjustment and maintenance of the machinery.

#### 1.6.3. Isolation of energy sources

Machinery must be fitted with means to isolate it from all energy sources. Such isolators must be clearly identified. They must be capable of being locked if reconnection could endanger persons. Isolators must also be capable of being locked where an operator is unable, from any of the points to which he has access, to check that the energy is still cut off.

In the case of machinery capable of being plugged into an electricity supply, removal of the plug is sufficient, provided that the operator can check from any of the points to which he has access that the plug remains removed.

After the energy is cut off, it must be possible to dissipate normally any energy remaining or stored in the circuits of the machinery without risk to persons.

As an exception to the requirement laid down in the previous paragraphs, certain circuits may remain connected to their energy sources in order, for example, to hold parts, to protect information, to light interiors, etc. In this case, special steps must be taken to ensure operator safety.

#### 1.6.4. Operator intervention

Machinery must be so designed, constructed and equipped that the need for operator intervention is limited. If operator intervention cannot be avoided, it must be possible to carry it out easily and safely.

#### 1.6.5. Cleaning of internal parts

The machinery must be designed and constructed in such a way that it is possible to clean internal parts which have contained dangerous substances or preparations without entering them; any necessary unblocking must also be possible from the outside. If it is impossible to avoid entering the machinery, it must be designed and constructed in such a way as to allow cleaning to take place safely.

#### 1.7. INFORMATION

#### 1.7.1. Information and warnings on the machinery

Information and warnings on the machinery should preferably be provided in the form of readily understandable symbols or pictograms. Any written or verbal information and warnings must be expressed in an official Community language or languages, which may be determined in accordance with the Treaty by the Member State in which the machinery is placed on the market and/or put into service and may be accompanied, on request, by versions in any other official Community language or languages understood by the operators.

#### 1.7.1.1. Information and information devices

The information needed to control machinery must be provided in a form that is unambiguous and easily understood. It must not be excessive to the extent of overloading the operator.

Visual display units or any other interactive means of communication between the operator and the machine must be easily understood and easy to use.

#### 1.7.1.2. Warning devices

Where the health and safety of persons may be endangered by a fault in the operation of unsupervised machinery, the machinery must be equipped in such a way as to give an appropriate acoustic or light signal as a warning.

Where machinery is equipped with warning devices these must be unambiguous and easily perceived. The operator must have facilities to check the operation of such warning devices at all times.

The requirements of the specific Community Directives concerning colours and safety signals must be complied with.

#### 1.7.2. Warning of residual risks

Where risks remain despite the inherent safe design measures, safeguarding and complementary protective measures adopted, the necessary warnings, including warning devices, must be provided.

#### 1.7.3. Marking of machinery

All machinery must be marked visibly, legibly and indelibly with the following minimum particulars:

- — the business name and full address of the manufacturer and, where applicable, his authorised representative,

- — designation of the machinery,

- — the CE Marking (see Annex III),

- — designation of series or type,

- — serial number, if any,

- — the year of construction, that is the year in which the manufacturing process is completed.

It is prohibited to pre-date or post-date the machinery when affixing the CE marking.

Furthermore, machinery designed and constructed for use in a potentially explosive atmosphere must be marked accordingly.

Machinery must also bear full information relevant to its type and essential for safe use. Such information is subject to the requirements set out in section 1.7.1.

Where a machine part must be handled during use with lifting equipment, its mass must be indicated legibly, indelibly and unambiguously.

#### 1.7.4. Instructions

All machinery must be accompanied by instructions in the official Community language or languages of the Member State in which it is placed on the market and/or put into service.

The instructions accompanying the machinery must be either ‘Original instructions’ or a ‘Translation of the original instructions’, in which case the translation must be accompanied by the original instructions.

By way of exception, the maintenance instructions intended for use by specialised personnel mandated by the manufacturer or his authorised representative may be supplied in only one Community language which the specialised personnel understand.

The instructions must be drafted in accordance with the principles set out below.

#### 1.7.4.1. General principles for the drafting of instructions

- (a) The instructions must be drafted in one or more official Community languages. The words ‘Original instructions’ must appear on the language version(s) verified by the manufacturer or his authorised representative.

- (b) Where no ‘Original instructions’ exist in the official language(s) of the country where the machinery is to be used, a translation into that/those language(s) must be provided by the manufacturer or his authorised representative or by the person bringing the machinery into the language area in question. The translations must bear the words ‘Translation of the original instructions’.

- (c) The contents of the instructions must cover not only the intended use of the machinery but also take into account any reasonably foreseeable misuse thereof.

- (d) In the case of machinery intended for use by non-professional operators, the wording and layout of the instructions for use must take into account the level of general education and acumen that can reasonably be expected from such operators.

#### 1.7.4.2. Contents of the instructions

Each instruction manual must contain, where applicable, at least the following information:

- (a) the business name and full address of the manufacturer and of his authorised representative;

- (b) the designation of the machinery as marked on the machinery itself, except for the serial number (see section 1.7.3);

- (c) the EC declaration of conformity, or a document setting out the contents of the EC declaration of conformity, showing the particulars of the machinery, not necessarily including the serial number and the signature;

- (d) a general description of the machinery;

- (e) the drawings, diagrams, descriptions and explanations necessary for the use, maintenance and repair of the machinery and for checking its correct functioning;

- (f) a description of the workstation(s) likely to be occupied by operators;

- (g) a description of the intended use of the machinery;

- (h) warnings concerning ways in which the machinery must not be used that experience has shown might occur;

- (i) assembly, installation and connection instructions, including drawings, diagrams and the means of attachment and the designation of the chassis or installation on which the machinery is to be mounted;

- (j) instructions relating to installation and assembly for reducing noise or vibration;

- (k) instructions for the putting into service and use of the machinery and, if necessary, instructions for the training of operators;

- (l) information about the residual risks that remain despite the inherent safe design measures, safeguarding and complementary protective measures adopted;

- (m) instructions on the protective measures to be taken by the user, including, where appropriate, the personal protective equipment to be provided;

- (n) the essential characteristics of tools which may be fitted to the machinery;

- (o) the conditions in which the machinery meets the requirement of stability during use, transportation, assembly, dismantling when out of service, testing or foreseeable breakdowns;

- (p) instructions with a view to ensuring that transport, handling and storage operations can be made safely, giving the mass of the machinery and of its various parts where these are regularly to be transported separately;

- (q) the operating method to be followed in the event of accident or breakdown; if a blockage is likely to occur, the operating method to be followed so as to enable the equipment to be safely unblocked;

- (r) the description of the adjustment and maintenance operations that should be carried out by the user and the preventive maintenance measures that should be observed;

- (s) instructions designed to enable adjustment and maintenance to be carried out safely, including the protective measures that should be taken during these operations;

- (t) the specifications of the spare parts to be used, when these affect the health and safety of operators;

- (u) the following information on airborne noise emissions:

  - — the A-weighted emission sound pressure level at workstations, where this exceeds 70 dB(A); where this level does not exceed 70 dB(A), this fact must be indicated,

  - — the peak C-weighted instantaneous sound pressure value at workstations, where this exceeds 63 Pa (130 dB in relation to 20 μPa),

  - — the A-weighted sound power level emitted by the machinery, where the A-weighted emission sound pressure level at workstations exceeds 80 dB(A).

  These values must be either those actually measured for the machinery in question or those established on the basis of measurements taken for technically comparable machinery which is representative of the machinery to be produced.

  In the case of very large machinery, instead of the A-weighted sound power level, the A-weighted emission sound pressure levels at specified positions around the machinery may be indicated.

  Where the harmonised standards are not applied, sound levels must be measured using the most appropriate method for the machinery. Whenever sound emission values are indicated the uncertainties surrounding these values must be specified. The operating conditions of the machinery during measurement and the measuring methods used must be described.

  Where the workstation(s) are undefined or cannot be defined, A-weighted sound pressure levels must be measured at a distance of 1 metre from the surface of the machinery and at a height of 1,6 metres from the floor or access platform. The position and value of the maximum sound pressure must be indicated.

  Where specific Community Directives lay down other requirements for the measurement of sound pressure levels or sound power levels, those Directives must be applied and the corresponding provisions of this section shall not apply;

- (v) where machinery is likely to emit non-ionising radiation which may cause harm to persons, in particular persons with active or non-active implantable medical devices, information concerning the radiation emitted for the operator and exposed persons.

#### 1.7.4.3. Sales literature

Sales literature describing the machinery must not contradict the instructions as regards health and safety aspects. Sales literature describing the performance characteristics of machinery must contain the same information on emissions as is contained in the instructions.

#### 2. SUPPLEMENTARY ESSENTIAL HEALTH AND SAFETY REQUIREMENTS FOR CERTAIN CATEGORIES OF MACHINERY

▼M2

Foodstuffs machinery, machinery for cosmetics or pharmaceutical products, hand-held and/or hand-guided machinery, portable fixing and other impact machinery, machinery for working wood and material with similar physical characteristics and machinery for pesticide application must meet all the essential health and safety requirements set out in this chapter (see General Principles, point 4).

▼B

#### 2.1. FOODSTUFFS MACHINERY AND MACHINERY FOR COSMETICS OR PHARMACEUTICAL PRODUCTS

#### 2.1.1. General

Machinery intended for use with foodstuffs or with cosmetics or pharmaceutical products must be designed and constructed in such a way as to avoid any risk of infection, sickness or contagion.

The following requirements must be observed:

- (a) materials in contact with, or intended to come into contact with, foodstuffs or cosmetics or pharmaceutical products must satisfy the conditions set down in the relevant Directives. The machinery must be designed and constructed in such a way that these materials can be cleaned before each use. Where this is not possible disposable parts must be used;

- (b) all surfaces in contact with foodstuffs or cosmetics or pharmaceutical products, other than surfaces of disposable parts, must:

  - — be smooth and have neither ridges nor crevices which could harbour organic materials. The same applies to their joinings,

  - — be designed and constructed in such a way as to reduce the projections, edges and recesses of assemblies to a minimum,

  - — be easily cleaned and disinfected, where necessary after removing easily dismantled parts; the inside surfaces must have curves with a radius sufficient to allow thorough cleaning;

- (c) it must be possible for liquids, gases and aerosols deriving from foodstuffs, cosmetics or pharmaceutical products as well as from cleaning, disinfecting and rinsing fluids to be completely discharged from the machinery (if possible, in a ‘cleaning’ position);

- (d) machinery must be designed and constructed in such a way as to prevent any substances or living creatures, in particular insects, from entering, or any organic matter from accumulating in, areas that cannot be cleaned;

- (e) machinery must be designed and constructed in such a way that no ancillary substances hazardous to health, including the lubricants used, can come into contact with foodstuffs, cosmetics or pharmaceutical products. Where necessary, machinery must be designed and constructed in such a way that continuing compliance with this requirement can be checked.

#### 2.1.2. Instructions

The instructions for foodstuffs machinery and machinery for use with cosmetics or pharmaceutical products must indicate recommended products and methods for cleaning, disinfecting and rinsing, not only for easily accessible areas but also for areas to which access is impossible or inadvisable.

#### 2.2. PORTABLE HAND-HELD AND/OR HAND-GUIDED MACHINERY

#### 2.2.1. General

Portable hand-held and/or hand-guided machinery must:

- — depending on the type of machinery, have a supporting surface of sufficient size and have a sufficient number of handles and supports of an appropriate size, arranged in such a way as to ensure the stability of the machinery under the intended operating conditions,

- — except where technically impossible, or where there is an independent control device, in the case of handles which cannot be released in complete safety, be fitted with manual start and stop control devices arranged in such a way that the operator can operate them without releasing the handles,

- — present no risks of accidental starting and/or continued operation after the operator has released the handles. Equivalent steps must be taken if this requirement is not technically feasible,

- — permit, where necessary, visual observation of the danger zone and of the action of the tool with the material being processed.

The handles of portable machinery must be designed and constructed in such a way as to make starting and stopping straightforward.

#### 2.2.1.1. Instructions

The instructions must give the following information concerning vibrations transmitted by portable hand-held and hand-guided machinery:

- — the vibration total value to which the hand-arm system is subjected, if it exceeds 2,5 m/s2. Where this value does not exceed 2,5 m/s2, this must be mentioned,

- — the uncertainty of measurement.

These values must be either those actually measured for the machinery in question or those established on the basis of measurements taken for technically comparable machinery which is representative of the machinery to be produced.

If harmonised standards are not applied, the vibration data must be measured using the most appropriate measurement code for the machinery.

The operating conditions during measurement and the methods used for measurement, or the reference of the harmonised standard applied, must be specified.

#### 2.2.2. Portable fixing and other impact machinery

#### 2.2.2.1. General

Portable fixing and other impact machinery must be designed and constructed in such a way that:

- — energy is transmitted to the impacted element by the intermediary component that does not leave the device,

- — an enabling device prevents impact unless the machinery is positioned correctly with adequate pressure on the base material,

- — involuntary triggering is prevented; where necessary, an appropriate sequence of actions on the enabling device and the control device must be required to trigger an impact,

- — accidental triggering is prevented during handling or in case of shock,

- — loading and unloading operations can be carried out easily and safely.

Where necessary, it must be possible to fit the device with splinter guard(s) and the appropriate guard(s) must be provided by the manufacturer of the machinery.

#### 2.2.2.2. Instructions

The instructions must give the necessary information regarding:

- — the accessories and interchangeable equipment that can be used with the machinery,

- — the suitable fixing or other impacted elements to be used with the machinery,

- — where appropriate, the suitable cartridges to be used.

#### 2.3. MACHINERY FOR WORKING WOOD AND MATERIAL WITH SIMILAR PHYSICAL CHARACTERISTICS

Machinery for working wood and materials with similar physical characteristics must comply with the following requirements:

- (a) the machinery must be designed, constructed or equipped in such a way that the piece being machined can be placed and guided in safety; where the piece is hand-held on a work-bench, the latter must be sufficiently stable during the work and must not impede the movement of the piece;

- (b) where the machinery is likely to be used in conditions involving the risk of ejection of workpieces or parts of them, it must be designed, constructed, or equipped in such a way as to prevent such ejection, or, if this is not possible, so that the ejection does not engender risks for the operator and/or exposed persons;

- (c) the machinery must be equipped with an automatic brake that stops the tool in a sufficiently short time if there is a risk of contact with the tool whilst it runs down;

- (d) where the tool is incorporated into a non-fully automated machine, the latter must be designed and constructed in such a way as to eliminate or reduce the risk of accidental injury.

▼M2

#### 2.4. MACHINERY FOR PESTICIDE APPLICATION

#### 2.4.1. Definition

‘Machinery for pesticide application’ means machinery specifically intended for the application of plant protection products within the meaning of Article 2(1) of Regulation (EC) No 1107/2009 of the European Parliament and of the Council of 21 October 2009 concerning the placing of plant protection products on the market ^(10).

#### 2.4.2. General

The manufacturer of machinery for pesticide application or his authorised representative must ensure that an assessment is carried out of the risks of unintended exposure of the environment to pesticides, in accordance with the process of risk assessment and risk reduction referred to in the General Principles, point 1.

Machinery for pesticide application must be designed and constructed taking into account the results of the risk assessment referred to in the first paragraph so that the machinery can be operated, adjusted and maintained without unintended exposure of the environment to pesticides.

Leakage must be prevented at all times.

#### 2.4.3. Controls and monitoring

It must be possible to easily and accurately control, monitor and immediately stop the pesticide application from the operating positions.

#### 2.4.4. Filling and emptying

The machinery must be designed and constructed to facilitate precise filling with the necessary quantity of pesticide and to ensure easy and complete emptying, while preventing spillage of pesticide and avoiding the contamination of the water source during such operations.

#### 2.4.5. Application of pesticides

#### 2.4.5.1. Application rate

The machinery must be fitted with means of adjusting the application rate easily, accurately and reliably.

#### 2.4.5.2. Distribution, deposition and drift of pesticide

The machinery must be designed and constructed to ensure that pesticide is deposited on target areas, to minimise losses to other areas and to prevent drift of pesticide to the environment. Where appropriate, an even distribution and homogeneous deposition must be ensured.

#### 2.4.5.3. Tests

In order to verify that the relevant parts of the machinery comply with the requirements set out in sections 2.4.5.1 and 2.4.5.2 the manufacturer or his authorised representative must, for each type of machinery concerned, perform appropriate tests, or have such tests performed.

#### 2.4.5.4. Losses during stoppage

The machinery must be designed and constructed to prevent losses while the pesticide application function is stopped.

#### 2.4.6. Maintenance

#### 2.4.6.1. Cleaning

The machinery must be designed and constructed to allow its easy and thorough cleaning without contamination of the environment.

#### 2.4.6.2. Servicing

The machinery must be designed and constructed to facilitate the changing of worn parts without contamination of the environment.

#### 2.4.7. Inspections

It must be possible to easily connect the necessary measuring instruments to the machinery to check the correct functioning of the machinery.

#### 2.4.8. Marking of nozzles, strainers and filters

Nozzles, strainers and filters must be marked so that their type and size can be clearly identified.

#### 2.4.9. Indication of pesticide in use

Where appropriate, the machinery must be fitted with a specific mounting on which the operator can place the name of the pesticide in use.

#### 2.4.10. Instructions

The instructions must provide the following information:

- (a) precautions to be taken during mixing, loading, application, emptying, cleaning, servicing and transport operations in order to avoid contamination of the environment;

- (b) detailed conditions of use for the different operating environments envisaged, including the corresponding preparation and adjustments required to ensure the deposition of pesticide on target areas while minimising losses to other areas, to prevent drift to the environment and, where appropriate, to ensure an even distribution and homogeneous deposition of pesticide;

- (c) the range of types and sizes of nozzles, strainers and filters that can be used with the machinery;

- (d) the frequency of checks and the criteria and method for the replacement of parts subject to wear that affect the correct functioning of the machinery, such as nozzles, strainers and filters;

- (e) specification of calibration, daily maintenance, winter preparation and other checks necessary to ensure the correct functioning of the machinery;

- (f) types of pesticides that may cause incorrect functioning of the machinery;

- (g) an indication that the operator should keep updated the name of the pesticide in use on the specific mounting referred to in section 2.4.9;

- (h) the connexion and use of any special equipment or accessories, and the necessary precautions to be taken;

- (i) an indication that the machinery may be subject to national requirements for regular inspection by designated bodies, as provided for in Directive 2009/128/EC of the European Parliament and of the Council of 21 October 2009 establishing a framework for Community action to achieve the sustainable use of pesticides ^(11);

- (j) the features of the machinery which must be inspected to ensure its correct functioning;

- (k) instructions for connecting the necessary measuring instruments.

▼B

#### 3. SUPPLEMENTARY ESSENTIAL HEALTH AND SAFETY REQUIREMENTS TO OFFSET HAZARDS DUE TO THE MOBILITY OF MACHINERY

Machinery presenting hazards due to its mobility must meet all the essential health and safety requirements described in this chapter (see General Principles, point 4).

#### 3.1. GENERAL

#### 3.1.1. Definitions

- (a) ‘Machinery presenting hazards due to its mobility’ means

  - — machinery the operation of which requires either mobility while working, or continuous or semi-continuous movement between a succession of fixed working locations, or

  - — machinery which is operated without being moved, but which may be equipped in such a way as to enable it to be moved more easily from one place to another.

- (b) ‘Driver’ means an operator responsible for the movement of a machine. The driver may be transported by the machinery or may be on foot, accompanying the machinery, or may guide the machinery by remote control.

#### 3.2. WORK POSITIONS

#### 3.2.1. Driving position

Visibility from the driving position must be such that the driver can, in complete safety for himself and the exposed persons, operate the machinery and its tools in their foreseeable conditions of use. Where necessary, appropriate devices must be provided to remedy hazards due to inadequate direct vision.

Machinery on which the driver is transported must be designed and constructed in such a way that, from the driving positions, there is no risk to the driver from inadvertent contact with the wheels and tracks.

The driving position of ride-on drivers must be designed and constructed in such a way that a driver's cab may be fitted, provided this does not increase the risk and there is room for it. The cab must incorporate a place for the instructions needed for the driver.

#### 3.2.2. Seating

Where there is a risk that operators or other persons transported by the machinery may be crushed between parts of the machinery and the ground should the machinery roll or tip over, in particular for machinery equipped with a protective structure referred to in section 3.4.3 or 3.4.4, their seats must be designed or equipped with a restraint system so as to keep the persons in their seats, without restricting movements necessary for operations or movements relative to the structure caused by the suspension of the seats. Such restraint systems should not be fitted if they increase the risk.

#### 3.2.3. Positions for other persons

If the conditions of use provide that persons other than the driver may occasionally or regularly be transported by the machinery or work on it, appropriate positions must be provided which enable them to be transported or to work on it without risk.

The second and third paragraphs of section 3.2.1 also apply to the places provided for persons other than the driver.

#### 3.3. CONTROL SYSTEMS

If necessary, steps must be taken to prevent unauthorised use of controls.

In the case of remote controls, each control unit must clearly identify the machinery to be controlled from that unit.

The remote control system must be designed and constructed in such a way as to affect only:

- — the machinery in question,

- — the functions in question.

Remote controlled machinery must be designed and constructed in such a way that it will respond only to signals from the intended control units.

#### 3.3.1. Control devices

The driver must be able to actuate all control devices required to operate the machinery from the driving position, except for functions which can be safely actuated only by using control devices located elsewhere. These functions include, in particular, those for which operators other than the driver are responsible or for which the driver has to leave the driving position in order to control them safely.

Where there are pedals, they must be so designed, constructed and fitted as to allow safe operation by the driver with the minimum risk of incorrect operation. They must have a slip-resistant surface and be easy to clean.

Where their operation can lead to hazards, notably dangerous movements, the control devices, except for those with preset positions, must return to the neutral position as soon as they are released by the operator.

In the case of wheeled machinery, the steering system must be designed and constructed in such a way as to reduce the force of sudden movements of the steering wheel or the steering lever caused by shocks to the guide wheels.

Any control that locks the differential must be so designed and arranged that it allows the differential to be unlocked when the machinery is moving.

The sixth paragraph of section 1.2.2, concerning acoustic and/or visual warning signals, applies only in the case of reversing.

#### 3.3.2. Starting/moving

All travel movements of self-propelled machinery with a ride-on driver must be possible only if the driver is at the controls.

Where, for operating purposes, machinery is fitted with devices which exceed its normal clearance zone (e.g. stabilisers, jib, etc.), the driver must be provided with the means of checking easily, before moving the machinery, that such devices are in a particular position which allows safe movement.

This also applies to all other parts which, to allow safe movement, have to be in particular positions, locked if necessary.

Where it does not give rise to other risks, movement of the machinery must depend on safe positioning of the aforementioned parts.

It must not be possible for unintentional movement of the machinery to occur while the engine is being started.

#### 3.3.3. Travelling function

Without prejudice to road traffic regulations, self-propelled machinery and its trailers must meet the requirements for slowing down, stopping, braking and immobilisation so as to ensure safety under all the operating, load, speed, ground and gradient conditions allowed for.

The driver must be able to slow down and stop self-propelled machinery by means of a main device. Where safety so requires, in the event of a failure of the main device, or in the absence of the energy supply needed to actuate the main device, an emergency device with a fully independent and easily accessible control device must be provided for slowing down and stopping.

Where safety so requires, a parking device must be provided to render stationary machinery immobile. This device may be combined with one of the devices referred to in the second paragraph, provided that it is purely mechanical.

Remote-controlled machinery must be equipped with devices for stopping operation automatically and immediately and for preventing potentially dangerous operation in the following situations:

- — if the driver loses control,

- — if it receives a stop signal,

- — if a fault is detected in a safety-related part of the system,

- — if no validation signal is detected within a specified time.

Section 1.2.4 does not apply to the travelling function.

#### 3.3.4. Movement of pedestrian-controlled machinery

Movement of pedestrian-controlled self-propelled machinery must be possible only through sustained action on the relevant control device by the driver. In particular, it must not be possible for movement to occur while the engine is being started.

The control systems for pedestrian-controlled machinery must be designed in such a way as to minimise the risks arising from inadvertent movement of the machine towards the driver, in particular:

- — crushing,

- — injury from rotating tools.

The speed of travel of the machinery must be compatible with the pace of a driver on foot.

In the case of machinery on which a rotary tool may be fitted, it must not be possible to actuate the tool when the reverse control is engaged, except where the movement of the machinery results from movement of the tool. In the latter case, the reversing speed must be such that it does not endanger the driver.

#### 3.3.5. Control circuit failure

A failure in the power supply to the power-assisted steering, where fitted, must not prevent machinery from being steered during the time required to stop it.

#### 3.4. PROTECTION AGAINST MECHANICAL HAZARDS

#### 3.4.1. Uncontrolled movements

Machinery must be designed, constructed and where appropriate placed on its mobile support in such a way as to ensure that, when moved, uncontrolled oscillations of its centre of gravity do not affect its stability or exert excessive strain on its structure.

#### 3.4.2. Moving transmission parts

By way of exception to section 1.3.8.1, in the case of engines, moveable guards preventing access to the moving parts in the engine compartment need not have interlocking devices if they have to be opened either by the use of a tool or key or by a control located in the driving position, providing the latter is in a fully enclosed cab with a lock to prevent unauthorised access.

#### 3.4.3. Roll-over and tip-over

Where, in the case of self-propelled machinery with a ride-on driver, operator(s) or other person(s), there is a risk of rolling or tipping over, the machinery must be fitted with an appropriate protective structure, unless this increases the risk.

This structure must be such that in the event of rolling or tipping over it affords the ride-on person(s) an adequate deflection-limiting volume.

In order to verify that the structure complies with the requirement laid down in the second paragraph, the manufacturer or his authorised representative must, for each type of structure concerned, perform appropriate tests or have such tests performed.

#### 3.4.4. Falling objects

Where, in the case of self-propelled machinery with a ride-on driver, operator(s) or other person(s), there is a risk due to falling objects or material, the machinery must be designed and constructed in such a way as to take account of this risk and fitted, if its size allows, with an appropriate protective structure.

This structure must be such that, in the event of falling objects or material, it guarantees the ride-on person(s) an adequate deflection-limiting volume.

In order to verify that the structure complies with the requirement laid down in the second paragraph, the manufacturer or his authorised representative must, for each type of structure concerned, perform appropriate tests or have such tests performed.

#### 3.4.5. Means of access

Handholds and steps must be designed, constructed and arranged in such a way that the operators use them instinctively and do not use the control devices to assist access.

#### 3.4.6. Towing devices

All machinery used to tow or to be towed must be fitted with towing or coupling devices designed, constructed and arranged in such a way as to ensure easy and secure connection and disconnection and to prevent accidental disconnection during use.

Insofar as the tow bar load so requires, such machinery must be equipped with a support with a bearing surface suited to the load and the ground.

#### 3.4.7. Transmission of power between self-propelled machinery (or tractor) and recipient machinery

Removable mechanical transmission devices linking self-propelled machinery (or a tractor) to the first fixed bearing of recipient machinery must be designed and constructed in such a way that any part that moves during operation is protected over its whole length.

On the side of the self-propelled machinery (or tractor), the power take-off to which the removable mechanical transmission device is attached must be protected either by a guard fixed and linked to the self-propelled machinery (or tractor) or by any other device offering equivalent protection.

It must be possible to open this guard for access to the removable transmission device. Once it is in place, there must be enough room to prevent the drive shaft damaging the guard when the machinery (or the tractor) is moving.

On the recipient machinery side, the input shaft must be enclosed in a protective casing fixed to the machinery.

Torque limiters or freewheels may be fitted to universal joint transmissions only on the side adjoining the driven machinery. The removable mechanical transmission device must be marked accordingly.

All recipient machinery, the operation of which requires a removable mechanical transmission device to connect it to self-propelled machinery (or a tractor), must have a system for attaching the removable mechanical transmission device so that, when the machinery is uncoupled, the removable mechanical transmission device and its guard are not damaged by contact with the ground or part of the machinery.

The outside parts of the guard must be so designed, constructed and arranged that they cannot turn with the removable mechanical transmission device. The guard must cover the transmission to the ends of the inner jaws in the case of simple universal joints and at least to the centre of the outer joint or joints in the case of wide-angle universal joints.

If means of access to working positions are provided near to the removable mechanical transmission device, they must be designed and constructed in such a way that the shaft guards cannot be used as steps, unless designed and constructed for that purpose.

#### 3.5. PROTECTION AGAINST OTHER HAZARDS

#### 3.5.1. Batteries

The battery housing must be designed and constructed in such a way as to prevent the electrolyte being ejected on to the operator in the event of rollover or tipover and to avoid the accumulation of vapours in places occupied by operators.

Machinery must be designed and constructed in such a way that the battery can be disconnected with the aid of an easily accessible device provided for that purpose.

#### 3.5.2. Fire

Depending on the hazards anticipated by the manufacturer, machinery must, where its size permits:

- — either allow easily accessible fire extinguishers to be fitted, or

- — be provided with built-in extinguisher systems.

#### 3.5.3. Emissions of hazardous substances

The second and third paragraphs of section 1.5.13 do not apply where the main function of the machinery is the spraying of products. However, the operator must be protected against the risk of exposure to such hazardous emissions.

#### 3.6. INFORMATION AND INDICATIONS

#### 3.6.1. Signs, signals and warnings

All machinery must have signs and/or instruction plates concerning use, adjustment and maintenance, wherever necessary, so as to ensure the health and safety of persons. They must be chosen, designed and constructed in such a way as to be clearly visible and indelible.

Without prejudice to the provisions of road traffic regulations, machinery with a ride-on driver must have the following equipment:

- — an acoustic warning device to alert persons,

- — a system of light signals relevant to the intended conditions of use; the latter requirement does not apply to machinery intended solely for underground working and having no electrical power,

- — where necessary, there must be an appropriate connection between a trailer and the machinery for the operation of signals.

Remote-controlled machinery which, under normal conditions of use, exposes persons to the risk of impact or crushing must be fitted with appropriate means to signal its movements or with means to protect persons against such risks. The same applies to machinery which involves, when in use, the constant repetition of a forward and backward movement on a single axis where the area to the rear of the machine is not directly visible to the driver.

Machinery must be constructed in such a way that the warning and signalling devices cannot be disabled unintentionally. Where it is essential for safety, such devices must be provided with the means to check that they are in good working order and their failure must be made apparent to the operator.

Where the movement of machinery or its tools is particularly hazardous, signs on the machinery must be provided to warn against approaching the machinery while it is working; the signs must be legible at a sufficient distance to ensure the safety of persons who have to be in the vicinity.

#### 3.6.2. Marking

The following must be shown legibly and indelibly on all machinery:

- — nominal power expressed in kilowatts (kW),

- — mass of the most usual configuration, in kilograms (kg);

and, where appropriate:

- — maximum drawbar pull provided for at the coupling hook, in Newtons (N),

- — maximum vertical load provided for on the coupling hook, in Newtons (N).

#### 3.6.3. Instructions

#### 3.6.3.1. Vibrations

The instructions must give the following information concerning vibrations transmitted by the machinery to the hand-arm system or to the whole body:

- — the vibration total value to which the hand-arm system is subjected, if it exceeds 2,5 m/s2. Where this value does not exceed 2,5 m/s2, this must be mentioned,

- — the highest root mean square value of weighted acceleration to which the whole body is subjected, if it exceeds 0,5 m/s2. Where this value does not exceed 0,5 m/s2, this must be mentioned,

- — the uncertainty of measurement.

These values must be either those actually measured for the machinery in question or those established on the basis of measurements taken for technically comparable machinery which is representative of the machinery to be produced.

Where harmonised standards are not applied, the vibration must be measured using the most appropriate measurement code for the machinery concerned.

The operating conditions during measurement and the measurement codes used must be described.

#### 3.6.3.2. Multiple uses

The instructions for machinery allowing several uses depending on the equipment used and the instructions for the interchangeable equipment must contain the information necessary for safe assembly and use of the basic machinery and the interchangeable equipment that can be fitted.

#### 4. SUPPLEMENTARY ESSENTIAL HEALTH AND SAFETY REQUIREMENTS TO OFFSET HAZARDS DUE TO LIFTING OPERATIONS

Machinery presenting hazards due to lifting operations must meet all the relevant essential health and safety requirements described in this chapter (see General Principles, point 4).

#### 4.1. GENERAL

#### 4.1.1. Definitions

- (a) ‘Lifting operation’ means a movement of unit loads consisting of goods and/or persons necessitating, at a given moment, a change of level.

- (b) ‘Guided load’ means a load where the total movement is made along rigid or flexible guides whose position is determined by fixed points.

- (c) ‘Working coefficient’ means the arithmetic ratio between the load guaranteed by the manufacturer or his authorised representative up to which a component is able to hold it and the maximum working load marked on the component.

- (d) ‘Test coefficient’ means the arithmetic ratio between the load used to carry out the static or dynamic tests on lifting machinery or a lifting accessory and the maximum working load marked on the lifting machinery or lifting accessory.

- (e) ‘Static test’ means the test during which lifting machinery or a lifting accessory is first inspected and subjected to a force corresponding to the maximum working load multiplied by the appropriate static test coefficient and then re-inspected once the said load has been released to ensure that no damage has occurred.

- (f) ‘Dynamic test’ means the test during which lifting machinery is operated in all its possible configurations at the maximum working load multiplied by the appropriate dynamic test coefficient with account being taken of the dynamic behaviour of the lifting machinery in order to check that it functions properly.

- (g) ‘Carrier’ means a part of the machinery on or in which persons and/or goods are supported in order to be lifted.

#### 4.1.2. Protection against mechanical hazards

#### 4.1.2.1. Risks due to lack of stability

Machinery must be designed and constructed in such a way that the stability required by section 1.3.1 is maintained both in service and out of service, including all stages of transportation, assembly and dismantling, during foreseeable component failures and also during the tests carried out in accordance with the instruction handbook. To that end, the manufacturer or his authorised representative must use the appropriate verification methods.

#### 4.1.2.2. Machinery running on guide rails and rail tracks

Machinery must be provided with devices which act on the guide rails or tracks to prevent derailment.

If, despite such devices, there remains a risk of derailment or of failure of a rail or of a running component, devices must be provided which prevent the equipment, component or load from falling or the machinery from overturning.

#### 4.1.2.3. Mechanical strength

Machinery, lifting accessories and their components must be capable of withstanding the stresses to which they are subjected, both in and, where applicable, out of use, under the installation and operating conditions provided for and in all relevant configurations, with due regard, where appropriate, to the effects of atmospheric factors and forces exerted by persons. This requirement must also be satisfied during transport, assembly and dismantling.

Machinery and lifting accessories must be designed and constructed in such a way as to prevent failure from fatigue and wear, taking due account of their intended use.

The materials used must be chosen on the basis of the intended working environments, with particular regard to corrosion, abrasion, impacts, extreme temperatures, fatigue, brittleness and ageing.

Machinery and lifting accessories must be designed and constructed in such a way as to withstand the overload in the static tests without permanent deformation or patent defect. Strength calculations must take account of the value of the static test coefficient chosen to guarantee an adequate level of safety. That coefficient has, as a general rule, the following values:

- (a) manually-operated machinery and lifting accessories: 1,5;

- (b) other machinery: 1,25.

Machinery must be designed and constructed in such a way as to undergo, without failure, the dynamic tests carried out using the maximum working load multiplied by the dynamic test coefficient. This dynamic test coefficient is chosen so as to guarantee an adequate level of safety: the coefficient is, as a general rule, equal to 1,1. As a general rule, the tests will be performed at the nominal speeds provided for. Should the control circuit of the machinery allow for a number of simultaneous movements, the tests must be carried out under the least favourable conditions, as a general rule by combining the movements concerned.

#### 4.1.2.4. Pulleys, drums, wheels, ropes and chains

Pulleys, drums and wheels must have a diameter commensurate with the size of the ropes or chains with which they can be fitted.

Drums and wheels must be designed, constructed and installed in such a way that the ropes or chains with which they are equipped can be wound without coming off.

Ropes used directly for lifting or supporting the load must not include any splicing other than at their ends. Splicings are, however, tolerated in installations which are intended by design to be modified regularly according to needs of use.

Complete ropes and their endings must have a working coefficient chosen in such a way as to guarantee an adequate level of safety. As a general rule, this coefficient is equal to 5.

Lifting chains must have a working coefficient chosen in such a way as to guarantee an adequate level of safety. As a general rule, this coefficient is equal to 4.

In order to verify that an adequate working coefficient has been attained, the manufacturer or his authorised representative must, for each type of chain and rope used directly for lifting the load and for the rope ends, perform the appropriate tests or have such tests performed.

#### 4.1.2.5. Lifting accessories and their components

Lifting accessories and their components must be sized with due regard to fatigue and ageing processes for a number of operating cycles consistent with their expected life-span as specified in the operating conditions for a given application.

Moreover:

- (a) the working coefficient of wire-rope/rope-end combinations must be chosen in such a way as to guarantee an adequate level of safety; this coefficient is, as a general rule, equal to 5. Ropes must not comprise any splices or loops other than at their ends;

- (b) where chains with welded links are used, they must be of the short-link type. The working coefficient of chains must be chosen in such a way as to guarantee an adequate level of safety; this coefficient is, as a general rule, equal to 4;

- (c) the working coefficient for textile ropes or slings is dependent on the material, method of manufacture, dimensions and use. This coefficient must be chosen in such a way as to guarantee an adequate level of safety; it is, as a general rule, equal to 7, provided the materials used are shown to be of very good quality and the method of manufacture is appropriate to the intended use. Should this not be the case, the coefficient is, as a general rule, set at a higher level in order to secure an equivalent level of safety. Textile ropes and slings must not include any knots, connections or splicing other than at the ends of the sling, except in the case of an endless sling;

- (d) all metallic components making up, or used with, a sling must have a working coefficient chosen in such a way as to guarantee an adequate level of safety; this coefficient is, as a general rule, equal to 4;

- (e) the maximum working load of a multilegged sling is determined on the basis of the working coefficient of the weakest leg, the number of legs and a reduction factor which depends on the slinging configuration;

- (f) in order to verify that an adequate working coefficient has been attained, the manufacturer or his authorised representative must, for each type of component referred to in (a), (b), (c) and (d), perform the appropriate tests or have such tests performed.

#### 4.1.2.6. Control of movements

Devices for controlling movements must act in such a way that the machinery on which they are installed is kept safe.

- (a) Machinery must be designed and constructed or fitted with devices in such a way that the amplitude of movement of its components is kept within the specified limits. The operation of such devices must, where appropriate, be preceded by a warning.

- (b) Where several fixed or rail-mounted machines can be manoeuvred simultaneously in the same place, with risks of collision, such machinery must be designed and constructed in such a way as to make it possible to fit systems enabling these risks to be avoided.

- (c) Machinery must be designed and constructed in such a way that the loads cannot creep dangerously or fall freely and unexpectedly, even in the event of partial or total failure of the power supply or when the operator stops operating the machine.

- (d) It must not be possible, under normal operating conditions, to lower the load solely by friction brake, except in the case of machinery whose function requires it to operate in that way.

- (e) Holding devices must be designed and constructed in such a way that inadvertent dropping of the loads is avoided.

#### 4.1.2.7. Movements of loads during handling

The operating position of machinery must be located in such a way as to ensure the widest possible view of trajectories of the moving parts, in order to avoid possible collisions with persons, equipment or other machinery which might be manoeuvring at the same time and liable to constitute a hazard.

Machinery with guided loads must be designed and constructed in such a way as to prevent persons from being injured by movement of the load, the carrier or the counterweights, if any.

#### 4.1.2.8. Machinery serving fixed landings

#### 4.1.2.8.1. Movements of the carrier

The movement of the carrier of machinery serving fixed landings must be rigidly guided to and at the landings. Scissor systems are also regarded as rigid guidance.

#### 4.1.2.8.2. Access to the carrier

Where persons have access to the carrier, the machinery must be designed and constructed in such a way as to ensure that the carrier remains stationary during access, in particular while it is being loaded or unloaded.

The machinery must be designed and constructed in such a way as to ensure that the difference in level between the carrier and the landing being served does not create a risk of tripping.

#### 4.1.2.8.3. Risks due to contact with the moving carrier

Where necessary in order to fulfil the requirement expressed in the second paragraph of section 4.1.2.7, the travel zone must be rendered inaccessible during normal operation.

When, during inspection or maintenance, there is a risk that persons situated under or above the carrier may be crushed between the carrier and any fixed parts, sufficient free space must be provided either by means of physical refuges or by means of mechanical devices blocking the movement of the carrier.

#### 4.1.2.8.4. Risk due to the load falling off the carrier

Where there is a risk due to the load falling off the carrier, the machinery must be designed and constructed in such a way as to prevent this risk.

#### 4.1.2.8.5. Landings

Risks due to contact of persons at landings with the moving carrier or other moving parts must be prevented.

Where there is a risk due to persons falling into the travel zone when the carrier is not present at the landings, guards must be fitted in order to prevent this risk. Such guards must not open in the direction of the travel zone. They must be fitted with an interlocking device controlled by the position of the carrier that prevents:

- — hazardous movements of the carrier until the guards are closed and locked,

- — hazardous opening of a guard until the carrier has stopped at the corresponding landing.

#### 4.1.3. Fitness for purpose

When lifting machinery or lifting accessories are placed on the market or are first put into service, the manufacturer or his authorised representative must ensure, by taking appropriate measures or having them taken, that the machinery or the lifting accessories which are ready for use — whether manually or power-operated — can fulfil their specified functions safely.

The static and dynamic tests referred to in section 4.1.2.3 must be performed on all lifting machinery ready to be put into service.

Where the machinery cannot be assembled in the manufacturer's premises or in the premises of his authorised representative, the appropriate measures must be taken at the place of use. Otherwise, the measures may be taken either in the manufacturer's premises or at the place of use.

#### 4.2. REQUIREMENTS FOR MACHINERY WHOSE POWER SOURCE IS OTHER THAN MANUAL EFFORT

#### 4.2.1. Control of movements

Hold-to-run control devices must be used to control the movements of the machinery or its equipment. However, for partial or complete movements in which there is no risk of the load or the machinery colliding, the said devices may be replaced by control devices authorising automatic stops at pre-selected positions without the operator holding a hold-to-run control device.

#### 4.2.2. Loading control

Machinery with a maximum working load of not less than 1 000 kilograms or an overturning moment of not less than 40 000 Nm must be fitted with devices to warn the driver and prevent dangerous movements in the event:

- — of overloading, either as a result of the maximum working load or the maximum working moment due to the load being exceeded, or

- — of the overturning moment being exceeded.

#### 4.2.3. Installations guided by ropes

Rope carriers, tractors or tractor carriers must be held by counterweights or by a device allowing permanent control of the tension.

#### 4.3. INFORMATION AND MARKINGS

#### 4.3.1. Chains, ropes and webbing

Each length of lifting chain, rope or webbing not forming part of an assembly must bear a mark or, where this is not possible, a plate or irremovable ring bearing the name and address of the manufacturer or his authorised representative and the identifying reference of the relevant certificate.

The certificate mentioned above must show at least the following information:

- (a) the name and address of the manufacturer and, if appropriate, his authorised representative;

- (b) a description of the chain or rope which includes:

  - — its nominal size,

  - — its construction,

  - — the material from which it is made, and

  - — any special metallurgical treatment applied to the material;

- (c) the test method used;

- (d) the maximum load to which the chain or rope should be subjected in service. A range of values may be given on the basis of the intended applications.

#### 4.3.2. Lifting accessories

Lifting accessories must show the following particulars:

- — identification of the material where this information is needed for safe use,

- — the maximum working load.

In the case of lifting accessories on which marking is physically impossible, the particulars referred to in the first paragraph must be displayed on a plate or other equivalent means and securely affixed to the accessory.

The particulars must be legible and located in a place where they are not liable to disappear as a result of wear or jeopardise the strength of the accessory.

#### 4.3.3. Lifting machinery

The maximum working load must be prominently marked on the machinery. This marking must be legible, indelible and in an un-coded form.

Where the maximum working load depends on the configuration of the machinery, each operating position must be provided with a load plate indicating, preferably in diagrammatic form or by means of tables, the working load permitted for each configuration.

Machinery intended for lifting goods only, equipped with a carrier which allows access to persons, must bear a clear and indelible warning prohibiting the lifting of persons. This warning must be visible at each place where access is possible.

#### 4.4. INSTRUCTIONS

#### 4.4.1. Lifting accessories

Each lifting accessory or each commercially indivisible batch of lifting accessories must be accompanied by instructions setting out at least the following particulars:

- (a) the intended use;

- (b) the limits of use (particularly for lifting accessories such as magnetic or vacuum pads which do not fully comply with section 4.1.2.6(e));

- (c) instructions for assembly, use and maintenance;

- (d) the static test coefficient used.

#### 4.4.2. Lifting machinery

Lifting machinery must be accompanied by instructions containing information on:

- (a) the technical characteristics of the machinery, and in particular:

  - — the maximum working load and, where appropriate, a copy of the load plate or load table described in the second paragraph of section 4.3.3,

  - — the reactions at the supports or anchors and, where appropriate, characteristics of the tracks,

  - — where appropriate, the definition and the means of installation of the ballast;

- (b) the contents of the logbook, if the latter is not supplied with the machinery;

- (c) advice for use, particularly to offset the lack of direct vision of the load by the operator;

- (d) where appropriate, a test report detailing the static and dynamic tests carried out by or for the manufacturer or his authorised representative;

- (e) for machinery which is not assembled on the premises of the manufacturer in the form in which it is to be used, the necessary instructions for performing the measures referred to in section 4.1.3 before it is first put into service.

#### 5. SUPPLEMENTARY ESSENTIAL HEALTH AND SAFETY REQUIREMENTS FOR MACHINERY INTENDED FOR UNDERGROUND WORK

Machinery intended for underground work must meet all the essential health and safety requirements described in this chapter (see General Principles, point 4).

#### 5.1. RISKS DUE TO LACK OF STABILITY

Powered roof supports must be designed and constructed in such a way as to maintain a given direction when moving and not slip before and while they come under load and after the load has been removed. They must be equipped with anchorages for the top plates of the individual hydraulic props.

#### 5.2. MOVEMENT

Powered roof supports must allow for unhindered movement of persons.

#### 5.3. CONTROL DEVICES

The accelerator and brake controls for movement of machinery running on rails must be hand-operated. However, enabling devices may be foot-operated.

The control devices of powered roof supports must be designed and positioned in such a way that, during displacement operations, operators are sheltered by a support in place. The control devices must be protected against any accidental release.

#### 5.4. STOPPING

Self-propelled machinery running on rails for use in underground work must be equipped with an enabling device acting on the circuit controlling the movement of the machinery such that movement is stopped if the driver is no longer in control of the movement.

#### 5.5. FIRE

The second indent of section 3.5.2 is mandatory in respect of machinery which comprises highly flammable parts.

The braking system of machinery intended for use in underground workings must be designed and constructed in such a way that it does not produce sparks or cause fires.

Machinery with internal combustion engines for use in underground workings must be fitted only with engines using fuel with a low vaporising pressure and which exclude any spark of electrical origin.

#### 5.6. EXHAUST EMISSIONS

Exhaust emissions from internal combustion engines must not be discharged upwards.

#### 6. SUPPLEMENTARY ESSENTIAL HEALTH AND SAFETY REQUIREMENTS FOR MACHINERY PRESENTING PARTICULAR HAZARDS DUE TO THE LIFTING OF PERSONS

Machinery presenting hazards due to the lifting of persons must meet all the relevant essential health and safety requirements described in this chapter (see General Principles, point 4).

#### 6.1. GENERAL

#### 6.1.1. Mechanical strength

The carrier, including any trapdoors, must be designed and constructed in such a way as to offer the space and strength corresponding to the maximum number of persons permitted on the carrier and the maximum working load.

The working coefficients for components set out in sections 4.1.2.4 and 4.1.2.5 are inadequate for machinery intended for the lifting of persons and must, as a general rule, be doubled. Machinery intended for lifting persons or persons and goods must be fitted with a suspension or supporting system for the carrier designed and constructed in such a way as to ensure an adequate overall level of safety and to prevent the risk of the carrier falling.

If ropes or chains are used to suspend the carrier, as a general rule, at least two independent ropes or chains are required, each with its own anchorage.

#### 6.1.2. Loading control for machinery moved by power other than human strength

The requirements of section 4.2.2 apply regardless of the maximum working load and overturning moment, unless the manufacturer can demonstrate that there is no risk of overloading or overturning.

#### 6.2. CONTROL DEVICES

Where safety requirements do not impose other solutions, the carrier must, as a general rule, be designed and constructed in such a way that persons in the carrier have means of controlling upward and downward movements and, if appropriate, other movements of the carrier.

In operation, those control devices must override any other devices controlling the same movement with the exception of emergency stop devices.

The control devices for these movements must be of the hold-to-run type except where the carrier itself is completely enclosed.

#### 6.3. RISKS TO PERSONS IN OR ON THE CARRIER

#### 6.3.1. Risks due to movements of the carrier

Machinery for lifting persons must be designed, constructed or equipped in such a way that the acceleration or deceleration of the carrier does not engender risks for persons.

#### 6.3.2. Risk of persons falling from the carrier

The carrier must not tilt to an extent which creates a risk of the occupants falling, including when the machinery and carrier are moving.

Where the carrier is designed as a work station, provision must be made to ensure stability and to prevent hazardous movements.

If the measures referred to in section 1.5.15 are not adequate, carriers must be fitted with a sufficient number of suitable anchorage points for the number of persons permitted on the carrier. The anchorage points must be strong enough for the use of personal protective equipment against falls from a height.

Any trapdoor in floors or ceilings or side doors must be designed and constructed in such a way as to prevent inadvertent opening and must open in a direction that obviates any risk of falling, should they open unexpectedly.

#### 6.3.3. Risk due to objects falling on the carrier

Where there is a risk of objects falling on the carrier and endangering persons, the carrier must be equipped with a protective roof.

#### 6.4. MACHINERY SERVING FIXED LANDINGS

#### 6.4.1. Risks to persons in or on the carrier

The carrier must be designed and constructed in such a way as to prevent risks due to contact between persons and/or objects in or on the carrier with any fixed or moving elements. Where necessary in order to fulfil this requirement, the carrier itself must be completely enclosed with doors fitted with an interlocking device that prevents hazardous movements of the carrier unless the doors are closed. The doors must remain closed if the carrier stops between landings where there is a risk of falling from the carrier.

The machinery must be designed, constructed and, where necessary, equipped with devices in such a way as to prevent uncontrolled upward or downward movement of the carrier. These devices must be able to stop the carrier at its maximum working load and at the foreseeable maximum speed.

The stopping action must not cause deceleration harmful to the occupants, whatever the load conditions.

#### 6.4.2. Controls at landings

Controls, other than those for emergency use, at landings must not initiate movements of the carrier when:

- — the control devices in the carrier are being operated,

- — the carrier is not at a landing.

#### 6.4.3. Access to the carrier

The guards at the landings and on the carrier must be designed and constructed in such a way as to ensure safe transfer to and from the carrier, taking into consideration the foreseeable range of goods and persons to be lifted.

#### 6.5. MARKINGS

The carrier must bear the information necessary to ensure safety including:

- — the number of persons permitted on the carrier,

- — the maximum working load.

<a id="annex-ii"></a>
## Annex II – Declarations

### 1. CONTENT

#### A. EC DECLARATION OF CONFORMITY OF THE MACHINERY

This declaration and translations thereof must be drawn up under the same conditions as the instructions (see Annex I, section 1.7.4.1(a) and (b)), and must be typewritten or else handwritten in capital letters.

This declaration relates exclusively to the machinery in the state in which it was placed on the market, and excludes components which are added and/or operations carried out subsequently by the final user.

The EC declaration of conformity must contain the following particulars:

- 1. business name and full address of the manufacturer and, where appropriate, his authorised representative;

- 2. name and address of the person authorised to compile the technical file, who must be established in the Community;

- 3. description and identification of the machinery, including generic denomination, function, model, type, serial number and commercial name;

- 4. a sentence expressly declaring that the machinery fulfils all the relevant provisions of this Directive and where appropriate, a similar sentence declaring the conformity with other Directives and/or relevant provisions with which the machinery complies. These references must be those of the texts published in the Official Journal of the European Union;

- 5. where appropriate, the name, address and identification number of the notified body which carried out the EC type-examination referred to in Annex IX and the number of the EC type-examination certificate;

- 6. where appropriate, the name, address and identification number of the notified body which approved the full quality assurance system referred to in Annex X;

- 7. where appropriate, a reference to the harmonised standards used, as referred to in Article 7(2);

- 8. where appropriate, the reference to other technical standards and specifications used;

- 9. the place and date of the declaration;

- 10. the identity and signature of the person empowered to draw up the declaration on behalf of the manufacturer or his authorised representative.

#### B. DECLARATION OF INCORPORATION OF PARTLY COMPLETED MACHINERY

This declaration and translations thereof must be drawn up under the same conditions as the instructions (see Annex 1, section 1.7.4.1(a) and (b)), and must be typewritten or else handwritten in capital letters.

The declaration of incorporation must contain the following particulars:

- 1. business name and full address of the manufacturer of the partly completed machinery and, where appropriate, his authorised representative;

- 2. name and address of the person authorised to compile the relevant technical documentation, who must be established in the Community;

- 3. description and identification of the partly completed machinery including generic denomination, function, model, type, serial number and commercial name;

- 4. a sentence declaring which essential requirements of this Directive are applied and fulfilled and that the relevant technical documentation is compiled in accordance with part B of Annex VII, and, where appropriate, a sentence declaring the conformity of the partly completed machinery with other relevant Directives. These references must be those of the texts published in the Official Journal of the European Union;

- 5. an undertaking to transmit, in response to a reasoned request by the national authorities, relevant information on the partly completed machinery. This shall include the method of transmission and shall be without prejudice to the intellectual property rights of the manufacturer of the partly completed machinery;

- 6. a statement that the partly completed machinery must not be put into service until the final machinery into which it is to be incorporated has been declared in conformity with the provisions of this Directive, where appropriate;

- 7. the place and date of the declaration;

- 8. the identity and signature of the person empowered to draw up the declaration on behalf of the manufacturer or his authorised representative.

### 2. CUSTODY

The manufacturer of machinery or his authorised representative shall keep the original EC declaration of conformity for a period of at least 10 years from the last date of manufacture of the machinery.

The manufacturer of partly completed machinery or his authorised representative shall keep the original declaration of incorporation for a period of at least 10 years from the last date of manufacture of the partly completed machinery.

<a id="annex-iii"></a>
## Annex III – CE marking

The CE conformity marking shall consist of the initials ‘CE’ taking the following form:

If the CE marking is reduced or enlarged the proportions shown in the above drawing must be respected.

The various components of the CE marking must have substantially the same vertical dimension, which may not be less than 5 mm. The minimum dimension may be waived for small-scale machinery.

The CE marking must be affixed in the immediate vicinity of the name of the manufacturer or his authorised representative, using the same technique.

Where the full quality assurance procedure referred to in Article 12(3)(c) and 12(4)(b) has been applied, the CE marking must be followed by the identification number of the notified body.

<a id="annex-iv"></a>
## Annex IV – Categories of machinery to which one of the procedures referred to in Article 12(3) and (4) must be applied

1. Circular saws (single- or multi-blade) for working with wood and material with similar physical characteristics or for working with meat and material with similar physical characteristics, of the following types:

- 1.1. sawing machinery with fixed blade(s) during cutting, having a fixed bed or support with manual feed of the workpiece or with a demountable power feed;

- 1.2. sawing machinery with fixed blade(s) during cutting, having a manually operated reciprocating saw-bench or carriage;

- 1.3 sawing machinery with fixed blade(s) during cutting, having a built-in mechanical feed device for the workpieces, with manual loading and/or unloading;

- 1.4. sawing machinery with movable blade(s) during cutting, having mechanical movement of the blade, with manual loading and/or unloading.

2. Hand-fed surface planing machinery for woodworking.

3. Thicknessers for one-side dressing having a built-in mechanical feed device, with manual loading and/or unloading for woodworking.

4. Band-saws with manual loading and/or unloading for working with wood and material with similar physical characteristics or for working with meat and material with similar physical characteristics, of the following types:

- 4.1. sawing machinery with fixed blade(s) during cutting, having a fixed or reciprocating-movement bed or support for the workpiece;

- 4.2. sawing machinery with blade(s) assembled on a carriage with reciprocating motion.

5. Combined machinery of the types referred to in points 1 to 4 and in point 7 for working with wood and material with similar physical characteristics.

6. Hand-fed tenoning machinery with several tool holders for woodworking.

7. Hand-fed vertical spindle moulding machinery for working with wood and material with similar physical characteristics.

8. Portable chainsaws for woodworking.

9. Presses, including press-brakes, for the cold working of metals, with manual loading and/or unloading, whose movable working parts may have a travel exceeding 6 mm and a speed exceeding 30 mm/s.

10. Injection or compression plastics-moulding machinery with manual loading or unloading.

11. Injection or compression rubber-moulding machinery with manual loading or unloading.

12. Machinery for underground working of the following types:

- 12.1. locomotives and brake-vans;

- 12.2. hydraulic-powered roof supports.

13. Manually loaded trucks for the collection of household refuse incorporating a compression mechanism.

14. Removable mechanical transmission devices including their guards.

15. Guards for removable mechanical transmission devices.

16. Vehicle servicing lifts.

17. Devices for the lifting of persons or of persons and goods involving a hazard of falling from a vertical height of more than three metres.

18. Portable cartridge-operated fixing and other impact machinery.

19. Protective devices designed to detect the presence of persons.

20. Power-operated interlocking movable guards designed to be used as safeguards in machinery referred to in points 9, 10 and 11.

21. Logic units to ensure safety functions.

22. Roll-over protective structures (ROPS).

23. Falling-object protective structures (FOPS).

<a id="annex-v"></a>
## Annex V – Indicative list of the safety components referred to in Article 2(c)

1. Guards for removable mechanical transmission devices.

2. Protective devices designed to detect the presence of persons.

3. Power-operated interlocking movable guards designed to be used as safeguards in machinery referred to in items 9, 10 and 11 of Annex IV.

4. Logic units to ensure safety functions.

5. Valves with additional means for failure detection intended for the control of dangerous movements on machinery.

6. Extraction systems for machinery emissions.

7. Guards and protective devices designed to protect persons against moving parts involved in the process on the machinery.

8. Monitoring devices for loading and movement control in lifting machinery.

9. Restraint systems to keep persons on their seats.

10. Emergency stop devices.

11. Discharging systems to prevent the build-up of potentially dangerous electrostatic charges.

12. Energy limiters and relief devices referred to in sections 1.5.7, 3.4.7 and 4.1.2.6 of Annex I.

13. Systems and devices to reduce the emission of noise and vibrations.

14. Roll-over protective structures (ROPS).

15. Falling-object protective structures (FOPS).

16. Two-hand control devices.

17. Components for machinery designed for lifting and/or lowering persons between different landings and included in the following list:

- (a) devices for locking landing doors;

- (b) devices to prevent the load-carrying unit from falling or unchecked upwards movement;

- (c) overspeed limitation devices;

- (d) energy-accumulating shock absorbers,

  - — non-linear, or

  - — with damping of the return movement;

- (e) energy-dissipating shock absorbers;

- (f) safety devices fitted to jacks of hydraulic power circuits where these are used as devices to prevent falls;

- (g) electric safety devices in the form of safety switches containing electronic components.

<a id="annex-vi"></a>
## Annex VI – Assembly instructions for partly completed machinery

The assembly instructions for partly completed machinery must contain a description of the conditions which must be met with a view to correct incorporation in the final machinery, so as not to compromise safety and health.

The assembly instructions must be written in an official Community language acceptable to the manufacturer of the machinery in which the partly completed machinery will be assembled, or to his authorised representative.

<a id="annex-vii"></a>
## Annex VII

### A. Technical file for machinery

This part describes the procedure for compiling a technical file. The technical file must demonstrate that the machinery complies with the requirements of this Directive. It must cover the design, manufacture and operation of the machinery to the extent necessary for this assessment. The technical file must be compiled in one or more official Community languages, except for the instructions for the machinery, for which the special provisions of Annex I, section 1.7.4.1 apply.

1. The technical file shall comprise the following:

- (a) a construction file including:

  - — a general description of the machinery,

  - — the overall drawing of the machinery and drawings of the control circuits, as well as the pertinent descriptions and explanations necessary for understanding the operation of the machinery,

  - — full detailed drawings, accompanied by any calculation notes, test results, certificates, etc., required to check the conformity of the machinery with the essential health and safety requirements,

  - — the documentation on risk assessment demonstrating the procedure followed, including:

    - (i) a list of the essential health and safety requirements which apply to the machinery,

    - (ii) the description of the protective measures implemented to eliminate identified hazards or to reduce risks and, when appropriate, the indication of the residual risks associated with the machinery,

  - — the standards and other technical specifications used, indicating the essential health and safety requirements covered by these standards,

  - — any technical report giving the results of the tests carried out either by the manufacturer or by a body chosen by the manufacturer or his authorised representative,

  - — a copy of the instructions for the machinery,

  - — where appropriate, the declaration of incorporation for included partly completed machinery and the relevant assembly instructions for such machinery,

  - — where appropriate, copies of the EC declaration of conformity of machinery or other products incorporated into the machinery,

  - — a copy of the EC declaration of conformity;

- (b) for series manufacture, the internal measures that will be implemented to ensure that the machinery remains in conformity with the provisions of this Directive.

The manufacturer must carry out necessary research and tests on components, fittings or the completed machinery to determine whether by its design or construction it is capable of being assembled and put into service safely. The relevant reports and results shall be included in the technical file.

2. The technical file referred to in point 1 must be made available to the competent authorities of the Member States for at least 10 years following the date of manufacture of the machinery or, in the case of series manufacture, of the last unit produced.

The technical file does not have to be located in the territory of the Community, nor does it have to be permanently available in material form. However, it must be capable of being assembled and made available within a period of time commensurate with its complexity by the person designated in the EC declaration of conformity.

The technical file does not have to include detailed plans or any other specific information as regards the sub-assemblies used for the manufacture of the machinery unless a knowledge of them is essential for verification of conformity with the essential health and safety requirements.

3. Failure to present the technical file in response to a duly reasoned request by the competent national authorities may constitute sufficient grounds for doubting the conformity of the machinery in question with the essential health and safety requirements.

### B. Relevant technical documentation for partly completed machinery

This part describes the procedure for compiling relevant technical documentation. The documentation must show which requirements of this Directive are applied and fulfilled. It must cover the design, manufacture and operation of the partly completed machinery to the extent necessary for the assessment of conformity with the essential health and safety requirements applied. The documentation must be compiled in one or more official Community languages.

It shall comprise the following:

- (a) a construction file including:

  - — the overall drawing of the partly completed machinery and drawings of the control circuits,

  - — full detailed drawings, accompanied by any calculation notes, test results, certificates, etc., required to check the conformity of the partly completed machinery with the applied essential health and safety requirements,

  - — the risk assessment documentation showing the procedure followed, including:

    - (i) a list of the essential health and safety requirements applied and fulfilled,

    - (ii) the description of the protective measures implemented to eliminate identified hazards or to reduce risks and, where appropriate, the indication of the residual risks,

    - (iii) the standards and other technical specifications used, indicating the essential health and safety requirements covered by these standards,

    - (iv) any technical report giving the results of the tests carried out either by the manufacturer or by a body chosen by the manufacturer or his authorised representative,

    - (v) a copy of the assembly instructions for the partly completed machinery;

- (b) for series manufacture, the internal measures that will be implemented to ensure that the partly completed machinery remains in conformity with the essential health and safety requirements applied.

The manufacturer must carry out necessary research and tests on components, fittings or the partly completed machinery to determine whether by its design or construction it is capable of being assembled and used safely. The relevant reports and results shall be included in the technical file.

The relevant technical documentation must be available for at least 10 years following the date of manufacture of the partly completed machinery or, in the case of series manufacture, of the last unit produced, and on request presented to the competent authorities of the Member States. It does not have to be located in the territory of the Community, nor does it have to be permanently available in material form. It must be capable of being assembled and presented to the relevant authority by the person designated in the declaration for incorporation.

Failure to present the relevant technical documentation in response to a duly reasoned request by the competent national authorities may constitute sufficient grounds for doubting the conformity of the partly completed machinery with the essential health and safety requirements applied and attested.

<a id="annex-viii"></a>
## Annex VIII – Assessment of conformity with internal checks on the manufacture of machinery

1. This Annex describes the procedure by which the manufacturer or his authorised representative, who carries out the obligations laid down in points 2 and 3, ensures and declares that the machinery concerned satisfies the relevant requirements of this Directive.

2. For each representative type of the series in question, the manufacturer or his authorised representative shall draw up the technical file referred to in Annex VII, part A.

3. The manufacturer must take all measures necessary in order that the manufacturing process ensures compliance of the manufactured machinery with the technical file referred to in Annex VII, part A, and with the requirements of this Directive.

<a id="annex-ix"></a>
## Annex IX – EC type-examination

EC type-examination is the procedure whereby a notified body ascertains and certifies that a representative model of machinery referred to in Annex IV (hereafter named the type) satisfies the provisions of this Directive.

1. The manufacturer or his authorised representative must, for each type, draw up the technical file referred to in Annex VII, part A.

2. For each type, the application for an EC type-examination shall be submitted by the manufacturer or his authorised representative to a notified body of his choice.

The application shall include:

- — the name and address of the manufacturer and, where appropriate, his authorised representative,

- — a written declaration that the application has not been submitted to another notified body,

- — the technical file.

Moreover, the applicant shall place at the disposal of the notified body a sample of the type. The notified body may ask for further samples if the test programme so requires.

3. The notified body shall:

- 3.1. examine the technical file, check that the type was manufactured in accordance with it and establish which elements have been designed in accordance with the relevant provisions of the standards referred to in Article 7(2), and those elements whose design is not based on the relevant provisions of those standards;

- 3.2. carry out or have carried out appropriate inspections, measurements and tests to ascertain whether the solutions adopted satisfy the essential health and safety requirements of this Directive, where the standards referred to in Article 7(2) were not applied;

- 3.3. where harmonised standards referred to in Article 7(2) were used, carry out or have carried out appropriate inspections, measurements and tests to verify that those standards were actually applied;

- 3.4. agree with the applicant as to the place where the check that the type was manufactured in accordance with the examined technical file and the necessary inspections, measurements and tests will be carried out.

4. If the type satisfies the provisions of this Directive, the notified body shall issue the applicant with an EC type-examination certificate. The certificate shall include the name and address of the manufacturer and his authorised representative, the data necessary for identifying the approved type, the conclusions of the examination and the conditions to which its issue may be subject.

The manufacturer and the notified body shall retain a copy of this certificate, the technical file and all relevant documents for a period of 15 years from the date of issue of the certificate.

5. If the type does not satisfy the provisions of this Directive, the notified body shall refuse to issue the applicant with an EC type-examination certificate, giving detailed reasons for its refusal. It shall inform the applicant, the other notified bodies and the Member State which notified it. An appeal procedure must be available.

6. The applicant shall inform the notified body which retains the technical file relating to the EC type-examination certificate of all modifications to the approved type. The notified body shall examine these modifications and shall then either confirm the validity of the existing EC type-examination certificate or issue a new one if the modifications are liable to compromise conformity with the essential health and safety requirements or the intended working conditions of the type.

7. The Commission, the Member States and the other notified bodies may, on request, obtain a copy of the EC type-examination certificates. On reasoned request, the Commission and the Member States may obtain a copy of the technical file and the results of the examinations carried out by the notified body.

8. Files and correspondence referring to the EC type-examination procedures shall be written in the official Community language(s) of the Member State where the notified body is established or in any other official Community language acceptable to the notified body.

9. Validity of the EC type-examination certificate

9.1. The notified body has the ongoing responsibility of ensuring that the EC type-examination certificate remains valid. It shall inform the manufacturer of any major changes which would have an implication on the validity of the certificate. The notified body shall withdraw certificates which are no longer valid.

9.2. The manufacturer of the machinery concerned has the ongoing responsibility of ensuring that the said machinery meets the corresponding state of the art.

9.3. The manufacturer shall request from the notified body the review of the validity of the EC type-examination certificate every five years.

If the notified body finds that the certificate remains valid, taking into account the state of the art, it shall renew the certificate for a further five years.

The manufacturer and the notified body shall retain a copy of this certificate, of the technical file and of all the relevant documents for a period of 15 years from the date of issue of the certificate.

9.4. In the event that the validity of the EC-type examination certificate is not renewed, the manufacturer shall cease the placing on the market of the machinery concerned.

<a id="annex-x"></a>
## Annex X – Full quality assurance

This Annex describes the conformity assessment of machinery referred to in Annex IV, manufactured using a full quality assurance system, and the procedure whereby a notified body assesses and approves the quality system and monitors its application.

1. The manufacturer must operate an approved quality system for design, manufacture, final inspection and testing, as specified in point 2, and shall be subject to the surveillance referred to in point 3.

2. Quality system

2.1. The manufacturer or his authorised representative shall lodge an application for assessment of his quality system to a notified body of his choice.

The application shall contain:

- — the name and address of the manufacturer and, where appropriate, his authorised representative,

- — the places of design, manufacture, inspection, testing and storage of the machinery,

- — the technical file described in Annex VII, Part A, for one model of each category of machinery referred to in Annex IV which he intends to manufacture,

- — the documentation on the quality system,

- — a written declaration that the application has not been submitted to another notified body.

2.2. The quality system must ensure conformity of the machinery with the provisions of this Directive. All the elements, requirements and provisions adopted by the manufacturer must be documented in a systematic and orderly manner, in the form of measures, procedures and written instructions. The documentation on the quality system must permit a uniform interpretation of the procedural and quality measures, such as quality programmes, plans, manuals and records.

It must contain, in particular, an adequate description of:

- — the quality objectives, the organisational structure, and the responsibilities and powers of the management with regard to the design and quality of the machinery,

- — the technical design specifications, including standards that will be applied and, where the standards referred to in Article 7(2) are not applied in full, the means that will be used to ensure that the essential health and safety requirements of this Directive are fulfilled,

- — the design inspection and design verification techniques, processes and systematic actions that will be used when designing machinery covered by this Directive,

- — the corresponding manufacturing, quality control and quality assurance techniques, processes and systematic actions that will be used,

- — the inspections and tests that will be carried out before, during and after manufacture, and the frequency with which they will be carried out,

- — the quality records, such as inspection reports and test data, calibration data, and reports on the qualifications of the personnel concerned,

- — the means of monitoring the achievement of the required design and quality of the machinery, as well as the effective operation of the quality system.

2.3. The notified body shall assess the quality system to determine whether it satisfies the requirements of point 2.2.

The elements of the quality system which conform to the relevant harmonised standard shall be presumed to conform to the corresponding requirements referred to in point 2.2.

The team of auditors must have at least one member who is experienced in the assessment of the technology of the machinery. The assessment procedure shall include an inspection to be carried out at the manufacturer's premises. During the assessment, the team of auditors shall carry out a review of the technical files referred to in point 2.1, second paragraph, third indent to ensure their compliance with the relevant health and safety requirements.

The manufacturer or his authorised representative shall be notified of the decision. The notification shall contain the conclusions of the examination and the reasoned assessment decision. An appeal procedure must be available.

2.4. The manufacturer shall undertake to fulfil the obligations arising from the quality system as approved and to ensure that it remains appropriate and effective.

The manufacturer or his authorised representative shall inform the notified body which approved the quality system of any planned change to it.

The notified body shall evaluate the proposed changes and decide whether the modified quality assurance system will continue to satisfy the requirements referred to in point 2.2, or whether a re-assessment is necessary.

It shall notify the manufacturer of its decision. The notification shall contain the conclusions of the examination and the reasoned assessment decision.

3. Surveillance under the responsibility of the notified body

3.1. The purpose of surveillance is to make sure that the manufacturer duly fulfils the obligations arising out of the approved quality system.

3.2. The manufacturer shall, for inspection purposes, allow the notified body access to the places of design, manufacture, inspection, testing and storage, and shall provide it with all necessary information, such as:

- — the documentation concerning the quality system,

- — the quality records provided for in that part of the quality system concerned with design, such as the results of analyses, calculations, tests, etc.,

- — the quality records provided for in that part of the quality system concerned with manufacture, such as inspection reports and test data, calibration data, reports on the qualifications of the personnel concerned, etc.

3.3. The notified body shall conduct periodic audits to make sure that the manufacturer is maintaining and applying the quality system; it shall provide the manufacturer with an audit report. The frequency of the periodic audits shall be such that a full reassessment is carried out every three years.

3.4. Moreover, the notified body may pay the manufacturer unannounced visits. The need for these additional visits and their frequency will be determined on the basis of a visit monitoring system managed by the notified body. In particular, the following factors will be taken into account in the visits monitoring system:

- — the results of previous surveillance visits,

- — the need to monitor remedial measures,

- — where appropriate, special conditions attaching to approval of the system,

- — significant modifications in the organisation of the manufacturing process, measures or techniques.

On the occasion of such visits, the notified body may, if necessary, carry out tests or have them carried out in order to check the proper functioning of the quality system. It shall provide the manufacturer with a visit report and, if a test was carried out, with a test report.

4. The manufacturer or his authorised representative shall keep available for the national authorities, for a period of ten years from the last date of manufacture:

- — the documentation referred to in point 2.1,

- — the decisions and reports of the notified body referred to in point 2.4, third and fourth subparagraphs, and in points 3.3 and 3.4.

<a id="annex-xi"></a>
## Annex XI – Minimum criteria to be taken into account by Member States for the notification of bodies

1. The body, its director and the staff responsible for carrying out the verification tests shall not be the designer, manufacturer, supplier or installer of machines which they inspect, nor the authorised representative of any of these parties. They shall not become involved, either directly or as authorised representatives, in the design, construction, marketing or maintenance of the machines. This does not preclude the possibility of exchanges of technical information between the manufacturer and the body.

2. The body and its staff shall carry out the verification tests with the highest degree of professional integrity and technical competence and shall be free from all pressures and inducements, particularly financial, which might influence their judgement or the results of the inspection, especially from persons or groups of persons with an interest in the result of verifications.

3. For each category of machinery for which it is notified, the body must possess personnel with technical knowledge and sufficient and appropriate experience to perform a conformity assessment. It must have the means necessary to complete the technical and administrative tasks connected with implementation of the checks in an appropriate manner; it must also have access to the equipment necessary for the exceptional checks.

4. The staff responsible for inspection shall have:

- — sound technical and vocational training,

- — satisfactory knowledge of the requirements of the tests they carry out and adequate experience of such tests,

- — the ability to draw up the certificates, records and reports required to authenticate the performance of the tests.

5. The impartiality of inspection staff shall be guaranteed. Their remuneration shall not depend on the number of tests carried out or on the results of such tests.

6. The body shall take out liability insurance unless its liability is assumed by the State in accordance with national law, or the Member State itself is directly responsible for the tests.

7. The staff of the body shall be bound to observe professional secrecy with regard to all information obtained in carrying out its tasks (except vis-à-vis the competent administrative authorities of the State in which its activities are carried out) under this Directive or any provision of national law giving effect to it.

8. Notified bodies shall participate in coordination activities. They shall also take part directly or be represented in European standardisation, or ensure that they know the situation in respect of relevant standards.

9. Member States may take all necessary measures they regard as necessary in order to ensure that, in the event of cessation of the activities of a notified body, the files of its customers are sent to another body or are made available to the Member State which has notified it.

<a id="annex-xii"></a>
## Annex XII

### Correlation table ^(12)

| Directive 98/37/EC | This Directive |
| --- | --- |
| Article 1(1) | Article 1(1) |
| Article 1(2)(a) | Article 2(a) and (b) |
| Article 1(2)(b) | Article 2(c) |
| Article 1(3) | Article 1(2) |
| Article 1(4) | Article 3 |
| Article 1(5) | — |
| Article 2(1) | Article 4(1) |
| Article 2(2) | Article 15 |
| Article 2(3) | Article 6(3) |
| Article 3 | Article 5(1)(a) |
| Article 4(1) | Article 6(1) |
| Article 4(2), first subparagraph | Article 6(2) |
| Article 4(2), second subparagraph | — |
| Article 4(3) | — |
| Article 5(1), first subparagraph | Article 7(1) |
| Article 5(1), second subparagraph | — |
| Article 5(2), first subparagraph | Article 7(2) and (3) |
| Article 5(2), last subparagraph | — |
| Article 5(3) | Article 7(4) |
| Article 6(1) | Article 10 |
| Article 6(2) | Article 22 |
| Article 7(1) | Article 11(1) and (2) |
| Article 7(2) | Article 11(3) and (4) |
| Article 7(3) | Article 11(4) |
| Article 7(4) | Article 11(5) |
| Article 8(1), first subparagraph | Article 5(1)(e) and Article 12(1) |
| Article 8(1), second subparagraph | Article 5(1)(f) |
| Article 8(2)(a) | Article 12(2) |
| Article 8(2)(b) | Article 12(4) |
| Article 8(2)(c) | Article 12(3) |
| Article 8(3) | — |
| Article 8(4) | — |
| Article 8(5) | — |
| Article 8(6) | Article 5(4) |
| Article 8(7) | — |
| Article 8(8) | — |
| Article 9(1), first subparagraph | Article 14(1) |
| Article 9(1), second subparagraph | Article 14(4) |
| Article 9(2) | Article 14(3) and (5) |
| Article 9(3) | Article 14(8) |
| Article 10(1 to 3) | Article 16(1) to (3) |
| Article 10(4) | Article 17 |
| Article 11 | Article 20 |
| Article 12 | Article 21 |
| Article 13(1) | Article 26(2) |
| Article 13(2) | — |
| Article 14 | — |
| Article 15 | Article 28 |
| Article 16 | Article 29 |
| Annex I — Preliminary observation 1 | Annex I — General Principles point 2 |
| Annex I — Preliminary observation 2 | Annex I — General Principles point 3 |
| Annex I — Preliminary observation 3 | Annex I — General Principles point 4 |
| Annex I, Part 1 | Annex I, Part 1 |
| Annex I, Section 1.1. | Annex I, Section 1.1. |
| Annex I, Section 1.1.1. | Annex I, Section 1.1.1. |
| Annex I, Section 1.1.2. | Annex I, Section 1.1.2. |
| Annex I, Section 1.1.2(d) | Annex I, Section 1.1.6. |
| Annex I, Section 1.1.3. | Annex I, Section 1.1.3. |
| Annex I, Section 1.1.4. | Annex I, Section 1.1.4. |
| Annex I, Section 1.1.5. | Annex I, Section 1.1.5. |
| Annex I, Section 1.2. | Annex I, Section 1.2. |
| Annex I, Section 1.2.1. | Annex I, Section 1.2.1. |
| Annex I, Section 1.2.2. | Annex I, Section 1.2.2. |
| Annex I, Section 1.2.3. | Annex I, Section 1.2.3. |
| Annex I, Section 1.2.4. | Annex I, Section 1.2.4. |
| Annex I, Section 1.2.4., paragraphs 1 to 3 | Annex I, Section 1.2.4.1. |
| Annex I, Section 1.2.4., paragraphs 4 to 6 | Annex I, Section 1.2.4.3. |
| Annex I, Section 1.2.4., paragraph 7 | Annex I, Section 1.2.4.4. |
| Annex I, Section 1.2.5. | Annex I, Section 1.2.5. |
| Annex I, Section 1.2.6. | Annex I, Section 1.2.6. |
| Annex I, Section 1.2.7. | Annex I, Section 1.2.1. |
| Annex I, Section 1.2.8. | Annex I, Section 1.1.6. |
| Annex I, Section 1.3 | Annex I, Section 1.3 |
| Annex I, Section 1.3.1. | Annex I, Section 1.3.1. |
| Annex I, Section 1.3.2. | Annex I, Section 1.3.2. |
| Annex I, Section 1.3.3. | Annex I, Section 1.3.3. |
| Annex I, Section 1.3.4. | Annex I, Section 1.3.4. |
| Annex I, Section 1.3.5. | Annex I, Section 1.3.5. |
| Annex I, Section 1.3.6. | Annex I, Section 1.3.6. |
| Annex I, Section 1.3.7. | Annex I, Section 1.3.7. |
| Annex I, Section 1.3.8 | Annex I, Section 1.3.8. |
| Annex I, Section 1.3.8 A | Annex I, Section 1.3.8.1. |
| Annex I, Section 1.3.8 B | Annex I, Section 1.3.8.2. |
| Annex I, Section 1.4. | Annex I, Section 1.4. |
| Annex I, Section 1.4.1. | Annex I, Section 1.4.1. |
| Annex I, Section 1.4.2. | Annex I, Section 1.4.2. |
| Annex I, Section 1.4.2.1. | Annex I, Section 1.4.2.1. |
| Annex I, Section 1.4.2.2. | Annex I, Section 1.4.2.2. |
| Annex I, Section 1.4.2.3. | Annex I, Section 1.4.2.3. |
| Annex I, Section 1.4.3. | Annex I, Section 1.4.3. |
| Annex I, Section 1.5. | Annex I, Section 1.5. |
| Annex I, Section 1.5.1. | Annex I, Section 1.5.1. |
| Annex I, Section 1.5.2. | Annex I, Section 1.5.2. |
| Annex I, Section 1.5.3. | Annex I, Section 1.5.3. |
| Annex I, Section 1.5.4. | Annex I, Section 1.5.4. |
| Annex I, Section 1.5.5. | Annex I, Section 1.5.5. |
| Annex I, Section 1.5.6. | Annex I, Section 1.5.6. |
| Annex I, Section 1.5.7. | Annex I, Section 1.5.7. |
| Annex I, Section 1.5.8. | Annex I, Section 1.5.8. |
| Annex I, Section 1.5.9. | Annex I, Section 1.5.9. |
| Annex I, Section 1.5.10. | Annex I, Section 1.5.10. |
| Annex I, Section 1.5.11. | Annex I, Section 1.5.11. |
| Annex I, Section 1.5.12. | Annex I, Section 1.5.12. |
| Annex I, Section 1.5.13. | Annex I, Section 1.5.13. |
| Annex I, Section 1.5.14. | Annex I, Section 1.5.14. |
| Annex I, Section 1.5.15. | Annex I, Section 1.5.15. |
| Annex I, Section 1.6. | Annex I, Section 1.6. |
| Annex I, Section 1.6.1. | Annex I, Section 1.6.1. |
| Annex I, Section 1.6.2. | Annex I, Section 1.6.2. |
| Annex I, Section 1.6.3. | Annex I, Section 1.6.3. |
| Annex I, Section 1.6.4. | Annex I, Section 1.6.4. |
| Annex I, Section 1.6.5. | Annex I, Section 1.6.5. |
| Annex I, Section 1.7. | Annex I, Section 1.7. |
| Annex I, Section 1.7.0. | Annex I, Section 1.7.1.1. |
| Annex I, Section 1.7.1. | Annex I, Section 1.7.1.2. |
| Annex I, Section 1.7.2. | Annex I, Section 1.7.2. |
| Annex I, Section 1.7.3. | Annex I, Section 1.7.3. |
| Annex I, Section 1.7.4. | Annex I, Section 1.7.4. |
| Annex I, Section 1.7.4.(b) and (h) | Annex I, Section 1.7.4.1. |
| Annex I, Section 1.7.4.(a) and (c) and (e) to (g) | Annex I, Section 1.7.4.2. |
| Annex I, Section 1.7.4.(d) | Annex I, Section 1.7.4.3. |
| Annex I, Part 2 | Annex I, Part 2 |
| Annex I, Section 2.1. | Annex I, Section 2.1. |
| Annex I, Section 2.1., paragraph 1 | Annex I, Section 2.1.1. |
| Annex I, Section 2.1., paragraph 2 | Annex I, Section 2.1.2. |
| Annex I, Section 2.2. | Annex I, Section 2.2. |
| Annex I, Section 2.2., paragraph 1 | Annex I, Section 2.2.1. |
| Annex I, Section 2.2., paragraph 2 | Annex I, Section 2.2.1.1. |
| Annex I, Section 2.3. | Annex I, Section 2.3. |
| Annex I, Part 3 | Annex I, Part 3 |
| Annex I, Section 3.1. | Annex I, Section 3.1. |
| Annex I, Section 3.1.1. | Annex I, Section 3.1.1. |
| Annex I, Section 3.1.2. | Annex I, Section 1.1.4. |
| Annex I, Section 3.1.3. | Annex I, Section 1.1.5. |
| Annex I, Section 3.2. | Annex I, Section 3.2. |
| Annex I, Section 3.2.1. | Annex I, Section 1.1.7. and 3.2.1. |
| Annex I, Section 3.2.2. | Annex I, Sections 1.1.8. and 3.2.2. |
| Annex I, Section 3.2.3. | Annex I, Section 3.2.3. |
| Annex I, Section 3.3. | Annex I, Section 3.3. |
| Annex I, Section 3.3.1. | Annex I, Section 3.3.1. |
| Annex I, Section 3.3.2. | Annex I, Section 3.3.2. |
| Annex I, Section 3.3.3. | Annex I, Section 3.3.3. |
| Annex I, Section 3.3.4. | Annex I, Section 3.3.4. |
| Annex I, Section 3.3.5. | Annex I, Section 3.3.5. |
| Annex I, Section 3.4. | Annex I, Section 3.4. |
| Annex I, Section 3.4.1., paragraph 1 | Annex I, Section 1.3.9. |
| Annex I, Section 3.4.1., paragraph 2 | Annex I, Section 3.4.1. |
| Annex I, Section 3.4.2. | Annex I, Section 1.3.2. |
| Annex I, Section 3.4.3. | Annex I, Section 3.4.3. |
| Annex I, Section 3.4.4. | Annex I, Section 3.4.4. |
| Annex I, Section 3.4.5. | Annex I, Section 3.4.5. |
| Annex I, Section 3.4.6. | Annex I, Section 3.4.6. |
| Annex I, Section 3.4.7. | Annex I, Section 3.4.7. |
| Annex I, Section 3.4.8. | Annex I, Section 3.4.2. |
| Annex I, Section 3.5. | Annex I, Section 3.5. |
| Annex I, Section 3.5.1. | Annex I, Section 3.5.1. |
| Annex I, Section 3.5.2. | Annex I, Section 3.5.2. |
| Annex I, Section 3.5.3. | Annex I, Section 3.5.3. |
| Annex I, Section 3.6. | Annex I, Section 3.6. |
| Annex I, Section 3.6.1. | Annex I, Section 3.6.1. |
| Annex I, Section 3.6.2. | Annex I, Section 3.6.2. |
| Annex I, Section 3.6.3. | Annex I, Section 3.6.3. |
| Annex I, Section 3.6.3(a) | Annex I, Section 3.6.3.1. |
| Annex I, Section 3.6.3(b) | Annex I, Section 3.6.3.2. |
| Annex I, Part 4 | Annex I, Part 4 |
| Annex I, Section 4.1. | Annex I, Section 4.1. |
| Annex I, Section 4.1.1. | Annex I, Section 4.1.1. |
| Annex I, Section 4.1.2. | Annex I, Section 4.1.2. |
| Annex I, Section 4.1.2.1. | Annex I, Section 4.1.2.1. |
| Annex I, Section 4.1.2.2. | Annex I, Section 4.1.2.2. |
| Annex I, Section 4.1.2.3. | Annex I, Section 4.1.2.3. |
| Annex I, Section 4.1.2.4. | Annex I, Section 4.1.2.4. |
| Annex I, Section 4.1.2.5. | Annex I, Section 4.1.2.5. |
| Annex I, Section 4.1.2.6. | Annex I, Section 4.1.2.6. |
| Annex I, Section 4.1.2.7. | Annex I, Section 4.1.2.7. |
| Annex I, Section 4.1.2.8. | Annex I, Section 1.5.16. |
| Annex I, Section 4.2. | Annex I, Section 4.2. |
| Annex I, Section 4.2.1. | — |
| Annex I, Section 4.2.1.1. | Annex I, Section 1.1.7. |
| Annex I, Section 4.2.1.2. | Annex I, Section 1.1.8. |
| Annex I, Section 4.2.1.3. | Annex I, Section 4.2.1. |
| Annex I, Section 4.2.1.4. | Annex I, Section 4.2.2. |
| Annex I, Section 4.2.2. | Annex I, Section 4.2.3. |
| Annex I, Section 4.2.3. | Annex I, Sections 4.1.2.7. and 4.1.2.8.2. |
| Annex I, Section 4.2.4. | Annex I, Section 4.1.3. |
| Annex I, Section 4.3. | Annex I, Section 4.3. |
| Annex I, Section 4.3.1. | Annex I, Section 4.3.1. |
| Annex I, Section 4.3.2. | Annex I, Section 4.3.2. |
| Annex I, Section 4.3.3. | Annex I, Section 4.3.3. |
| Annex I, Section 4.4. | Annex I, Section 4.4. |
| Annex I, Section 4.4.1. | Annex I, Section 4.4.1. |
| Annex I, Section 4.4.2. | Annex I, Section 4.4.2. |
| Annex I, Part 5 | Annex I, Part 5 |
| Annex I, Section 5.1. | Annex I, Section 5.1. |
| Annex I, Section 5.2. | Annex I, Section 5.2. |
| Annex I, Section 5.3. | — |
| Annex I, Section 5.4. | Annex I, Section 5.3. |
| Annex I, Section 5.5. | Annex I, Section 5.4. |
| Annex I, Section 5.6. | Annex I, Section 5.5. |
| Annex I, Section 5.7. | Annex I, Section 5.6. |
| Annex I, Part 6 | Annex I, Part 6 |
| Annex I, Section 6.1. | Annex I, Section 6.1. |
| Annex I, Section 6.1.1. | Annex I, Section 4.1.1.(g) |
| Annex I, Section 6.1.2. | Annex I, Section 6.1.1. |
| Annex I, Section 6.1.3. | Annex I, Section 6.1.2. |
| Annex I, Section 6.2. | Annex I, Section 6.2. |
| Annex I, Section 6.2.1. | Annex I, Section 6.2. |
| Annex I, Section 6.2.2. | Annex I, Section 6.2. |
| Annex I, Section 6.2.3. | Annex I, Section 6.3.1. |
| Annex I, Section 6.3. | Annex I, Section 6.3.2. |
| Annex I, Section 6.3.1. | Annex I, Section 6.3.2., paragraph 3 |
| Annex I, Section 6.3.2. | Annex I, Section 6.3.2., paragraph 4 |
| Annex I, Section 6.3.3. | Annex I, Section 6.3.2., paragraph 1 |
| Annex I, Section 6.4.1. | Annex I, Sections 4.1.2.1., 4.1.2.3. and 6.1.1. |
| Annex I, Section 6.4.2. | Annex I, Section 6.3.1. |
| Annex I, Section 6.5. | Annex I, Section 6.5. |
| Annex II, Parts A and B | Annex II, Part 1,Section A |
| Annex II, Part C | — |
| Annex III | Annex III |
| Annex IV.A.1 (1.1. to 1.4) | Annex IV.1 (1.1. to 1.4) |
| Annex IV.A.2 | Annex IV.2 |
| Annex IV.A.3 | Annex IV.3 |
| Annex IV.A.4 | Annex IV.4 (4.1 and 4.2) |
| Annex IV.A.5 | Annex IV.5 |
| Annex IV.A.6 | Annex IV.6 |
| Annex IV.A.7 | Annex IV.7 |
| Annex IV.A.8 | Annex IV.8 |
| Annex IV.A.9 | Annex IV.9 |
| Annex IV.A.10 | Annex IV.10 |
| Annex IV.A.11 | Annex IV.11 |
| Annex IV.A.12 (first and second indent) | Annex IV.12 (12.1 and 12.2) |
| Annex IV.A.12 (third indent) | — |
| Annex IV.A.13 | Annex IV.13 |
| Annex IV.A.14, first part | Annex IV.15 |
| Annex IV.A.14, second part | Annex IV.14 |
| Annex IV.A.15 | Annex IV.16 |
| Annex IV.A.16 | Annex IV.17 |
| Annex IV.A.17 | — |
| Annex IV.B.1 | Annex IV.19 |
| Annex IV.B.2 | Annex IV.21 |
| Annex IV.B.3 | Annex IV.20 |
| Annex IV.B.4 | Annex IV.22 |
| Annex IV.B.5 | Annex IV.23 |
| Annex V, Section 1 | — |
| Annex V, Section 2 | — |
| Annex V, Section 3, first subparagraph, point (a) | Annex VII, Part A, Section 1, first subparagraph, point (a) |
| Annex V, Section 3, first subparagraph, point (b) | Annex VII, Part A, Section 1, first subparagraph, point (b) |
| Annex V, Section 3, second subparagraph | Annex VII, Part A, Section 1, second subparagraph |
| Annex V, Section 3, third subparagraph | Annex VII, Part A, Section 3 |
| Annex V, Section 4(a) | Annex VII, Part A. Section 2, second and third subparagraphs |
| Annex V, Section 4 (b) | Annex VII, Part A. Section 2, first subparagraph |
| Annex V, Section 4(c) | Annex VII, Part A, Introduction |
| Annex VI, Section 1 | Annex IX, Introduction |
| Annex VI, Section 2 | Annex IX, Sections 1 and 2 |
| Annex VI, Section 3 | Annex IX, Section 3 |
| Annex VI, Section 4, first subparagraph | Annex IX, Section 4, first subparagraph |
| Annex VI, Section 4, second subparagraph | Annex IX, Section 7 |
| Annex VI, Section 5 | Annex IX, Section 6 |
| Annex VI, Section 6, first sentence | Annex IX, Section 5 |
| Annex VI, Section 6, second and third sentences | Article 14(6) |
| Annex VI, Section 7 | Annex IX, Section 8 |
| Annex VII, Section 1 | Annex XI, Section 1 |
| Annex VII, Section 2 | Annex XI, Section 2 |
| Annex VII, Section 3 | Annex XI, Section 3 |
| Annex VII, Section 4 | Annex XI, Section 4 |
| Annex VII, Section 5 | Annex XI, Section 5 |
| Annex VII, Section 6 | Annex XI, Section 6 |
| Annex VII, Section 7 | Annex XI, Section 7 |
| Annex VIII | — |
| Annex IX | — |

<a id="notes"></a>
## Notes

(1) OJ L 42, 23.2.1970, p. 1. Directive as last amended by Commission Directive 2006/28/EC (OJ L 65, 7.3.2006, p. 27).

(2) OJ L 124, 9.5.2002, p. 1. Directive as last amended by Commission Directive 2005/30/EC (OJ L 106, 27.4.2005, p. 17).

(3) OJ L 77, 26.3.1973, p. 29. Directive as amended by Directive 93/68/EEC (OJ L 220, 30.8.1993, p. 1).

(4) OJ L 204, 21.7.1998, p. 37. Directive as last amended by the 2003 Act of Accession.

(5) Regulation (EU) 2024/2747 of the European Parliament and of the Council of 9 October 2024 establishing a framework of measures, related to an internal market emergency and to the resilience of the internal market and amending Council Regulation (EC) No 2679/98 (Internal Market Emergency and Resilience Act) (OJ L, 2024/2747, 8.11.2024, ELI: http://data.europa.eu/eli/reg/2024/2747/oj).

(6) OJ L 123, 12.5.2016, p. 1.

(7) Regulation (EU) 2019/1020 of the European Parliament and of the Council of 20 June 2019 on market surveillance and compliance of products and amending Directive 2004/42/EC and Regulations (EC) No 765/2008 and (EU) No 305/2011 (OJ L 169, 25.6.2019, p. 1).

(8) Regulation (EU) No 1025/2012 of the European Parliament and of the Council of 25 October 2012 on European standardisation, amending Council Directives 89/686/EEC and 93/15/EEC and Directives 94/9/EC, 94/25/EC, 95/16/EC, 97/23/EC, 98/34/EC, 2004/22/EC, 2007/23/EC, 2009/23/EC and 2009/105/EC of the European Parliament and of the Council and repealing Council Decision 87/95/EEC and Decision No 1673/2006/EC of the European Parliament and of the Council (OJ L 316, 14.11.2012, p. 12).

(9) Regulation (EU) No 182/2011 of the European Parliament and of the Council of 16 February 2011 laying down the rules and general principles concerning mechanisms for control by Member States of the Commission’s exercise of implementing powers (OJ L 55, 28.2.2011, p. 13).

(10) OJ L 309, 24.11.2009, p. 1.

(11) OJ L 309, 24.11.2009, p. 71.

(12) This table indicates the relation between parts of Directive 98/37/EC and the parts of this Directive that deal with the same subject. However, the content of the correlated parts is not necessarily identical.
