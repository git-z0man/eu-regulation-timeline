---
act: espr/sreq-m604
version: 2024-07-31_commission-decision
stage: commission-decision
language: en
title: COMMISSION IMPLEMENTING DECISION of 31.7.2024 on a standardisation request to the European Committee for Standardisation, the European Committee for Electrotechnical Standardisation, and the European Telecommunications Standards Institute as regards digital product passports in support of Union policy on ecodesign requirements for sustainable products and on batteries and waste batteries (Only the English, French and German texts are authentic) THE EUROPEAN COMMISSION, Having regard to the Treaty on the Functioning of the European Union, Having regard to Regulation (EU) No 1025/2012 of the European Parliament and of the Council of 25 October 2012 on European standardisation, amending Council Directives 89/686/EEC and 93/15/EEC and Directives 94/9/EC, 94/25/EC, 95/16/EC, 97/23/EC, 98/34/EC, 2004/22/EC, 2007/23/EC, 2009/23/EC and 2009/105/EC of the European Parliament and of the Council and repealing Council Decision 87/95/EEC and Decision No 1673/2006/EC of the European Parliament
  and of the Council, ^(1) and in particular Article 10(1) thereof,
retrieved: '2026-09-27'
converter: tools/pdf2md.py
counts:
  recitals: 30
  articles: 5
  annexes: 2
official_source: https://ec.europa.eu/transparency/documents-register/detail?ref=C(2024)5423&lang=en
reuse: '© European Union, European Commission (Register of Commission documents). Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
extraction: Text extracted from the PDF text layer; headers, footers and page numbers removed, hyphenation joined, structure inferred from the layout, tables flattened. Check wording against the PDF before quoting.
---


# COMMISSION IMPLEMENTING DECISION of 31.7.2024 on a standardisation request to the European Committee for Standardisation, the European Committee for Electrotechnical Standardisation, and the European Telecommunications Standards Institute as regards digital product passports in support of Union policy on ecodesign requirements for sustainable products and on batteries and waste batteries (Only the English, French and German texts are authentic) THE EUROPEAN COMMISSION, Having regard to the Treaty on the Functioning of the European Union, Having regard to Regulation (EU) No 1025/2012 of the European Parliament and of the Council of 25 October 2012 on European standardisation, amending Council Directives 89/686/EEC and 93/15/EEC and Directives 94/9/EC, 94/25/EC, 95/16/EC, 97/23/EC, 98/34/EC, 2004/22/EC, 2007/23/EC, 2009/23/EC and 2009/105/EC of the European Parliament and of the Council and repealing Council Decision 87/95/EEC and Decision No 1673/2006/EC of the European Parliament and of the Council, ^(1) and in particular Article 10(1) thereof,

COMMISSION IMPLEMENTING DECISION

of 31.7.2024

on a standardisation request to the European Committee for Standardisation, the European Committee for Electrotechnical Standardisation, and the European Telecommunications Standards Institute as regards digital product passports in support of Union policy on ecodesign requirements for sustainable products and on batteries and waste batteries

(Only the English, French and German texts are authentic)

THE EUROPEAN COMMISSION,

Having regard to the Treaty on the Functioning of the European Union,

Having regard to Regulation (EU) No 1025/2012 of the European Parliament and of the Council of 25 October 2012 on European standardisation, amending Council Directives 89/686/EEC and 93/15/EEC and Directives 94/9/EC, 94/25/EC, 95/16/EC, 97/23/EC, 98/34/EC, 2004/22/EC, 2007/23/EC, 2009/23/EC and 2009/105/EC of the European Parliament and of the Council and repealing Council Decision 87/95/EEC and Decision No 1673/2006/EC of the European Parliament and of the Council, ^(1) and in particular Article 10(1) thereof,

Whereas:

## Recitals

<a id="rec-1"></a>
(1) As part of a Union policy on ecodesign requirements for sustainable products, the Commission adopted, in March 2022, a proposal for a Regulation of the European Parliament and of the Council establishing a framework for setting ecodesign requirements for sustainable products ^(2) laying down rules to improve the environmental sustainability of products and to ensure free movement in the internal market by setting ecodesign requirements that products are to fulfil to be placed on the market or put into service. The proposal introduces a requirement that products may only be placed on the market or put into service if a digital product passport (‘product passport’) is available in accordance with certain requirements and specifies the requirements for the product passport.

<a id="rec-2"></a>
(2) In the framework on the policy on batteries and waste batteries, Regulation (EU) 2023/1542 of the European Parliament and of the Council ^(3) was adopted on 12 July 2023. That Regulation establishes requirements on sustainability, safety, labelling, marking and information for the placing on the market or putting into service of batteries, as well as requirements for the collection, treatment, and recycling of waste batteries. Article 77 of that Regulation provides that certain categories of batteries may only be placed on the market or put into service if they have a product passport (electronic battery passport). Article 78 of Regulation (EU) 2023/1542 specifies the essential requirements for the technical design and operation of that product passport.

<a id="rec-3"></a>
(3) A product passport is a tool to foster the sustainability of products and the transition to sustainable business models by making information available to actors along the entire value chain. The availability of a product passport significantly enhances end-to-end traceability of a product throughout its value chain, helps consumers make informed choices by providing access to product information relevant to them, allows economic operators and other value chain actors such as repairers or recyclers to access relevant information, and enables competent national authorities to perform their duties. Product passports should be as uniform as possible across products, industry sectors and relevant Union legislations, and they should be used as consistently as possible to avoid confusion and misunderstandings when organisations or industries use different semantic or technical standards. To promote such uniformity, the product passport should also allow the inclusion of information concerning integrated product components, where relevant.

<a id="rec-4"></a>
(4) The product passports should be easily shared and used across different systems and platforms to enable information exchange between various stakeholders, such as manufacturers, suppliers, customers, and regulators.

<a id="rec-5"></a>
(5) The implementation of product passports should rely on standards which provide clear and consistent voluntary requirements. This should facilitate interoperability between different product passports reducing the time and resources required to implement and maintain them, as well as stimulate innovation and competition of market players offering services related to the product passports (services).

<a id="rec-6"></a>
(6) The product passport should be designed and implemented to allow differentiated access to its information depending on the type of information and the type of stakeholders.

<a id="rec-7"></a>
(7) To avoid costs to companies and to the public that are disproportionate compared to its benefits, the product passport should be defined at the level of item, batch or product model, depending on specific needs and complexity of the value chain, the size, nature or impacts of the products considered.

<a id="rec-8"></a>
(8) Unique identification of products is a fundamental element to enable traceability across the entire supply chain. Therefore, the product passport should be linked to a unique product identifier. In addition, where appropriate, the passport should allow for the tracing of the economic operators and facilities involved in the entire supply chain.

<a id="rec-9"></a>
(9) The unique identifier and the corresponding identification system of the product passport are to allow interoperability with existing legacy identification systems, as far as possible. The product passport system is to allow a suitable assignment of data carriers to the product which should be accessible without the need for the download of additional software. Moreover, all identifiers are to be portable and transferable through an open interoperable data exchange network without vendor lock-in, including their portability across resolver services or systems.

<a id="rec-10"></a>
(10) The creation of the data carriers and the unique identifiers should ensure that the information contained in the product passport can be accessed, recorded, and transmitted by all economic operators depending on their access rights, as well as guarantee the compatibility of the data carriers and unique identifiers with external components such as scanning devices.

<a id="rec-11"></a>
(11) To ensure that the product passport is flexible, agile and market-driven and evolving in line with business models, markets and innovation, it should be based on a decentralised data system, set up and maintained by economic operators. However, for enforcement and monitoring purposes, it may be necessary that competent national authorities and the Commission have direct access to all decentralised data systems and thus to all data carriers and unique identifiers linked to products placed on the market or put in service.

<a id="rec-12"></a>
(12) The product passport system should allow an interoperable extendibility of product passports based on regulatory requirements. The technical solution should enable that extendibility in case of need at a later stage. The extendibility of the product passports should cover at least: (1) additional type of data/properties/attributes and (2) additional records.

<a id="rec-13"></a>
(13) European standards are important instruments to support the implementation of Union policies and legislation and to ensure a high level of protection of safety and fundamental rights for all persons in the Union. European standards can also support the establishment of equal conditions of competition and a level playing field for the development of product passports, in particular for small and medium-sized enterprises developing product passport and related services.

<a id="rec-14"></a>
(14) To advance technical harmonisation in the field of product passports and to prepare the necessary technical environment for the implementation of the Union policy on ecodesign requirements for sustainable products and of Regulation (EU) 2023/1542, it is necessary to start the work on European standards.

<a id="rec-15"></a>
(15) European standards should be technology neutral and performance-based. They contribute to ensuring equal conditions of competition among relevant economic operators, in particular small and medium-sized enterprises. Indirectly those standards also contribute to lower production costs benefitting consumers, to increase the sustainability, to limit the energy consumption of the product passport system and to ensure technical interoperability.

<a id="rec-16"></a>
(16) The European Committee for Standardization (CEN) and the European Committee for Electrotechnical Standardization (CENELEC) and the European Telecommunications Standards Institute (ETSI) have indicated that the work covered by the standardisation request falls within their area of competence.

<a id="rec-17"></a>
(17) It is therefore appropriate to request that CEN, CENELEC and ETSI draft new European standards in support of Union policy on ecodesign requirements for sustainable products and on batteries and waste batteries.

<a id="rec-18"></a>
(18) In accordance with Article 5 of Regulation (EU) 1025/2012, the European Standardisation Organisations (ESOs) are expected to take all steps to ensure the involvement of small and medium enterprises and civil society organisations in the Union, including consumer organisations, in the standardisation processes and in the consensus-building exercise, both at the national and Union level. CEN, CENELEC and ETSI should thus include in the work programme the actions to be undertaken to ensure appropriate involvement of small and medium enterprises and civil society organisations in the Union and shall provide the necessary evidence of those actions in the context of interim and final reports provided on the execution of the standardisation request.

<a id="rec-19"></a>
(19) Requested standards should be coherent with the principles laid down in the Union legislation relating to processing of personal data, protection of privacy, security of network and information systems, cybersecurity or protection from fraud and with the technical mechanisms established in support hereof. The Commission and CEN, CENELEC and ETSI should cooperate in view of finding solutions in cases where the need to ensure such coherence might raise practical issues for the development of the European standards under this standardisation request.

<a id="rec-20"></a>
(20) European standards should include detailed technical specifications of the essential requirements. They should also clearly indicate the correspondence between those technical specifications and the essential requirements they aim to cover. In addition, they should reflect the generally acknowledged state of the art. As cybersecurity threats evolve at a fast pace, CEN, CENELEC and ETSI should monitor constantly the generally acknowledged state of the art and report to the Commission promptly where an evolution has been observed and provide the Commission with a plan to adapt existing standards.

<a id="rec-21"></a>
(21) The requested standards should be adopted by CEN, CENELEC and ETSI by the deadlines set out in this Decision. Given the short timeline for the implementation of the European policies requiring the use of the product passport, it may not be possible to extend those deadlines.

<a id="rec-22"></a>
(22) The standards to be drafted should build mainly on existing standards and best industry practice at international level, avoiding the lock-in of proprietary solutions. Therefore, existing ISO and IEC standards should be considered first and, if necessary, reviewed and complemented with specifications from existing European standards, national standards, and fora standards (in this order). To ensure semantic and technical interoperability, the standardisation process should consider the European Interoperability Framework ^(4) and related assets, like core vocabularies, base registries, application profiles or CAMSS (Common Assessment Method for Standards and Specifications).

<a id="rec-23"></a>
(23) As all relevant interested parties, including the Member States and the European stakeholder organisations receiving Union financing in accordance with Regulation (EU) No 1025/2012, may identify needs to develop additional standards, it may be necessary to consider adding new items to the list of standards set out in Annex I to this Decision. It may therefore be necessary to adjust the scope of this request accordingly.

<a id="rec-24"></a>
(24) The ESOs have agreed to follow the Guidelines for the execution of standardisation requests ^(5).

<a id="rec-25"></a>
(25) In order to ensure transparency and facilitate the execution of the requested standardisation activities CEN, CENELEC and ETSI should prepare a work programme and submit it to the Commission.

<a id="rec-26"></a>
(26) In order to enable the Commission to better monitor the requested standardisation work, CEN, CENELEC and ETSI should provide the Commission with access to an overall project plan containing detailed information on the execution of the standardisation request.

<a id="rec-27"></a>
(27) In accordance with Article 10(3) of Regulation (EU) No 1025/2012, each standardisation request is subject to acceptance by the relevant ESOs. It is therefore necessary to provide for the rules on validity of this request if it is not accepted by CEN, CENELEC and ETSI.

<a id="rec-28"></a>
(28) To ensure legal certainty as to the validity of the request after its execution, it is appropriate to provide for a date of expiry of this Decision.

<a id="rec-29"></a>
(29) The ESOs, the European stakeholders' organisations receiving Union financing, the Ecodesign Forum, and the Telecommunication Conformity Assessment and Market Surveillance Committee established by Article 45 of Directive 2014/53/EU of the European Parliament and of the Council ^(6) have been consulted.

<a id="rec-30"></a>
(30) The measures provided for in this Decision are in accordance with the opinion of the Committee established by Article 22 of Regulation (EU) No 1025/2012,

HAS ADOPTED THIS DECISION:

<a id="art-1"></a>
### Article 1 – Requested standardisation activities

1. The European Committee for Standardisation (CEN), the European Committee for Electrotechnical Standardisation (CENELEC) and the European Telecommunications Standards Institute (ETSI) are requested to draft the European standards listed in Annex I in support of Union policy on ecodesign requirements for sustainable products and on batteries and waste batteries by 31 December 2025.

2. The European standards referred to in paragraph 1 shall meet the requirements set out in Annex II.

3. CEN, CENELEC and ETSI shall provide the Commission with the titles of the requested European standards in all the official languages of the Union.

<a id="art-2"></a>
### Article 2 – Work programme

1. CEN, CENELEC and ETSI shall prepare a joint work programme indicating all the standards listed in Annex I, the responsible technical bodies and a timetable for the execution of the requested standardisation activities in line with the deadlines set out in Annex I.

2. CEN, CENELEC and ETSI shall submit the draft work programme to the Commission by [2 months after notification -exact date to be inserted in final Decision] and provide it with access to an overall project plan.

3. CEN, CENELEC and ETSI shall inform the Commission of any amendments to the work programme.

<a id="art-3"></a>
### Article 3 – Reporting

1. CEN, CENELEC and ETSI shall report annually to the Commission on the execution of the request referred to in Article 1, indicating the progress made in implementation of the work programme referred to in Article 2 and providing information on any new standards that need to be prepared or any existing standards that need to be reviewed to meet the requirements referred to in Article 1, paragraph 2.

2. CEN, CENELEC and ETSI shall submit the first joint annual report to the Commission by 31 December 2024 and the final report by 31 December 2025.

3. Without prejudice to the reporting obligations set out in paragraphs 1 and 2, CEN, CENELEC and ETSI shall promptly report to the Commission any major concerns relating to the scope of the request referred to in Article 1 and the deadlines set out in Annex I.

<a id="art-4"></a>
### Article 4 – Validity of the standardisation request

1. If CEN, CENELEC and ETSI do not accept the request referred to in Article 1 within a month of receiving it, the request may not constitute a basis for the standardisation activities referred to in that Article.

2. This Decision shall expire on 30 June 2026.

<a id="art-5"></a>
### Article 5 – Addressee

This Decision is addressed to the European Committee for Standardisation, the European Committee for Electrotechnical Standardisation and the European Telecommunications Standards Institute.

Done at Brussels, 31.7.2024

For the Commission Thierry BRETON Member of the Commission

## Notes

^(1) OJ L 316, 14.11.2012, p. 12, ELI: http://data.europa.eu/eli/reg/2012/1025/oj.

^(2) COM(2022) 142 final.

^(3) Regulation (EU) 2023/1542 of the European Parliament and of the Council of 12 July 2023 concerning batteries and waste batteries, amending Directive 2008/98/EC and Regulation (EU) 2019/1020 and repealing Directive 2006/66/EC (OJ L 191, 28.7.2023, p. 1, ELI: http://data.europa.eu/eli/reg/2023/1542/oj).

^(4) COM(2017) 134 final of 23 March 2017

^(5) SWD(2015) 205 final of 27 October 2015.

^(6) Directive 2014/53/EU of the European Parliament and of the Council of 16 April 2014 on the harmonisation of the laws of the Member States relating to the making available on the market of radio equipment and repealing Directive 1999/5/EC (OJ L 153 22.5.2014, p. 62, ELI: http://data.europa.eu/eli/dir/2014/53/2023-10-01)

<a id="annex-i"></a>
## Annex I – List of European standards to be drafted and deadlines for their adoption as referred to in Article 1

Reference information Deadline for the adoption by the ESOs

1. European standard(s) on unique identifiers 31 December 2025

2. European standard(s) on data carriers and links between physical 31 December 2025 product and digital representation

3. European standard(s) on access rights management, information, 31 December 2025 system security, and business confidentiality

4. European standard(s) on interoperability (technical, semantic, 31 December 2025 organisation)

5. European standard(s) on data processing, data exchange protocols 31 December 2025 and data formats

6. European standard(s) on data storage, archiving, and data persistence 31 December 2025

7. European standard(s) on data authentication, reliability, integrity 31 December 2025

8. European standards on Application Programming Interfaces (APIs) 31 December 2025 for the product passport lifecycle management and searchability

<a id="annex-ii"></a>
## Annex II – Requirements for the standards referred to in Article 1

PART A. GENERAL REQUIREMENTS FOR STANDARDS LISTED IN ANNEX I

1. Definitions and general technical requirements to be supported by the standards

1.1. For the purpose of this Annex, the following definitions apply:

- (1) ‘Product’ means any physical good that is placed on the market or put into service.

- (2) ‘Model’ means a version of a product of which all units share the same technical characteristics and the same model identifier.

- (3) ‘Batch’ means a subset of a specific model composed of all products produced in a specific manufacturing plant at a specific moment in time.

- (4) ‘Item” means a single unit of a model.

- (5) ‘Manufacturer’ means any natural or legal person who manufactures a product or who has such a product designed or manufactured and markets that product under its name or trademark or, in the absence of such person, any natural or legal person who places on the market or puts into service a product.

- (6) ‘Upgrading’ means enhancing the functionality, performance, capacity, or aesthetics of a product.

- (7) ‘Refurbishment’ means preparing or modifying an object that is waste or a product to restore its performance or functionality within the intended use, range of performance and maintenance originally conceived at the design stage, or to meet applicable technical standards or regulatory requirements, with the result of making a fully functional product.

- (8) ‘Maintenance’ means an action carried out to keep a product in a condition where it is able to function as required.

- (9) ‘Repair’ means returning a defective product or waste to a condition where it fulfils its intended use.

- (10) ‘Data carrier’ means a linear bar code symbol, a two-dimensional symbol or other automatic identification data capture medium that can be read by a device.

- (11) ‘Unique product identifier’ means a unique string of characters for the identification of products that also enables a web link to the product passport.

- (12) ‘Unique operator identifier’ means a unique string of characters for the identification of actors involved in the value chain of products.

- (13) ‘Unique facility identifier’ means a unique string of characters for the identification of locations or buildings involved in the value chain of a product or used by actors involved in the value chain of a product.

- (14) ‘Processing’ means processing as defined in Article 3, point (2), of Regulation (EU) 2018/1807 of the European Parliament and of the Council ^(1).

- (15) ‘DPP-system’ means the set of IT standards and protocols required to ensure the full interoperability of product passports and compliance with the requirements referred to in point 2.1.

- (16) ‘DPP-data’ means the information included in a product passport and accessible to different users based on their own respective access rights.

- (17) ‘Decentralised identifier’ means a globally unique persistent identifier that does not require a centralized registration authority and is often generated and/or registered cryptographically.

1.2. The standards to be developed shall reflect the generally acknowledged state of art and be technology-neutral and take into account to the extent possible the energy use and energy efficiency of the DPP-system.

1.3. The standards shall be rooted in existing mature international standards while at the same time taking into consideration new and innovative approaches, provided that a full cross-sectoral interoperability can be guaranteed. In particular, ISO/IEC standards shall be considered first and if necessary, complemented by existing European standards, national standards and fora standards (in this order). A landscape analysis of existing standards to be used for product passport has already been carried out and the results are available at: https://www.standict.eu/landscape-analysis-report/landscape-digital-product-passport-standards.

2. Legal requirements

2.1. The standards shall support the application of the following requirements:

- (a) The product passport shall be connected through a data carrier to a persistent unique product identifier;

- (b) all information included in the product passport shall be based on open standards, developed with an inter-operable format and shall be, as appropriate, machine-readable, structured, and searchable, and transferrable through an open interoperable data exchange network without vendor lock-in;

- (c) product passports shall be fully interoperable with other digital product passports required by Union law in relation to the technical, semantic and organisational aspects of end-to-end communication and data transfer;

- (d) the access to information included in the product passport shall take place in accordance with the specific access rights at product group level identified in applicable Union law;

- (e) customers, end-users, manufacturers, importers and distributors, dealers, professional repairers, refurbishers, remanufacturers, recyclers, market surveillance authorities and customs authorities, civil society organisations, trade unions consumers, economic operators and other relevant actors shall have free of charge and easy access to the product passport based on their respective access rights set out in applicable Union law;

- (f) the data included in the product passports shall be stored by the economic operator responsible for its creation or by operators authorised to act on their behalf;

- (g) if the data included in the product passports is stored or otherwise processed by operators authorised to act on behalf of the economic operator responsible for the creation of the passport, operators shall not be allowed to sell, re-use or process such data, in whole or in part, beyond what is necessary for the provision of the relevant storing or processing services, unless specifically agreed with the economic operator placing the product on the market or putting it into service;

- (h) the product passport shall remain available including after an insolvency, a liquidation or a cessation of activity in the Union of the economic operator that created the product passport;

- (i) the rights to access, introduce, modify or update information in the battery passport shall be restricted based on the access rights specified in applicable Union law;

- (j) data authentication, reliability and integrity shall be ensured;

- (k) product passports shall be designed and operated so that a high level of security and privacy is ensured and fraud is avoided.

2.2. The requirements referred to in point 2.1 shall be taken into account from the beginning and throughout the entire process of developing the standards.

2.3. The standards shall not support any other legal requirements than the requirements referred to in point 2.1.

2.4. The structure of the standards shall be such that a clear distinction can be made between those clauses and sub-clauses of the standards which are necessary to be applied in order to support the requirements referred to in point 2.1 and those which are not. Clauses or sub-clauses which are not necessary shall not compromise or endanger conformity with the requirements referred to in 2.1.

2.5. The standards shall follow the principles laid down in the Union legal framework in the area of cybersecurity, processing of personal data and protection of privacy or networks. Coherence among mechanisms established in that Union legislation shall be ensured. Where applicable cybersecurity certification schemes under Regulation (EU) 2019/881 of the European Parliament and of the Council ^(2) are adopted, the standards shall be developed in a manner coherent with the relevant content of those schemes.

2.6. The standards shall rely, as relevant, on existing similar or equivalent approaches already used in Union legislation.

2.7. Each standard developed on the basis of the request referred to in Article 1 shall refer to this Decision.

2.8. A standard shall not make conformity with that standard dependent on requirements of administrative or organisational nature like management system requirements for organisations, competence requirement for natural persons or through normative references to management system standards of any kind.

2.9. To reduce dependencies between the elements in the set of standards listed in Annex I (the ‘modules’), the standardisation work shall be organized in a modular way to ensure interoperability, reduce lock-in effects, and enable parallel standardisation work. The standards shall be written as formalised avoiding different interpretations.

2.10. The interfaces between the eight modules shall be presented in a meta-structure to ensure the possibility that different standards fulfilling the same function can be used and that the change of a standard within one module does not make it necessary to lead change other modules.

PART B. SPECIFIC REQUIREMENTS FOR THE STANDARDS LISTED IN ANNEX I

1. Standard(s) on unique identifiers

1.1. The standard(s) shall define requirements related to the following areas:

- (1) uniqueness of each identifier (i.e., the same identifier shall not be assigned to different products, different economic operators or different facilities);

- (2) syntax-related requirements;

- (3) semantic-related requirements.

1.2. The standards shall consider the diversity of identifiers currently used by economic operators and accommodate them as much as possible.

1.3. The standard(s) shall allow the possibility to use both ‘centralised’ and ‘decentralised’ identifiers, including the definition of conformance criteria if different methods to produce an identifier are allowed.

1.4. The unique product identifier shall always allow the possibility to include the three different granularity levels, i.e. model, batch, or item. This is needed because product passports of products sold online will only be available at model level, while product passports may need to be available at batch level with the possibility for economic operators to serialise their product passports having a product passport at item level. The move from batch to item level will also be necessary for product groups for which updates of product passports will be expected, for example due to repair activities. In addition, in some cases, for instance batteries covered by Regulation (EU) 2023/1542, the granularity level for the product passport is at item level.

1.5. The standard(s) developed shall adequately take into account typology of identifiers already used in other Union legislations and initiatives.

1.6. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 ISO/IEC 15459: Automatic identification and data capture techniques – Unique identification

 ISO/IEC 61406: Identification Link

 ISO/IEC 29161: Information technology - Data structure - Unique identification for the Internet of Things  ISO/IEC 15418: Information technology - Automatic identification and data capture techniques - GS1 Application Identifiers and ASC MH10 Data Identifiers and maintenance

 ISO/IEC 9834-8:2004: (and RFC 4122): Procedures for generation and registration of Universally Unique Identifiers (UUIDs)

 ISO 17442: Financial services - Legal Entity Identifier (LEI)

 ISO/TR 23249: Blockchain and distributed ledger technologies - Overview of existing DLT systems for identity manage

 ISO/TR 6039: Blockchain and distributed ledger technologies - Identifiers of subjects and objects for the design of blockchain systems

 ISO 22383: Guidelines for selection and performance evaluation of authentication solutions for material goods

 ISO 22385: Guidelines for establishing a Framework for Trust and Interoperability

 ISO 22387: Confirmation procedures for the application of artefact metrics

 ISO 22376: Electronic Storage Specifications for use of Visible Digital Seal (VDS) for the authentication, verification and acquisition of data carried by a document or object

 ISO 22372: Framework for establishing trustworthy supply chains

 ISO/IEC 19762: Information technology - Automatic identification and data capture (AIDC) techniques - Harmonized vocabulary

 ITU-T X.1403: DATA NETWORKS, OPEN SYSTEM COMMUNICATIONS AND SECURITY – Secure applications and services (2) – Distributed ledger technology security

 W3C on DIDs (available at: https://www.w3.org/TR/did-core/)

 W3C on verifiable credentials (available at: https://www.w3.org/TR/vc-data-model/)

 EN IEC 63365: Digital Nameplate – Digital Product Marking

 ISO/IEC 20248: Information technology - Automatic identification and data capture techniques – Digital signature data structure schema

 ISO/IEC 19845:2015: Universal Business Language (UBL) v2.1

 EN 16931-1, -3-2, -3-3: Electronic invoicing – Part 1 Semantic model of core elements, Part 2-3 UBL profile, Part 3-3 CII profile

 ISO 22378: Guidelines for establishing interoperability among independently functioning product identification and related authentication systems

 ISO 22381: Guidelines for establishing interoperability of object identification and authentication systems

 CEFACT Cross Industry Invoice (available at: https://unece.org/fileadmin/DAM/cefact/cf_plenary/2018_plenary/ECE_TRAD E_C_CEFACT_2018_12E.pdf)

2. Standard(s) on data carriers and links between physical product and digital representation

2.1. The standard(s) shall define common rules for how to construct the Automatic Identification and Data Capture (AIDC) media to be used as data carrier linked to the product passport.

2.2. The requirements shall concern, as applicable:

- (a) symbology characteristics;

- (b) data character encoding methods;

- (c) symbol formats;

- (d) dimensional characteristics;

- (e) error correction rules;

- (f) reference decoding algorithm;

- (g) printing quality requirements;

- (h) production quality requirements;

- (i) user-selectable application parameters (if relevant);

- (j) durability requirements.

2.3. The data carrier shall contain links to the product passport. The data carrier shall act as a reference to both the public and the restricted DPP-data (i.e., the information included in each product passport, to be identified at product group level).

2.4. The data carrier may also include control data elements. These elements shall enable the verification of the following:

- (a) the authenticity of the data carrier;

- (b) the product itself.

2.5. In addition, the data carrier may also include cross-sectoral basic data elements, i.e. data that can be consulted offline. These elements shall make it possible to consult data from the data carrier even when the online information cannot be accessed, for example, when:

- (a) the subject reading the data carrier is offline;

- (b) a link present in the data carrier is broken;

- (c) a link does not lead to a valid page on a website;

- (d) the server hosting the product passport is down for maintenance or is overloaded.

2.6. The cross-sectoral basic data elements may include the following six pieces of information:

- (2) the product passport owner (the economic operator who created the product passport);

- (3) unique operator identifier (the main manufacturer, if different from the product passport owner);

- (4) the facility identifier (the location where the main manufacturing stage took place);

- (5) the unique product identifier (identifier of the product registered in the product passport registry);

- (6) an additional product identifier (an optional additional identifier associated to the product);

- (7) the product group (information about the type of product).

2.7. The selection of existing standards or the development of a new standard to meet the requirements in point(s) 2.2 to 2.4 shall be based on an assessment of the benefits and drawbacks of including each of the three kinds of data (DPP data, control data elements and cross-sectoral basic data elements) as part of the common rules for how to create a data carrier.

2.8. In case of a visual data carrier, the possibility of setting a product passport visual identity (i.e., by specifying the colours of the data carrier, including specific text, logo or image into the data carrier, or accompanying the data carrier by a specific text, logo or image, etc.) shall be duly considered.

2.9. The links to the product passport shall include both the link to the public DPP-data and to the restricted DPP-data.

2.10. The control data elements could be a link about how to identify counterfeiting and a hash of the product passport registered in the product passport registry.

2.11. The standard(s) shall also specify how the link between the data carrier and the product passport shall be established, including aspects such as look-up mechanisms. Rules and requirements guaranteeing the persistency of the links shall be integrated, including the links’ portability across resolver services or systems.

2.12. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 EN IEC 61406-1: Identification Link

 EN IEC 63365: Digital Nameplate - Digital Product Marking

 CLC/TR 50489: Smart tracker chips - Feasibility study on the inclusion of RFID in Electrical and Electronic Equipment for WEEE management

 ISO/IEC 24458: Information technology – Automatic identification and data capture techniques – Bar code printer and bar code reader performance testing specification

 ISO/IEC 22603-1: Information technology - Digital representation of product information - Part 1: General requirements

 ISO/IEC 21471: Information technology - Automatic identification and data capture techniques – Extended rectangular data matrix (DMRE) bar code symbology specification

 ISO/IEC 18004: Information technology - Automatic identification and data capture techniques - QR Code bar code symbology specification

 ISO/IEC 16022: Information technology - Automatic identification and data capture techniques – Data Matrix bar code symbology specification

 ISO/IEC 15426-2: Information technology - Automatic identification and data capture techniques - Bar code verifier conformance specification -

<a id="annex-ii-part-2"></a>
### Part 2 – Two-dimensional symbols

 ISO/IEC 15424: Information technology - Automatic identification and data capture techniques – Data Carrier Identifiers (including Symbology Identifiers)

 ISO/IEC 15415: Information technology - Automatic identification and data capture techniques - Bar code symbol print quality test specification - Two-dimensional symbols

 ISO/IEC 15418: Information technology - Automatic identification and data capture techniques - GS1 Application Identifiers and ASC MH10 Data Identifiers and maintenance

 ISO 23354: Business requirements for end‐to‐end visibility of logistics flow

 ISO 15000-2:2021: AS4 profile of ebXML Messaging v3

 PEPPOL eDelivery (available at eDelivery Documentation -OpenPeppol)

 GS1 DataMatrix Guideline (available at: https://www.gs1.org/standards/gs1-datamatrix-guideline/25)

 ISO/IEC NP 18975: Encoding and resolving identifiers over HTTP

 GS1 Digital Link (available at: https://www.gs1.org/standards/gs1-digital-link)

 DIDs (available at: https://www.w3.org/TR/did-core/)

 DID Resolution (available at: https://w3c-ccg.github.io/did-resolution/)

 DID Registration (available at: https://identity.foundation/did-registration/)

 Digital Object Identifier (available at: https://www.iso.org/standard/81599.html)

 Uniform Resource Names (available at: https://www.rfc-editor.org/rfc/rfc8141)

 PEPPOL Service Metadata Locator (available at: https://docs.peppol.eu/edelivery/)

3. Standards on access rights management, information system security and business confidentiality

3.1. Identity management ensures that organisations, individuals, machines, and services are provided with acknowledged identities. The standard(s) shall define clear rules and requirements related to access control measures to regulate the access to restricted product passport information.

3.2. When developing the European standard(s), the following elements shall be adequately considered:

- (a) access rights management shall be attribute-based;

- (b) the economic operators placing the products on the internal market shall be responsible for managing the corresponding product passport access rights (or a service provider contracted by the economic operator);

- (c) the access rights for each information included in the product passport shall be product group specific;

- (d) the public data included in the product passport shall not require any access right management;

- (e) the access rights shall include any mandatory and necessary licensing rules governing items related to data models, data exchange protocols, data processing, and interoperability.

3.3. The standard(s) shall also identify rules to guarantee IT-security, cybersecurity, and data protection.

3.4. The standard(s) shall also address the issue of how to transfer responsibilities, access-rights, and data from one economic operator to another, for example when a product passport needs to be updated to include information related to repair activities performed by a professional repairer.

3.5. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 EN IEC 63278-3: Asset Administration Shell for Industrial Applications – Part 3: Security provisions for Asset Administration Shells.

 ISO 22385: Guidelines for establishing a Framework for Trust and Interoperability

 ISO/IEC 29146: Information technology - Security techniques - A framework for access management

 ISO/IEC 24760: IT Security and Privacy - A framework for identity management

 ISO/IEC 24761: Information technology - Security techniques -Authentication context for biometrics

 ISO/IEC TS 29003: Information technology - Security techniques -Identity proofing

 ISO/IEC 20248: Information technology - Automatic identification and data capture techniques – Digital signature data structure schema

 ISO/IEC 30147: Information technology - Internet of things -Methodology for trustworthiness of IoT system/service

 ISO/IEC AWI 30149: Internet of things (IoT) - Trustworthiness framework

 ISO 15000-2:2021: AS4 profile of ebXML Messaging v3

 ISO/IEC 27040: Information technology - Security techniques - Storage security

 ISO/TR 6039: Blockchain and distributed ledger technologies -Identifiers of subjects and objects for the design of blockchain systems

 ISO 23257 Blockchain and distributed ledger technologies — Reference architecture

 ISO/TS 23635 Blockchain and distributed ledger technologies — Guidelines for governance  ISO/WD TR 23642 Blockchain and distributed ledger technologies -Overview of smart contract security good practice and issues

 ISO/IEC 27040: Information technology - Security techniques - Stage security

 IEC 62443 series

 IEC 63069

 IEC TR 63283-3 and series

 IEC 63278-3 and series

 IEC 61406 series

 ITU-T Rec X.1144 (XACML v3, available at: https://www.itu.int/rec/T-REC-X.1144-201310-I)

 Verifiable Credentials (available at: https://www.w3.org/TR/vc-data-model/)

 ODRL Model (available at: https://www.w3.org/TR/odrl/)

 ODRL Vocabulary (available at: https://www.w3.org/TR/odrl-vocab/)

 OAuth2 (available at: https://oauth.net/2/)

 IETF RFC7515 on JSON Web Signature (available at: https://datatracker.ietf.org/doc/html/rfc7515)

 Certificate Transparency (IETF RFCs 6962 and 9162 available at https://datatracker.ietf.org/doc/rfc6962/ and https://datatracker.ietf.org/doc/rfc9162/)

 OCSP Stapling (IETF RFC 6066, among others, available at https://datatracker.ietf.org/doc/html/rfc6066)

4. Standards on interoperability (technical, semantic, and organisational)

4.1. The standard(s) shall define, inter alia, rules related to the following:

- (a) semantic description of a product, including but not limited to unambiguous meaning and consistent naming and, where relevant, a value list, a specific format and defined units of measure for all quantitative values;

- (b) a common information model allowing for the implementation of dictionary systems;

- (c) metadata models and formats to be used in exchange and representation. The standard(s) shall include rules on how to systematically use such metadata models when developing product group specific data models.

4.2. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 EN IEC 63278: Asset Administration Shell for Industrial Applications

 EN IEC 61360: Standard data element types with associated classification scheme - Part 1: Definitions - Principles and methods

 ISO/IEC 21823: Internet of things (IoT) - Interoperability for IoT systems  Baseline protocol (available at: https://github.com/eea-oasis/baseline-standard/blob/main/core/baseline-core-v1.0-psd01.md)

 ISO 11354-1:2011: Enterprise interoperability framework

5. Standard(s) on data processing, data exchange protocols and data formats

5.1. The standard(s) shall define, inter alia, rules related to the following:

- (a) data exchange protocols, including rules to exchange data between two or more parties;

- (b) processes to introduce, modify, and update information in the product passport.

5.2. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 ISO 9735: Electronic data interchange for administration, commerce and transport (EDIFACT) - Application level syntax rules

 ISO 14533: Processes, data elements and documents in commerce, industry and administration – Long term signature profiles

 ISO/IEC 19845: Universal Business Language (UBL) v2.1

 ISO/IEC 20248: Information technology - Automatic identification and data capture techniques – Digital signature data structure schema

 EN 16931: Electronic invoicing

 ISO 23247: Automation systems and integration - Digital twin framework for manufacturing

 ISO 10303 series: Industrial automation systems and integration -Product data representation and exchange

 ISO 15000-2:2021: AS4 profile of ebXML Messaging v3

 ISO 23354: Business requirements for end‐to‐end visibility of logistics flow

 ISO 15000-2:2021: AS4 profile of ebXML Messaging v3

 EN ISO 23386 Building information modelling and other digital processes used in construction - Methodology to describe, author and maintain properties in interconnected data dictionaries

 EN ISO 12006-3 Building construction — Organization of information about construction works — Part 3: Framework for object-oriented information

 EN 17549-2 Building information modelling – Information structure based on EN ISO 16739 1 to exchange data templates and data sheets for construction objects Part 2. Configurable construction objects and requirements

 ISO 59040 Circular Economy – Product Circularity Data Sheet (under development)

 ISO/CD TR 6277 Blockchain and distributed ledger technologies – Data flow model for blockchain and DLT  ISO/AWI TS 23516 Blockchain and Distributed Ledger Technology — Interoperability Framework

 PEPPOL eDelivery (available at http://peppol.eu/downloads/the-peppol-edelivery-network-specifications/)

 ISO/ IEC 19987 - Information technology — EPC Information Services (EPCIS) Standard

 ISO/ IEC 19988 - Information technology - Core Business Vocabulary Standard

 EPCIS – Automotive Business Vocabulary, VDA 5530 - part 1

 IEC 62720 – Units of Measurement (available as a database standard at https://cdd.iec.ch)

 IEC 61360-4 DB - IEC Common Data Dictionary - IEC CDD) (available as a database standard at https://cdd.iec.ch)

 ECLASS

 W3C Web of Things (WoT) Architecture

 W3C WoT Thing Description (TD)

 SAREF Core Ontologie - ETSI TS 103 264

 UNECE-UN/CEFACT Cross Industry Invoice (available at: https://unece.org/fileadmin/DAM/cefact/cf_plenary/2018_plenary/ECE_TRADE_C_CEFACT_2018_12E.pdf)

 UNECE-UN/CEFACT Supply chain reference data model (available at: https://unece.org/fileadmin/DAM/uncefact/BRS/BRS_SCRDM_v1.0.0.2.pdf)

 UNCCL (available at: https://unece.org/sites/default/files/2022-06/CCL22A.zip)

 UNCL (available at: https://service.unece.org/trade/untdid/d22a/d22a.zip)

 UNLOCODE (available at: https://unece.org/cefact/codesfortrade/codes_index.html)

 OpenIDConnect (available at: https://openid.net/connect/)

 OID4VC (available at: https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0.html)

 OID4VP (available at: https://openid.net/specs/openid-connect-4-verifiable-presentations-1_0-07.html)

 VCs (available at: https://www.w3.org/TR/vc-data-model/)

 JSON-LD (available at: https://www.w3.org/TR/json-ld11/)

 VC-JSON (available at: GitHub - w3c/vc-json-schema/)

 Circular product data exchange use case (available at: https://uncefact.unece.org/display/uncefactpublic/EXTENSION+TEXTI LE+AND+LEATHER+BRS+PART+2%3A+Use+case+and+CCBDA+d ata+structure+supporting+product+circularity- Sustainable Development and Circular Economy Reference Data Model (available at: https://uncefact.unece.org/display/uncefactpublic/Sustainable+Developm ent+and+Circular+Economy+Reference+Data+Model)

 Circular product data exchange structure (available at: https://uncefact.unece.org/display/uncefactpublic/EXTENSION+TEXTI LE+AND+LEATHER+BRS+PART+2%3A+Use+case+and+CCBDA+d ata+structure+supporting+product+circularity)

 Product transparency data exchange structure (available at: https://unece.org/trade/uncefact/mainstandards#:~:text=Product%20Tran sparency%20Message%C2%A0)

 Product traceability data exchange structure (EPCIS) (available at: https://uncefact.unece.org/display/uncefactpublic/JSON-LD+Web+Vocabulary)

 Product transparency data exchange structure (available at: https://uncefact.unece.org/display/uncefactpublic/JSON-LD+Web+Vocabulary)

 Circular product data exchange structure (available at: https://uncefact.unece.org/display/uncefactpublic/EXTENSION+TEXTI LE+AND+LEATHER+BRS+PART+2%3A+Use+case+and+CCBDA+d ata+structure+supporting+product+circularity)

 Sustainable Development and Circular Economy Reference Data Model (available at: https://uncefact.unece.org/display/uncefactpublic/JSON-LD+Web+Vocabulary)

 Product Circularity Data Sheet (available at: https://pcds.lu/wp-content/uploads/2020/11/20200214_Light_PCDS_v3.2s_FORM.pdf)

 GS1 Attribute Definitions for Business (available at: https://www.gs1.org/standards/attribute-definitions-for-business)

 GS1 Global Data Model Attribute Implementation Guide (available at: https://www.gs1.org/standards/gs1-global-data-model-attribute-implementation-guideline/current-standard)

 GS1 Digital Link Standard (available at: https://www.gs1.org/standards/gs1-digital-link)

 GS1 General Specifications (available at: https://www.gs1.org/standards/barcodes-epcrfid-id-keys/gs1-general-specifications)

 GS1 Digital Link Implementation Guideline ((available at: https://www.gs1.org/standards/gs1-digital-link)

 GS1 DataMatrix Guideline (available at: https://www.gs1.org/standards/gs1-datamatrix-guideline/25)

 Global Traceability Standard (available at: https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard)

6. Standards on data storage, archiving and data persistence 6.1. The standard(s) shall define rules for decentralised data storage, archiving and data persistence. The archiving service securely stores historical passport data, preserving a comprehensive record of past information. This feature is particularly relevant for market surveillance purposes. Persistence is required to make sure that data included in the product passports remains available even when the economic operator creating the passport is no longer active.

6.2. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 EN IEC 63278: Asset Administration Shell for Industrial Applications

 Decentralized Web Node (available at: https://identity.foundation/decentralized-web-node/spec/)

 Encrypted Data Vaults (available at: https://identity.foundation/edv-spec/)

 Certificate Transparency (IETF RFCs 6962 and 9162 available at https://datatracker.ietf.org/doc/rfc6962/ and https://datatracker.ietf.org/doc/rfc9162/)

7. Standards on data authentication, reliability and integrity

7.1. The standard(s) shall provide an open and interoperable method between automated identification services and data carriers to read data, verify data originality and data integrity in offline and online use cases. The standard(s) shall establish a framework for ensuring trust, interoperability and interoperation via secure and reliable electronically signed encoded data set (ESEDS) schemes for multi-actor applications in multi-sector environment.

7.2. When developing the standard(s), at least the following elements shall be addressed:

- (a) management and verification of identifiers;

- (b) relationship between the unique identifiers and possible authentication elements related to them;

- (c) questions that deal with the identification of the verifier and any authorised access to privileged product related information;

- (d) verifier access history (logs);

- (e) authentication solutions;

- (f) artefact metrics, where relevant;

- (g) information processing and communication that protects integrity along the supply chain of physical and related electronic documents, products, software and services life cycle to mitigate the risk of product fraud and counterfeit goods, by using object identification techniques;

- (h) verifiable credentials.

7.3. Existing relevant standards shall be duly considered when drafting the new European standard(s). A non-exhaustive list is provided below:

 ISO/IEC 20248: Information technology - Automatic identification and data capture techniques – Digital signature data structure schema  ISO 22378: Guidelines for establishing interoperability among independently functioning product identification and related authentication systems

 ISO 22383: Guidelines for selection and performance evaluation of authentication solutions for material goods

 ISO 22385: Guidelines for establishing a Framework for Trust and Interoperability

 ISO 22387: Confirmation procedures for the application of artefact metrics

 ISO 8000 – Data Quality

 Certificate Transparency (IETF RFCs 6962 and 9162 available at https://datatracker.ietf.org/doc/rfc6962/ and https://datatracker.ietf.org/doc/rfc9162/)

8. Standards on Application Programming Interfaces (APIs) for the product passport lifecycle management and searchability

8.1. The standard(s) aim at harmonising the APIs for automating the management of the product passport throughout its lifecycle and serving remote queries coming from the product passport registry or applications from national authorities.

8.2. Custodians of product passports (either economic operators or service providers) shall make available APIs covering the following:

- (a) CRUD (Create, Read, Update, Delete) operations on products passports;

- (b) remote queries on the products passports under their custodianship.

8.3. When developing the standard(s), at least the following aspectsshall be adequately specified:

- (a) syntax and semantics of the API interfaces;

- (b) security and access control to the APIs;

- (c) performance and response time;

- (d) considerations on versioning and backward compatibility of API interfaces;

- (e) message exchange patterns, for instance synchronous, asynchronous, request-response, fire-and-forget, publish and subscribe;

- (f) availability and scalability;

- (g) mechanisms to ensure the authenticity, integrity and reliability of the data.

8.4. The Study: "APIs4DGov - Digital Government APIs. The Road to value-added Open-driven services” by the JRC (available at https://data.jrc.ec.europa.eu/collection/id-0097) shall be used in the design of the APIs. Furthermore, existing relevant standards shall be duly considered when drafting the new API standard(s). A non-exhaustive list is provided below:

 WS-* standards (available at https://www.oasis-open.org/specs/index.php)  SOAP messaging framework (available at https://www.w3.org/TR/soap12/)

 REST (Representational state transfer) architectural style

 HTTP (available at https://datatracker.ietf.org/doc/html/rfc9112)

 ISO/IEC 21778:2017 - Information technology — The JSON data interchange syntax

 IETF RFC7515 on JSON Web Signature (available at: https://datatracker.ietf.org/doc/html/rfc7515)

 JSON-LD (available at: https://www.w3.org/TR/json-ld11/)

 eDelivery Building Blocks (available at https://ec.europa.eu/digital-building-blocks/wikis/display/DIGITAL/eDelivery)

 PEPPOL eDelivery (available at http://peppol.eu/downloads/the-peppol-edelivery-network-specifications/)

 ISO 15000-2:2021: AS4 profile of ebXML Messaging v3

 ISO 22385: Guidelines for establishing a Framework for Trust and Interoperability

 ISO/IEC 24760: IT Security and Privacy - A framework for identity management

 ISO EN 301549:2015 Accessibility requirements suitable for public procurement of ICT products and services in Europe

 ISO/IEC 19845:2015: Universal Business Language (UBL) v2.1

 ISO/IEC NP 18975: Encoding and resolving identifiers over HTTP

 OpenIDConnect (available at: https://openid.net/connect/)

 OpenID for Verifiable Credentials (available at: https://openid.net/sg/openid4vc/)

 OpenAPI Specification (available at: https://spec.openapis.org/oas/v3.0.3)

 JSON Web Token (available at: https://www.rfc-editor.org/rfc/rfc7519)

## Notes

^(1) Regulation (EU) 2018/1807 of the European Parliament and of the Council of 14 November 2018 on a framework for the free flow of non-personal data in the European Union (OJ L 303, 28.11.2018, p. 59, ELI: http://data.europa.eu/eli/reg/2018/1807/oj).

^(2) Regulation (EU) 2019/881 of the European Parliament and of the Council of 17 April 2019 on ENISA (the European Union Agency for Cybersecurity) and on information and communications technology cybersecurity certification and repealing Regulation (EU) No 526/2013 (Cybersecurity Act) (OJ L 151, 7.6.2019, p. 15, ELI: http://data.europa.eu/eli/reg/2019/881/oj).
