---
act: espr/sreq-m604
version: 2024-07-31_commission-decision
stage: commission-decision
language: de
title: DURCHFÜHRUNGSBESCHLUSS DER KOMMISSION vom 31.7.2024 über einen Normungsauftrag an das Europäische Komitee für Normung, das Europäische Komitee für elektrotechnische Normung und das Europäische Institut für Telekommunikationsnormen im Hinblick auf digitale Produktpässe zur Unterstützung der Unionspolitik in Bezug auf Ökodesign-Anforderungen für nachhaltige Produkte sowie auf Batterien und Altbatterien (Nur der englische, französische und deutsche Text sind verbindlich)
retrieved: '2026-09-27'
converter: tools/pdf2md.py
counts:
  recitals: 30
  articles: 5
  annexes: 2
official_source: https://ec.europa.eu/transparency/documents-register/detail?ref=C(2024)5423&lang=de
reuse: '© European Union, European Commission (Register of Commission documents). Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
extraction: Text extracted from the PDF text layer; headers, footers and page numbers removed, hyphenation joined, structure inferred from the layout, tables flattened. Check wording against the PDF before quoting.
---


# DURCHFÜHRUNGSBESCHLUSS DER KOMMISSION vom 31.7.2024 über einen Normungsauftrag an das Europäische Komitee für Normung, das Europäische Komitee für elektrotechnische Normung und das Europäische Institut für Telekommunikationsnormen im Hinblick auf digitale Produktpässe zur Unterstützung der Unionspolitik in Bezug auf Ökodesign-Anforderungen für nachhaltige Produkte sowie auf Batterien und Altbatterien (Nur der englische, französische und deutsche Text sind verbindlich)

DURCHFÜHRUNGSBESCHLUSS DER KOMMISSION

vom 31.7.2024

über einen Normungsauftrag an das Europäische Komitee für Normung, das Europäische Komitee für elektrotechnische Normung und das Europäische Institut für Telekommunikationsnormen im Hinblick auf digitale Produktpässe zur Unterstützung der Unionspolitik in Bezug auf Ökodesign-Anforderungen für nachhaltige Produkte sowie auf Batterien und Altbatterien

(Nur der englische, französische und deutsche Text sind verbindlich)

DIE EUROPÄISCHE KOMMISSION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union,

gestützt auf die Verordnung (EU) Nr. 1025/2012 des Europäischen Parlaments und des Rates vom 25. Oktober 2012 zur europäischen Normung, zur Änderung der Richtlinien 89/686/EWG und 93/15/EWG des Rates sowie der Richtlinien 94/9/EG, 94/25/EG, 95/16/EG, 97/23/EG, 98/34/EG, 2004/22/EG, 2007/23/EG, 2009/23/EG und 2009/105/EG des Europäischen Parlaments und des Rates und zur Aufhebung des Beschlusses 87/95/EWG des Rates und des Beschlusses Nr. 1673/2006/EG des Europäischen Parlaments und des Rates ^(1), insbesondere auf Artikel 10 Absatz 1,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Die Kommission hat im März 2022 als Teil der Unionspolitik in Bezug auf Ökodesign-Anforderungen an nachhaltige Produkte einen Vorschlag für eine Verordnung des Europäischen Parlament und des Rates zur Schaffung eines Rahmens für die Festlegung von Ökodesign-Anforderungen für nachhaltige Produkte ^(2) mit Vorschriften zur Verbesserung der ökologischen Nachhaltigkeit von Produkten und zur Gewährleistung des freien Verkehrs innerhalb des Binnenmarkts mittels der Festlegung von Ökodesign-Anforderungen, die Produkte erfüllen müssen, um in Verkehr gebracht oder in Betrieb genommen zu werden, angenommen. Mit dem Vorschlag wird eine Anforderung eingeführt, nach der Produkte nur in Verkehr gebracht oder in Betrieb genommen werden dürfen, wenn ein digitaler Produktpass (im Folgenden „Produktpass“) vorliegt, der bestimmten Anforderungen entspricht; ferner werden die Anforderungen an den Produktpass festgelegt.

<a id="rec-2"></a>
(2) Im Rahmen der Politik in Bezug auf Batterien und Altbatterien wurde am 12. Juli 2023 die Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates ^(3) angenommen. Diese Verordnung enthält Anforderungen an die Nachhaltigkeit, Sicherheit, Kennzeichnung und Information, die das Inverkehrbringen und die Inbetriebnahme von Batterien ermöglichen, sowie Vorschriften für die Sammlung, die Behandlung und das Recycling von Altbatterien. Artikel 77 dieser Verordnung sieht vor, dass bestimmte Kategorien von Batterien nur in Verkehr gebracht oder in Betrieb genommen werden dürfen, wenn sie über einen Produktpass (elektronischer Batteriepass) verfügen. In Artikel 78 der Verordnung (EU) 2023/1542 werden die grundlegenden Anforderungen an die technische Gestaltung und den Einsatz des Produktpasses festgelegt.

<a id="rec-3"></a>
(3) Ein Produktpass ist ein Instrument zur Förderung der Nachhaltigkeit von Produkten und des Übergangs zu nachhaltigen Geschäftsmodellen, indem Akteuren entlang der gesamten Wertschöpfungskette Informationen bereitgestellt werden. Die Verfügbarkeit eines Produktpasses verbessert die Rückverfolgbarkeit eines Produkts während seines gesamten Lebenszyklus erheblich, hilft Verbrauchern dabei, fundierte Entscheidungen zu treffen, indem für sie relevante Produktinformationen zugänglich gemacht werden, ermöglicht Wirtschaftsteilnehmern und anderen Akteuren der Wertschöpfungskette wie Reparaturbetrieben oder Recyclingunternehmen den Zugang zu relevanten Informationen und versetzt die zuständigen nationalen Behörden in die Lage, ihre Aufgaben wahrzunehmen. Produktpässe sollten für alle Produkte, Industriesektoren und einschlägige Rechtsvorschriften der Union so einheitlich wie möglich sein und so durchgängig wie möglich verwendet werden, um Unklarheiten und Missverständnisse im Falle von Organisationen oder Industriezweigen, die unterschiedliche semantische oder technische Standards anwenden, zu vermeiden. Zur Förderung dieser Einheitlichkeit sollte der Produktpass gegebenenfalls auch die Aufnahme von Informationen über integrierte Produktkomponenten ermöglichen.

<a id="rec-4"></a>
(4) Die Produktpässe sollten leicht zwischen verschiedenen Systemen und Plattformen ausgetauscht und übergreifend genutzt werden können, um den Informationsaustausch zwischen verschiedenen Interessenträgern wie Herstellern, Lieferanten, Kunden und Regulierungsstellen zu ermöglichen.

<a id="rec-5"></a>
(5) Die Umsetzung von Produktpässen sollte auf Normen beruhen, die klare und kohärente freiwillige Anforderungen vorsehen. Dies sollte die Interoperabilität zwischen verschiedenen Produktpässen erleichtern und den Zeit- und Ressourcenaufwand für ihre Umsetzung und Pflege verringern sowie die Innovation und den Wettbewerb von Marktteilnehmern, die Dienstleistungen im Zusammenhang mit den Produktpässen (Dienstleistungen) anbieten, fördern.

<a id="rec-6"></a>
(6) Der Produktpass sollte so gestaltet und umgesetzt werden, dass je nach Art der Informationen und Art der Interessenträger ein differenzierter Zugang zu den enthaltenen Informationen möglich ist.

<a id="rec-7"></a>
(7) Um zu vermeiden, dass Unternehmen und der Öffentlichkeit Kosten entstehen, die nicht im Verhältnis zu seinem Nutzen stehen, sollte der Produktpass je nach den spezifischen Erfordernissen und der Komplexität der Wertschöpfungskette, der Größe, der Art oder der Auswirkungen der betreffenden Produkte auf Artikel-, Chargen- oder Produktmodellebene definiert sein.

<a id="rec-8"></a>
(8) Die eindeutige Kennung von Produkten ist eine Voraussetzung für die Rückverfolgbarkeit entlang der gesamten Lieferkette. Daher sollte der Produktpass mit einer eindeutigen Produktkennung verknüpft werden. Zudem sollte der Produktpass, sofern angemessen, die Rückverfolgbarkeit der an der gesamten Lieferkette beteiligten Wirtschaftsteilnehmer und Produktionsanlagen ermöglichen.

<a id="rec-9"></a>
(9) Die eindeutige Kennung und das entsprechende Identifizierungssystem des Produktpasses sollten soweit möglich die Interoperabilität mit bestehenden alten Identifizierungssystemen ermöglichen. Im Zuge des Produktpasssystems sollte Produkten ein geeigneter Datenträger zugewiesen werden, der ohne das Herunterladen zusätzlicher Software zugänglich ist. Weiterhin sollen alle Kennungen übertragbar und über ein offenes interoperables Netz für den Datenaustausch ohne Anbieterbindung austauschbar sein, auch über Auflösungsdienste oder -systeme.

<a id="rec-10"></a>
(10) Die Schaffung der Datenträger und der eindeutigen Kennungen sollten gewährleisten, dass die im Produktpass enthaltenen Informationen von allen Wirtschaftsteilnehmern je nach ihren Zugriffsrechten eingesehen, aufgezeichnet und übermittelt werden können, und die Kompatibilität der Datenträger und der eindeutigen Kennungen mit externen Komponenten wie Scangeräten garantieren.

<a id="rec-11"></a>
(11) Um sicherzustellen, dass der Produktpass flexibel, agil und marktgesteuert ist und mit Geschäftsmodellen, Märkten und der Innovation Schritt hält, sollte er auf einem dezentralen Datensystem basieren, das von Wirtschaftsteilnehmern eingerichtet und gepflegt wird. Zu Durchsetzungs- und Überwachungszwecken kann es jedoch erforderlich sein, dass die zuständigen nationalen Behörden und die Kommission unmittelbar Zugang zu sämtlichen dezentralen Datensystemen und damit zu sämtlichen Datenträgern und eindeutigen Kennungen von in Verkehr gebrachten oder in Betrieb genommenen Produkten haben.

<a id="rec-12"></a>
(12) Das Produktpasssystem sollte eine interoperable Ausweitung der Produktpässe auf Grundlage rechtlicher Anforderungen ermöglichen. Die technische Lösung sollte diese Ausweitung im Bedarfsfall zu einem späteren Zeitpunkt zulassen. Die Ausweitung der Produktpässe sollte mindestens Folgendes abdecken: 1) zusätzliche Arten von Daten/Eigenschaften/Attributen und 2) zusätzliche Verzeichnisse.

<a id="rec-13"></a>
(13) Europäische Normen sind wichtige Instrumente, um die Umsetzung der Politik und der Rechtsvorschriften der Union zu unterstützen und ein hohes Maß an Schutz in Bezug auf die Sicherheit und die Grundrechte für alle Menschen in der Union zu gewährleisten. Normen können auch die Schaffung gleicher Wettbewerbs- und Ausgangsbedingungen für die Entwicklung von Produktpässen unterstützen, insbesondere für kleine und mittlere Unternehmen, die Produktpässe und dazugehörige Dienstleistungen entwickeln.

<a id="rec-14"></a>
(14) Um die technische Harmonisierung im Bereich der Produktpässe voranzutreiben und das notwendige technische Umfeld für die Umsetzung der Unionspolitik in Bezug auf Ökodesign-Anforderungen für nachhaltige Produkte und der Verordnung (EU) 2023/1542 vorzubereiten, ist es notwendig, mit der Ausarbeitung europäischer Normen zu beginnen.

<a id="rec-15"></a>
(15) Europäische Normen sollten technologieneutral und leistungsbezogen sein. Sie tragen dazu bei, gleiche Wettbewerbsbedingungen für die einschlägigen Wirtschaftsakteure, insbesondere für kleine und mittlere Unternehmen, zu gewährleisten. Indirekt tragen diese Normen auch dazu bei, die Produktionskosten zum Vorteil der Kunden zu verringern, die Nachhaltigkeit zu erhöhen, den Energieverbrauch des Produktpasssystems einzuschränken und die technische Interoperabilität zu gewährleisten.

<a id="rec-16"></a>
(16) Das Europäische Komitee für Normung (CEN), das Europäische Komitee für elektrotechnische Normung (Cenelec) und das Europäische Institut für Telekommunikationsnormen (ETSI) haben angegeben, dass die Arbeiten, die Gegenstand des Normungsauftrags sind, in ihren Zuständigkeitsbereich fallen.

<a id="rec-17"></a>
(17) Es ist daher angezeigt, das CEN, das Cenelec und das ETSI mit der Ausarbeitung neuer europäischer Normen zur Unterstützung der Unionspolitik in Bezug auf Ökodesign-Anforderungen für nachhaltige Produkte sowie für Batterien und Altbatterien zu beauftragen.

<a id="rec-18"></a>
(18) Gemäß Artikel 5 der Verordnung (EU) 1025/2012 werden die europäischen Normungsorganisationen aufgefordert, alle nötigen Maßnahmen zu ergreifen, um die Einbeziehung kleiner und mittlerer Unternehmen sowie von Organisationen der Zivilgesellschaft, einschließlich Verbraucherorganisationen, in den Normungsprozess und die Konsensbildung sowohl auf nationaler als auch auf Unionsebene zu gewährleisten. Das CEN, das Cenelec und das ETSI sollten daher die für die Gewährleistung einer angemessenen Einbeziehung kleiner und mittlerer Unternehmen sowie von Organisationen der Zivilgesellschaft in der Union erforderlichen Maßnahmen in das Arbeitsprogramm aufnehmen und die erforderlichen Nachweise für diese Maßnahmen im Rahmen der Zwischen- und Abschlussberichte über die Ausführung des Normungsauftrags vorlegen.

<a id="rec-19"></a>
(19) Die in Auftrag gegebenen Normen sollten mit den Grundsätzen der Rechtsvorschriften der Union in Bezug auf die Verarbeitung personenbezogener Daten, den Schutz der Privatsphäre, die Sicherheit von Netz- und Informationssystemen, die Cybersicherheit oder den Schutz vor Betrug sowie mit den zu ihrer Unterstützung eingerichteten technischen Mechanismen im Einklang stehen. Die Kommission, das CEN, das Cenelec und das ETSI sollten zusammenarbeiten, um Lösungen für Fälle zu finden, in denen die Notwendigkeit, diesen Einklang zu gewährleisten, zu praktischen Probleme bei der Entwicklung der europäischen Normen im Rahmen dieses Normungsauftrags führen könnte.

<a id="rec-20"></a>
(20) Europäische Normen sollten ausführliche technische Spezifikationen der wesentlichen Anforderungen enthalten. Darüber hinaus sollten in ihnen auch die Entsprechungen zwischen den technischen Spezifikationen und den wesentlichen Anforderungen, die sie abdecken sollen, eindeutig angegeben sein. Ferner sollten sie den allgemein anerkannten Stand der Technik widerspiegeln. Aufgrund der raschen Weiterentwicklung von Cyberbedrohungen sollten das CEN, das Cenelec und das ETSI den allgemein anerkannten Stand der Technik laufend beobachten, der Kommission unverzüglich Bericht erstatten, sobald eine Entwicklung beobachtet wurde, und ihr einen Plan zur Anpassung bestehender Normen vorlegen.

<a id="rec-21"></a>
(21) Die in Auftrag gegebenen Normen sollten vom CEN, dem Cenelec und dem ETSI innerhalb der in diesem Beschluss festgelegten Fristen angenommen werden. Aufgrund des knappen Zeitplans für die Umsetzung der europäischen Maßnahmen, die die Verwendung des Produktpasses erfordern, können diese Fristen möglicherweise nicht verlängert werden.

<a id="rec-22"></a>
(22) Die auszuarbeitenden Normen sollten hauptsächlich auf bestehenden Normen und bewährten brancheninternen Verfahren auf internationaler Ebene aufbauen, um die Abhängigkeit von proprietären Lösungen zur vermeiden. Daher sollten zunächst bestehende ISO- und IEC-Normen in Betracht gezogen und erforderlichenfalls überarbeitet und durch Spezifikationen aus bestehenden europäischen Normen, nationalen Normen und Normen von Foren (in dieser Reihenfolge) ergänzt werden.

Zur Gewährleistung der semantischen und technischen Interoperabilität sollten beim Normungsprozess auch der Europäische Interoperabilitätsrahmen ^(4) und damit zusammenhängende Ressourcen wie Kernvokabulare, Basisregister, Anwendungsprofile oder das Gemeinsame Bewertungsverfahren für Normen und Spezifikationen (CAMSS – Common Assessment Method for Standards and Specifications) in Betracht gezogen werden.

<a id="rec-23"></a>
(23) Da alle interessierten Kreise einschließlich der Mitgliedstaaten und der europäischen Organisationen von Interessenträgern, die von der Union nach Maßgabe der Verordnung (EU) Nr. 1025/2012 finanziert werden, Bedarf an der Entwicklung neuer Normen anmelden können, könnte es notwendig werden, der Liste von Normen in Anhang I dieses Beschlusses neue Punkte hinzuzufügen. Der Umfang des vorliegenden Auftrags muss daher möglicherweise angepasst werden.

<a id="rec-24"></a>
(24) Die europäischen Normungsorganisationen haben sich bereit erklärt, sich an die Leitlinien für die Ausführung von Normungsaufträgen ^(5) zu halten.

<a id="rec-25"></a>
(25) Zur Gewährleistung von Transparenz und zur Erleichterung der Durchführung der in Auftrag gegebenen Normungstätigkeiten sollten das CEN, das Cenelec und das ETSI ein Arbeitsprogramm ausarbeiten und der Kommission vorlegen.

<a id="rec-26"></a>
(26) Im Hinblick auf eine bessere Überwachung der in Auftrag gegebenen Normungsarbeiten durch die Kommission sollten das CEN, das Cenelec und das ETSI der Kommission einen allgemeinen Projektplan vorlegen, in dem detaillierte Angaben zur Durchführung des Normungsauftrags enthalten sind.

<a id="rec-27"></a>
(27) Gemäß Artikel 10 Absatz 3 der Verordnung (EU) Nr. 1025/2012 steht jeder Normungsauftrag unter dem Vorbehalt seiner Annahme durch die betreffenden europäischen Normungsorganisationen. Daher sind Regelungen bezüglich der Gültigkeit des vorliegenden Normungsauftrags für den Fall festzulegen, dass er vom CEN, dem Cenelec oder dem ETSI nicht angenommen wird.

<a id="rec-28"></a>
(28) Zur Gewährleistung der Rechtssicherheit hinsichtlich der Gültigkeit des Auftrags nach seiner Ausführung ist es angezeigt, ein Datum für das Ende der Geltungsdauer des vorliegenden Beschlusses festzulegen.

<a id="rec-29"></a>
(29) Die europäischen Normungsorganisationen, die europäischen Interessenverbände, die Finanzhilfen der Union erhalten, das Ökodesign-Forum und der nach Artikel 45 der Richtlinie 2014/53/EU des Europäischen Parlaments und des Rates ^(6) eingesetzte Ausschuss für Konformitätsbewertung von Telekommunikationsgeräten und Marktüberwachung wurden konsultiert.

<a id="rec-30"></a>
(30) Die in diesem Beschluss vorgesehenen Maßnahmen entsprechen der Stellungnahme des gemäß Artikel 22 der Verordnung (EU) Nr. 1025/2012 eingesetzten Ausschusses —

HAT FOLGENDEN BESCHLUSS ERLASSEN:

<a id="art-1"></a>
### Artikel 1 – In Auftrag gegebene Normungstätigkeiten

- (1) Das Europäische Komitee für Normung (CEN), das Europäische Komitee für elektrotechnische Normung (Cenelec) und das Europäische Institut für Telekommunikationsnormen (ETSI) werden aufgefordert, die in Anhang I aufgeführten europäischen Normen zur Unterstützung der Unionspolitik in Bezug auf Ökodesign-Anforderungen für nachhaltige Produkte sowie auf Batterien und Altbatterien bis zum 31. Dezember 2025 auszuarbeiten.

- (2) Die in Absatz 1 genannten europäischen Normen müssen die in Anhang II festgelegten Anforderungen erfüllen.

- (3) Das CEN, das Cenelec und das ETSI übermitteln der Kommission die Titel der in Auftrag gegebenen europäischen Normen in allen Amtssprachen der Union.

<a id="art-2"></a>
### Artikel 2 – Arbeitsprogramm

- (1) Das CEN, das Cenelec und das ETSI arbeiten ein gemeinsames Arbeitsprogramm aus, in dem alle in Anhang I genannten Normen, die zuständigen technischen Gremien sowie ein Zeitplan für die Ausführung der in Auftrag gegebenen Normungstätigkeiten gemäß den in Anhang I festgelegten Fristen aufgeführt sind.

- (2) Das CEN, das Cenelec und das ETSI legen de Kommission den Entwurf des Arbeitsprogramms bis zum [2 Monate nach Notifizierung – genaues Datum wird in endgültigem Beschluss eingefügt] vor und gewähren ihr Einblick in einen allgemeinen Projektplan.

- (3) Das CEN, das CENELEC und das ETSI unterrichten die Kommission über alle Änderungen am Arbeitsprogramm.

<a id="art-3"></a>
### Artikel 3 – Berichterstattung

- (1) Das CEN, das Cenelec und das ETSI erstatten der Kommission jährlich Bericht über die Ausführung des in Artikel 1 genannten Auftrags und legen dabei die Fortschritte bei der Durchführung des in Artikel 2 genannten Arbeitsprogramms dar und liefern Informationen über alle neuen Normen, die vorbereitet werden müssen, oder alle bestehenden Normen, die überarbeitet werden müssen, um die in Artikel 1 Absatz 2 genannten Anforderungen zu erfüllen.

- (2) Das CEN, das Cenelec und das ETSI legen der Kommission den ersten gemeinsamen Jahresbericht bis zum 31. Dezember 2024 und den Abschlussbericht bis zum 31. Dezember 2025 vor.

- (3) Unbeschadet der Berichterstattungspflichten nach den Absätzen 1 und 2 teilen das CEN, das Cenelec und das ETSI der Kommission wichtige Bedenken in Bezug auf den Umfang des Auftrags nach Artikel 1 und die Fristen nach Anhang I unverzüglich mit.

<a id="art-4"></a>
### Artikel 4 – Gültigkeit des Normungsauftrags

- (1) Nimmt das CEN, das Cenelec oder das ETSI den Auftrag nach Artikel 1 nicht innerhalb eines Monats nach dessen Eingang an, so kann er nicht als Grundlage für die im genannten Artikel aufgeführten Normungstätigkeiten dienen.

- (2) Die Geltungsdauer des vorliegenden Beschlusses endet am 30. Juni 2026.

<a id="art-5"></a>
### Artikel 5 – Adressat

Dieser Beschluss ist an das Europäische Komitee für Normung, das Europäische Komitee für elektrotechnische Normung und das Europäische Institut für Telekommunikationsnormen gerichtet.

Brüssel, den 31.7.2024

Für die Kommission Thierry BRETON Mitglied der Kommission

## Fußnoten

^(1) ABl. L 316 vom 14.11.2012, S. 12, ELI: http://data.europa.eu/eli/reg/2012/1025/oj.

^(2) COM(2022) 142 final.

^(3) Verordnung (EU) 2023/1542 des Europäischen Parlaments und des Rates vom 12. Juli 2023 über Batterien und Altbatterien, zur Änderung der Richtlinie 2008/98/EG und der Verordnung (EU) 2019/1020 und zur Aufhebung der Richtlinie 2006/66/EG (ABl. L 191 vom 28.7.2023, S. 1, ELI: http://data.europa.eu/eli/reg/2023/1542/oj).

^(4) COM(2017) 134 final vom 23. März 2017.

^(5) SWD(2015) 205 final vom 27. Oktober 2015.

^(6) Richtlinie 2014/53/EU des Europäischen Parlaments und des Rates vom 16. April 2014 über die Harmonisierung der Rechtsvorschriften der Mitgliedstaaten über die Bereitstellung von Funkanlagen auf dem Markt und zur Aufhebung der Richtlinie 1999/5/EG (ABl. L 153 vom 22.5.2014, S. 62, ELI: http://data.europa.eu/eli/dir/2014/53/2023-10-01).

<a id="annex-i"></a>
## Anhang I – Liste der auszuarbeitenden europäischen Normen und Fristen für ihre Annahme nach Artikel 1

Referenzangaben Frist für die Annahme durch die europäischen Normungsorganisationen

1. Europäische Norm(en) für eindeutige Kennungen 31. Dezember 2025

2. Europäische Norm(en) für Datenträger und Verknüpfungen 31. Dezember 2025 zwischen physischem Produkt und digitaler Darstellung

3. Europäische Norm(en) für die Verwaltung von Zugriffsrechten, 31. Dezember 2025 Informationen, Systemsicherheit und die Wahrung von Geschäftsgeheimnissen

4. Europäische Norm(en) für die (technische, semantische und 31. Dezember 2025 organisatorische) Interoperabilität

5. Europäische Norm(en) für die Datenverarbeitung, 31. Dezember 2025 Datenaustauschprotokolle und Datenformate

6. Europäische Norm(en) für die Speicherung, Archivierung und 31. Dezember 2025 Persistenz von Daten

7. Europäische Norm(en) für die Authentifizierung, 31. Dezember 2025 Zuverlässigkeit und Integrität von Daten

8. Europäische Normen für 31. Dezember 2025 Anwendungsprogrammierschnittstellen (APIs) für die Lebenszyklusverwaltung, Auffindbarkeit und Durchsuchbarkeit des Produktpasses

<a id="annex-ii"></a>
## Anhang II – Anforderungen an die Normen gemäß Artikel 1

TEIL A. ALLGEMEINE ANFORDERUNGEN AN DIE IN ANHANG I AUFGEFÜHRTEN NORMEN

1. Definitionen und allgemeine technische Anforderungen, die durch die Normen unterstützt werden sollen

1.1. Für die Zwecke dieses Anhangs bezeichnet der Ausdruck

- (1) „Produkt“ jede physische Ware, die in Verkehr gebracht oder in Betrieb genommen wird;

- (2) „Modell“ eine Version eines Produkts, bei der sämtliche Produkteinheiten die gleichen technischen Merkmale und dieselbe Modellkennung aufweisen;

- (3) „Charge“ eine Untermenge eines bestimmten Modells, die aus allen in einem bestimmten Herstellungsbetrieb zu einem bestimmten Zeitpunkt hergestellten Produkten besteht;

- (4) „Artikel“ eine einzige Produkteinheit eines Modells;

- (5) „Hersteller“ jede natürliche oder juristische Person, die ein Produkt herstellt bzw. entwickeln oder herstellen lässt und dieses unter ihrem eigenen Namen oder ihrer eigenen Marke vermarktet; gibt es keine solche Person, so gilt jede natürliche oder juristische Person als Hersteller, die ein Produkt in Verkehr bringt oder in Betrieb nimmt;

- (6) „Nachrüstung“ die Verbesserung der Funktionalität, Leistung, Kapazität oder Ästhetik eines Produkts;

- (7) „Überholung“ die Vorbereitung oder Veränderung eines Gegenstands, bei dem es sich um Abfall oder ein Produkt handelt, zur Wiederherstellung seiner Leistung oder Funktionalität, die im Rahmen des in der Produktentwicklungsphase ursprünglich vorgesehenen Verwendungszwecks, Leistungsbereichs sowie der vorgesehenen Wartung festgelegt wurde, oder zur Einhaltung geltender technischer Normen oder rechtlicher Anforderungen, mit dem Ergebnis, dass ein voll funktionsfähiges Produkt entsteht;

- (8) „Wartung“ eine Maßnahme, die durchgeführt wird, um ein Produkt in einem Zustand zu halten, in dem es gemäß den Anforderungen funktionieren kann;

- (9) „Reparatur“ eine Maßnahme, die durchgeführt wird, um ein fehlerhaftes Produkt oder Abfall in einen Zustand zurückzuversetzen, in dem der vorgesehene Verwendungszweck erfüllt wird;

- (10) „Datenträger“ einen Strichcode, ein zweidimensionales Symbol oder ein anderes automatisches Datenerfassungsmedium, das von einem Gerät gelesen werden kann;

- (11) „eindeutige Produktkennung“ eine eindeutige Zeichenfolge zur Identifizierung von Produkten, die auch einen Weblink zum Produktpass ermöglicht;

- (12) „eindeutige Kennung des Wirtschaftsteilnehmers“ eine eindeutige Zeichenfolge zur Identifizierung der an der Wertschöpfungskette von Produkten beteiligten Akteure;

- (13) „eindeutige Kennung der Einrichtung“ eine eindeutige Zeichenfolge zur Identifizierung von Standorten oder Gebäuden, die an der Wertschöpfungskette eines Produkts beteiligt sind oder von Akteuren genutzt werden, die an der Wertschöpfungskette eines Produkts beteiligt sind;

- (14) „Verarbeitung“ Verarbeitung im Sinne des Artikels 3 Nummer 2 der Verordnung (EU) 2018/1807 des Europäischen Parlaments und des Rates ^(1);

- (15) „DPP-System“ die Gesamtheit der IT-Normen und -Protokolle, die zur Gewährleistung der vollen Interoperabilität von Produktpässen und der Einhaltung der unter Nummer 2.1 genannten Anforderungen erforderlich sind;

- (16) „DPP-Daten“ die Informationen, die in einem Produktpass erhalten und verschiedenen Nutzern auf der Grundlage ihrer jeweiligen Zugriffsrechte zugänglich sind;

- (17) „dezentrale Kennung“ eine weltweit eindeutige, dauerhafte Kennung, für die keine zentralisierte Registrierungsstelle erforderlich ist und die häufig kryptografisch generiert und/oder registriert wird.

1.2. Die auszuarbeitenden Normen müssen dem allgemein anerkannten Stand der Technik entsprechen, technologieneutral sein und soweit möglich den Energieverbrauch und die Energieeffizienz des DPP-Systems berücksichtigen.

1.3. Die Normen müssen auf bestehenden ausgereiften internationalen Normen aufbauen und gleichzeitig neue und innovative Ansätze berücksichtigen, sofern eine umfassende sektorübergreifende Interoperabilität gewährleistet werden kann. Insbesondere ISO- und IEC-Normen müssen als Erstes in Betracht gezogen und erforderlichenfalls durch bestehende europäische Normen, nationale Normen und Normen von Foren (in dieser Reihenfolge) ergänzt werden. Eine Lageanalyse hinsichtlich bestehender Normen, die für den Produktpass zu verwenden sind, wurde bereits durchgeführt; die Ergebnisse sind abrufbar unter: https://www.standict.eu/landscape-analysis-report/landscape-digital-product-passport-standards.

2. Rechtliche Anforderungen

2.1. Die Normen müssen die Anwendung folgender Anforderungen unterstützen:

a) Der Produktpass muss mittels eines Datenträgers mit einer dauerhaften eindeutigen Produktkennung verbunden sein.

b) Alle im Produktpass enthaltenen Informationen müssen auf offenen Standards gründen, in einem interoperablen Format entwickelt und gegebenenfalls maschinenlesbar, strukturiert, auffindbar, durchsuchbar und mittels eines offenen interoperablen Netzes für den Datenaustausch ohne Anbieterbindung übertragbar sein.

c) Produktpässe müssen in Bezug auf die technischen, semantischen und organisatorischen Aspekte der Ende-zu-Ende-Kommunikation und der Datenübertragung vollständig interoperabel mit anderen digitalen Produktpässen sein, die gemäß den Unionsvorschriften vorgeschrieben sind. d) Der Zugang zu den im Produktpass enthaltenen Informationen muss gemäß den spezifischen Zugriffsrechten auf Produktgruppenebene erfolgen, die in geltendem Unionsrecht festgelegt sind.

e) Kunden, Endverbraucher, Hersteller, Einführer und Vertreiber, Händler, fachlich kompetente Reparaturbetriebe, Wiederaufarbeiter, Wiederverwerter, Recyclingunternehmen, Marktüberwachungsbehörden und Zollbehörden, Organisationen der Zivilgesellschaft, Gewerkschaften, Verbraucher, Wirtschaftsteilnehmer und andere relevante Akteure müssen auf der Grundlage ihrer jeweiligen Zugriffsrechte nach geltendem Unionsrecht kostenlos und leicht auf den Produktpass zugreifen können.

f) Die in den Produktpässen enthaltenen Daten müssen von dem für seine Ausstellung verantwortlichen Wirtschaftsakteur oder von Akteuren, die befugt sind, in dessen Namen zu handeln, gespeichert werden.

g) Werden die in den Produktpässen enthaltenen Daten von Akteuren, die befugt sind, im Namen des für die Erstellung des Passes verantwortlichen Wirtschaftsteilnehmers zu handeln, gespeichert oder anderweitig verarbeitet, dürfen die Akteure diese Daten weder ganz noch teilweise auf eine Art verkaufen, weiterverwenden oder verarbeiten, die über das für die Erbringung der betreffenden Speicher- oder Verarbeitungsdienste erforderliche Maß hinausgeht, es sei denn, dies wurde mit dem Wirtschaftsteilnehmer, der das Produkt in Verkehr bringt oder in Betrieb nimmt, ausdrücklich vereinbart.

h) Der Produktpass muss auch nach einer Insolvenz, Liquidation oder Einstellung der Tätigkeit in der Union des Wirtschaftsteilnehmers, der den Produktpass erstellt hat, verfügbar bleiben.

i) Die Rechte auf Zugriff zu Informationen im Batteriepass sowie auf deren Aufnahme, Änderung oder Aktualisierung müssen auf Grundlage der im geltenden Unionsrecht festgelegten Zugriffsrechte eingeschränkt werden.

j) Die Authentifizierung, Zuverlässigkeit und Integrität der Daten müssen gewährleistet werden.

k) Produktpässe müssen so gestaltet und eingesetzt werden, dass ein hohes Maß an Sicherheit und Privatsphäre gewährleistet und Betrug vermieden wird.

2.2. Die unter Nummer 2.1 genannten Anforderungen müssen von Beginn des Verfahrens der Normentwicklung an und in seinem gesamten Verlauf berücksichtigt werden.

2.3. Die Normen dürfen keine anderen als die unter Nummer 2.1 genannten rechtlichen Anforderungen unterstützen.

2.4. Die Normen müssen so gegliedert sein, dass eindeutig unterschieden werden kann, welche Abschnitte und Unterabschnitte der Normen zur Unterstützung der unter Nummer 2.1 genannten Anforderungen angewandt werden müssen und welche nicht. Nicht angewandte Abschnitte und Unterabschnitte dürfen keine Beschränkung oder Gefährdung der Konformität mit den in Nummer 2.1 genannten Anforderungen darstellen.

2.5. Die Normen müssen die Grundsätze des Rechtsrahmens der Union im Bereich Cybersicherheit, Verarbeitung personenbezogener Daten und Schutz der Privatsphäre oder der Netze befolgen. Die Kohärenz zwischen den in jenen Vorschriften der Union festgelegten Mechanismen muss gewährleistet sein. Werden anwendbare Schemata für die Cybersicherheitszertifizierung gemäß der Verordnung (EU) 2019/881 des Europäischen Parlaments und des Rates ^(2) angenommen, so müssen die Normen in einer Weise ausgearbeitet werden, die mit dem relevanten Inhalt dieser Systeme im Einklang steht.

2.6. Die Normen müssen sich gegebenenfalls auf bestehende ähnliche oder gleichwertige Ansätze stützen, die bereits in den Rechtsvorschriften der Union Anwendung finden.

2.7. Jede Norm, die auf der Grundlage des in Artikel 1 genannten Auftrags ausgearbeitet wird, muss sich auf den vorliegenden Beschluss beziehen.

2.8. Eine Norm darf die Konformität mit der Norm nicht von verwaltungstechnischen oder organisatorischen Anforderungen abhängig machen, wie etwa Anforderungen an das Managementsystem für Organisationen, Anforderungen an die Kompetenz natürlicher Personen, oder von normativen Verweisen auf Managementsystemnormen jeglicher Art.

2.9. Zur Verringerung von Abhängigkeiten zwischen den Elementen der in Anhang I aufgeführten Normgruppen (im Folgenden „Module“) muss die Normungsarbeit modular aufgebaut sein, um Interoperabilität zu gewährleisten, Anbieterabhängigkeiten zu verringern und gleichzeitig erfolgende Normungsarbeiten zu ermöglichen. Die Normen müssen so formuliert sein, dass unterschiedliche Auslegungen vermieden werden.

2.10. Die Schnittstellen zwischen den acht Modulen müssen in einer Metastruktur dargestellt werden, um zu gewährleisten, dass unterschiedliche Normen, die die gleiche Funktion erfüllen, verwendet werden können und die Änderung einer Norm innerhalb eines Moduls keine Änderung anderer Module erfordert.

TEIL B. SPEZIFISCHE ANFORDERUNGEN AN DIE IN ANHANG I AUFGEFÜHRTEN NORMEN

1. Normen für eindeutige Kennungen

1.1. In den Normen sind Anforderungen in Bezug auf folgende Bereiche festzulegen:

1) Eindeutigkeit jeder Kennung (z. B. darf eine Kennung nicht verschiedenen Produkten, Wirtschaftsteilnehmern oder Einrichtungen zugewiesen werden),

2) syntaxbezogene Anforderungen,

3) semantikbezogene Anforderungen.

1.2. Die Normen müssen die Vielfalt der derzeit von den Wirtschaftsteilnehmern verwendeten Kennungen berücksichtigen und so weit wie möglich aufnehmen.

1.3. In den Normen muss die Möglichkeit geboten werden, sowohl „zentralisierte“ als auch „dezentrale“ Kennungen zu verwenden; dabei sind Konformitätskriterien für den Fall festzulegen, dass unterschiedliche Methoden zur Erstellung einer Kennung zulässig sind.

1.4. Die eindeutige Produktkennung muss immer die Möglichkeit bieten, die drei verschiedenen Granularitätsstufen aufzunehmen, z. B. Modell, Charge oder Artikel.

Dies ist erforderlich, da Produktpässe von Produkten, die im Internet verkauft werden, nur auf Modellebene verfügbar sein werden, während Produktpässe möglicherweise auf Chargenebene verfügbar sein müssen mit der Möglichkeit für Wirtschaftsteilnehmer, ihre Produktpässe serienmäßig zu erstellen und so einen Produktpass auf Artikelebene zu erhalten. Die Übertragung von Chargen- auf Artikelebene wird auch für Produktgruppen erforderlich sein, für die Aktualisierungen von Produktpässen zu erwarten sind, z. B. aufgrund von Reparaturarbeiten. Darüber hinaus liegt die Granularität des Produktpasses in einigen Fällen, beispielsweise bei Batterien, die unter die Verordnung (EU) 2023/1542 fallen, auf Artikelebene.

1.5. In den ausgearbeiteten Normen muss die Art der Kennungen, die bereits in anderen Rechtsvorschriften und Initiativen der Union verwendet werden, in angemessenem Umfang berücksichtigt werden.

1.6. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 ISO/IEC 15459: Verfahren der automatischen Identifikation und Datenerfassung – Eindeutige Identifikation

 ISO/IEC 61406: Identifizierungslink

 ISO/IEC 29161: Informationstechnik – Datenstruktur – Eindeutige Identifikation für IoT

 ISO/IEC 15418: Informationstechnik – Automatische Datenerfassung und Identifikation – GS1 Datenbezeichner und ASC MH10 Datenbezeichner und deren Pflege

 ISO/IEC 9834-8:2004 (und RFC 4122): Verfahrensregeln für die Generierung und Registrierung universell eindeutiger Kennzeichen (UUIDs)

 ISO 17442: Finanzdienstleistungen – Identifikator für juristische Personen (LEI)

 ISO/TR 23249: Blockchain und Technologien für verteilte elektronische Journale – Überblick über bestehende DLT-Systeme für das Identitätsmanagement

 ISO/TR 6039: Blockchain und Technologien für verteilte elektronische Journale – Kennzeichen von Subjekten und Objekten für die Gestaltung von Blockchain-Systemen

 ISO 22383: Richtlinien und Leistungskriterien für Authentifizierungslösungen für materielle Güter

 ISO 22385: Richtlinien für die Schaffung eines Rahmens für Vertrauen und Interoperabilität

 ISO 22387: Bestätigungsverfahren für die Anwendung von Artefakt-Metriken

 ISO 22376: Elektronische Speicherspezifikationen für die Verwendung des Sichtbaren Digitalen Siegels (VDS) für die Authentifizierung, Verifizierung und Erfassung von Daten auf einem Dokument oder Objekt

 ISO 22372: Rahmen für die Schaffung vertrauenswürdiger Lieferketten

 ISO/IEC 19762: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren (AIDC) – Harmonisiertes Vokabular  ITU-T X.1403: DATENNETZE, SICHERHEIT VON UND KOMMUNIKATION ZWISCHEN OFFENEN SYSTEMEN – Sichere Anwendungen und Dienste (2) – Sicherheit von Technologie für verteilte elektronische Journale

 W3C-Empfehlung zu dezentralen Kennungen (abrufbar unter: https://www.w3.org/TR/did-core/)

 W3C-Empfehlung zu verifizierbaren digitalen Nachweisen (abrufbar unter: https://www.w3.org/TR/vc-data-model/)

 EN IEC 63365: Digitales Typenschild – Digitale Produktkennzeichnung

 ISO/IEC 20248: Informationstechnik – Automatische Identifikations- und Datenerfassungstechniken – Datenstrukturschema für digitale Signaturen

 ISO/IEC 19845:2015: Universal business language (UBL) v2.1

 EN 16931-1, -3-2, -3-3: Elektronische Rechnungsstellung – Teil 1: Semantisches Datenmodell der Kernelemente, Teil 2-3 UBL-Profil, Teil 3-3: Cross-Industry-Invoice-Profil

 ISO 22378: Leitfaden zur Etablierung von Interoperabilität zwischen unabhängig funktionierender Produktidentifikation und damit verbundenen Authentifizierungssystemen

 ISO 22381: Leitfaden zur Etablierung von Interoperabilität zwischen Objektidentifizierungssystemen und Authentifizierungssystemen

 CEFACT Cross Industry Invoice (abrufbar unter: https://unece.org/fileadmin/DAM/cefact/cf_plenary/2018_plenary/ECE_TRAD E_C_CEFACT_2018_12E.pdf)

2. Normen für Datenträger und Verknüpfungen zwischen physischem Produkt und digitaler Darstellung

2.1. In den Normen sind gemeinsame Regelungen für den Aufbau der Speichermedien zur automatischen Identifikation und Datenerfassung (AIDC) für deren Verwendung als mit dem Produktpass verknüpfte Datenträger festzulegen.

2.2. Die Anforderungen müssen gegebenenfalls folgendes betreffen:

a) Symbologie-Eigenschaften

b) Methoden zur Zeichenkodierung der Daten

c) Symbolformate

d) Eigenschaften hinsichtlich der Dimension

e) Regeln zur Fehlerkorrektur

f) Den Referenzdekodierungsalgorithmus

g) Anforderungen an die Druckqualität

h) Anforderungen an die Produktionsqualität

i) vom Nutzer wählbare Anwendungsparameter (falls zutreffend)

j) Anforderungen an die Lebensdauer

2.3. Der Datenträger muss mit dem Produktpass verknüpft sein. Der Datenträger muss als Bezugspunkt für sowohl öffentlich als auch eingeschränkt zugängliche DPP-Daten (z. B. die in jedem Produktpass enthaltenen Informationen auf Produktgruppenebene) dienen.

2.4. Der Datenträger kann auch Kontrolldatenelemente enthalten. Diese Elemente müssen die Verifizierung von Folgendem ermöglichen:

a) der Authentizität des Datenträgers,

b) des Produkts selbst.

2.5. Darüber hinaus kann der Datenträger auch sektorübergreifende Basisdatenelemente d. h. offline abrufbare Daten enthalten. Diese Elemente sollen ermöglichen, dass aus dem Datenträger auch Daten abgelesen werden können, wenn kein Zugriff auf die Online-Informationen möglich ist, z. B. in folgenden Fällen:

a) Beim Lesen des Datenträgers besteht keine Internetverbindung.

b) Ein Link im Datenträger ist defekt.

c) Ein Link führt zu keiner gültigen Seite einer Website.

d) Der Hostserver des Produktpass ist aufgrund von Wartungsarbeiten geschlossen oder überlastet.

2.6. Die sektorübergreifenden Basisdatenelemente können die folgenden sechs Angaben enthalten:

1) den Inhaber des Produktpasses (den Wirtschaftsteilnehmer, der den Produktpass erstellt hat),

2) die eindeutige Kennung des Wirtschaftsteilnehmers (des Haupthersteller, falls nicht identisch mit dem Inhaber des Produktpasses),

3) die Kennung der Einrichtung (des Ortes, an dem die Hauptherstellungsphase erfolgte),

4) die eindeutige Produktkennung (im Produktpassregister registrierte Kennung des Produkts),

5) eine zusätzliche Produktkennung (eine optionale zusätzliche Kennung in Verbindung mit dem Produkt),

6) die Produktgruppe (Informationen zum Produkttyp).

2.7. Die Auswahl bestehender Normen oder die Ausarbeitung einer neuen Norm zur Erfüllung der unter Nummer 2.2 bis 2.4 aufgeführten Anforderungen muss als Teil der gemeinsamen Vorschriften für die Erstellung eines Datenträgers auf einer Bewertung der Vor- und Nachteile der Einbeziehung jeder der drei Datenarten (DPP-Daten, Kontrolldatenelemente und sektorübergreifende Basisdatenelemente) gründen.

2.8. Handelt es sich um einen visuellen Datenträger, ist die Möglichkeit der Erstellung einer visuellen Kennung (z. B. durch Festlegung der Farben des Datenträgers wie auch eines spezifischen Textes, Logos oder Bilds im Datenträger oder die Beilegung eines spezifischen Textes, Logos oder Bilds usw.) gebührend zu berücksichtigen.

2.9. Die Links zum Produktpass müssen sowohl einen Link zu den öffentlich als auch den eingeschränkt zugänglichen DPP-Daten enthalten.

2.10. Mögliche Kontrolldatenelemente wären unter anderem ein Link zur Identifizierung von Fälschungen und ein Hash des im Produktpassregister registrierten Produktpasses.

2.11. In den Normen ist auch festzulegen, wie die Verknüpfung zwischen dem Datenträger und dem Produktpass erfolgen soll, auch im Hinblick auf Aspekte wie Suchfunktionen. Regeln und Anforderungen zur Gewährleistung der Persistenz der Verknüpfungen müssen integriert werden, darunter auch die Übertragbarkeit der Verknüpfungen zwischen Auflösungsdiensten oder -systemen.

2.12. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 EN IEC 61406-1: Identifizierungslink

 EN IEC 63365: Digitales Typenschild – Digitale Produktkennzeichnung

 CLC/TR 50489: Smart tracker chips – Machbarkeitsstudie zur Einbeziehung von RFID in Elektro- und Elektronikgeräte für deren Entsorgung

 ISO/IEC 24458: Informationstechnik – Automatische Identifikationsund Datenerfassungstechniken – Testspezifikation für Barcodedrucker und Barcodeleser

 ISO/IEC 22603-1: Informationstechnik – Digitale Darstellung von Produktinformationen – Teil 1: Allgemeine Anforderungen

 ISO/IEC 21471: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren – Erweiterte rechteckige Data Matrix (DMRE) – Barcode-Symbologie-Spezifikation

 ISO/IEC 18004: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren – Spezifikation der Barcode-Symbologie „QR Code“

 ISO/IEC 16022: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren – Data Matrix-Barcode-Symbologie-Spezifikation

 ISO/IEC 15426-2: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren – Prüfanforderungen für Strichcodeprüfgeräte – Teil 2: Zweidimensionale Symbologien

 ISO/IEC 15424: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren – Datensatz-Identifikatoren (inklusive Symbologie-Identifikatoren)

 ISO/IEC 15415: Informationstechnik – Automatische Identifikation und Datenerfassungsverfahren – Testspezifikation für Strichcode-Druckqualität – 2D-Symbole

 ISO/IEC 15418: Informationstechnik – Automatische Datenerfassung und Identifikation – GS1 Datenbezeichner und ASC MH10 Datenbezeichner und deren Pflege

 ISO 23354: Geschäftsanforderungen für die Ende-zu-Ende Sichtbarkeit von Logistikabläufen  ISO 15000-2:2021: Aussage zur Anwendbarkeit des ebXML Messaging-Service-Profils

 eDelivery, die elektronische Zustellung des paneuropäischen öffentlichen Auftragswesens online (PEPPOL) (abrufbar unter eDelivery Documentation – OpenPeppol)

 Die Leitlinie zur GS1-Datenmatrix (abrufbar unter: https://www.gs1.org/standards/gs1-datamatrix-guideline/25)

 ISO/IEC NP 18975: Kodierung und Auflösung von Identifikatoren über HTTP

 Der GS1 Digital Link Standard (abrufbar unter: https://www.gs1.org/standards/gs1-digital-link)

 Dezentrale Kennungen (abrufbar unter: https://www.w3.org/TR/did-core/)

 Auflösung von dezentralen Kennungen (abrufbar unter: https://w3c-ccg.github.io/did-resolution/)

 Registrierung dezentraler Kennungen (abrufbar unter: https://identity.foundation/did-registration/)

 Digitale Objektkennung (abrufbar unter: https://www.iso.org/standard/81599.html)

 Uniform Resource Names (abrufbar unter: https://www.rfc-editor.org/rfc/rfc8141)

 Der Service-Metadata-Locator (SML) des paneuropäischen öffentlichen Auftragswesens online (PEPPOL) (abrufbar unter: https://docs.peppol.eu/edelivery/)

3. Normen für die Verwaltung von Zugriffsrechten, Informationen, Systemsicherheit und die Wahrung von Geschäftsgeheimnissen

3.1. Das Identitätsmanagement stellt sicher, dass Organisationen, Einzelpersonen, Maschinen und Dienstleistungen über anerkannte Kennungen verfügen. In den Normen sind klare Regelungen und Anforderungen in Bezug auf Maßnahmen der Zugriffskontrolle zur Regulierung des Zugriffs auf eingeschränkt zugängliche Informationen im Produktpass festzulegen.

3.2. Bei der Ausarbeitung der europäischen Normen sind die folgenden Elemente angemessen zu berücksichtigen:

a) Die Verwaltung von Zugriffsrechten muss attributbasiert sein.

b) Die Wirtschaftsteilnehmer, die die Produkte auf dem Binnenmarkt in Verkehr bringen, haben für die Verwaltung der entsprechenden Zugangsrechte zum Produktpass Verantwortung zu tragen (oder ein von dem Wirtschaftsteilnehmer beauftragter Dienstleister).

c) Die Zugriffsrechte für jede im Produktpass enthaltene Information müssen produktspezifisch sein.

d) Die im Produktpass enthaltenen öffentlichen Daten dürfen keine Verwaltung von Zugriffsrechten erfordern. e) Die Zugriffsrechte müssen alle verbindlichen und erforderlichen Lizenzvorschriften für Datenmodelle, Datenaustauschprotokolle, Datenverarbeitung und Interoperabilität umfassen.

3.3. In den Normen sind auch Vorschriften zur Gewährleistung der IT-Sicherheit, Cybersicherheit und des Datenschutzes festzulegen.

3.4. Weiterhin muss in den Normen behandelt werden, wie Zuständigkeiten, Zugriffsrechte und Daten von einem Wirtschaftsteilnehmer auf einen anderen übertragen werden können, wenn beispielsweise ein Produktpass aktualisiert werden muss, um Informationen über Reparaturtätigkeiten eines fachlich kompetenten Reparateurs aufzunehmen.

3.5. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 EN IEC 63278-3: Verwaltungsschale für industrielle Anwendungen – Teil 3 Sicherheitsvorschriften für Verwaltungsschalen

 ISO 22385: Richtlinien für die Schaffung eines Rahmens für Vertrauen und Interoperabilität

 ISO/IEC 29146: Informationstechnologie – Sicherheitstechniken – Ein Rahmenwerk für die Zugangsverwaltung

 ISO/IEC 24760: Informationstechnik – Sicherheitsverfahren – Rahmenwerk für Identitätsmanagement

 ISO/IEC 24761: Informationstechnik – Sicherheitsverfahren – Authentifizierungskontext für Biometrie

 ISO/IEC TS 29003: Informationstechnik – Sicherheitsverfahren – Nachweisen von Identitäten

 ISO/IEC 20248: Informationstechnik – Automatische Identifikationsund Datenerfassungstechniken – Datenstrukturschema für digitale Signaturen

 ISO/IEC 30147: Informationstechnik – Internet der Dinge (IoT) – Methodik für die Vertrauenswürdigkeit von IoT-Systemen/Diensten

 ISO/IEC AWI 30149: Internet der Dinge (IoT) – Vertrauenswürdigkeitsrahmen

 ISO 15000-2:2021: Aussage zur Anwendbarkeit des ebXML Messaging-Service-Profils

 ISO/IEC 27040: Informationstechnik – IT-Sicherheitsverfahren – Speichersicherheit

 ISO/TR 6039: Blockchain und Technologien für verteilte elektronische Journale – Kennzeichen von Subjekten und Objekten für die Gestaltung von Blockchain-Systemen

 ISO 23257: Blockchain und Technologien für verteilte elektronische Journale – Referenzarchitektur

 ISO 23635: Blockchain und Technologien für verteilte elektronische Journale – Leitlinien zur Governance  ISO/WD TR 23642: Blockchain und Technologien für verteilte elektronische Journale – Überblick über bewährte Verfahren und Probleme im Bereich der Sicherheit von Smart Contracts

 ISO/IEC 27040: Informationstechnik – IT-Sicherheitsverfahren – Speichersicherheit

 IEC-Reihe 62443

 IEC 63069

 IEC TR 63283-3 und Reihe

 IEC TR 63278-3 und Reihe

 IEC-Reihe 61406

 ITU-T Rec X.1144 (XACML v3, abrufbar unter: https://www.itu.int/rec/T-REC-X.1144-201310-I)

 Verifizierbare digitale Nachweise (abrufbar unter: https://www.w3.org/TR/vc-data-model/)

 ODRL-Modell (abrufbar unter: https://www.w3.org/TR/odrl/)

 ODRL-Vokabular (abrufbar unter: https://www.w3.org/TR/odrl-vocab/)

 OAuth2 (abrufbar unter: https://oauth.net/2/)

 IETF RFC7515 zur JSON Websignatur (abrufbar unter: https://datatracker.ietf.org/doc/html/rfc7515)

 Certificate Transparency (IETF RFCs 6962 und 9162, abrufbar unter https://datatracker.ietf.org/doc/rfc6962/ und https://datatracker.ietf.org/doc/rfc9162/)

 OCSP Stapling (IETF RFC 6066, unter anderem, abrufbar unter https://datatracker.ietf.org/doc/html/rfc6066)

4. Normen für die (technische, semantische oder organisatorische) Interoperabilität

4.1. In den Normen sind unter anderem Regelungen in Bezug auf folgende Bereiche festzulegen:

a) die semantische Beschreibung eines Produkts, einschließlich, aber nicht beschränkt auf eine eindeutige Bedeutung und gegebenenfalls eine Wertliste, ein bestimmtes Format und festgelegte Maßeinheiten für alle quantitativen Werte,

b) ein gemeinsames Informationsmodell, das die Einführung von Wörterbuchsystemen ermöglicht,

c) Metadatenmodelle und -formate für den Austausch und die Darstellung. Die Normen müssen Vorschriften für die systematische Verwendung solcher Metadatenmodelle bei der Entwicklung produktgruppenspezifischer Datenmodelle enthalten.

4.2. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 EN IEC 63278: Verwaltungsschale für industrielle Anwendungen  EN IEC 61360: Genormte Datenelementtypen mit Klassifikationsschema für elektrische Betriebsmittel – Teil 1: Definitionen – Regeln und Methoden

 ISO/IEC 21823: Internet of things (IoT) – Interoperabilität für Internet of things Systeme

 Baseline-Protokoll (abrufbar unter: https://github.com/eea-oasis/baseline-standard/blob/main/core/baseline-core-v1.0-psd01.md)

 ISO 11354-1:2011: Rahmenwerk für die Unternehmensinteroperabilität

5. Normen für die Datenverarbeitung, Datenaustauschprotokolle und Datenformate

5.1. In den Normen sind unter anderem Regelungen in Bezug auf folgende Bereiche festzulegen:

a) Datenaustauschprotokolle, einschließlich Regeln für den Datenaustausch zwischen zwei oder mehr Parteien,

b) Prozesse zur Eingabe, Modifizierung und Aktualisierung von Informationen im Produktpass.

5.2. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 ISO 9735: Elektronischer Datenaustausch für Verwaltung, Wirtschaft und Transport (EDIFACT) – Syntax-Regeln auf Anwendungsebene

 ISO 14533: Prozesse, Datenelemente und Dokumente in Handel, Industrie und Verwaltung – Langzeit-Signaturprofile

 ISO/IEC 19845: Universal business language (UBL) v2.1

 ISO/IEC 20248: Informationstechnik – Automatische Identifikationsund Datenerfassungstechniken – Datenstrukturschema für digitale Signaturen

 EN 16931: Elektronische Rechnungsstellung

 ISO 23247: Automatisierungssysteme und Integration – Rahmenwerk für Digitale Zwillinge für das verarbeitende Gewerbe

 IEC-Reihe 10303: Industrielle Automatisierungssysteme und Integration – Produktdatendarstellung und -austausch

 ISO 15000-2:2021: Aussage zur Anwendbarkeit des ebXML Messaging-Service-Profils

 ISO 23354: Geschäftsanforderungen für die Ende-zu-Ende Sichtbarkeit von Logistikabläufen

 ISO 15000-2:2021: Aussage zur Anwendbarkeit des ebXML Messaging-Service-Profils

 EN ISO 23386: Bauwerksinformationsmodellierung und andere digitale Prozesse im Bauwesen – Methodik zur Beschreibung, Erstellung und Pflege von Merkmalen in miteinander verbundenen Datenkatalogen

 EN ISO 12006-3: Bauwesen – Organisation von Daten zu Bauwerken – Teil 3: Struktur für den objektorientierten Informationsaustausch  EN 17549-2: Building Information Modeling – Datenstruktur nach EN ISO 16739-1 für den Austausch von Datenvorlagen und Datenblättern für Bauobjekte – Teil 2: Konfigurierbare Produkte und Anforderungen

 ISO 59040: Circular Economy – Datenblatt zur Produktzirkularität

 ISO/CD TR 6277: Blockchain und Technologien für verteilte elektronische Journale – Datenflussmodell für Blockchain und DLT

 ISO/AWI TS 23516: Blockchain und Technologien für verteilte elektronische Journale – Rahmenwerk für die Interoperabilität

 eDelivery, die elektronische Zustellung des paneuropäischen öffentlichen Auftragswesens online (PEPPOL) (abrufbar unter http://peppol.eu/downloads/the-peppol-edelivery-network-specifications/)

 ISO/IEC 19987: Informationstechnik – EPC Informationsservice – Spezifikation

 ISO/IEC 19988: Informationstechnik – GS1 Core Business Vokabular (CBV)

 EPCIS – Automotive Business Vocabulary, VDA 5530 – Teil 1

 IEC 62720: Maßeinheiten (abrufbar als Datenbanknorm unter https://cdd.iec.ch)

 IEC 61360-4 DB: Gemeinsames IEC-Datenbeschreibungsverzeichnis (IEC CDD) (abrufbar als Datenbanknorm unter https://cdd.iec.ch)

 ECLASS

 W3C Web of Things (WoT) Architektur

 W3C WoT Thing Description (TD)

 SAREF-Kernontologie – ETSI TS 103 264

 UNECE-UN/CEFACT Cross Industry Invoice (abrufbar unter: https://unece.org/fileadmin/DAM/cefact/cf_plenary/2018_plenary/ECE_TRADE_C_CEFACT_2018_12E.pdf)

 UNECE-UN/CEFACT Lieferketten-Referenzdatenmodell (abrufbar unter: https://unece.org/fileadmin/DAM/uncefact/BRS/BRS_SCRDM_v1.0.0.2.pdf)

 UNCCL (abrufbar unter: https://unece.org/sites/default/files/2022-06/CCL22A.zip)

 UNCL (abrufbar unter: https://service.unece.org/trade/untdid/d22a/d22a.zip)

 UNLOCODE (abrufbar unter: https://unece.org/cefact/codesfortrade/codes_index.html)

 OpenIDConnect (abrufbar unter: https://openid.net/connect/)

 OID4VC (abrufbar unter: https://openid.net/specs/openid-4-verifiable-credential-issuance-1_0.html)  OID4VP (abrufbar unter: https://openid.net/specs/openid-connect-4-verifiable-presentations-1_0-07.html)

 Verifizierbare digitale Nachweise (abrufbar unter: https://www.w3.org/TR/vc-data-model/)

 JSON-LD (abrufbar unter: https://www.w3.org/TR/json-ld11/)

 VC-JSON (abrufbar unter: GitHub - w3c/vc-json-schema/)

 Austausch von Daten zu kreislauforientierten Produkten – Anwendungsfall (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/EXTENSION+TEXTI LE+AND+LEATHER+BRS+PART+2%3A+Use+case+and+CCBDA+d ata+structure+supporting+product+circularity

 Nachhaltige Entwicklung und Kreislaufwirtschaft – Referenzdatenmodell (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/Sustainable+Developm ent+and+Circular+Economy+Reference+Data+Model)

 Austausch von Daten zu kreislauforientierten Produkten – Struktur (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/EXTENSION+TEXTI LE+AND+LEATHER+BRS+PART+2%3A+Use+case+and+CCBDA+d ata+structure+supporting+product+circularity)

 Datenaustauschstruktur für Produkttransparenz (abrufbar unter: https://unece.org/trade/uncefact/mainstandards#:~:text=Product%20Tran sparency%20Message%C2%A0)

 Datenaustauschstruktur für die Rückverfolgbarkeit von Produkten (EPCIS) (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/JSON-LD+Web+Vocabulary)

 Datenaustauschstruktur für Produkttransparenz (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/JSON-LD+Web+Vocabulary)

 Austausch von Daten zu kreislauforientierten Produkten – Struktur (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/EXTENSION+TEXTI LE+AND+LEATHER+BRS+PART+2%3A+Use+case+and+CCBDA+d ata+structure+supporting+product+circularity)

 Nachhaltige Entwicklung und Kreislaufwirtschaft – Referenzdatenmodell (abrufbar unter: https://uncefact.unece.org/display/uncefactpublic/JSON-LD+Web+Vocabulary)

 Datenblatt zur Kreislauffähigkeit von Produkten (abrufbar unter: https://pcds.lu/wp-content/uploads/2020/11/20200214_Light_PCDS_v3.2s_FORM.pdf)

 GS1 Attribute Definitions for Business (abrufbar unter: https://www.gs1.org/standards/attribute-definitions-for-business)  Umsetzungsleitfaden für Attribute im Rahmen des Globalen Datenmodells von GS1 (abrufbar unter: https://www.gs1.org/standards/gs1-global-data-model-attribute-implementation-guideline/current-standard)

 Der GS1 Digital Link Standard (abrufbar unter: https://www.gs1.org/standards/gs1-digital-link)

 GS1 – Allgemeine Spezifikationen (abrufbar unter: https://www.gs1.org/standards/barcodes-epcrfid-id-keys/gs1-general-specifications)

 Umsetzungsleitfaden zum GS1 Digital Link Standard (abrufbar unter: https://www.gs1.org/standards/gs1-digital-link)

 Die Leitlinie zur GS1-Datenmatrix (abrufbar unter: https://www.gs1.org/standards/gs1-datamatrix-guideline/25)

 Globaler GS1 Rückverfolgbarkeitsstandard (abrufbar unter: https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard)

6. Normen für die Speicherung, Archivierung und Persistenz von Daten

6.1. In den Normen sind unter anderem Regelungen in Bezug auf die dezentrale Speicherung, Archivierung und Persistenz von Daten festzulegen. Der Archivierungsdienst speichert historische Passdaten auf sichere Weise und unterhält so ein umfassendes Verzeichnis früherer Informationen. Dies ist insbesondere für die Marktüberwachung von besonderer Bedeutung. Persistenz ist erforderlich, um dafür zu sorgen, dass die im Produktpass enthaltenen Daten auch dann zugänglich bleiben, wenn der Wirtschaftsteilnehmer, der den Pass erstellt hat, nicht mehr tätig ist.

6.2. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 EN IEC 63278: Verwaltungsschale für industrielle Anwendungen

 Dezentrale Webknoten (abrufbar unter: https://identity.foundation/decentralized-web-node/spec/)

 Verschlüsselte Data Vaults (abrufbar unter: https://identity.foundation/edv-spec/)

 Certificate Transparency (IETF RFCs 6962 und 9162, abrufbar unter https://datatracker.ietf.org/doc/rfc6962/ und https://datatracker.ietf.org/doc/rfc9162/)

7. Normen für die Authentifizierung, Zuverlässigkeit und Integrität von Daten

7.1. Die Normen müssen eine offene und interoperable Methode für das Lesen sowie die Überprüfung der Originalität und Integrität von Daten zwischen automatisierten Identifizierungsdiensten und Datenträgern sowohl in Anwendungsfällen online als auch offline enthalten. Mit den Normen muss mittels sicherer und zuverlässiger elektronisch unterzeichneter kodierter Datensatzschemata (electronically signed encoded data set – ESEDS) für Anwendungen mit mehreren Akteuren im sektorübergreifenden Raum ein Rahmen zur Gewährleistung von Vertrauen, Interoperabilität und Interoperation geschaffen werden.

7.2. Bei der Ausarbeitung der Normen sind zumindest die folgenden Elemente zu behandeln:

a) die Verwaltung und Verifizierung von Kennungen,

b) die Beziehung zwischen den eindeutigen Kennungen und möglichen mit ihnen verbundenen Authentifizierungselementen,

c) Fragen hinsichtlich der Identifizierung der Prüfer und jeglichen autorisierten Zugangs zu vertraulichen produktbezogenen Informationen,

d) die Aufzeichnung der Zugriffe durch Prüfer (logs),

e) Authentifizierungslösungen,

f) gegebenenfalls die Artefakt-Metrik,

g) eine Informationsverarbeitung und Kommunikation im Sinne des Schutzes der Integrität physischer und damit verbundener elektronischer Dokumente, Produkte, Software und Dienstleistungen entlang der Lieferkette und über deren gesamten Lebenszyklus, um das Risiko von Produktbetrug und nachgeahmten Waren durch den Einsatz von Objektidentifizierungstechniken zu mindern,

h) verifizierbare digitale Nachweise.

7.3. Bestehende einschlägige Normen sind bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 ISO/IEC 20248: Informationstechnik – Automatische Identifikationsund Datenerfassungstechniken – Datenstrukturschema für digitale Signaturen

 ISO 22378: Leitfaden zur Etablierung von Interoperabilität zwischen unabhängig funktionierender Produktidentifikation und damit verbundenen Authentifizierungssystemen

 ISO 22383: Richtlinien und Leistungskriterien für Authentifizierungslösungen für materielle Güter

 ISO 22385: Richtlinien für die Schaffung eines Rahmens für Vertrauen und Interoperabilität

 ISO 22387: Bestätigungsverfahren für die Anwendung von Artefakt-Metriken

 ISO 8000: Datenqualität

 Certificate Transparency (IETF RFCs 6962 und 9162, abrufbar unter https://datatracker.ietf.org/doc/rfc6962/ und https://datatracker.ietf.org/doc/rfc9162/)

8. Normen für Anwendungsprogrammierschnittstellen (APIs) für die Lebenszyklusverwaltung, Auffindbarkeit und Durchsuchbarkeit des Produktpasses

8.1. Das Ziel der Normen ist die Harmonisierung der APIs zur Automatisierung der Verwaltung des Produktpasses während seines gesamten Lebenszyklus und für Fernabfragen aus dem Produktpassregister oder Anwendungen nationaler Stellen.

8.2. Die Verwahrer von Produktpässen (Wirtschaftsteilnehmer oder Dienstleister) müssen APIs zur Verfügung stellen, die Folgendes abdecken: a) das Erstellen, Lesen, Aktualisieren oder Löschen von Produktpässen (CRUD-Operationen – Create, Read, Update, Delete),

b) die Fernabfrage von Produktpässen unter ihrer Verwahrung.

8.3. Bei der Ausarbeitung der Normen sind zumindest die folgenden Aspekte angemessen anzugeben:

a) die Syntax und die Semantik der API-Schnittstellen,

b) die Sicherheit der und die Zugriffskontrolle zu den APIs,

c) die Leistung und die Ansprechzeit,

d) Überlegungen zur Versionierung und Rückwärtskompatibilität von API-Schnittstellen,

e) Nachrichtenübermittlungsmuster, z. B. synchron, asynchron, Request-Response, Fire-and-Forget oder Publish-and-Subscribe,

f) Verfügbarkeit und Skalierbarkeit,

g) Mechanismen zur Gewährleistung der Authentizität, Integrität und Zuverlässigkeit der Daten.

8.4. Die Studie „APIs4DGov - Digital Government APIs – The Road to value-added Open-driven services“ der JRC (abrufbar unter: https://data.jrc.ec.europa.eu/collection/id-0097) muss bei der Gestaltung der APIs verwendet werden. Darüber hinaus sind bestehende einschlägige Normen bei der Ausarbeitung der neuen europäischen Normen gebührend zu berücksichtigen. Es folgt eine nicht erschöpfende Liste:

 WS-*-Normen (abrufbar unter: https://www.oasis-open.org/specs/index.php)

 SOAP messaging framework (abrufbar unter: https://www.w3.org/TR/soap12/)

 REST-Architekturstil (Representational State Transfer)

 HTTP (abrufbar unter: https://datatracker.ietf.org/doc/html/rfc9112)

 ISO/IEC 21778:2017: Das JSON Datenaustauschformat

 IETF RFC7515 zur JSON Websignatur (abrufbar unter: https://datatracker.ietf.org/doc/html/rfc7515)

 JSON-LD (abrufbar unter: https://www.w3.org/TR/json-ld11/)

 der eDelivery-Baustein (abrufbar unter: https://ec.europa.eu/digital-building-blocks/wikis/display/DIGITAL/eDelivery)

 eDelivery, die elektronische Zustellung des paneuropäischen öffentlichen Auftragswesens online (PEPPOL) (abrufbar unter: http://peppol.eu/downloads/the-peppol-edelivery-network-specifications/)

 ISO 15000-2:2021: Aussage zur Anwendbarkeit des ebXML Messaging-Service-Profils

 ISO 22385: Richtlinien für die Schaffung eines Rahmens für Vertrauen und Interoperabilität  ISO/IEC 24760: Informationstechnik – Sicherheitsverfahren – Rahmenwerk für Identitätsmanagement

 ISO EN 301549:2015: Anforderungen an die Barrierefreiheit für öffentliche Beschaffung von IKT-Produkten und -Dienstleistungen in Europa

 ISO/IEC 19845:2015: Universal business language (UBL) v2.1

 ISO/IEC NP 18975: Kodierung und Auflösung von Identifikatoren über HTTP

 OpenIDConnect (abrufbar unter: https://openid.net/connect/)

 OpenID für verifizierbare digitale Nachweise (abrufbar unter: https://openid.net/sg/openid4vc/)

 OpenAPI Specification (abrufbar unter: https://spec.openapis.org/oas/v3.0.3)

 JSON Web Token (abrufbar unter: https://www.rfc-editor.org/rfc/rfc7519)

## Fußnoten

^(1) Verordnung (EU) 2018/1807 des Europäischen Parlaments und des Rates vom 14. November 2018 über einen Rahmen für den freien Verkehr nicht personenbezogener Daten in der Europäischen Union (ABl. L 303 vom 28.11.2018, S. 59, ELI: http://data.europa.eu/eli/reg/2018/1807/oj).

^(2) Verordnung (EU) 2019/881 des Europäischen Parlaments und des Rates vom 17. April 2019 über die ENISA (Agentur der Europäischen Union für Cybersicherheit) und über die Zertifizierung der Cybersicherheit von Informations- und Kommunikationstechnik und zur Aufhebung der Verordnung (EU) Nr. 526/2013 (Rechtsakt zur Cybersicherheit) (ABl. L 151 vom 7.6.2019, S. 15, ELI: http://data.europa.eu/eli/reg/2019/881/oj).
