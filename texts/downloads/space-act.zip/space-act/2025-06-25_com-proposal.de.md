---
act: space-act
version: 2025-06-25_com-proposal
stage: com-proposal
language: de
celex: 52025PC0335
title: Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES über die Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten in der Union
retrieved: '2026-09-24'
converter: tools/eurlex2md.py
counts:
  recitals: 140
  articles: 119
  annexes: 7
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52025PC0335
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES über die Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten in der Union

<a id="begr-ndung"></a>
## BEGRÜNDUNG

### 1. KONTEXT DES VORSCHLAGS

#### • Gründe und Ziele des Vorschlags

Die Weltraumtätigkeiten nehmen weltweit rasch zu, angekurbelt durch die steigende Nachfrage nach weltraumgestützten Daten und Weltraumdiensten und durch sinkende Kosten für die Herstellung und den Start von Satelliten. Die Weltraumwirtschaft hat auch neue Marktteilnehmer gewonnen.

Um diese Ausweitung der Weltraumtätigkeiten und die zunehmende Beteiligung neuer kommerzieller Akteure an grenzüberschreitenden Weltraumtätigkeiten zu flankieren, haben 13 Mitgliedstaaten nationale Rechtsvorschriften für den Bereich Weltraum erlassen. Damit wird den völkerrechtlichen Verpflichtungen Rechnung getragen, die eine Überwachung der Weltraumtätigkeiten verlangen. Der daraus resultierende Flickenteppich von Regulierungsansätzen führt zu einem fragmentierten Binnenmarkt. Diese Fragmentierung dürfte zunehmen, da weitere Mitgliedstaaten beabsichtigen, Rechtsrahmen für Weltraumtätigkeiten zu schaffen.

Unterschiede bei den nationalen Ansätzen zum Schutz der Sicherheit, Resilienz und ökologischen Nachhaltigkeit der Weltrauminfrastruktur können sich negativ auf die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten in der Union auswirken. Dies beeinträchtigt letztlich die Wettbewerbsfähigkeit der Weltraumindustrie in der Union und das Funktionieren grenzüberschreitender Wertschöpfungsketten. Das allgemeine Ziel der vorliegenden Initiative besteht darin, die Entwicklung und das Funktionieren des Binnenmarkts für die Weltraumwirtschaft zu unterstützen. Im Einzelnen zielt die Initiative auf Folgendes ab:

- • Schaffung eines Unionsrechtsrahmens für die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten durch Unionsbetreiber im Bereich Weltraum, um Innovationen zu fördern und ein stabiles, berechenbares und wettbewerbliches Geschäftsumfeld zu schaffen;

- • Sicherstellung der Verfolgbarkeit von Weltraumobjekten und Verringerung der Entstehung von Weltraummüll, wodurch die Sicherheit von Weltraumtätigkeiten erhöht wird;

- • Schaffung eines Risikobewertungsrahmens, der auf die spezifischen Anforderungen an die Cybersicherheit der Weltrauminfrastruktur zugeschnitten ist, wodurch sich die Resilienz von Weltraumtätigkeiten erhöht;

- • Schaffung einer gemeinsamen Methode für die Berechnung der Umweltauswirkungen von Weltraumtätigkeiten in der Union, wodurch die Nachhaltigkeit von Weltraumtätigkeiten verbessert wird.

Mit der Initiative sollen die Rechtssicherheit, die die Unionsbetreiber im Bereich Weltraum für die Durchführung von Weltraumtätigkeiten benötigen, geschaffen und die Wettbewerbsfähigkeit der Weltraumindustrie gefördert sowie zugleich die Risiken, die sich aus dem exponentiellen Wachstum der Weltraumtätigkeiten ergeben, angegangen und die langfristige Nutzung des Weltraums sichergestellt werden.

In den politischen Leitlinien für die Europäische Kommission 2024-2029^(1(1) sowie im Draghi-Bericht zur Zukunft der europäischen Wettbewerbsfähigkeit wird die Weltraumwirtschaft als strategischer Schlüsselsektor für die Union^(2(2) genannt, und es wird die Empfehlung ausgesprochen, in naher Zukunft einen gemeinsamen Unionsrechtsrahmen für einen funktionierenden Binnenmarkts im Bereich Weltraum zu schaffen. Die Kommission hat den vorgeschlagenen EU-Weltraum-Rechtsakt in zwei kürzlich veröffentlichten gemeinsamen Mitteilungen zu den wichtigsten Prioritäten erklärt: im Ansatz der EU für das Weltraumverkehrsmanagement und in der EU-Weltraumstrategie für Sicherheit und Verteidigung^(3(3). Die vorliegende Gesetzgebungsinitiative entspricht den Forderungen der Mitgliedstaaten nach einer Maßnahme zur Schaffung eines Binnenmarkts für Weltraumtätigkeiten durch einen kohärenten und stabilen Regelungsrahmen. In den jüngsten Schlussfolgerungen des Rates haben die Mitgliedstaaten anerkannt, dass die Fragmentierung des Binnenmarkts für Weltraumdienste und -produkte verhindert und die globale Wettbewerbsfähigkeit der Weltraumindustrie der Union gestärkt werden müssen^(4(4). Sie bestätigten die Bedeutung von Maßnahmen der Union zur Sicherstellung der Gleichbehandlung von Betreibern im Bereich Weltraum und gleicher Wettbewerbsbedingungen für die Weltraumindustrie der Union^(5(5). Auch die nationalen Parlamente haben anerkannt, dass es wichtig es ist, einen Rechtsrahmen zu schaffen, um die langfristige Nachhaltigkeit des Bereichs Weltraum sicherzustellen^(6(6). Die Weltraumindustrie, einschließlich kleiner und mittlerer Unternehmen (KMU), hat ebenfalls ihre Unterstützung für einen klaren und vorhersehbaren Rechtsrahmen zum Ausdruck gebracht^(7(7).

#### • Kohärenz mit den bestehenden Vorschriften in diesem Bereich

Der Vertrag der Vereinten Nationen über die Grundsätze zur Regelung der Tätigkeiten von Staaten bei der Erforschung und Nutzung des Weltraums (Weltraumvertrag) regelt – unter Hervorhebung des Grundsatzes der staatlichen Verantwortung – die weltweiten ordnungspolitischen Rahmenbedingungen in Bezug auf den Weltraum. Er verpflichtet die Staaten, ihre Weltraumtätigkeiten zu genehmigen, zu beaufsichtigen und für sie die Verantwortung zu übernehmen. Das Fehlen spezifischer verbindlicher technischer Vorschriften zur Umsetzung der allgemeinen Verpflichtungen des Weltraumvertrags hat jedoch zu unterschiedlichen Genehmigungsanforderungen geführt, da die Mitgliedstaaten unterschiedliche Regulierungsansätze verfolgt haben.

Heute gibt es in dreizehn Mitgliedstaaten nationale Rechtsvorschriften zum Thema Weltraum. Andere Mitgliedstaaten sind dabei, Rechtsvorschriften für den Bereich Weltraum auszuarbeiten oder bestehende Rechtsvorschriften zu aktualisieren, um mit dem Aufkommen neuer Marktteilnehmer und deren sich ausweitenden Tätigkeiten Schritt zu halten. Die mangelnde Koordinierung zwischen den verschiedenen Regulierungsansätzen hat zu einer fragmentierten Regulierungslandschaft geführt, in der neu auftretende Hindernisse das Funktionieren des Binnenmarkts für Weltraumdienste und weltraumgestützte Daten in der Union beeinträchtigen könnten.

Mit dem vorgeschlagenen EU-Weltraum-Rechtsakt wird der Rechtsrahmen in der gesamten Union harmonisiert, indem in den nationalen Rechtsvorschriften für den Bereich Weltraum festgelegte Anforderungen integriert werden, um Überschneidungen, Doppelarbeit und Konflikte zu vermeiden und das Funktionieren des Binnenmarkts zu verbessern.

#### • Kohärenz mit der Politik der Union in anderen Bereichen

Was erstens die Resilienz betrifft, hat die Union Rechtsvorschriften zur Cybersicherheit (NIS-2-Richtlinie) und zur physischen Resilienz kritischer Einrichtungen (CER-Richtlinie) erlassen, die die Resilienz der Bodeninfrastruktur zur Unterstützung von Weltraumdiensten stärken.

Während die NIS-2-Richtlinie die Bodensegment-Betreiber einerseits und die Anbieter elektronischer Kommunikation andererseits betrifft, decken weder die NIS-2-Richtlinie noch die CER-Richtlinie unionseigene Ressourcen ab, die im Rahmen des Weltraumprogramms der Union betrieben werden. Daher bieten sie keinen vollständigen Risikomanagementrahmen für alle Segmente der Weltrauminfrastruktur oder alle Betreiber im Bereich Weltraum.

Mit dem vorgeschlagenen EU-Weltraum-Rechtsakt wird diese Lücke geschlossen, indem spezifische und klare Cybersicherheitsvorschriften festgelegt werden, die für alle Betreiber im Bereich Weltraum und Ressourcen der Weltrauminfrastruktur gelten, wodurch eine maßgeschneiderte Basis für die Resilienz der Weltraumwirtschaft geschaffen wird. Die öffentlichen und privaten Interessenträger der Weltraumwirtschaft erhalten Klarheit über ihre rechtlichen Verpflichtungen, derer es bedarf, um die Resilienz der Weltrauminfrastruktur und der Weltraummissionen sicherzustellen. Da die Mitgliedstaaten mit der Umsetzung und Durchführung der NIS-2-Richtlinie befasst sind, besteht zudem die dringende Notwendigkeit, diese neuen Vorschriften an die spezifischen Anforderungen für die Weltraumwirtschaft anzupassen. Der Vorschlag gewährleistet eine klare Verknüpfung mit dem allgemeinen Cybersicherheitsrahmen auf Unionsebene. Da der EU-Weltraum-Rechtsakt zu einer „lex specialis“ in Bezug auf die Cybersicherheitsmaßnahmen von Unionsbetreibern im Bereich Weltraum wird, die in der NIS-2-Richtlinie als wesentliche oder wichtige Einrichtungen eingestuft werden, würden besagte Betreiber im Bereich Weltraum das Kapitel über Resilienz anwenden, um Doppelanforderungen zu vermeiden.

Was zweitens die Sicherheitsbelange angeht, werden durch den vorgeschlagenen EU-Weltraum-Rechtsakt Synergien mit der Sicherheitspolitik und den Sicherheitsvorschriften der Union sichergestellt. Wenn Weltraumtätigkeiten mehrere Mitgliedstaaten betreffen, wird die Koordinierung mit dem Flugverkehrsmanagement durch die Durchführungsverordnung (EU) 2019/123 der Kommission zur Optimierung der europäischen Netzfunktionen erreicht. Sicherheitsvorfälle an der Schnittstelle von Luftverkehrs- und Weltraumtätigkeiten werden systematisch über das gemäß der Verordnung (EU) Nr. 376/2014 eingerichtete obligatorische Meldesystem der Union gemeldet. Mit Blick auf die Zukunft können künftige Vorschriften für Operationen in großen Höhen Definitionen für Trägerraketen enthalten, wodurch eine umfassende regulatorische Abdeckung für diese neu entstehenden Bereiche sichergestellt wird.

Drittens trägt der vorgeschlagene EU-Weltraum-Rechtsakt im Einklang mit dem europäischen Grünen Deal^(8(8) und den Nachhaltigkeitszielen der Union^(9(9) dazu bei, den Umweltfußabdruck von Weltraumtätigkeiten zu verringern, und bietet die Möglichkeit, potenziellen neuen Verpflichtungen der Union im Rahmen der in diesem Bereich geschlossenen internationalen Übereinkommen nachzukommen.

Die Methoden zur Bewertung der Auswirkungen von Weltraumtätigkeiten, z. B. die Lebenszyklusanalyse (LCA) oder die umweltbezogenen Strategien und Instrumente der Union, wie der Umweltfußabdruck von Produkten (PEF)^(10(10), sind heute eindeutig rückständig^(11(11). Darüber hinaus wird in keinem der allgemeinen Nachhaltigkeits- oder umweltbezogenen Rahmen, wie dem Umwelt-, Sozial- und Governance-Rahmen (ESG)^(12(12), irgendeine der spezifischen und besonders komplexen Umweltauswirkungen von Weltraumtätigkeiten berücksichtigt.

Gestützt auf den PEF-Ansatz sieht der vorgeschlagene EU-Weltraum-Rechtsakt daher die Entwicklung und obligatorische Anwendung einer weltraumspezifischen LCA-Methode vor.

### 2. RECHTSGRUNDLAGE, SUBSIDIARITÄT UND VERHÄLTNISMÄẞIGKEIT

#### • Rechtsgrundlage

Rechtsgrundlage für diesen Vorschlag ist Artikel 114 des Vertrags über die Arbeitsweise der Europäischen Union (AEUV), der die Annahme von Maßnahmen für die Errichtung und das Funktionieren des Binnenmarkts vorsieht.

Der Vertrag sieht zwar ausdrücklich eine Rechtsgrundlage für Maßnahmen im Zusammenhang mit der Raumfahrtpolitik vor (Artikel 189 AEUV), doch kann diese Rechtsgrundlage für diese Initiative nicht herangezogen werden. Artikel 189 AEUV gilt nur für Maßnahmen zur Förderung gemeinsamer Initiativen, zur Unterstützung der Forschung und technologischen Entwicklung oder zur Koordinierung der Anstrengungen zur Erforschung und Nutzung des Weltraums. Jede Harmonisierung der Rechtsvorschriften der Mitgliedstaaten ist ausdrücklich ausgeschlossen.

Nach ständiger Rechtsprechung kann jedoch Artikel 114 AEUV als Rechtsgrundlage für die Errichtung und das Funktionieren des Binnenmarkts für Weltraumdienste und weltraumgestützte Daten dienen^(13(13). In dieser Hinsicht können die unterschiedlichen Ansätze der Mitgliedstaaten es den Betreibern im Bereich Weltraum erschweren, Weltraumtätigkeiten durchzuführen, und zwar insbesondere grenzüberschreitende Tätigkeiten, bei denen sie mehrere Genehmigungen von verschiedenen Mitgliedstaaten einholen müssen (z. B. eine Genehmigung in dem Staat, in dem die Tätigkeiten durchgeführt werden, und eine in dem Staat, in dem ein Raumfahrzeug gestartet wird).

Der vorgeschlagene EU-Weltraum-Rechtsakt führt eine gezielte Harmonisierung der wichtigsten Aspekte der Sicherheit, Resilienz und ökologischen Nachhaltigkeit herbei, die bei der Genehmigung von Weltraumtätigkeiten berücksichtigt werden. Er würde die Errichtung und das Funktionieren des Binnenmarkts für Weltraumdienste und weltraumgestützte Daten, die durch die Nutzung und den Betrieb der Weltrauminfrastruktur generiert werden, sicherstellen. Die Mitgliedstaaten würden die von anderen Mitgliedstaaten erteilten Genehmigungen für Weltraumtätigkeiten in Bezug auf die von dieser Verordnung erfassten wichtigen Angelegenheiten anerkennen. Gleichzeitig würden sie jedoch weiterhin die Möglichkeit haben, für Weltraummissionen, die von in anderen Mitgliedstaaten zugelassenen Unionsbetreibern im Bereich Weltraum durchgeführt werden, strengere Anforderungen festzulegen, wenn dies objektiv erforderlich ist, um die Sicherheit, Resilienz oder ökologische Nachhaltigkeit des Betriebs oder Starts von Raumfahrzeugen in ihrem Hoheitsgebiet zu gewährleisten.

Der vorgeschlagene EU-Weltraum-Rechtsakt würde zu einheitlicheren und kohärenteren Genehmigungsanforderungen im gesamten Binnenmarkt führen, was wiederum dazu beitragen würde, die Wettbewerbsfähigkeit der Weltraumindustrie der Union zu steigern. Der EU-Weltraum-Rechtsakt würde es den Unionsbetreibern im Bereich Weltraum ermöglichen, ohne Hindernisse in mehreren Rechtsräumen tätig zu werden, und er würde für die erforderliche Rechtssicherheit sorgen. Dies würde Investitionen in diesem Sektor fördern, wodurch auch die Expansion von New-Space-Unternehmen erleichtert würde. Ebenso würden die neuen Technologien, die durch die in den Rechtsvorschriften festgelegten Anforderungen (beispielsweise im Zusammenhang mit ISOS, Müll und Tracking-Technologien sowie mit dem Erhalt des dunklen und stillen Nachthimmels) vorangebracht werden, die industrielle Innovation im Sektor fördern und zur langfristigen Sicherheit, Nachhaltigkeit und Resilienz von Weltraumtätigkeiten beitragen.

#### • Subsidiarität (bei nicht ausschließlicher Zuständigkeit)

Die Mitgliedstaaten haben in Bezug auf die Sicherheit, Resilienz und ökologische Nachhaltigkeit von Weltraumtätigkeiten unterschiedliche Ansätze verfolgt. Dass auf Unionsebene gehandelt wird, ist von wesentlicher Bedeutung, um eine gezielte Harmonisierung mehrerer Schlüsselaspekte zu erreichen, die derzeit von den nationalen Genehmigungsanforderungen nicht in gleicher Weise abgedeckt werden.

Durch die Schaffung eines Rahmens auf Unionsebene würden das gemeinsame Niveau der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten erhöht und im Vergleich zu Einzelmaßnahmen auf Ebene der Mitgliedstaaten ein erheblicher Mehrwert geschaffen.

Durch eine Maßnahme auf Unionsebene würden insbesondere 1) durch eine Angleichung der Genehmigungsanforderungen in Bezug auf Sicherheit, Resilienz und ökologische Nachhaltigkeit gleiche Wettbewerbsbedingungen in der gesamten Union geschaffen; 2) die neuen Vorschriften reibungslos in die geltenden Rechtsvorschriften für den Bereich Weltraum integriert werden, um Überschneidungen, Doppelarbeit und Konflikte zu vermeiden und so das Funktionieren des Binnenmarkts zu verbessern; 3) in einem Mitgliedstaat erteilte Genehmigungen für Weltraumtätigkeiten in einem anderen Mitgliedstaat sicher anerkannt werden; 4) Vorkehrungen für einen besseren und einheitlicheren Schutz aller Weltrauminfrastruktur-Ressourcen in der gesamten Union getroffen, und ein Beitrag geleistet, um sicherzustellen, dass diese Infrastruktur weltraumgestützte Daten und Weltraumdienste sicher und geschützt bereitstellt; 5) einheitliche Bewertungen der Umweltauswirkungen von Weltraumtätigkeiten sichergestellt.

Ein gemeinsamer Ansatz auf Unionsebene würde zugleich dafür sorgen, dass die Union weltweit eine gewichtige Rolle bei Normungstätigkeiten in einem Bereich spielt, der dringend langfristige Lösungen erfordert.

#### • Verhältnismäßigkeit

Wie in der beigefügten Folgenabschätzung dargelegt, geht der Vorschlag nicht über das zur Erreichung der Ziele dieser Initiative erforderliche Maß hinaus und ist nicht mit unverhältnismäßigen Kosten verbunden, die die Wettbewerbsfähigkeit der Weltraumindustrie der Union beeinträchtigen könnten.

Durch eine Unionsmaßnahme würde eine gemeinsame Grundlage für die Aspekte der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten in der Union geschaffen, und zwar a) in einer angemessenen Weise im Hinblick auf die spezifischen Risiken jeder Umlaufbahn, jeder Höhe oder von Besonderheiten, die sich aus nicht kritischen Weltraummissionen ergeben, b) unter Wahrung der Technologieneutralität und c) unter uneingeschränkter Achtung der Vorrechte der Mitgliedstaaten in Bezug auf die nationale Sicherheit.

Durch den Vorschlag werden unnötige Belastungen minimiert, indem die Genehmigungen für Konstellationen gestrafft werden (z. B. eine einzige Genehmigung pro Konstellation statt pro Satellit). Weniger strenge Sicherheitsanforderungen gelten für Weltraummissionen in sehr niedrigen Erdumlaufbahnen, bei denen der Müll naturgemäß durch den raschen Wiedereintritt in die Atmosphäre begrenzt ist. Zugleich werden die resilienzbezogenen Verpflichtungen in Abhängigkeit von der Größe der Betreiber im Bereich Weltraum, der Kritikalität der Mission und dem genutzten Antrieb skaliert.

#### • Wahl des Instruments

Gemäß Artikel 114 des Vertrags über die Arbeitsweise der Europäischen Union sind das Europäische Parlament und der Rat befugt, Verordnungen und Richtlinien zu erlassen.

Die Kommission hat beschlossen, einen Vorschlag für eine Verordnung vorzulegen, um eine einheitliche Umsetzung in der gesamten Union sicherzustellen. Dadurch wird verhindert, dass Unterschiede die Bereitstellung von Weltraumtätigkeiten und weltraumgestützten Daten im Binnenmarkt behindern, und zudem werden so Rechtssicherheit und Transparenz gewährleistet, ein einheitlicher Schutz der Rechte und Pflichten für alle Anbieter von Weltraumdiensten aus der EU und aus Drittländern im Binnenmarkt sichergestellt und eine einheitliche Umsetzung in allen Mitgliedstaaten ermöglicht.

### 3. ERGEBNISSE DER EX-POST-BEWERTUNG, DER KONSULTATION DER INTERESSENTRÄGER UND DER FOLGENABSCHÄTZUNG

#### • Ex-post-Bewertung/Eignungsprüfungen bestehender Rechtsvorschriften

Entfällt.

#### • Konsultation der Interessenträger

Bei der Ausarbeitung des Vorschlags hat die Kommission im Einklang mit den Leitlinien für eine bessere Rechtsetzung alle einschlägigen Interessenträger umfassend konsultiert. Sie führte eine gezielte Konsultation und eine öffentliche Konsultation durch, veröffentlichte eine Aufforderung zur Stellungnahme, führte spezifische Umfragen zu den drei Hauptbereichen des Vorschlags durch und veranstaltete vier Workshops mit Interessenträgern. Die daraus gewonnenen Erkenntnisse wurden in die Studie zur Unterstützung der vorbereitenden Arbeiten der Kommission einbezogen.

a) Gezielte Konsultation von Interessenträgern

Vom 29. September bis 2. November 2023 wurde eine gezielte Konsultation von Interessenträgern durchgeführt. Sie richtete sich an die Weltraumindustrie, darunter Hochschul-/Forschungseinrichtungen, Wirtschaftsverbände, Hersteller von Raumfahrzeugen, Betreiber im Bereich Weltraum, Fluggesellschaften und Flugsicherungsorganisationen sowie an Verbraucherorganisationen, Umweltorganisationen, Nichtregierungsorganisationen (NRO), Behörden, Gewerkschaften und die Öffentlichkeit. Beiträge gingen aus 27 EU-Mitgliedstaaten (47 % der Befragten) und mehreren Drittländern wie Kanada, Japan, Norwegen, der Schweiz, den Vereinigten Staaten und dem Vereinigten Königreich (5 %) ein. Die Herkunft der übrigen Antworten (49 %) wurde nicht angegeben.

Insgesamt gingen 333 Beiträge (einschließlich 65 Begleitunterlagen) ein, von denen 170 von Organisationen und 153 von Einzelpersonen stammten und wobei die übrigen anonyme Beiträge waren. 62 % der Organisationen waren Kleinstunternehmen, kleine oder mittlere Unternehmen.

Sowohl aus den Antworten auf die Umfrage als auch den Positionspapieren, die – auch von Industrieverbänden – eingereicht wurden, ging eine breite Unterstützung für einen EU-Weltraum-Rechtsakt hervor. Insbesondere besteht in der europäischen Weltraumindustrie ein breiter Konsens darüber, dass der EU-Weltraum-Rechtsakt einen klaren und gemeinsamen Rahmen schaffen würde, der die unterschiedlichen grundlegenden Vorschriften für Weltraumtätigkeiten in der Union harmonisiert. Dies wird als besonders nützlich angesehen, da hierdurch Organisationen in die Lage versetzt werden, problemlos ins Ausland zu expandieren und ihre Dienste in mehreren Mitgliedstaaten anzubieten. Darüber hinaus wird die Einführung eines EU-Weltraum-Rechtsakts als Chance für die Union gesehen, bei der Festlegung globaler Standards, mit denen der Bereich Weltraum sicherer, resilienter und nachhaltiger gemacht werden kann, eine Führungsrolle zu übernehmen.

Gleichzeitig betonte die Industrie, dass der EU-Weltraum-Rechtsakt darauf abzielen sollte, ihre Wettbewerbsfähigkeit zu erhalten, indem Unternehmen aus Drittländern, die Produkte oder Dienstleistungen auf dem Unionsmarkt in Verkehr bringen, in den Anwendungsbereich einbezogen werden. Industrievertreter und Verbände äußerten auch Sorgen hinsichtlich der potenziellen Belastung und der zusätzlichen Kosten, die der EU-Weltraum-Rechtsakt für Start-up-Unternehmen und KMU mit sich bringen könnte, und forderten unterstützende Maßnahmen, um diese Auswirkungen auszugleichen.

b) Öffentliche Konsultationen

Vom 4. Oktober bis 28. November 2023 wurde eine öffentliche Konsultation von Interessenträgern durchgeführt. Die Umfrage umfasste elf allgemeine Fragen zu Sicherheitsrisiken im Zusammenhang mit Weltraumtätigkeiten sowie Fragen zu möglichen Maßnahmen auf Unionsebene. Insgesamt gingen 44 Beiträge von Einzelpersonen, Organisationen, Hochschul-/Forschungseinrichtungen, Behörden, Wirtschaftsverbänden und NRO ein.

Die Umfrage zeigte, dass die Interessenträger einen EU-Weltraum-Rechtsakt nachdrücklich befürworten. Die Befragten wiesen auf die Unzulänglichkeit der derzeitigen nationalen und internationalen Rechtsvorschriften zum Thema Weltraum hin und betonten, dass es eines umfassenden Rechtsrahmens bedarf. Die meisten Interessenträger plädieren für eine Kombination aus verbindlichen und freiwilligen Maßnahmen zur Gewährleistung sicherer, resilienter und nachhaltiger Weltraumtätigkeiten und erkennen dabei die Bedeutung der internationalen Zusammenarbeit weitgehend an.

#### • Einholung und Nutzung von Expertenwissen

Bei der Erstellung des Berichts über die Folgenabschätzung stützte sich die Kommission auf externes Fachwissen:

- • Deloitte und Roland Berger leisteten beratende Unterstützung für den Bericht über die Folgenabschätzung;

- • Cyberinflight und die RHEA-Gruppe trugen mit Fachwissen zum Thema Cybersicherheit im Weltraum bei;

- • die Kommission veranstaltete am 16. Februar 2023 bzw. 13. November 2023 zwei Workshops mit Sachverständigen für das europäische Weltraumrecht;

- • Euroconsult führte eine Studie über die europäische Weltraumindustrie und den europäischen Weltraummarkt durch;

- • die Kommission arbeitete mit verschiedenen Interessenträgern (z. B. der Agentur der Europäischen Union für das Weltraumprogramm (EUSPA), anderen Kommissionsdienststellen, der Europäischen Weltraumorganisation (ESA) und Industrieverbänden) zusammen, um umfassende Daten zur Untermauerung der Folgenabschätzung zu sammeln.

#### • Folgenabschätzung

Entsprechend ihrer Strategie für eine bessere Rechtsetzung führte die Kommission eine Folgenabschätzung für diesen Vorschlag durch. Der Ausschuss für Regulierungskontrolle der Kommission gab am 22. Februar 2024 eine befürwortende Stellungnahme mit Vorbehalten^(14(14) ab. Dabei wurden die folgenden Optionen berücksichtigt:

- • Option 1: Die Kommission würde die Kodifizierung nicht verbindlicher Maßnahmen zwischen der Industrie und den Mitgliedstaaten durch einen Koregulierungsansatz erleichtern. Die Koregulierung kombiniert legislative und regulatorische Maßnahmen mit Maßnahmen der am stärksten betroffenen Akteure und stützt sich dabei auf deren praktisches Fachwissen. Darüber hinaus fördert die Kommission die Entwicklung von Siegeln durch die Industrie.

- • Option 2: Annahme eines verbindlichen Unionsrahmens.

- • Option 2+: Annahme eines verbindlichen Unionsrahmens gemäß Option 2 in Verbindung mit nicht verbindlichen und unterstützenden Maßnahmen.

- • Option 2++: Optionen 2 und 2+ mit internationalen bilateralen Abkommen zur Förderung eines globalen Ansatzes im Hinblick auf die Sicherheit und Resilienz im Weltraum sowie die Umweltauswirkungen von Weltraumtätigkeiten.

Auf der Grundlage der Bewertung und des Vergleichs aller Optionen wurde Option 2+ „Annahme eines verbindlichen Rahmens auf Unionsebene in Verbindung mit nicht verbindlichen Maßnahmen“ als die bevorzugte Option ermittelt. Dieses Ergebnis steht auch im Einklang mit der bevorzugten Option, die von den Interessenträgern (einschließlich KMU) im Rahmen der gezielten Konsultation ausgewählt wurde.

Überblick über die wirtschaftlichen Auswirkungen

Die Umsetzung eines Rechtsrahmens für die Weltraumwirtschaft bringt diverse Kosten und Vorteile sowohl für den öffentlichen als auch für den privaten Sektor mit sich.

Was den öffentlichen Sektor betrifft, bewerten Mitgliedstaaten mit etablierten Weltraumprogrammen bereits viele der vorgesehenen Anforderungen im Einklang mit den Verpflichtungen aus dem UN-Vertrag. In diesen Mitgliedstaaten ist der Großteil der europäischen Weltraumwirtschaft angesiedelt und ihre Vorschriften müssten nur geringfügig angepasst werden, was mit einem minimalen Verwaltungsaufwand (1 bis 2 Vollzeitäquivalente (VZÄ)) verbunden wäre. Demgegenüber sind in Mitgliedstaaten, in denen es keine Rechtsvorschriften für den Bereich Weltraum gibt, in der Regel neu aufkommende Weltraumtätigkeiten angesiedelt. Auch in diesem Fall würden sich die Anpassungskosten für neue Anforderungen in Grenzen halten (bis zu 4 VZÄ).

In Bezug auf die technische Bewertung zur Erfüllung der Genehmigungsanforderungen der Union haben die Mitgliedstaaten die Wahl, sich auf die technische Bewertung zu stützen, die von der ESA und der Agentur der Union für das Weltraumprogramm (im Folgenden „EUSPA“ oder „Agentur“) bereitgestellt wird.

Im privaten Sektor variieren die Kosten je nach Unternehmen. Für Satellitenbetreiber könnte sich je nach den Anforderungen der Weltraummissionen ein Anstieg der Herstellungskosten für Satelliten-Plattformen um bis zu 10 % ergeben. Den Anbietern von Startdiensten entstehen zusätzliche Kosten, die sich bei großen Anbietern möglicherweise auf bis zu 1,5 Mio. EUR für schwere Trägerraketen (Ariane 64) und bei KMU auf bis zu 200 000 EUR belaufen. Die Risikomanagementkosten für Unternehmen werden auf 10 % ihres IT-Budgets geschätzt, und die die Genehmigungsanforderungen betreffenden Kosten werden sich pro Produktlinie auf etwa 100 000 EUR belaufen. Die Umsetzung der Produktkategorieregeln für die Berechnung des Umweltfußabdrucks (PEFCR-Regeln) wird 4 000 bis 8 000 EUR kosten.

Trotz dieser Kosten dürfte die Vereinfachung der Rechtsvorschriften erhebliche Vorteile mit sich bringen. Die Möglichkeit, ein einzelnes Produkt in 27 Mitgliedstaaten zu vermarkten, vereinfacht den Zugang und verringert Verwaltungshürden, wodurch eine schnellere Markteinführung ermöglicht wird. Allein der Übergang von der Genehmigung für einzelne Satelliten zur Genehmigung für Konstellationen dürfte den Satellitenbetreibern in den nächsten zehn Jahren Einsparungen in Höhe von 68 Mio. EUR bringen. Darüber hinaus wird der jährliche wirtschaftliche Effekt der Verlängerung der Lebensdauer von Satelliten in erdnahen Umlaufbahnen von fünf auf sechs Jahre auf 1,3 Mrd. EUR geschätzt. Die Unternehmen werden einen weltweiten Wettbewerbsvorteil erlangen und von hohen Cybersicherheitsstandards profitieren, die die Cyberrisiken verringern, wodurch die Hersteller potenziell 320 Mio. EUR pro Jahr einsparen können. Langfristig dürfte der vorgeschlagene EU-Weltraum-Rechtsakt die Weltraumindustrie der Union stützen (schätzungsweise 20 % eines prognostizierten Marktvolumens von 700 Mrd. EUR bis 2031) und gleichzeitig die Entstehung neuer Geschäftssegmente fördern, wie z. B. aktive Beseitigung von Weltraummüll, Reparatur- und Wartungsarbeiten im Orbit, Montage und Fertigung sowie Verschlüsselungstechnologien.

Überblick über die gesellschaftlichen Auswirkungen

Im Vergleich zu den anderen Optionen würde die bevorzugte Option aufgrund der Verbindlichkeit der vorgesehenen Maßnahmen (die mit nicht verbindlichen und unterstützenden Maßnahmen verbunden werden) erhebliche Vorteile in Form einer besseren Einhaltung der Vorschriften mit sich bringen. Durch sie würden der Zugang der Öffentlichkeit zu weltraumgestützten Diensten geschützt, das Vertrauen in und der Verlass auf Weltraumsysteme und -dienste sowie weltraumgestützte Daten gestärkt und die Governance durch harmonisierte Genehmigungsbedingungen verbessert werden. Darüber hinaus würde sie Astronomen und indigene Gemeinschaften durch die Verringerung der Lichtverschmutzung schützen und zu Innovation, Wachstum und Wettbewerbsfähigkeit in der Weltraumwirtschaft beitragen.

Überblick über die Auswirkungen auf die Umwelt

Die bevorzugte Option hätte positive Auswirkungen auf die Umwelt aufgrund der verbindlichen Anforderungen im Hinblick auf die Entfernung von Satelliten aus der Umlaufbahn und eine gemeinsame LCA. Auf der Grundlage der PEFCR-Regeln würde die Genehmigungsanforderung einen Überblick über die verschiedenen Kategorien von Umweltauswirkungen bieten. Sie würde auch den Zugang zu nachhaltigen Finanzierungen für die Weltraumindustrie der Union erleichtern.

#### • Effizienz der Rechtsetzung und Vereinfachung

Ein gemeinsamer Regelungsrahmen würde die Wettbewerbsfähigkeit der Weltraumindustrie der Union verbessern, indem 1) sich der Verwaltungsaufwand und die Kosten für Unternehmen verringern, die nicht mehr mehrere unkoordinierte Anforderungen in der gesamten Union erfüllen müssten, und 2) die Verlässlichkeit der Weltraumunternehmen in der Union durch verbesserte Resilienz und Sicherheit erhöht und ihnen ein weltweiter Wettbewerbsvorteil verschafft würde.

Eine stärkere Integration des Binnenmarkts würde auch neue Märkte für KMU öffnen, den relevanten Unionsmarkt vergrößern und Innovationen fördern. Dies würde auch Anreize für mehr private Investitionen setzen und zur Expansion und zum Wachstum der New-Space-Industrie (hauptsächlich Start-up- und Scale-up-Unternehmen sowie KMU, die größere Finanzmittel beschaffen müssen) in der Union beitragen.

Ziel der vorgeschlagenen Initiative ist es, auf Unionsebene gleiche Wettbewerbsbedingungen zu schaffen und sicherzustellen, dass Unionsbetreiber im Bereich Weltraum nicht unter Wettbewerbsverzerrungen durch außerhalb der Union niedergelassene Betreiber im Bereich Weltraum leiden, die von weniger strengen Normen profitieren. Die Möglichkeit der gegenseitigen Anerkennung könnte letztlich den Marktanteil der Unionsbetreiber im Bereich Weltraum erhöhen.

Die Kosten für die Industrie und insbesondere für KMU ergäben sich aufgrund der Pflicht, technische und operative Anforderungen zu erfüllen, verbunden mit zusätzlichen Kosten für Verwaltungskontrollen und Durchsetzung. Insgesamt dürften diese Änderungen den Verwaltungsaufwand und die Kosten für die gesamte Industrie, auch für KMU, erhöhen. Die Herstellungskosten könnten um 3 % bis 10 % steigen. Diese Auswirkungen könnten abgemildert werden durch i) die Auswirkungen der Unterstützungsmaßnahmen und ii) die in den Vorschriften verankerte Verhältnismäßigkeit (um beispielsweise der Größe der Unternehmen, der Kritikalität der Mission oder der Umlaufbahn Rechnung zu tragen). Die Initiative würde auch operative Vorteile für KMU mit sich bringen, insbesondere höhere Einnahmen aufgrund einer längeren Lebensdauer der Satelliten.

#### • Grundrechte

Die Verpflichtungen erkennen die unternehmerische Freiheit (Artikel 16 der Charta der Grundrechte der Europäischen Union) uneingeschränkt an. Ein gemeinsamer Regelungsrahmen würde die Rechtssicherheit erhöhen und ein innovations- und wettbewerbsfreundliches Umfeld in der Weltraumwirtschaft fördern. Mit den Anforderungen werden legitime Ziele von allgemeinem Interesse verfolgt, die die Sicherheit, Resilienz und ökologische Nachhaltigkeit von Weltraumtätigkeiten sicherstellen. Darüber hinaus sind sie auf das erforderliche und verhältnismäßige Maß beschränkt, wobei gewährleistet ist, dass etwaige Auswirkungen auf die Tätigkeiten von Betreibern im Bereich Weltraum begrenzt bleiben und mit dem in Artikel 52 Absatz 1 der Charta verankerten Grundsatz der Verhältnismäßigkeit im Einklang stehen.

### 4. AUSWIRKUNGEN AUF DEN HAUSHALT

Ein detaillierter Überblick über die Auswirkungen des Vorschlags auf den Haushalt der Europäischen Union ist dem mit dem Vorschlag vorgelegten „Finanz- und Digitalbogen zu Rechtakten“ zu entnehmen.

Der Vorschlag hat Auswirkungen auf die zuständigen Behörden auf nationaler Ebene (d. h. auf diejenigen, die für die Erteilung einschlägiger Genehmigungen für die Durchführung von Weltraumtätigkeiten zuständig sind). Diese Auswirkungen werden im Überblick über die wirtschaftlichen Auswirkungen und in der Folgenabschätzung ausführlicher beschrieben.

### 5. WEITERE ANGABEN

#### • Durchführungspläne sowie Monitoring-, Bewertungs- und Berichterstattungsmodalitäten

Die spezifischen Ziele der Initiative würden jährlich überwacht. Der Vorschlag würde fünf Jahre nach seinem Inkrafttreten bewertet werden, um die Auswirkungen und die Reaktion des Markts, insbesondere der KMU, zu beurteilen.

#### • Ausführliche Erläuterung einzelner Bestimmungen des Vorschlags

TITEL I Allgemeine Bestimmungen

Titel I (Artikel 1-5) enthält die allgemeinen Vorschriften für den Gegenstand der Verordnung. Diese Vorschriften betreffen die Genehmigung, Registrierung und Beaufsichtigung von Weltraumtätigkeiten in der Union, das Verkehrsmanagement in der Umlaufbahn, Governance- und Durchsetzungsaspekte sowie die Einführung eines Weltraumsiegels der Union. In Artikel 2 („Anwendungsbereich“) ist festgelegt, auf welche Anbieter von Weltraumdiensten und Weltraumobjekte die Verordnung Anwendung findet, einschließlich Betreibern aus Drittländern, die in der Union Weltraumdienste oder weltraumgestützte Daten bereitstellen. Titel I enthält auch den Grundsatz des freien Verkehrs von weltraumgestützten Daten und Weltraumdiensten innerhalb der Union sowie eine Klausel, mit der die Zuständigkeit der Mitgliedstaaten in Bezug auf die nationale Sicherheit sichergestellt wird. Schließlich werden darin die wichtigsten Begriffe definiert, die in der Verordnung verwendet werden.

TITEL II – Genehmigung und Registrierung von Weltraumtätigkeiten

In Kapitel I (Artikel 6-10) sind die Bedingungen festgelegt, die Unionsbetreiber im Bereich Weltraum erfüllen müssen, um eine Genehmigung für die Durchführung von Weltraumtätigkeiten zu erhalten. Die zuständigen nationalen Behörden der Mitgliedstaaten überwachen das Verfahren zur Erteilung von Genehmigungen an Unionsbetreiber im Bereich Weltraum und unterrichten die Agentur über alle zugelassenen Betreiber im Bereich Weltraum. Die Agentur trägt alle Betreiber im Bereich Weltraum, einschließlich der Drittlandsbetreiber im Bereich Weltraum, über die die Kommission einen Beschluss gemäß Kapitel III gefasst hat, in das Unionsregister der Weltraumobjekte (URSO) ein. Für Starts von Satellitenkonstellationen wird ein vereinfachtes Verfahren für die Genehmigung und dessen anschließende Erneuerung oder Rücknahme eingeführt. Im Einklang mit dem Grundsatz der Verhältnismäßigkeit werden für bestimmte Kategorien von Unionsbetreibern im Bereich Weltraum Sonderregelungen und spezifische Ausnahmen festgelegt.

In Kapitel II (Artikel 11-13) wird das Genehmigungsverfahren für Unionsbetreiber im Bereich Weltraum festgelegt, die beabsichtigen, unionseigene Ressourcen zu betreiben oder zu starten. Die Kommission erteilt die Genehmigung (auf Vorschlag der Agentur auf der Grundlage einer technischen Bewertung), führt eine laufende Aufsicht durch und setzt eine Genehmigung für unionseigene Ressourcen unter den in der Verordnung festgelegten Umständen aus oder nimmt sie zurück.

Kapitel III (Artikel 14-23) enthält die Vorschriften für die Registrierung von Betreibern aus Drittländern und internationalen Organisationen, die weltraumgestützte Dienste in der Union bereitstellen. Es enthält spezifische Ausnahmeregelungen für Startdienste, die von Einrichtungen aus Drittländern oder staatlichen Stellen in Drittländern erbracht werden, sowie eine Klausel für den Binnenmarkt-Notfall. Drittlandsbetreiber im Bereich Weltraum und internationale Organisationen, die Weltraumdienste oder weltraumgestützte Daten in der Union bereitstellen, werden im URSO registriert, wenn sie die Einhaltung der in der Verordnung festgelegten technischen Anforderungen nachweisen. Die Agentur erstellt ferner eine gesonderte Liste aller Primäranbieter weltraumgestützter Daten in der Union. Bei Betreibern im Bereich Weltraum, die in einem Drittland niedergelassen sind, für das die Kommission einen Gleichwertigkeitsbeschluss erlassen hat, wird davon ausgegangen, dass sie die Anforderungen der Verordnung erfüllen. Drittlandsbetreiber benennen einen gesetzlichen Vertreter in der Union, um eine wirksame Zusammenarbeit mit den zuständigen Behörden, der Kommission und der Agentur zu gewährleisten.

Kapitel IV (Artikel 24-27) enthält Vorschriften für die Einrichtung des URSO, des elektronischen Zertifikats und für die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten in der Union. Die Agentur wird elektronische Zertifikate ausstellen, mit denen die Konformität von weltraumgestützten Daten und Weltraumdiensten, die von Einrichtungen aus Drittländern und internationalen Organisationen bereitgestellt werden, mit den Anforderungen der Verordnung bescheinigt wird. Verträgen über die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten in der Union muss ein elektronisches Zertifikat beigefügt sein, und die Primäranbieter weltraumgestützter Daten melden der Agentur mutmaßliche Unregelmäßigkeiten.

TITEL III Governance-Aspekte

Kapitel I (Artikel 28-39) enthält in Abschnitt 1 die wichtigsten Governance-Grundsätze für die Mitgliedstaaten in Bezug auf die Genehmigung und Beaufsichtigung von Weltraumtätigkeiten sowie die Marktüberwachung. Jeder Mitgliedstaat sollte eine zuständige Behörde benennen oder einrichten, die mit ausreichenden Ressourcen und Befugnissen ausgestattet ist, um die Einhaltung der Vorschriften durch die Unionsbetreiber im Bereich Weltraum zu überwachen. Die zuständigen nationalen Behörden müssen über Aufsichts-, Untersuchungs-, Abhilfe- und Sanktionsbefugnisse verfügen.

In Abschnitt 2 werden Verfahren für Mitgliedstaaten festgelegt, die beabsichtigen, qualifizierte technische Stellen für Weltraumtätigkeiten zu benennen. Diese Mitgliedstaaten benennen eine Behörde zur Bewertung, Benennung und Überwachung der qualifizierten technischen Stellen. Dabei kann es sich um die auf nationaler Ebene benannte nationale Akkreditierungsstelle handeln, die sicherstellen soll, dass diese Stellen über die zur Bewertung der Einhaltung der technischen Anforderungen des Titels IV der Verordnung erforderliche technische Kompetenz verfügen und diese aufrechterhalten. Die Mitgliedstaaten setzen die Kommission über ihre qualifizierten technischen Stellen in Kenntnis. In Abschnitt 3 werden das Verfahren für die Beantragung des Status einer qualifizierten technischen Stelle für die unter Titel IV fallenden Angelegenheiten und die geltenden Anforderungen festgelegt. Die Mitgliedstaaten stellen sicher, dass gegen die Entscheidungen von qualifizierten technischen Stellen Rechtsmittel eingelegt werden können.

In Kapitel II (Artikel 40-57) wird die Governance auf Unionsebene festgelegt und in Abschnitt 1 werden die Aufgaben und Zuständigkeiten im Einzelnen dargelegt. Der Agentur werden neue Aufgaben übertragen, insbesondere die Unterstützung der Kommission bei der Genehmigung und Beaufsichtigung von Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, und bei der Registrierung von Drittlandsbetreibern im Bereich Weltraum und internationalen Organisationen, die weltraumgestützte Daten und Weltraumdienste in der Union bereitstellen. Die Agentur richtet die erforderlichen Datenbanken (URSO und die Kontaktlistendatenbank der Union für Warnmeldungen zu Ereignissen von hohem Interesse) ein und verwaltet diese und stellt die elektronischen Zertifikate aus.

Die Agentur richtet spezielle interne Strukturen (Konformitätsgremium und Widerspruchskammer) ein, um die Kommission bei der Genehmigung und Registrierung von Betreibern im Bereich Weltraum und Drittlandsbetreibern im Bereich Weltraum zu unterstützen und um Mitgliedstaaten ohne qualifizierte technische Stellen durch technische Bewertungsverfahren zu helfen. Die Agentur würde die Kommission bei der Ausübung der Aufsichtsbefugnisse über Unionsbetreiber im Bereich Weltraum und Anbieter aus Drittländern unterstützen. Die Widerspruchskammer würde die Verteidigungsrechte gegenüber Entscheidungen der Agentur gewährleisten. Die neuen Aufgaben werden durch ein Registrierungsgebührensystem finanziert. In Abschnitt 2 werden die Befugnisse der Agentur und der Kommission in Bezug auf Betreiber von unionseigenen Ressourcen und in Bezug auf Drittlandsbetreiber im Bereich Weltraum festgelegt.

TITEL IV Technische Anforderungen

Titel IV enthält die Anforderungen, die die verschiedenen Kategorien von Anbietern von Weltraumdiensten erfüllen müssen, was hauptsächlich Angelegenheiten in Bezug auf die Sicherheit, die Resilienz und die ökologische Nachhaltigkeit betrifft.

Kapitel I (Artikel 58-73) enthält Vorschriften bezüglich der Sicherheit und der Nachhaltigkeit im Weltraum, die Trägerraketen (Abschnitt 1) und Raumfahrzeuge (Abschnitt 2) betreffen. Die Sicherheitsvorschriften zielen darauf ab, Kollisionsrisiken zu verringern, die Entstehung von Müll in den Umlaufbahnen einzudämmen und einen sicheren Start und Wiedereintritt sicherzustellen, wobei für Betreiber im Bereich Weltraum spezifische Verfahren und technische Anforderungen gelten.

Gemäß Abschnitt 1 müssen sich Startbetreiber mit den Behörden und Anbietern von Flugverkehrsdiensten abstimmen, um das Risiko von Kollisionen beim Start und beim Wiedereintritt zu mindern. Sie sind verpflichtet, Flugsicherheitssysteme zu installieren und Maßnahmen zur Eindämmung von Weltraummüll umzusetzen. Die Kommission muss im Wege von Durchführungsrechtsakten detaillierte Methoden zur Berechnung von Kollisionsvermeidungsfenstern, Unfallrisikoschwellen und Koordinierungsverfahren festlegen.

Gemäß Abschnitt 2 müssen Raumfahrzeugbetreiber die Verfolgbarkeit von Raumfahrzeugen sicherstellen und Dienste zur Kollisionsvermeidung in Anspruch nehmen. Sie müssen für die Koordinierung des Wiedereintritts sorgen und ein gewisses Maß an Manövrierbarkeit aufrechterhalten. Zu den weiteren Verpflichtungen gehören die Erstellung von Plänen zur Verringerung des Weltraummülls, die Begrenzung der Licht- und Funkfrequenzverschmutzung und die Einhaltung zusätzlicher Standards für Sicherheit und die Verringerung von Weltraummüll für große Konstellationen. Betreiber im Bereich Weltraum können die Verlängerung einer Mission beantragen, wenn sie die Anforderungen im Hinblick auf das Ende der Lebensdauer und Weltraummüll weiterhin erfüllen. Betreiber im Bereich Weltraum müssen sicherstellen, dass die Hersteller der Lieferanten die in diesem Kapitel festgelegten Anforderungen an Entwurf und Herstellung erfüllen.

Kapitel II (Artikel 74-95) enthält allgemeine Grundsätze für das Risikomanagement für Weltrauminfrastrukturen und die Anforderung, Risikobewertungen durchzuführen, wobei auf den bestehenden Rechtsvorschriften über Cybersicherheit und physische Resilienz kritischer Einrichtungen aufgebaut wird. Betreiber im Bereich Weltraum sind verpflichtet, durch umfassende, verhältnismäßige und gefahrenübergreifende Maßnahmen allen Risiken für die Weltrauminfrastruktur zu begegnen. Diese Maßnahmen erstrecken sich über den gesamten Lebenszyklus einer Weltraummission (von der Konzeption und Herstellung bis hin zu Start, Betrieb und Entsorgung) und decken sowohl digitale als auch physische Bedrohungen ab.

Während die Weltraumwirtschaft Teil des NIS-2-Ökosystems bleiben sollte, sollten die in diesem Kapitel festgelegten Cybervorschriften, die auf die Weltraumwirtschaft zugeschnitten sind, für die in Anhang I Nummern 8 und 11 der NIS-2-Richtlinie genannten Unionsbetreiber im Bereich Weltraum gelten, um Doppelarbeit zu vermeiden und Lücken in der Abdeckung der Weltraumwirtschaft zu schließen. Betreiber im Bereich Weltraum führen Risikobewertungen durch, ermitteln Schwachstellen, setzen Abhilfemaßnahmen um und passen die Risikoszenarien an die Besonderheiten jeder Weltraummission an. Betreiber im Bereich Weltraum sollten umfassende Strategien für das Informationssicherheitsmanagement festlegen und aufrechterhalten sowie strenge Kontrollen der Zugriffsberechtigungen und den physischen Schutz von Weltraumressourcen sicherstellen. Es werden weitere Vorschriften für die Erkennung und Überwachung von Sicherheitsvorfällen, die Implementierung von Verschlüsselung, Backup-Protokolle, die Ausarbeitung umfassender Strategien zur Fortführung des Geschäftsbetriebs sowie Reaktions- und Wiederherstellungspläne festgelegt. Betreiber im Bereich Weltraum, die dem vereinfachten Risikomanagementverfahren unterliegen, sollten weniger strenge Maßnahmen anwenden und gleichzeitig die Resilienz kritischer Ressourcen und Funktionen sicherstellen. Unionsbetreiber im Bereich Weltraum melden der Agentur erhebliche Sicherheitsvorfälle im Zusammenhang mit unionseigenen Ressourcen. Ein Unionsnetz für Resilienz im Weltraum (EUSRN) erleichtert die Zusammenarbeit zwischen der Kommission, der Agentur und den zuständigen nationalen Behörden bei der Überwachung und Bewältigung erheblicher Cybervorfälle und der Angleichung der Resilienzmaßnahmen an andere Cybersicherheitsrahmen der Union.

Kapitel III (Artikel 96-100) betrifft die ökologische Nachhaltigkeit. Betreiber im Bereich Weltraum sind verpflichtet, den Umweltfußabdruck (Environmental Footprint, EF) über den gesamten Lebenszyklus von Weltraummissionen zu berechnen, einschließlich der Phasen der Konzeption, der Herstellung, des Betriebs und des Endes der Lebensdauer, es sei denn, sie erfüllen die Voraussetzungen für eine Ausnahme. Betreiber im Bereich Weltraum müssen im Rahmen ihres Genehmigungsantrags eine Erklärung zum Umweltfußabdruck mitsamt den unterstützenden Studien und Daten zum Umweltfußabdruck vorlegen, die von einer qualifizierten technischen Stelle für Weltraumtätigkeiten im Zuge der Erteilung eines Zertifikats überprüft werden. Sie müssen alle relevanten Daten von ihren Lieferanten einholen, aggregierte und aufgeschlüsselte Datensätze zur Aufnahme in die EF-Datenbank an die Kommission übermitteln und sie auf dem neuesten Stand halten.

Kapitel IV (Artikel 101) enthält die Anforderungen an Operationen und Dienste im Weltraum (ISOS). Raumfahrzeuge müssen so ausgerüstet sein, dass sie über spezielle Schnittstellen im Weltraum gewartet werden können. Die Kommission wird die Gestaltungsgrundsätze für diese Schnittstellen detailliert angeben und kann weitere Bedingungen für die Beseitigung von Weltraummüll für bedrohliche Objekte festlegen.

Kapitel V (Artikel 102-103) enthält Vorschriften für den Verkehr in der Umlaufbahn, einschließlich Vorschriften für die Durchführung von Kollisionsvermeidungsmanövern im Rahmen von Warnungen zu Ereignissen von hohem Interesse. In diesem Kapitel wird ein Wegerecht-Ansatz eingeführt, der die Vermeidung von Kollisionen zwischen mehreren manövrierfähigen Raumfahrzeugen erleichtern soll.

In Kapitel VI (Artikel 104) wird der Kommission die Befugnis übertragen, europäische Normungsorganisationen mit der Ausarbeitung von Normen zu beauftragen oder Durchführungsrechtsakte zur Festlegung gemeinsamer Spezifikationen für bestimmte technische Anforderungen zu erlassen.

TITEL V Gleichwertigkeitsbeschlüsse, internationale Übereinkünfte und Vorschriften in Bezug auf internationale Organisationen

In Titel V (Artikel 105-108) wird es der Kommission ermöglicht, Gleichwertigkeitsbeschlüsse für Drittlandsbetreiber im Bereich Weltraum zu erlassen, und es werden die für internationale Organisationen geltenden Vorschriften für die einzelnen Arten von Ressourcen festgelegt. Die Union bemüht sich gegebenenfalls im Einklang mit Artikel 218 AEUV um den Abschluss von Übereinkünften mit internationalen Organisationen, die unionseigene Ressourcen betreiben.

TITEL VI Unterstützende Maßnahmen

Kapitel I (Artikel 109-111) enthält eine Reihe unterstützender Maßnahmen, die dazu beitragen sollen, einen Teil der Durchführungskosten, insbesondere für Start-ups, Scale-ups und KMU, auszugleichen und die Durchführung der Verordnung zu unterstützen. Die unterstützenden Maßnahmen umfassen Maßnahmen zum Kapazitätsaufbau (z. B. Erstellung von Leitfäden), technische Hilfe (z. B. Einrichtung eines Pools unabhängiger Sachverständiger, der Betreiber im Bereich Weltraum bei der Zusammenstellung der technischen Dossiers unterstützt) und die Finanzierung einer digitalen Lösung (d. h. eines zentralen Informationsportals).

Mit Kapitel II (Artikel 112-113) wird ein „Rahmen für das Weltraumsiegel der Union“ geschaffen, damit Betreiber im Bereich Weltraum, die freiwillig höhere Anforderungen an Sicherheit, Resilienz und ökologische Nachhaltigkeit zusätzlich zu den in der Verordnung festgelegten Anforderungen erfüllen, das Weltraumsiegel der Union verliehen werden kann.

TITEL VII Übergangs- und Schlussbestimmungen

Titel VII (Artikel 114-120) enthält die Bestimmungen bezüglich der Befugnis der Kommission zum Erlass von delegierten Rechtsakten und Durchführungsrechtsakten sowie über das Berufsgeheimnis. Ferner sind dort eine Überprüfungsklausel, Übergangsfristen sowie das Datum des Inkrafttretens und der Anwendung vorgesehen.

DAS EUROPÄISCHE PARLAMENT UND DER RAT DER EUROPÄISCHEN UNION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union, insbesondere auf Artikel 114,

auf Vorschlag der Europäischen Kommission,

nach Zuleitung des Entwurfs des Gesetzgebungsakts an die nationalen Parlamente,

nach Stellungnahme des Europäischen Wirtschafts- und Sozialausschusses^(15(1),

nach Stellungnahme des Ausschusses der Regionen^(16(2),

gemäß dem ordentlichen Gesetzgebungsverfahren,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Weltraumgestützte Daten und Weltraumdienste sind zu einem wichtigen Bestandteil der Wirtschaft der Union und des täglichen Lebens der Bürgerinnen und Bürger geworden. Sie werden in Sektoren genutzt, die für das Funktionieren des Binnenmarkts von entscheidender Bedeutung sind, einschließlich der Sektoren, die unter die Richtlinie (EU) 2022/2557 des Europäischen Parlaments und des Rates über die Resilienz kritischer Einrichtungen^(17)^(3) und die Richtlinie (EU) 2022/2555 des Europäischen Parlaments und des Rates über Maßnahmen für ein hohes gemeinsames Cybersicherheitsniveau in der Union^(18)^(4) fallen.

<a id="rec-2"></a>
(2) Weltraumgestützte Daten und Weltraumdienste leisten unschätzbare Beiträge zu einer großen Vielzahl von Bereichen wie Internetanbindung, Satellitenfernsehen, Navigationsmanagement und Umweltüberwachung. Sie ermöglichen Anwendungen für wissenschaftliche Zwecke oder Sicherheits- und Verteidigungsoperationen wie Such- und Rettungseinsätze, Kommunikation für Befehls- und Kontrollzwecke und Aufklärungsfähigkeiten. Weltraumgestützte Daten und Weltraumdienste unterstützen zunehmend die Durchsetzung der staatlichen Politik der Mitgliedstaaten und fördern die politische Agenda der Union und ihren Weg zum digitalen und ökologischen Wandel.

<a id="rec-3"></a>
(3) In der Weltraumwirtschaft der Union waren in den letzten zehn Jahren strukturelle Veränderungen zu verzeichnen. Dies war zum Teil auf eine gestiegene Nachfrage nach Weltraumdiensten und einen verbesserten Zugang zum Weltraum aufgrund des technologischen Fortschritts und der Kostensenkungen zurückzuführen. Weltraumtätigkeiten, die zuvor auf wenige Mitgliedstaaten konzentriert waren und von großen etablierten Industrieakteuren dominiert wurden, sind schrittweise neuen Marktteilnehmern zugänglich geworden. Das Aufkommen – in den meisten Mitgliedstaaten – der sogenannten „New-Space“-Marktakteure, von denen die meisten private Unternehmen sind, hat eine Expansion des Weltraummarkts der Union ermöglicht und gleichzeitig den inhärent grenzübergreifenden Charakter von Weltraumtätigkeiten offenbart.

<a id="rec-4"></a>
(4) Diese grenzübergreifende Dimension von Weltraumtätigkeiten spiegelt sich in der länderübergreifenden Beschaffung von Weltrauminfrastrukturressourcen wider, bei der Produkte, Komponenten und Systeme verschiedener Segmente der Weltrauminfrastruktur sowie die einschlägige Technologie und das einschlägige Fachwissen von oder aus mehreren Mitgliedstaaten zusammengeführt werden. Gleichzeitig sind die Mitgliedstaaten bei der Durchführung von Raumfahrzeugstarts untereinander auf ihre Fähigkeiten angewiesen. Ebenso wird bei den Start- und Wiedereintrittsoperationen die inhärent grenzübergreifende Dimension deutlich, da Weltraumtätigkeiten Auswirkungen auf den Luftraum mehrerer Mitgliedstaaten haben.

<a id="rec-5"></a>
(5) Die strukturellen Veränderungen in der Weltraumwirtschaft der Union, die Zunahme der Weltraumtätigkeiten und die wachsende Rolle privater Akteure bei der Durchführung von Weltraumtätigkeiten haben wiederum zu einer Ausweitung der nationalen regulatorischen Interventionen geführt. 13 Mitgliedstaaten haben bereits Rechtsvorschriften zur Regelung der Weltraumtätigkeiten erlassen, während mehrere andere Mitgliedstaaten Vorbereitungen für den Erlass ähnlicher Rechtsvorschriften treffen.

<a id="rec-6"></a>
(6) Nationale regulatorische Interventionen beruhen auf dem legitimen Bedürfnis der Mitgliedstaaten, die Art und Weise der Durchführung ihrer Weltraumtätigkeiten zu regeln. Die Mitgliedstaaten kommen ihren Verpflichtungen gemäß Artikel VI des Vertrags der Vereinten Nationen (VN) über die Grundsätze zur Regelung der Tätigkeiten von Staaten bei der Erforschung und Nutzung des Weltraums einschließlich des Mondes und anderer Himmelskörper (Weltraumvertrag) nach, da sie gemäß diesem Vertrag eine internationale Verantwortung und Haftung für alle nationalen Tätigkeiten tragen, die von staatlichen Stellen oder nichtstaatlichen Einrichtungen im Weltraum durchgeführt werden. Im Weltraumvertrag ist gefordert, dass die nationalen Tätigkeiten im Einklang mit dessen Bestimmungen durchgeführt werden, wobei ausdrücklich verlangt wird, dass Tätigkeiten im Weltraum, die von nichtstaatlichen Einrichtungen durchgeführt werden, der Genehmigung und fortlaufenden Aufsicht durch den jeweiligen Vertragsstaat des Weltraumvertrags unterliegen müssen.

<a id="rec-7"></a>
(7) Weder im Weltraumvertrag noch in einem anderen internationalen Vertrag des VN-Regelungsrahmens für den Weltraum sind jedoch spezifische und detaillierte Vorschriften vorgesehen, um den neuen Risiken im Zusammenhang mit der Zunahme der Weltraumtätigkeiten zu begegnen. Die von den Vereinten Nationen angenommenen Richtlinien zur langfristigen Nachhaltigkeit bieten einen Handlungsrahmen für nationale und regionale Stellen, um den künftigen Schutz der Umlaufbahnen sicherzustellen. Abgesehen von diesen unverbindlichen Richtlinien stellen jedoch die Überlastung der Umlaufbahnen, das Risiko von Kollisionen, das Risiko der Störung von Weltraumdiensten aufgrund von Cyberangriffen auf die Weltrauminfrastruktur sowie die Umweltauswirkungen von Weltraumtätigkeiten einen wachsenden Grund zur Sorge um die Sicherheit, Resilienz und ökologische Nachhaltigkeit von Weltraumtätigkeiten dar, für die es auf internationaler Ebene keine Rechtsvorschriften gibt, sodass eine Regelungslücke besteht.

<a id="rec-8"></a>
(8) Darüber hinaus gehen die internationalen Weltraumverträge auf eine Zeit zurück, in der das Weltraumrecht noch in den Kinderschuhen steckte, und sie legen den Grundstein für einen allgemeinen Rahmen allgemeiner Grundsätze und Verpflichtungen. In Ermangelung aktueller und detaillierter technischer Normen zur Bewältigung neuer Sicherheits-, Resilienz- und Nachhaltigkeitsrisiken verfolgen die Mitgliedstaaten ihre eigenen Regulierungs- und Genehmigungsansätze mit unterschiedlichen Vorschriften für den Betrieb von Satelliten, für Startplätze und Startbetrieb, Trägerraketen und Satelliten an Bord.

<a id="rec-9"></a>
(9) Diese Ansätze verfolgen ein gemeinsames Ziel, nämlich die Festlegung der Genehmigungsbedingungen zwecks Bewältigung der oben genannten Risiken. Die Mitgliedstaaten erkennen damit an, wie wichtig es ist, die Sicherheit von Umlaufbahnen und die Resilienz der Weltrauminfrastruktur unter gebührender Berücksichtigung der optimalen und nachhaltigen Nutzung des Weltraums zu wahren. Diese nationalen Rechtsvorschriften für den Bereich Weltraum unterscheiden sich jedoch hinsichtlich des Umfangs und der Tiefe der spezifischen Anforderungen zur Bewältigung der Risiken für die Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten. Diesbezüglich variieren die Ansätze der Mitgliedstaaten von minimalistischen Ansätzen bis hin zu detaillierten normativen Grundsätzen. Unterschiedliche nationale Anforderungen können zu einer Fragmentierung des Binnenmarkts führen und die von den Unionsbetreibern im Bereich Weltraum benötigte Rechtssicherheit herabsetzen.

<a id="rec-10"></a>
(10) Infolgedessen bilden sich in der Union verschiedene fragmentierte Rahmenwerke für Weltraumtätigkeiten aus, die durch eine Vielzahl von Normen mit unterschiedlichem Detaillierungsgrad bedingt sind, was auch zu einer mangelnden Koordinierung zwischen den Mitgliedstaaten führt.

<a id="rec-11"></a>
(11) Eine Fragmentierung der Genehmigungsbedingungen in Bezug auf Schlüsselelemente der Weltrauminfrastruktur (wie etwa Raumfahrzeuge) oder die Vorschriften für das Cyberrisikomanagement bei der Erbringung von Weltraumdiensten oder die Umweltauswirkungen von Weltraumtätigkeiten kann sich nachteilig auf die Freiheit zur Bereitstellung von weltraumgestützten Daten, die von der Weltrauminfrastruktur generiert werden, sowie die Erbringung und Nutzung von Weltraumdiensten in der Union auswirken.

<a id="rec-12"></a>
(12) Typische Ressourcen der Weltrauminfrastruktur, wie z. B. Raumfahrzeuge, die die in einigen Rechtsvorschriften festgelegten spezifischen Anforderungen nicht erfüllen, dürfen möglicherweise nicht im Binnenmarkt für Weltraumdienste genutzt werden. Einige Mitgliedstaaten haben sich beispielsweise dafür entschieden, aus Sicherheitsgründen strengere Anforderungen an die Konstruktion von Satelliten zu stellen, als sie nach den Rechtsvorschriften anderer Mitgliedstaaten für zum Start zugelassene Satelliten gelten. Diese Divergenz kann nicht nur den grenzüberschreitenden Handel für ein Unternehmen, das Satelliten liefert, erschweren, sondern birgt auch die Gefahr, dass Mitgliedstaaten, die in Bezug auf die die Sicherheitsgenehmigung betreffenden Anforderungen eine strenge Haltung einnehmen, beschließen, in ihrem Hoheitsgebiet den Start von Satelliten nicht zuzulassen, deren Betrieb in Mitgliedstaaten, in denen weniger strenge Sicherheitsanforderungen gelten, zulässig ist. Ebenso könnte die Bereitstellung von Weltraumdiensten, wie etwa Betriebs- und Startdiensten, im gesamten Binnenmarkt beeinträchtigt werden, wenn Anforderungen an die Überwachung und Verfolgung vor und nach dem Start von Satelliten oder spezifische Vorschriften über das Cyberrisikomanagement nur in einigen Mitgliedstaaten eingeführt würden.

<a id="rec-13"></a>
(13) Letztlich können sich solche Hindernisse nachteilig auf die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten in der gesamten Union auswirken. Da sich Weltraumdienste auf weltraumgestützte Daten stützen, die durch die Ressourcen der Weltrauminfrastruktur generiert werden und diese nutzen, hängt die Bereitstellung von Weltraumdiensten vom Niveau der Sicherheit und Resilienz der Ressourcen der Weltrauminfrastruktur ab.

<a id="rec-14"></a>
(14) Anforderungen, die höhere Kosten verursachen, wie z. B. Konstruktionsanforderungen zur Vermeidung einer Zunahme von Weltraummüll, oder Risikobewertungen zur Gewährleistung der Cybersicherheit in den verschiedenen Segmenten der Weltrauminfrastruktur, können die Unionsbetreiber im Bereich Weltraum dazu veranlassen, sich in Hoheitsgebieten mit weniger strengen Genehmigungsanforderungen niederzulassen.

<a id="rec-15"></a>
(15) Angesichts der wachsenden Zahl von Unionsbetreibern im Bereich Weltraum sowie der steigenden Zahl von Unternehmen, die Trägerraketenlösungen entwickeln, und der Mitgliedstaaten, die die Entwicklung von Startfähigkeiten planen, dürfte sich der grenzübergreifende Charakter der Weltraumtätigkeiten in der Union verstärken. Vor diesem Hintergrund werden die unterschiedlichen Bedingungen in den nationalen Genehmigungsregelungen wahrscheinlich zu weiteren Hürden in der Weltraumwirtschaft führen, was Auswirkungen auf die Kontinuität der Versorgung mit weltraumgestützten Daten und der Bereitstellung von Weltraumdiensten haben wird, die ihrerseits viele Tätigkeitsbereiche im Binnenmarkt unterstützen, einschließlich kritischer Sektoren und Infrastrukturen.

<a id="rec-16"></a>
(16) Um das Funktionieren des Binnenmarkts zu gewährleisten und zu verbessern, sollte daher auf Unionsebene eine Reihe einheitlicher, wirksamer und verhältnismäßiger verbindlicher Vorschriften festgelegt werden, durch die zentrale Aspekte im Bereich der Weltraumdienste im Zusammenhang mit der Genehmigung von Weltraumtätigkeiten harmonisiert werden, um die ungehinderte Bereitstellung von weltraumgestützten Daten und Weltraumdiensten im gesamten Binnenmarkt sicherzustellen.

<a id="rec-17"></a>
(17) Durch die Festlegung technologieneutraler Kernanforderungen sollte Innovation gefördert werden, indem Anbietern von Weltraumdiensten Zugang zu aktuellen und potenziellen neuen Märkten geboten wird, was zu einer größeren Auswahl für die Endnutzer führt.

<a id="rec-18"></a>
(18) Nur in begrenzten Fällen sollte die Kommission angesichts der strategischen Bedeutung des Zugangs der Union oder der Mitgliedstaaten zu bestimmten Weltraumdiensten eine Ausnahme von den in dieser Verordnung festgelegten Anforderungen für Startdienste gewähren, wenn dies durch ein öffentliches Interesse gerechtfertigt ist. Der Kommission sollten Durchführungsbefugnisse übertragen werden, um dem jeweiligen Startbetreiber aus einem Drittland eine Ausnahme zu gewähren, wenn die Bedingung eines öffentlichen Interesses erfüllt ist.

<a id="rec-19"></a>
(19) Derweil könnte in Not- oder Krisensituationen ein rasches Handeln erforderlich sein, um weltraumgestützte Daten oder Weltraumdienste, die von nicht in der Union registrierten Anbietern von Weltraumdiensten bereitgestellt werden, ausnahmsweise und vorübergehend zu nutzen.

<a id="rec-20"></a>
(20) In der Union niedergelassene Anbieter von Weltraumdiensten sollten einer Genehmigungsregelung unterliegen, um die wesentlichen Sicherheits- und Resilienzaspekte typischer Weltraumdienste zu berücksichtigen, die beispielsweise den Betrieb von Raumfahrzeugen, die Bereitstellung von Startdiensten sowie den Betrieb und die Instandhaltung von Startplätzen betreffen. Unionsbetreiber im Bereich Weltraum, die unionseigene Ressourcen betreiben, sollten die Genehmigung von der mit der Verordnung (EU) 2021/696 des Europäischen Parlaments und des Rates^(19)^(5) eingerichteten Agentur der Europäischen Union für das Weltraumprogramm (im Folgenden „Agentur“) erhalten und Unionsbetreibern im Bereich Weltraum, die nicht im Eigentum der Union stehende Ressourcen betreiben, sollte die Genehmigung von den Mitgliedstaaten erteilt werden.

<a id="rec-21"></a>
(21) In der Union niedergelassene Anbieter von Weltraumdiensten, die fortgeschrittene Weltraumdienste wie Weltraumdienste zur Kollisionsvermeidung oder Operationen und Dienste im Weltraum (ISOS) anbieten, unterstützen die typischen Weltraumdienste und spielen eine Rolle beim Schutz und der langfristigen Nachhaltigkeit der Ressourcen der Weltrauminfrastruktur. Daher ist es angezeigt, diese Kategorie neuer Anbieter von Weltraumdiensten einem begrenzten Regelwerk zu unterwerfen. Dies würde die Entwicklung neuer Anwendungen und Märkte in der Weltraumwirtschaft (Weltraumwirtschaft) ermöglichen.

<a id="rec-22"></a>
(22) Die Primäranbieter weltraumgestützter Daten spielen eine Schlüsselrolle als Bindeglied zwischen den vor- und den nachgelagerten Sektoren, da sie weltraumgestützte Daten von Betreibern im Bereich Weltraum für die verschiedenen nachfolgenden Verwendungen dieser weltraumgestützten Daten zum Nutzen der gesamten Wirtschaft und der Bürgerinnen und Bürger kanalisieren. Obgleich die materiellrechtlichen Vorschriften, die für Betreiber im Bereich Weltraum gelten, nicht für Primäranbieter weltraumgestützter Daten gelten sollten, spielen sie doch nach wie vor eine wichtige Rolle in der Weltraumwirtschaft, insofern sie sicherstellen, dass die weltraumgestützten Daten, die von den Primäranbietern weltraumgestützter Daten in der Wertschöpfungskette weitergereicht werden, von Betreibern im Bereich Weltraum stammen, die die Vorschriften dieser Verordnung einhalten. Daher sollte die Agentur eine Liste dieser Primäranbieter weltraumgestützter Daten in der Union erstellen. Angesichts ihrer Rolle als Bindeglied sind die Primäranbieter weltraumgestützter Daten am besten in der Lage, Warnmeldungen oder Beschwerden über mögliche Unregelmäßigkeiten im Zusammenhang mit der Verwendung weltraumgestützter Daten in der Union entgegenzunehmen, ihre Lieferanten direkt zu warnen oder die Agentur oder die jeweils zuständige Behörde in dem Mitgliedstaat, in dem sie niedergelassen sind, von etwaigen Vorwürfen in Kenntnis zu setzen, wonach möglicherweise weltraumgestützte Daten im Binnenmarkt genutzt werden, die möglicherweise von nicht registrierten oder nicht konformen Betreibern im Bereich Weltraum stammen.

<a id="rec-23"></a>
(23) Um gleiche Bedingungen für die Tätigkeit im Binnenmarkt zu schaffen, sollten die Vorschriften für alle in den Anwendungsbereich dieser Verordnung fallenden Anbieter von Weltraumdiensten, einschließlich der Unionsbetreiber im Bereich Weltraum, in dem Umfang gelten, in dem weltraumgestützte Daten und Weltraumdienste in der Union bereitgestellt werden.

<a id="rec-24"></a>
(24) Um sicherzustellen, dass keinem Betreiber im Bereich Weltraum ein Vorteil dadurch entsteht, dass er nicht den in dieser Verordnung festgelegten Vorschriften unterliegt, ist es daher angebracht, eine einheitliche Behandlung aller Betreiber im Bereich Weltraum, einschließlich Anbietern von Weltraumdiensten aus Drittländern wie Raumfahrzeugbetreibern aus Drittländern, Startanbietern aus Drittländern und Primäranbietern weltraumgestützter Daten aus Drittländern, sicherzustellen, wenn sie weltraumgestützte Daten oder Weltraumdienste in der Union bereitstellen.

<a id="rec-25"></a>
(25) Diese Verordnung sollte daher für Anbieter von Weltraumdiensten unabhängig von ihrem Niederlassungsort gelten, sofern die weltraumgestützten Daten oder Weltraumdienste in der Union bereitgestellt werden und somit ein wesentlicher Bezug zum Binnenmarkt belegt ist, wodurch das Risiko einer Umgehung von Vorschriften zum Nachteil der Verbraucherinnen und Verbraucher sowie Unternehmen in der Union verhindert und die Wirksamkeit der mit dieser Verordnung verfolgten Ziele gewahrt wird.

<a id="rec-26"></a>
(26) Alle in einem Drittland niedergelassenen Anbieter von Weltraumdiensten sollten in Abhängigkeit von ihren kommerziellen Erfordernissen und organisatorischen Anforderungen schriftlich einen oder mehrere gesetzliche Vertreter in der Union benennen. Diese gesetzlichen Vertreter in der Union sollten mit allen erforderlichen Befugnissen und Ressourcen ausgestattet werden, um mit den zuständigen Behörden, der Kommission und der Agentur in Bezug auf alle Aspekte zusammenzuarbeiten, die für den Erhalt von Informationen und Entscheidungen im Zusammenhang mit der Einhaltung und Durchsetzung dieser Verordnung erforderlich sind.

<a id="rec-27"></a>
(27) Bestimmte Drittländer legen möglicherweise Wert auf ein hohes Niveau der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten und stellen daher Anforderungen an die Sicherheit, Resilienz und ökologische Nachhaltigkeit, die mit den in dieser Verordnung festgelegten Anforderungen vergleichbar sind.

<a id="rec-28"></a>
(28) In diesen Fällen soll durch einen Gleichwertigkeitsmechanismus die Anerkennung eines Schutzniveaus sichergestellt werden, das mit dem nach dieser Verordnung erforderlichen Schutzniveau vergleichbar ist. Wenn die Kommission in Bezug auf den geltenden Rechtsrahmen eines Drittlands und die in diesem Drittland geltenden rechtsverbindlichen Vorschriften, die als gleichwertig mit den in dieser Verordnung festgelegten Anforderungen angesehen werden, eine Bewertung durchgeführt hat, sollte daher die Einhaltung der Vorschriften durch die in diesem Drittland niedergelassenen Anbieter von Weltraumdiensten auf dieser Grundlage festgestellt werden. Diese Anbieter von Weltraumdiensten sollten die Möglichkeit haben, weltraumgestützte Daten und Weltraumdienste in der Union auf der Grundlage eines von der Kommission zu erlassenden Gleichwertigkeitsbeschlusses bereitzustellen.

<a id="rec-29"></a>
(29) Anbieter von Weltraumdiensten, die in einem Drittland niedergelassen sind, für das kein Gleichwertigkeitsbeschluss erlassen wurde, sollten verpflichtet werden, sich Kontrollen zu unterziehen, um die Einhaltung der in dieser Verordnung festgelegten Anforderungen festzustellen. Im Sinne der Konvergenz der Aufsichtskonzepte sollte die Agentur die technischen Bewertungen durchführen, die die Kommission benötigt, um die Einhaltung der Vorschriften festzustellen, und die es ihr ermöglichen, auf der Grundlage technischer Bewertungen über die Registrierung von Anbietern von Weltraumdiensten in der Union sowie über etwaige Aufsichtsmaßnahmen zu entscheiden. Zu diesem Zweck sollte auf Unionsebene ein Register eingerichtet werden.

<a id="rec-30"></a>
(30) Die Union sollte sich nach und nach um den Abschluss von Abkommen über die gegenseitige Anerkennung mit Drittländern bemühen.

<a id="rec-31"></a>
(31) Um alle Ressourcen der Weltrauminfrastruktur umfassend abzudecken und Lücken zu vermeiden, sollte diese Verordnung auch für Ressourcen gelten, die von internationalen Organisationen, die Weltraumtätigkeiten ausüben, wie der Europäischen Weltraumorganisation (ESA) oder der Europäischen Organisation für die Nutzung von meteorologischen Satelliten (EUMETSAT), betrieben werden. Derartige internationale Organisationen sind angesichts ihres umfangreichen technischen, wissenschaftlichen und operativen Fachwissens sowie ihrer speziellen Infrastruktur und Fähigkeiten im Weltraumbereich wichtige Partner für die Kommission, die Agentur und die Mitgliedstaaten, insbesondere im Zusammenhang mit der Umsetzung von Komponenten des Weltraumprogramms der Union, der gemeinsamen Beschaffung oder Programmen der Mitgliedstaaten.

<a id="rec-32"></a>
(32) Um im Rahmen der mit dieser Verordnung verbundenen Harmonisierung regulatorische Kohärenz zu erreichen, sollten diese internationalen Organisationen, wenn sie ihre eigenen Ressourcen betreiben, dem Unionsrecht unterliegen, und zwar unter angemessenen Bedingungen, was die Mittel zur Anwendung des Unionsrechts auf sie und die Durchsetzung angeht, die in internationalen Abkommen zwischen der Union und jeder dieser internationalen Organisationen festgelegt werden sollten. Betreiben diese internationalen Organisationen Ressourcen der Mitgliedstaaten, so sollten die zuständigen Behörden für die Durchsetzung der in dieser Verordnung festgelegten Vorschriften sorgen. Betreiben diese internationalen Organisationen unionseigene Ressourcen, sollte die Durchsetzung im Einklang mit den Bestimmungen der von der Kommission zu diesem Zweck geschlossenen Beitragsvereinbarungen sichergestellt werden.

<a id="rec-33"></a>
(33) Die ESA ist eine internationale Organisation mit umfangreicher Fachkompetenz im Bereich Weltraum und ein wichtiger Partner bei der Umsetzung des Weltraumprogramms der Union. Die ESA entwickelt und betreibt im Einklang mit speziellen Vereinbarungen Ressourcen der Weltrauminfrastruktur für das Weltraumprogramm der Union und das Programm der Union für sichere Konnektivität. Die ESA entwickelt zudem im Namen der Mitgliedstaaten und im Rahmen ihrer mandatsmäßigen Tätigkeiten und optionalen Programme Weltraummissionen und leistet auf Ersuchen eines oder mehrerer Mitgliedstaaten Unterstützung für nationale Projekte im Weltraumbereich. Die ESA ist auch eine zentrale Triebkraft für die Entwicklung technischer Normen für Weltraumtätigkeiten. Die Bedingungen für die Anwendung dieser Verordnung auf die ESA sollten in einer Vereinbarung unter gebührender Berücksichtigung des Status und des institutionellen Rahmens der ESA näher festgelegt werden.

<a id="rec-34"></a>
(34) Die in dieser Verordnung festgelegten Vorschriften sollten sich sowohl auf unionseigene Ressourcen gemäß der Verordnung (EU) 2021/696 und der Verordnung (EU) 2023/588 des Europäischen Parlaments und des Rates^(20)^(6) als auch auf Ressourcen der Mitgliedstaaten erstrecken, unabhängig davon, ob sie sich im Eigentum staatlicher oder gewerblicher Betreiber befinden oder von diesen betrieben werden, einschließlich Ressourcen mit doppeltem Verwendungszweck, die unter zivile Kontrolle gestellt sind und für zivile Zwecke genutzt werden.

<a id="rec-35"></a>
(35) Was unionseigene Ressourcen betrifft, sollten Anbieter von Weltraumdiensten von der Agentur die Genehmigung für den Betrieb derjenigen unionseigenen Ressourcen erhalten, die die Anforderungen an Sicherheit, Resilienz und ökologische Nachhaltigkeit erfüllen.

<a id="rec-36"></a>
(36) Um die Zuständigkeiten der Mitgliedstaaten zu wahren, sollte diese Verordnung nicht für Weltraumobjekte gelten, die ausschließlich dazu verwendet werden, Ziele der Verteidigung oder der nationalen Sicherheit zu ermöglichen, unabhängig davon, welche Einrichtung solche Weltraumtätigkeiten durchführt. Weltraumobjekte, die nur teilweise für Verteidigungszwecke genutzt werden, sollten vom Anwendungsbereich dieser Verordnung ausgenommen werden, wenn sie zu Verteidigungszwecken nur für die Dauer der jeweiligen von den Streitkräften durchgeführten Weltraummission unter die Kontrolle eines Mitgliedstaats gestellt und von diesem betrieben werden müssen. In solchen Fällen obliegt es jedem Mitgliedstaat, unter Berücksichtigung der Umstände des Einzelfalls zu entscheiden, ob ein solches Weltraumobjekt unter die oben genannte Ausnahme fällt.

<a id="rec-37"></a>
(37) Diese Verordnung sollte daher die Zuständigkeiten der Mitgliedstaaten in Bezug auf alle Angelegenheiten im Zusammenhang mit der nationalen Sicherheit unberührt lassen, was sich auch auf Fälle erstreckt, in denen die Mitgliedstaaten für die Zwecke und die Ausübung dieser Zuständigkeit im Bereich der nationalen Sicherheit bestimmte Weltraumtätigkeiten durchführen müssen, indem sie beispielsweise die Kontrolle über ein ihrer Rechtshoheit unterworfenes Weltraumobjekt übernehmen.

<a id="rec-38"></a>
(38) Angesichts der bestehenden Regelung der Funkfrequenznutzung im Rahmen des internationalen Telekommunikationsrechts und des damit in Einklang stehenden nationalen und EU-Rechts, insbesondere der Entscheidung Nr. 676/2002/EG des Europäischen Parlaments und des Rates^(21)^(7), der Richtlinie (EU) 2018/1972 des Europäischen Parlaments und des Rates^(22)^(8) und des Beschlusses Nr. 243/2012/EU des Europäischen Parlaments und des Rates^(23)^(9), sollte diese Verordnung keine Aspekte im Zusammenhang mit der Zuweisung von Funkfrequenzen oder der Genehmigung für ihre Nutzung abdecken. Wenn ein Unternehmen, bei dem es sich um einen Anbieter elektronischer Kommunikationsnetze und -dienste handelt, nur als bloßer Nutzer einer von einem Betreiber im Bereich Weltraum angebotenen Einrichtung handelt, sollte es zudem nur als Primäranbieter weltraumgestützter Daten im Sinne dieser Verordnung gelten. Betreibt oder kontrolliert ein Anbieter elektronischer Kommunikationsnetze und -dienste auch einen Satelliten oder eine Startinfrastruktur, so sollte er als Betreiber im Bereich Weltraum im Sinne dieser Verordnung gelten.

<a id="rec-39"></a>
(39) Diese Verordnung gilt unbeschadet der Wettbewerbsvorschriften der Union, einschließlich der Kartell-, Fusions- und Beihilfevorschriften.

<a id="rec-40"></a>
(40) Die in dieser Verordnung festgelegten wesentlichen harmonisierten Mindestvorschriften über die Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten sollten die von den zuständigen Behörden erteilten Genehmigungen oder gegebenenfalls die von den Mitgliedstaaten festgelegten Regelungen für staatliche Stellen, die ein nationales Weltraumprogramm durchführen, einbeziehen. Dem besonderen Charakter bestimmter Einrichtungen, wie z. B. nationale Weltraumprogramme durchführender staatlicher Weltraumagenturen, die möglicherweise nicht unbedingt in gleicher Weise genehmigungspflichtig sind wie andere Anbieter von Weltraumdiensten, sollte Rechnung getragen werden. Folglich sollten die Mitgliedstaaten in Bezug auf diese Einrichtungen für eine angemessene Aufsicht sorgen, bei der die Grundsätze der Aufgabentrennung und des Nichtvorliegens von Interessenkonflikten geachtet und umgesetzt werden.

<a id="rec-41"></a>
(41) Um nahtlose Genehmigungsverfahren im gesamten Binnenmarkt zu ermöglichen und für die Gleichbehandlung aller Unionsbetreiber im Bereich Weltraum zu sorgen, sollte die Gesamtdauer der Genehmigungsverfahren 12 Monate betragen, wobei die Möglichkeit bestehen sollte, die im Genehmigungsverfahren geltenden Fristen auszusetzen, um der Notwendigkeit weiterer Klarstellungen und Bewertungen Rechnung zu tragen.

<a id="rec-42"></a>
(42) Den Mitgliedstaaten sollte es weiterhin freistehen, sich im Vorfeld ihrer formellen Genehmigungsverfahren im Einklang mit ihren nationalen Vorschriften mit potenziellen Antragstellern auszutauschen. Ein solcher erster und informeller Austausch würde es den Antragstellern ermöglichen, die Anforderungen, die in dieser Verordnung und gegebenenfalls den nationalen Rechtsvorschriften, einschließlich aller einschlägigen Rechtsvorschriften anderer Mitgliedstaaten, falls beispielsweise in Anbetracht der Kriterien der Staatsangehörigkeit, der Niederlassung, des Betriebsorts oder des Startorts mehrere Genehmigungen im Binnenmarkt erforderlich sind, festgelegt sind, besser zu verstehen und ihre Einhaltung sicherzustellen.

<a id="rec-43"></a>
(43) Die zuständigen Behörden eines Mitgliedstaats sollten die von den zuständigen Behörden anderer Mitgliedstaaten erteilten Genehmigungen in Bezug auf die unter diese Verordnung fallenden Angelegenheiten akzeptieren und anerkennen. Zugleich sollte für die vollständige Transparenz der nationalen Anforderungen, die möglicherweise von den Mitgliedstaaten festgelegt werden, gesorgt werden, einschließlich strengerer Anforderungen, die erforderlich sein können, um die Sicherheit, Resilienz oder ökologische Nachhaltigkeit einer Tätigkeit oder eines Starts zu gewährleisten, die bzw. der in ihrem Hoheitsgebiet im Zusammenhang mit einer Weltraummission durchgeführt wird, die von in ihrem eigenen Niederlassungsmitgliedstaat zugelassenen Betreibern im Bereich Weltraum durchgeführt wird. Diese Informationen sollten über ein gemeinsames Informationsportal bereitgestellt werden.

<a id="rec-44"></a>
(44) Angesichts der technischen Komplexität und der Dauer der Vorbereitung einer Weltraummission sollten die Antragsteller ausreichend Zeit für die Vorlage aller erforderlichen Informationen oder Klarstellungen haben. Dabei sollte auch eine Aussetzung der im Rahmen der Genehmigungsverfahren für die zuständigen Behörden geltenden Fristen vorgesehen werden.

<a id="rec-45"></a>
(45) Die Vermutung der Konformität der Weltraumobjekte mit den Anforderungen dieser Verordnung sollte sowohl bei in der Union niedergelassenen Anbietern von Weltraumdiensten gelten, da diese Konformität von den zuständigen nationalen Behörden im Zuge der Erteilung der Genehmigung überprüft wurde, als auch bei in einem Drittland niedergelassenen Anbietern von Weltraumdiensten, für die die Kommission einen Gleichwertigkeitsbeschluss erlassen hat.

<a id="rec-46"></a>
(46) Sobald die Einhaltung der in dieser Verordnung festgelegten Anforderungen festgestellt wurde, sollten die Registrierung im Unionsregister der Weltraumobjekte (URSO) und die Ausstellung eines elektronischen Zertifikats (e-Zertifikat) – mit dem nachgewiesen wird, dass die weltraumgestützten Daten von Weltraumobjekten generiert wurden, die dieser Verordnung entsprechen, bzw. dass die Weltraumdienste auf der Nutzung und dem Betrieb von Weltraumobjekten basieren, die dieser Verordnung entsprechen – die uneingeschränkte Bereitstellung der weltraumgestützten Daten und Weltraumdienste in der gesamten Union ermöglichen. Die Agentur sollte registrierten Anbietern von Weltraumdiensten die einzelnen elektronischen Zertifikate ausstellen.

<a id="rec-47"></a>
(47) Konsolidierte Listen aller in der Union und in Drittländern niedergelassenen Anbieter von Weltraumdiensten, die im URSO registriert sind, sollten der Öffentlichkeit über die URSO-Website zugänglich gemacht werden, um so für Transparenz in Bezug auf alle in der Union registrierten Anbieter von Weltraumdiensten zu sorgen. Jede Person sollte die Quelle der weltraumgestützten Daten überprüfen können, um sich jederzeit zu vergewissern, dass die in der Union bereitgestellten Weltraumdienste Daten nutzen, die von Weltraumobjekten erzeugt wurden, die die Anforderungen des Unionsrechts erfüllen.

<a id="rec-48"></a>
(48) Auf Ersuchen der Kommission sollte ein spezifischer Standard für das elektronische Zertifikat ausgearbeitet werden, der bis zum Geltungsbeginn dieser Verordnung vorliegen sollte. Das elektronische Zertifikat würde die Verbindung zwischen einem bestimmten Weltraumobjekt und den weltraumgestützten Daten herstellen, die durch seine Nutzung generiert wurden, und die Integrität dieser weltraumgestützten Daten gewährleisten.

<a id="rec-49"></a>
(49) Um der gestiegenen Nachfrage der Kunden nach Satellitenangeboten gerecht zu werden, die Vorteile des technologischen Fortschritts und der damit verbundenen Kostensenkungen zu nutzen und einen besseren Zugang zu Kapital sicherzustellen, sollten die Genehmigungsverfahren für den Start von Satellitenkonstellationen gestrafft werden. Unter bestimmten Voraussetzungen und vorbehaltlich einer Reihe von Absicherungen sollte ein vereinfachtes Genehmigungsverfahren zur Verfügung stehen, das zur Erteilung einer einzigen Genehmigung führt, die für die gesamte Satellitenkonstellation gültig ist.

<a id="rec-50"></a>
(50) In Anerkennung der besonderen Art und des besonderen Zwecks von Forschungsraumfahrzeugen, die nach wie vor von entscheidender Bedeutung für die Förderung wissenschaftlicher Erkenntnisse und technologischer Fähigkeiten sind, sollten in dieser Verordnung bestimmte Ausnahmen für diese Kategorien festgelegt werden, um ihren besonderen Erfordernissen und Merkmalen Rechnung zu tragen und gleichzeitig die Sicherheit und Nachhaltigkeit der Umlaufbahnen sicherzustellen.

<a id="rec-51"></a>
(51) Betreiber im Bereich Weltraum sollten in den Genuss spezieller Ausnahmen von den Vorschriften kommen, die in den verschiedenen unter diese Verordnung fallenden Bereichen festgelegt sind. Bei der Durchführung von Forschungsmissionen im Weltraum sollten sie von bestimmten Sicherheitsvorschriften ausgenommen werden. Ebenso sollten Betreiber im Bereich Weltraum, die als kleine Unternehmen eingestuft oder Forschungs- oder Bildungseinrichtungen sind, ein vereinfachtes Risikomanagement anwenden, dessen Schwerpunkt auf kritischen Ressourcen liegt und das den wichtigsten Risiken begegnet. Weltraummissionen für die In-Orbit-Demonstration/In-Orbit-Validierung (IOD/IOV) sollten ebenfalls von der Berechnung des Umweltfußabdrucks von Weltraumtätigkeiten ausgenommen werden.

<a id="rec-52"></a>
(52) Es ist von entscheidender Bedeutung, einen sicheren, resilienten, nachhaltigen und kosteneffizienten Zugang zum Weltraum sicherzustellen, um – im Einklang mit den im Weltraumvertrag verankerten zentralen Grundsätzen und Rechten – über eine Vielzahl von Diensten verfügen zu können und die wissenschaftliche Forschung zu unterstützen. Zugleich benötigen Startbetreiber möglicherweise auch Zeit für die Anpassung an die neuen Sicherheitsmaßnahmen für Starts. Diese Verordnung sollte einen geeigneten Mechanismus vorsehen, um den Zugang zum Weltraum sicherzustellen, während sich die Industrie an die auf Unionsebene eingeführten neuen Grundanforderungen an die Sicherheit anpasst.

<a id="rec-53"></a>
(53) Die Überlastung bestimmter Umlaufbahnen, die ein erhöhtes Risiko der Kollision von Satelliten und der Ausbreitung von Weltraummüll mit sich bringt, sowie die geopolitische Bedrohungslage, die ein erhöhtes Risiko für die Cybersicherheit der Weltrauminfrastruktur birgt, mitsamt dem Risiko physischer Kontakte im Weltraum, beispielsweise aufgrund der Nähe oder von Störungen, stellen Herausforderungen globaler Natur dar, mit denen sich in jüngerer Zeit viele Raumfahrtnationen auseinandersetzen.

<a id="rec-54"></a>
(54) Der Markt für Trägerraketen – von Mikro- bis Schwerlast-Trägerraketen – hat sich weiterentwickelt. Es werden neue Fähigkeiten entwickelt, wie etwa die Wiederverwendbarkeit beispielsweise der ersten Stufe und der Booster der Trägerraketen. Mehr Mitgliedstaaten entwickeln Startfähigkeiten und intensivieren so den Zugang zum Weltraum.

<a id="rec-55"></a>
(55) Der Zugang zum Weltraum ist für die strategische Autonomie der EU von entscheidender Bedeutung. Ein erhöhter Startverkehr hat jedoch auch Folgen für die Sicherheit von Start und Wiedereintritt sowie für die Sicherheit in der Luft und am Boden. Der zunehmende Weltraumstartverkehr könnte sich auch negativ auf die wirtschaftliche, ökologische und effiziente Leistung des einheitlichen europäischen Luftraums auswirken. Das Risiko einer Störung des Luft- und Seeverkehrs sollte im Einvernehmen mit den zuständigen Behörden und Anbietern von Flugverkehrsdiensten minimiert werden. Die Koordinierung zwischen den zuständigen Behörden und den zuständigen Anbietern von Flugverkehrsdiensten auf nationaler Ebene trägt dazu bei, die Auswirkungen von Verkehrsstörungen und das Kollisionsrisiko zu begrenzen. Wenn Weltraumstarts mehr als einen Mitgliedstaat betreffen, bedarf es der rechtzeitigen Koordinierung zwischen den Betreibern im Bereich Weltraum und dem europäischen Netzmanager. Diese Koordinierung sollte eine Bewertung des Umfangs und der Dauer der Schließung des europäischen Luftraums sowie der betroffenen Flugstrecken umfassen. Erst zu einem späteren Zeitpunkt sollten angemessene Kostenteilungsverfahren für die Nutzung des Luftraums festgelegt werden. Hierdurch werden Anreize für die sichere und nachhaltige Nutzung des Luftraums für alle Nutzer geschaffen. Darüber hinaus können die Start- und Wiedereintrittsphasen auch ein Risiko für Unfälle am Boden bergen, das durch eine enge Abstimmung mit den betroffenen zuständigen Behörden und Anbietern von Flugverkehrsdiensten begrenzt werden muss. Dem zunehmenden Risiko von Kollisionen mit Luftfahrzeugen während der Flugphase zwischen Start und Wiedereintritt kann durch bewährte Flugsicherheitsmethoden und bewährte Verfahren für die Risikobewertung begegnet werden.

<a id="rec-56"></a>
(56) Starttätigkeiten sind von Natur aus risikobehaftet und können zu irreversiblen Schäden führen, wenn sie nicht ordnungsgemäß verwaltet werden. Daher sollten Vorschriften festgelegt werden, mit denen sichergestellt wird, dass Trägerraketen verfolgbar sind und einer Risikobewertung unterzogen werden, bei der besondere Maßnahmen zur weitestgehenden Minderung der damit verbundenen Risiken ermittelt und festgelegt werden.

<a id="rec-57"></a>
(57) Prognosen (ohne Berücksichtigung neuer Starts) zeigen, dass durch Kollisionen zwischen Weltraumobjekten, die sich bereits im Weltraum befinden, sehr viel Weltraummüll entstehen wird. Die Gefahr von Kollisionen von Weltraumobjekten würde letztlich eine bereits überlastete erdnahe Umlaufbahn (LEO) unter Druck setzen, was ein Risiko für den künftigen Zugang zum Weltraum darstellt. Der massemäßig größte Teil des Weltraummülls stammt von Teilen von Trägerraketen (Raketenkörpern). Unterdessen nimmt die Zahl der Raumfahrzeuge in den Umlaufbahnen aufgrund der Entwicklung von Satellitenkonstellationen rasch zu.

<a id="rec-58"></a>
(58) Um die Weltraumumgebung zu schützen, muss sichergestellt werden, dass Trägerraketen und Raumfahrzeuge eine möglichst geringe Menge an Müll erzeugen. Die Vermeidung von Müll steht auch im Einklang mit dem Ansatz der Abfallrahmenrichtlinie^(24)^(10), wonach die Vermeidung die erste Stufe der Abfallhierarchie ist. Folglich sollten entsprechende Vorgaben sowohl für die Konzeptionsphase als auch für die Lebensdauer im Orbit vorgesehen werden. Diese Notwendigkeit wird auch auf internationaler Ebene anerkannt, auf der mehrere Normen von der Internationalen Normungsorganisation (ISO) angenommen wurden. Daher sollte die Genehmigung zur Durchführung von Weltraumtätigkeiten daran geknüpft werden, dass die Betreiber im Bereich Weltraum spezifische, den Weltraummüll betreffende Pläne vorlegen, in denen dargelegt wird, wie die Entstehung von Weltraummüll bei den Trägerraketen und Raumfahrzeugen begrenzen wird.

<a id="rec-59"></a>
(59) Für das Funktionieren von Weltraumdiensten zur Kollisionsvermeidung für Raumfahrzeuge ist es erforderlich, dass die Raumfahrzeuge ihre Position präzise übermitteln können. Es sollten Anforderungen an die Verfolgbarkeit ausgearbeitet werden, um die öffentlichen Dienste der Partnerschaft zur Beobachtung und Verfolgung von Objekten im Weltraum (EU-SST) der Union zu verbessern sowie den Zeitaufwand und die Kosten für die genaue Bestimmung der Orbitalposition durch diese Verfolgungsdienste zu reduzieren. Die Fähigkeit, Raumfahrzeuge zu verfolgen, sollte sowohl auf Ebene der Raumfahrzeuge als auch auf Ebene des Bodensegments sichergestellt werden.

<a id="rec-60"></a>
(60) Aufgrund des zunehmenden Mülls und des immer dichteren Verkehrs in der Umlaufbahn ist die Nutzung eines Weltraumdienstes zur Kollisionsvermeidung für alle Raumfahrzeuge ein Muss. Diese Anforderung ist notwendig, um das laufende Station-Keeping des Raumfahrzeugs sicherzustellen. Die obligatorische Inanspruchnahme eines Weltraumdienstes zur Kollisionsvermeidung sollte im Mittelpunkt der Anforderungen in Bezug auf die Sicherheit im Weltraum stehen. Demgemäß müsste die für die Erbringung des Weltraumdienstes zur Kollisionsvermeidung zuständige Einrichtung bestimmte Fähigkeiten nachweisen.

<a id="rec-61"></a>
(61) Darüber hinaus sollte die Einrichtung, die für den Weltraumdienst zur Kollisionsvermeidung für alle Raumfahrzeuge in der Union zuständig ist, die Koordinierung der Reaktionen auf eine Warnmeldung zu Ereignissen von hohem Interesse (im Folgenden „HIE-Warnmeldung“) verbessern und auch das Risiko begrenzen, dass eine derartige Warnmeldung unterschiedliche Reaktionsstrategien auslöst, die ihrerseits eine Kollision verursachen könnten.

<a id="rec-62"></a>
(62) Die SST-Partnerschaft der EU, die als Teil der SSA-Komponente gemäß der Verordnung (EU) 2021/696 des Europäischen Parlaments und des Rates entwickelt wurde, bzw. eine Nachfolgeeinrichtung, hat unter Beweis gestellt, dass sie mithilfe ihrer Sensoren und ihres ausgereiften Know-hows in der Lage ist, eine große Zahl von Raumfahrzeugen zu verwalten, und daher als Unionsanbieter von Weltraumdiensten zur Kollisionsvermeidung geeignet ist, der für den Weltraumdienst zur Kollisionsvermeidung zuständig ist.

<a id="rec-63"></a>
(63) Die Entstehung von Müll sollte am besten vermieden werden, indem Kapazitäten für die Durchführung von Kollisionsvermeidungsmanövern und zum Verlagern von Satelliten in Friedhofsorbits verlangt werden. Folglich sollten alle Raumfahrzeuge mit der Fähigkeit ausgestattet werden, wiederholt Manöver auszuführen, mit Ausnahme von Raumfahrzeugen, die sich unterhalb von 400 km befinden, da der atmosphärische Widerstand in diesem Fall auf natürliche Weise für eine kurze orbitale Lebensdauer dieser Raumfahrzeugs sorgen würde.

<a id="rec-64"></a>
(64) Es ist gängige Praxis, dass Raumfahrzeugbetreibern die Genehmigung zur Verlängerung einer Weltraummission erteilt wird. Wenn sie eine Verlängerung beantragen, sollten die Raumfahrzeugbetreiber aus der Union jedoch überarbeitete Pläne zur Verringerung des Weltraummülls vorlegen müssen, um sicherzustellen, dass nicht die Gefahr besteht, dass durch die verlängerte Missionsdauer Weltraummüll erzeugt wird.

<a id="rec-65"></a>
(65) Aufgrund des zunehmenden Orbitalverkehrs stoßen Astronomen bei ihren astronomischen Beobachtungskampagnen auf Licht- und Funkfrequenzstörungen. Diese Störungen haben direkte Auswirkungen auf die Forschung und die planetaren Verteidigungsfähigkeiten. Daher sollten Risikominderungsmaßnahmen zum Schutz des dunklen und stillen Nachthimmels ausgearbeitet werden.

<a id="rec-66"></a>
(66) Satellitenkonstellationen sind von Vorteil für die effiziente Nutzung von Weltraumdiensten zum Nutzen der Bürgerinnen und Bürger und der Unternehmen. Aufgrund der großen Zahl von Satelliten haben sie jedoch größere Auswirkungen auf die Weltraumumgebung als ein einzelnes Raumfahrzeug. Darüber hinaus könnte jedes katastrophale Ereignis innerhalb der Konstellation das Kessler-Syndrom auslösen und den Zugang zum Weltraum in Zukunft unmöglich machen. Daher sollten für Satellitenkonstellationen spezielle und in Abhängigkeit von der Größe der Konstellationen unterschiedliche Verpflichtungen auferlegt werden.

<a id="rec-67"></a>
(67) Um die Effizienz der in Bezug auf die Sicherheit und Nachhaltigkeit im Weltraum festgelegten Kernanforderungen sicherzustellen, sollten weitere technische Elemente festgelegt werden, um für die Betreiber im Bereich Weltraum Rechtssicherheit zu gewährleisten.

<a id="rec-68"></a>
(68) Bislang wurde die Cybersicherheit in der Weltraumwirtschaft auf Unionsebene nur teilweise durch einen allgemein geltenden Rahmen gemäß der Richtlinie (EU) 2022/2555 geregelt. Die derzeitige Cybersicherheitsregelung deckt nicht alle Arten von Akteuren und Diensten vollumfänglich ab, die für die Weltraumwirtschaft relevant sind. Daher sollten Anforderungen an die Cybersicherheit für Anbieter nicht öffentlicher elektronischer Kommunikationsnetze und -dienste, für Einrichtungen, die unter die Größenobergrenze von mittleren Unternehmen gemäß Artikel 2 des Anhangs der Empfehlung 2003/361/EG der Kommission^(25)^(11) fallen, sowie für Forschungs- und Bildungseinrichtungen festgelegt werden und sich gleichermaßen auf Beobachtungsdaten und Starts mit Trägerraketen außerhalb der Union erstrecken.

<a id="rec-69"></a>
(69) Zugleich mangelt es den Grundanforderungen an die Cybersicherheit in der ganzen Weltraumwirtschaft insgesamt an Abstimmung und Kohärenz. Während die Resilienz unionseigener Ressourcen im Rahmen der Komponenten des Weltraumprogramms der Union erreicht wurde, gilt für einen Teil der Ressourcen nationaler Weltrauminfrastrukturen möglicherweise ein niedrigeres Schutzniveau. Eine solche Divergenz würde nur weiter zunehmen und zu Asymmetrien führen. Darüber hinaus arbeitet das Weltraumprogramm der Union in einer zunehmend verflochtenen Architektur, die Nutzlasten nationaler kommerzieller Satelliten einbezieht. Daher sollten die Weltrauminfrastrukturen der Mitgliedstaaten in angemessener Weise auf ein höheres Resilienzniveau gebracht werden, damit weder die Sicherheit von unionseigenen Ressourcen noch das Funktionieren des Weltraumprogramms der Union gefährdet wird und letztlich negative Auswirkungen auf die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten sowie kritische Einrichtungen und Sektoren im gesamten Binnenmarkt vermieden werden können.

<a id="rec-70"></a>
(70) Das derzeitige Ungleichgewicht ist nicht nur darauf zurückzuführen, dass Weltraumprogramme parallel (auf Ebene der Union und auf Ebene der Mitgliedstaaten) entwickelt wurden. Es steht auch im Zusammenhang mit dem Fehlen gemeinsamer Grundanforderungen an die Cybersicherheit und das Risikomanagement, die auf die besonderen Erfordernisse der Weltrauminfrastruktur zugeschnitten sind. Während nur einige Mitgliedstaaten einen normativen Ansatz gewählt haben, ist das Niveau oder die Tiefe dieser Anforderungen im Binnenmarkt unterschiedlich. Die Resilienz der Weltrauminfrastruktur hängt in vielen Fällen von den finanziellen Möglichkeiten und letztlich von der Bereitschaft der Unternehmen ab, sich an bewährte Risikomanagementverfahren zu halten und die Cybersicherheit bei der Konzeption und Durchführung von Weltraummissionen zu berücksichtigen.

<a id="rec-71"></a>
(71) Um diese Lücken zu schließen und Ungleichgewichte zu beseitigen, sollten maßgeschneiderte Resilienz-Grundanforderungen für die gesamte Weltraumwirtschaft festgelegt werden. Diese Vorschriften sollten für die gesamte Weltrauminfrastruktur in der gesamten Union gelten und unionseigene Ressourcen sowie nationale staatliche und nichtstaatliche Ressourcen abdecken. Alle Boden-, Weltraum- und Verbindungssegmente der Weltrauminfrastruktur sowie die digitalen und physischen weltraum- und bodengestützten Systeme und Teilsysteme sollten kohärent abgedeckt werden, um alle relevanten Risiken wie Cyber- und elektronische Störungen sowie physische Risiken abzudecken.

<a id="rec-72"></a>
(72) Da diese Verordnung den Grad der Harmonisierung des für die Weltraumwirtschaft geltenden Risikomanagements erhöht, stellt dieses höhere Niveau auch im Vergleich zu den Anforderungen der Richtlinie (EU) 2022/2555 eine stärkere Harmonisierung dar. Folglich sollte diese Verordnung in Bezug auf Artikel 21 der Richtlinie (EU) 2022/2555 eine „lex specialis“ darstellen. Gleichzeitig sollte die Weltraumwirtschaft eine enge Beziehung zu dem in der Richtlinie (EU) 2022/2555 festgelegten horizontalen Rahmen der Union für Cybersicherheit aufrechterhalten, um die vollständige Kohärenz mit den von den Mitgliedstaaten angenommenen Cybersicherheitsvorschriften und -strategien und der durch die genannte Richtlinie geschaffenen institutionellen Struktur sicherzustellen. Die Lücke zwischen den Resilienz-Grundanforderungen, die für unionseigene Ressourcen gelten, und denen, die für Ressourcen der Mitgliedstaaten gelten, sollte somit geschlossen werden. Daher sollten strengere Risikomanagementanforderungen für die Weltraumwirtschaft eingeführt werden, um eine stärkere Harmonisierung im Vergleich zu den derzeitigen Anforderungen zu erreichen, die in der Richtlinie (EU) 2022/2555 festgelegt sind.

<a id="rec-73"></a>
(73) Die Gewährleistung der Cybersicherheit der Weltrauminfrastruktur ist in allen Phasen der Konzeption, der Entwicklung und des Betriebs der Weltrauminfrastruktur von größter Bedeutung. Daher sollten während des gesamten Lebenszyklus von Weltraummissionen unter gebührender Berücksichtigung aller wichtigen Phasen robuste Risikomanagementmaßnahmen angewendet werden. Es sollte ein angemessener Schutz aller Ressourcen, Systeme und Daten erreicht werden, von der Konzeption und Herstellung über den Start und Betrieb bis hin zum Ende der Lebensdauer.

<a id="rec-74"></a>
(74) Im Mittelpunkt des von den Unionsbetreibern im Bereich Weltraum ins Werk gesetzten Risikomanagements sollten Risikobewertungen stehen, die auf Segment-, System- und Komponentenebene auf der Grundlage von Risikoszenarien durchzuführen sind und sich zumindest auf kritische Ressourcen wie technische Systeme, Flugsoftware, Telemetrie-/Telekommandoeinheit, Missionskontrollzentren oder Raumfahrzeug-Kontrollzentren erstrecken. Die Liste der Kategorien kritischer Ressourcen, Operationen und der Phasen während des gesamten Lebenszyklus von Weltraummissionen, für die die Unionsbetreiber im Bereich Weltraum solche Risikoszenarien erarbeiten müssen, sowie die Methoden zur Modellierung von Risikoszenarien und Bedrohungen zur Untermauerung der Risikobewertungen sollte von der Kommission erstellt werden.

<a id="rec-75"></a>
(75) Im Einklang mit dem Grundsatz der Verhältnismäßigkeit sollte in dieser Verordnung die besondere Stellung von Betreibern im Bereich Weltraum anerkannt werden, bei denen es sich um kleine Unternehmen oder Forschungs- oder Bildungseinrichtungen handelt. Diese Kategorien können aufgrund der Größe, der Ressourcen und des Umfangs der Tätigkeiten geringere Auswirkungen haben. In diesem Fall besteht das zwingende Ziel darin, den Schutz kritischer Funktionen und Ressourcen sicherzustellen und wesentlichen Risiken wie dem Risiko des Verlusts der Kontrolle über Ressourcen mit Antrieb und der Fähigkeit zur Aussendung von Störungen zu begegnen.

<a id="rec-76"></a>
(76) Um einen gemeinsamen Ansatz für den Betrieb der gesamten Weltrauminfrastruktur sicherzustellen, sollten grundlegende Vorschriften für die Identifizierung und Verwaltung von Ressourcen sowie für die Verwaltung und Kontrolle von Zugangsrechten festgelegt werden, um den Zugang zum Bodensegment und die Kontrolle über das Weltraumsegment zu schützen. Es sollten Schlüsselelemente zur Wahrung der Resilienz von Ressourcen festgelegt werden, insbesondere im Hinblick auf die Resilienz der Netz- und Informationssysteme, wobei der Notwendigkeit Rechnung zu tragen ist, eine wirksame technische Kontrolle über das Weltraumsegment aufrechtzuerhalten.

<a id="rec-77"></a>
(77) Es sollten grundlegende Mindestgrundsätze für Unionsbetreiber im Bereich Weltraum festgelegt werden, um solide Verschlüsselungsverfahren sicherzustellen, und zwar durch Festlegung eines kryptografischen Konzepts, das spezifischen Cybersicherheitserfordernissen der Weltraummissionen gerecht wird, einer maßgeschneiderten Strategie für die Verwaltung kryptografischer Schlüssel sowie einer Ende-zu-Ende-Authentifizierung von Verbindungen zwischen Satellitenkontrollzentren und dem Weltraumsegment.

<a id="rec-78"></a>
(78) Unionsbetreiber im Bereich Weltraum sollten wesentliche Maßnahmen ergreifen, um rasche und wirksame Maßnahmen zur Fortführung des Geschäftsbetriebs sowie zur Reaktion und Wiederherstellung zu ermöglichen und so eine wirksame Reaktion auf Sicherheitsvorfälle sicherzustellen und die Kontinuität kritischer Operationen im Zuge von Weltraummissionen zu gewährleisten.

<a id="rec-79"></a>
(79) Um ein hohes Maß an Resilienz der Weltrauminfrastruktur zu erreichen, sollten die Unionsbetreiber im Bereich Weltraum – im Einklang mit der derzeitigen Praxis – verpflichtet werden, die Systeme unter Berücksichtigung der durchgeführten Risikobewertungen regelmäßig zu testen. Diese Tests können die Durchführung von bedrohungsorientierten Penetrationstests mit Absicherungen hinsichtlich der Bedingungen für die Durchführung solcher Tests und der von den Prüfern zu erfüllenden Kriterien umfassen.

<a id="rec-80"></a>
(80) Die Komplexität der Lieferkette in der Weltraumwirtschaft kann angesichts der zahlreichen Quellen, die für den Erwerb von Komponenten genutzt werden, spezifische Cybersicherheitsrisiken mit sich bringen. Komponenten werden oft weltweit beschafft und unter Umständen nicht den erforderlichen Integritätsprüfungen unterzogen, insbesondere wenn es sich um Komponenten handelt, die in die verschiedenen Systeme der Weltrauminfrastruktur eingebaut werden. Um solchen Risiken zu begegnen, sollten die Unionsbetreiber im Bereich Weltraum einen Rahmen für das Risikomanagement in der Lieferkette mit speziellen Strategien festlegen, die darauf abzielen, die Risiken in der Lieferkette zu verringern, indem Kontrollen der Integrität und Authentizität von Software eingeführt werden, Kriterien für die Auswahl der Softwareprodukte festgelegt werden und die Cybersicherheit der – z. B. im Zusammenhang mit der Erbringung von Wartung oder Support – vorübergehend miteinander verbundenen Netz- und Informationssysteme gebührend berücksichtigt wird.

<a id="rec-81"></a>
(81) Diese Verordnung sollte integraler Bestandteil des allgemeinen Rahmens der Union für die Resilienz kritischer Einrichtungen sein. Was die unionseigenen Ressourcen angeht, waren die Mitgliedstaaten gemäß der Verordnung (EU) 2021/696 im Zusammenhang mit der Richtlinie 2008/114/EG des Rates^(26)^(12) (an deren Stelle nun die Richtlinie (EU) 2022/2557 getreten ist) verpflichtet, zum Schutz der Bodeninfrastruktur in ihrem Hoheitsgebiet, die Teil des Weltraumprogramms der Union ist, Maßnahmen zu ergreifen, die den im Rahmen der Umsetzung der genannten Richtlinie festgelegten Maßnahmen zumindest gleichwertig sind. Um die vollständige Kohärenz mit den geltenden Unionsvorschriften über die Resilienz kritischer Einrichtungen sicherzustellen und die vollständige Kontinuität der Beziehung zwischen der allgemeinen aktualisierten Resilienzregelung und den harmonisierten Vorschriften im Bereich Weltraum zu wahren, sollte im Zusammenhang mit dieser Verordnung ein ähnlicher Ansatz für die Beziehung zwischen der Richtlinie (EU) 2022/2557 und der vorliegenden Verordnung verfolgt werden. Im Hinblick auf die physische Resilienz des Bodensegments sollten daher alle Unionsbetreiber im Bereich Weltraum die in dieser Verordnung festgelegten Maßnahmen anwenden und sicherstellen, dass sie den gemäß der Richtlinie (EU) 2022/2557 ergriffenen Maßnahmen mindestens gleichwertig sind. Darüber hinaus sollte klargestellt werden, dass die in dieser Verordnung definierten und in ihren Anwendungsbereich fallenden Unionsbetreiber im Bereich Weltraum als kritische Einrichtungen im Sinne der Richtlinie (EU) 2022/2557 eingestuft werden können, wenn sie Betreiber von Bodeninfrastrukturen gemäß Nummer 10 des Anhangs der genannten Richtlinie sind. Diese Richtlinie gilt daher für Betreiber im Bereich Weltraum, die in den Anwendungsbereich dieser Verordnung fallen, sofern sie von den Mitgliedstaaten als kritische Einrichtungen eingestuft werden. Andererseits sollte diese Verordnung für alle Betreiber im Bereich Weltraum gelten, unabhängig davon, ob sie gemäß der genannten Richtlinie als kritische Einrichtungen eingestuft wurden oder nicht. Schließlich sollte klargestellt werden, dass das in dieser Verordnung definierte und in ihren Anwendungsbereich fallende Bodensegment so zu verstehen ist, dass es die in dieser Richtlinie genannte Bodeninfrastruktur umfasst.

<a id="rec-82"></a>
(82) In der Richtlinie (EU) 2022/2557 sind die wesentlichen Mindestharmonisierungsvorschriften festgelegt, mit denen die Resilienz kritischer Einrichtungen und die grenzüberschreitende Zusammenarbeit zwischen den zuständigen Behörden verbessert werden sollen. Die Richtlinie (EU) 2022/2557 sollte die Grundlage für die physische Resilienz kritischer Einrichtungen, die Bodeninfrastrukturen betreiben, bleiben, die in den Anwendungsbereich dieser Richtlinie und unter die vorliegende Verordnung fallen. Für diese Einrichtungen sollte diese Verordnung unbeschadet und ergänzend zur Richtlinie (EU) 2022/2557 gelten. Die Resilienz der kritischen Einrichtungen, die in den Anwendungsbereich der Richtlinie (EU) 2022/2557 fallen, sollte im Einklang mit dieser Richtlinie sichergestellt werden. Die kritische Infrastruktur, die diese Einrichtungen betreiben, kann Kontrollzentren, Antennen, Versuchsanlagen, Standorte, einschließlich Startplätze, physische Ausrüstung und Komponenten, Hardware, Systeme und Teilsysteme, die Teil der Weltrauminfrastruktur sind, technische Systeme, Stromversorgungssysteme und Antriebssysteme umfassen.

<a id="rec-83"></a>
(83) Darüber hinaus gilt gemäß der Richtlinie (EU) 2022/2557, dass eine kritische Einrichtung, die aufgrund von Verpflichtungen aus anderen Rechtsakten, die für ihre Risikobewertung relevant sind, andere Risikobewertungen vorgenommen oder Dokumente erstellt hat, diese Bewertungen und Dokumente verwenden kann, um die in der Richtlinie (EU) 2022/2557 festgelegten Anforderungen zu erfüllen. In der Richtlinie (EU) 2022/2557 ist in diesem Zusammenhang ausdrücklich die Möglichkeit vorgesehen, dass eine zuständige Behörde gemäß dieser Richtlinie bei der Wahrnehmung ihrer Aufsichtsaufgaben und unter bestimmten Bedingungen erklären kann, dass diese Bewertung ganz oder teilweise den einschlägigen Verpflichtungen aus dieser Richtlinie entspricht.

<a id="rec-84"></a>
(84) Angesichts der engen Verknüpfungen zwischen dieser Verordnung und der Richtlinie (EU) 2022/2557 sollten die im Rahmen dieser beiden Rechtsakte eingerichteten zuständigen Behörden daher zusammenarbeiten, um die Synergien ihrer jeweiligen Maßnahmen zu verbessern, und zwar insbesondere dann, wenn Risikobewertungen, die von in den Anwendungsbereich der genannten Richtlinie fallenden Unionsbetreibern im Bereich Weltraum gemäß dieser Verordnung durchgeführt werden, zum Nachweis der Einhaltung bestimmter Anforderungen der genannten Richtlinie herangezogen werden.

<a id="rec-85"></a>
(85) In Bezug auf die physische Resilienz des Weltraumsegments wird in dieser Verordnung anerkannt, dass ISOS dazu beitragen würden, das Resilienzniveau und die Lebensdauer von Ressourcen im Weltraum zu verbessern.

<a id="rec-86"></a>
(86) Zusätzlich zur Festlegung der wesentlichen Vorschriften über die Bewältigung und Untersuchung von Sicherheitsvorfällen sollte ein Mechanismus für die Meldung von Sicherheitsvorfällen durch Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen im Rahmen des Weltraumprogramms der Union eingerichtet werden, mit dem bestehende Lücken bei der Meldung von Sicherheitsvorfällen geschlossen werden. Die Agentur sollte Zugang zu Informationen über erhebliche Sicherheitsvorfälle für alle Komponenten des Weltraumprogramms der Union erhalten, und zwar über die im Rahmen des Weltraumprogramms der Union eingerichtete Struktur für die Sicherheitsüberwachung, die Unterstützung leistet und rund um die Uhr die Sicherheit der relevanten Systeme überwacht. Um Kohärenz mit dem allgemeinen Rahmen für die Cybersicherheit zu erreichen, sollte dieser Mechanismus an die in der Richtlinie (EU) 2022/2555 festgelegte Meldung von Sicherheitsvorfällen angepasst werden.

<a id="rec-87"></a>
(87) Darüber hinaus sollte diese Verordnung in Bezug auf die Meldung erheblicher Sicherheitsvorfälle, die die Weltrauminfrastruktur von Mitgliedstaaten beeinträchtigen, die derzeit in der Richtlinie (EU) 2022/2555 oder der Richtlinie (EU) 2022/2557 festgelegten Anforderungen an die Meldung von Sicherheitsvorfällen unberührt lassen. Folglich sollten die Meldevorschriften dieser beiden Richtlinien weiterhin uneingeschränkt für Unionsbetreiber im Bereich Weltraum gelten, bei denen es sich um wesentliche oder wichtige Einrichtungen bzw. kritische Einrichtungen im Sinne dieser Richtlinien handelt.

<a id="rec-88"></a>
(88) Die durch die Richtlinien (EU) 2022/2555 und (EU) 2022/2557 eingerichteten Aufsichtsbehörden können sich von den gemäß dieser Verordnung benannten oder eingerichteten zuständigen Behörden unterscheiden. Um das Verständnis und das Bewusstsein dieser zuständigen Behörden im Hinblick auf das Ausmaß und die Auswirkungen der erheblichen Sicherheitsvorfälle, die sich auf die Weltrauminfrastruktur auswirken, zu verbessern, sollten die Unionsbetreiber im Bereich Weltraum erhebliche Sicherheitsvorfälle, die nationale Ressourcen der Weltrauminfrastruktur beeinträchtigen, den im Rahmen dieser Verordnung zuständigen Behörden melden, die ihrerseits entsprechende zusammenfassende Informationen an die Agentur weiterleiten sollten.

<a id="rec-89"></a>
(89) Es sollte eine Koordinierung und ein regelmäßiger Austausch zwischen der Agentur und den zuständigen nationalen Behörden eingerichtet werden, um die Meldung von Sicherheitsvorfällen in der Weltraumwirtschaft zu straffen und unionsweit einheitliche Ansätze in Bezug auf die Bewältigung von erheblichen Sicherheitsvorfällen mit Auswirkungen auf die Weltrauminfrastruktur zu erreichen. Das Unionsnetz für Resilienz im Weltraum (EUSRN) sollte eine wichtige Rolle dabei spielen, diese Kohärenz herzustellen und die Koordinierung mit den einschlägigen Strukturen sicherzustellen, die durch die in den Richtlinien (EU) 2022/2555 und (EU) 2022/2557 festgelegten allgemeinen Rahmen für Cybersicherheit und Resilienz geschaffen wurden, insbesondere mit dem Netzwerk von Computer-Notfallteams und dem im Rahmen der Richtlinie (EU) 2022/2555 eingerichteten Europäischen Netzwerk der Verbindungsorganisationen für Cyberkrisen (EU-CyCLONe). Hierzu könnten beispielsweise aktuelle Lageberichte oder Informationen dazu bereitgestellt werden, in welchen Fällen erhebliche Sicherheitsvorfälle bei Weltrauminfrastrukturen Auswirkungen auf Sektoren und Dienste haben können, die in den Anwendungsbereich dieser Richtlinien fallen. Insbesondere würde die Arbeit des EUSRN auch dazu beitragen, Lösungsvorschläge zur Straffung der Meldung von Cybervorfällen in der gesamten Weltraumwirtschaft zu steuern, um sie an den Vereinfachungsansatz im Rahmen NIS-2-Richtlinie anzupassen und so den Weg für eine vollständige Konvergenz der Weltraumwirtschaft und des Cyberbereichs zum Nutzen der gesamten Weltraumcommunity zu ebnen.

<a id="rec-90"></a>
(90) Die Wahrung der Resilienz der Weltrauminfrastruktur und der Weltraumtätigkeiten ist ein Kernelement des Binnenmarkts für weltraumgestützte Daten und Dienste. Gleichzeitig sollten die in dieser Verordnung festgelegten Resilienzmaßnahmen angesichts der Bedeutung des Bereichs Weltraum für eine Vielzahl von Anwendungen (Zivil-, Sicherheits- und Verteidigungsbereich) auch andere Initiativen unterstützen können, z. B. im Zusammenhang mit der Überwachung von Bedrohungen im Weltraum bei der Entwicklung der Architektur der EU für die Reaktion auf Bedrohungen im Weltraum. Eine bessere Kenntnis der Agentur der von allen Betreibern im Bereich Weltraum gemeldeten Sicherheitsvorfälle und die Koordinierung mit den einschlägigen Cyberbehörden würde es dem Unionsnetz für Resilienz im Weltraum ermöglichen, zur Ermittlung und Meldung von Ereignissen im Zusammenhang mit Weltraumsystemen, die eine Bedrohung für die Union und die Mitgliedstaaten darstellen, beizutragen und gemäß dem Beschluss (GASP) 2021/698 des Rates über die Sicherheitssysteme und -dienste, die im Rahmen des Europäischen Weltraumprogramms eingeführt, betrieben und genutzt werden und die Sicherheit der Europäischen Union berühren können, tätig zu werden und sich abzustimmen.

<a id="rec-91"></a>
(91) Ein freiwilliger Informationsaustausch über Cyberbedrohungen und Cyberangriffe, elektronische Störungen wie Jamming oder Spoofing, Kompromittierungsindikatoren, gegnerische Taktiken, Techniken und Verfahren, Schwachstellen, bedrohungsspezifische Informationen sowie der Austausch bewährter Cybersicherheitsverfahren und -empfehlungen würden das allgemeine Resilienzniveau der Weltrauminfrastruktur erhöhen. Daher ist es wichtig, die Bedingungen für einen solchen Informationsaustausch festzulegen, der dazu beiträgt, die Fähigkeit der Betreiber im Bereich Weltraum zu verbessern, Sicherheitsvorfälle zu verhindern bzw. deren Auswirkungen einzudämmen.

<a id="rec-92"></a>
(92) Unionsbetreiber im Bereich Weltraum sollten diese Informationen im Rahmen von Vereinbarungen über den Informationsaustausch austauschen, die den potenziell sensiblen Charakter der ausgetauschten Informationen gebührend schützen und Verhaltensregeln unterliegen, und zwar unter uneingeschränkter Achtung des Geschäftsgeheimnisses, der Vorschriften über den Schutz personenbezogener Daten im Einklang mit der Verordnung (EU) 2016/679 des Europäischen Parlaments und des Rates^(27)^(13) und der Wettbewerbspolitik. Die Kommission sollte sich aktiv darum bemühen, solche Vereinbarungen zu erleichtern, indem sie die Einrichtung eines Informationsaustausch- und -analysezentrums der EU im Bereich Weltraum unterstützt und fördert, das auch auf den Erfahrungen anderer Sektoren aufbaut.

<a id="rec-93"></a>
(93) Es sollten harmonisierte Vorschriften zur ökologischen Nachhaltigkeit festgelegt werden, um das Potenzial des Binnenmarkts auszuschöpfen und die ökologische Nachhaltigkeit in der Weltraumwirtschaft zu fördern, eine Marktfragmentierung zu verhindern und den Übergang zu einer gerechten, klimaneutralen, ressourceneffizienten Kreislaufwirtschaft voranzubringen.

<a id="rec-94"></a>
(94) Der Übergang zu kreislaufwirtschaftlichen und nachhaltigen Verfahren im Weltraum sollte der langfristigen nachhaltigen Nutzung von Ressourcen bei Weltraumtätigkeiten förderlich sein. Indem die Weltraumindustrie nun beginnt, die Grundsätze der Kreislaufwirtschaft zu übernehmen, sollte sie nachhaltigere Verfahren anwenden, die sich als wirksam erwiesen haben, und gleichzeitig Innovationen hin zu neuen Produkten mit geringeren Umweltauswirkungen vorantreiben. In dieser Hinsicht sollten ISOS auch eine wesentliche Rolle bei der Erleichterung dieses Übergangs zu Nachhaltigkeit und Kreislaufwirtschaft im Bereich Weltraum spielen.

<a id="rec-95"></a>
(95) Da diese Verordnung Teil der umfassenden Bemühungen der Union zur Schaffung eines soliden politischen Rahmens für ökologisch nachhaltige Produkte, Dienste und Geschäftsmodelle ist, sollte sie die in der Ökodesign-Verordnung für nachhaltige Produkte und im Rahmen des Aktionsplans für die Kreislaufwirtschaft festgelegten Maßnahmen ergänzen. Die Studien zum Umweltfußabdruck im Zusammenhang mit dieser Verordnung sollten in diesem Sinne die Entwicklung verbesserter Ökodesign-Verfahren unterstützen sowie zur Kartierung der Energie- und Materialströme in der Weltraumwirtschaft der Union, auch in Bezug auf strategische und/oder kritische Rohstoffe, beitragen und eine höhere Resilienz der Lieferkette ermöglichen.

<a id="rec-96"></a>
(96) Betreiber im Bereich Weltraum sollten daher verpflichtet werden, den Umweltfußabdruck ihrer Weltraumtätigkeiten während des gesamten Lebenszyklus von Weltraummissionen zu berechnen. Ein Zertifikat sollte von einer qualifizierten technischen Stelle für Weltraumtätigkeiten ausgestellt werden, die zum Zweck der Bescheinigung die Überprüfung und Validierung der Berechnung des Umweltfußabdrucks von Weltraumtätigkeiten durchführt.

<a id="rec-97"></a>
(97) Um die Umweltauswirkungen von Weltraumtätigkeiten zu begrenzen und ihre Nachhaltigkeit zu fördern, sollte die Kommission eine detaillierte Methode für die Berechnung des Umweltfußabdrucks von Weltraumtätigkeiten auf der Grundlage wissenschaftlich fundierter Bewertungsmethoden oder internationaler Normen, wie sie in der Empfehlung der Kommission zur Anwendung der Methoden zur Berechnung des Umweltfußabdrucks dargelegt sind, entwickeln, um den Vergleich zwischen Weltraumsystemen zu erleichtern.

<a id="rec-98"></a>
(98) Indessen kann die Richtigkeit der Umweltaussagen ohne zuverlässige, vergleichbare und überprüfbare Informationen nicht nachgewiesen werden. Die Daten sollten hohen Genauigkeitsstandards genügen. Standardisierte Daten über die Umweltauswirkungen von Weltraumtätigkeiten sollten in eine zentrale Datenbank auf Unionsebene eingespeist werden, in der den Umweltfußabdruck betreffende Daten gespeichert werden sollten, um so die Transparenz zu erleichtern und die Zusammenarbeit und den Datenaustausch im Zusammenhang mit der Lebenszyklusanalyse (LCA) für Weltraumtätigkeiten zu fördern. Das Eigentum der Union an den abgeleiteten Datensätzen sollte das Eigentum von Unionsbetreibern im Bereich Weltraum, Drittlandsbetreibern im Bereich Weltraum und internationalen Organisationen an Daten unberührt lassen, die in den aggregierten und aufgeschlüsselten Datensätzen enthalten sind, die an die den Umweltfußabdruck betreffende Datenbank der Kommission übermittelt werden. Weder abgeleitete noch aggregierte Datensätze, die von der Kommission veröffentlicht werden, dürfen es ermöglichen, die Daten zur Ermittlung der Herkunft der Daten umzuarbeiten oder zu dekompilieren.

<a id="rec-99"></a>
(99) Alle Operationen und Dienste im Weltraum sollten auf sichere, verantwortungsvolle und friedliche Weise unter Achtung der Rechte anderer Mitgliedstaaten und Drittländer auf Erforschung und Nutzung des Weltraums durchgeführt werden. Der neue Bereich der Operationen und Dienste im Weltraum mit seinen entsprechenden Anwendungen und Fähigkeiten sollte der künftigen Entwicklung des Raumfahrt-Ökosystems der Union förderlich sein und zur Schaffung neuer Märkte (Weltraumwirtschaft), zur Förderung der Nachhaltigkeit und zur Erhöhung der Resilienz, Anpassungsfähigkeit und Skalierbarkeit der Weltrauminfrastruktur sowie zur Minderung der Risiken im Zusammenhang mit Weltraummüll beitragen.

<a id="rec-100"></a>
(100) Da die mit Operationen und Diensten im Weltraum verbundene Technologie naturgemäß einen doppelten Verwendungszweck hat, sollte ein transparenter Rahmen, der auf zentralen Grundsätzen beruht, das Risiko des Missbrauchs von Fähigkeiten und Technologien im Zusammenhang mit der Bereitstellung von Operationen und Diensten im Weltraum verringern. In Anbetracht der Tatsache, dass in der Union bereits erste Operationen und Dienste im Weltraum verfügbar sind, z. B. für Inspektion und Transport, ist es notwendig, parallel die Erforschung und Entwicklung der mit Operationen und Diensten im Weltraum verbundenen Technologien zu fördern und spezielle Technologien und Dienste im Weltraum zu demonstrieren.

<a id="rec-101"></a>
(101) Weltraummissionen im Zusammenhang mit Operationen und Diensten im Weltraum könnten komplex sein und daher eine detaillierte Vorbereitung erfordern. Ein Versorgungsraumfahrzeug führt Rendezvous- und Annäherungsoperationen mit dem festgelegten Maß an Autonomie sowie typische Vorgänge wie z. B. Andock-, Roboter- und Betankungsvorgänge durch. Das Risiko einer Kollision zwischen einem Versorgungsraumfahrzeug und einem Kundenraumfahrzeug oder dem Weltraummüllobjekt sollte durch geeignete Maßnahmen wie die Vorrüstung des künftigen Raumfahrzeugs für den Erhalt von Diensten im Weltraum verhindert bzw. gemindert werden.

<a id="rec-102"></a>
(102) Was die Kollisionsvermeidung und Regeln für den Orbitalverkehr angeht, sollten die Raumfahrzeugbetreiber und Anbieter von Weltraumdiensten zur Kollisionsvermeidung der Union zusammenarbeiten, um effiziente Weltraumdienste zur Kollisionsvermeidung sicherzustellen, insbesondere im Fall einer HIE-Warnmeldung.

<a id="rec-103"></a>
(103) Da die zuständigen Behörden den Unionsbetreibern im Bereich Weltraum die Genehmigungen für alle Phasen einer Weltraummission erteilen, ist der Zugang zu Daten für jedes einzelne genehmigte Raumfahrzeug bis zum Ende der Lebensdauer erforderlich. Um die bestehenden Fähigkeiten voll auszuschöpfen, sollten sich die zuständigen Behörden auf die Fähigkeiten der SST-Partnerschaft der EU stützen, um die Überwachung während der Phasen in der Umlaufbahn und am Ende der Lebensdauer durchzuführen.

<a id="rec-104"></a>
(104) Jede effiziente Reaktion auf eine HIE-Warnmeldung zwischen zwei verschiedenen Raumfahrzeugen erfordert den Dialog zwischen den beteiligten Raumfahrzeugbetreibern. Um sicherzustellen, dass dieser Dialog zügig aufgenommen werden kann, sollte der Anbieter von Weltraumdiensten zur Kollisionsvermeidung als Vermittler fungieren, indem er die verschiedenen Ansprechstellen für die Raumfahrzeugbetreiber aus der Union unterhält.

<a id="rec-105"></a>
(105) Aufgrund der steigenden Zahl von HIE-Warnmeldungen sollten die Raumfahrzeugbetreiber aus der Union in der Lage sein, häufiger auf solche Warnmeldungen zu reagieren. Nach Erhalt einer HIE-Warnmeldung würde der Anbieter von Weltraumdiensten zur Kollisionsvermeidung dem Raumfahrzeugbetreiber aus der Union eine Liste von Maßnahmen vorschlagen. Um die Reaktionszeit der Anbieter von Kollisionsvermeidungsdiensten zu verkürzen, sollte ein standardisiertes Verfahren für die Verkehrsregeln festgelegt werden.

<a id="rec-106"></a>
(106) Den Mitgliedstaaten kommt bei der Durchsetzung dieser Verordnung eine Schlüsselrolle zu. Um den inhärenten Unterschieden zwischen den institutionellen Strukturen auf nationaler Ebene Rechnung zu tragen und bestehende Regelungen zu bewahren, sollten die Mitgliedstaaten eine oder mehrere zuständige Behörden benennen oder einrichten, die auf nationaler Ebene für die Kontrolle der Anwendung dieser Verordnung zuständig sind. Gibt es in Mitgliedstaaten mehr als eine zuständige Behörde, so sollte nur eine dieser Behörden für die Zwecke dieser Verordnung als zentrale Ansprechstelle für diesen Mitgliedstaat dienen, um die Kommunikation mit der Kommission zu erleichtern.

<a id="rec-107"></a>
(107) Die Konvergenz der Befugnisse der zuständigen Behörden muss verbessert werden, um die wirksame Durchsetzung dieser Verordnung im gesamten Binnenmarkt zu ermöglichen. Gemeinsame Mindestbefugnisse in Verbindung mit einer angemessenen Mittelausstattung sollte eine wirksame Aufsicht gewährleisten. Den zuständigen Behörden sollte daher im Einklang mit dem nationalen Recht ein Mindestmaß an Aufsichts- und Untersuchungsbefugnissen übertragen werden. Die zuständigen Behörden sollten bei der Ausübung ihrer Befugnisse gemäß dieser Verordnung objektiv und unparteiisch vorgehen und bei ihrer Beschlussfassung unabhängig bleiben. Die Mitglieder der zuständigen Behörden sollten sich jeder Handlung enthalten, die mit ihren Aufgaben unvereinbar wäre, und sie sollten Vertraulichkeitsvorschriften unterliegen.

<a id="rec-108"></a>
(108) Die Mitgliedstaaten sollten alle erforderlichen Maßnahmen ergreifen, um sicherzustellen, dass die Bestimmungen dieser Verordnung umgesetzt werden, und dazu u. a. wirksame, verhältnismäßige und abschreckende Sanktionen für Verstöße gegen die Vorschriften festlegen. Bei der Bemessung der Höhe der Geldbußen sollten die Mitgliedstaaten in jedem Einzelfall alle relevanten Umstände der konkreten Situation berücksichtigen und dabei insbesondere Art, Schwere und Dauer des Verstoßes, die Dauer des verursachten Schadens sowie etwaige frühere Verstöße gebührend berücksichtigen.

<a id="rec-109"></a>
(109) Die zuständigen Behörden sollten zusammenarbeiten und bewährte Verfahren für die Anwendung dieser Verordnung austauschen, unter anderem durch Amtshilfe und gemeinsame Untersuchungen, die unter uneingeschränkter Achtung der nationalen Verfahren durchgeführt werden.

<a id="rec-110"></a>
(110) Die technische Bewertung der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten erfordert Spezialkenntnisse in diesen Bereichen. Die zuständigen Behörden sollten sich in den meisten Fällen auf die technischen Kenntnisse und das Fachwissen von technischen Stellen stützen, die in der Lage sind, Bewertungen und Überprüfungen durchzuführen, um sich zu vergewissern, dass die Anforderungen dieser Verordnung erfüllt sind, sodass die Genehmigungen für die Durchführung von Weltraumtätigkeiten anschließend von den zuständigen Behörden erteilt werden können.

<a id="rec-111"></a>
(111) Angesichts der Notwendigkeit, flexible Regelungen beizubehalten, sollte es den Mitgliedstaaten freistehen, sich bei der Durchführung dieser technischen Bewertungen auf die Unterstützung der Agentur oder internationaler Organisationen mit technischem Fachwissen zu stützen.

<a id="rec-112"></a>
(112) Mitgliedstaaten, die beabsichtigen, qualifizierte technischen Stellen für Weltraumtätigkeiten einzurichten und zu nutzen, sollten bei der Benennung einer notifizierenden Behörde für die Bewertung und Überwachung qualifizierter technischer Stellen für Weltraumtätigkeiten das Akkreditierungssystem gemäß der Verordnung (EG) Nr. 765/2008 des Europäischen Parlaments und des Rates^(28)^(14) nutzen.

<a id="rec-113"></a>
(113) Um bei der Durchführung der technischen Bewertung in Angelegenheiten, die unter diese Verordnung fallen, ein einheitliches Maß an Qualität, Fachwissen und Integrität zu gewährleisten, müssen Anforderungen in Bezug auf die Kompetenz, die Unabhängigkeit und das Nichtvorliegen von Interessenkonflikten dieser Stellen festgelegt werden. Die notifizierenden Behörden der Mitgliedstaaten sollten sich auf das von der Kommission im Zusammenhang mit notifizierten Stellen für andere Bereiche des Binnenmarkts entwickelte und verwaltete elektronische Notifizierungsinstrument (NANDO-Informationssystem) stützen.

<a id="rec-114"></a>
(114) Die im Rahmen dieser Verordnung eingerichteten zuständigen Behörden tragen den technischen Bewertungen und Stellungnahmen der zuständigen nationalen Behörden, der zentralen Ansprechstelle oder der gemäß im Rahmen der Richtlinie (EU) 2022/2555 eingerichteten Computer-Notfallteams gebührend Rechnung, um die aufsichtliche Konvergenz sicherzustellen und eine Kultur zu schaffen, in der die Aufsichtsbefugnisse der Behörden gemäß der Richtlinie (EU) 2022/2555 beachtet werden.

<a id="rec-115"></a>
(115) Angepasste Governance-Strukturen der Agentur sind für eine wirksame Wahrnehmung der mit dieser Verordnung übertragenen Aufgaben von wesentlicher Bedeutung. Es sollte ein Konformitätsgremium eingerichtet und mit der Durchführung aller erforderlichen technischen Bewertungen betraut werden, die es der Kommission ermöglichen würden, über die Genehmigung und Beaufsichtigung von Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, sowie über die Registrierung und laufende Beaufsichtigung von Drittlandsbetreibern, die weltraumgestützte Daten und Weltraumdienste in der Union bereitstellen, zu entscheiden.

<a id="rec-116"></a>
(116) Um eine solide und unabhängige Arbeitsweise der Agentur sicherzustellen, sollten die Mitglieder des Konformitätsgremiums unabhängig und im Interesse der Union handeln. Sie sollten keine Weisungen von einer Regierung eines Mitgliedstaats, von Organen, Einrichtungen oder sonstigen Stellen der Union oder von öffentlichen oder privaten Einrichtungen anfordern, befolgen oder entgegennehmen. Darüber hinaus sollten in der Geschäftsordnung praktische Vorkehrungen für die Vorbeugung von und den Umgang mit Interessenkonflikten festgelegt werden.

<a id="rec-117"></a>
(117) Wenn Fragen im Zusammenhang mit Aufgaben oder Aspekten von Interesse für Agenturen oder Einrichtungen der Union oder in direktem Zusammenhang mit Drittländern oder internationalen Organisationen in Bezug auf die Ressourcen von Weltrauminfrastruktur solcher Drittländer oder internationaler Organisationen erörtert werden müssen oder wenn das Konformitätsgremium Klarstellungen oder Informationen von einer zuständigen Aufsichtsbehörde eines Drittlands zu Aspekten benötigt, in deren Zusammenhang das Konformitätsgremium die Einhaltung dieser Verordnung durch in Drittländern niedergelassene Anbieter von Weltraumdiensten überprüfen muss, sollte die Teilnahme als Beobachter möglich sein, vorbehaltlich weiterer Regelungen, in denen die Bedingungen für die Teilnahme der Vertreter dieser Drittländer oder internationalen Organisationen im Wege des Abschlusses einschlägiger Übereinkünfte festgelegt werden.

<a id="rec-118"></a>
(118) Um die spezifischen Kompetenzen, technischen Fähigkeiten und Fachkenntnisse der zuständigen nationalen Behörden und der qualifizierten technischen Stellen für Weltraumtätigkeiten zu nutzen, sollte sich das Konformitätsgremium auf nationale aufsichtliche und technische Fähigkeiten stützen, indem er spezielle Unterausschüsse für Fragen der Sicherheit, Resilienz und ökologischen Nachhaltigkeit einsetzt und spezielle multidisziplinäre gemeinsame Teams für die Durchführung der technischen Kontrollen zusammenstellt.

<a id="rec-119"></a>
(119) Für die Zwecke der Aufdeckung von Verstößen gegen diese Verordnung in Bezug auf die unionseigenen Ressourcen und die in Drittländern niedergelassenen Anbieter von Weltraumdiensten ist es erforderlich, dass die Kommission und die Agentur über wirksame Befugnisse, Instrumente und Ressourcen verfügen, die die volle Wirksamkeit der Aufsicht gewährleisten. Daher sollten die Kommission und die Agentur befugt sein, Informationen anzufordern sowie Untersuchungen und Vor-Ort-Inspektionen durchzuführen. Die Kommission sollte Aufsichtsbefugnisse erhalten und von den Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, und von den Anbietern von Weltraumdiensten mit Sitz in Drittländern verlangen, Verstöße abzustellen, sowie Geldbußen und Zwangsgelder verhängen.

<a id="rec-120"></a>
(120) Im Zusammenhang mit den Untersuchungs- und Inspektionsbefugnissen kann der Zugang zu den Räumlichkeiten der Unionsbetreiber im Bereich Weltraum, die unionseigene Ressourcen betreiben, und in Drittländern niedergelassenen Anbieter von Weltraumdiensten erforderlich sein, wenn Anbieter von Weltraumdiensten, an die ein Auskunftsersuchen gerichtet wurde, diesem nicht nachkommen oder wenn die Gefahr besteht, dass Dokumente, auf die sich das Auskunftsersuchen bezieht, entfernt, manipuliert oder vernichtet werden. Dieser Zugang sollte auf der Grundlage der Zustimmung der Einrichtung des Drittlands und der zuständigen Drittlandsbehörde erfolgen.

<a id="rec-121"></a>
(121) Die Achtung der Verteidigungsrechte von in einem Drittland niedergelassenen Anbietern von Weltraumdiensten sollte während des gesamten Prozesses der Registrierung und Überwachung der laufenden Einhaltung durch die Agentur sichergestellt werden, indem insbesondere das Recht, begründete Erklärungen für die Zwecke der vorläufigen Bewertungen im Zusammenhang mit der Registrierung einzureichen, und das Recht, gegen die Entscheidungen der Agentur vor ihrer neu eingerichteten Widerspruchskammer Widerspruch einzulegen, eingeräumt werden.

<a id="rec-122"></a>
(122) Alle Befugnisse der Agentur und der Kommission sollten in vollem Einklang mit den Grundrechten und unter Achtung der Grundsätze ausgeübt werden, die im Vertrag über die Arbeitsweise der Europäischen Union (AEUV) und in der Charta der Grundrechte der Europäischen Union anerkannt wurden, insbesondere in Übereinstimmung mit dem Recht auf Achtung des Privat- und Familienlebens und den Schutz personenbezogener Daten sowie dem Recht auf Informations- und Meinungsfreiheit, unternehmerische Freiheit, Eigentum und Verbraucherschutz, wirksamen Rechtsbehelf und Verteidigung. Diese Verordnung sollte folglich in Einklang mit diesen Rechten und Grundsätzen ausgelegt und angewandt werden.

<a id="rec-123"></a>
(123) Darüber hinaus sollte eine Reihe von Verfahrensregeln für die Ausübung von Untersuchungsbefugnissen vorgesehen werden. Wenn die Agentur oder die Kommission feststellt, dass es ernsthafte Anhaltspunkte für das Vorliegen von Tatsachen gibt, die einen oder mehrere Verstöße gegen diese Verordnung darstellen könnten, sollte sie Untersuchungen unter uneingeschränkter Achtung der Verteidigungsrechte des betreffenden Unionsbetreibers im Bereich Weltraum oder des Drittlandsanbieters von Weltraumdiensten durchführen. Im Zusammenhang mit dem Erlass einstweiliger Maßnahmen können die Agentur und die Kommission in Fällen, in denen dringende Maßnahmen zur Abwendung eines drohenden und erheblichen Schadens erforderlich sind, kürzere Fristen für die Stellungnahme des betreffenden Betreibers im Bereich Weltraum setzen und ihm nur Gelegenheit zur schriftlichen Stellungnahme geben.

<a id="rec-124"></a>
(124) Zum wirksamen Schutz der Verteidigungsrechte gegenüber allen Entscheidungen der Agentur sollte die Agentur aus Gründen der Verfahrensökonomie und zur Verringerung der Belastung des Gerichtshofs der Europäischen Union natürlichen und juristischen Personen die Möglichkeit geben, gegen an sie gerichtete oder sie unmittelbar und individuell betreffende Entscheidungen, die im Rahmen der der Agentur durch diese Verordnung übertragenen Befugnisse getroffen wurden, Widerspruch einzulegen.

<a id="rec-125"></a>
(125) Daher sollte eine Widerspruchskammer eingerichtet werden, um sicherzustellen, dass die von den Entscheidungen der Agentur betroffenen Parteien die erforderlichen Rechtsbehelfe in Anspruch nehmen können. Die Widerspruchskammer muss unabhängig von jeglicher Regulierungs- und Verwaltungsstruktur der Agentur agieren können und darf nicht an Weisungen jeglicher Art gebunden sein. Die Beschlüsse der Widerspruchskammer sollten vor dem Gerichtshof der Europäischen Union anfechtbar sein.

<a id="rec-126"></a>
(126) Diese Verordnung sollte sich auf den derzeitigen europäischen Normungsrechtsrahmen stützen, der auf den Grundsätzen des neuen Konzepts beruht, die in der Entschließung des Rates vom 7. Mai 1985 über eine neue Konzeption auf dem Gebiet der technischen Harmonisierung und der Normung sowie in der Verordnung (EU) Nr. 1025/2012 des Europäischen Parlaments und des Rates^(29)^(15) dargelegt sind. Da diese Verordnung der erste Regulierungsansatz auf Unionsebene in diesem Bereich ist, sollte auch bezüglich der Normung ein ausgewogener und schrittweiser Ansatz verfolgt werden. Die technischen Anforderungen, die für die Einführung des elektronischen Zertifikats durch die Agentur sowie für einen dunklen und ruhigen Himmel erforderlich sind, sollten im Rahmen des Normungsprozesses entwickelt werden. Die Kommission sollte daher die europäischen Normungsorganisationen damit beauftragen, Normen für diese grundlegende Anforderung zu entwickeln. Der Kommission sollte die Befugnis übertragen werden, Durchführungsrechtsakte zur Festlegung gemeinsamer Spezifikationen für diese grundlegenden Anforderungen unter begrenzten Umständen zu erlassen, wobei die Rolle und die Funktionen der Normungsorganisationen zu berücksichtigen sind.

<a id="rec-127"></a>
(127) Im Hinblick auf die Schaffung eines gemeinsamen Ansatzes für Unionsbetreiber im Bereich Weltraum, die bereit sind, in Bezug auf Sicherheit, Resilienz oder ökologische Nachhaltigkeit von Weltraumtätigkeiten über die in dieser Verordnung vorgeschriebene Grundlage hinauszugehen, sollte ein Rahmen für das Weltraumsiegel der Union geschaffen werden.

<a id="rec-128"></a>
(128) Die Weltraumsiegelsysteme der Union sollten die derzeitigen Lücken schließen, die sich aus der Koexistenz verschiedener Standards oder nicht entwickelter Verfahren ergeben, und so zur Entwicklung eines gemeinsamen Ansatzes beitragen. Unter Beteiligung der Mitgliedstaaten, der Weltraumsiegelgruppe der Union (Union Space Label Group, EUSLG) und der Interessenträgergruppe für das Weltraumsiegel (Stakeholder Space Label Group, SSLG) sollte unter Federführung der Kommission und mit Unterstützung der Agentur ein Weltraumsiegelsystem der Union entwickelt werden. Die EUSLG sollte sich aus Vertretern der zuständigen Behörden im Weltraumsektor und anderer zuständiger nationaler Behörden zusammensetzen, während die SSLG aus Vertretern von Industrieorganisationen und Hochschulen bestehen sollte.

<a id="rec-129"></a>
(129) Im Anschluss an ein solches Ersuchen sollte die Agentur unverzüglich mögliche Systeme für den festgelegten Anwendungsbereich und Gegenstand vorbereiten. Die Agentur sollte mittels öffentlicher Konsultationen alle wahrscheinlichen Auswirkungen des Ersuchens der Kommission auf den Markt bewerten, insbesondere etwaige Auswirkungen auf KMU und kleine Midcap-Unternehmen, auf Innovation, Marktzutrittsschranken oder verbundene Kosten.

<a id="rec-130"></a>
(130) Es sollte eine Beraterreserve ausgewählt werden, um die technischen Anforderungen für jedes einzelne Siegelsystem zu bewerten. Die Beraterreserve sollte sich aus Vertretern der Wissenschaft und des durch diese Verordnung benannten Anbieters von Weltraumdiensten zur Kollisionsvermeidung der Union zusammensetzen, um sicherzustellen, dass es keine Interessenkonflikte zwischen den Beratern, dem Inhalt des Siegelsystems und den Antragstellern gibt.

<a id="rec-131"></a>
(131) Um die Umsetzung der in dieser Verordnung festgelegten Anforderungen zu erleichtern und zu begleiten, sollte eine Reihe von Unterstützungsmaßnahmen und flankierenden Maßnahmen bis zu ihrer Durchführung und für die gesamte Dauer ihrer Durchführung eingeführt werden. Diese Maßnahmen würden in der Bereitstellung von Leitlinien und Unterstützung für Betreiber im Bereich Weltraum bei der Vorbereitung technischer Dossiers für die Genehmigung oder Registrierung in unter diese Verordnung fallenden Angelegenheiten sowie in einer Reihe von Maßnahmen zum Kapazitätsaufbau und zur Finanzausstattung bestehen.

<a id="rec-132"></a>
(132) Die Kommission sollte die Kriterien und Methodik entwickeln, um die zuständigen Behörden bei der Bewertung der Sicherheitsrisiken zu unterstützen und so die Vergleichbarkeit von Aufsichtsüberprüfungen zu erleichtern, und präzisieren, was eine schwerwiegende Betriebsstörung der durchgeführten Weltraumtätigkeiten oder der von einem Betreiber im Bereich Weltraum erbrachten Dienste darstellt. Die Verwendung kryptografischer Produkte sollte von der Kommission im Wege delegierter Rechtsakte weiter spezifiziert werden, die für kryptografische Produkte zu entwickeln sind, die im Rahmen künftiger Systeme der Union für die Zertifizierung der Cybersicherheit auf der Grundlage der Verordnung (EU) 2019/881 des Europäischen Parlaments und des Rates^(30)^(16) zertifiziert werden sollen, um den Schutz von Telemetrie und Telekommandos zu gewährleisten.

<a id="rec-133"></a>
(133) Im Bereich der ökologischen Nachhaltigkeit sollte die Kommission im Wege von Durchführungsrechtsakten weitere Vorschriften festlegen, einschließlich einer spezifischen Methode für die Berechnung und Überprüfung des Umweltfußabdrucks von Weltraumtätigkeiten.

<a id="rec-134"></a>
(134) Um sicherzustellen, dass der Regelungsrahmen den Entwicklungen des technischen Fortschritts oder neuen Verpflichtungen der Union im Rahmen internationaler Übereinkommen gebührend Rechnung trägt und daher erforderlichenfalls angepasst werden kann, sollte der Kommission die Befugnis übertragen werden, gemäß Artikel 290 AEUV Rechtsakte zu erlassen, um die Rangfolge für die Entfernung von Raumfahrzeugen in der LEO zu ändern, den technischen Fortschritt in Bezug auf Operationen und Dienste im Weltraum anzuerkennen sowie die Anforderungen und enthaltenen Elemente folgender Aspekte zu ergänzen: die Sicherheitsrisikobewertungen, die Anforderungen an die physische Resilienz, die Erkennungssysteme und -mechanismen der Bodenstationen, den Schutz der Netz- und Informationssysteme, die zur Gewährleistung einer angemessenen Überlebensfähigkeit des Weltraumsegments und zur Erleichterung einer raschen Wiederherstellung nach Sicherheitsvorfällen erforderlichen Reserven sowie das Risikomanagement in der Lieferkette. Der Kommission sollte die Befugnis übertragen werden, gemäß Artikel 290 AEUV Rechtsakte zur Ergänzung dieser Verordnung zu erlassen, um die Verwendung zertifizierter kryptografischer Produkte und Schlüsselverwaltungsprodukte oder -dienste zum Schutz von Telemetrie und Telekommandos festzulegen, indem Folgendes spezifiziert wird: die Kriterien für schwerwiegende Betriebsstörungen der Weltraumtätigkeiten oder -dienste, der Betriebsmodus und die Anforderungen für die aktive Müllbeseitigung für ISOS, die Höhe der von der Agentur erhobenen Gebühren und die Art und Weise ihrer Zahlung, die Verhängung von Geldbußen und Zwangsgeldern, die Kriterien für die Zusammensetzung und das Fachwissen des Personals, das die gemeinsamen Prüfungsteams für die technischen Gremien zusammenstellt, sowie die Bereiche, die von der Kofinanzierung profitieren. Es ist von besonderer Bedeutung, dass die Kommission im Zuge ihrer Vorbereitungsarbeit angemessene Konsultationen, auch auf der Ebene von Sachverständigen, durchführt, die mit den Grundsätzen in Einklang stehen, die in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung niedergelegt wurden. Um insbesondere für eine gleichberechtigte Beteiligung an der Vorbereitung delegierter Rechtsakte zu sorgen, erhalten das Europäische Parlament und der Rat alle Dokumente zur gleichen Zeit wie die Sachverständigen der Mitgliedstaaten, und ihre Sachverständigen haben systematisch Zugang zu den Sitzungen der Sachverständigengruppen der Kommission, die mit der Vorbereitung der delegierten Rechtsakte befasst sind.

<a id="rec-135"></a>
(135) Um einheitliche Bedingungen für die Durchführung dieser Verordnung zu gewährleisten, sollten der Kommission Durchführungsbefugnisse übertragen werden, um auf der Grundlage einer detaillierten Bewertung Gleichwertigkeitsbeschlüsse zur Gewährung von Ausnahmeregelungen für Trägerraketen zu erlassen, wenn die Bedingung eines öffentlichen Interesses erfüllt ist, um einer öffentlichen Einrichtung eines Drittlands die Bereitstellung von Weltraumdiensten oder weltraumgestützten Daten in der Union bis zum Abschluss internationaler Übereinkünfte zu ermöglichen, um Maßnahmen zur Einleitung der Kollisionsvermeidung und Senkung der Unfallgefahr bei Start und Wiedereintritt zu entwickeln, um den Weltraummüll von Trägerraketen zu vermindern, zur Rückverfolgbarkeit von Raumfahrzeugen, für Regeln für den Umlaufverkehr, zur Positionierung von Raumfahrzeugen in der Umlaufbahn, zur Eindämmung des Weltraummülls von Raumfahrzeugen, für die Konstellation von Raumfahrzeugen, zur Festlegung des Inhalts und der Vorlagen für die Meldung erheblicher Sicherheitsvorfälle, zur Festlegung der Methode für die Berechnung und Überprüfung des Umweltfußabdrucks von Weltraumtätigkeiten sowie der Vorlagen und Inhalte für die Berichterstattung in Bezug auf die Erklärung zur Berechnung des Umweltfußabdrucks, zur Festlegung der Entwurfsgrundsätze für SSI und kompostierbare und austauschbare funktionale Satellitenmodule für ISOS; zur Festlegung der gemeinsamen Spezifikationen für die technischen Anforderungen an das elektronische Zertifikat sowie für den dunklen und ruhigen Himmel, zur Festlegung von Vorlagen für die Weltraumsiegelsysteme der Union und Annahme neuer oder geänderter Weltraumsiegelsysteme der Union. Diese Befugnisse sollten im Einklang mit der Verordnung (EU) Nr. 182/2011 des Europäischen Parlaments und des Rates^(31)^(17) ausgeübt werden.

<a id="rec-136"></a>
(136) Die Kommission sollte sofort geltende Durchführungsrechtsakte erlassen, wenn in hinreichend begründeten Fällen im Zusammenhang mit Krisen oder Notfällen im Binnenmarkt Gründe äußerster Dringlichkeit für einen befristeten Zeitraum die Nutzung weltraumgestützter Daten oder Dienste erfordern, die nicht im URSO registriert sind.

<a id="rec-137"></a>
(137) Da die Ziele dieser Verordnung, nämlich die Schaffung eines Binnenmarkts für den Weltraumsektor durch harmonisierte gemeinsame Vorschriften, mit denen den wichtigsten Risiken für die Weltrauminfrastruktur und Weltraumdienste begegnet und dadurch die Sicherheit, Resilienz und ökologische Nachhaltigkeit von Weltraumtätigkeiten sichergestellt werden sollen, auf Ebene der Mitgliedstaaten nicht ausreichend verwirklicht werden können, sondern vielmehr wegen des Umfangs oder der Wirkungen auf Unionsebene besser zu verwirklichen sind, kann die Union im Einklang mit dem in Artikel 5 des Vertrags über die Europäische Union verankerten Subsidiaritätsprinzip tätig werden. Entsprechend dem in demselben Artikel genannten Grundsatz der Verhältnismäßigkeit geht diese Verordnung nicht über das für die Verwirklichung dieser Ziele erforderliche Maß hinaus.

<a id="rec-138"></a>
(138) Die Einhaltung der Vorschriften für die ökologische Nachhaltigkeit sollte für Betreiber im Bereich Weltraum, bei denen es sich um kleine Unternehmen oder Forschungs- oder Bildungseinrichtungen handelt 48 Monate nach Inkrafttreten dieser Verordnung verpflichtend sein, während die Anforderungen im Zusammenhang mit der Bereitstellung von ISOS 60 Monate nach Inkrafttreten dieser Verordnung gelten sollten.

<a id="rec-139"></a>
(139) Darüber hinaus werden in dieser Verordnung die Dauer der Vorbereitung auf Weltraummissionen und die technischen und komplexen Einschränkungen der verschiedenen Meilensteine während der gesamten Konstruktions- und Bauphase von Raumfahrzeugen gebührend berücksichtigt. Eine Übergangsfrist erscheint notwendig, um Einschränkungen Rechnung zu tragen, die sich aus den technischen Anpassungen ergeben, die in den Vorbereitungsphasen einer Weltraummission im Rahmen der Phase der kritischen Entwurfsprüfung erforderlich sind.

<a id="rec-140"></a>
(140) Den Betreibern im Bereich Weltraum sollte ausreichend Zeit für die Anpassung an die in dieser Verordnung festgelegten Anforderungen eingeräumt werden. Die Anwendung dieser Verordnung sollte 24 Monate nach ihrem Inkrafttreten beginnen —

HABEN FOLGENDE VERORDNUNG ERLASSEN:

<a id="title-i"></a>
## Titel I – ALLGEMEINE BESTIMMUNGEN

<a id="art-1"></a>
### Artikel 1 – Gegenstand

(1) Diese Verordnung enthält Vorschriften für die Errichtung und das Funktionieren des Binnenmarkts für weltraumgestützte Daten und Weltraumdienste.

(2) Mit dem Ziel, durch den Betrieb und die Nutzung von Weltrauminfrastrukturen, die weltraumgestützte Daten generieren, ein hohes gemeinsames Maß an Sicherheit, Resilienz und ökologischer Nachhaltigkeit von Weltraumdiensten zu erreichen, werden in dieser Verordnung harmonisierte Vorschriften für Folgendes festgelegt:

  - a) Genehmigung, Registrierung und Überwachung von Weltraumtätigkeiten, die von in der Union niedergelassenen Erbringern von Weltraumdiensten durchgeführt werden, bzw. Registrierung und Beaufsichtigung von Weltraumtätigkeiten, die von in Drittländern niedergelassenen internationalen Organisationen und Anbietern von Weltraumdiensten bei der Bereitstellung von weltraumgestützten Daten oder Weltraumdiensten in der Union bereitgestellt werden, in Bezug auf Fragen der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten;

  - b) Vorschriften für das Verkehrsmanagement in der Umlaufbahn in Form der Bereitstellung von Diensten zur Kollisionsvermeidung;

  - c) Governance- und Durchsetzungsaspekte;

  - d) Einführung eines Weltraumsiegels der Union und Maßnahmen zum Kapazitätsaufbau.

<a id="art-2"></a>
### Artikel 2 – Anwendungsbereich

(1) Diese Verordnung gilt für die folgenden Anbieter von Weltraumdiensten:

  - a) Betreiber im Bereich Weltraum;

  - b) Anbieter von Weltraumdiensten zur Kollisionsvermeidung;

  - c) Primäranbieter weltraumgestützter Daten;

  - d) internationalen Organisationen.

(2) Titel IV Kapitel I und V gelten nicht für Umlaufbahnen, die weiter entfernt sind als die geostationäre Erdumlaufbahn (GEO).

(3) Diese Verordnung gilt nicht für:

  - a) Weltraumobjekte, die ausschließlich für Zwecke der Verteidigung oder der nationalen Sicherheit verwendet werden, unabhängig davon, welcher Anbieter von Weltraumdiensten die Weltraumtätigkeiten durchführt;

  - b) Weltraumobjekte, die für die Dauer der jeweiligen Weltraummission vorübergehend einer militärischen Operation und Kontrolle zu Verteidigungszwecken unterstellt wurden;

  - c) die Genehmigung oder Verwaltung von Funkfrequenzen gemäß dem Beschluss 676/2002/EU, der Richtlinie (EU) 2018/1972 und dem Beschluss Nr. 243/2012/EU;

  - d) vor dem 1. Januar 2030 gestartete Ressourcen.

(4) Die in Titel IV Kapitel I festgelegten Anforderungen an den Entwurf und die Herstellung von Weltraumobjekten gelten für Weltraumobjekte, deren Operation weltraumgestützte Daten generiert, die in der Union genutzt werden oder die Bereitstellung von Weltraumdiensten in der Union ermöglichen.

<a id="art-3"></a>
### Artikel 3 – Freier Verkehr

(1) Die Mitgliedstaaten beschränken die Bereitstellung von weltraumgestützten Daten und Weltraumdiensten in der Union durch Anbieter von Weltraumdiensten, die im Unionsregister der Weltraumobjekte gemäß Artikel 24 eingetragen sind, nicht aus Gründen der Sicherheit, Resilienz und ökologischen Nachhaltigkeit im Rahmen dieser Verordnung.

(2) Ungeachtet des Absatzes 1 können die Mitgliedstaaten in Fällen, in denen ein Anbieter von Weltraumdiensten der Union beabsichtigt, in einem anderen Mitgliedstaat als dem Niederlassungsmitgliedstaat tätig zu werden oder von einem solchen aus zu Starts durchzuführen, bei der Erteilung der jeweiligen Operations- oder Startgenehmigungen strengere Anforderungen an die Sicherheit, Resilienz oder ökologische Nachhaltigkeit in Bezug auf die jeweilige Weltraummission stellen, soweit diese Anforderungen objektiv erforderlich sind, um die Sicherheit, Resilienz oder ökologische Nachhaltigkeit der jeweiligen Operation oder des jeweiligen Starts vorbehaltlich einer Genehmigung in ihrem Hoheitsgebiet zu gewährleisten.

(3) Die Mitgliedstaaten stellen alle einschlägigen Informationen bezüglich der in Absatz 2 genannten Anforderungen über das gemäß Artikel 110 eingerichtete Informationsportal zur Verfügung.

<a id="art-4"></a>
### Artikel 4 – Klausel über die nationale Sicherheit

Diese Verordnung berührt nicht die Zuständigkeiten der Mitgliedstaaten bezüglich des Schutzes der nationalen Sicherheit und anderer wesentlicher staatlicher Funktionen.

<a id="art-5"></a>
### Artikel 5 – Begriffsbestimmungen

Für die Zwecke dieser Verordnung gelten folgende Begriffsbestimmungen:

  - 1. „Weltraumobjekt“ bezeichnet ein vom Menschen hergestelltes Objekt, das in den Weltraum geschickt wird, einschließlich eines Raumfahrzeugs und der Orbitalstufe einer Trägerrakete;

  - 2. „Raumfahrzeug“ bezeichnet ein Weltraumobjekt, das der Erfüllung einer bestimmten Funktion oder Weltraummission dient, beispielsweise der Bereitstellung von Kommunikations-, Navigations- oder Beobachtungsdiensten oder der Bereitstellung von Operationen und Diensten im Weltraum, und schließt Satelliten, Trägerraketen-Orbitalstufen und Wiedereintrittskörper ein.

  - 3. „Konstellation“ bezeichnet eine Gruppe von Weltraumobjekten, die aus mindestens 10 und höchstens 99 operativen Raumfahrzeugen besteht, die für eine gemeinsame Weltraummission koordiniert werden und einem vordefinierten Plan für den Einsatz in der Umlaufbahn unterliegen;

  - 4. „Megakonstellation“ bezeichnet eine Konstellation mit mindestens 100 und nicht mehr als 999 operativen Raumfahrzeugen;

  - 5. „Gigakonstellation“ bezeichnet eine Konstellation mit mindestens 1 000 operativen Raumfahrzeugen;

  - 6. „geogeschütztes Gebiet“ bezeichnet ein Segment der Kugelschale, das wie folgt definiert wird: untere Höhe = geostationäre Höhe minus 200 km; obere Höhe = geostationäre Höhe plus 200 km; – 15 Grad ≤ geografische Breite ≤ + 15 Grad geostationäre Höhe (35 786 km ist die Höhe der geostationären Erdumlaufbahn);

  - 7. „Mini-Satellitenklasse“ bezeichnet eine Klasse von Satelliten mit einem Gewicht von mindestens 201 kg und weniger als 600 kg;

  - 8. „Weltraummission“ bezeichnet eine von einem Weltraumobjekt durchzuführende nutzerdefinierte Mission;

  - 9. „Weltrauminfrastruktur“ bezeichnet eine Ressource oder eine Reihe von Ressourcen, Systeme und Teilsysteme oder Teile davon, die für die Durchführung von Weltraumtätigkeiten durch Interaktion und die Operation von Boden-, Weltraum- und Verbindungssegmenten genutzt wird;

  - 10. „Bodensegment“ bezeichnet das auf der Erde befindliche Segment der Weltrauminfrastruktur innerhalb oder außerhalb des Gebiets der Union, das die im Anhang der Richtlinie (EU) 2022/2557 genannte Bodeninfrastruktur umfasst, einschließlich Folgendem: Bodenstationen, Terminals, terrestrische Ausrüstung, die für die Kommunikation mit Weltraumobjekten und zur Unterstützung der Durchführung von Weltraumtätigkeiten benötigt wird, Missionskontrollzentren und andere Bodenkontrollzentren, generische Bodeninfrastruktur, Bodennetze, Hilfseinrichtungen wie Raumfahrzeug-AIT-Anlagen (Assembly, Testing and Integration), Startpads und damit zusammenhängende Infrastrukturen, die für die Durchführung von Starttätigkeiten erforderlich sind;

  - 11. „Weltraumsegment“ bezeichnet das im Weltraum befindliche Segment der Weltrauminfrastruktur, einschließlich Folgendem: Weltraumobjekte, Raumstationen, Raumsonden, bemannte Raumtransportsysteme sowie eingebaute Hardware und Software in den Informationssystemen und sonstiges eingebautes Material bzw. sonstige eingebaute Ausrüstung;

  - 12. „weltraumgestützte Daten“ bezeichnet Daten, die aus dem Weltraum empfangen werden, einschließlich, aber nicht beschränkt auf die Daten des Abfangens, der Lokalisierung oder der Übertragung eines von einem Weltraumobjekt erzeugten Signals sowie Beobachtungsdaten, die von der Erde, einem Himmelskörper, einem Weltraumobjekt oder aus dem Weltraum stammen;

  - 13. „Weltraumtätigkeiten“ bezeichnet eine Reihe von Operationen die bei Tätigkeiten im Weltraum durchgeführt werden, insbesondere:

    - a) Operation und Steuerung von Weltraumobjekten, auch für den Wiedereintritt;

    - b) Startdienste, einschließlich Startversuche;

    - c) Operation und Instandhaltung von Startplätzen und -anlagen;

    - d) Tätigkeiten im Zusammenhang mit der Erkundung des Weltraums, z. B. bemannte Raumfahrt, Weltraumtransport und Durchführung von – auch wissenschaftlichen – Experimenten im Weltraum;

    - e) Tätigkeiten im Zusammenhang mit der Nutzung und der Verwaltung von Weltraumobjekten im außeratmosphärischen Raum, wie z. B. Operationen und Dienste im Weltraum (ISOS);

    - f) Operationen, die die Überwachung von Weltraummüll umfassen;

    - g) Operationen, die die Entsorgung von Weltraummüll umfassen;

  - 14. „Weltraumdienste“ bezeichnet einen der folgenden Dienste:

    - a) Operation und Steuerung eines Weltraumobjekts;

    - b) Bereitstellung von Startdiensten sowie Diensten für die Operation und die Instandhaltung der Startplätze;

    - c) alle Dienste, die von Primäranbieter weltraumgestützter Daten bereitgestellt werden;

    - d) Operationen und Dienste im Weltraum (ISOS);

    - e) Weltraumdienste zur Kollisionsvermeidung;

  - 15. „Anbieter von Weltraumdiensten“ bezeichnet einen Anbieter von Weltraumdiensten, der unter diese Verordnung fällt;

  - 16. „Betreiber im Bereich Weltraum“ bezeichnet eine öffentliche oder private Einrichtung, die eine Weltrauminfrastruktur betreibt, indem sie auf der Grundlage einer Genehmigung oder einer besonderen Regelung für die Durchführung eines nationalen Weltraumprogramms mindestens einen der folgenden Weltraumdienste bereitstellt:

    - a) Operation, Steuerung und Rückkehr eines Weltraumobjekts (im Folgenden „Raumfahrzeugbetreiber“)

    - b) Operation, Steuerung und Überwachung des Startprozesses eines Weltraumobjekts (im Folgenden „Startbetreiber“);

    - c) Operation, Steuerung und Instandhaltung von Anlagen des Bodensegments der für den Startprozess genutzten Weltrauminfrastruktur (im Folgenden „Betreiber des Startplatzes“);

    - d) Operation und Steuerung eines Weltraumobjekts für die Zwecke der Durchführung von Operationen und Diensten im Weltraum, auch für andere Weltraumobjekte (im Folgenden „ISOS-Anbieter“);

  - 17. „Unionsbetreiber im Bereich Weltraum“ bezeichnet einen Betreiber im Bereich Weltraum, der in der Union niedergelassen ist oder von einer natürlichen oder juristischen Person kontrolliert wird, bei der es sich um einen in der Union niedergelassenen Anbieter von Weltraumdiensten handelt;

  - 18. „Kontrolle“ bezeichnet für die Zwecke der Nummer 17 die Fähigkeit, unmittelbar oder mittelbar durch einen oder mehrere zwischengeschaltete Rechtsträger einen bestimmenden Einfluss auf einen Rechtsträger auszuüben;

  - 19. „Drittlandsbetreiber im Bereich Weltraum“ bezeichnet einen in einem Drittland niedergelassenen Betreiber im Bereich Weltraum, der Folgendes durchführt:

    - a) Bereitstellung von Weltraumdiensten für Unionsbetreiber im Bereich Weltraum oder in Bezug auf die unter den Nummern 20 und 21 definierten Weltraumressourcen,

    - b) eigenständiges Handeln als Primäranbieter weltraumgestützter Daten oder

    - c) Bereitstellung von Diensten für Primäranbieter weltraumgestützter Daten;

  - 20. „unionseigene Ressourcen“ bezeichnet die in Artikel 9 Absatz 1 der Verordnung (EU) 2021/696 und Artikel 1 der Verordnung (EU) 2023/588 genannten materiellen und immateriellen Vermögenswerte, die im Rahmen des Weltraumprogramms der Union geschaffen oder entwickelt wurden;

  - 21. „staatliche oder nichtstaatliche Weltraumressourcen“ bezeichnet andere als die unter Nummer 20 definierten Ressourcen, unabhängig davon, ob sie sich in öffentlichem oder privatem Eigentum befinden, die von einer Behörde oder einer in einem Mitgliedstaat niedergelassenen privaten Partei betrieben werden, einschließlich unter ziviler Kontrolle gestellter Ressourcen mit doppeltem Verwendungszweck;

  - 22. „Primäranbieter weltraumgestützter Daten“ bezeichnet in der Union oder in einem Drittland niedergelassene Anbieter von Weltraumdiensten, die eine Erstverarbeitung weltraumgestützter Daten einleiten, die technisch ausreichend ist, um eine spätere Bereitstellung weltraumgestützter Daten zu ermöglichen, im Einzelnen:

    - a) Anbieter elektronischer Kommunikationsdienste, wenn es sich bei den betreffenden weltraumgestützten Daten um Kommunikation handelt;

    - b) Anbieter von Weltraumdiensten, die die Erstverarbeitung von Beobachtungsdaten vor einer weiteren Verarbeitung sicherstellen, wenn es sich bei den betreffenden weltraumgestützten Daten um Beobachtungsdaten handelt;

  - 23. „internationale Organisation“ bezeichnet eine internationale Organisation, die in der Union Weltraumdienste oder weltraumgestützte Daten bereitstellt, die von Weltraumobjekten erzeugt werden, die nicht über die geostationäre Umlaufbahn hinausgehen und von solchen internationalen Organisationen betrieben werden;

  - 24. „Anbieter von Weltraumdiensten zur Kollisionsvermeidung“ bezeichnet einen Anbieter von Diensten zur Kollisionsvermeidung, einschließlich der Kollisionsvermeidungsstelle in der Union oder Kollisionsvermeidungsanbieter, die in einem Drittland niedergelassen sind;

  - 25. „Forschungs- und Bildungseinrichtung“ bezeichnet einen Anbieter von Weltraumdiensten, der Weltraumtätigkeiten zu experimentellen Zwecken durchführt, unabhängig davon, ob die Ergebnisse dieser Forschung für kommerzielle Zwecke genutzt werden oder nicht;

  - 26. „kleine und mittlere Unternehmen“ (im Folgenden „KMU“) bezeichnet kleine und mittlere Unternehmen im Sinne des Artikels 2 des Anhangs der Empfehlung 2003/361/EG der Kommission ;

  - 27. „kleine Midcap-Unternehmen“ bezeichnet Unternehmen im Sinne des Artikels 2 des Anhangs der Empfehlung C(2025) 3500 final der Kommission;

  - 28. „Stellen, die ein vereinfachtes Risikomanagement anwenden“ bezeichnet Betreiber im Bereich Weltraum, bei denen es sich um kleine Unternehmen oder Forschungs- oder Bildungseinrichtungen handelt und die das vereinfachte Risikomanagement gemäß Artikel 10 Absatz 3 und Artikel 15 Absatz 2 anwenden;

  - 29. „Trägerrakete“ bezeichnet ein System, das Teil eines Weltraumsegments ist und dazu bestimmt ist, ein oder mehrere Weltraumobjekte in den Weltraum zu transportieren;

  - 30. „Orbitalstufe einer Trägerrakete“ bezeichnet ein vollständiges Element einer Trägerrakete, das dazu bestimmt ist, während einer speziellen Phase der Operation der Trägerrakete für das Erreichen der Umlaufbahn einen bestimmten Schub zu erzeugen;

  - 31. „Startdienst“ bezeichnet einen Dienst, der dazu bestimmt ist, ein Weltraumobjekt in die Umlaufbahn zu bringen, einschließlich Startversuchen;

  - 32. „Startplatz“ bezeichnet einen Ort auf der Erde, der Teil des Bodensegments der Weltrauminfrastruktur ist und von dem aus der Start eines Weltraumobjekts durchgeführt wird;

  - 33. „Ereignisse von hohem Interesse“ oder „HIE“ (High-Interest Events) bezeichnet Annäherungen mit einem hohen Risiko, welche die Durchführung von Kollisionsvermeidungsmanövern durch einen Betreiber im Bereich Weltraum erforderlich machen können;

  - 34. „Nominalbetrieb“ bezeichnet die Ausführung geplanter Aufgaben oder der Funktionen, für die ein Raumfahrzeug oder die Orbitalstufe einer Trägerrakete entworfen wurde;

  - 35. „Konjunktionsdatennachrichten“ bezeichnet Informationen über eine Konjunktion zwischen zwei Weltraumobjekten;

  - 36. „Kollisionsvermeidung“ bezeichnet die Durchführung von Kollisionsvermeidungsmanövern mit Blick auf eine Verringerung des Kollisionsrisikos im Weltraum;

  - 37. „Delta V“ bezeichnet die Geschwindigkeitserhöhung, die erforderlich ist, um eine bestimmte Umlauf- oder Flugbahn zu erreichen;

  - 38. „Objekt von Interesse“ bezeichnet alle Gegenstände, die an einer Situation beteiligt sind, die andere Weltraumobjekte oder die Situation auf der Erde beeinträchtigen könnte;

  - 39. „Wiedereintritt“ bezeichnet die dauerhafte Rückkehr eines Weltraumobjekts in die Erdatmosphäre;

  - 40. „Entsorgung“ bezeichnet eine Reihe von Maßnahmen, die von einem Raumfahrzeug oder einer Orbitalstufe einer Trägerrakete mit oder ohne Unterstützung eines Versorgungsraumfahrzeugs durchgeführt werden, um das Risiko einer unbeabsichtigten Fragmentierung dauerhaft zu verringern und eine langfristige Freihaltung der Umlaufbahnen zu erreichen;

  - 41. „Entsorgungsphase“ bezeichnet den Zeitraum zwischen dem Ende der Weltraummission eines Raumfahrzeugs bzw. einer Orbitalstufe einer Trägerrakete und dem Ende ihrer bzw. seiner Lebensdauer;

  - 42. „Ende der Lebensdauer“ bezeichnet den Moment, in dem ein Raumfahrzeug oder die Orbitalstufe einer Trägerrakete dauerhaft abgeschaltet ist, nämlich bei Abschluss der Entsorgungsphase, bei Wiedereintritt in die Erdatmosphäre oder Steuerungsverlust durch einen Betreiber im Bereich Weltraum;

  - 43. „Missionsende“ bezeichnet die Phase, in der ein Raumfahrzeug oder die Orbitalstufe einer Trägerrakete die Aufgaben, für die es bzw. sie konzipiert wurde, abschließt – und bei der es sich nicht um die Entsorgung handelt oder es bzw. sie infolge eines Ausfalls nicht mehr funktionstüchtig ist – oder in der es bzw. sie durch eine willentliche Entscheidung dauerhaft angehalten wird;

  - 44. „Passivierung“ bezeichnet die dauerhafte Entschärfung, unumkehrbare Deaktivierung oder Sicherung aller im Fahrzeug gelagerten Energiequellen, die zu einer unbeabsichtigten Fragmentierung führen könnten;

  - 45. „Weltraummüll“ bezeichnet jedes in einer Erd- oder Mondumlaufbahn befindliche oder wieder in die Erdatmosphäre oder Mondexosphäre eintretende Weltraumobjekt, einschließlich Raumfahrzeuge sowie Bruchstücke oder Teile davon, das funktionsuntüchtig ist oder keinem bestimmten Zweck mehr dient, einschließlich Teile von Raketen oder künstlichen Satelliten sowie nicht mehr in Betrieb befindliche künstliche Satelliten;

  - 46. „Netz- und Informationssystem“ bezeichnet ein Netz- und Informationssystem im Sinne des Artikels 6 Nummer 1 der Richtlinie (EU) 2022/2555 ;

  - 47. „Sicherheit von Netz- und Informationssystemen“ die Sicherheit von Netz- und Informationssystemen im Sinne des Artikels 6 Nummer 2 der Richtlinie (EU) 2022/2555 ;

  - 48. „kritische Infrastrukturen“ bezeichnet kritische Infrastrukturen im Sinne des Artikels 2 Nummer 4 der Richtlinie (EU) 2022/2557;

  - 49. „Missionskontrollzentrum“ bezeichnet das Element des Bodensegments, das der Steuerung und Überwachung der Durchführung einer Weltraummission dient;

  - 50. „Satellitenkontrollzentrum“ bezeichnet das Element des Bodensegments, das der Steuerung und Überwachung der Konfiguration einer Satellitenplattform dient;

  - 51. „wirksame technische Kontrolle“ bezeichnet die Sicherstellung eines Betreibers im Bereich Weltraum, dass ein Weltraumobjekt ausschließlich Befehle ausführt, die von autorisierten Quellen übermittelt werden, und dass diese Befehle in der richtigen Reihenfolge und zum vorgesehenen Zeitpunkt ausgeführt werden;

  - 52. „Telemetrie/Telekommando“ bezeichnet die Verbindungen, die die Telemetrie vom Weltraumsegment zum Bodensegment übertragen, und die Verbindungen, die das Telekommando vom Bodensegment an das Weltraumsegment senden;

  - 53. „Resilienz“ bezeichnet die Fähigkeit, einen Sicherheitsvorfall zu verhindern, sich davor zu schützen, darauf zu reagieren und einen solchen abzuwehren, die Folgen eines solchen Vorfalls zu begrenzen, einen Sicherheitsvorfall aufzufangen, zu bewältigen und sich von einem solchen Vorfall zu erholen;

  - 54. „Cyberbedrohung“ bezeichnet eine Cyberbedrohung im Sinne des Artikels 2 Nummer 8 der Verordnung (EU) 2019/881 ;

  - 55. „erhebliche Cyberbedrohung“ bezeichnet eine erhebliche Cyberbedrohung im Sinne des Artikels 6 Nummer 11 der Richtlinie (EU) 2022/2555 ;

  - 56. „Sicherheitsvorfall“ bezeichnet ein Ereignis, das Folgendes beeinträchtigt:

    - a) die Verfügbarkeit, Authentizität, Integrität oder Vertraulichkeit der gespeicherten, übermittelten oder verarbeiteten Daten oder der Dienste, die über Netz- und Informationssysteme angeboten werden bzw. zugänglich sind, oder

    - b) die physische Sicherheit der Ressourcen der Weltrauminfrastruktur und der Betreiber im Bereich Weltraum;

  - 57. „Bewältigung von Sicherheitsvorfällen“ bezeichnet die Bewältigung von Sicherheitsvorfällen im Sinne des Artikels 6 Nummer 8 der Richtlinie (EU) 2022/2555 ;

  - 58. „zusätzliche Wirkungskategorien“ bezeichnet Kategorien von Umweltinformationen, die nicht zu den Wirkungskategorien des Umweltfußabdrucks gehören, die zusammen mit den Ergebnissen des Umweltfußabdrucks von Produkten berechnet und mitgeteilt werden;

  - 59. „aggregierter Datensatz“ bezeichnet eine Sachbilanz mehrerer Prozesse oder Lebenszyklusabschnitte, bei dem Inputs und Outputs lediglich horizontal oder vertikal auf aggregierter Ebene bereitgestellt werden;

  - 60. „ökologische Nachhaltigkeit“ bezeichnet die Fähigkeit, die natürliche Erdumwelt im Laufe der Zeit durch geeignete Verfahren und Strategien zu erhalten und zu schützen, die dem aktuellen Bedarf gerecht werden, und die keine Auswirkungen auf die Verfügbarkeit von Ressourcen in der Zukunft haben;

  - 61. „Disaggregation“ bezeichnet das Verfahren, in dem ein aggregierter Datensatz in kleinere Prozessdatensätze für horizontale oder vertikale Einheiten aufgegliedert wird;

  - 62. „abgeleiteter Datensatz“ bezeichnet einen Datensatz, der durch die Kombination von zwei oder mehr Datensätzen durch mathematische Vorgänge oder durch die Kombination von mindestens einem Datensatz mit wesentlichen zusätzlichen Informationen oder anderen Datensätzen gewonnen wird;

  - 63. „Operationen und Dienste im Weltraum“ oder „ISOS“ (In-Space Operations and Services) bezeichnet Tätigkeiten, die im Weltraum (auf der Umlaufbahn und im Weltraum) zur Erbringung von Diensten an Ressourcen im Weltraumsegment durchgeführt werden und die die Wahrnehmung von Aufgaben wie den folgenden umfassen: Inspektion, Rendezvous, Andocken, Reparatur, Betankung, Rekonfigurierung, Herstellung, Montage und Demontage, Wiederverwendung, Recycling, Entfernung und Transport operativer, nicht-operativer und fehlerhafter Objekte (Müll) im Weltraum, einschließlich Plattformen oder größerer Strukturen, durch ein hochautonomes Versorgungsraumfahrzeug;

  - 64. „ISOS-Operation“ bezeichnet die Ausführung der geplanten ISOS-Aufgaben im Zusammenhang mit einem oder mehreren Weltraumobjekten;

  - 65. „ISOS-Versorgungsraumfahrzeug“ bezeichnet ein Raumfahrzeug, das speziell für den Zweck der Bereitstellung bestimmter ISOS entworfen worden ist;

  - 66. „Kundenraumfahrzeug“ bezeichnet ein Raumfahrzeug, das ISOS erhält;

  - 67. „zuständige Behörde“ bezeichnet eine Behörde, die gemäß Artikel 28 als zuständige Behörde eingerichtet oder benannt wurde;

  - 68. „qualifizierte technische Stelle für Weltraumtätigkeiten“ bezeichnet eine in einem Mitgliedstaat niedergelassene technische Stelle, die eine technische Bewertung in Bezug auf unter diese Verordnung fallende Angelegenheiten im Zusammenhang mit Sicherheit, Resilienz und ökologischer Nachhaltigkeit durchführt und die der Kommission gemäß dieser Verordnung notifiziert wurde;

  - 69. „technische Bewertung“ bezeichnet das Verfahren, mit dem nachgewiesen wird, dass Anbieter von Weltraumdiensten die in dieser Verordnung festgelegten technischen Anforderungen erfüllen;

  - 70. „Norm“ bezeichnet eine Norm im Sinne des Artikels 2 Nummer 1 der Verordnung (EU) 1025/2012 ;

  - 71. „gemeinsame Spezifikationen“ bezeichnet eine Reihe technischer Anforderungen, bei denen es sich nicht um eine Norm handelt und durch die die Einhaltung der in Bezug auf das elektronische Zertifikat sowie die Licht- und Funkverschmutzung geltenden Anforderungen ermöglicht wird;

  - 72. „Umsatz“ bezeichnet die von einem Unternehmen im Sinne des Artikels 5 Absatz 1 der Verordnung (EG) Nr. 139/2004 des Rates erzielten Umsätze;

  - 73. „Weltraumsiegel der Union“ bezeichnet ein von der mit Artikel 1 der Verordnung (EU) 2021/696 eingerichteten Agentur der Europäischen Union für das Weltraumprogramm der Union (im Folgenden „Agentur“) ausgestelltes Dokument, in dem bescheinigt wird, dass ein bestimmtes Weltraumobjekt im Hinblick auf die Einhaltung der in einem Weltraumsiegelsystem der Union festgelegten spezifischen Anforderungen an die Sicherheit, die Resilienz oder die ökologische Nachhaltigkeit bewertet worden ist;

  - 74. „Weltraumsiegelsystem der Union“ bezeichnet ein umfassendes Paket von auf Unionsebene festgelegten Vorschriften, technischen Anforderungen, Normen und Verfahren, die für die Überprüfung der Konformität von Produkten, Verfahren und Dienstleistungen gelten, einschließlich Test- und Inspektionstätigkeiten in Bezug auf Sicherheit, Resilienz oder ökologische Nachhaltigkeit;

  - 75. „kritische Entwurfsprüfung“ bezeichnet die Phase des Konstruktions-, Fertigungs- und Entwicklungsverfahrens, in der festgestellt wird, dass der Entwurf und die Konfiguration der Systeme und Teilsysteme allen spezifizierten Anforderungen der Weltraummission in Bezug auf Leistung, Kompatibilität, Produktspezifikationen, Risikobewertung, vorläufige Prüfplanung, Angemessenheit der vorläufigen Operation und Bereitstellung von Unterlagen genügen, damit die Implementierung und Integration des Systems fortgeführt werden können.

<a id="title-ii"></a>
## Titel II – GENEHMIGUNG UND REGISTRIERUNG VON WELTRAUMTÄTIGKEITEN

<a id="title-ii-chapter-i"></a>
## Kapitel I – GENEHMIGUNG VON UNIONSBETREIBERN IM BEREICH WELTRAUM

<a id="art-6"></a>
### Artikel 6 – Genehmigung für die Durchführung von Weltraumtätigkeiten

(1) Unionsbetreiber im Bereich Weltraum dürfen Weltraumdienste nur dann bereitstellen, wenn sie in einem Mitgliedstaat eine Genehmigung zur Durchführung von Weltraumtätigkeiten erhalten haben, in der je nach Kategorie des betreffenden Betreibers im Bereich Weltraum die Einhaltung der in Titel IV Kapitel I bis V festgelegten Anforderungen bestätigt wird.

(2) Ein Mitgliedstaat erkennt die von einem anderen Mitgliedstaat erteilten Genehmigungen hinsichtlich der in Titel IV Kapitel I bis V festgelegten Anforderungen an.

(3) Die Genehmigung wird von der zuständigen Behörde des Mitgliedstaats, in dem der Antragsteller niedergelassen ist, und gegebenenfalls von der zuständigen Behörde des Mitgliedstaats, in dem der Antragsteller tätig sein will bzw. in dem er Starts durchführen will, sofern es sich nicht um den Niederlassungsmitgliedstaat handelt, ausgestellt.

    Die zuständigen Behörden dieser Mitgliedstaaten koordinieren sich untereinander, um ihre jeweiligen Genehmigungsverfahren zu erleichtern.

(4) Für die Zwecke der Erteilung einer Genehmigung berücksichtigt die zuständige Behörde die Stellungnahme der qualifizierten technischen Stelle für Weltraumtätigkeiten im Rahmen der gemäß Artikel 8 durchgeführten technischen Bewertungen.

(5) Unionsbetreiber im Bereich Weltraum, die beabsichtigen, die Weltraumdienste eines Drittlandsbetreibers im Bereich Weltraum oder einer internationalen Organisation in Anspruch zu nehmen, weisen gegenüber den jeweils zuständigen Behörden in ihrem Antrag auf Genehmigung nach, dass dieser Betreiber im Bereich Weltraum oder die internationale Organisation gemäß Artikel 17 bzw. Artikel 18 im URSO registriert ist.

    Ist das Registrierungsverfahren im URSO noch nicht abgeschlossen, so stimmt sich der Unionsbetreiber im Bereich Weltraum eng mit dem Drittlandsbetreiber im Bereich Weltraum oder der internationalen Organisation aus dem Drittland, der jeweils zuständigen Behörde und der Agentur ab, indem er unter anderem Aktualisierungen bezüglich des Stands des Registrierungsverfahrens anfordert.

    Die Agentur stellt solche Aktualisierungen unverzüglich zur Verfügung, um unnötige Verzögerungen im Genehmigungsverfahren für den Unionsbetreiber im Bereich Weltraum zu vermeiden.

(6) Ergibt sich die Notwendigkeit der Bereitstellung von Weltraumdiensten durch einen Drittlandsbetreiber im Bereich Weltraum oder eine internationale Organisation, nachdem eine Genehmigung erteilt wurde, wie z. B. im Falle von ISOS, so unterrichtet der Unionsbetreiber im Bereich Weltraum unverzüglich die zuständige Behörde darüber und legt ihr den Nachweis der Registrierung dieses Drittlandbetreibers im Bereich Weltraum oder der betreffenden internationalen Organisation im URSO vor.

<a id="art-7"></a>
### Artikel 7 – Genehmigungsverfahren

(1) Ein Antragsteller beantragt die Genehmigung bei der in Artikel 6 Absatz 3 genannten zuständigen Behörde.

(2) Der Antrag auf Genehmigung enthält ein technisches Dossier mit allen erforderlichen Unterlagen und Belegen zum Nachweis der Einhaltung der Anforderungen gemäß Titel IV Kapitel I bis V, sofern anwendbar.

(3) In seinem Antrag auf Genehmigung gibt der Antragsteller der zuständigen Behörde an, welche qualifizierten technischen Stellen für Weltraumtätigkeiten der Antragsteller für die technische Bewertung der Anforderungen gemäß Titel IV Kapitel I bis V zu nutzen beabsichtigt.

(4) Die Mitgliedstaaten legen Verfahren fest, die es den zuständigen Behörden ermöglichen, die technischen Unterlagen an die vom Antragsteller angegebenen qualifizierten technischen Stellen für Weltraumtätigkeiten zu übermitteln, oder es dem Antragsteller zu ermöglichen, sich direkt an die qualifizierten technischen Stellen für Weltraumtätigkeiten zu wenden.

(5) Eine qualifizierte technische Stelle für Weltraumtätigkeiten bewertet, ob die in Titel IV Kapitel I bis V festgelegten Anforderungen erfüllt sind, und gibt innerhalb von sechs Monaten nach Eingang der technischen Unterlagen eine Stellungnahme dazu ab, ob die geplanten Weltraumtätigkeiten die Anforderungen gemäß Titel IV Kapitel I bis V erfüllen.

    Die zuständigen Behörden tragen der technischen Bewertung, die von den qualifizierten technischen Stellen für Weltraumtätigkeiten gemäß Artikel 8 Absatz 2 Unterabsatz 3 in Bezug auf Titel IV Kapitel II durchgeführt wurde, weitestgehend Rechnung.

(6) Innerhalb von zwölf Monaten nach Eingang des Antrags erteilt die zuständige Behörde die Genehmigung oder lehnt den Antrag ab und setzt den Antragsteller entsprechend in Kenntnis.

    Die Frist wird ausgesetzt, bis der Antragsteller auf Anfrage der zuständigen Behörde die vollständigen Informationen vorgelegt hat.

(7) Für die Zwecke der Registrierung im URSO unterrichten die zuständigen Behörden die Agentur über alle zugelassenen Unionsbetreiber im Bereich Weltraum und Primäranbieter von Weltraumdiensten der Union sowie über alle Drittlandsbetreiber im Bereich Weltraum, denen die Durchführung von Starts von ihrem Hoheitsgebiet aus genehmigt wurde.

<a id="art-8"></a>
### Artikel 8 – Technische Bewertungen

(1) Im Zuge der Einrichtung der Genehmigungssysteme legen die Mitgliedstaaten fest, von welchen der folgenden Stellen die technischen Bewertungen durchgeführt werden:

  - a) qualifizierte technische Stellen für Weltraumtätigkeiten;

  - b) internationale Organisationen mit spezifischem technischem Fachwissen in den unter diese Verordnung fallenden Angelegenheiten;

  - c) der Agentur;

  - d) einer Kombination der unter den Buchstaben a, b und c genannten Optionen.

(2) Mitgliedstaaten, die beabsichtigen, das in Absatz 1 Buchstabe a genannte System zu nutzen, stellen sicher, dass in ihrem Hoheitsgebiet qualifizierte technische Stellen für Weltraumtätigkeiten eingerichtet werden.

    Für die Durchführung technischer Bewertungen in Angelegenheiten, die unter Titel IV Kapitel I bis V fallen, nutzen die Mitgliedstaaten qualifizierte technische Stellen für Weltraumtätigkeiten, die in ihrem Hoheitsgebiet niedergelassen sind.

    Die Mitgliedstaaten stellen sicher, dass die gemäß Artikel 8 Absatz 1 der Richtlinie (EU) 2022/2555 eingerichtete zuständige Behörde für die Durchführung der technischen Bewertung in Angelegenheiten, die unter Titel IV Kapitel II fallen, in Bezug auf Unionsbetreiber im Bereich Weltraum zuständig ist, mit Ausnahme der Operation der in Artikel 5 Absatz 1 Nummer 20 genannten Ressourcen.

(3) Die in Absatz 1 Buchstabe b genannten Anbieter von Weltraumdiensten, die technische Bewertungstätigkeiten durchführen, erfüllen die in Titel III Kapitel I Abschnitt 3 festgelegten Anforderungen.

    Die Mitgliedstaaten, die das in Absatz 1 Buchstabe b genannte System nutzen, stellen die gerichtliche Durchsetzung der in Unterabsatz 1 genannten Verpflichtung sicher.

(4) Die Mitgliedstaaten teilen der Kommission ihre Wahl gemäß Absatz 1 und etwaige diesbezügliche Änderungen mit.

<a id="art-9"></a>
### Artikel 9 – Genehmigung von Konstellationen

(1) Beabsichtigt der Unionsbetreiber im Bereich Weltraum, eine Weltraummission durchzuführen, die den Start einer Satellitenkonstellation umfasst, so stellt er bei der zuständigen Behörde einen Antrag auf eine Einzelgenehmigung für den Start oder gegebenenfalls den Start und die Operation in Bezug auf alle Satelliten, die Teil der Konstellation sind, sofern alle folgenden Bedingungen erfüllt sind:

  - a) alle Satelliten, die im Rahmen der jeweiligen Weltraummission gestartet werden sollen, sind identisch und erfüllen dieselben Aufgaben in gleicher Form;

  - b) der Start aller Satelliten soll mit derselben Trägerrakete und vom selben Startplatz aus erfolgen.

    Der Unionsbetreiber im Bereich Weltraum stellt sicher, dass die Satelliten, die Teil der Konstellation sind, die Anforderungen gemäß Titel IV Kapitel I bis V erfüllen, und erklärt, dass die in Unterabsatz 1 festgelegten Bedingungen erfüllt sind.

(2) Bestätigt nach Eingang eines Antrags gemäß Absatz 1 Unterabsatz 1 die Bewertung der zuständigen Behörde in Bezug auf einen einzelnen Satelliten, der im Rahmen der jeweiligen Weltraummission gestartet werden soll, die Einhaltung der in Titel IV Kapitel I bis V festgelegten Anforderungen, so erteilt die zuständige Behörde eine Genehmigung für die gesamte Satellitenkonstellation (im Folgenden „Einzelgenehmigung“).

(3) Die zuständigen Behörden können ab dem Tag der Erteilung der Einzelgenehmigung Stichprobeninspektionen an allen Satelliten durchführen, die Teil der Konstellation sind, und nicht der Ex-ante-Kontrolle unterzogen wurden, auf die sich die Einzelgenehmigung stützt.

(4) Die zuständige Behörde entzieht die Einzelgenehmigung, wenn die Ergebnisse der Stichprobeninspektionen ergeben, dass der Satellit die Anforderungen für die Genehmigung nicht erfüllt.

(5) Werden bei den in Absatz 3 genannten Stichprobeninspektionen Aspekte festgestellt, die mit der in Absatz 1 Unterabsatz 2 genannten Erklärung in Widerspruch stehen, ohne dass festgestellt wird, dass keine Erfüllung vorliegt, und bestehen laut der Bewertung durch die zuständige Behörde unter Berücksichtigung der Erläuterungen des Unionsbetreibers im Bereich Weltraum keine größeren Risiken für die jeweilige Weltraummission, kann die zuständige Behörde eine Strafe verhängen.

(6) Die zuständigen Behörden überprüfen die Genehmigungen für den Start von Satellitenkonstellationen beim Start der ersten Exemplare der neuen Satellitengeneration.

<a id="art-10"></a>
### Artikel 10 – Vereinfachte Regeln

(1) Die Bedingungen für die Genehmigung gemäß Artikel 6 Absatz 1 werden für die in den Absätzen 2, 3 und 4 genannten Unionsbetreiber im Bereich Weltraum gemäß diesen Absätzen angepasst.

(2) Betreiber im Bereich Weltraum, bei denen es sich um Forschungs- oder Bildungseinrichtungen handelt oder die Forschungsmissionen im Weltraum durchführen, müssen die Anforderungen des Titels IV Kapitel I Abschnitt 2 wie in Artikel 62 dargelegt erfüllen.

(3) Stellen, die ein vereinfachtes Risikomanagement anwenden, haben in Bezug auf Titel IV Kapitel II die Bestimmungen des Artikels 79 Absatz 1 Unterabsatz 1 nur in Bezug auf kritische Ressourcen und kritische Funktionen einzuhalten.

(4) Betreiber im Bereich Weltraum, bei denen es sich um kleine Unternehmen oder Forschungs- oder Bildungseinrichtungen handelt, die Weltraummissionen zur In-Orbit-Demonstration- und -Validierung (IOD/IOV) durchführen, sind in Bezug auf Titel IV Kapitel III von der Verpflichtung gemäß Artikel 96 Absatz 2 ausgenommen.

<a id="title-ii-chapter-ii"></a>
## Kapitel II – GENEHMIGUNG FÜR UNIONSBETREIBER IM BEREICH WELTRAUM, DIE UNIONSEIGENE RESSOURCEN BETREIBEN

<a id="art-11"></a>
### Artikel 11 – Antrag auf Genehmigung

(1) Werden Weltraumtätigkeiten im Zusammenhang mit unionseigenen Ressourcen durchgeführt, so genehmigt die Kommission die mit der Ausführung oder der Operation der jeweiligen Komponente des Unionsprogramms betraute Stelle.

    Die in Unterabsatz 1 genannte Genehmigung stützt sich auf eine technische Bewertung, die die Agentur in Bezug auf die Erfüllung der in Titel IV Kapitel I, II, III, IV und V festgelegten Anforderungen durch den Antragsteller durchführt.

(2) Je nach der spezifischen Lenkung der Komponente des Unionsprogramms übermittelt die antragstellende Stelle der Agentur und der Kommission alle technischen Einzelheiten und Erläuterungen, die die Einhaltung der in Titel IV Kapitel I, II, III, IV und V festgelegten Anforderungen belegen.

(3) Die Agentur prüft binnen 30 Arbeitstagen nach Eingang des Antrags der Stelle auf Genehmigung, ob der Antrag vollständig ist.

    Ist ein Antrag auf Genehmigung unvollständig oder ist eine weitere Klarstellung erforderlich, setzt die Agentur eine Frist, innerhalb derer die antragstellende Stelle erforderlichenfalls zusätzliche Informationen vorlegen oder Klarstellungen vornehmen muss.

    Nachdem die Agentur den Antrag für vollständig befunden hat, teilt sie dies dem Antragsteller mit.

<a id="art-12"></a>
### Artikel 12 – Prüfung durch die Agentur

(1) Innerhalb von sechs Monaten nach der in Artikel 11 Absatz 3 Unterabsatz 3 genannten Mitteilung prüft die Agentur gemäß Artikel 43 Absatz 1 Buchstabe a den Antrag auf Genehmigung, indem sie prüft, ob der Antragsteller

  - a) über die erforderliche Zuverlässigkeit, Fähigkeit und das Fachwissen verfügt, um Weltraumtätigkeiten durchzuführen;

  - b) die Einhaltung der in dieser Verordnung festgelegten Anforderungen und gegebenenfalls der spezifischen Anforderungen, die für die Durchführung der Weltraummission im Zusammenhang mit dem Weltraumprogramm gemäß der Verordnung (EU) 2021/696 oder der Verordnung (EU) 2023/588 erforderlich sind, für die ein Genehmigungsantrag gestellt wird, sicherstellt;

  - c) keine Gefahr für die öffentliche Ordnung, die Sicherheit von Personen und Eigentum und die öffentliche Gesundheit in der Union darstellt.

    Die Agentur fällt auf Grundlage der gemäß Artikel 43 Absatz 1 Buchstabe a durchgeführten technischen Bewertung eine ausführlich begründete Entscheidung, in der der Kommission vorgeschlagen wird, eine Genehmigung zu erteilen oder zu verweigern.

    Die Agentur teilt der Kommission ihre Entscheidung unverzüglich mit.

(2) Innerhalb von 30 Arbeitstagen nach Eingang der in Absatz 1 Unterabsatz 2 genannten Entscheidung der Agentur erlässt die Kommission einen Beschluss über die Erteilung oder die Verweigerung der Genehmigung und informiert den Antragsteller unverzüglich. Der Beschluss wird mit seiner Mitteilung an den Antragsteller wirksam.

    Die Kommission erteilt nur dann eine Genehmigung, wenn der Antragsteller die in Absatz 1 Unterabsatz 1 genannten Anforderungen erfüllt.

(3) Die Agentur registriert die gemäß diesem Kapitel zugelassenen Unionsbetreiber im Bereich Weltraum unverzüglich im URSO.

<a id="art-13"></a>
### Artikel 13 – Aussetzung oder Rücknahme der Genehmigung

(1) Ein Unionsbetreiber im Bereich Weltraum, der unionseigene Ressourcen betreibt, meldet der Agentur unverzüglich Folgendes:

  - a) jedes unvorhergesehene Ereignis, das eine Änderung seiner Genehmigung erforderlich machen könnte;

  - b) jede geplante oder unmittelbar bevorstehende Beendigung seiner Tätigkeit.

(2) Die Agentur schlägt der Kommission vor, die Genehmigung gegebenenfalls auszusetzen oder zurückzunehmen, wenn ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen,

  - a) die Genehmigung aufgrund falscher Erklärungen oder auf sonstige rechtswidrige Weise erhalten hat;

  - b) die Bedingungen, unter denen die Genehmigung erteilt wurde, nicht länger erfüllt und die von der Kommission geforderten Abhilfemaßnahmen nicht ergriffen hat.

(3) Spätestens zwei Monate nach Eingang des in Absatz 2 Unterabsatz 1 genannten Vorschlags der Agentur entscheidet die Kommission über die vorgeschlagene Aussetzung oder Rücknahme.

    Die Kommission teilt ihre Entscheidung unverzüglich dem betreffenden Unionsbetreiber im Bereich Weltraum, der unionseigene Ressourcen betreibt, und der zuständigen Behörde des Mitgliedstaats mit, in dem dieser Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen niedergelassen ist.

<a id="title-ii-chapter-iii"></a>
## Kapitel III – ANBIETER VON WELTRAUMDIENSTEN AUS DRITTLÄNDERN UND INTERNATIONALE ORGANISATIONEN

<a id="art-14"></a>
### Artikel 14 – Bereitstellung von weltraumgestützten Daten und Weltraumdiensten durch Drittlandsbetreiber im Bereich Weltraum und internationale Organisationen

(1) Drittlandsbetreiber im Bereich Weltraum, die gemäß Artikel 17 im Unionsregister der Weltraumobjekte registriert sind und im Besitz des in Artikel 25 Absatz 1 genannten elektronischen Zertifikats sind, dürfen Weltraumdienste für Unionsbetreiber im Bereich Weltraum und in Bezug auf unionseigene Ressourcen und auf die in Artikel 5 Absatz 1 Ziffer 21 genannten Ressourcen erbringen.

(2) Damit internationale Organisationen aufgrund ihrer Verträge weltraumgestützte Daten bzw. Weltraumdienste in der Union bereitstellen können, müssen die in den Artikeln 107 bzw. 108 genannten Abkommen bestehen.

    Internationale Organisationen, die weltraumgestützte Daten oder Weltraumdienste in der Union gemäß Unterabsatz 1 erbringen, werden im URSO registriert und befinden sich im Besitz des in Artikel 25 Absatz 1 genannten elektronischen Zertifikats.

(3) Absatz 2 gilt nicht, wenn eine internationale Organisation nur technische Bewertungstätigkeiten gemäß Artikel 8 Absatz 1 Buchstabe b durchführt.

<a id="art-15"></a>
### Artikel 15 – Vorschriften für Drittlandsbetreiber im Bereich Weltraum

(1) Raumfahrzeugbetreiber aus Drittländern unterliegen den in den Artikeln 62, 66, 67, 69 bis 73, 75 bis 92 und 96 bis 100 festgelegten geltenden Anforderungen für Raumfahrzeugbetreiber aus der Union.

    Darüber hinaus müssen Raumfahrzeugbetreiber aus Drittländern

  - a) einen öffentlichen oder kommerziellen Anbieter von Weltraumdiensten zur Kollisionsvermeidung in Anspruch nehmen;

  - b) sicherstellen, dass der in Buchstabe a genannte Anbieter von Weltraumdiensten zur Kollisionsvermeidung über die technischen Mittel zur Bewertung der Kollisionsvermeidung verfügt und die Anforderungen in Anhang IV Nummer 1 erfüllt;

  - c) der Agentur in dem Antrag auf Registrierung im URSO den Namen und die Kontaktdaten des unter Buchstabe a genannten Anbieters von Weltraumdiensten zur Kollisionsvermeidung mitteilen.

      Die Agentur nimmt die in Buchstabe c genannten Informationen in die in Artikel 67 Absatz 1 genannte Kontaktlistendatenbank der Union auf.

(2) Startbetreiber aus Drittländern und Betreiber von Startplätzen aus Drittländern unterliegen den Anforderungen, die aufgrund der Artikel 61, 75 bis 92 und 96 bis 100 für Startbetreiber und Betreiber von Startplätzen aus der Union gelten.

(3) ISOS-Anbieter aus Drittländern unterliegen den Anforderungen, die gemäß Artikel 101 für ISOS-Anbieter aus der Union gelten.

(4) Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus Drittländern unterliegen den Anforderungen, die aufgrund der Artikel 102 und 103 für Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus der Union gelten.

<a id="art-16"></a>
### Artikel 16 – Vorschriften für Drittlandsbetreiber im Bereich Weltraum aus gleichwertigen Rechtsordnungen

Bei Drittlandsbetreibern im Bereich Weltraum, die in einem Drittland niedergelassen sind, für das die Kommission einen Gleichwertigkeitsbeschluss gemäß Artikel 105 erlassen hat, wird davon ausgegangen, dass sie die Anforderungen des Artikels 15 erfüllen.

<a id="art-17"></a>
### Artikel 17 – Registrierung von Anbietern von Weltraumdiensten aus Drittländern

(1) Auf der Grundlage einer Entscheidung der Kommission, die Registrierung gemäß Absatz 5 zu gestatten, registriert die Agentur Drittlandsbetreiber im Bereich Weltraum, welche die Einhaltung der Anforderungen des Titels IV gemäß Artikel 16 oder Artikel 15 nachweisen, im URSO.

(2) Wurde eine Ausnahme gemäß Artikel 19 gewährt, werden Startbetreiber aus Drittländern auf der Grundlage eines Beschlusses der Kommission im URSO registriert, obwohl sie nicht sämtliche der in Artikel 15 genannten Bedingungen erfüllen.

    Hat ein Mitgliedstaat eine Ausnahmeregelung beantragt, um einem Unionsbetreiber im Bereich Weltraum zu ermöglichen, mit einem Drittlandsbetreiber im Bereich Weltraum zu starten, so legt dieser Drittlandsbetreiber im Bereich Weltraum der Agentur Nachweise für diesen Antrag vor.

(3) Um eine Registrierung im URSO gemäß Absatz 1 zu erhalten, muss ein Drittlandsbetreiber im Bereich Weltraum bei der Agentur einen Antrag stellen. Der Antrag muss alle Nachweise enthalten, die für den Nachweis der Konformität gemäß Absatz 1 erforderlich sind.

    Die Agentur bewahrt alle von den Antragstellern im Registrierungsverfahren vorgelegten Nachweise auf.

(4) Die Agentur prüft den Antrag auf Registrierung und unterrichtet den Drittlandsbetreiber im Bereich Weltraum über das Ergebnis ihrer vorläufigen Beurteilung. Die Agentur gestattet dem Drittlandsbetreiber im Bereich Weltraum, eine begründete Erklärung abzugeben und zusätzliche Erklärungen oder Nachweise vorzulegen.

(5) Spätestens fünf Monate nach Eingang des Antrags gemäß Absatz 3 Unterabsatz 1 unterbreitet die Agentur der Kommission einen Vorschlag für eine Entscheidung über die Genehmigung oder Ablehnung der Registrierung eines Drittlandsbetreibers im Bereich Weltraum im URSO.

(6) Die Kommission trifft eine Entscheidung auf der Grundlage des in Absatz 5 genannten Vorschlags der Agentur und teilt diese Entscheidung dem Drittlandsbetreiber im Bereich Weltraum und der Agentur mit.

(7) Findet Artikel 16 Anwendung, so registriert die Agentur auf folgender Grundlage:

  - a) Der Drittlandsbetreiber im Bereich Weltraum ist in einem Drittland zugelassen und unterliegt in einem Drittland einer laufenden Aufsicht;

  - b) die Kommission hat einen Gleichwertigkeitsbeschluss gemäß Artikel 105 erlassen.

(8) Wurde ein Antrag auf Ausnahme gemäß Artikel 19 gestellt, so registriert die Agentur den Drittlandsbetreiber im Bereich Weltraum im URSO, nachdem die Kommission ihren Beschluss gemäß Artikel 19 Absatz 5 Unterabsatz 1 gefasst hat.

<a id="art-18"></a>
### Artikel 18 – Registrierung internationaler Organisationen

(1) Sind die Bedingungen der Artikel 107 oder 108 erfüllt, so registriert die Agentur internationale Organisationen im URSO.

(2) Für die Zwecke des Absatzes 1 gelten Artikel 17 Absätze 3, 4, 5, 7 und 8 sowie die Artikel 19, 21 und 22 entsprechend.

<a id="art-19"></a>
### Artikel 19 – Ausnahmen

(1) Ein Mitgliedstaat kann die Kommission ersuchen, einen Beschluss zu erlassen, der es der Agentur gestattet, einen Startbetreiber aus einem Drittland, der eine oder mehrere der in Artikel 15 Absatz 2 genannten Bedingungen nicht erfüllt, registrieren zu lassen, wenn die in Absatz 2 genannten Bedingungen eines öffentlichen Interesses erfüllt sind.

    Ein Mitgliedstaat stellt einen Antrag gemäß Absatz 3 Unterabsatz 1.

    Bei unionseigenen Ressourcen bewertet die Kommission von sich aus, ob die in Absatz 2 genannte Bedingung eines öffentlichen Interesses erfüllt ist.

(2) In Bezug auf Startdienste weist ein Mitgliedstaat nach, dass die von einem Startbetreiber aus einem Drittland erbrachten Startdienste den Zugang zum Weltraum und dessen Nutzung erleichtern, wenn die folgenden kumulativen Bedingungen erfüllt sind:

  - a) Es gibt in der Union keine ohne Weiteres verfügbare Ersatzlösung oder realistische Alternative zu den Startdiensten des jeweiligen Startbetreibers aus einem Drittland;

  - b) die von dem jeweiligen Startbetreiber aus einem Drittland bereitgestellten Startdienste fördern die technologischen Fähigkeiten, die für die Union oder die Mitgliedstaaten von strategischer Bedeutung sind.

(3) Der Antrag nach Absatz 1 Unterabsatz 2 muss Folgendes enthalten:

  - a) Die Nennung des Startbetreibers aus dem Drittland, für den eine Ausnahme beantragt wird;

  - b) die klare, eindeutige und erschöpfende Angabe aller in Artikel 15 Absatz 2 genannten Anforderungen, für die eine Ausnahme beantragt wird;

  - c) die Darlegung der erforderlichen technischen Einzelheiten in Bezug auf die betreffende Weltraummission;

  - d) die Erbringung der erforderlichen Nachweise dafür, dass die übrigen Anforderungen erfüllt sind.

    In dem Antrag in Bezug auf einen Startbetreiber aus einem Drittland werden, soweit möglich, alternative Risikominderungsmaßnahmen vorgeschlagen, um sicherzustellen, dass die mit den Anforderungen gemäß Artikel 15 Absatz 2 verfolgten Ziele, für die eine Ausnahme beantragt wird, erreicht oder zumindest teilweise erreicht werden.

(4) Nach Eingang des Antrags gemäß Absatz 3 leitet die Kommission ihn an die Agentur weiter. Innerhalb eines Monats nimmt die Agentur eine technische Bewertung der Einhaltung der Anforderungen des Artikels 15 vor, für die keine Ausnahme beantragt wird.

(5) Innerhalb von zwei Monaten nach Eingang der von der Agentur gemäß Absatz 4 vorgenommenen technischen Bewertung fällt die Kommission auf der Grundlage dieser technischen Bewertung entweder eine Entscheidung über die Gewährung einer Ausnahme für den betreffenden Startbetreiber aus einem Drittland, wenn sie zu dem Schluss kommt, dass die in Absatz 2 genannte Bedingung eines öffentlichen Interesses erfüllt ist, oder die Entscheidung, die Gewährung einer solchen Ausnahme zu verweigern, wenn sie zu dem Schluss kommt, dass diese Bedingung eines öffentlichen Interesses nicht erfüllt ist.

    Diese Entscheidungen werden nach dem in Artikel 114 Absatz 2 genannten Prüfverfahren als Durchführungsrechtsakte erlassen.

(6) Gewährt die Kommission einem Startbetreiber aus einem Drittland gemäß Absatz 5 Unterabsatz 1 eine Ausnahme, so gewährt sie zugleich dem Unionsbetreiber im Bereich Weltraum, der die Startdienste des betreffenden Startbetreibers aus einem Drittland nutzt, eine Ausnahme.

<a id="art-20"></a>
### Artikel 20 – Öffentliche Einrichtungen aus Drittländern

(1) Auf Antrag einer öffentlichen Einrichtung eines Drittlands, der die Bereitstellung von Weltraumdiensten oder weltraumgestützten Daten in der Union gestattet wird, oder auf Antrag eines Mitgliedstaats gemäß Absatz 2 bewertet die Kommission mit Unterstützung der Agentur zunächst, ob es sich bei dieser öffentlichen Einrichtung aus einem Drittland um eine staatliche Einrichtung handelt oder ob sie Ressourcen von Weltrauminfrastrukturen betreibt oder besitzt, bei denen es sich um militärische Systeme mit eventueller ziviler Nutzung handelt.

    Im Rahmen ihrer technischen Unterstützung für die Kommission erfasst die Agentur alle einschlägigen Tätigkeiten und Dienste, die von dieser öffentlichen Einrichtung aus einem Drittland erbracht werden, und ermittelt alle relevanten Ressourcen der Weltrauminfrastruktur, die diese öffentliche Einrichtung aus einem Drittland betreibt oder besitzt.

(2) Ein Mitgliedstaat kann die Kommission ersuchen, einer öffentlichen Einrichtung eines Drittlands die Bereitstellung von Weltraumdiensten oder weltraumgestützten Daten für die Union zu gestatten.

    Zur Stützung seines Antrags kann ein Mitgliedstaat ein öffentliches Interesse von einem oder mehreren Mitgliedstaaten an der Erlangung oder gegebenenfalls an der Sicherung eines kontinuierlichen und ungehinderten Zugangs zu den jeweiligen weltraumgestützten Daten oder Weltraumdiensten anführen, die von dieser öffentlichen Einrichtung des Drittlands bereitgestellt werden, und die Folgen des Verlusts eines solchen Zugangs auf Ebene der Union oder der Mitgliedstaaten für die relevanten Märkte nachweisen.

(3) Die Kommission kann von sich aus die Bewertung gemäß Absatz 1 vornehmen.

(4) Kommt die Kommission nach der Bewertung gemäß Absatz 1 zu dem Schluss, dass keine Sicherheitsrisiken für die Union oder die Mitgliedstaaten bestehen, kann sie eine Entscheidung fällen, dergemäß die betreffende öffentliche Einrichtung des Drittlands Weltraumdienste oder weltraumgestützte Daten in der Union bereitzustellen darf.

    Die in Unterabsatz 1 genannte Entscheidung gilt bis zu dem Tag, an dem eine mit dem betreffenden Drittland geschlossene internationale Übereinkunft wirksam wird, in der die Bedingungen für die Bereitstellung von Weltraumdiensten oder weltraumgestützten Daten durch eine öffentliche Einrichtung eines Drittlands in der Union geregelt werden, oder bis zu dem Tag, an dem die Kommission in Bezug auf dieses Drittland eine Entscheidung über die Gleichwertigkeit gefällt hat, je nachdem, welcher Zeitpunkt früher liegt.

    Die Agentur registriert die betreffende öffentliche Einrichtung des Drittlands auf der Grundlage der Entscheidung der Kommission gemäß Unterabsatz 1 unverzüglich im URSO.

    Die in Unterabsatz 1 genannte Entscheidung wird gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren als Durchführungsrechtsakt erlassen.

<a id="art-21"></a>
### Artikel 21 – Notfallklausel

(1) Tritt in einem Mitgliedstaat ein Notfall oder eine Krise ein oder führt ein Sicherheitsvorfall oder ein Angriff zu Störungen, die weitere Mitgliedstaaten oder Organe der Union betreffen, so nimmt die Kommission so bald wie möglich von sich aus oder auf Ersuchen des betreffenden Mitgliedstaats eine Bewertung vor.

    Auf der Grundlage dieser Bewertung kann die Kommission nach dem in Artikel 114 Absatz 2 genannten Prüfverfahren die Nutzung weltraumgestützter Daten oder Weltraumdienste durch Anbieter von Weltraumdiensten, die nicht im URSO registriert sind, gestatten.

(2) Die in Absatz 1 genannte Entscheidung wird nach dem in Artikel 8 von Verordnung (EU) Nr. 182/2011 genannten Verfahren so bald wie möglich und je nach Schwere, Dauer und Auswirkungen des jeweiligen Notfalls, der Krise oder der Störung bestätigt, widerrufen oder verlängert.

<a id="art-22"></a>
### Artikel 22 – Aussetzung oder Rücknahme der Registrierung

(1) Die Agentur unterbreitet der Kommission den Vorschlag, die Registrierung eines Drittlandsbetreibers im Bereich Weltraum im URSO auszusetzen oder zurückzunehmen, wenn

  - a) die Agentur auf der Grundlage dokumentierter Nachweise feststellt, dass der Drittlandsbetreiber im Bereich Weltraum eine oder mehrere der in Artikel 16 bzw. Artikel 15 festgelegten Anforderungen nicht mehr erfüllt und nicht in der Lage ist, die erforderlichen Abhilfemaßnahmen anzuwenden, um deren kontinuierliche Einhaltung sicherzustellen;

  - b) die zuständige Aufsichtsbehörde des Drittlandes die dem betreffenden Anbieter von Weltraumdiensten erteilte Betriebs- oder Startgenehmigung ausgesetzt oder zurückgenommen hat.

(2) Bevor die Agentur der Kommission aus den in Absatz 1 Buchstabe a genannten Gründen einen Vorschlag zur Aussetzung oder Rücknahme der Registrierung vorlegt, führt sie einen Dialog mit dem betreffenden Drittlandsbetreiber im Bereich Weltraum über die Gründe, den Kontext, den Umfang und die Schwere der Nichteinhaltung sowie über die Abhilfemaßnahmen und Fristen, die dieser Drittlandsbetreiber im Bereich Weltraum benötigt, um die Einhaltung sicherzustellen, wobei etwaige technische Anpassungen gebührend zu berücksichtigen sind.

    Während dieses Dialogs bietet die Agentur dem betreffenden Drittlandsbetreiber im Bereich Weltraum die Gelegenheit, zu den Gründen, aus denen die Agentur ihren Vorschlag anzunehmen beabsichtigt, Stellung zu nehmen, Erklärungen abzugeben und alle sachdienlichen Unterlagen und Nachweise zur Untermauerung ihrer Erklärungen, einschließlich technischer Analysen, vorzulegen und die Einhaltung der Vorschriften zu erreichen.

(3) Spätestens zwei Monate nach Eingang des in Absatz 1 Unterabsatz 1 genannten Vorschlags fällt die Kommission eine Entscheidung.

(4) In dem in Absatz 1 Buchstabe b genannten Fall unterrichtet die Kommission die betreffende Aufsichtsbehörde des Drittlands mindestens 30 Tage vor Erlass einer Aussetzungs- oder Rücknahmeentscheidung über ihre Absicht, die Registrierung im URSO auszusetzen oder zurückzunehmen.

(5) Die Kommission unterrichtet die zuständigen Behörden unverzüglich über jede gemäß den Absätzen 2 und 4 zu erlassende Maßnahme.

    Die Agentur veröffentlicht eine Zusammenfassung der Informationen über eine Aussetzung oder Rücknahme auf ihrer Website und auf dem URSO-Portal.

(6) Die Entscheidung der Kommission über die Aussetzung oder Rücknahme der Registrierung im URSO wird zu dem Zeitpunkt wirksam, der in der Entscheidung der Kommission festgelegt wird. Bei der Festlegung dieses Zeitpunkts berücksichtigt die Kommission auf Vorschlag der Agentur die Zeit, die für die Anpassung der relevanten Verträge erforderlich sein kann.

    Je nach der Komplexität der gegebenenfalls erforderlichen vertraglichen Anpassungen liegt der Zeitpunkt der Rücknahme der Registrierung nicht mehr als 16 Monate nach dem Tag der Annahme der Entscheidung über die Rücknahme.

<a id="art-23"></a>
### Artikel 23 – Gesetzlicher Vertreter in der Union

(1) Drittlandsbetreiber im Bereich Weltraum benennen schriftlich eine oder mehrere juristische Person(en) in einem der Mitgliedstaaten, die als ihr gesetzlicher Vertreter in der Union auftritt/auftreten.

(2) Der gesetzliche Vertreter in der Union wird vom Drittlandsbetreiber im Bereich Weltraum ermächtigt, zusätzlich zu oder anstelle des Drittlandsbetreibers im Bereich Weltraum von den zuständigen Behörden, der Kommission und der Agentur in allen Fragen im Zusammenhang mit der Einhaltung dieser Verordnung angesprochen zu werden. Er verfügt über alle erforderlichen Befugnisse und Ressourcen, um eine effiziente und rechtzeitige Zusammenarbeit mit diesen Behörden zu gewährleisten.

<a id="title-ii-chapter-iv"></a>
## Kapitel IV – BEREITSTELLUNG VON WELTRAUMGESTÜTZTEN DATEN UND WELTRAUMDIENSTEN IN DER UNION UND ELEKTRONISCHE RÜCKVERFOLGBARKEIT

<a id="art-24"></a>
### Artikel 24 – Unionsregister der Weltraumobjekte (URSO)

(1) Die Agentur richtet ein Unionsregister der Weltraumobjekte (URSO) ein, in dem Folgendes registriert wird:

  - a) Unionsbetreiber im Bereich Weltraum, die gemäß Artikel 6 Absatz 1 zugelassen und der Agentur von den zuständigen Behörden gemäß Artikel 7 Absatz 7 gemeldet wurden;

  - b) Unionsbetreiber im Bereich Weltraum, bei denen es sich um Einrichtungen handelt, die mit der Durchführung oder dem Betrieb einer Komponente des Unionsprogramms betraut sind, auf der Grundlage einer der Kommission gemäß Artikel 12 Absatz 2 erteilten Genehmigung;

  - c) Drittlandsbetreiber im Bereich Weltraum, für die eine Entscheidung über die Registrierung gemäß Artikel 17 Absatz 1 erlassen wurde;

  - d) internationale Organisationen, die gemäß Artikel 18 Absatz 1 registriert sind.

(2) Die Agentur erstellt, aktualisiert und veröffentlicht die konsolidierten Listen aller in Absatz 1 genannten Anbieter von Weltraumdiensten auf der URSO-Website.

(3) URSO verfügt über ein zentrales Inventar und eine zentrale Plattform.

<a id="art-25"></a>
### Artikel 25 – Elektronisches Zertifikat (e-Zertifikat)

(1) Nach Abschluss der Registrierung im URSO stellt die Agentur den Anbietern von Weltraumdiensten mit Ausnahme der Anbieter von <Weltraumdiensten zur Kollisionsvermeidung ein elektronisches Zertifikat (im Folgenden „e-Zertifikat“) aus und händigt ihnen dieses aus.

(2) In dem in Absatz 1 genannten e-Zertifikat müssen die Weltraummission(en) und das (die) Weltraumobjekt(e) angegeben werden, welche die weltraumgestützten Daten generiert oder die Bereitstellung von Weltraumdiensten ermöglicht haben, und es muss die Konformität jener Weltraumobjekte mit den Anforderungen dieser Verordnung bescheinigt werden.

(3) Verträgen von Anbietern von Weltraumdiensten gemäß Artikel 2 Absatz 1 Buchstaben a, c und d über die Bereitstellung weltraumgestützter Daten und Weltraumdienste in der Union ist das in Absatz 1 genannte e-Zertifikat beizufügen.

(4) Die folgenden Informationen werden von den zuständigen Behörden in Bezug auf Unionsbetreiber im Bereich Weltraum gemäß Artikel 7 Absatz 7 und direkt von Drittlandsbetreibern im Bereich Weltraum und internationalen Organisationen übermittelt, damit die Agentur das in Absatz 1 genannte e-Zertifikat ausstellen und generieren kann:

  - a) Einzelheiten zu dem betreffenden Anbieter von Weltraumdiensten, wie Name, physische Anschrift, Internetadresse, Mitgliedstaat oder gegebenenfalls Drittland der Niederlassung und Genehmigung, Name und Anschrift der zuständigen Behörde oder gegebenenfalls der zuständigen Aufsichtsbehörde des Drittlands;

  - b) Einzelheiten zur Art der erbrachten Weltraumdienste unter Angabe des Mitgliedstaats/der Mitgliedstaaten oder der Drittländer, in denen diese erbracht werden;

  - c) technische Einzelheiten zu dem Weltraumobjekt, das betrieben oder gestartet wird, und der jeweiligen Weltraummission.

(5) Für die Zwecke der Normungsanfrage gemäß Artikel 104 muss das in Absatz 1 genannte e-Zertifikat folgende Anforderungen erfüllen:

  - a) Mit dem e-Zertifikat wird festgestellt, dass bestimmte weltraumgestützte Daten durch die Nutzung einer klar definierten Weltraummission und eines klar definierten Weltraumobjekts erzeugt werden;

  - b) bei Beobachtungsdaten muss das e-Zertifikat die Verfolgung des Flusses weltraumgestützter Daten von der Generierung durch ein bestimmtes Weltraumobjekt bis zur Integration in den ersten Weltraumdienst unter Nutzung dieser weltraumgestützten Daten ermöglichen;

  - c) das e-Zertifikat muss auf Algorithmen beruhen, um die Integrität weltraumgestützter Daten bei der Aufnahme in nachfolgende Dienste sicherzustellen.

(6) Für die Zwecke der Ausstellung des in Absatz 1 genannten e-Zertifikats kann die Agentur gegebenenfalls technische Unterstützung von den zuständigen Behörden und den qualifizierten technischen Stellen für Weltraumtätigkeiten in Bezug auf die in Absatz 5 genannten Elemente anfordern.

<a id="art-26"></a>
### Artikel 26 – Bereitstellung von Weltraumdiensten und weltraumgestützten Daten in der Union

(1) Stellen Anbieter von Weltraumdiensten, mit Ausnahme von Anbietern von Weltraumdiensten zur Kollisionsvermeidung, erstmals weltraumgestützte Daten oder Weltraumdienste in der Union bereit, so müssen sie im Besitz des in Artikel 25 Absatz 1 genannten e-Zertifikats sein.

(2) Sie stellen sicher, dass das e-Zertifikat ihren Verträgen über die Bereitstellung weltraumgestützter Daten oder Weltraumdienste beigefügt ist.

<a id="art-27"></a>
### Artikel 27 – Anforderungen an Primäranbieter weltraumgestützter Daten

(1) Primäranbieter weltraumgestützter Daten stellen weltraumgestützte Daten in der Union nur bereit, wenn diese weltraumgestützten Daten von Weltraumobjekten erzeugt wurden, die im URSO registriert sind.

(2) Erhalten Primäranbieter weltraumgestützter Daten Alarmmeldungen oder Beschwerden über mögliche Unregelmäßigkeiten, alarmieren sie ihre Lieferanten und setzen sich gleichzeitig mit der Agentur oder der zuständigen Behörde des Mitgliedstaats, in dem sie niedergelassen sind, in Verbindung.

<a id="title-iii"></a>
## Titel III – GOVERNANCE-ASPEKTE

<a id="title-iii-chapter-i"></a>
## Kapitel I – GOVERNANCE IN DEN MITGLIEDSTAATEN

<a id="title-iii-chapter-i-section-1"></a>
## Abschnitt 1 – ZUSTÄNDIGE BEHÖRDEN

<a id="art-28"></a>
### Artikel 28 – Benennung oder Einrichtung zuständiger Behörden

(1) Jeder Mitgliedstaat benennt oder richtet eine Behörde ein, die als zuständige Behörde für die Genehmigung und Beaufsichtigung von Unionsbetreibern im Bereich Weltraum und für alle Marktüberwachungstätigkeiten zuständig ist, die erforderlich sind, um die Nutzung weltraumgestützter Daten im Einklang mit dieser Verordnung sicherzustellen.

(2) Die Mitgliedstaaten gewährleisten, dass die zuständigen Behörden über die Unabhängigkeit, das Fachwissen, die finanziellen und personellen Ressourcen, die operativen Kapazitäten und die Befugnisse verfügen, die für die Wahrnehmung der in Absatz 1 genannten Funktionen erforderlich sind.

<a id="art-29"></a>
### Artikel 29 – Aufsichtsaufgaben in Bezug auf Unionsbetreiber im Bereich Weltraum

(1) Die zuständigen Behörden beaufsichtigen die Weltraumtätigkeiten der Unionsbetreiber im Bereich Weltraum, wobei sie insbesondere

  - a) die Anwendung der in dieser Verordnung festgelegten Anforderungen kontrollieren;

  - b) Nachprüfungen ausführen;

  - c) interne Aufzeichnungen über Zuwiderhandlungen gegen die in dieser Verordnung festgelegten Anforderungen führen;

  - d) mit den zuständigen Behörden anderer Mitgliedstaaten zusammenarbeiten, um die Konsistenz bei der Anwendung dieser Verordnung in der gesamten Union zu gewährleisten;

  - e) das Bewusstsein und Verständnis für die in dieser Verordnung festgelegten Anforderungen fördern;

  - f) Audits durchführen;

  - g) eine qualifizierte technische Stelle für Weltraumtätigkeiten mit der Durchführung technischer Bewertungen gemäß Artikel 8 Absatz 1 Buchstabe a beauftragen;

  - h) im Rahmen von Aufsichtsaufgaben die Anwendung des Grundsatzes der Verhältnismäßigkeit durch die Unionsbetreiber im Bereich Weltraum überprüfen;

  - i) der Kommission über die wichtigsten Aufsichtstätigkeiten im Zusammenhang mit der Anwendung dieser Verordnung Bericht erstatten.

(2) Die Mitgliedstaaten sorgen für eine angemessene Beaufsichtigung der Unionsbetreiber im Bereich Weltraum, die nationale Weltraumprogramme durchführen, indem sie auf die Aufgabentrennung und das Nichtvorliegen von Interessenkonflikten achten.

<a id="art-30"></a>
### Artikel 30 – Aufsichtsbefugnisse

(1) Die zuständigen Behörden verfügen über alle Aufsichts-, Untersuchungs-, Abhilfe- und Sanktionsbefugnisse, die für die Wahrnehmung der in Artikel 29 genannten Funktionen und Aufgaben erforderlich sind.

(2) Bei der Durchführung von Aufsichtstätigkeiten in Bezug auf Titel IV Kapitel II sorgen die zuständigen Behörden für die Koordinierung mit den gemäß Artikel 8 Absatz 1 der Richtlinie 2022/2555 benannten zuständigen Behörden, die für die Aufsichtsaufgaben nach dieser Richtlinie zuständig sind.

    Die Mitgliedstaaten können die zuständigen Behörden ermächtigen, einschlägige Aufsichtstätigkeiten und -aufgaben in Bezug auf Titel IV Kapitel II dieser Verordnung an die gemäß Artikel 8 Absatz 1 der Richtlinie 2022/2555 eingerichteten zuständigen Behörden zu delegieren.

    Die in den Unterabsätzen 1 und 2 genannten Aufsichtsaufgaben gemäß der Richtlinie 2022/2555 werden unter vollständiger Wahrung der Integrität der in Absatz 1 genannten Aufsichtsbefugnisse ausgeübt.

(3) Die zuständigen Behörden verfügen mindestens über die folgenden Ermittlungsbefugnisse, die es ihnen gestatten,

  - a) die Vorlage aller erforderlichen Daten und Unterlagen zu verlangen;

  - b) Zugang zu Räumlichkeiten, Grundstücken und Transportmitteln, einschließlich aller Datenverarbeitungsanlagen und -mittel, zu erhalten;

  - c) Beweise der Umsetzung der in dieser Verordnung festgelegten Anforderungen und der zugrunde liegenden Nachweise zu verlangen;

  - d) die technischen Bewertungen, die von qualifizierten technischen Stellen für Weltraumtätigkeiten gemäß Artikel 8 durchgeführt werden, zu überprüfen;

  - e) innerhalb und außerhalb des Werksgeländes Inspektionen, einschließlich Audits, durchzuführen.

(4) Führen die zuständigen Behörden Inspektionen durch, so sind die zur Durchführung der Inspektionen befugten Bediensteten befugt,

  - a) alle Räumlichkeiten, Gelände und Transportmittel der jeweiligen Unionsbetreiber im Bereich Weltraum zu betreten;

  - b) die Bücher und sonstigen Geschäftsunterlagen zu prüfen, unabhängig davon, in welcher Form sie gespeichert sind, auf alle Informationen zuzugreifen, die den Unionsbetreibern im Bereich Weltraum, die Gegenstand der Inspektion sind, zugänglich sind, sowie Kopien oder Auszüge dieser Bücher oder Aufzeichnungen anzufordern;

  - c) alle Vertreter oder Bedienstete des von der Inspektion betroffenen Unionsbetreibers im Bereich Weltraum um Erläuterungen zu Sachverhalten und Unterlagen, die in den Zuständigkeitsbereich des Gegenstands der Inspektion fallen, zu ersuchen und die Antworten aufzuzeichnen;

  - d) Geschäftsgebäude, Bücher oder Aufzeichnungen jeder Art für die Dauer der Inspektion in dem hierfür erforderlichen Ausmaß zu versiegeln.

(5) Die zuständigen Behörden verfügen mindestens über die folgenden Durchsetzungsbefugnisse, die es ihnen gestatten,

  - a) Warnungen vor mutmaßlichen Zuwiderhandlungen gegen die in dieser Verordnung festgelegten Anforderungen auszusprechen;

  - b) die Unionsbetreiber im Bereich Weltraum anzuweisen, ein Verhalten einzustellen, das nach Auffassung der zuständigen Behörden gegen die Anforderungen dieser Verordnung verstößt;

  - c) die Unionsbetreiber im Bereich Weltraum anzuweisen, die Einhaltung der Vorschriften in der von den zuständigen Behörden festzulegenden Weise und nach dem von ihnen festzulegenden Zeitplan sicherzustellen;

  - d) die Unionsbetreiber im Bereich Weltraum anzuweisen, die von den zuständigen Behörden festgestellten Mängel bei der Anwendung der in dieser Verordnung festgelegten Anforderungen zu beheben, unter anderem durch die Anwendung von Abhilfemaßnahmen bei Zuwiderhandlungen gegen die in dieser Verordnung festgelegten Anforderungen;

  - e) für einen bestimmten Zeitraum einen Kontrollbeauftragten zu benennen, der die Einhaltung der in dieser Verordnung festgelegten Anforderungen durch die Unionsbetreiber im Bereich Weltraum überwacht.

(6) Die zuständigen Behörden verfügen mindestens über folgende Sanktionierungsbefugnisse, die es ihnen gestatten,

  - a) bei Zuwiderhandlung gegen die in dieser Verordnung festgelegten Anforderungen eine Geldbuße oder eine Verwaltungsstrafe zu verhängen oder eine zuständige Verwaltungs- oder Justizbehörde zu ersuchen, diese zu verhängen;

  - b) die Genehmigung vorübergehend auszusetzen oder eine zuständige Verwaltungs- oder Justizbehörde zu ersuchen, die Genehmigung teilweise oder vollständig auszusetzen;

  - c) die Genehmigung zur Durchführung von Weltraumtätigkeiten zurückzunehmen, wenn ein Unionsbetreiber im Bereich Weltraum die Bedingungen, unter denen die Genehmigung erteilt wurde, nicht mehr erfüllt, oder wenn ein Unionsbetreiber im Bereich Weltraum sich in einer Situation befindet, in der die Genehmigung nach nationalem Recht zurückgenommen würde.

      Eine vorübergehende Aussetzung gemäß Buchstabe b wird angewandt, bis der betreffende Unionsbetreiber im Bereich Weltraum alle Maßnahmen ergreift, die erforderlich sind, um die von der zuständigen Behörde festgestellten Probleme zu beheben oder allen von der zuständigen Behörde vorgeschriebenen Maßnahmen in vollem Umfang nachzukommen.

(7) Die zuständigen Behörden können von sich aus beschließen, einstweilige Maßnahmen gegen Unionsbetreiber im Bereich Weltraum zu verhängen, insbesondere in dringenden Fällen, um die Anforderungen dieser Verordnung zu erfüllen.

(8) Die Mitgliedstaaten können durch Rechtsvorschriften vorsehen, dass die zuständigen Behörden neben den in den Absätzen 3 bis 7 aufgeführten Befugnissen über zusätzliche Befugnisse verfügen. Die Ausübung dieser Befugnisse darf die effektive Umsetzung dieses Kapitels nicht beeinträchtigen.

<a id="art-31"></a>
### Artikel 31 – Verwaltungsstrafen

(1) Die Mitgliedstaaten legen Regeln für Strafen für Zuwiderhandlung gegen die Bestimmungen dieser Verordnung fest. Diese Strafen müssen wirksam, verhältnismäßig und abschreckend sein. Die Mitgliedstaaten teilen der Kommission diese Maßnahmen unverzüglich mit und melden ihr etwaige spätere Änderungen.

(2) Bei der Festsetzung der Verwaltungsstrafe und der Höhe der Geldbuße berücksichtigen die zuständigen Behörden alle relevanten Umstände, einschließlich, gegebenenfalls

  - a) die Schwere und Dauer der Zuwiderhandlung sowie die Dauer des durch die Zuwiderhandlung verursachten Schadens;

  - b) frühere Zuwiderhandlungen der für die Zuwiderhandlung verantwortlichen natürlichen oder juristischen Person;

  - c) den durch die Zuwiderhandlung verursachten materiellen oder immateriellen Schaden, einschließlich finanzieller oder wirtschaftlicher Verluste und schädlicher Auswirkungen auf andere Dienste, und relevante Kriterien für die Auswirkungen einer Zuwiderhandlung, wie die Zahl der betroffenen Nutzer oder die Höhe des Schadens, der einem Dritten durch die Zuwiderhandlung entstanden ist;

  - d) den Vorsatz oder die Fahrlässigkeit des Urhebers der Zuwiderhandlung;

  - e) Maßnahmen, die der Unionsbetreiber im Bereich Weltraum ergriffen hat, um den Schaden zu verhindern oder zu mindern;

  - f) den Umfang der Zusammenarbeit mit den zuständigen Behörden sowie jegliche Behinderung von Inspektionen, Audits oder anderen Überwachungstätigkeiten der zuständigen Behörden nach Aufdeckung der Zuwiderhandlung;

  - g) die Höhe der von der für die Zuwiderhandlung verantwortlichen natürlichen oder juristischen Person erzielten Gewinne oder vermiedenen Verluste;

  - h) die Notwendigkeit einer abschreckenden Wirkung der Geldbuße.

(3) Die zuständigen Behörden müssen ihre Durchsetzungsmaßnahmen begründen.

(4) Die Aufsichtsmaßnahmen müssen unter Berücksichtigung aller Umstände jedes Einzelfalls wirksam, abschreckend und verhältnismäßig sein. Vor dem Erlass einer Aufsichtsmaßnahme unterrichten die zuständigen Behörden die Unionsbetreiber im Bereich Weltraum über ihre vorläufigen Feststellungen und gewähren den Unionsbetreibern im Bereich Weltraum eine angemessene Frist zur Stellungnahme.

(5) Die Mitgliedstaaten stellen sicher, dass die zuständigen Behörden befugt sind, Zuwiderhandlungen gegen diese Verordnung unmittelbar vor ein Gericht zu bringen, und dass sie berechtigt sind, eigenständig an allen Arten von Gerichtsverfahren im Zusammenhang mit der Durchsetzung dieser Verordnung teilzunehmen, auch durch Einlegung von Rechtsmitteln.

<a id="title-iii-chapter-i-section-2"></a>
## Abschnitt 2 – ÜBERWACHUNG QUALIFIZIERTER TECHNISCHER STELLEN FÜR WELTRAUMTÄTIGKEITEN

<a id="art-32"></a>
### Artikel 32 – Nutzung qualifizierter technischer Stellen für Weltraumtätigkeiten

(1) Mitgliedstaaten, welche die in Artikel 8 Absatz 1 Buchstabe a genannte Möglichkeit nutzen, stellen sicher, dass qualifizierte technische Stellen für Weltraumtätigkeiten von Behörden benannt, bewertet und überwacht und der Kommission gemäß Artikel 33 notifiziert werden.

(2) Die Mitgliedstaaten können die Aufgaben der Bewertung und Überwachung im Sinne und im Einklang mit der Verordnung (EG) Nr. 765/2008 der nationalen Akkreditierungsstelle übertragen. Die Kommission macht diese Informationen der Öffentlichkeit zugänglich.

(3) Die Mitgliedstaaten tragen dafür Sorge, dass die öffentliche Stelle im Sinne des Absatzes 1

  - a) so organisiert und betrieben wird, dass kein Interessenkonflikt mit den technischen Bewertungstätigkeiten der qualifizierten technischen Stellen für Weltraumtätigkeiten entsteht;

  - b) die Aufgaben der Benennung, Bewertung und Überwachung der qualifizierten technischen Stellen für Weltraumtätigkeiten objektiv und unparteiisch wahrnimmt;

  - c) über ausreichend Personal für die Wahrnehmung ihrer Aufgaben verfügt.

<a id="art-33"></a>
### Artikel 33 – Notifizierungsverfahren

(1) Die Mitgliedstaaten notifizieren der Kommission alle in ihrem Hoheitsgebiet niedergelassenen qualifizierten technischen Stellen für Weltraumtätigkeiten. Für die Zwecke dieser Notifizierung verwenden sie das Informationssystem „New Approach Notified and Designated Organisations“ (NANDO).

(2) Die Mitgliedstaaten können der Kommission nur qualifizierte technische Stellen für Weltraumtätigkeiten notifizieren, die den Anforderungen des Artikels 35 genügen.

(3) Die Notifizierung gemäß Absatz 1 enthält Folgendes:

  - a) die vollständigen Einzelheiten der technischen Bewertungstätigkeiten, die bezüglich der unter diese Verordnung fallenden Bereiche durchgeführt wurden, sowie jegliche relevanten Bewertungsmodule, aus denen hervorgeht, welche Prozesse, Dienstleistungen oder Produkte in Bezug auf die unter diese Verordnung fallenden Bereiche abgedeckt sind;

  - b) jegliche relevante Bestätigung der Kompetenz.

(4) Stützt sich eine Notifizierung nicht auf die Akkreditierungsurkunde gemäß Artikel 34 Absatz 5 Buchstabe b, so legen die Mitgliedstaaten der Kommission und den anderen Mitgliedstaaten Nachweise vor, welche die Kompetenz dieser qualifizierten technischen Stelle für Weltraumtätigkeiten belegen, und stellen sicher, dass diese Stelle regelmäßig überwacht wird und weiterhin die Anforderungen des Artikels 35 erfüllt.

(5) Eine Stelle darf nur dann Tätigkeiten als qualifizierte technische Stelle für Weltraumtätigkeiten ausüben, wenn die Kommission oder ein Mitgliedstaat nicht innerhalb von zwei Monaten nach dem Datum der Notifizierung Einwände erhoben hat, wenn diese sich auf die Akkreditierungsurkunde gemäß Artikel 34 Absatz 5 Buchstabe b stützt, oder innerhalb von drei Monaten nach dem Datum der Notifizierung, wenn diese sich auf die in Artikel 34 Absatz 6 genannten Nachweise stützt.

<a id="title-iii-chapter-i-section-3"></a>
## Abschnitt 3 – QUALIFIZIERTE TECHNISCHE STELLEN FÜR WELTRAUMTÄTIGKEITEN

<a id="art-34"></a>
### Artikel 34 – Verfahren für qualifizierte technische Stellen für Weltraumtätigkeiten

(1) Beabsichtigt eine Stelle, technische Bewertungen für eine oder mehrere unter Titel IV Kapitel I bis V fallende Angelegenheit(en) durchzuführen, so stellt sie bei der in Artikel 32 genannten zuständigen Behörde des Mitgliedstaats, in dem sie niedergelassen ist, einen Antrag auf Benennung als qualifizierte technische Stelle für Weltraumtätigkeiten.

(2) Betreffen die technischen Bewertungstätigkeiten Angelegenheiten, die unter Titel IV Kapitel II fallen, so greifen die Mitgliedstaaten auf die in Artikel 8 der Richtlinie (EU) 2022/2555 benannten zuständigen nationalen Behörden zurück.

(3) Bei der Wahrnehmung ihrer in Artikel 28 Absatz 1 genannten Genehmigungs- und Aufsichtsaufgaben tragen die zuständigen Behörden den von den in Absatz 2 genannten Stellen und Behörden durchgeführten technischen Bewertungen gebührend Rechnung und sorgen für die aufsichtliche Konvergenz mit den in Artikel 8 der Richtlinie 2022/2555 genannten Behörden.

    Die Mitgliedstaaten sorgen durch Mechanismen und Protokolle für eine enge Koordinierung zwischen diesen Behörden und den gemäß Artikel 28 Absatz 1 dieser Verordnung benannten zuständigen Behörden.

(4) Ist eine öffentliche Einrichtung, die technische Bewertungen in Bezug auf die in Titel IV Kapitel I und V festgelegten Anforderungen durchführt, Teil des Aufbaus der Verwaltung der in Artikel 28 Absatz 1 genannten zuständigen Behörde, so wird der in Absatz 1 genannte Antrag von der zuständigen Behörde gestellt.

(5) Die in Absatz 1 genannten Stellen geben an, für welche der unter Titel IV Kapitel I bis V fallenden Angelegenheiten der Antrag auf Anerkennung als qualifizierte technische Stelle für Weltraumtätigkeiten eingereicht wird, und

  - a) liefern eine Beschreibung aller durchzuführenden technischen Bewertungstätigkeiten;

  - b) legen gegebenenfalls jegliche Akkreditierungsurkunden vor, die von einer nationalen Akkreditierungsstelle ausgestellt wurden und mit denen bescheinigt wird, dass die betreffende Stelle den Anforderungen laut Artikel 35 genügt;

  - c) legen gegebenenfalls ein gültiges Dokument vor, das die Benennung des Antragstellers als notifizierte Stelle gemäß den einschlägigen Harmonisierungsrechtsvorschriften der Union belegt.

(6) Kann ein Antragsteller die Akkreditierungsurkunde gemäß Absatz 5 Buchstabe b nicht vorlegen, so legt er der in Artikel 32 genannten Behörde alle Unterlagen vor, die es dieser Behörde ermöglichen, Kontrollen oder eine regelmäßige Überwachung durchzuführen, um die Einhaltung der Anforderungen des Artikels 35 sicherzustellen.

(7) Wurde der Antragsteller bereits gemäß einer Harmonisierungsrechtsvorschrift der Union als notifizierte Stelle benannt, so können alle mit einer solchen Benennung verbundenen Dokumente und Bescheinigungen verwendet werden, um seine Benennung als qualifizierte technische Stelle für Weltraumtätigkeiten gemäß dieser Verordnung zu unterstützen.

(8) Sind die Bedingungen gemäß Absatz 5 erfüllt, so entscheidet die in Artikel 32 genannte Behörde positiv über den Antrag. Die Entscheidung wird der technischen Stelle, den zuständigen Behörden des betreffenden Mitgliedstaats und der Kommission zugestellt.

(9) Eine qualifizierte technische Stelle für Weltraumtätigkeiten aktualisiert die in den Absätzen 5, 6 und 7 genannten Unterlagen bei allen relevanten Änderungen, damit die notifizierende Behörde überwachen kann, ob diese qualifizierte technische Stelle für Weltraumtätigkeiten den Anforderungen des Artikels 35 kontinuierlich entspricht.

<a id="art-35"></a>
### Artikel 35 – Anforderungen an qualifizierte technische Stellen für Weltraumtätigkeiten

(1) Qualifizierte technische Stellen für Weltraumtätigkeiten müssen die in Anhang IX Nummer 1 festgelegten Anforderungen erfüllen.

(2) Werden technische Bewertungstätigkeiten im Zusammenhang mit Titel IV Kapitel III durchgeführt, so muss eine qualifizierte technische Stelle für Weltraumtätigkeiten zusätzlich zu der in Absatz 1 genannten Verpflichtung den Anforderungen gemäß Anhang IX Nummer 2 genügen.

(3) Bei qualifizierten technischen Stellen für Weltraumtätigkeiten, die technische Bewertungstätigkeiten im Zusammenhang mit Titel IV Kapitel I und V durchführen, muss es sich um öffentliche Stellen handeln.

(4) Eine qualifizierte technische Stelle für Weltraumtätigkeiten, die Aufgaben im Zusammenhang mit der technischen Bewertung an Unterauftragnehmer vergibt, unterrichtet die in Artikel 32 genannte Behörde entsprechend und stellt sicher, dass ihr Unterauftragnehmer den in den Absätzen 1 und 2 genannten Anforderungen entspricht.

    Qualifizierte technische Stellen für Weltraumtätigkeiten halten alle Unterlagen im Zusammenhang mit der Bewertung der Qualifikationen des Unterauftragnehmers und den von diesem Unterauftragnehmer ausgeführten Arbeiten für die in Artikel 32 genannte Behörde bereit.

<a id="art-36"></a>
### Artikel 36 – Identifikationsnummern

Die Kommission erteilt jeder qualifizierten technischen Stelle für Weltraumtätigkeiten eine Identifikationsnummer und veröffentlicht die Liste der qualifizierten technischen Stellen für Weltraumtätigkeiten in der Union, ihre Identifikationsnummer und die unter Titel IV fallenden Angelegenheiten, für die sie notifiziert wurden.

<a id="art-37"></a>
### Artikel 37 – Änderungen der Notifizierung

(1) Die in Artikel 32 genannte Behörde beschränkt gegebenenfalls die Notifizierung einer qualifizierten technischen Stelle für Weltraumtätigkeiten oder setzt sie aus oder nimmt sie zurück, wenn die Stelle den Anforderungen des Artikels 35 nicht mehr genügt oder ihren Verpflichtungen nicht nachkommt. Die Behörde setzt die Kommission und die anderen Mitgliedstaaten davon in Kenntnis.

(2) Im Fall einer Einschränkung, Aussetzung oder Rücknahme der Notifizierung oder wenn eine im Hoheitsgebiet eines Mitgliedstaats niedergelassene qualifizierte technische Stelle für Weltraumtätigkeiten ihre Tätigkeit eingestellt hat, ergreift dieser Mitgliedstaat geeignete Schritte, um die Unterlagen dieser qualifizierten technischen Stelle für Weltraumtätigkeiten an eine andere qualifizierte technische Stelle für Weltraumtätigkeiten oder, falls dies nicht möglich ist, an die Agentur oder die in Artikel 8 Absatz 1 Buchstabe b genannte internationale Organisation zu übermitteln.

<a id="art-38"></a>
### Artikel 38 – Widerspruch gegen Entscheidungen qualifizierter technischer Stellen für Weltraumtätigkeiten

Die Mitgliedstaaten stellen sicher, dass Entscheidungen qualifizierter technischer Stellen für Weltraumtätigkeiten angefochten werden können.

<a id="art-39"></a>
### Artikel 39 – Koordinierung qualifizierter technischer Stellen für Weltraumtätigkeiten

Die Kommission ermöglicht eine angemessene unionsweite Koordinierung qualifizierter technischer Stellen für Weltraumtätigkeiten, unter anderem durch die Einrichtung sektorspezifischer Gruppen qualifizierter technischer Stellen für Weltraumtätigkeiten.

<a id="title-iii-chapter-ii"></a>
## Kapitel II – GOVERNANCE AUF UNIONSEBENE

<a id="title-iii-chapter-ii-section-1"></a>
## Abschnitt 1 – AUFGABEN UND STRUKTUREN DER AGENTUR

<a id="art-40"></a>
### Artikel 40 – Aufgaben der Agentur

(1) Die Agentur hat in Bezug auf die in den Titeln II bis VI dieser Verordnung festgelegten Anforderungen folgende Aufgaben:

  - a) die technischen Bewertungen durchzuführen, die es der Kommission ermöglichen, Entscheidungen über die Genehmigung und laufende Beaufsichtigung von Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, sowie über die Registrierung und die laufende Beaufsichtigung von Drittlandsbetreibern zu fällen;

  - b) auf Anfrage die technischen Bewertungen gemäß Artikel 8 Absatz 1 Buchstabe c durchzuführen;

  - c) auf der Grundlage einer Entscheidung der Kommission die Registrierung von Drittlandsbetreibern im Bereich Weltraum und von internationalen Organisationen gemäß den Artikeln 17 und 18 durchzuführen;

  - d) URSO gemäß Artikel 24 einzurichten und zu verwalten;

  - e) die e-Zertifikate nach Artikel 25 Absatz 1 auszugeben;

  - f) die Registrierung im URSO bzw. der Aussetzung bzw. Rücknahme der Registrierung gemäß Artikel 22 zu verwalten;

  - g) die Kontaktlistendatenbank der Union für Warnungen vor Ereignissen von hohem Interesse gemäß Artikel 67 Absatz 1 einzurichten und zu verwalten;

  - h) der Kommission Berichte über die Anwendung der unionsweit vereinfachten Risikoverwaltung und geeignete Empfehlungen gemäß Artikel 79 Absatz 3 Unterabsatz 1 vorzulegen;

  - i) Tätigkeiten des nach Artikel 94 Absatz 1 eingerichteten Unionsnetzes für Resilienz im Weltraum (Union Space Resilience Network, EUSRN) zu koordinieren und das Sekretariat des EUSRN zu stellen;

  - j) zur Schaffung und Pflege des Rahmens für das Weltraumsiegel der Union im Einklang mit den Bestimmungen von Titel VI Kapitel II beizutragen;

  - k) eine Website zu pflegen, auf der aktuelle Informationen über die Weltraumsiegelsysteme der Union und die Weltraumsiegel der Union gemäß Artikel 111 Absatz 5 bereitgestellt und veröffentlicht werden;

  - l) die Kommission bei der Ausarbeitung von delegierten Rechtsakten und Durchführungsrechtsakten auf der Grundlage dieser Verordnung und bei der Ausarbeitung von Vorschlägen für Änderungen dieser Verordnung zu unterstützen, indem sie förmliche fachliche Stellungnahmen an die Kommission abgibt;

  - m) Leitlinien für die zuständigen Behörden und die Unionsbetreiber im Bereich Weltraum auszugeben und Empfehlungen an eine oder mehrere zuständige Behörden abzugeben, um unionsweit einheitliche Aufsichtspraktiken und die einheitliche Anwendung des Unionsrechts zu fördern;

  - n) auf Ersuchen der Kommission in Angelegenheiten, die unter diese Verordnung fallen, zur Festlegung, Messung, Berichterstattung und Analyse von Leistungsindikatoren, insbesondere zu erheblichen Sicherheitsvorfällen und Kollisionen, beizutragen;

  - o) alle erforderlichen technischen, wissenschaftlichen und administrativen Beratungs- und Unterstützungsleistungen für die Kommission bereitzustellen, damit diese ihre Aufsichtsaufgaben im Rahmen dieser Verordnung wahrnehmen kann;

  - p) die Zusammenarbeit mit Aufsichtsbehörden von Drittländern, internationalen Organisationen oder deren Stellen aufzubauen und die Sensibilisierung für die in dieser Verordnung festgelegten Anforderungen auf internationaler Ebene zu fördern und zu erleichtern;

  - q) gegebenenfalls mit anderen Organen, Einrichtungen und sonstigen Stellen der Union zusammenzuarbeiten, wenn die Tätigkeiten dieser Organe, Einrichtungen und sonstigen Stellen der Union technische Aspekte im Zusammenhang mit der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten oder andere relevante Fragen wie den Einsatz künstlicher Intelligenz bei der Durchführung von Weltraumtätigkeiten abdecken.

(2) Vor der Vorlage der fachlichen Stellungnahmen gemäß Absatz 1 Buchstabe l sowie vor der Herausgabe der in Absatz 1 Buchstabe m genannten Leitlinien führt die Agentur öffentliche Konsultationen durch.

    Die Agentur übermittelt der Kommission bis zum 1.8.2028 die fachlichen Stellungnahmen, um die Kommission bei der Ausarbeitung der delegierten Rechtsakte gemäß Artikel 113 und der Durchführungsrechtsakte gemäß Artikel 59 Absatz 3 Unterabsatz 1, Artikel 61 Absatz 3 Unterabsatz 1, Artikel 63 Absatz 2, Artikel 68 Absatz 2 Unterabsatz 1, Artikel 69 Absatz 2 Unterabsatz 1, Artikel 70 Absatz 3 Unterabsatz 1, Artikel 73 Absatz 4 Unterabsatz 1, Artikel 93 Absatz 8, Artikel 96 Absatz 7 Unterabsatz 2, Artikel 97 Absatz 4, Artikel 101 Absatz 5 Unterabsatz 1, Artikel 104 Absatz 2 und Artikel 111 Absatz 4 Unterabsatz 1 zu unterstützen.

(3) Bevor die Agentur eine neue Leitlinie oder Empfehlung herausgibt, überprüft sie bestehende Leitlinien und Empfehlungen, um Doppelungen zu vermeiden.

<a id="art-41"></a>
### Artikel 41 – Gebühren der Agentur

(1) Die Agentur erhebt im Einklang mit dem in Absatz 3 genannten delegierten Rechtsakt von Unionsbetreibern im Bereich Weltraum, Drittlandsbetreibern im Bereich Weltraum und internationalen Organisationen Gebühren zur vollständigen Deckung der erforderlichen Ausgaben, die der Agentur bei der Wahrnehmung der Aufgaben gemäß dieser Verordnung entstehen, einschließlich der Erstattung der Kosten, die infolge der Arbeit der gemeinsamen Prüfungsteams gemäß Artikel 44 Absatz 2 Unterabsatz 1 entstanden sind, oder der Kosten für die Beratung durch unabhängige Sachverständige.

(2) Die Höhe einer Gebühr, die einem in Absatz 1 genannten Anbieter von Weltraumdiensten in Rechnung gestellt wird, deckt alle Kosten ab, die sich aus der Wahrnehmung der in dieser Verordnung festgelegten Aufgaben ergeben. Der Betrag muss in einem angemessenen Verhältnis zum Umsatz des betreffenden Anbieters von Weltraumdiensten stehen.

(3) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Ergänzung dieser Verordnung durch Festlegung der Höhe der Gebühren und der Art und Weise ihrer Entrichtung zu erlassen.

<a id="art-42"></a>
### Artikel 42 – Strukturen der Agentur

Für die Zwecke der in Artikel 43 genannten Aufgaben werden innerhalb der Agentur ein Konformitätsgremium und eine Widerspruchskammer eingerichtet.

<a id="art-43"></a>
### Artikel 43 – Aufgaben des Konformitätsgremiums

(1) Das Konformitätsgremium ist zuständig für Folgendes:

  - a) die Vorlage technischer Vorschläge an die Kommission zur Genehmigung von Betreibern von unionseigenen Ressourcen gemäß Artikel 12 Absatz 2, die von der Kommission mit der Durchführung oder dem Betrieb einer Komponente des Unionsprogramms gemäß dem genannten Artikel betraut werden, und die Durchführung von technischen Bewertungstätigkeiten während der gesamten Dauer einer solchen Genehmigung, damit die Kommission die laufende Beaufsichtigung dieses Betreiber ausüben kann, um die Einhaltung der in dieser Verordnung festgelegten Anforderungen sicherzustellen;

  - b) die Durchführung technischer Bewertungstätigkeiten in Bezug auf die in Titel IV Kapitel I, II, III, IV und V festgelegten Anforderungen, bevor die zuständigen Behörden Anbietern von Weltraumdiensten der Union Genehmigungen in Bezug auf die in Artikel 5 Absatz 1 Ziffer 21 genannten Ressourcen erteilen, wenn ein Mitgliedstaat beschlossen hat, die Agentur gemäß Artikel 8 Absatz 1 Buchstabe c mit der Durchführung einer solchen technischen Bewertung zu betrauen;

  - c) die Bewertung und Vorlage technischer Vorschläge an die Kommission in Bezug auf die laufende Einhaltung der in Titel IV festgelegten Anforderungen durch die Drittlandsbetreiber im Bereich Weltraum gemäß Artikel 15 bzw. Artikel 16.

(2) Für die Zwecke des Absatzes 1 hat das Konformitätsgremium folgende Befugnisse:

  - a) in der in Absatz 3 genannten Weise technische Bewertungsentscheidungen zu fällen, in denen es der Kommission die Genehmigung von Unionsbetreibern im Bereich Weltraum gemäß Artikel 11 Absatz 1 Unterabsatz 1 vorschlägt, die gemäß Artikel 12 Absatz 2 unionseigene Ressourcen betreiben und mit der Ausführung oder dem Betrieb von Komponenten des Unionsprogramms betraut sind, und der Kommission während der gesamten Dauer einer solchen Genehmigung die erforderlichen Aufsichtsmaßnahmen vorzuschlagen;

  - b) Entscheidungen über die technische Bewertung in Bezug auf die Erfüllung der in Titel IV Kapitel I, II, III, IV und V festgelegten Anforderungen zu treffen, wenn ein Mitgliedstaat die Agentur mit der Durchführung der technischen Bewertung gemäß Artikel 8 Absatz 1 Buchstabe c betraut;

  - c) auf der Grundlage einer Entscheidung der Kommission gemäß Artikel 11 Absatz 1 Unterabsatz 1, Artikel 17 Absatz 6 und Artikel 22 Absatz 6 Unterabsatz 1 die Registrierung im URSO bzw. die Aussetzung oder Rücknahme der Registrierung von Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, von Drittlandsbetreibern im Bereich Weltraum sowie von internationalen Organisationen gemäß den Artikeln 17, 18 und 22 im URSO sicherzustellen sowie URSO und die zugehörige Plattform zu verwalten;

  - d) technische Bewertungsentscheidungen zu fällen, in denen der Kommission Maßnahmen vorgeschlagen werden, mit denen sichergestellt werden soll, dass Drittlandsbetreiber im Bereich Weltraum, sobald sie registriert sind, die Anforderungen des Titels IV in der in den Artikeln 15 und 16 festgelegten Weise erfüllen;

  - e) die e-Zertifikate nach Artikel 25 Absatz 1 auszustellen;

  - f) die Schlussfolgerungen der von den technischen Gremien gemäß Artikel 44 Absatz 2 Unterabsatz 2 vorgelegten Berichte bei der Durchführung der in Absatz 1 genannten technischen Bewertungen zu billigen;

  - g) die konsolidierten Listen der Anbieter von Weltraumdiensten, die im URSO registriert sind, gemäß Artikel 24 Absatz 2 zu erstellen und zu veröffentlichen;

  - h) sich eine Geschäftsordnung zu geben und diese zu veröffentlichen.

(3) Für die Zwecke der Entscheidungen nach Absatz 2 handelt das Konformitätsgremium wie folgt:

  - a) die Einhaltung der in Titel IV Kapitel I, III, IV und V festgelegten Anforderungen wird durch technische Bewertungen gemäß Artikel 44 Absatz 1 festgestellt;

  - b) die Einhaltung der in Titel IV Kapitel II festgelegten Anforderungen wird wie folgt festgestellt:

    - i) bei Entscheidungen zur technischen Bewertung in Bezug auf die in Absatz 1 Buchstabe a genannten Anbieter von Weltraumdiensten stellt das Gremium für die Sicherheitsakkreditierung im Einklang mit Kapitel II der Verordnung (EU) 2021/696 die Einhaltung der Anforderungen fest;

    - ii) bei Entscheidungen zur technischen Bewertung in Bezug auf die in Absatz 1 Buchstaben b und c genannten Anbieter von Weltraumdiensten wird die Einhaltung der Anforderungen gemäß Artikel 44 Absatz 1 festgestellt.

<a id="art-44"></a>
### Artikel 44 – Technische Konfigurationen des Konformitätsgremiums

(1) Das Konformitätsgremium führt seine Arbeit als Konfiguration der folgenden drei technischen Gremien aus:

  - a) technisches Gremium für Konformität im Bereich der Sicherheit;

  - b) technisches Gremium für Konformität im Bereich der Resilienz;

  - c) technisches Gremium für Konformität im Bereich der ökologischen Nachhaltigkeit.

(2) Die in Absatz 1 genannten technischen Gremien setzen sich aus gemeinsamen Prüfungsteams zusammen, die sich aus Bediensteten der Agentur, den zuständigen Behörden und qualifizierten technischen Stellen für Weltraumtätigkeiten zusammensetzen.

    Nach Abschluss ihrer technischen Bewertungen legen die technischen Gremien dem Konformitätsgremium Berichte vor.

    Die technischen Gremien werden von einem technischen Sekretariat unterstützt, das die erforderlichen vorbereitenden Arbeiten durchführt, damit das Konformitätsgremium seine Aufgaben gemäß dieser Verordnung erfüllen kann.

(3) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Ergänzung dieser Verordnung zu erlassen, in denen die Kriterien für die Zusammensetzung und das Fachwissen des Personals festgelegt werden, das die gemeinsamen Prüfungsteams für die technischen Gremien bildet, um eine ausgewogene Beteiligung der Bediensteten der zuständigen Behörden und der qualifizierten technischen Stellen für Weltraumtätigkeiten zu gewährleisten und die Einzelheiten ihrer Benennung, Aufgaben und Arbeitsvereinbarungen festzulegen.

<a id="art-45"></a>
### Artikel 45 – Zusammensetzung des Konformitätsgremiums und Abstimmungsregeln

(1) Das Konformitätsgremium setzt sich aus einem Vertreter jedes Mitgliedstaats und einem Vertreter der Kommission zusammen.

    Die Amtszeit der Mitglieder des Konformitätsgremiums beträgt 4 Jahre und kann verlängert werden.

(2) Die Vertreter der Agenturen oder Stellen der Union und von Drittländern oder internationalen Organisationen können ausnahmsweise wie folgt als Beobachter zu den Sitzungen des Konformitätsgremiums eingeladen werden:

  - a) in Bezug auf die Vertreter der Agenturen oder Einrichtungen der Union in Angelegenheiten, die Aufgaben oder Aspekte betreffen, die für diese Agenturen oder Einrichtungen der Union von Interesse sind;

  - b) in Bezug auf die Vertreter von Drittländern oder internationalen Organisationen in Angelegenheiten, die unmittelbar mit ihnen zusammenhängen, insbesondere in Bezug auf Ressourcen von Weltrauminfrastrukturen, die sich in ihrem Besitz oder Hoheitsgebiet befinden, oder in Angelegenheiten, die unmittelbar mit der Einhaltung dieser Verordnung durch Drittlandsbetreiber im Bereich Weltraum und internationale Organisationen zusammenhängen.

(3) Regelungen über die Bedingungen der Teilnahme von Vertretern von Drittländern oder internationalen Organisationen nach Absatz 2 mit den entsprechenden Bedingungen werden in den einschlägigen Übereinkünften geregelt und sind mit der Geschäftsordnung des Konformitätsgremiums vereinbar.

(4) Die Entscheidungen des Konformitätsgremiums werden von allen stimmberechtigten Mitgliedern einvernehmlich gefasst. Kann kein Konsens erzielt werden, so fasst das Konformitätsgremium Entscheidungen auf der Grundlage der Beschlussfassung mit qualifizierter Mehrheit gemäß Artikel 16 EUV.

    Der Vertreter der Kommission beteiligt sich nicht an der Abstimmung.

    Der Vorsitzende des Konformitätsgremiums unterzeichnet im Namen des Registrierungsgremiums die von diesem gefällten Entscheidungen.

<a id="art-46"></a>
### Artikel 46 – Widerspruchskammer

(1) Es wird eine Widerspruchskammer eingerichtet. Die Widerspruchskammer entscheidet über Widersprüche gegen Entscheidungen der Agentur.

(2) Die Widerspruchskammer setzt sich aus sechs Mitgliedern und sechs stellvertretenden Mitgliedern zusammen, die aus einer von der Kommission oder vom Verwaltungsrat erstellten Liste qualifizierter Bewerber auf der Grundlage ihres einschlägigen Fachwissens in den Bereichen Weltraumrecht oder Weltraumtätigkeiten, insbesondere in Angelegenheiten im Zusammenhang mit der Sicherheit, dem Risikomanagement, der Cybersicherheit und der ökologischen Nachhaltigkeit von Weltraumtätigkeiten oder im Zusammenhang mit ISOS ernannt werden.

(3) Zwei Mitglieder der Widerspruchskammer und zwei stellvertretende Mitglieder werden vom Verwaltungsrat gemäß Artikel 72 Absatz 1 der Verordnung (EU) 2021/696 aus einer Auswahlliste ernannt, die von der Kommission im Anschluss an eine öffentliche Aufforderung zur Interessenbekundung vorgeschlagen wird, welche im Amtsblatt der Europäischen Union veröffentlicht wird.

(4) Die Mitglieder der Widerspruchskammer sind in ihrer Beschlussfassung unabhängig. Sie sind an keinerlei Weisungen gebunden. Sie dürfen innerhalb und in Bezug auf die Agentur, deren Verwaltungsrat, deren Gremium für die Sicherheitsakkreditierung oder deren Konformitätsgremium keine sonstigen Aufgaben wahrnehmen.

(5) Die Amtszeit der Mitglieder der Widerspruchskammer beträgt 4 Jahre. Sie kann einmal verlängert werden. Die Mitglieder der Widerspruchskammer dürfen während ihrer Amtszeit nur abberufen werden, wenn sie durch eine Entscheidung des Verwaltungsrats eines schweren Fehlverhaltens für schuldig befunden wurden.

(6) Die Entscheidungen der Widerspruchskammer werden mit einer Mehrheit von vier ihrer sechs Mitglieder getroffen. Die Widerspruchskammer ernennt ihre(n) Vorsitzende(n).

    Der/die Vorsitzende und die Mitglieder haben gleiche Stimmrechte.

(7) Die Agentur sorgt für eine angemessene Arbeits- und Sekretariatsunterstützung der Widerspruchskammer.

<a id="art-47"></a>
### Artikel 47 – Widerspruch

(1) Gegen eine Entscheidung der Agentur nach Titel II Kapitel II, III und IV, Artikel 43 Absatz 2, Artikel 49 bis 52 und Titel IV sowie gegen jede andere Entscheidung der Agentur, die an eine natürliche oder juristische Person gerichtet ist oder die, obwohl sie als an eine andere Person gerichtete Entscheidung ergangen ist, diese Person unmittelbar und individuell betrifft, kann Widerspruch eingelegt werden.

(2) Der Widerspruch ist samt Begründung innerhalb von drei Monaten nach dem Datum der Bekanntgabe der Entscheidung an die betreffenden Person oder, sofern eine solche Bekanntgabe nicht erfolgt ist, innerhalb von drei Monaten ab dem Datum, an dem die Agentur ihre Entscheidung bekannt gegeben hat, schriftlich bei der Agentur einzulegen.

(3) Ein nach Absatz 1 eingelegter Widerspruch setzt die Anwendung der in jenem Absatz genannten Entscheidung nicht aus. Die Widerspruchskammer kann jedoch die Anwendung der angefochtenen Entscheidung aussetzen, wenn sie dies für erforderlich hält.

(4) Die Widerspruchskammer entscheidet über Widersprüche innerhalb von 6 Monaten nach deren Einreichung. Die Widerspruchskammer bestätigt entweder die Entscheidung oder verweist die Angelegenheit an das Konformitätsgremium zurück. Dieses ist an die Entscheidung der Widerspruchskammer gebunden.

    Die Beschlüsse der Widerspruchskammer werden begründet und von der Behörde veröffentlicht.

(5) Der Kommission wird die Befugnis übertragen, die Einzelheiten des Verfahrens vor der Widerspruchskammer nach dem in Artikel 114 Absatz 2 genannten Prüfverfahren festzulegen.

(6) Klagen auf Aufhebung einer Entscheidung, die von der Agentur im Einklang mit dieser Verordnung getroffen wurde, und Klagen wegen Untätigkeit innerhalb der festgelegten Fristen können erst dann beim Gerichtshof eingereicht werden, wenn das oben genannte Widerspruchsverfahren erschöpft ist.

<a id="title-iii-chapter-ii-section-2"></a>
## Abschnitt 2 – BEFUGNISSE DER KOMMISSION UND DER AGENTUR IN BEZUG AUF UNIONSBETREIBER IM BEREICH WELTRAUM, DIE UNIONSEIGENE RESSOURCEN BETREIBEN, UND ANBIETER VON WELTRAUMDIENSTEN AUS DRITTLÄNDERN

<a id="art-48"></a>
### Artikel 48 – Umfang und Ausübung der Befugnisse durch die Agentur und die Kommission

(1) Die Kommission beaufsichtigt mit Unterstützung und Mitarbeit der Agentur die folgenden Anbieter von Weltraumdiensten in Bezug auf die Einhaltung der in dieser Verordnung festgelegten Anforderungen in der in diesem Abschnitt beschriebenen Weise:

  - a) Unionsbetreiber im Bereich Weltraum, die unionseigene Ressourcen betreiben, bei denen es sich um Einrichtungen handelt, die mit der Ausführung oder dem Betrieb von Komponenten des Unionsprogramms betraut sind, auf der Grundlage der von der Kommission gemäß Artikel 12 Absatz 2 erteilten Genehmigung;

  - b) Drittlandsbetreiber im Bereich Weltraum;

  - c) internationale Organisationen nach Artikel 107 Absatz 3 bzw. Artikel 108.

(2) Für die Zwecke der Durchführung der in Artikel 40 Absatz 1 Buchstabe a genannten technischen Bewertungen verfügt die Agentur über die in den Artikeln 49, 50, 51 und 52 genannten Befugnisse.

    Die Agentur unterrichtet die Kommission über jede der in den Artikeln 49, 50, 51 und 52 genannten Maßnahmen.

(3) Die Kommission und die Agentur nehmen die in den Artikeln 49, 50, 51 und 52 genannten Aufgaben getrennt oder gemeinsam wahr.

(4) Unbeschadet der jeweiligen Zuständigkeiten der Organe der Union und der Mitgliedstaaten kann die Agentur für die Zwecke des Absatzes 1 Buchstabe b nach dem Treffen der in Artikel 106 Absatz 1 genannten internationalen Übereinkünfte Vereinbarungen über die Verwaltungszusammenarbeit mit den zuständigen Behörden von Drittländern schließen, um eine reibungslose Durchführung von Inspektionen zu ermöglichen, wenn die in Artikel 52 Absatz 1 festgelegten Bedingungen erfüllt sind.

    Diese Kooperationsvereinbarungen begründen keine rechtlichen Verpflichtungen gegenüber der Union und ihren Mitgliedstaaten und hindern die Mitgliedstaaten und die zuständigen Behörden nicht daran, bilaterale oder multilaterale Vereinbarungen mit Drittländern und deren einschlägigen Behörden zu schließen.

(5) In den Kooperationsvereinbarungen ist mindestens Folgendes festgelegt:

  - a) die detaillierten Verfahren und Koordinierungsaspekte mit den zuständigen Drittlandsbehörden, die es der Agentur ermöglichen, gemäß Artikel 52 Inspektionen in den Geschäftsgebäuden der in Absatz 1 Buchstabe b genannten Anbieter von Weltraumdiensten außerhalb der Union durchzuführen;

  - b) die Einzelheiten zur Festlegung der Bedingungen für die Teilnahme der Vertreter der einschlägigen Behörden von Drittländern an Inspektionen, die von der Agentur gemäß Artikel 52 durchgeführt werden, insbesondere wenn es sich bei den in Absatz 1 Buchstabe b genannten Anbietern von Weltraumdiensten um öffentliche Einrichtungen handelt;

  - c) die erforderlichen Protokolle und Mechanismen, um die Übermittlung aller relevanten Informationen zwischen der Agentur und den Behörden des Drittstaats sicherzustellen, insbesondere die Mechanismen für die umgehende Benachrichtigung durch eine Drittlandsbehörde über Situationen, in denen davon ausgegangen wird, dass die in Absatz 1 Buchstabe b genannten Anbieter von Weltraumdiensten gegen Anforderungen verstoßen haben, die sie nach dem geltenden Recht des betreffenden Drittstaats einhalten müssen, sowie die angewandten Rechtsbehelfe und Sanktionen;

  - d) die erforderliche Koordinierung der Aufsichtstätigkeiten, die im Rahmen dieser Verordnung bzw. der von den Drittlandsbehörden durchgeführten Tätigkeiten durchgeführt werden;

  - e) die regelmäßige Übermittlung von Aktualisierungen in Bezug auf regulatorische oder aufsichtliche Entwicklungen in dem betreffenden Drittland.

<a id="art-49"></a>
### Artikel 49 – Informationsersuchen

(1) Die Kommission und die Agentur können durch Beschluss ersuchen, dass die in Artikel 48 Absatz 1 Buchstaben a, b und c genannten Anbieter von Weltraumdiensten der Kommission und der Agentur alle Informationen zur Verfügung stellen, die sie für die Wahrnehmung ihrer Aufgaben im Rahmen dieser Verordnung benötigen, einschließlich einschlägiger Geschäftsunterlagen, Berichte über Audits oder Sicherheitsvorfälle oder Informationen über ausgelagerte Tätigkeiten.

(2) In ihren nach Absatz 1 erlassenen Entscheidungen geben die Kommission und die Agentur den Zweck des Ersuchens an, geben an, welche Informationen benötigt werden, legen eine Frist fest, innerhalb deren diese Informationen zu übermitteln sind, geben an, welche Geldbußen gemäß Artikel 55 Absatz 1 Buchstabe c für die Erteilung unvollständiger, unrichtiger oder irreführender Informationen oder Erläuterungen zu verhängen sind, welche Möglichkeiten bestehen, diese Entscheidung durch den Gerichtshof überprüfen zu lassen, und welche Rechtsbehelfe nach Artikel 47 verfügbar sind.

(3) Die in Artikel 48 Absatz 1 Buchstaben a, b und c genannten Anbieter von Weltraumdiensten stellen die angeforderten Informationen zur Verfügung.

<a id="art-50"></a>
### Artikel 50 – Untersuchungsbefugnisse

(1) Die Kommission und die Agentur führen Untersuchungen bei den in Artikel 48 Absatz 1 Buchstaben a, b und c genannten Anbietern von Weltraumdiensten durch.

(2) Die Kommission und die Agentur erteilen ihren benannten Bediensteten eine Genehmigung, damit diese die in Absatz 1 genannten Untersuchungen durchführen können. Die Bediensteten der Kommission und der Agentur üben ihre Untersuchungsbefugnisse nach Vorlage dieser Genehmigung aus.

    Die Kommission und die Agentur können andere Personen der in Artikel 44 Absatz 1 genannten gemeinsamen Prüfungsteams oder Auditoren damit betrauen, gemeinsam mit den Bediensteten der Agentur Untersuchungen durchzuführen.

(3) In der Genehmigung gemäß Absatz 2 Unterabsatz 1 werden der Zweck, der Gegenstand, die durchzuführenden Maßnahmen sowie die Geldbußen gemäß Artikel 55 Absatz 1 Buchstabe c angegeben, die anwendbar sind, wenn die gemäß Absatz 4 Unterabsatz 1 vorgelegten Elemente oder die Antworten auf die gemäß Absatz 4 Buchstabe c gestellten Fragen und Erläuterungen unrichtig oder irreführend sind.

(4) Die Bediensteten der Kommission und der Agentur sind befugt,

  - a) Aufzeichnungen, Daten, Verfahren und sonstiges für die Erfüllung ihrer Aufgaben relevantes Material, unabhängig davon, in welcher Form es gespeichert ist, zu prüfen;

  - b) beglaubigte Kopien oder Auszüge dieser Aufzeichnungen, Daten und Verfahren und des sonstigen Materials anzufertigen oder zu verlangen;

  - c) jede Person oder ihre Vertreter oder jeden Beschäftigten vorzuladen und zur Abgabe mündlicher oder schriftlicher Erklärungen zu Sachverhalten oder Unterlagen aufzufordern, die mit dem Gegenstand und Zweck der Nachprüfung in Zusammenhang stehen, und die Antworten aufzuzeichnen;

  - d) Aufzeichnungen von Telefongesprächen und Datenübermittlungen anzufordern.

(5) Die in Artikel 48 Absatz 1 Buchstaben a, b und c genannten Anbieter von Weltraumdiensten sind verpflichtet, sich Untersuchungen zu unterziehen.

    Rechtzeitig vor dem Datum der Untersuchung unterrichten die Kommission und die Agentur die zuständige nationale Behörde, bei der die Untersuchung durchgeführt werden soll, über die geplante Untersuchung und über die Namen der in Absatz 2 Unterabsatz 2 genannten ermächtigten Bediensteten bzw. ggf. die sonstigen ermächtigten Personen.

(6) Die Bediensteten der betreffenden zuständigen Behörde unterstützen auf Ersuchen der Kommission und der Agentur die ermächtigten Bediensteten der Kommission und der Agentur sowie sonstige ermächtigte Personen bei der Erfüllung ihrer Aufgaben. Auf Antrag können die Bediensteten der betreffenden zuständigen Behörde an der jeweiligen Untersuchung teilnehmen.

<a id="art-51"></a>
### Artikel 51 – Inspektionen vor Ort in der Union

(1) Die Kommission und die Agentur können alle erforderlichen Inspektionen vor Ort in allen Geschäftsgebäuden, Grundstücken oder Sachen der Unionsbetreiber im Bereich Weltraum, die unionseigene Ressourcen betreiben, sowie in allen Geschäftsräumen, Grundstücken oder Sachen der in Artikel 48 Absatz 1 Buchstaben b und c genannten Anbieter von Weltraumdiensten in der Union durchführen.

(2) Die in Absatz 1 genannten Inspektionen werden auf der Grundlage der Entscheidungen der Kommission bzw. der Agentur im Rahmen einer Untersuchung vor Ort durchgeführt.

    In dieser Entscheidung werden die ermächtigten Bediensteten der Kommission und der Agentur sowie sonstige von der Kommission und der Agentur zur Durchführung einer Inspektion ermächtigte Personen benannt.

    In der Entscheidung werden der Zweck, der Gegenstand und das Datum der Inspektion angegeben. Die Entscheidung enthält einen Verweis auf die Geldbußen und Zwangsgelder gemäß Artikel 56 Absatz 1 in Fällen, in denen sich die betroffenen Personen nicht einer Nachprüfung unterziehen, sowie die Möglichkeit, diese Entscheidung durch den Gerichtshof überprüfen zu lassen, und die nach Artikel 47 verfügbaren Rechtsbehelfe.

(3) Die Bediensteten der Kommission und der Agentur sowie andere Personen, die gemäß Absatz 2 Unterabsatz 2 zur Durchführung einer Inspektion vor Ort befugt sind, dürfen alle Geschäftsgebäude, Grundstücke oder Sachen der Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen, bzw. der in Artikel 48 Absatz 1 Buchstaben b bzw. c genannten Anbieter von Weltraumdiensten betreten. Sie verfügen über alle in Artikel 50 Absatz 4 genannten Befugnisse sowie über die Befugnis, Geschäftsgebäude, Bücher oder Aufzeichnungen für den Zeitraum und in dem Umfang zu versiegeln, der für diese Inspektion erforderlich ist.

(4) Rechtzeitig vor der Inspektion unterrichten die Kommission und die Agentur die zuständige Behörde des Mitgliedstaats, wo die Inspektion durchgeführt werden soll. Die Inspektionen werden durchgeführt, wenn die zuständige Behörde keine Einwände erhoben hat.

    Die in Absatz 2 Unterabsatz 2 genannten Bediensteten üben ihre Befugnisse unter Vorlage der in Absatz 2 Unterabsatz 1 genannten Entscheidung aus.

(5) Unionsbetreiber im Bereich Weltraum, die unionseigene Ressourcen betreiben, und Anbieter von Weltraumdiensten gemäß Artikel 48 Absatz 1 Buchstaben b bzw. c müssen sich den durch Entscheidung der Agentur und der Kommission angeordneten Inspektionen vor Ort unterziehen.

(6) Die Bediensteten der zuständigen Behörde des Mitgliedstaats, in dem die Inspektion durchgeführt werden soll, und die von diesen zuständigen Behörden ermächtigten Personen unterstützen auf Ersuchen der Kommission oder der Agentur die in Absatz 2 Unterabsatz 2 genannten Bediensteten. Die Bediensteten der zuständigen Behörden können auf Antrag auch bei den Inspektionen vor Ort anwesend sein.

(7) Die Kommission und die Agentur können von den zuständigen Behörden verlangen, in ihrem Namen spezifische Untersuchungsaufgaben und Inspektionen vor Ort gemäß diesem Artikel und Artikel 50 durchzuführen. Zu diesem Zweck verfügen die zuständigen Behörden mindestens über die in diesem Artikel und in Artikel 50 genannten Befugnisse.

<a id="art-52"></a>
### Artikel 52 – Inspektionen vor Ort außerhalb der Union

(1) Können die Kommission und die Agentur ihre in dieser Verordnung festgelegten Aufgaben nicht durch Interaktion mit den in Artikel 23 genannten gesetzlichen Vertretern der in Artikel 48 Absatz 1 Buchstabe b genannten Anbieter von Weltraumdiensten erfüllen, so können die Kommission und die Agentur Inspektionen vor Ort in den Geschäftsgebäuden, auf Grundstücken oder in Sachen der in Artikel 48 Absatz 1 Buchstabe b genannten Anbieter von Weltraumdiensten, die sich außerhalb der Union befinden, durchführen, wenn alle folgenden Bedingungen erfüllt sind:

  - a) der betreffende Anbieter von Weltraumdiensten stimmt gemäß Artikel 48 Absatz 1 Buchstabe b der Durchführung einer Inspektion in einem Drittland zu und

  - b) die zuständige Drittlandsbehörde wurde von der Agentur offiziell benachrichtigt und hat keine Einwände dagegen erhoben.

(2) Wenn die Kommission und die Agentur auf der Grundlage von Absatz 1 tätig werden, verfügen sie über die Befugnisse gemäß

  - a) Artikel 49;

  - b) Artikel 50 Absatz 4 Buchstaben a, b und c;

  - c) Artikel 51 Absatz 3.

<a id="art-53"></a>
### Artikel 53 – Verfahren für Untersuchungen durch die Agentur

(1) Liegen der Agentur schwerwiegende Hinweise auf Zuwiderhandlungen gegen die in Titel IV festgelegten technischen Anforderungen vor, so leitet die Agentur eine Untersuchung ein.

(2) Die mit der Untersuchung beauftragten Bediensteten haben die Befugnis, nach Artikel 49 Informationen anzufordern, um nach den Artikeln 50 und 51 Untersuchungen und Inspektionen vor Ort durchzuführen.

<a id="art-54"></a>
### Artikel 54 – Maßnahmen infolge einer Untersuchung durch die Agentur

(1) Stellt die Agentur auf der Grundlage der in Artikel 53 Absatz 2 genannten Untersuchung vorläufig fest, dass ein Unionsbetreiber im Bereich Weltraum, der unionseigene Ressourcen betreibt, bzw. ein Anbieter von Weltraumdiensten gemäß Artikel 48 Absatz 1 Buchstaben b und c eine Zuwiderhandlung gegen die in dieser Verordnung festgelegten Vorschriften gemäß Anhang X begangen hat, so unterbreitet die Agentur der Kommission einen Vorschlag, um das Vorliegen einer Zuwiderhandlung gegen die Bestimmungen diese Verordnung festzustellen und eine oder mehrere der in Artikel 55 Absatz 1 Unterabsatz 1 genannten Maßnahmen in Bezug auf den betreffenden Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen oder Anbieter von Weltraumdiensten in der Union gemäß Artikel 48 Absatz 1 Buchstaben b und c zu ergreifen.

    Die Agentur gibt alle Fakten, Vorschriftenverstöße und den vorgeschlagenen Betrag der Geldbuße an.

    Die Kommission kann von sich aus, auf Ersuchen eines Mitgliedstaats oder auf Beschwerde hin jede Zuwiderhandlung gegen die Bestimmungen dieser Verordnung untersuchen.

(2) Bei der Übermittlung des in Absatz 1 Unterabsatz 1 genannten Vorschlags an die Kommission berücksichtigt die Agentur Art und Schwere der Zuwiderhandlung auf der Grundlage ihrer vorläufigen Feststellungen anhand folgender Kriterien:

  - a) die Schwere und Dauer der Zuwiderhandlung sowie die Permanenz des durch die Zuwiderhandlung verursachten Schadens;

  - b) frühere Zuwiderhandlungen, die dieser Unionsbetreiber im Bereich Weltraum, der unionseigene Ressourcen betreibt, begangen hat;

  - c) den materiellen oder immateriellen Schaden, der eventuell oder tatsächlich durch die Zuwiderhandlung verursacht wurde, einschließlich finanzieller oder wirtschaftlicher Verluste und schädlicher Auswirkungen auf andere Dienste, sowie alle relevanten Kriterien bezüglich der Auswirkungen der Zuwiderhandlung, wie die Zahl der betroffenen Nutzer oder die Höhe der einem Dritten infolge dieser Zuwiderhandlung entstandenen Verluste;

  - d) den Vorsatz oder die Fahrlässigkeit des Urhebers der Zuwiderhandlung;

  - e) die Maßnahmen, die der Unionsbetreiber im Bereich Weltraum, der unionseigene Ressourcen betreibt, ergriffen hat, um die unter Buchstabe c genannten materiellen oder immateriellen Schäden zu verhindern oder zu mindern;

  - f) den Umfang der Zusammenarbeit während des Untersuchungsverfahrens, einschließlich der Behinderung von Audits oder Überwachungstätigkeiten nach der Aufdeckung der Zuwiderhandlung;

  - g) die Höhe der von der für die Zuwiderhandlung verantwortlichen natürlichen oder juristischen Person erzielten Gewinne oder vermiedenen Verluste;

  - h) mögliche systemische Folgen, die eine solche Zuwiderhandlung nach sich ziehen kann;

  - i) die Notwendigkeit einer abschreckenden Wirkung von Geldbußen.

(3) Kann die Agentur aufgrund des Ergebnisses einer Untersuchung nach diesem Abschnitt nicht feststellen, ob eine Zuwiderhandlung gegen die Bestimmungen dieser Verordnung vorliegt, so erlässt die Agentur eine Entscheidung als Abschluss der Untersuchung. Die Agentur setzt die Kommission unverzüglich davon in Kenntnis.

<a id="art-55"></a>
### Artikel 55 – Aufsichtsmaßnahmen der Kommission

(1) Nach Eingang des in Artikel 54 Absatz 1 Unterabsatz 1 genannten Vorschlags der Agentur kann die Kommission eine oder mehrere der folgenden Maßnahmen ergreifen:

  - a) das Vorliegen einer Zuwiderhandlung feststellen und den in Artikel 48 Absatz 1 Buchstaben b und c genannten betroffenen Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen oder den betreffenden Anbieter von Weltraumdiensten in der Union auffordern, die Zuwiderhandlung abzustellen;

  - b) erforderlichenfalls auf der Grundlage einer dem ersten Anschein nach festgestellten Zuwiderhandlung einstweilige Maßnahmen verhängen, um einen nicht wiedergutzumachenden Schaden zu vermeiden;

  - c) gemäß Artikel 56 eine Geldbuße oder gegebenenfalls ein Zwangsgeld verhängen;

  - d) die in Artikel 48 Absatz 1 Buchstaben b und c genannte Genehmigung des betreffenden Unionsbetreibers im Bereich Weltraum von unionseigenen Ressourcen bzw. die Registrierung des betreffenden Anbieters von Weltraumdiensten im URSO aussetzen oder zurücknehmen;

  - e) eine Bekanntmachung veröffentlichen, in welcher der Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen oder Artikel 48 Absatz 1 Buchstaben b und c, der für die Zuwiderhandlung verantwortlich ist, und die Art der Zuwiderhandlung angegeben werden.

(2) Bei der Ergreifung der in Absatz 1 genannten Maßnahmen berücksichtigt die Kommission Art und Schwere der Zuwiderhandlung unter Berücksichtigung der in Artikel 54 Absatz 2 genannten Kriterien.

<a id="art-56"></a>
### Artikel 56 – Geldbußen und Zwangsgelder

(1) Schlägt die Agentur gemäß Artikel 54 Absatz 1 Unterabsatz 1 vor, dass die Kommission bei einer Zuwiderhandlung gegen die Bestimmungen dieser Verordnung in Bezug auf einen Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen oder einen Anbieter von Weltraumdiensten gemäß Artikel 48 Absatz 1 Buchstaben b und c eine Geldbuße oder ein Zwangsgeld verhängt, so kann die Kommission im Rahmen des Beschlusses zur Feststellung einer Zuwiderhandlung gemäß den Absätzen 2, 3, 4, 5, 6 und 7 eine Geldbuße oder ein Zwangsgeld verhängen.

(2) Eine Zuwiderhandlung gilt als vorsätzlich begangen, wenn objektive Anhaltspunkte belegen, dass eine Person die Zuwiderhandlung absichtlich begangen hat.

(3) Der Höchstbetrag der in Absatz 1 genannten Geldbuße beträgt das Doppelte des Betrags der Gewinne, die durch den Verstoß erzielt wurden, oder, sofern sich diese beziffern lassen, das Doppelte des Betrags der Verluste, die durch den Verstoß vermieden wurden, oder, falls dies nicht möglich ist, 2 % des weltweiten Gesamtumsatzes einer juristischen Person im Sinne des einschlägigen Unionsrechts im vorangegangenen Geschäftsjahr.

(4) Bei der Festsetzung der Höhe der gemäß Absatz 1 zu verhängenden Geldbuße berücksichtigt die Kommission die in Artikel 54 Absatz 2 genannten Kriterien.

(5) Die Kommission kann regelmäßig zu entrichtende Geldbußen und Zwangsgelder verhängen, um Unionsbetreiber im Bereich Weltraum, die unionseigene Ressourcen betreiben, bzw. Anbieter von Weltraumdiensten gemäß Artikel 48 Absatz 1 Buchstaben b und c zu zwingen, die Zuwiderhandlung abzustellen oder sich einer Untersuchung zu unterziehen und insbesondere die vollständigen Aufzeichnungen, Daten, Verfahren oder sonstiges erforderliches Material vorzulegen und alle anderen Informationen zu ergänzen und zu berichtigen, die im Rahmen einer durch eine Entscheidung nach Artikel 50 eingeleiteten Untersuchung bereitgestellt wurden.

(6) Ein Zwangsgeld muss wirksam und verhältnismäßig sein. Die Zahlung des Zwangsgelds wird für jeden Tag des Verzugs angeordnet.

(7) Ein Zwangsgeld wird für einen Zeitraum von höchstens 6 Monaten nach Bekanntgabe des Beschlusses der Kommission verhängt, es sei denn, bei der Überprüfung dieser Maßnahme wird am Ende des 6-monatigen Zeitraums festgestellt, dass die Maßnahme ihren Zweck nicht erreicht hat.

(8) Die Geldbußen und Zwangsgelder werden dem Gesamthaushaltsplan der Europäischen Union zugewiesen.

(9) In Bezug auf die Verhängung von Geldbußen und Zwangsgeldern gemäß diesem Artikel erlässt die Kommission gemäß Artikel 113 delegierte Rechtsakte zur Ergänzung dieser Verordnung, in denen Folgendes festgelegt wird:

  - a) die detaillierten Kriterien und detaillierte Methodik für die Festsetzung der Höhe der Geldbußen und Zwangsgelder;

  - b) die detaillierten Regeln für Untersuchungen, damit verbundene Maßnahmen und die Berichterstattung sowie die Beschlussfassung einschließlich Bestimmungen zum Recht auf Verteidigung, Akteneinsicht, Rechtsvertretung und Vertraulichkeit sowie befristete Regelungen und

  - c) die Verfahren für die Einziehung von Geldbußen und Zwangsgeldern.

(10) Der Gerichtshof der Europäischen Union besitzt die unbeschränkte Befugnis zur Überprüfung von Entscheidungen, mit denen Geldbußen oder Zwangsgelder verhängt werden. Er kann die verhängten Geldbußen oder Zwangsgelder aufheben, herabsetzen oder erhöhen.

<a id="art-57"></a>
### Artikel 57 – Anspruch auf rechtliches Gehör für Personen, die Gegenstand von Untersuchungen sind

(1) Bevor die Kommission einen Beschluss nach den Artikeln 55 und 56 fasst, bietet sie den Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, und Anbietern von Weltraumdiensten gemäß Artikel 48 Absatz 1 Buchstaben b und c, die Gegenstand des Verfahrens sind, die Gelegenheit, zu den Feststellungen und Gründen, aus denen die Kommission einen Beschluss zu erlassen beabsichtigt, angehört zu werden.

    Die Kommission stützt ihre Entscheidungen nur auf Feststellungen, zu denen sich die Personen, die Gegenstand des Verfahrens sind, äußern konnten.

(2) Vorbehaltlich des berechtigten Interesses anderer Personen an der Wahrung von Geschäftsgeheimnissen haben die Personen, die Gegenstand des Rechtsstreits sind, das Recht auf Einsicht in die Verfahrensakte der Kommission.

    Das Recht auf Akteneinsicht erstreckt sich nicht auf vertrauliche Informationen oder interne vorbereitende Dokumente der Agentur oder der Kommission.

<a id="title-iv"></a>
## Titel IV – TECHNISCHE VORSCHRIFTEN

<a id="title-iv-chapter-i"></a>
## Kapitel I – SICHERHEIT UND NACHHALTIGKEIT IM WELTRAUM

<a id="title-iv-chapter-i-section-1"></a>
## Abschnitt 1 – TRÄGERRAKETEN

<a id="art-58"></a>
### Artikel 58 – Sicherheitsplan für Starts

Startbetreiber aus der Union legen der zuständigen Behörde einen Sicherheitsplan für den Start gemäß Anhang I Nummer 3 vor.

<a id="art-59"></a>
### Artikel 59 – Sicherheits- und Koordinierungsmaßnahmen während des Starts und des Wiedereintritts

(1) Startbetreiber aus der Union ergreifen geeignete Maßnahmen, um das Risiko von Zusammenstößen zwischen der Trägerrakete und Luftfahrzeugen, Seeschiffen oder Raumfahrzeugen sowie Müll in der Umlaufbahn während der Start- und Wiedereintrittsphase zu mindern.

(2) Die Minderungsmaßnahmen gemäß Absatz 1 umfassen:

  - a) die Umsetzung der in Anhang I Nummer 1.1 festgelegten Koordinierungsanforderungen mit den zuständigen Behörden in Bezug auf Flugverkehrsdienste, Anbieter von Weltraumdiensten zur Kollisionsvermeidung: und Anbieter von Flugverkehrsdiensten, die betroffen sein könnten;

  - b) die Durchführung einer Risikobewertung – die Kollisionsvermeidung während des Starts (Launch Collision Avoidance, LCOLA) – gemäß Anhang I Nummer 1.2 und die entsprechende Umsetzung des Startsperrfensters;

  - c) die Berechnung und Begrenzung des Unfallrisikos beim Start und Wiedereintritt gemäß Anhang I Nummer 1.3.

(3) Die Kommission legt im Wege von Durchführungsrechtsakten Folgendes fest:

  - a) die Entwicklung der Methode zur Berechnung von LCOLA auf Grundlage der Kollisionswahrscheinlichkeit, die unter anderem von der Größe des Objekts von Interesse und der Frage, ob das Raumfahrzeug bewohnbar oder aktiv ist, abhängt;

  - b) die Auswahl unter den bestehenden Methoden und Entwicklung eines neuen Berechnungsverfahrens für die kollektive Unfallgefahr aufgrund von Start und Wiedereintritt, wobei die folgenden Elemente gebührend zu berücksichtigen sind:

    - i) alle Phänomene, bei denen ein Risiko katastrophaler Schäden besteht (Aufstiegsphase, Niedergang der Raketenstufe nach der Abkopplung, Wiedereintritt eines in die Umlaufbahn gebrachten Decks in die Atmosphäre, Phase der Rückführung eines wiederverwendbaren Decks);

    - ii) Flugbahnen vor der Fragmentierung (in der Atmosphäre oder im Weltraum) in Abhängigkeit von den in Betracht gezogenen Flugzeiten und Störungen;

    - iii) die entsprechenden Szenarien für Fragmentierung und Müllentstehung beim Wiedereintritt oder zum Zeitpunkt der Neutralisierung der Trägerrakete und der Rückkehr eines beliebigen Elements der Trägerrakete zur Erde;

    - iv) die Verteilung des Mülls am Boden und die Bewertung der Auswirkungen;

    - v) die Zuverlässigkeit der Trägerrakete während der Startphase, gegebenenfalls auch während der Rückführungsphase;

    - vi) die Zuverlässigkeit des Rückholmanövers des in die Umlaufbahn gebrachten Trägerraketenelements im Fall eines kontrollierten Wiedereintritts;

  - c) die Festlegung der Schwellenwerte für die Unfallrisiken gemäß Anhang I Nummer 1.3 Buchstabe b für die genannten Risikoszenarien;

  - d) die Festlegung der Mindestanforderungen an die Koordinierung zwischen dem Startbetreiber aus der Union, dem Anbieter von Weltraumdiensten zur Kollisionsvermeidung, den zuständigen Behörden und den Anbietern von Flugverkehrsdiensten, um die Auswirkungen des Startbetriebs auf andere Flugverkehrsdienste während der Start- und Wiedereintrittsphase zu bewerten und die Störung so gering wie möglich zu halten.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-60"></a>
### Artikel 60 – Flugsicherheitssystem

(1) Trägerraketen müssen entweder Verfolgungsgeräte enthalten oder es müssen Vorrichtungen zur Verfolgung vorhanden sein, die eine Echtzeitüberwachung der Position und Geschwindigkeit der Trägerrakete ermöglichen.

(2) Trägerraketen müssen zumindest mit einem Telemetrie-Datenübertragungssystem zur Überwachung der Leistungsdaten der Trägerrakete ausgestattet sein, es sei denn, die Analyse vor dem Flug ergibt, dass der Flug der Trägerrakete nicht zu einem unbekannten und gefährlichen Verteilungsgebiet führt.

(3) Startbetreiber aus der Union führen eine Risikobewertung durch, um potenzielle Risikoszenarien zu ermitteln und Minderungsmaßnahmen gemäß Anhang I Nummer 2.1 durchzuführen.

(4) Startbetreiber aus der Union müssen ein fahrzeugseitiges System für die Neutralisierung der Trägerrakete gemäß Anhang I Nummer 2.2 hinzufügen.

<a id="art-61"></a>
### Artikel 61 – Eindämmung von Weltraummüll von Trägerraketen

(1) Startbetreiber aus der Union begrenzen das Entstehen von Weltraummüll über folgende Maßnahmen:

  - a) Begrenzung der geplanten Müllfreisetzung auf die Erde während des Nominalbetriebs durch die Durchführungsmaßnahmen gemäß Anhang II Nummer 1.1;

  - b) Schutz vor unbeabsichtigter Fragmentierung anhand der Durchführungsmaßnahmen gemäß Anhang II Nummer 1.2 und Anhang II Nummer 1.3;

  - c) Entsorgung am Ende der Lebensdauer gemäß Anhang II Nummer 2.

(2) Startbetreiber aus der Union legen die folgenden Pläne zur Eindämmung von Weltraummüll vor:

  - a) einen Plan zur Müllbekämpfung gemäß den technischen und betrieblichen Anforderungen gemäß Anhang II Nummer 3.1;

  - b) einen Plan für die Entsorgung am Ende der Lebensdauer gemäß Anhang II Nummer 3.2.

(3) Die Kommission legt im Wege von Durchführungsrechtsakten Folgendes fest:

  - a) den Zeitraum, innerhalb dessen eine in der erdnahen Umlaufbahn (Low Earth Orbit, LEO) eingesetzte Trägerrakete gemäß Anhang II Nummer 1.1.1 Buchstabe e entsorgt werden muss, einschließlich spezifischer Maßnahmen für das pyrotechnische System und den Feststoff- oder Hybridtreibstoff;

  - b) das sichere Gebiet und den sicheren Zeitpunkt für die Entsorgung von Trägerraketen, die in der mittleren Erdumlaufbahn (MEO) eingesetzt werden, gemäß Anhang II Nummer 1.1.1 Buchstabe d, einschließlich spezifischer Maßnahmen für das pyrotechnische System und den Feststoff- oder Hybridtreibstoff;

  - c) den Schwellenwert für die Wahrscheinlichkeit einer unbeabsichtigten Fragmentierung in der Umlaufbahn aufgrund interner Ursachen gemäß Anhang II Nummer 1.2.1;

  - d) die Dauer und den Schwellenwert des Fragmentierungsrisikos aufgrund von Kollisionen gemäß Anhang II Nummer 1.3;

  - e) die Entwicklung der in Anhang II Nummer 2.2 Buchstabe b Ziffer ii genannten Bedingungen für eine kontrolliert zerbrechende Konstruktion („Design for Demise“) von Trägerraketen für den Wiedereintritt in die Atmosphäre und den unkontrollierten Wiedereintritt und

  - f) die Entwicklung der Methode zur Berechnung der Wahrscheinlichkeit einer erfolgreichen Entsorgung und des prozentualen Schwellenwerts gemäß Anhang II Nummer 2.5.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="title-iv-chapter-i-section-2"></a>
## Abschnitt 2 – RAUMFAHRZEUG

<a id="art-62"></a>
### Artikel 62 – Sonderregelung für Raumfahrzeuge für Forschung und Bildung

(1) Raumfahrzeugbetreiber aus der Union, die Forschungs- und Ausbildungsmissionen durchführen, sind von den Anforderungen ausgenommen, die wie folgt festgelegt sind:

  - a) Artikel 66 für Forschungsraumfahrzeuge, die dazu bestimmt sind, in eine Umlaufbahn oberhalb der in besagtem Artikel vorgeschriebenen Grenze und unterhalb von 600 km gebracht zu werden, wobei:

    - i) ein Rückverfolgungssystem eine genaue Positionierung des Raumfahrzeugs ermöglicht und

    - ii) die einschlägigen Dokumente für Weltraummissionen zeigten, warum die Manövrierfähigkeit nicht erhalten blieb;

  - b) Artikel 72 für Raumfahrzeuge, die dazu bestimmt sind, weniger als ein Jahr in der Umlaufbahn zu bleiben;

  - c) Anhang IV Nummer 2.3;

  - d) Anhang IV Nummer 2.5;

  - e) Anhang V Nummer 1.2.1 Buchstabe e Ziffer iv;

  - f) Anhang V Nummer 4.3 Buchstabe f Ziffer iii;

    Für die Zwecke des Unterabsatzes 1 Buchstabe c muss eine Kontaktstelle zur Verfügung stehen, um innerhalb einer angemessenen Einsatzzeit für LEO/MEO/GEO zu reagieren.

    Für die Zwecke des Unterabsatzes 1 Buchstabe d kann der Raumfahrzeugbetreiber des Forschungsraumfahrzeugs der Union den in Artikel 64 Absatz 1 genannten Anbieter von Weltraumdiensten zur Kollisionsvermeidung der Union ersuchen, bei der Bereitstellung der Ephemeriden und Kovarianzen seiner Raumfahrzeuge behilflich zu sein.

    Für die Zwecke des Unterabsatzes 1 Buchstabe e werden bei einer Redundanzverpflichtung die mit der Größe des Raumfahrzeugs verbundenen technischen Beschränkungen berücksichtigt.

(2) Die in Absatz 1 genannten Ausnahmen werden fallweise unter Berücksichtigung der Größe und des Gewichts des Raumfahrzeugs sowie der Dauer und Umlaufbahn der Mission geprüft.

<a id="art-63"></a>
### Artikel 63 – Rückverfolgbarkeit

(1) Raumfahrzeugbetreiber aus der Union stellen sicher, dass ein Raumfahrzeug über die technischen Mittel verfügt, um die Rückverfolgbarkeit und die genaue Bestimmung der Position in der Umlaufbahn gemäß Anhang III Nummer 1 zu ermöglichen.

    Raumfahrzeugbetreiber aus der Union stellen sicher, dass die Systeme im Bodensegment Daten in einem bestehenden anerkannten Datenformat gemäß Anhang III Nummer 2 verarbeiten können.

(2) Die Kommission legt im Wege von Durchführungsrechtsakten den Genauigkeitsgrad fest, der für die Rückverfolgbarkeit von Raumfahrzeugen gemäß Anhang III Nummer 1.1 erforderlich ist. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-64"></a>
### Artikel 64 – Kollisionsvermeidung

(1) Raumfahrzeugbetreiber aus der Union nehmen die Weltraumdienste zur Kollisionsvermeidung in Anspruch, die durch den Anbieter von Weltraumdiensten zur Kollisionsvermeidung bereitgestellt werden, der für die Unterkomponente „Beobachtung und Verfolgung von Objekten im Weltraum (SST)“ gemäß Artikel 58 Absatz 2 der Verordnung (EU) 2021/696 zuständig ist (im Folgenden „Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus der Union“).

(2) Die in Absatz 1 genannte Inanspruchnahme deckt sämtliche Phasen einer Weltraummission ab, einschließlich der Phase des Übergangs in eine höhere Umlaufbahn, von ISOS und des Endes der Lebensdauer, mit Ausnahme der Wiedereintrittsphase.

(3) Während des Betriebs unterrichten Raumfahrzeugbetreiber aus der Union den Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus der Union unverzüglich über Folgendes:

  - a) alle geplanten Änderungen des Betriebs;

  - b) die Entscheidung, die Entsorgungsphase zu beginnen und das Ende der Lebensdauer einzuleiten, indem die einschlägigen Informationen drei Monate vor Beginn des Verfahrens übermittelt werden;

  - c) jegliche ungeplante Änderungen des Betriebs, auch in Bezug auf während der Lebensdauer der Weltraummission und der Entsorgungsphase aufgetretene Probleme, welche die Einhaltung dieser Verordnung beeinträchtigen würden, ohne unnötige Verzögerung.

(4) Raumfahrzeugbetreiber aus der Union müssen die in Anhang IV Nummer 2 festgelegten Anforderungen erfüllen und mit dem Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus der Union im Einklang mit den dort genannten Anforderungen zusammenarbeiten.

(5) Nach Erhalt einer Warnung vor einem Ereignis von hohem Interesse unterrichten Raumfahrzeugbetreiber aus der Union den Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus der Union unverzüglich über alle Maßnahmen, die gemäß Anhang IV Nummer 2 ergriffen wurden, um eine Kollision zu verhindern.

<a id="art-65"></a>
### Artikel 65 – Wiedereintrittsdienste

(1) Raumfahrzeugbetreiber aus der Union übermitteln dem in Artikel 64 Absatz 1 genannten Anbieter von Weltraumdiensten zur Kollisionsvermeidung aus der Union die erforderlichen Daten und Informationen, wie z. B. Positionsbestimmung, Zustand des Raumfahrzeugs und Kommunikationsfähigkeit, um einen genaueren Wiedereintrittsdienst zu ermöglichen, unbeschadet der Übermittlung an die in Artikel 58 Absatz 2 der Verordnung (EU) 2021/696 genannte Stelle, die in der Unterkomponente „Beobachtung und Verfolgung von Objekten im Weltraum (SST)“ für den Wiedereintrittsdienst zuständig ist.

(2) Die in Absatz 1 genannte Stelle, die für den Wiedereintrittsdienst zuständig ist, sorgt für die erforderliche Koordinierung mit den zuständigen Behörden und Anbietern von Flugverkehrsdiensten, um die Auswirkungen des Wiedereintritts auf andere Verkehrsdienste so gering wie möglich zu halten.

<a id="art-66"></a>
### Artikel 66 – Manövrierfähigkeit von Raumfahrzeugen

(1) Raumfahrzeugbetreiber aus der Union stellen sicher, dass ein Raumfahrzeug so konzipiert, hergestellt und betrieben wird, dass dem Raumfahrzeug Manövrierfähigkeiten für Umlaufbahnen mit einer Höhe von mehr als 400 km gewährt und ermöglicht werden.

(2) Die Manövrierfähigkeit gemäß Absatz 1 muss zumindest:

  - a) den Anforderungen in Nummer 2 von Anhang IV entsprechen und die Reaktion auf eine Warnung vor Ereignissen von hohem Interesse gemäß Artikel 64 Absatz 5 ermöglichen;

  - b) die Durchführung der Verwertung am Ende der Lebensdauer gemäß Artikel 70 Absatz 1 Buchstabe c ermöglichen.

      Das Bodensegment muss in der Lage sein, Vorhersagen zur Umlaufbahn zu empfangen und Daten gemäß Anhang III Nummer 2 zu verarbeiten.

<a id="art-67"></a>
### Artikel 67 – Kontaktlistendatenbank für Warnungen vor Ereignissen von hohem Interesse

(1) Die Agentur richtet eine Kontaktlistendatenbank der Union für Warnungen vor Ereignissen von hohem Interesse (im Folgenden „Kontaktlistendatenbank“) ein und verwaltet diese.

(2) Raumfahrzeugbetreiber aus der Union melden der Agentur die Kontaktdaten ihrer für Kollisionsvermeidung und Wiedereintritt zuständigen Beschäftigten, damit sie von der Agentur in die gemäß Absatz 1 eingerichtete Kontaktlistendatenbank aufgenommen werden können.

(3) Die Agentur übermittelt die Kontaktlistendatenbank an den in Artikel 64 Absatz 1 genannten Anbieter von Weltraumdiensten zur Kollisionsvermeidung der Union.

<a id="art-68"></a>
### Artikel 68 – Vorschriften für den Verkehr in der Umlaufbahn

(1) Raumfahrzeugbetreiber aus der Union müssen die Anforderungen an den Verkehr in der Umlaufbahn und die Koordinierung gemäß Anhang IV Nummer 2 erfüllen.

(2) Die Kommission erlässt im Wege von Durchführungsrechtsakten Bestimmungen für Anforderungen an die Kollisionsvermeidung gemäß Anhang IV Nummer 2.

    Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-69"></a>
### Artikel 69 – Positionsbestimmung in der Umlaufbahn

(1) Vor dem Start analysieren Raumfahrzeugbetreiber aus der Union die Wahl der Umlaufbahn und geben die Gründe für die Wahl an.

    Raumfahrzeugbetreiber aus der Union wählen die Umlaufbahn auf der Grundlage einer Analyse unter Berücksichtigung der vorhandenen Raumfahrzeuge und des Mülls in den Umlaufbahnen aus.

(2) Die Kommission entwickelt im Wege von Durchführungsrechtsakten Folgendes:

  - a) spezifische Methoden zur Berechnung der Überlastung der LEO, MEO und GEO;

  - b) Methoden zur Berechnung der Auswahl der Umlaufbahn auf der Grundlage anerkannter und dem Stand der Technik entsprechender Methoden.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-70"></a>
### Artikel 70 – Eindämmung von Weltraummüll

(1) Raumfahrzeugbetreiber aus der Union ergreifen folgende Maßnahmen:

  - a) die Begrenzung der geplanten Freisetzung von Müll auf die Erde während des Nominalbetriebs gemäß Anhang V Nummer 1.1;

  - b) die Begrenzung des Risikos einer unbeabsichtigten Fragmentierung gemäß Anhang V Nummer 1.2 und Anhang V Nummer 1.3;

  - c) den Abschluss der Entsorgung am Ende der Lebensdauer gemäß Anhang V Nummer 3;

  - d) die Durchführung eines Plans zur Reaktion auf Störungen gemäß Anhang V Nummer 4.3;

  - e) die Gewährleistung der Zuverlässigkeit der Konstruktion gemäß Anhang V Nummer 2.1 und

  - f) die Festlegung der Betriebsverfahren für die Qualitäts- und Zuverlässigkeitskontrolle gemäß Anhang V Nummer 2.2.

(2) Raumfahrzeugbetreiber aus der Union erstellen die folgenden Pläne zur Eindämmung von Weltraummüll zum Nachweis der Erfüllung der in Absatz 1 festgelegten Anforderungen:

  - a) einen Plan zur Müllbekämpfung gemäß Anhang V Nummer 4.1;

  - b) einen Plan für die Entsorgung am Ende der Lebensdauer gemäß Anhang V Nummer 4.2;

  - c) einen Plan zur Reaktion auf Störungen gemäß Anhang V Nummer 4.3.

(3) Die Kommission kann Durchführungsrechtsakte erlassen, um

  - a) Maßnahmen zur Begrenzung der Müllentstehung durch Begrenzung der geplanten Müllfreisetzungen nach Anzahl und Dauer in der Umlaufbahn zu entwickeln, einschließlich spezifischer Vorschriften für die Konstruktion pyrotechnischer Geräte und Feststoffraketenmotoren gemäß Anhang V Nummer 1.1;

  - b) Maßnahmen zur Begrenzung des Fragmentierungsrisikos zu entwickeln, um

    - i) die internen Ursachen der Fragmentierung und des Kollisionsrisikos gemäß Anhang V Nummer 1.2.1 Buchstabe a zu begrenzen;

    - ii) die in Anhang V Nummer 1.3 Buchstaben a und b genannten Konstruktions- und Herstellungsanforderungen zu entwickeln, um das Fragmentierungsrisiko aufgrund von Kollisionen zu begrenzen;

    - iii) eine Methode zur Berechnung der Kollisionswahrscheinlichkeit und des Schwellenwerts gemäß Anhang V Nummer 1.3 Buchstaben c und d zu entwickeln;

  - c) die Maßnahmen für das Ende der Lebensdauer festzulegen, indem

    - i) der Schwellenwert für die Wahrscheinlichkeit einer erfolgreichen Entsorgung und der Berechnungsmethode gemäß Anhang V Nummer 3.1.2 und Anhang V Nummer 3.1.3 bestimmt wird;

    - ii) die maximale orbitale Lebensdauer in der LEO vor dem Wiedereintritt gemäß Anhang V Nummer 3.4.2 festgelegt wird;

    - iii) die Anforderungen an den Wiedereintritt für LEO gemäß Anhang V Nummer 3.5.4, Anhang V Nummer 3.5.6 und Anhang V Nummer 3.5.8 entwickelt werden;

    - iv) die spezifischen Anforderungen an den Wiedereintritt für MEO gemäß Anhang V Nummer 3.6 bestimmt werden;

  - d) die technischen Bedingungen für die sanfte Passivierung gemäß Anhang V Nummer 1.2.1 Buchstabe e Ziffer v Nummer 2 und für die Passivierung zum Wiedereintritt gemäß Anhang V Nummer 1.2.1 Buchstabe f festzulegen.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zu erlassen, um die in Anhang V Nummer 3.3 festgelegte Rangfolge zu ändern, damit der technische Fortschritt in Bezug auf ISOS in dieser Rangfolge Berücksichtigung findet und die Rangfolge an den technischen Fortschritt angepasst werden kann.

<a id="art-71"></a>
### Artikel 71 – Verlängerung einer Mission

(1) Möchte ein Raumfahrzeugbetreiber aus der Union eine Weltraummission verlängern, so übermittelt er der zuständigen Behörde spätestens drei Monate vor dem geplanten Ende der betreffenden Weltraummission einen Verlängerungsantrag.

(2) Auf Antrag gemäß Absatz 1 können die zuständigen Behörden beschließen, die Dauer einer Weltraummission, die von einem Raumfahrzeugbetreiber aus der Union durchgeführt wird, über den Zeitraum hinaus zu verlängern, für den die ursprüngliche Genehmigung erteilt wurde.

(3) Die zuständige Behörde genehmigt den Antrag auf Verlängerung der Weltraummission, wenn das Raumfahrzeug noch die Anforderungen des Anhangs V erfüllt.

<a id="art-72"></a>
### Artikel 72 – Licht- und Funkverschmutzung

(1) Raumfahrzeugbetreiber aus der Union erstellen einen Plan mit Maßnahmen, die geeignet sind, die Licht- und Funkverschmutzung gemäß Absatz 2 zu begrenzen.

(2) Die visuelle Helligkeit von Raumfahrzeugen während der gesamten Lebensdauer, einschließlich der Konstruktionsanforderungen für Beschichtungen oder Abschirmungen mit geringer Reflexion, muss mindestens 7 betragen.

    Der in Absatz 1 genannte Plan muss sämtliche folgenden Elemente umfassen:

  - a) eine Beschreibung der technischen und operationellen Interventionen, die der Raumfahrzeugbetreiber aus der Union zur Verringerung der visuellen Helligkeit des Raumfahrzeugs und zur Minimierung der Auswirkung von Satelliten auf astronomische Beobachtungen ergriffen hat;

  - b) eine Beschreibung der technischen und operationellen Interventionen, die der Raumfahrzeugbetreiber aus der Union zur Begrenzung von Störungen von Radioastronomie-Observatorien und zur Minimierung der Auswirkungen von Satelliten auf astronomische Beobachtungen ergriffen hat.

<a id="art-73"></a>
### Artikel 73 – Konstellationen

(1) Raumfahrzeugbetreiber aus der Union, die eine Konstellation, eine Megakonstellation oder eine Gigakonstellation betreiben, müssen

  - a) sicherstellen, dass jedes einzelne Raumfahrzeug über ein Antriebssystem verfügt;

  - b) im Bodensegment einen Katalog der einzelnen Raumfahrzeugbahnen pflegen und täglich Überprüfungen des Kollisionsrisikos durchführen;

  - c) die Sicherheit im Einklang mit den Anforderungen in Anhang VI Nummer 1 in Bezug auf Maßnahmen zur Kollisionsvermeidung innerhalb einer Konstellation gewährleisten;

  - d) die zusätzlichen Berichtspflichten gemäß Anhang VI Nummer 2 erfüllen.

(2) Raumfahrzeugbetreiber aus der Union, die eine Megakonstellation oder Gigakonstellation betreiben, müssen

  - a) bei der Wahl der Umlaufbahn folgende Elemente berücksichtigen:

    - i) die Auswirkungen der Stationierung der gesamten Konstellation auf die Überlastung der Umlaufbahn;

    - ii) vor der Wahl der Umlaufbahn bestehende Konstellationen in der Umlaufbahn;

    - iii) die Gewährleistung, dass die gewählte Umlaufbahn nicht mit der anderer Weltraumobjekte zusammenfällt, was eine große Zahl wiederkehrender und systematischer Konjunktionssituationen implizieren würde;

    - iv) die Gesamtzahl der während der Lebensdauer der Satellitenkonstellation erwarteten Kollisionsvermeidungsmanöver.

  - b) die Folgen von funktionsunfähig lancierten Raumfahrzeugen beschränken, indem Raumfahrzeuge in eine Umlaufbahn gebracht werden, die

    - i) eine kurze Wiedereintrittszeit des Raumfahrzeugs ermöglichen;

    - ii) begrenzte Kollisionsrisiken haben.

  - c) sicherstellen, dass die geforderte Wahrscheinlichkeit einer erfolgreichen Entsorgung gemäß Artikel 70 Absatz 1 Buchstabe c in einem angemessenen Verhältnis zur Anzahl der Raumfahrzeuge steht;

  - d) sicherstellen, dass die in der Umlaufbahn verbrachte Zeit nach dem Ende der Lebensdauer unter der in Anhang V festgelegten Dauer liegt.

(3) Unionsbetreiber im Bereich Weltraum, die eine Gigakonstellation betreiben, legen der zuständigen Behörde während der Konstruktion und des Betriebs eines Raumfahrzeugs einen Plan vor, aus dem hervorgeht, dass der Kraftstoff verfügbar ist, der erforderlich ist, um die hohe Zahl von Manövern im Zusammenhang zur voraussehbaren erforderlichen Kollisionsvermeidung zu bewältigen.

(4) Die Kommission legt im Wege von Durchführungsrechtsakten Folgendes fest:

  - a) das Risiko einer Kollision innerhalb einer Satellitenkonstellation gemäß Anhang VI Nummer 1.2 Buchstabe c;

  - b) eine Begrenzung der Licht- und Funkverschmutzung gemäß Anhang VI Nummer 2.1.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-74"></a>
### Artikel 74 – Anwendbarkeit von Produktanforderungen

In ihren Verträgen mit Lieferantenherstellern stellen Unionsbetreiber im Bereich Weltraum sicher, dass die vertraglich vereinbarten Weltraumobjekte oder gegebenenfalls die Komponenten den in diesem Kapitel festgelegten Konstruktions- und Herstellungsanforderungen entsprechen.

<a id="title-iv-chapter-ii"></a>
## Kapitel II – RESILIENZ DER WELTRAUMINFRASTRUKTUR

<a id="title-iv-chapter-ii-section-1"></a>
## Abschnitt 1 – ALLGEMEINE BESTIMMUNGEN

<a id="art-75"></a>
### Artikel 75 – Verhältnis zur NIS-2-Richtlinie und zur Richtlinie über die Resilienz kritischer Einrichtungen

(1) Hinsichtlich Unionsbetreibern im Bereich Weltraum, die im Zusammenhang mit Weltraumtätigkeiten und Weltraumdiensten, die unter die vorliegende Verordnung fallen, als wesentliche oder wichtige Einrichtungen im Sinne des Artikels 3 der Richtlinie (EU) 2022/2555 gelten, gilt diese Verordnung in Bezug auf Artikel 21 der Richtlinie (EU) 2022/2555 im Zusammenhang mit Risikomanagementmaßnahmen im Bereich der Cybersicherheit als sektorspezifischer Rechtsakt der Union für die Zwecke des Artikels 4 der genannten Richtlinie.

(2) Wurden Unionsbetreiber im Bereich Weltraum gemäß der Richtlinie (EU) 2022/2557 als kritische Einrichtungen eingestuft, so gilt diese Verordnung ergänzend zur Richtlinie (EU) 2022/2557.

(3) Für die Zwecke dieses Kapitels arbeiten die zuständigen Behörden mit den gemäß Artikel 9 Absatz 1 der Richtlinie 2022/2557 benannten oder eingerichteten zuständigen Behörden wie folgt zusammen:

  - a) im Zusammenhang mit der Unterstützung der gemäß der vorliegenden Verordnung durchzuführenden Risikobewertungen nach Artikel 78 Absatz 2 und im Zusammenhang mit der gemäß der Richtlinie (EU) 2022/2557 durchzuführenden Risikobewertungen nach Artikel 12 Absatz 2 Unterabsatz 2 und Artikel 13 Absatz 2;

  - b) wann immer dies für die Zwecke der Gewährleistung der einheitlichen Anwendung der vorliegenden Verordnung und der Richtlinie (EU) 2022/2557 und des Informationsaustauschs, auch für die in den Artikeln 11, 15, 18 und 21 der genannten Richtlinie genannten Zwecke, erforderlich ist.

<a id="title-iv-chapter-ii-section-2"></a>
## Abschnitt 2 – RISIKOMANAGEMENT

<a id="art-76"></a>
### Artikel 76 – Risikomanagement während des Lebenszyklus von Weltraummissionen

(1) Unionsbetreiber im Bereich Weltraum ergreifen alle erforderlichen Maßnahmen, um die Risiken für die Sicherheit von Netz- und Informationssystemen und die Sicherheit der physischen Infrastrukturen und der Umwelt im Einklang mit dem Grundsatz der Verhältnismäßigkeit und unter Berücksichtigung ihres Risikoprofils und ihrer Größe sowie der Art, des Umfangs und der Komplexität ihrer Weltraumtätigkeiten zu bewältigen.

    Die in Unterabsatz 1 genannten Maßnahmen müssen

  - a) umfassend sein und je nach den auszuführenden Aufgaben alle Segmente der Weltrauminfrastruktur einschließlich der Bodeninfrastruktur und deren Systeme und Teilsysteme abdecken;

  - b) angemessen sein und in einem sinnvollen Verhältnis zu den Risiken stehen;

  - c) einem gefahrenübergreifenden Ansatz folgen.

(2) Die in Absatz 1 Unterabsatz 1 genannten Maßnahmen müssen es Unionsbetreibern im Bereich Weltraum ermöglichen,

  - a) die Resilienz der Weltrauminfrastruktur jederzeit zu gewährleisten;

  - b) eine wirksame technische Kontrolle ihrer Weltraummissionen bei gleichzeitiger Gewährleistung eines angemessenen und mit den Zielen und Merkmalen jeder Weltraummission im Einklang stehenden Risikoniveaus und in Übereinstimmung mit den Aufsichtsanweisungen aufrechtzuerhalten.

(3) Unionsbetreiber im Bereich Weltraum berücksichtigen bei der Bewertung des angemessenen und kohärenten Risikoniveaus gemäß Absatz 2 Buchstabe b mindestens die folgenden Kriterien:

  - a) Art und Merkmale der Weltraummission, z. B. ihre Einzelziele, die Umlaufbahn und die Größe der Konstellation;

  - b) die Auswirkungen auf andere Weltraumtätigkeiten;

  - c) die Größe der Einrichtung, das Ausmaß der Risikoexposition und die Wahrscheinlichkeit des Eintretens von Sicherheitsvorfällen und deren Schwere, einschließlich ihrer gesellschaftlichen und wirtschaftlichen Auswirkungen.

(4) Unionsbetreiber im Bereich Weltraum steuern die in Absatz 1 Unterabsatz 1 genannten Risiken, um die digitale und physische Resilienz der Weltrauminfrastruktur während des gesamten Lebenszyklus von Weltraummissionen sicherzustellen, wobei Folgendes gebührend berücksichtigt wird:

  - a) die Konzeptions- und Entwurfsphase, einschließlich der Vorbereitung der Fertigungsphase, wie Missionsanalyse, Systemanalyse, Systemdefinition, Systemdesign, bis zur vollständigen Festlegung der Systeme;

  - b) die Fertigungs- und Prüfphasen wie Herstellung, Montage, Integration, Verifizierung, Validierung und Qualifizierung;

  - c) die Betriebsphase, einschließlich

    - i) Transport, Inbetriebnahme, Start und Eintritt in die vorläufige Umlaufbahn (Launch and Early Orbit Phase, LEOP);

    - ii) Betrieb eines Weltraumobjekts, Routinephase, Tätigkeiten im Zusammenhang mit der Kontrolle, Verwaltung und Überwachung einer Weltraummission und ggf. einschlägige Koordinierung;

    - iii) Instandhaltung des Boden- und Weltraumsegments;

    - iv) der Durchführung von Operationen und Diensten im Weltraum, wie z. B. Reparatur- und Wartungsarbeiten in der jeweiligen Umlaufbahn;

  - d) die Phasen nach dem Ende der Lebensdauer, insbesondere die Phasen Ende der Weltraummission, Passivierung, Entsorgung und Außerbetriebnahme und Entfernung aus der Umlaufbahn;

  - e) unterstützende Tätigkeiten wie Transport, Lagerung, Logistik, Wartungsdienste, Verwaltung der allgemeinen IKT-Infrastruktur.

(5) Unionsbetreiber im Bereich Weltraum errichten, implementieren und unterhalten ein Informationssicherheitsmanagementsystem im Einklang mit den einschlägigen Normen.

    Das in Unterabsatz 1 genannte Informationssicherheitsmanagementsystem ist Teil des Gesamtrisikomanagements der Unionsbetreiber im Bereich Weltraum und wird so implementiert, dass diese gemäß Artikel 78 Absatz 1 Buchstabe a und den in Absatz 2 Buchstabe b festgelegten Grundsätzen effiziente und umfassende Maßnahmen gegen alle Risikoquellen ergreifen können.

(6) Unionsbetreiber im Bereich Weltraum legen eine Strategie und Verfahren fest, um zu bewerten, ob die ergriffenen Risikomanagementmaßnahmen im Bereich der Cybersicherheit wirksam umgesetzt und aktuell gehalten werden, und wenden diese an.

<a id="art-77"></a>
### Artikel 77 – Organisatorische Aspekte

(1) Das Leitungsorgan eines Unionsbetreibers im Bereich Weltraum der Union überwacht die Umsetzung der Risikomanagementmaßnahmen, die ergriffen wurden, um die Einhaltung der in diesem Kapitel festgelegten Anforderungen sicherzustellen, und ist dafür verantwortlich und haftbar.

(2) Unionsbetreiber im Bereich Weltraum richten interne Mechanismen für die Personalsicherheitspolitik ein und überarbeiten und überwachen diese, um sicherzustellen, dass das gesamte Personal die Verantwortlichkeiten im Bereich der Sicherheit im Einklang mit den Aufgaben und Verantwortlichkeiten verstanden hat und diese wahrnimmt. Unionsbetreiber im Bereich Weltraum richten eine Personalstrategie ein, die während der gesamten Einstellungs- und Disziplinarverfahren alle erforderlichen Überprüfungen und Kontrollen gewährleistet.

<a id="art-78"></a>
### Artikel 78 – Risikobewertungen

(1) Während des gesamten Lebenszyklus von Weltraummissionen obliegt es den Unionsbetreibern im Bereich Weltraum

  - a) alle Risikoquellen kontinuierlich zu identifizieren und zu bewerten;

  - b) die identifizierten Risiken regelmäßig zu überprüfen;

  - c) Cybersicherheitslücken, physische Schwachstellen und Sicherheitsvorfälle zu identifizieren und im Hinblick auf die in Absatz 2 genannte Risikobewertung zu analysieren, wenn solche Schwachstellen nicht unverzüglich behoben oder eingedämmt werden können;

  - d) spezielle Risikomanagementpläne für alle ermittelten Cybersicherheitslücken zu erstellen, von denen ein Risiko ausgeht, das über dem in Artikel 76 Absatz 2 Buchstabe b genannten Risikoniveau liegt.

(2) Unionsbetreiber im Bereich Weltraum führen Risikobewertungen gemäß Anhang VII Nummer 1 durch.

(3) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zu erlassen, um diese Verordnung wie folgt zu ergänzen:

  - a) Festlegung – für die Zwecke der in Anhang VII Nummer 1.4 Buchstabe f genannten Risikoszenarien – der Kriterien für die Identifizierung

    - i) kritischer Ressourcen, kritischer Funktionen, kritischer Operationen und kritischer Phasen während des gesamten Lebenszyklus von Weltraummissionen, für die Unionsbetreiber im Bereich Weltraum Sicherheitsrisikoszenarien entwickeln;

    - ii) kritischer Ressourcen und kritischer Funktionen gemäß Artikel 79 Absatz 1 Unterabsatz 1, für die die Stellen, die ein vereinfachtes Risikomanagement anwenden, Sicherheitsrisikoszenarien entwickeln;

  - b) Entwicklung von Risikoszenarien, die auf die Risiken zugeschnitten sind, mit denen sich Unionsbetreiber im Bereich Weltraum bzw. Stellen, die ein vereinfachtes Risikomanagement anwenden, befassen;

  - c) Erstellung eines Mindestkatalogs von Sicherheitszielen, einschließlich der zu berücksichtigenden Risikostufen;

  - d) Entwicklung der Kriterien und der Methodik zur Gewährleistung der Vergleichbarkeit von Risikobewertungen, um die Aufsichtstätigkeiten der zuständigen Behörden („Aufsichtsüberprüfungen“) zu erleichtern;

  - e) Entwicklung von Methoden zur Modellierung von Bedrohungen zur Unterstützung der Risikobewertungen für verschiedene Segmente und Systeme der Weltrauminfrastruktur;

  - f) Entwicklung von Risikomanagementmaßnahmen, die von den Unionsbetreibern im Bereich Weltraum anzuwenden sind.

<a id="art-79"></a>
### Artikel 79 – Vereinfachtes Risikomanagement

(1) Einrichtungen, die dem vereinfachten Risikomanagement nach Artikel 10 Absatz 3 unterliegen, wenden die in Anhang VII Nummer 9 festgelegten Maßnahmen nur in Bezug auf kritische Ressourcen und kritische Funktionen an, die hinsichtlich folgender Risiken erforderlich sind:

    a) Verlust der Kontrolle über Ressourcen mit Antrieb;

    b) Verlust der Kontrolle über Ressourcen, die Interferenzen hervorrufen können, welche die Sicherheit anderer Weltraumoperationen beeinträchtigen könnten.

(2) Die zuständigen Behörden übermitteln der Agentur die Liste der Stellen, die ein vereinfachtes Risikomanagement anwenden.

(3) Die Agentur erstattet der Kommission jährlich Bericht über die Anwendung des vereinfachten Risikomanagements in der gesamten Union. Die Agentur kann Empfehlungen zur Unterstützung der aufsichtlichen Konvergenz im gesamten Binnenmarkt abgeben.

    Die wichtigsten Ergebnisse der in Unterabsatz 1 genannten Berichte werden gegebenenfalls auf die Tagesordnung der Sitzungen des gemäß Artikel 94 Absatz 1 eingerichteten Unionsnetzes für Resilienz im Weltraum gesetzt.

(4) Damit die Bestimmungen dieser Verordnung auf der Grundlage der besten verfügbaren Techniken an den wissenschaftlichen und technischen Fortschritt angepasst werden können, wird der Kommission die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Änderung der in Anhang VII Nummer 9 festgelegten Anforderungen zu erlassen.

<a id="art-80"></a>
### Artikel 80 – Ermittlung und Verwaltung von Informationen und Ressourcen der Weltrauminfrastruktur

(1) Unionsbetreiber im Bereich Weltraum erstellen, pflegen und aktualisieren umfassende Strategien für die Kategorisierung und Verwaltung von Informationen und Ressourcen der Weltrauminfrastruktur.

(2) Unionsbetreiber im Bereich Weltraum identifizieren und dokumentieren Ressourcen gemäß Anhang VII Nummer 2 unter Berücksichtigung der in Artikel 78 Absatz 2 genannten Risikobewertungen und in dem für die Überwachung und Erkennung von Sicherheitsvorfällen gemäß Artikel 83 notwendigen und angemessenen Umfang.

(3) Unionsbetreiber im Bereich Weltraum kategorisieren die Informationen entsprechend den Erfordernissen der Informationssicherheit unter Berücksichtigung mindestens des Folgenden:

  - a) der Notwendigkeit, die Vertraulichkeit, Integrität, Authentizität und Verfügbarkeit von Informationen zu gewährleisten;

  - b) des für die Sicherheitsstufe der jeweiligen Weltraummission erforderlichen Grads der Kritikalität.

(4) Für die Zwecke der Absätze 1, 2 und 3 erstellen und führen Unionsbetreiber im Bereich Weltraum bzw. Stellen, die ein vereinfachtes Risikomanagement in Bezug auf die in Artikel 79 Absatz 1 Unterabsatz 1 genannten kritischen Ressourcen und kritischen Funktionen anwenden, Bestandsverzeichnisse.

    Die in Unterabsatz 1 genannten Bestandsverzeichnisse werden per Weltraummission erstellt, wobei die Herkunft und der aktuelle physische Standort der Ressourcen anzugeben sind, gegebenenfalls einschließlich Benennung eines Cloud-gestützten Dienstes. Die Bestandsverzeichnisse müssen auf dem neuesten Stand sein.

<a id="art-81"></a>
### Artikel 81 – Verwaltung und Kontrolle der Zugangsrechte

(1) Unionsbetreiber im Bereich Weltraum führen die Verwaltung und Kontrolle der Zugangsrechte mithilfe von Identitäts- und Zugangsverwaltungsprotokollen durch.

(2) In den in Absatz 1 genannten Protokollen werden die Bedingungen und Verfahren für die logischen und physischen Zugangsrechte zu Systemen und Ressourcen, auch für den Fernzugriff, festgelegt.

(3) Die in Absatz 1 genannten Identitäts- und Zugangsverwaltungsprotokolle

    a) sind geeignet, den Zugang zum Bodensegment und zu den Zentren für die Steuerung des Weltraumsegments zu sichern;

    b) ermöglichen eine Beschränkung des physischen und logischen Zugangs zu allen kritischen Ressourcen, kritischen Informationen, kritischen Funktionen, kritischen Operationen und gegebenenfalls kritischen Ausrüstungen oder Informationen, die gemäß Artikel 80 Absatz 2 identifiziert wurden;

    c) sind auf Standardeinsätze und Notfallsituationen zugeschnitten, um bei Aktivierung der in Artikel 87 genannten Reaktions- und Wiederherstellungspläne wirksame und rechtzeitige Notfallmaßnahmen zu ermöglichen.

(4) Bei der Festlegung der in Absatz 2 genannten Bedingungen und Verfahren legen Unionsbetreiber im Bereich Weltraum die Erteilung, die kontinuierliche Verwaltung (einschließlich Änderung, Höher- oder Herabstufung), den Widerruf, die Beendigung, die Verifikation und die Überprüfung logischer und physischer Zugriffsrechte für alle autorisierten Geräte, Prozesse und Nutzer dar.

    Diese Bedingungen und Verfahren müssen auf den Grundsätzen „Kenntnis nur, wenn nötig“ und „Prinzip der minimalen Zugriffsrechte“ beruhen (Beschränkung auf das, was erforderlich ist, um eine rechtmäßige und genehmigte Verwendung bzw. Tätigkeit zu gewährleisten).

(5) Die Identitäts- und Zugangsrechte gemäß Absatz 2 werden automatisch widerrufen, wenn die Autorisierungen für Personal oder Geräte ablaufen oder nicht mehr benötigt werden.

(6) Die in Absatz 1 genannten Identitäts- und Zugangsverwaltungsprotokolle gewährleisten einen angemessenen Schutz der gemäß Artikel 80 Absatz 2 identifizierten Informationen und Ressourcen vor Risiken, einschließlich Beschädigung, Missbrauch oder unbefugtem Zugriff oder unbefugter Nutzung.

<a id="art-82"></a>
### Artikel 82 – Physische Resilienz

(1) Unionsbetreiber im Bereich Weltraum ergreifen die in Anhang VII Nummer 3 festgelegten Maßnahmen sowie alle anderen Maßnahmen, die erforderlich und angemessen sind, um die Resilienz der physischen Ressourcen zu gewährleisten, und diese Maßnahmen sind den in Artikel 13 der Richtlinie (EU) 2022/2557 genannten technischen, sicherheitsbezogenen und organisatorischen Maßnahmen mindestens gleichwertig, was die Resilienz der Bodensegmente betrifft.

(2) Wurden Unionsbetreiber im Bereich Weltraum gemäß der Richtlinie (EU) 2022/2557 als kritische Einrichtungen eingestuft, so gilt die vorliegende Verordnung unbeschadet und ergänzend zu jener Richtlinie.

(3) Unionsbetreiber im Bereich Weltraum definieren, schützen und trennen Bereiche, die Ressourcen und Informationen enthalten, welche als sensibel anzusehen sind oder auf der Grundlage der gemäß Artikel 80 Absatz 2 vorgenommenen Identifizierung als kritisch identifiziert sind.

(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Änderung der in Anhang VII Nummer 3 festgelegten Anforderungen zu erlassen, um sie auf der Grundlage der besten verfügbaren Techniken an den wissenschaftlichen und technischen Fortschritt anzupassen.

<a id="art-83"></a>
### Artikel 83 – Erkennung und Überwachung von Sicherheitsvorfällen

(1) Unionsbetreiber im Bereich Weltraum überwachen kontinuierlich das Auftreten von Anomalien und Sicherheitsvorfällen durch Einsatz geeigneter Erkennungssysteme und -mechanismen.

(2) Unionsbetreiber im Bereich Weltraum bzw. Einrichtungen, die das vereinfachte Risikomanagement in Bezug auf die in Artikel 79 Absatz 1 Unterabsatz 1 genannten kritischen Ressourcen und kritischen Funktionen anwenden, stellen sicher, dass die Bodenstationen Zugang zu Erkennungssystemen und -mechanismen haben, die mindestens die in Anhang VII Nummer 4 festgelegten Anforderungen erfüllen.

(3) Das Raumfahrzeug und das Bodensegment sind so zu konfigurieren, dass sie nach Erkennung eines Sicherheitsvorfalls ein Sicherheitsereignis generieren bzw. empfangen, das an ein Teilsystem „Sicherheitsüberwachung“ gesendet wird. Das Teilsystem „Sicherheitsüberwachung“ des Bodensegments ist informationstechnisch von der übrigen Infrastruktur getrennt (logische Trennung).

(4) Unionsbetreiber im Bereich Weltraum stellen sicher, dass die Erkennungssysteme und -mechanismen gemäß den Artikeln 88 und 89 regelmäßig getestet werden.

(5) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Änderung des in Anhang VII Nummer 4 festgelegten Anforderungskatalogs zu erlassen, um ihn auf der Grundlage der besten verfügbaren Techniken an den wissenschaftlichen und technischen Fortschritt anzupassen.

<a id="art-84"></a>
### Artikel 84 – Prävention und Schutz

(1) Unionsbetreiber im Bereich Weltraum passen die gemäß diesem Kapitel erlassenen Maßnahmen zur Cybersicherheit des Raumfahrzeugs und des Bodensegments an die jeweiligen Erfordernisse der Weltraummission an und decken die bei der Bewertung des Sicherheitsrisikos gemäß Artikel 78 Absatz 2 ermittelten Risiken angemessen ab.

(2) Unionsbetreiber im Bereich Weltraum stellen sicher, dass die Netz- und Informationssysteme die folgenden Bedingungen erfüllen:

  - a) Sie genügen den in Anhang VII Nummer 5.1 genannten Anforderungen.

  - b) Sie sind so konfiguriert, dass das Bodensegment die Überwachung der Telemetrie/des Telekommandos am Boden und die Überwachung des Zustands des Raumfahrzeugs ermöglicht.

  - c) Sie ermöglichen den Unionsbetreibern im Bereich Weltraum, eine wirksame technische Kontrolle des Weltraumsegments aufrechtzuerhalten.

(3) Unionsbetreiber im Bereich Weltraum bzw. Stellen, die in Bezug auf die in Artikel 79 Absatz 1 Unterabsatz 1 genannten kritischen Ressourcen und kritischen Funktionen ein vereinfachtes Risikomanagement anwenden, stellen sicher, dass nur zugelassene Geräte mit den Systemen kommunizieren, die für die Kontrolle und Steuerung eines Satelliten und die Konfiguration des Weltraumobjekts zuständig sind.

    Hierzu müssen sie mindestens die Anforderungen gemäß Anhang VII Nummer 5.2 und Anhang VII Nummer 5.3 erfüllen.

(4) Unionsbetreiber im Bereich Weltraum setzen Präventions- und Schutzmaßnahmen um, die erforderlich und angemessen sind, um die Resilienz von Weltraumtätigkeiten zu gewährleisten, indem sie mindestens die in Anhang VII Nummer 5.4 festgelegten Maßnahmen in Bezug auf das Bodensegment ergreifen.

(5) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Änderung der in Anhang VII Nummer 5 festgelegten Anforderungen zu erlassen, um sie auf der Grundlage der besten verfügbaren Techniken an den wissenschaftlichen und technischen Fortschritt anzupassen.

<a id="art-85"></a>
### Artikel 85 – Kryptografie und Verschlüsselung

(1) Auf der Grundlage der in Artikel 78 Absatz 2 genannten Risikobewertung erfüllen Unionsbetreiber im Bereich Weltraum bzw. Stellen, die ein vereinfachtes Risikomanagement in Bezug auf die in Artikel 79 Absatz 1 Unterabsatz 1 genannten kritischen Ressourcen und kritischen Funktionen anwenden, Folgendes:

  - a) Sie legen ein kryptografisches Konzept fest, um die Cybersicherheit der Weltraummissionen zu gewährleisten, indem sie alle relevanten Kriterien wie das Ziel der Weltraummission, die Leistungsmerkmale der Nutzlast, etwaige funktionelle Anforderungen und alle relevanten Bedrohungsszenarien gebührend berücksichtigen.

  - b) Sie wählen kryptografische Mechanismen im Einklang mit den einschlägigen Standards und Empfehlungen der zuständigen Behörden aus.

  - c) Sie setzen Strategien und Verfahren für die Verwendung von Kryptografie und Verschlüsselung für ihre Weltraummissionen um.

(2) Unionsbetreiber im Bereich Weltraum legen eine Lebenszyklusmanagementstrategie für die kryptografischen Schlüssel fest, in der Vorschriften für den Schutz und die Verwaltung kryptografischer Schlüssel festgelegt werden, um deren sichere Erzeugung, Nutzung, Speicherung, Verteilung und Entsorgung zu gewährleisten.

(3) Für die Zwecke des Absatzes 1 Unterabsatz 1 erfüllen Unionsbetreiber im Bereich Weltraum mindestens die folgenden Anforderungen:

  - a) Ende-zu-Ende-Authentifizierung der Verbindungen zwischen den Satellitenkontrollzentren und dem Weltraumsegment unter Verwendung kryptografischer Mechanismen zwischen dem Bodensegment und dem Satelliten;

  - b) Sicherstellung der Verschlüsselung der Telekommandos unter Berücksichtigung der in Artikel 78 Absatz 2 genannten Risikobewertungen und gemäß den Empfehlungen aus Aufsichtsüberprüfungen;

  - c) Gewährleistung der Verfügbarkeit kryptografischer Schlüssel und Parameter, die für die Umsetzung der in Artikel 87 genannten Reaktions- und Wiederherstellungspläne erforderlich sind, durch redundante kryptografische Ausrüstung oder durch die Umsetzung einer Schlüsselhinterlegung.

(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zu erlassen, um die Nutzung kryptografischer Produkte und damit zusammenhängender Schlüsselverwaltungsprodukte oder -dienste durch Unionsbetreiber im Bereich Weltraum weiter zu ergänzen, die im Rahmen der gemäß Artikel 49 der Verordnung (EU) 2019/881 angenommenen europäischen Schemata für die Cybersicherheitszertifizierung zertifiziert wurden, um durch diese Ergänzungen den Schutz der Telemetrie und der Telekommandos zu gewährleisten.

<a id="art-86"></a>
### Artikel 86 – Backup-Management und Redundanzen

(1) Unionsbetreiber im Bereich Weltraum bzw. Stellen, die ein vereinfachtes Risikomanagement in Bezug auf die in Artikel 79 Absatz 1 Unterabsatz 1 genannten kritischen Ressourcen und kritischen Funktionen anwenden, sorgen für eine solide und umfassende Strategie für das Backup-Management, um eine Wiederherstellung der Netz- und Informationssysteme zu ermöglichen und bei minimalen Ausfallzeiten und begrenzten Maßnahmen zur Beseitigung der Störung und zum Ausgleich von Verlusten die Wiederherstellungsprozesse und die Rückgewinnung von Daten nach der Aktivierung der Reaktions- und Notfallwiederherstellungsmaßnahmen zu erleichtern.

    In dieser Strategie sind die dem Backup-Management unterliegenden Daten, die Häufigkeit der Sicherungen sowie die angewandten Wiedergewinnungs- und Wiederherstellungsverfahren und -methoden festgelegt.

(2) Unionsbetreiber im Bereich Weltraum stellen sicher, dass die Datensicherungssysteme die Sicherheit der Netz- und Informationssysteme und die Vertraulichkeit, Integrität, Authentizität und Verfügbarkeit von Daten nicht gefährden.

(3) Unionsbetreiber im Bereich Weltraum bzw. Stellen, die in Bezug auf die in Artikel 79 Absatz 1 Unterabsatz 1 genannten kritischen Ressourcen und kritischen Funktionen ein vereinfachtes Risikomanagement anwenden, stellen sicher, dass die relevanten Komponenten der Netz- und Informationssysteme im Bodensegment ausreichend redundant ausgelegt sind.

    Sie gewährleisten insbesondere Folgendes:

  - a) Redundanzen für andere Elemente als die Netz- und Informationssysteme in der erforderlichen Weise, um die Betriebskontinuität sicherzustellen, z. B. Redundanzen der Stromversorgung in Form von Generatoren für sekundäre Verarbeitungsstandorte;

  - b) dass redundante Elemente und die Sicherung in der erforderlichen Weise auf verschiedene geografische Standorte verteilt werden;

  - c) eine angemessene Überlebensfähigkeit des Weltraumsegments ohne Eingreifen, um eine rasche Wiederherstellung nach Sicherheitsvorfällen wie Cyberangriffen, Katastrophen, Ausfällen sowie einer unbeabsichtigten Unterbrechung der Dienste zu ermöglichen.

(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zu erlassen, um die Anforderungen an die Sicherung, die erforderlich sind, um eine angemessene Überlebensfähigkeit des Weltraumsegments zu gewährleisten und eine rasche Wiederherstellung nach Sicherheitsvorfällen zu ermöglichen, genauer festzulegen, damit die Bestimmungen dieser Verordnung auf der Grundlage der besten verfügbaren Techniken an den wissenschaftlichen und technischen Fortschritt angepasst werden können.

<a id="art-87"></a>
### Artikel 87 – Strategie zur Fortführung des Geschäftsbetriebs und Reaktions- und Wiederherstellungspläne

(1) Im Rahmen ihres Risikomanagements legen Unionsbetreiber im Bereich Weltraum Maßnahmen zur Bewältigung von Sicherheitsvorfällen und für das Krisenmanagement fest und dokumentieren diese. Die Maßnahmen werden in einer strukturierten Strategie zur Fortführung des Geschäftsbetriebs festgelegt, die mittels maßgeschneiderter Reaktions- und Wiederherstellungspläne umgesetzt wird.

(2) Die in Absatz 1 genannten Reaktions- und Wiederherstellungspläne müssen es den Unionsbetreibern im Bereich Weltraum ermöglichen, rasch und wirksam auf Sicherheitsvorfälle zu reagieren und deren nachteilige Auswirkungen einzudämmen.

(3) Die von Unionsbetreibern im Bereich Weltraum ergriffenen Krisenmanagementmaßnahmen bauen auf den im Weltraumsegment und im Bodensegment getroffenen Maßnahmen auf, einschließlich Redundanzen und Backups, um insbesondere Folgendes abzumildern:

  - a) Naturkatastrophen;

  - b) Betriebsunfälle;

  - c) Unterbrechung von Versorgungseinrichtungen, insbesondere während der Betriebsphase;

  - d) Ausfall der Stromerzeugung, Stromausfälle und Störungen und Änderungen der Konditionierung der betreffenden Ausrüstung;

  - e) Ausfall physischer Ressourcen im Bodensegment, einschließlich des Ausfalls von Missionskontrollzentren, des Ausfalls von Satellitenkontrollzentren und des Ausfalls der terrestrischen Zusammenschaltung zwischen ihnen;

  - f) Störungen der Boden-Weltraum-, Weltraum-Boden- und Weltraum-Weltraum-Funkfrequenzverbindungen;

  - g) veränderte oder kompromittierte Teile des Bodensegments, auch in Bezug auf die kryptografischen Schlüssel.

      Bei der Umsetzung der Anforderungen gemäß Unterabsatz 1 tragen Unionsbetreiber im Bereich Weltraum der Notwendigkeit Rechnung, eine wirksame technische Kontrolle des Weltraumsegments aufrechtzuerhalten, die Kontinuität der Dienste sicherzustellen und die Bereiche, in denen Dienste nicht verfügbar sind, so gering wie möglich zu halten.

(4) Unionsbetreiber im Bereich Weltraum stellen sicher, dass das Personal, das an der Durchführung von Maßnahmen zur Fortführung des Geschäftsbetriebs und der Umsetzung von Reaktions- und Wiederherstellungsplänen beteiligt ist, umfassende und angemessene Schulungen erhalten hat, wie sie zur Erfüllung seiner Aufgaben erforderlich sind.

<a id="art-88"></a>
### Artikel 88 – Prüfung

(1) Unionsbetreiber im Bereich Weltraum erstellen, pflegen und überprüfen als integralen Bestandteil ihres Risikomanagements ein Prüfprogramm für die Netz- und Informationssysteme.

(2) Das in Absatz 1 genannte Prüfprogramm umfasst Prüfkampagnen, die alle erforderlichen Tests umfassen, insbesondere unter Berücksichtigung der Risikobewertung gemäß Artikel 78 Absatz 2.

(3) Unionsbetreiber im Bereich Weltraum stellen sicher, dass sie vor dem Start bzw. im Fall von Satelliten, die Teil einer Konstellation sind, vor dem Start der ersten Gruppe von Satelliten und danach mindestens alle drei Jahre bedrohungsorientierte Penetrationstests (Threat Led Penetration Testing, TTLPT) durchführen.

    In dem Plan für Prüfer, die TLPT durchführen, sind der Umfang und die Methodik der TLPT, die für die Durchführung dieser Tests zuständige Stelle und die Eindämmungsstrategie für alle Risiken, die die Durchführung von TLPT mit sich bringen kann, darzulegen.

    Prüfer, die TLPT durchführen, müssen folgende Anforderungen erfüllen:

  - a) Sie sind von höchster Eignung und Reputation;

  - b) sie verfügen über alle fachlichen und organisatorischen Fähigkeiten und weisen spezifisches Fachwissen auf dem Gebiet der Penetrationstests nach;

  - c) sie legen ein unabhängiges Zuverlässigkeitszeugnis oder einen Prüfbericht vor;

  - d) sie legen einen Abhilfeplan zur Behandlung der festgestellten Risiken vor.

    Prüfer außerhalb der Unternehmensstruktur von Unionsbetreibern im Bereich Weltraum müssen von einer Akkreditierungsstelle eines Mitgliedstaats zertifiziert sein oder förmliche Verhaltenskodizes oder ethische Rahmenbedingungen einhalten. Sie müssen in vollem Umfang durch eine entsprechende Berufshaftpflichtversicherung gegen das Risiko von Fehlverhalten und Fahrlässigkeit versichert sein.

    Unionsbetreiber im Bereich Weltraum überwachen Systemausfälle und Anomalien, die während der Prüfprozesse beobachtet werden, und bewerten ihre Kritikalität.

<a id="art-89"></a>
### Artikel 89 – Lernen und Ausbildung

(1) Unionsbetreiber im Bereich Weltraum schulen ihr Personal in angemessener Weise gemäß den Absätzen 2, 3, 4, 5 und 6.

(2) Das gesamte Personal von Unionsbetreibern im Bereich Weltraum muss angemessen und kontinuierlich geschult werden und die in Anhang VII Nummer 7.1 genannten Schulungen absolvieren.

(3) Unionsbetreiber im Bereich Weltraum stellen sicher, dass das gesamte Personal maßgeschneiderte Schulungen gemäß Anhang VII Nummer 7.2 erhält.

(4) Das für Unionsbetreiber im Bereich Weltraum tätige Sicherheitspersonal muss über die erforderlichen Sicherheitskompetenzen verfügen und angemessen geschult sein.

(5) Personal von Unionsbetreibern im Bereich Weltraum, das in sensiblen Umgebungen tätig ist oder sensible Ausrüstungen oder Daten handhabt, wird regelmäßig hinsichtlich der besten Methoden und Verfahren für die Wahrnehmung dieser Aufgaben geschult.

(6) Unionsbetreiber im Bereich Weltraum nutzen die aus dem Umgang mit Sicherheitsvorfällen gewonnenen Erkenntnisse zur Aktualisierung von Plänen zur Fortführung des Geschäftsbetriebs und von Schulungen und Prüfprogrammen für das Personal.

<a id="art-90"></a>
### Artikel 90 – Krisenkommunikation und Offenlegungspolitik

(1) Unionsbetreiber im Bereich Weltraum richten eine Krisenkommunikationsstrategie ein, die eine verantwortungsvolle Offenlegung erheblicher Sicherheitsvorfälle ermöglicht und auf jede der folgenden Kategorien ausgerichtet und darauf zugeschnitten ist:

  - a) Personal, das an der Wahrnehmung von Risikomanagementaufgaben, insbesondere an Reaktions- und Reaktions- und Wiederherstellungsmaßnahmen, beteiligt ist;

  - b) anderes Personal als das unter Buchstabe a genannte Personal, soweit die Kommunikation mit diesem Personal nach dem Grundsatz „Kenntnis nur, wenn nötig“ als angemessen erachtet wird, um eine allgemeine Sensibilisierung im Unternehmen zu gewährleisten;

  - c) Kunden, um sie vor erheblichen Cyberbedrohungen zu warnen und dafür zu sensibilisieren;

  - d) im Fall von Satelliten, die Nutzlasten Dritter tragen, und wenn ein Sicherheitsvorfall negative Auswirkungen auf den Betrieb der Satellitenplattform hat, auf das betreffende Drittunternehmen gemäß einer vorab festgelegten Vereinbarung und gemäß den Anweisungen in ihrem Reaktions- und Notfallwiederherstellungsplan.

(2) Mindestens eine Person in der Unternehmensstruktur von Unionsbetreibern im Bereich Weltraum ist für die Umsetzung der in Absatz 1 genannten Kommunikationsstrategie verantwortlich und nimmt die Funktion eines Medienbeauftragten wahr.

<a id="art-91"></a>
### Artikel 91 – Umgang mit Sicherheitsvorfällen

(1) Unionsbetreiber im Bereich Weltraum richten einen Prozess für die Behandlung von Sicherheitsvorfällen ein und setzen ihn um, der es ihnen ermöglicht, Sicherheitsvorfälle unverzüglich zu erkennen, zu identifizieren, zu behandeln und darauf zu reagieren und erhebliche Sicherheitsvorfälle gemäß Artikel 93 zu melden.

    Unionsbetreiber im Bereich Weltraum legen Rollen und Zuständigkeiten in Bezug auf die verschiedenen Arten von Sicherheitsvorfällen fest, die an die verschiedenen Risikoszenarien angepasst sind.

(2) Unionsbetreiber im Bereich Weltraum stellen sicher, dass zumindest die erheblichen Sicherheitsvorfälle unverzüglich dem leitenden Risikomanagement-Personal gemeldet werden.

    Das Leitungsorgan erhält regelmäßig, wie vom leitenden Informationssicherheitsbeauftragten, vom Sicherheitsbeauftragten oder vom leitenden Risikomanagement-Beauftragten festzulegen, ausreichende Informationen über den erheblichen Sicherheitsvorfall, eine Folgenabschätzung, Informationen über die ergriffenen Reaktions- und Wiederherstellungsmaßnahmen sowie etwaige zusätzliche Kontrollen und Verfahren, die bei der Weiterverfolgung dieses erheblichen Sicherheitsvorfalls festzulegen sind.

(3) Wenn ein Satellit Nutzlasten Dritter trägt und ein Sicherheitsvorfall negative Auswirkungen auf den Betrieb der Satellitenplattform hat, unterrichten Unionsbetreiber im Bereich Weltraum das betreffende Drittunternehmen und befolgen die Anweisungen, die in den in Unterabsatz 2 genannten vordefinierten Vereinbarungen sowie in den Reaktions- und Wiederherstellungsplänen festgelegt sind.

    Um einen schnellen und effektiven Umgang mit Sicherheitsvorfällen zu gewährleisten, schließen Unionsbetreiber im Bereich Weltraum Vereinbarungen mit Dritten, für die ein Satellit eine Nutzlast trägt.

(4) Unionsbetreiber im Bereich Weltraum untersuchen die Ursachen von Sicherheitsvorfällen, um künftige Sicherheitsvorfälle zu verhindern.

<a id="art-92"></a>
### Artikel 92 – Risikomanagement in der Lieferkette

(1) Unionsbetreiber im Bereich Weltraum richten einen Rahmen für das Risikomanagement in der Lieferkette ein. Ihre Verträge mit Lieferantenherstellern und Dienstleistern enthalten Aspekte im Zusammenhang mit der Sicherheit der Lieferkette, insbesondere in Bezug auf die Anforderungen an die Informationssicherheit.

(2) Unionsbetreiber im Bereich Weltraum stützen ihr Risikomanagement in der Lieferkette auf eine Strategie zur Verringerung der Risiken in der Lieferkette, die mindestens die in Anhang VII Nummer 6 genannten Maßnahmen umfasst.

(3) Unionsbetreiber im Bereich Weltraum erstellen ein Verzeichnis zumindest der kritischen Ressourcen aus Drittländern, die unter Berücksichtigung der in Artikel 78 Absatz 2 genannten Risikobewertung erforderlich sind, zum Zwecke der Aufrechterhaltung einer wirksamen technischen Kontrolle des Weltraumobjekts, wie z. B. der Umlaufbahnkontrolle, um die Analyse des Grads der Abhängigkeit der jeweiligen Weltraummissionen von den betreffenden Ressourcen zu unterstützen.

(4) Damit die Bestimmungen dieser Verordnung auf der Grundlage der besten verfügbaren Techniken an den wissenschaftlichen und technischen Fortschritt angepasst werden können, wird der Kommission die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Änderung des in Anhang VII Nummer 6 festgelegten Anforderungskatalogs zu erlassen.

<a id="title-iv-chapter-ii-section-3"></a>
## Abschnitt 3 – MELDUNG VON SICHERHEITSVORFÄLLEN

<a id="art-93"></a>
### Artikel 93 – Meldung erheblicher Sicherheitsvorfälle

(1) Unionsbetreiber im Bereich Weltraum melden der in Artikel 34 Absatz 4 der Verordnung (EU) 2021/696 genannten Struktur erhebliche Sicherheitsvorfälle, die sich auf unionseigene Ressourcen auswirken.

(2) Unbeschadet des Absatzes 3 melden Unionsbetreiber im Bereich Weltraum den in Artikel 28 Absatz 1 genannten zuständigen Behörden erhebliche Sicherheitsvorfälle, die die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen betreffen. Die in Artikel 28 Absatz 1 genannten zuständigen Behörden übermitteln der Agentur wiederum eine Zusammenfassung jedes gemeldeten Sicherheitsvorfalls.

(3) Gelten Unionsbetreiber im Bereich Weltraum als wesentliche oder wichtige Einrichtungen im Sinne der Anhänge I oder II der Richtlinie (EU) 2022/2555 , so erfolgt die Meldung nach Absatz 2 über die gemäß Artikel 10 Absatz 1 der Richtlinie 2022/2555 eingerichteten Computer-Notfallteams oder gegebenenfalls die gemäß Artikel 8 Absatz 1 der Richtlinie 2022/2555 eingerichtete zuständige Behörde, die unverzüglich alle einschlägigen gemeldeten Informationen an die in Artikel 28 Absatz 1 der genannten Richtlinie genannten zuständigen Behörden weiterleitet, einschließlich aller technischen Unterstützung und Rückmeldungen, die diese Computer-Notfallteams oder Behörden den Betreibern im Bereich Weltraum gemäß Artikel 23 der genannten Richtlinie zur Verfügung gestellt haben.

    Wurden Unionsbetreiber im Bereich Weltraum gemäß der Richtlinie (EU) 2022/2557 als kritische Einrichtungen eingestuft, so legen die Mitgliedstaaten fest, ob die in Unterabsatz 1 genannte Berichterstattung von den Unionsbetreibern im Bereich Weltraum direkt an die in Artikel 28 Absatz 1 genannten zuständigen Behörden oder an die in Artikel 15 der genannten Richtlinie genannten Behörden oder auf andere Weise erfolgt.

    Absatz 7 gilt in diesem Fall entsprechend für die zu übermittelnden Informationen.

(4) Für Unionsbetreiber im Bereich Weltraum, die als wesentliche oder wichtige Einrichtungen im Sinne der Anhänge I oder II der Richtlinie (EU) 2022/2555 gelten oder gemäß der Richtlinie (EU) 2022/2557 als kritische Einrichtungen eingestuft werden, lässt die in den Absätzen 2 und 3 genannte Meldepflicht die in Artikel 23 der Richtlinie (EU) 2022/2555 bzw. in Artikel 15 Absätze 1 und 2 der Richtlinie (EU) 2022/2557 vorgesehenen Meldepflichten unberührt.

(5) Unbeschadet der technischen Beiträge, der Beratung, der Abhilfemaßnahmen und der anschließenden Folgemaßnahmen, die gegebenenfalls im Einklang mit dem nationalen Recht von den Computer-Notfallteams gemäß Artikel 11 der Richtlinie (EU) 2022/2555 bereitgestellt werden können, können die zuständigen Behörden den Unionsbetreibern im Bereich Weltraum Rückmeldung geben, indem sie relevante anonymisierte Informationen über Cyberbedrohungen zur Verfügung stellen und Abhilfemaßnahmen oder Wege zur Minimierung und Minderung potenzieller negativer Auswirkungen über Grenzen hinweg erörtern.

(6) Ein Sicherheitsvorfall gilt als erheblich, wenn

  - a) er eine schwerwiegende Störung des Betriebs der von Unionsbetreibern im Bereich Weltraum durchgeführten Weltraumtätigkeiten oder der erbrachten Dienste oder erhebliche finanzielle Verluste für die betreffenden Unionsbetreiber im Bereich Weltraum verursacht hat oder verursachen kann;

  - b) er andere natürliche oder juristische Personen durch erhebliche materielle oder immaterielle Schäden beeinträchtigt hat oder beeinträchtigen kann.

(7) Unionsbetreiber im Bereich Weltraum übermitteln in Bezug auf die in Absatz 1 genannte Anforderung der Agentur bzw. in Bezug auf die in Absatz 2 genannte Anforderung den zuständigen Behörden die folgenden Informationen:

  - a) unverzüglich, in jedem Fall aber innerhalb von 12 Stunden nach Kenntnisnahme des erheblichen Sicherheitsvorfalls in Bezug auf unionseigene Ressourcen und innerhalb von 24 Stunden für die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen eine Frühwarnung, aus der hervorgeht, ob der erhebliche Sicherheitsvorfall möglicherweise durch rechtswidrige oder böswillige Handlungen verursacht wurde oder ob er grenzüberschreitende Auswirkungen haben könnte;

  - b) unverzüglich, in jedem Fall aber innerhalb von 72 Stunden nach Kenntnisnahme des erheblichen Sicherheitsvorfalls, eine Meldung über den Sicherheitsvorfall, in der die unter Buchstabe a genannten Informationen aktualisiert werden, und legen eine erste Bewertung des erheblichen Sicherheitsvorfalls, einschließlich seines Schweregrads und seiner Auswirkungen, sowie, soweit verfügbar, die Kompromittierungsindikatoren vor;

  - c) auf Ersuchen der zuständigen Behörde oder gegebenenfalls der Agentur einen Zwischenbericht mit relevanten Statusaktualisierungen;

  - d) spätestens einen Monat nach Übermittlung der Meldung des Sicherheitsvorfalls gemäß Buchstabe b einen Abschlussbericht, der Folgendes enthält:

    - i) eine ausführliche Beschreibung des erheblichen Sicherheitsvorfalls, einschließlich seines Schweregrads und seiner Auswirkungen;

    - ii) Angaben zur Art der Bedrohung bzw. zugrunde liegenden Ursache, die wahrscheinlich diesen erheblichen Sicherheitsvorfall ausgelöst hat;

    - iii) Angaben zu den getroffenen und laufenden Abhilfemaßnahmen;

    - iv) gegebenenfalls die grenzüberschreitenden Auswirkungen des erheblichen Sicherheitsvorfalls;

  - e) wenn ein erheblicher Sicherheitsvorfall zum Zeitpunkt der Vorlage des Abschlussberichts gemäß Buchstabe d noch nicht abgeschlossen ist, zu diesem Zeitpunkt einen Fortschrittsbericht sowie einen Abschlussbericht innerhalb eines Monats nach dem Datum der Behandlung des erheblichen Sicherheitsvorfalls.

    Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Ergänzung dieser Verordnung zu erlassen, in denen die Kriterien festgelegt werden, anhand deren bestimmt wird, was eine schwerwiegende Störung des Betriebs von Weltraumtätigkeiten oder der von einem Unionsbetreiber im Bereich Weltraum erbrachten Dienste gemäß Absatz 6 Buchstabe a darstellt, einschließlich der einschlägigen Wesentlichkeitsschwellen.

(8) Der Kommission wird die Befugnis übertragen, gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren Durchführungsrechtsakte zu erlassen, um den Inhalt der gemäß Absatz 7 zu meldenden Informationen genauer festzulegen und die Muster und Verfahren für die Übermittlung dieser Informationen festzulegen.

<a id="art-94"></a>
### Artikel 94 – Unionsnetz für Resilienz im Weltraum

(1) Das Unionsnetz für Resilienz im Weltraum (im Folgenden „EUSRN“) wird eingerichtet, um die Koordinierung und den Austausch zwischen der Agentur und den zuständigen Behörden bei der Erfüllung ihrer jeweiligen Mandate in Bezug auf unionseigene Ressourcen bzw. die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen zu unterstützen.

(2) Das EUSRN hat folgende Aufgaben:

  - a) Sicherstellung kohärenter Ansätze der zuständigen Behörden bei der Beratung und Unterstützung gemäß Artikel 93 Absatz 5 und Unterstützung der Unionsbetreiber im Bereich Weltraum bei der Gewährleistung einer kohärenten Überwachung und Bewältigung erheblicher Sicherheitsvorfälle;

  - b) im Hinblick auf erhebliche Sicherheitsvorfälle, die die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen beeinträchtigen, negative Auswirkungen auf die Funktionsweise des Weltraumprogramms der Union gemäß Artikel 1 der Verordnung (EU) 2021/696 zu verhindern und zu diesem Zweck die erforderliche Koordinierung zu fördern und den Erlass von Maßnahmen durch die Kommission und die Agentur zu unterstützen, die erforderlich sind, um diese negativen Auswirkungen im Rahmen der durch die Artikel 28, 29 und 34 der Verordnung (EU) 2021/696 übertragenen Mandate zu mindern, damit die in Artikel 4 Absatz 1 Buchstabe c der genannten Verordnung festgelegten Ziele erreicht werden können;

  - c) Gewährleistung der Kohärenz der gemäß Artikel 34 Absatz 6 und Artikel 42 der Verordnung (EU) 2021/696 ergriffenen nationalen Maßnahmen zum Schutz der Ressourcen von Infrastruktur im Hoheitsgebiet der Mitgliedstaaten in den Bodensegmenten, die integraler Bestandteil des Weltraumprogramms der Union sind;

  - d) Erörterung aller relevanten Entwicklungen in Bezug auf Risiken, die sich auf die Ressourcen der Weltrauminfrastruktur auswirken, Förderung eines kohärenten Ansatzes bei der Überwachung und Bewältigung von Cyberrisiken für den Weltraumsektor in der Union, Erörterung bewährter Verfahren und Austausch von Informationen über einschlägige Resilienzmaßnahmen;

  - e) Organisation gemeinsamer Sitzungen mit der gemäß Artikel 14 Absatz 1 eingesetzten NIS-Kooperationsgruppe oder mit dem gemäß Artikel 16 Absatz 1 der Richtlinie (EU) 2022/2555 eingerichteten EU-CyCLONe zum Austausch einschlägiger Informationen im Zusammenhang mit dem Weltraumsektor über Cyberbedrohungen, Sicherheitsvorfälle, Schwachstellen, Sensibilisierungsinitiativen, Schulungen, Übungen und Kompetenzen, Kapazitätsaufbau, Normen und technische Spezifikationen.

(3) Das EUSRN setzt sich aus Vertretern der zuständigen Behörden, der Kommission, der Agentur und des Europäischen Auswärtigen Dienstes (EAD) zusammen.

    Gegebenenfalls kann die Kommission oder die Agentur Vertreter anderer Organe, Agenturen oder Einrichtungen der Union, insbesondere der Agentur der Europäischen Union für Cybersicherheit (ENISA), der Europäischen Verteidigungsagentur (EDA) oder des Militärstabs der Europäischen Union (EUMS) zu bestimmten Sitzungen des EUSRN einladen.

(4) Das EUSRN tauscht regelmäßig Informationen mit dem in Artikel 15 der Richtlinie (EU) 2022/2555 genannten Netzwerk von Computer-Notfallteams (im Folgenden „CSIRTs-Netz“), der ENISA und dem in Artikel 16 der genannten Richtlinie genannten Europäischen Netz der Verbindungsorganisationen für Cyberkrisen (EU-CyCLONe) aus und erstattet diesen Bericht, um Lageaktualisierungen und Bewertungen in Bezug auf erhebliche Sicherheitsvorfälle, die sich auf die in Artikel 5 Absatz 1 Nummer 21 der vorliegenden Verordnung genannten Ressourcen auswirken, bereitzustellen und etwaige Folgen erheblicher Sicherheitsvorfälle für andere Sektoren und Dienste, die in den Anwendungsbereich jener Richtlinie fallen, zu erörtern.

(5) Die Kommission sorgt für die Koordinierung zwischen dem EUSRN und der nach Artikel 19 der Richtlinie (EU) 2022/2557 eingesetzten Gruppe für die Resilienz kritischer Einrichtungen bzw. zwischen dem EUSRN und der nach Artikel 14 der Richtlinie (EU) 2022/2555 eingesetzten Kooperationsgruppe.

(6) Das EUSRN tritt regelmäßig, jedoch mindestens jährlich zusammen. Die Agentur führt den Vorsitz in den technischen Arbeitsgruppen.

    Zusätzlich zu den regelmäßigen Sitzungen gemäß Unterabsatz 1 hält das EUSRN alle 18 Monate eine ordentliche Tagung ab, die der Erleichterung der strategischen Zusammenarbeit im Weltraumbereich und dem Austausch einschlägiger Aktualisierungen und Analysen dient. Die Kommission führt den Vorsitz in den ordentlichen Tagungen.

<a id="title-iv-chapter-ii-section-4"></a>
## Abschnitt 4 – INFORMATIONSAUSTAUSCH UND SENSIBILISIERUNG

<a id="art-95"></a>
### Artikel 95 – Informationsaustausch über Cyberbedrohungen

(1) Unionsbetreiber im Bereich Weltraum können auf freiwilliger Basis untereinander einschlägige Informationen im Bereich der Cybersicherheit austauschen, einschließlich einschlägiger Informationen über Cyberangriffe, Cyberbedrohungen, elektronische Eingriffe wie Störfälle, Spoofing, Informationen über Kompromittierungsindikatoren, gegnerische Taktiken, Techniken und Verfahren, Beinahe-Vorfälle, Schwachstellen, bedrohungsspezifische Informationen sowie Cybersicherheitswarnungen und Empfehlungen für die Konfiguration von Cybersicherheitsinstrumenten zur Aufdeckung von Cyberangriffen, sofern

  - a) dieser Informationsaustausch darauf abzielt, Sicherheitsvorfälle zu verhindern, aufzudecken, darauf zu reagieren oder sich von ihnen zu erholen oder ihre Folgen einzudämmen;

  - b) durch diesen Informationsaustausch das Cybersicherheitsniveau und die allgemeine Resilienz der Unionsbetreiber im Bereich Weltraum erhöht wird, insbesondere, indem Aufklärungsarbeit über Cyberbedrohungen geleistet wird, die Fähigkeit solcher Bedrohungen, sich zu verbreiten, eingedämmt bzw. verhindert und die Entwicklung von Abwehrkapazitäten und des gemeinsamen Wissensstands bezüglich der Beseitigung von Schwachstellen, Techniken zur Erkennung, Eindämmung und Verhütung von Bedrohungen, Eindämmungsstrategien, Reaktions- und Wiederherstellungsphasen unterstützt wird oder indem die gemeinsame Forschung im Bereich Cyberbedrohung zwischen öffentlichen und privaten Einrichtungen gefördert wird;

  - c) dieser Informationsaustausch in vertrauenswürdigen Gemeinschaften von Unionsbetreibern im Bereich Weltraum stattfindet;

  - d) dieser Informationsaustausch durch Vereinbarungen umgesetzt wird, die den potenziell sensiblen Charakter der ausgetauschten Informationen schützen und die Verhaltensregeln unterliegen, in deren Rahmen die Wahrung des Geschäftsgeheimnisses und der Regeln zum Schutz personenbezogener Daten im Einklang mit der Verordnung (EU) 2016/679 und die Leitlinien für die Wettbewerbspolitik vollumfänglich befolgt werden.

(2) Die in Absatz 1 Buchstabe d genannten Vereinbarungen

  - a) legen die Bedingungen für den Zugang zu Vereinbarungen über den Informationsaustausch und die Regeln für die Teilnahme an solchen Vereinbarungen sowie die Art der auszutauschenden Informationen fest;

  - b) geben die operativen Aspekte an, wie z. B. die Nutzung spezieller IKT-Plattformen und Automatisierungsinstrumente;

  - c) legen die Einzelheiten der Beteiligung von Behörden an den Vereinbarungen über den Informationsaustausch und die Funktion fest, in der diese Behörden an solchen Vereinbarungen teilnehmen können.

(3) Unionsbetreiber im Bereich Weltraum unterrichten die zuständigen Behörden über ihre Beteiligung an den in Absatz 1 genannten Vereinbarungen über den Austausch von Informationen im Bereich der Cybersicherheit, wenn sie solche Vereinbarungen abschließen und aus diesen Vereinbarungen ausscheiden.

(4) Die Kommission erleichtert mit Unterstützung der Agentur den Abschluss von Vereinbarungen über den Austausch von Informationen im Bereich der Cybersicherheit gemäß Absatz 1 Buchstabe d, indem sie die Tätigkeiten des EU-Weltrauminformationsaustausch- und -analysezentrums unterstützt oder fördert.

<a id="title-iv-chapter-iii"></a>
## Kapitel III – ÖKOLOGISCHE NACHHALTIGKEIT VON WELTRAUMTÄTIGKEITEN

<a id="art-96"></a>
### Artikel 96 – Umweltfußabdruck von Weltraumtätigkeiten

(1) Nachhaltigkeit umfasst Nachhaltigkeit im Weltraum und Nachhaltigkeit auf der Erde (ökologische Nachhaltigkeit).

(2) Unionsbetreiber im Bereich Weltraum, mit Ausnahme der in Artikel 10 Absatz 4 genannten, berechnen den Umweltfußabdruck der von ihnen durchgeführten Weltraumtätigkeiten.

(3) Unionsbetreiber im Bereich Weltraum verpflichten ihre Anbieter vertraglich, alle Daten zur Verfügung zu stellen, die Unionsbetreiber im Bereich Weltraum benötigen, um der in Absatz 2 genannten Verpflichtung nachzukommen.

(4) Im Rahmen des Genehmigungsantrags gemäß Artikel 6 müssen die Antragsteller den zuständigen Behörden eine Erklärung zur Berechnung des Umweltfußabdrucks vorlegen.

(5) Mit der Erklärung zur Berechnung des Umweltfußabdrucks wird bescheinigt, dass Unionsbetreiber im Bereich Weltraum gemäß Artikel 97 den Umweltfußabdruck der von ihnen geplanten Weltraumtätigkeiten berechnet haben.

(6) Der Erklärung zur Berechnung des Umweltfußabdrucks gemäß Absatz 4 ist Folgendes beizufügen:

  - a) ein Zertifikat über den Umweltfußabdruck, das gemäß Artikel 98 Absatz 2 ausgestellt wird;

  - b) die Umweltfußabdruck-Studie zur Unterstützung der Ergebnisse der Erklärung zur Berechnung des Umweltfußabdrucks;

  - c) die aggregierten und disaggregierten Datensätze auf der Grundlage des gemäß Absatz 2 berechneten Umweltfußabdrucks;

  - d) der Nachweis der Übermittlung der aggregierten und disaggregierten Datensätze an die Kommission gemäß Artikel 99 Absatz 1 Unterabsatz 1.

(7) Die Erklärung zur Berechnung des Umweltfußabdrucks enthält folgende Informationen:

  - a) den Namen, den eingetragenen Handelsnamen oder die eingetragene Handelsmarke der Unionsbetreiber im Bereich Weltraum, ihre Postanschrift und ihre elektronischen Kommunikationsmittel;

  - b) Informationen über die Art der geplanten Weltraumtätigkeiten und die Art der Produkte, Stoffe oder Materialien, für die die Erklärung zur Berechnung des Umweltfußabdrucks gilt;

  - c) den Nachweis, dass der Umweltfußabdruck im Einklang mit den Berechnungs- und Überprüfungsvorschriften des gemäß Artikel 97 Absatz 4 erlassenen Durchführungsrechtsakts berechnet und überprüft wurde;

  - d) die Umweltfußabdruck-Leistungsklasse, in die das Raumfahrzeug fällt, gemäß den Vorschriften des gemäß Artikel 97 Absatz 4 erlassenen Durchführungsrechtsakts.

    Der Kommission wird die Befugnis übertragen, gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren Durchführungsrechtsakte zu erlassen, um die Vorlagen und den Inhalt der gemäß Absatz 6 Unterabsatz 1 zu meldenden Informationen festzulegen.

(8) Bis zum 31. Dezember 2031 sind die folgenden Unionsbetreiber im Bereich Weltraum von den Verpflichtungen gemäß den Artikeln 96, 97, 98, 99 und 100 ausgenommen:

  - a) kleine Unternehmen;

  - b) Forschungs- und Bildungseinrichtungen.

<a id="art-97"></a>
### Artikel 97 – Berechnung des Umweltfußabdrucks und Überprüfung der Weltraumtätigkeiten

(1) Der Umweltfußabdruck von Weltraumtätigkeiten umfasst alle Weltraummissionen, die in jeder Erdumlaufbahn, einschließlich „Friedhofsorbits“, durchgeführt werden.

(2) Die Berechnung nach Artikel 96 Absatz 2 erfasst alle Tätigkeiten, die während des gesamten Lebenszyklus einer Weltraummission durchgeführt werden, auch in den Anfangsphasen, wie Entwurf und Entwicklung, während der Herstellungsphase, in der Betriebsphase und in den Phasen am Ende der Lebensdauer.

(3) Der Umweltfußabdruck der Weltraumtätigkeiten im Rahmen des Weltraumprogramms der Union und des Programms der Union für sichere Konnektivität umfasst die in Artikel 3 Absatz 1 Buchstaben a bis c und e der Verordnung (EU) 2021/696 und in Artikel 1 der Verordnung (EU) 2023/588 genannten Komponenten.

(4) Der Kommission wird die Befugnis übertragen, gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren Durchführungsrechtsakte zu erlassen, um die Methode für die Berechnung und Überprüfung des Umweltfußabdrucks von Weltraumtätigkeiten unter Berücksichtigung wissenschaftlich fundierter Bewertungsmethoden und der einschlägigen internationalen Normen, die mit der Empfehlung (EU) 2021/2279 der Kommission^(32)^(18) in Einklang stehen, festzulegen. Diese Durchführungsrechtsakte werden überprüft, um wissenschaftlichen und technologischen Entwicklungen Rechnung zu tragen und dem technischen Fortschritt zu folgen.

<a id="art-98"></a>
### Artikel 98 – Zertifikat über den Umweltfußabdruck

(1) Bei der Beantragung einer Genehmigung gemäß Artikel 7 Absatz 1 muss ein Antragsteller im Besitz eines Zertifikats sein, aus dem hervorgeht, dass der Umweltfußabdruck seiner vorgesehenen Weltraumtätigkeiten gemäß den Anforderungen des Artikels 96 Absatz 2 berechnet wurde.

(2) Das in Absatz 1 genannte Zertifikat wird von einer qualifizierten technischen Stelle für Weltraumtätigkeiten mit technischer Bewertung, einschließlich Verifizierung und Validierung, für die Zwecke der Artikel 96, 97, 98, 99 und 100 ausgestellt.

<a id="art-99"></a>
### Artikel 99 – Übermittlung von Datensätzen an die Datenbank der Union zum Umweltfußabdruck

(1) Bevor Antragsteller eine Genehmigung gemäß Artikel 7 Absatz 1 beantragen, übermitteln sie der Kommission die aggregierten und disaggregierten Datensätze gemäß Artikel 96 Absatz 6 Buchstabe c.

    Die Kommission übernimmt diese Datensätze in die Datenbank der Union, in der Umweltfußabdruck-Daten gespeichert werden, und stellt den Antragstellern einen Eingangsnachweis aus.

(2) Innerhalb von zwei Wochen nach dem Datum der Mitteilung der Entscheidung über deren Registrierung im Unionsregister der Weltraumobjekte an Drittlandsbetreiber im Bereich Weltraum und internationale Organisationen übermittelt die Agentur der Kommission zwecks Integration in die Datenbank der Union, in der Umweltfußabdruck-Daten gespeichert werden, die aggregierten und disaggregierten Datensätze gemäß Artikel 96 Absatz 6 Buchstabe c, die diese Anbieter von Weltraumdiensten gemäß Artikel 15 Absatz 1 Unterabsatz 1 oder Artikel 15 Absatz 2 in ihrem Antrag auf Registrierung im Unionsregister der Weltraumobjekte eingereicht haben.

    Die Kommission stellt einen Eingangsnachweis aus.

(3) Die Kommission gewährleistet die Vertraulichkeit der Daten in den disaggregierten Datensätzen.

(4) Die in Absatz 1 genannten aggregierten Datensätze werden von der Kommission über die Datenbank der Union zum Umweltfußabdruck öffentlich zugänglich gemacht.

<a id="art-100"></a>
### Artikel 100 – Verwendung disaggregierter Datensätze für die Politikgestaltung

(1) Die Kommission verwendet die in Artikel 99 genannten disaggregierten Datensätze ausschließlich für die Zwecke der Politikgestaltung, zur Bereitstellung regulatorischer Aktualisierungen und zur Erstellung abgeleiteter Datensätze.

(2) Unionsbetreiber im Bereich Weltraum, Drittlandsbetreiber im Bereich Weltraum und internationale Organisationen behalten das uneingeschränkte Eigentum an den Daten, die in den gemäß Artikel 99 übermittelten aggregierten und disaggregierten Datensätzen enthalten sind.

(3) Die Union erwirbt das weltweite ausschließliche Eigentumsrecht an den abgeleiteten Datensätzen, die auf der Grundlage der in Absatz 1 genannten disaggregierten Datensätze erstellt wurden.

<a id="title-iv-chapter-iv"></a>
## Kapitel IV – OPERATIONEN UND DIENSTE IM WELTRAUM (ISOS)

<a id="art-101"></a>
### Artikel 101 – ISOS

(1) Unionsbetreiber im Bereich Weltraum, die ISOS durchführen, müssen die in diesem Artikel und in Anhang VIII festgelegten Anforderungen ab dem 1. Januar 2034 erfüllen.

(2) Bezüglich unionseigener Ressourcen müssen Raumfahrzeuge oberhalb der Mini-Satellitenklasse, die von Unionsbetreibern im Bereich Weltraum betrieben werden, über eine technische Mindestkapazität für den Empfang von Weltraumdiensten verfügen.

(3) Zur Gewährleistung der in Absatz 2 genannten technischen Mindestkapazität wird ein von Unionsbetreibern im Bereich Weltraum betriebenes Kundenraumfahrzeug mit speziellen Schnittstellen für Raumfahrzeuge (Spacecraft Service Interfaces, SSI) ausgestattet.

(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 113 delegierte Rechtsakte zur Ergänzung dieser Verordnung zu erlassen, indem sie Folgendes festlegt:

  - a) die wichtigsten Merkmale des speziellen Betriebsmodus für den Dienst, der ein kooperatives Verhalten des Kundenraumfahrzeugs gewährleistet und das Risiko von Kollisionen und Fehlfunktionen nach dem Dienst minimiert;

  - b) wenn Weltraummüll-Objekte andere Raumfahrzeuge gefährden und das Risiko einer Verschmutzung der Umlaufbahn erhöhen, die Anforderungen, die notwendig sind, um die Entfernung von Müll aus der Umlaufbahn mittels ISOS (aktive Beseitigung von Weltraummüll) zu ermöglichen, einschließlich der Anforderungen, die für das Betriebskonzept gelten.

(5) Die Kommission legt im Wege von Durchführungsrechtsakten Folgendes fest:

  - a) die Gestaltungsgrundsätze für die spezielle Schnittstelle für Raumfahrzeuge gemäß Absatz 3;

  - b) Entwurfsgrundsätze für zusammensetzbare und austauschbare funktionale Satellitenmodule (Composable and Exchangeable Functional Satellite Modules, SatAPPs), die mit einem Raumfahrzeug verbunden werden können, um neue Funktionen oder Nutzlasten von Raumfahrzeugen unter Verwendung von speziellen Schnittstellen für Raumfahrzeuge bereitzustellen.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

<a id="title-iv-chapter-v"></a>
## Kapitel V – VORSCHRIFTEN FÜR DEN VERKEHR IN DER UMLAUFBAHN

<a id="art-102"></a>
### Artikel 102 – Aufsichtsüberprüfung und Aktualisierungen durch die Kollisionsvermeidungsstelle

(1) Eine zuständige Behörde kann den in Artikel 64 Absatz 1 genannten Unionsanbieter von Weltraumdiensten zur Kollisionsvermeidung auffordern, ihr im Rahmen der jährlichen Berichterstattung oder spezifischer Untersuchungen, die bei Unions-Raumfahrzeugbetreibern durchgeführt werden, aktuelle Informationen über ihre Raumfahrzeuge zur Verfügung zu stellen.

(2) Nach Eingang einer solchen Aufforderung meldet der in Artikel 64 Absatz 1 genannte Unionsanbieter von Weltraumdiensten zur Kollisionsvermeidung der zuständigen Behörde, ob

  - a) die vom Unions-Raumfahrzeugbetreiber ergriffenen Maßnahmen die Anforderungen, die in den in Artikel 70 Absatz 2 Unterabsatz 1 genannten Plänen zur Eindämmung von Weltraummüll dargelegt sind, in allen Phasen der Weltraummission erfüllen;

  - b) die Orbitposition der gewählten Umlaufbahn gemäß Artikel 69 entspricht;

  - c) der Unions-Raumfahrzeugbetreiber die Anforderungen des Artikels 64 Absätze 1, 2, 3 und 4 und gegebenenfalls des Artikels 101 Absatz 3 erfüllt.

<a id="art-103"></a>
### Artikel 103 – Bedingungen für Kollisionsvermeidungsmanöver bei Ereignissen von hohem Interesse

(1) Veröffentlicht die in Artikel 64 Absatz 1 genannte Kollisionsvermeidungsstelle eine Warnung vor einem Ereignis von hohem Interesse zwischen zwei manövrierfähigen Raumfahrzeugen und beschließt sie, dass eines der beiden betroffenen Raumfahrzeuge ein Kollisionsvermeidungsmanöver durchführen muss, so beruht das von ihr vorgeschlagene Manöver auf folgenden Grundsätzen:

  - a) Dem Schutz von Fahrzeugen mit Besatzung wird in größtmöglichem Umfang Rechnung getragen;

  - b) das anfängliche Kollisionsrisiko wird um mindestens eine Größenordnung unter die Manöverschwelle für die Warnung vor einem Ereignis von hohem Interesse gesenkt und

  - c) es dürfen keine unangemessenen Risiken von Sekundärkollisionen entstehen.

(2) Sind beide Raumfahrzeuge bei der in Artikel 64 Absatz 1 genannten Kollisionsvermeidungsstelle registriert, so bemühen sich die Unions-Raumfahrzeugbetreiber, sich innerhalb einer angemessenen Frist auf eine Strategie zur Umsetzung des in Absatz 1 genannten Kollisionsvermeidungsmanövers unter der Regie dieser Kollisionsvermeidungsstelle zu verständigen.

(3) Kann innerhalb einer angemessenen Frist keine Einigung gemäß Absatz 2 erzielt werden, so schlägt die in Artikel 64 Absatz 1 genannte Kollisionsvermeidungsstelle eine Handlungsstrategie vor. In dieser Strategie werden Vorfahrtsregeln unter Berücksichtigung mindestens des Folgenden eingehalten:

  - a) Schutz des bemannten Fahrzeugs;

  - b) Beteiligung eines Raumfahrzeugs, das Teil einer Konstellation ist;

  - c) operative Kapazität für Kollisionsvermeidungsmanöver;

  - d) Zustand des Raumfahrzeugs;

  - e) die Exzentrizität der Umlaufbahn des Raumfahrzeugs;

  - f) das Alter des Raumfahrzeugs;

  - g) Phase und Art der jeweiligen Weltraummission.

(4) Ist eines der beiden Raumfahrzeuge nicht bei der in Artikel 64 Absatz 1 genannten Kollisionsvermeidungsstelle registriert, so nimmt diese Stelle Kontakt zu dem jeweiligen Raumfahrzeug auf.

(5) Im Fall einer erfolgreichen Kontaktaufnahme gemäß Absatz 4 bemüht sich die in Artikel 64 Absatz 1 genannte Kollisionsvermeidungsstelle in größtmöglichem Umfang um Folgendes:

  - a) Austausch von Informationen über die Mittel und Methoden zur Berechnung des Kollisionsrisikos;

  - b) Weitergabe aller erforderlichen Daten und Berechnungsergebnisse zur Vermeidung einer Kollision;

  - c) in Zusammenarbeit mit den Betreibern beider Raumfahrzeuge: Festlegung der besten Manöver zur Kollisionsvermeidung unter Berücksichtigung der in Absatz 3 genannten Elemente des Manöver-Aktionsplans.

(6) Sind die in Absatz 4 genannten Kontakte erfolglos oder kann nicht innerhalb eines angemessenen Zeitraums Kontakt aufgenommen werden, so empfiehlt die in Artikel 64 Absatz 1 genannte Kollisionsvermeidungsstelle dem Unions-Raumfahrzeugbetreiber eine Strategie für Maßnahmen, die mindestens die Einhaltung der in Absatz 1 genannten Grundsätze gewährleistet, und unterrichtet den anderen Unions-Raumfahrzeugbetreiber über die beabsichtigte Maßnahme.

<a id="title-iv-chapter-vi"></a>
## Kapitel VI – NORMUNG UND GEMEINSAME SPEZIFIKATIONEN

<a id="art-104"></a>
### Artikel 104 – Normen

(1) Die Kommission beauftragt gemäß Artikel 10 Absatz 1 der Verordnung (EU) Nr. 1025/2012 eine oder mehrere europäische Normungsorganisationen damit, Normen für die folgenden grundlegenden Anforderungen auszuarbeiten:

  - a) die Anforderungen gemäß Artikel 72 Absatz 2 Unterabsatz 1 zum Nachweis der Einhaltung von Artikel 72 Absatz 1;

  - b) die Anforderungen gemäß Artikel 25 Absatz 5 Unterabsatz 1 zum Nachweis der Einhaltung von Artikel 25 Absatz 2.

      Bei der Ausarbeitung der in Unterabsatz 1 genannten Normungsanträge kann die Kommission bestehende oder in Entwicklung befindliche europäische oder internationale Normen berücksichtigen, um die Entwicklung von Normen im Einklang mit der Verordnung (EU) Nr. 1025/2012 zu vereinfachen.

(2) Sind die in Absatz 3 genannten Bedingungen erfüllt, so erlässt die Kommission Durchführungsrechtsakte zur Festlegung gemeinsamer Spezifikationen für die technischen Anforderungen, mit denen die Mittel zur Erfüllung der in Absatz 1 Unterabsatz 1 genannten grundlegenden Anforderungen bereitgestellt werden.

(3) Die in Absatz 2 genannten Durchführungsrechtsakte werden in folgenden Fällen erlassen, in denen die Kommission gemäß Artikel 10 Absatz 1 der Verordnung (EU) Nr. 1025/2012 eine oder mehrere europäische Normungsorganisationen ersucht hat, eine Norm für die in Absatz 1 Unterabsatz 1 genannten grundlegenden Anforderungen auszuarbeiten, und eine der folgenden Situationen eintritt:

  - a) Anforderungen sind nicht durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst;

  - b) Anforderungen sind durch harmonisierte Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht worden sind, oder durch Teile dieser Normen erfasst, aber die Anwendung dieser Normen oder Teile davon führt zu einer Nichteinhaltung der grundlegenden Anforderungen, oder

  - c) die Kommission ist der Auffassung, dass dringende Bedenken ausgeräumt werden müssen.

    Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Beratungsverfahren erlassen.

<a id="title-v"></a>
## Titel V – GLEICHWERTIGKEITSBESCHLÜSSE, INTERNATIONALE ÜBEREINKÜNFTE UND VORSCHRIFTEN IN BEZUG AUF INTERNATIONALE ORGANISATIONEN

<a id="art-105"></a>
### Artikel 105 – Gleichwertigkeit

(1) Die Kommission kann auf der Grundlage einer eingehenden Bewertung im Wege von Durchführungsrechtsakten gemäß Artikel 114 Absatz 2 einen Gleichwertigkeitsbeschluss erlassen, in dem sie feststellt, dass der Rechts- und Aufsichtsrahmen eines Drittlands sicherstellt, dass die in diesem Drittland niedergelassenen Drittlandsbetreiber im Bereich Weltraum rechtsverbindliche Anforderungen erfüllen, die den Anforderungen dieser Verordnung gleichwertig sind und in diesem Drittland einer wirksamen Aufsicht und Durchsetzung unterliegen.

(2) Der Rechts- und Aufsichtsrahmen eines Drittlands gilt nur dann als gleichwertig mit dieser Verordnung, wenn er mindestens die folgenden Bedingungen erfüllt:

  - a) Die in diesem Drittland niedergelassenen Drittlandsbetreiber im Bereich Weltraum unterliegen einer Genehmigung und wirksamen und kontinuierlichen Aufsichts- und Durchsetzungsmaßnahmen;

  - b) die in diesem Drittland niedergelassenen Drittlandsbetreiber im Bereich Weltraum unterliegen rechtsverbindlichen Vorschriften, die den Anforderungen des Artikels 15 gleichwertig sind, und

  - c) der Rechts- und Aufsichtsrahmen dieses Drittlands sieht ein wirksames gleichwertiges System für die Anerkennung von Anbietern von Weltraumdiensten vor, die nach den Rechtsvorschriften des Drittlands zugelassen werden.

(3) Die Kommission kann an die Gleichwertigkeitsbeschlüsse besondere Bedingungen knüpfen, z. B. wenn Umfang und Geltungsbereich der weltraumgestützten Daten oder der Weltraumdienste, die von Drittlandsbetreibern im Bereich Weltraum bereitgestellt werden, für die Union voraussichtlich von strategischer Bedeutung sind, oder um sicherzustellen, dass die Kommission, die Agentur und die zuständigen Behörden über die erforderlichen Instrumente verfügen, um Aufsichtsarbitrage zu verhindern.

    Im Beschluss ist anzugeben, ob er für einen bestimmten Zeitraum gilt.

(4) Die Kommission unterrichtet das Europäische Parlament und den Rat jährlich über die Gleichwertigkeitsbeschlüsse, die die Kommission im Berichtsjahr gefasst oder zurückgezogen hat.

(5) Die Agentur schließt mit den jeweils zuständigen Drittlandbehörden, deren Rechts- und Aufsichtsrahmen als im Sinne des Absatzes 1 gleichwertig anerkannt wurde, Vereinbarungen über die Zusammenarbeit.

    In diesen Vereinbarungen wird zumindest Folgendes festgelegt:

  - a) Die Mechanismen für den Informationsaustausch zwischen der Agentur und den zuständigen Aufsichtsbehörden der betreffenden Drittländer, einschließlich des Zugangs zu allen von der Agentur angeforderten Informationen über die in den Drittländern zugelassenen Drittlandsbetreiber im Bereich Weltraum;

  - b) die Mechanismen für eine unverzügliche Benachrichtigung der Agentur, wenn eine zuständige Drittlandsbehörde der Auffassung ist, dass die Drittlandsbetreiber im Bereich Weltraum, die die Agentur gemäß Artikel 24 im URSO registriert hat, gegen die Genehmigungsbedingungen in diesem Drittstaat oder gegen andere Rechtsvorschriften verstoßen, zu deren Einhaltung diese Drittlandsbetreiber im Bereich Weltraum verpflichtet sind;

  - c) die Verfahren für die Koordinierung der Tätigkeiten, einschließlich Untersuchungen und Vor-Ort-Inspektionen, die die Agentur in Zusammenarbeit mit den zuständigen Behörden der Mitgliedstaaten durchführen kann, nachdem sie die zuständige Behörde des Drittlandes ordnungsgemäß darüber unterrichtet hat.

(6) Die Kommission überwacht in Zusammenarbeit mit der Agentur, ob der Rechts- und Aufsichtsrahmen eines Drittlands den Anforderungen dieser Verordnung fortgesetzt gleichwertig ist.

    Ist der Rechts- und Aufsichtsrahmen eines Drittlands nicht mehr gleichwertig, so hebt die Kommission den betreffenden Gleichwertigkeitsbeschluss auf.

<a id="art-106"></a>
### Artikel 106 – Internationale Übereinkünfte mit Drittländern

(1) Die Union kann Abkommen über die Zusammenarbeit mit Drittländern in unter diese Verordnung fallenden Angelegenheiten schließen, insbesondere in Bezug auf

  - a) die Erleichterung der gegenseitigen Anerkennung von Vorschriften in Angelegenheiten, die unter diese Verordnung fallen;

  - b) die Erleichterung der gegenseitigen Anerkennung technischer Bewertungen, die von qualifizierten technischen Stellen für Weltraumtätigkeiten sowie von einschlägigen Behörden und technischen Stellen von Drittländern durchgeführt werden;

  - c) die Festlegung der Einzelheiten und Verfahren für die Ausnahmeregelung für Startdienste gemäß Artikel 19;

  - d) die Festlegung der Bedingungen für die Nutzung von Weltraumdiensten oder weltraumgestützten Daten in der Union, die von einem Drittlandsbetreiber im Bereich Weltraum bereitgestellt werden, bei dem es sich um eine staatliche Stelle handelt oder der militärische Ressourcen der Weltrauminfrastruktur betreibt oder besitzt, auch für zivile Zwecke.

(2) Die Agentur kann mit den einschlägigen Aufsichtsbehörden von Drittländern, die nicht in Absatz 1 Buchstabe b genannt sind, zusammenarbeiten und vorbehaltlich der Genehmigung durch die Kommission mit diesen Behörden oder mit Einrichtungen internationaler Organisationen Absichtserklärungen und Arbeitsvereinbarungen schließen.

<a id="art-107"></a>
### Artikel 107 – Für internationale Organisationen geltende Regelungen

(1) Die Kommission kann im Wege von Beitragsvereinbarungen eine internationale Organisation mit der Durchführung von Aufgaben im Zusammenhang mit dem Betrieb von Ressourcen der Union betrauen.

    In diesen Beitragsvereinbarungen werden die Bedingungen sowie die praktischen und operativen Modalitäten für die Kontrolle der Anwendung der in Titel IV festgelegten Anforderungen durch diese internationale Organisation festgelegt.

(2) Betreibt eine internationale Organisation die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen, so stellen die Mitgliedstaaten sicher, dass diese internationale Organisation im Rahmen der in Artikel 6 Absatz 1 genannten Genehmigungen die Anforderungen des Titels IV erfüllt.

(3) Betreibt eine internationale Organisation eigene Ressourcen der Weltrauminfrastruktur, so bemüht sich die Union um den Abschluss von Übereinkünften mit dieser internationalen Organisation.

    In der in Unterabsatz 1 genannten Vereinbarung werden die Bedingungen sowie die praktischen und operativen Modalitäten festgelegt, um die Kontrolle der Anwendung der in Titel IV festgelegten Anforderungen durch diese internationale Organisation unter gebührender Berücksichtigung ihres institutionellen Rahmens zu gewährleisten.

<a id="art-108"></a>
### Artikel 108 – Beziehungen mit der Europäischen Weltraumorganisation

(1) Die Union bemüht sich um den Abschluss einer Vereinbarung mit der Europäischen Weltraumorganisation (ESA), um die mit dieser Verordnung verfolgten Ziele voranzubringen und die Zusammenarbeit zwischen der Union und der ESA zu verstärken.

(2) In der in Absatz 1 genannten Vereinbarung werden die Bedingungen für die Umsetzung der in Titel IV festgelegten Anforderungen durch die ESA sowie die praktischen und operativen Modalitäten zur Gewährleistung der Kontrolle der Anwendung dieser Anforderungen festgelegt, insbesondere

  - a) wenn die ESA nicht der Betreiber der unionseigenen Ressourcen ist, die erforderlichen Vorkehrungen, damit die ESA die technische Bewertung durchführen kann, die es der Kommission ermöglicht, die Einhaltung der in der Verordnung festgelegten Anforderungen durch den Unionsbetreiber im Bereich Weltraum, der Weltraumressourcen der Union betreibt, im Hinblick auf die Erteilung der Genehmigung und die laufende Aufsicht gemäß Artikel 11 Absatz 1 Unterabsatz 1 zu bewerten;

  - b) wenn unionseigene Ressourcen entweder von der ESA betrieben werden oder sich im Eigentum der ESA befinden, die erforderlichen Vorkehrungen und Bedingungen für die Erlaubnis der technischen Bewertungstätigkeiten und der Genehmigungs- und Aufsichtsaufgaben;

  - c) Unterstützung, die die ESA unter der Aufsicht der Kommission in Bezug auf die für die Normung erforderlichen technischen Spezifikationen leisten kann, wobei die bestehenden internationalen technischen Normen für Weltraumtätigkeiten zu berücksichtigen sind.

(3) Die ESA kann die Mitgliedstaaten durch technische Bewertungen gemäß Artikel 8 Absatz 1 Buchstabe b unterstützen.

    In der in Absatz 1 genannten Vereinbarung werden die Bedingungen festgelegt, unter denen die ESA als qualifizierte technische Stelle für Weltraumtätigkeiten anerkannt werden kann.

(4) Auf Ersuchen der Kommission kann die ESA als Beobachter oder Mitglied an einer einschlägigen beratenden Gruppe technischer Art teilnehmen, die im Rahmen dieser Verordnung eingerichtet werden kann.

<a id="title-vi"></a>
## Titel VI – UNTERSTÜTZENDE MAẞNAHMEN

<a id="title-vi-chapter-i"></a>
## Kapitel I – MAẞNAHMEN ZUM KAPAZITÄTSAUFBAU

<a id="art-109"></a>
### Artikel 109 – Kapazitätsaufbau

(1) Die Kommission unterstützt Betreiber im Bereich Weltraum, zuständige Behörden und qualifizierte technische Stellen für Weltraumtätigkeiten bei der Durchführung dieser Verordnung, indem sie

  - a) gegebenenfalls in enger Zusammenarbeit mit der Agentur und der ENISA Leitlinien, Methoden und bewährte Verfahren zu folgenden Themen entwickelt:

    - i) Verwendung – im Zusammenhang mit auf nationaler Ebene durchgeführten Verfahren zur Vergabe öffentlicher Aufträge – von Unionszeichen für die Sicherheit des Weltraums, die gemäß Artikel 112 Absatz 4 ausgestellt werden;

    - ii) Anforderungen, die für neuartige oder in Entwicklung befindliche Gebiete gelten, wie z. B. Reparatur- und Wartungsarbeiten in der jeweiligen Umlaufbahn oder Orbit-Verkehrsregeln;

    - iii) gegebenenfalls in anderen Angelegenheiten, die unter diese Verordnung fallen;

  - b) Förderung der Zusammenarbeit und des Informationsaustauschs in Angelegenheiten, die unter Titel IV Kapitel II fallen, mit Unterstützung der Agentur durch Erleichterung des Abschlusses von Vereinbarungen über den Informationsaustausch gemäß Artikel 29 der Richtlinie (EU) 2022/2555.

(2) Die Kommission unterstützt den Kapazitätsaufbau sowie Forschungs- und Innovationstätigkeiten, indem sie gemeinsame Forschungs- und Entwicklungsprojekte kofinanziert, um die Einführung technologischer Lösungen durch die Industrie zu ermöglichen, die die Einhaltung der in dieser Verordnung festgelegten Anforderungen in den folgenden Bereichen erleichtern:

  - a) Entwicklung von Verschlüsselungstechnologien und -protokollen;

  - b) Entwicklung von fahrzeugseitigen Sicherheitssystemen;

  - c) Entwicklung von ISOS-Technologien und -Konzepten;

  - d) in sonstigen Angelegenheiten, die unter diese Verordnung fallen.

    Die Kommission erlässt gemäß Artikel 113 delegierte Rechtsakte zur Ergänzung dieser Verordnung, in denen die in Unterabsatz 1 Buchstabe c genannten Aspekte festgelegt werden.

(3) Die Kommission finanziert

  - a) die Entwicklung von Normen für Neutralisatoren von Trägerraketen;

  - b) die Bereitstellung von Gutscheinen zur Unterstützung der Teilnahme von Betreibern im Bereich Weltraum an Coaching-Programmen, mit denen ein Teil der Kosten ausgeglichen werden soll, die durch die Umsetzung der in Artikel 96 Absatz 2 festgelegten Anforderungen entstehen.

(4) Die Kommission erleichtert den Zugang zu den bedrohungsorientierten Penetrationstests gemäß Artikel 88 Absatz 3 Unterabsatz 1, indem sie die Verfügbarkeit solcher Prüfdienste in der Union erfasst und Rahmenverträge ausarbeitet, um insbesondere KMU und kleinen Midcap-Unternehmen einen schnellen und erschwinglichen Zugang zu gewährleisten.

<a id="art-110"></a>
### Artikel 110 – Informationsportal

(1) Die Kommission richtet mit Unterstützung der Agentur ein Informationsportal zur Unterstützung dieser Verordnung (im Folgenden „Informationsportal“) ein und verwaltet es.

(2) Das Informationsportal hat folgende Aufgaben:

  - a) Unterstützung der Betreiber im Bereich Weltraum bei der Durchführung dieser Verordnung;

  - b) Bereitstellung von Konformitätschecklisten, um die freiwillige Teilnahme an den gemäß Artikel 111 Absatz 4 Unterabsatz 1 eingerichteten Weltraumsiegelsystemen der Union zu fördern;

  - c) Unterstützung einschlägiger zentraler Ansprechstellen, die von den Mitgliedstaaten eingerichtet werden.

(3) Die Mitgliedstaaten unterrichten die Kommission über alle nationalen Helpdesk-Portale, die zur Verwaltung von Anfragen zu Vorschriften, Verfahrensweisen und Genehmigungsverfahren eingerichtet wurden.

    Die Kommission stellt die Interoperabilität dieser Helpdesk-Portale mit dem Informationsportal sicher.

<a id="title-vi-chapter-ii"></a>
## Kapitel II – RAHMEN FÜR DAS WELTRAUMSIEGEL DER UNION

<a id="art-111"></a>
### Artikel 111 – Weltraumsiegelsystem der Union

(1) Die Kommission entwickelt einen Rahmen für ein Weltraumsiegel der Union, um eine verstärkte freiwillige Einhaltung hoher Standards für den Schutz von Weltraumtätigkeiten zu fördern.

    Der Rahmen für das Weltraumsiegel der Union setzt sich aus den in den Absätzen 2 und 3 genannten Siegelsystemen der Union zusammen.

(2) In einem Weltraumsiegelsystem der Union sind die detaillierten Anforderungen festgelegt zur

  - a) Begrenzung der mit Weltraummüll verbundenen Risiken;

  - b) Verbesserung der Sicherheit und Nachhaltigkeit von Weltraumobjekten in der Umlaufbahn, der Sicherheit von Luftfahrzeugen im Flug oder der Sicherheit von Personen und Gütern am Boden bei der Durchführung von Weltraumtätigkeiten;

  - c) Verringerung der Lichtverschmutzung durch Raumfahrzeuge;

  - d) Verringerung der Funkverschmutzung durch Raumfahrzeuge;

  - e) Gewährleistung der Resilienz der Weltrauminfrastruktur, insbesondere in Bezug auf kritische Ressourcen, und der Resilienz der Lieferkette;

  - f) Ermöglichung von Operationen und Diensten im Weltraum;

  - g) Verringerung der Umweltauswirkungen von Weltraumtätigkeiten.

(3) Auf Ersuchen der Kommission erstellt die Agentur ein Kandidatensystem oder schlägt eine Aktualisierung eines bestehenden Weltraumsiegelsystems der Union vor.

    In einem Weltraumsiegelsystem der Union können für die spezifischen Weltraummissionen, -dienste oder -produkte, für die es gilt, eine oder mehrere der folgenden Schutzstufen festgelegt sein: „Basis“, „wesentlich“ oder „hoch“.

    In diesem Fall stellt die Agentur sicher, dass das festgelegte Schutzniveau dem Schutzniveau entspricht, das mit den Anforderungen des jeweiligen Weltraumsiegelsystems der Union verbunden ist.

(4) Die Kommission erlässt im Wege von Durchführungsrechtsakten Folgendes:

  - a) ein Muster für die Elemente des Weltraumsiegels der Union, einschließlich ihrer Dauer;

  - b) Weltraumsiegelsysteme der Union auf der Grundlage des Kandidatensystems oder Aktualisierungen eines bestehenden Weltraumsiegelsystems der Union.

    Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 2 genannten Prüfverfahren erlassen.

(5) Die Agentur unterhält eine spezielle Website, auf der aktuelle Informationen über die Weltraumsiegelsysteme der Union und die Weltraumsiegel der Union bereitgestellt und veröffentlicht werden.

<a id="art-112"></a>
### Artikel 112 – Vergabe und Verwendung des Weltraumsiegels der Union

(1) Möchte sich ein Betreiber im Bereich Weltraum um ein Weltraumsiegel der Union bewerben, so reicht er bei der Agentur einen Antrag auf Erteilung eines Weltraumsiegels der Union ein, dem ein detailliertes technisches Dossier beigefügt ist, aus dem hervorgeht, dass die Anforderungen des Siegelsystems/der Siegelsysteme der Union, für das/die das Weltraumsiegel der Union beantragt wird, erfüllt sind.

    Die Agentur unterrichtet die Kommission unverzüglich über den Antrag.

(2) Die Agentur übermittelt der Kommission eine ausführliche Stellungnahme bezüglich der Übereinstimmung des Antrags mit den Anforderungen der einschlägigen Weltraumsiegelsysteme der Union.

(3) Auf Grundlage der Bewertung der Agentur entscheidet die Kommission im Wege von Durchführungsrechtsakten über die Anträge.

(4) Die Agentur stellt Betreibern im Bereich Weltraum, deren Anträge von der Kommission gemäß Absatz 3 genehmigt wurden, für die Dauer eines Weltraumsiegels, die in dem entsprechenden Weltraumsiegelsystem der Union anzugeben ist, Weltraumsiegel der Union aus.

(5) Die Agentur überprüft regelmäßig von sich aus oder auf Beschwerde, ob ein Inhaber eines Weltraumsiegels der Union die Anforderungen des jeweiligen Weltraumsiegels der Union erfüllt. Stellt die Agentur fest, dass der Inhaber eines Weltraumsiegels der Union die Anforderungen nicht erfüllt, so widerruft sie das Weltraumsiegel der Union. Vor dem Widerruf des Weltraumsiegels der Union muss die Agentur dem Inhaber des Weltraumsiegels der Union die Abgabe einer mit Gründen versehenen Stellungnahme erlauben.

(6) Der Inhaber eines Weltraumsiegels der Union unterrichtet die Agentur über alle später festgestellten Unregelmäßigkeiten, die sich auf die Einhaltung der Anforderungen des jeweiligen Weltraumsiegels der Union auswirken können, in Bezug auf die Weltraummission, den Dienst oder das Produkt, die mit dem Siegel versehen sind.

(7) Jede falsche oder irreführende Werbung oder Verwendung eines Weltraumsiegels der Union oder eines Logos, die zu Verwechslungen mit einem Weltraumsiegel der Union führt, ist verboten.

<a id="title-vii"></a>
## Titel VII – ÜBERGANGS- UND SCHLUSSBESTIMMUNGEN

<a id="art-113"></a>
### Artikel 113 – Ausübung der Befugnisübertragung

(1) Die Befugnis zum Erlass delegierter Rechtsakte wird der Kommission unter den in diesem Artikel festgelegten Bedingungen übertragen.

(2) Die Befugnis zum Erlass der delegierten Rechtsakte gemäß Artikel 41 Absatz 3, Artikel 44 Absatz 3, Artikel 56 Absatz 9 Unterabsatz 1, Artikel 70 Absatz 4, Artikel 78 Absatz 3, Artikel 79 Absatz 4, Artikel 82 Absatz 4, Artikel 83 Absatz 5, Artikel 84 Absatz 5, Artikel 85 Absatz 4, Artikel 86 Absatz 4, Artikel 92 Absatz 4, Artikel 93 Absatz 7 Unterabsatz 2, Artikel 101 Absatz 4 Unterabsatz 1 und Artikel 109 Absatz 2 Unterabsatz 2 wird der Kommission für einen Zeitraum von sieben Jahren ab dem 1. Januar 2027 übertragen.

(3) Für jeden delegierten Rechtsakt gemäß Absatz 2 legt die Agentur der Kommission nach Durchführung öffentlicher Konsultationen bis zum 1.7.2028 förmliche technische Stellungnahmen vor. In Angelegenheiten, die unter Titel IV Kapitel II fallen, konsultiert die Agentur die ENISA.

(4) Die Befugnisübertragung gemäß Artikel 41 Absatz 3, Artikel 44 Absatz 3, Artikel 56 Absatz 9 Unterabsatz 1, Artikel 70 Absatz 4, Artikel 78 Absatz 3, Artikel 79 Absatz 4, Artikel 82 Absatz 4, Artikel 83 Absatz 5, Artikel 84 Absatz 5, Artikel 85 Absatz 4, Artikel 86 Absatz 4, Artikel 92 Absatz 4, Artikel 93 Absatz 7 Unterabsatz 2, Artikel 101 Absatz 4 Unterabsatz 1 und Artikel 109 Absatz 2 Unterabsatz 2 kann vom Europäischen Parlament oder vom Rat jederzeit widerrufen werden.

    Der Beschluss über den Widerruf beendet die Übertragung der in diesem Beschluss angegebenen Befugnis. Er wird am Tag nach seiner Veröffentlichung im Amtsblatt der Europäischen Union oder zu einem im Beschluss über den Widerruf angegebenen späteren Zeitpunkt wirksam. Die Gültigkeit von delegierten Rechtsakten, die bereits in Kraft sind, wird von dem Beschluss über den Widerruf nicht berührt.

(5) Vor dem Erlass eines delegierten Rechtsakts konsultiert die Kommission von den einzelnen Mitgliedstaaten benannte Sachverständige im Einklang mit den in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung enthaltenen Grundsätzen.

(6) Sobald die Kommission einen delegierten Rechtsakt erlässt, übermittelt sie ihn gleichzeitig dem Europäischen Parlament und dem Rat.

(7) Ein delegierter Rechtsakt, der gemäß Artikel 41 Absatz 3, Artikel 44 Absatz 3, Artikel 56 Absatz 9 Unterabsatz 1, Artikel 70 Absatz 4, Artikel 78 Absatz 3, Artikel 79 Absatz 4, Artikel 82 Absatz 4, Artikel 83 Absatz 5, Artikel 84 Absatz 5, Artikel 85 Absatz 4, Artikel 86 Absatz 4, Artikel 92 Absatz 4, Artikel 93 Absatz 7 Unterabsatz 2, Artikel 101 Absatz 4 Unterabsatz 1 und Artikel 109 Absatz 2 Unterabsatz 2 erlassen wurde, tritt nur in Kraft, wenn weder das Europäische Parlament noch der Rat innerhalb einer Frist von zwei Monaten nach Übermittlung dieses Rechtsakts an das Europäische Parlament und den Rat Einwände erhoben haben oder wenn vor Ablauf dieser Frist das Europäische Parlament und der Rat beide der Kommission mitgeteilt haben, dass sie keine Einwände erheben werden. Auf Initiative des Europäischen Parlaments oder des Rates wird diese Frist um zwei Monate verlängert.

<a id="art-114"></a>
### Artikel 114 – Ausschussverfahren

(1) Die Kommission wird von einem Ausschuss unterstützt. Dieser Ausschuss ist ein Ausschuss im Sinne der Verordnung (EU) Nr. 182/2011 .

(2) Wird auf den vorliegenden Absatz Bezug genommen, so gilt Artikel 5 der Verordnung (EU) Nr. 182/2011 .

(3) Wird auf den vorliegenden Absatz Bezug genommen, so gilt Artikel 4 der Verordnung (EU) Nr. 182/2011.

(4) Der Ausschuss tritt in unterschiedlicher Zusammensetzung wie folgt zusammen:

  - a) Zusammensetzung „Sicherheit“;

  - b) Zusammensetzung „Resilienz“;

  - c) Zusammensetzung „ökologische Nachhaltigkeit“;

  - d) Zusammensetzung „ISOS“;

  - e) Zusammensetzung „weltraumgestützte Daten“.

(5) Im Einklang mit den von der Union geschlossenen internationalen Übereinkünften können unter den in der Geschäftsordnung des Ausschusses festgelegten Bedingungen die Vertreter von Drittländern oder internationalen Organisationen als Beobachter zu seinen Sitzungen eingeladen werden, wobei der Sicherheit der Union Rechnung zu tragen ist.

<a id="art-115"></a>
### Artikel 115 – Berufsgeheimnis

(1) Vertrauliche Informationen, die von einer in Absatz 2 genannten Person, Einrichtung oder Behörde gemäß dieser Verordnung empfangen, ausgetauscht oder übermittelt werden, unterliegen der Bedingung des Berufsgeheimnisses gemäß den Absätzen 2 und 3.

(2) Unbeschadet des Austauschs und der Nutzung von Informationen gemäß dieser Verordnung gilt die Pflicht zur Wahrung des Berufsgeheimnisses für alle Personen, einschließlich der von ihnen beauftragten Prüfer und Sachverständigen, die für die Kommission, die Agentur, die zuständigen Behörden oder eine qualifizierte technische Stelle für Weltraumtätigkeiten, eine Behörde oder eine natürliche oder juristische Person, der die zuständigen Behörden oder die qualifizierten technischen Stellen für Weltraumtätigkeiten Befugnisse und Aufgaben übertragen haben, tätig sind.

(3) Unter das Berufsgeheimnis fallende Informationen, einschließlich im Kontext der zwischen den gemäß der vorliegenden Verordnung zuständigen Behörden und den gemäß der Richtlinie (EU) 2022/2555 und der Richtlinie (EU) 2022/2557 benannten oder eingerichteten zuständigen Behörden ausgetauschten Informationen, dürfen keiner anderen Person oder Behörde gegenüber offengelegt werden, es sei denn, dies geschieht aufgrund von Unionsrecht oder nationalem Recht.

(4) Alle im Rahmen der vorliegenden Verordnung zwischen zuständigen Behörden ausgetauschten Informationen, die Geschäfts- oder Betriebsbedingungen und wirtschaftliche oder persönliche Angelegenheiten betreffen, sind vertraulich und unterliegen den Anforderungen des Berufsgeheimnisses, es sei denn, ihre Weitergabe wird von einer zuständigen Behörde zum Zeitpunkt der Einleitung der Übermittlung für zulässig erklärt oder diese Weitergabe ist für die Zwecke von Gerichtsverfahren erforderlich.

<a id="art-116"></a>
### Artikel 116 – Evaluierung und Überprüfung

(1) Bis zum 1. Dezember 2035 und danach alle fünf Jahre legt die Kommission dem Europäischen Parlament und dem Rat einen Bericht über die Bewertung dieser Verordnung, einschließlich einer Bewertung der ökologischen, wirtschaftlichen und sozialen Auswirkungen von Weltraumtätigkeiten auf andere Sektoren, und gegebenenfalls einen Bericht über ihre Überprüfung vor, dem erforderlichenfalls ein Gesetzgebungsvorschlag beigefügt ist. Die Berichte werden veröffentlicht.

(2) Für die Zwecke der Bewertung und Überprüfung gemäß Absatz 1 kann die Kommission die Agentur und die Mitgliedstaaten auffordern, Daten und Informationen zur Verfügung zu stellen. Die Agentur und die Mitgliedstaaten stellen der Kommission die angeforderten Daten und Informationen unverzüglich zur Verfügung.

(3) Bei der Bewertung und Überprüfung gemäß Absatz 1 berücksichtigt die Kommission die Stellungnahmen, Standpunkte und Erkenntnisse der Agentur, des Europäischen Parlaments, des Rates, der Mitgliedstaaten und der zuständigen Behörden sowie anderer einschlägiger Stellen und Organisationen oder einschlägiger Quellen.

<a id="art-117"></a>
### Artikel 117 – Berichte an die Kommission

Bis zum 1. Dezember 2031 und danach jedes Jahr erstatten die Mitgliedstaaten der Kommission Bericht über den Stand der Durchführung dieser Verordnung. Der Bericht enthält Informationen über Durchsetzungsmaßnahmen und Aktualisierungen zum Weltraumsektor auf nationaler Ebene, wie z. B. über Aspekte der Wettbewerbsfähigkeit, die sich auf das Funktionieren des Binnenmarkts auswirken, und Elemente zum Bedarf an öffentlichen und privaten Ausgaben.

In ihrem ersten Bericht teilen die Mitgliedstaaten der Kommission ihre vorbereitenden Maßnahmen und die auf nationaler Ebene ergriffenen Maßnahmen mit, einschließlich Anpassungen zur Gewährleistung einer reibungslosen Anwendung dieser Verordnung.

<a id="art-118"></a>
### Artikel 118 – Übergangszeitraum

(1) Für Genehmigungen für Ressourcen, die nach dem 1. Januar 2030 starten sollen und deren kritische Entwurfsprüfung am [JO: 12 Monate ab dem Datum des Inkrafttretens dieser Verordnung berechnen] endete, gilt diese Verordnung erst ab dem 1. Januar 2032.

(2) Die zuständigen Behörden (in Bezug auf Unionsbetreiber im Bereich Weltraum) und die Agentur (in Bezug auf Drittlandsbetreiber im Bereich Weltraum) stellen das Ende der in Absatz 1 genannten kritischen Entwurfsprüfungsphase zu dem Zeitpunkt fest, zu dem die Betreiber im Bereich Weltraum die Nachweise vorlegen, die sie von der einschlägigen, vertraglich mit der technischen Genehmigung der Konstruktion des Raumfahrzeugs betrauten Stelle erhalten haben.

<a id="art-119"></a>
### Artikel 119 – Inkrafttreten und Geltung

Diese Verordnung tritt am zwanzigsten Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

Sie gilt ab dem 1. Januar 2030.

Diese Verordnung ist in allen ihren Teilen verbindlich und gilt unmittelbar in jedem Mitgliedstaat.

Geschehen zu Brüssel am

Im Namen des Europäischen Parlaments Im Namen des Rates

Die Präsidentin Der Präsident/Die Präsidentin

[...] [...]

<a id="finanz-und-digitalbogen-zu-rechtsakten"></a>
## FINANZ- UND DIGITALBOGEN ZU RECHTSAKTEN

1. RAHMEN DES VORSCHLAGS/DER INITIATIVE

1.1. Bezeichnung des Vorschlags/der Initiative

    Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates über die Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten in der Union.

1.2. Politikbereich(e)

    Ein neuer Plan für nachhaltigen Wohlstand und nachhaltige Wettbewerbsfähigkeit in Europa

    Wohlstand und Wettbewerbsfähigkeit:

1.3. Ziel(e)

1.3.1. Allgemeine(s) Ziel(e)

    Die vorgeschlagene Verordnung zielt darauf ab, die Entwicklung und das Funktionieren des Binnenmarkts für die Weltraumwirtschaft zu unterstützen.

1.3.2. Einzelziel(e)

    Einzelziel Nr.

    Der Vorschlag sieht vier spezifische Ziele vor:

    i) Schaffung eines Unionsrahmens, der das Verhalten von Betreibern im Bereich Weltraum in der Union so regelt, dass ein stabiles, berechenbares und wettbewerbsfähiges Unternehmensumfeld geschaffen wird, das Innovationen fördert;

    ii) Sicherstellung der Verfolgbarkeit von Weltraumobjekten und Verringerung der Entstehung von Weltraummüll aus Weltraumtätigkeiten;

    iii) Schaffung eines kohärenten Resilienzszenarios für den Weltraumsektor durch einen Risikobewertungsrahmen und auf die Weltrauminfrastruktur zugeschnittene Cybersicherheitsvorschriften;

    iv) eine gemeinsame Methode zur Bewertung und Messung der Umweltauswirkungen von Weltraumtätigkeiten in der Union.

1.3.3. Erwartete Ergebnisse und Auswirkungen

    Bitte geben Sie an, wie sich der Vorschlag/die Initiative auf die Begünstigten/Zielgruppen auswirken sollte.

    Die vorgeschlagene Verordnung würde die Bedingungen für das Funktionieren des Binnenmarkts für weltraumgestützte Daten und Weltraumdienste verbessern, was erhebliche positive Auswirkungen auf die Weltraumindustrie der EU und ihre Wettbewerbsfähigkeit hätte.

    Die Entwicklung des Binnenmarkts im Bereich Weltraum würde eine stärkere Integration zwischen den Mitgliedstaaten bedeuten, die Voraussetzungen für einen verbesserten Marktzugang für Unternehmen schaffen, Innovationen in der gesamten Branche fördern, mehr private Investitionen anziehen und den Verwaltungsaufwand für Unternehmen verringern.

    Maßnahmen zur Sicherstellung der Verfolgbarkeit von Weltraumobjekten und zur Verringerung des Weltraummülls würden zu einer sichereren und nachhaltigeren Weltraumumgebung beitragen. Dies würde das Risiko von Kollisionen und der Entstehung von Weltraummüll erheblich verringern und sowohl die operativen Satelliten als auch die langfristige Nachhaltigkeit der Umlaufbahnen sichern.

    Die Entwicklung einer kohärenten Ausgangsbasis für alle Ressourcen der Weltrauminfrastruktur und die Umsetzung von Risikobewertungsrahmen, die auf den Cybersicherheitsbedarf des Weltraumsektors zugeschnitten sind, würden die Resilienz der Weltraumtätigkeiten in der Union gegen Cyberbedrohungen stärken. Dies würde das Vertrauen in die Fähigkeiten der Interessenträger, einschließlich privater Unternehmen und staatlicher Stellen, stärken, die Nutzung von Weltraumdiensten weiter voranbringen, Investitionen anziehen und das Wachstum einer robusten und sicheren Weltraumindustrie in der EU fördern.

    Die Entwicklung einer gemeinsamen Methode zur Messung der Umweltauswirkungen von Weltraumtätigkeiten würde eine fundierte Entscheidungsfindung auf der Grundlage standardisierter Parameter erleichtern und es Unternehmen ermöglichen, in umweltfreundlichere Technologien zu investieren, und es politischen Entscheidungsträgern ermöglichen, die Vorteile und Risiken von Weltraumtätigkeiten in ein Gleichgewicht zu bringen.

    Schließlich würde die erfolgreiche Umsetzung der Verordnung die Fähigkeit der Union verbessern, auf globale Normen im Weltraumbereich Einfluss zu nehmen und die Wettbewerbsfähigkeit der Industrie der Union auf den Weltmärkten steigern.

    In der Folgenabschätzung zu dieser Verordnung ergab sich ein jährlicher Gesamtnutzen für Unternehmen (Satellitenbetreiber) in Höhe von 677,5 Mio. EUR, wodurch die Kosten, die sich aus den Anforderungen der neuen Verordnung ergeben, vollständig ausgeglichen werden. Für die Behörden der Mitgliedstaaten werden die Kosten für Compliance und Durchsetzung auf 1 bis 4 VZÄ geschätzt.

1.3.4. Leistungsindikatoren

    Bitte geben Sie an, anhand welcher Indikatoren die Fortschritte und Ergebnisse verfolgt werden sollen.

    Die folgenden Indikatoren werden verwendet, um die erfolgreiche Umsetzung dieser Verordnung zu überwachen und die Auswirkungen und die Reaktion des Markts, insbesondere der KMU, zu bewerten.

| Einzelziele | Indikator | Methode | Basisszenario | Zielwert^(33(1) | Jährliche Fortschrittsabschätzung | Überprüfungshäufigkeit |
| --- | --- | --- | --- | --- | --- | --- |
| Unterstützung der Entwicklung und des Funktionierens eines Binnenmarkts für die Weltraumwirtschaft | Weltraumtätigkeiten im Binnenmarkt, die den vorgeschlagenen Rechtsvorschriften entsprechen | Berichterstattung durch die Mitgliedstaaten. | 0 | 100 % | 100 % nach Inkrafttreten des Rechtsakts | Jährlich |
| Sicherstellung der Verfolgbarkeit von Weltraumobjekten und Verringerung der Entstehung von Weltraummüll | Anzahl der Ereignisse von hohem Interesse | Über die SSST-Partnerschaft der EU | 622 (LEO) 33 (MEO) 101 (GEO) | Verringerung um 10 % | Verringerung um ca. 5 % pro Jahr | Jährlich |
| Sicherstellung der Verfolgbarkeit von Weltraumobjekten und Verringerung der Entstehung von Weltraummüll | Anzahl erfolgreicher Entsorgungen am Ende der Lebensdauer | Über die SSST-Partnerschaft der EU | GEO: 60 % LEO: 65 % | 90 % für alle Umlaufbahnen | Zunahme um ca. 3 % pro Jahr | Jährlich |
| Schaffung eines auf die Cybersicherheit für die Weltrauminfrastruktur zugeschnittenen Risikobewertungsrahmens | Anzahl gemeldeter erheblicher Cybersicherheitsvorfälle, die eingedämmt wurden | EUSPA über den Berichterstattungsmechanismus (für unionseigene Ressourcen); Computer-Notfallteams (CSIRTs)/zentrale Ansprechstellen (SPOC) (gemäß NIS) und die nationalen Weltraumüberwachungszentren für die anderen Ressourcen | Keine Angaben übermittelt | 50 % Reduzierung | 50 % nach Inkrafttreten des Gesetzes | Jährlich |
| Einführung einer gemeinsamen Methode zur Messung der Umweltauswirkungen von Weltraumtätigkeiten | Darstellung des EU-Marktanteils in % bei der PEFCR-Entwicklung | Berichterstattung durch die Mitgliedstaaten | 0 % | ≥ 51 % | ≥ 51 % | Jährlich |
| Einführung einer gemeinsamen Methode zur Messung der Umweltauswirkungen von Weltraumtätigkeiten | % der Betreiber im Bereich Weltraum, die eine Umweltberichterstattung durchführen | Berichterstattung durch die Mitgliedstaaten | 40 %^(34(2) | 80 %^(35(3) | 80 % nach Festlegung des PEFCR-Rahmens | Jährlich |
| Einführung einer gemeinsamen Methode zur Messung der Umweltauswirkungen von Weltraumtätigkeiten | Zahl der Weltraummissionen, die den standardisierten LCA-Rahmen integrieren | Berichterstattung durch die Mitgliedstaaten | entfällt (Fehlen eines standardisierten LCA-Rahmens für Weltraumtätigkeiten) | 80 %^(36(4) | Nach Schaffung des LCA-Rahmens | Jährlich nach der Entwicklung des Rahmens |
| Einführung einer gemeinsamen Methode zur Messung der Umweltauswirkungen von Weltraumtätigkeiten | Umweltfußabdruck von Weltraumtätigkeiten (z. B. CO₂-Emissionen) | Berichterstattung durch die Mitgliedstaaten | entfällt (fehlendes gemeinsames Messverfahren) | Zu überwachen | Nach der Festlegung des PEFCR-Rahmens werden jährliche Reduktionsziele festgelegt. | Jährlich nach der Entwicklung des Rahmens |

1.4. Der Vorschlag/Die Initiative betrifft

  - ☑ eine neue Maßnahme

  - ☐ eine neue Maßnahme im Anschluss an ein Pilotprojekt/eine vorbereitende Maßnahme^(37)^(5)

  - ☐ die Verlängerung einer bestehenden Maßnahme

  - ☐ die Zusammenführung mehrerer Maßnahmen oder die Neuausrichtung mindestens einer Maßnahme

1.5. Begründung des Vorschlags/der Initiative

1.5.1. Kurz- oder langfristig zu deckender Bedarf, einschließlich einer detaillierten Zeitleiste für die Durchführung der Initiative

    13 Mitgliedstaaten verfügen über Weltraumgesetze, und weitere Mitgliedstaaten arbeiten derzeit an der Ausarbeitung von Rechtsvorschriften für den Bereich Weltraum, um der Zunahme der Weltraumtätigkeiten und dem Aufkommen neuer Marktteilnehmer Rechnung zu tragen. Mangelnde Koordinierung und die regulatorischen Unterschiede haben zu einem fragmentierten Rechtsrahmen geführt, der Hindernisse für die Bereitstellung von Weltraumdiensten und weltraumgestützten Daten im Binnenmarkt schaffen könnte.

    Ohne Koordinierung werden sich die Mittel und Ansätze zur Regulierung der Weltraumtätigkeiten in der Union weiter auseinander entwickeln. Mit der vorgeschlagenen Verordnung wird daher eine gezielte Harmonisierung der Kernanforderungen an die Genehmigung für die Erbringung von Weltraumtätigkeiten und -diensten eingeführt. Die Kernanforderungen betreffen in erster Linie die Sicherheit, Resilienz und ökologische Nachhaltigkeit von Weltraumtätigkeiten. Für ISOS und den Routinebetrieb in der Umlaufbahn gelten begrenzte Bestimmungen.

    Ein kohärentes und einheitliches Schutzniveau für alle Ressourcen der Weltrauminfrastruktur erleichtert die Bereitstellung von Weltraumdiensten, den freien Verkehr weltraumgestützter Daten, die durch die Nutzung einer solchen Weltrauminfrastruktur generiert werden, sowie die Fähigkeit der Betreiber im Bereich Weltraum, Weltraumtätigkeiten ohne Hemmnisse in mehreren Rechtsordnungen durchzuführen. Die Verordnung würde somit Rechtssicherheit für Betreiber und Nutzer im Bereich Weltraum in der Union schaffen.

    Die Verordnung wird für alle nach dem 1. Januar 2030 gestarteten Ressourcen gelten. Für Ressourcen, die sich noch in einer kritischen Entwicklungsphase befinden, sieht die Verordnung jedoch einen weiteren Übergangszeitraum von 24 Monaten für die Einhaltung der Vorschriften vor.

    Bestimmte Aspekte, wie z. B. die Governance, sollten bis 2030 umgesetzt werden können. Die Mitgliedstaaten sollten sicherstellen, dass sie bis zu diesem Zeitpunkt für die Wahrnehmung der in der Verordnung festgelegten Aufgaben und den Aufbau von technischem Fachwissen und Kapazitäten bestehende Behörden benennen oder neue Behörden schaffen, um eine reibungslose Durchführung dieser Verordnung durch qualifizierte technische Stellen für Weltraumtätigkeiten, die technische Bewertungsaufgaben wahrnehmen, zu ermöglichen.

    Auf Unionsebene sollte die Agentur der Europäischen Union für das Weltraumprogramm (im Folgenden „Agentur“) alle erforderlichen Strukturen, internen Prozesse und Verfahren einrichten, um die ihr durch die Verordnung übertragenen neuen Zuständigkeiten wahrzunehmen.

    Diese neuen Zuständigkeiten betreffen insbesondere die technische Bewertung im Hinblick auf die Unterstützung der Kommission bei neuen Aufgaben in Bezug auf die Genehmigung und Beaufsichtigung von Unionsbetreibern im Bereich Weltraum, die unionseigene Ressourcen betreiben, die Registrierung und Beaufsichtigung von Betreibern aus Drittstaaten und die Durchführung technischer Bewertungen für Mitgliedstaaten, in deren Hoheitsgebiet es keine qualifizierten technischen Stellen gibt. Darüber hinaus sorgt die Agentur für die Koordinierung der Tätigkeiten des Unionsnetzes für Resilienz im Weltraum (EUSRN), überwacht Sicherheitsvorfälle im Zusammenhang mit unionseigenen Ressourcen, verwaltet die Einrichtung und Umsetzung der neuen Weltraumsiegelsysteme der Union und trägt zur Entwicklung und Umsetzung der verschiedenen in dieser Verordnung vorgesehenen Unterstützungsmaßnahmen bei.

    Die Agentur sollte sich auf die Ausübung ihrer neuen Befugnisse zur technischen Bewertung, um die Kommission bei der Wahrnehmung ihrer Aufsichtsaufgaben zu unterstützen, und auf die Einrichtung spezieller interner Strukturen zu diesem Zweck wie des Konformitätsgremiums und der Widerspruchskammer vorbereiten.

    Zum Zeitpunkt der Anwendbarkeit der Verordnung sollten bereits eine Reihe von Datenbanken und zugehörigen Instrumenten vorhanden sein, insbesondere das Unionsregister der Weltraumobjekte (URSO) und die Kontaktlistendatenbank der Union für Warnmeldungen zu Ereignissen von hohem Interesse.

    Die Europäische Kommission gestaltet im Wege von delegierten Rechtsakten und/oder Durchführungsrechtsakten die technischen Anforderungen, die für die Durchführung der in dieser Verordnung festgelegten Vorschriften erforderlich sind, weiter aus und erteilt Normungsaufträge für die Entwicklung harmonisierter Normen.

    Schließlich wird eine Reihe unterstützender Maßnahmen durch Maßnahmen zum Kapazitätsaufbau, technische Hilfe und Finanzierung eingeführt, um die Mitgliedstaaten und die Weltraumindustrie bei der Durchführung der Verordnung zu unterstützen und sie auf diese vorzubereiten. Weiterhin sollen diese Maßnahmen einen Teil der möglichen Durchführungskosten, z. B. für Start-up-Unternehmen, expandierende KMU und kleine Midcap-Unternehmen, ausgleichen.

1.5.2. Mehrwert aufgrund des Tätigwerdens der EU (kann sich aus unterschiedlichen Faktoren ergeben, z. B. Vorteile durch Koordinierung, Rechtssicherheit, größere Wirksamkeit oder Komplementarität). Für die Zwecke dieses Abschnitts bezeichnet der Ausdruck „Mehrwert aufgrund des Tätigwerdens der EU“ den Wert, der sich aus dem Tätigwerden der EU ergibt und den Wert ergänzt, der andernfalls allein von den Mitgliedstaaten geschaffen worden wäre.

    Weltraumtätigkeiten sind ausgeprägt grenzüberschreitend, da die in einem Mitgliedstaat hergestellte Weltrauminfrastruktur häufig von Unternehmen genutzt wird, die im gesamten Binnenmarkt tätig sind, während Betreiber im Bereich Weltraum häufig mehrere Genehmigungen in mehreren Mitgliedstaaten erwerben müssen. Der sich abzeichnende uneinheitliche Rahmen mit potenziell divergierenden nationalen Vorschriften birgt die Gefahr, dass ein wettbewerbsfähiger Binnenmarkt für Weltraumprodukte, Weltraumdienste und weltraumgestützte Daten behindert wird.

    Es sind gemeinsame Maßnahmen auf Unionsebene erforderlich, um das Niveau der Sicherheit, Resilienz und ökologischen Nachhaltigkeit von Weltraumtätigkeiten in der gesamten Union zu erhöhen. Dies stellt einen klaren Mehrwert gegenüber den Einzelmaßnahmen der Mitgliedstaaten dar, indem 1) gleiche Wettbewerbsbedingungen in der gesamten Union durch die Angleichung der Kernanforderungen an die Genehmigungsbedingungen in Bezug auf Sicherheit, Resilienz und Umweltauswirkungen von Weltraumtätigkeiten geschaffen werden, 2) eine bessere Koordinierung der Mitgliedstaaten gewährleistet wird, um Überschneidungen, Doppelarbeit und Konflikte zu vermeiden, indem kohärente Mechanismen im gesamten Binnenmarkt eingeführt werden, 3) das Schutzniveau der Weltrauminfrastruktur in einheitlicher Weise angehoben wird, um die Fähigkeit der Mitgliedstaaten zu stärken, weltraumgestützte Daten bereitzustellen, was wiederum die Erbringung von Diensten im gesamten Binnenmarkt ermöglicht, und 4) Kohärenz bei der Berechnung der Umweltauswirkungen von Weltraumtätigkeiten in der Union gewährleistet wird.

    Ein gemeinsamer Ansatz für sichere, resiliente und nachhaltige Weltraumtätigkeiten auf Unionsebene würde dem Weltraumsektor der Union vielfältige Vorteile bringen, indem für Rechtssicherheit gesorgt, Hindernisse bei der Bereitstellung von Weltraumdiensten und weltraumgestützten Daten beseitigt, der Verwaltungsaufwand und die Kosten im Zusammenhang mit den vielfältigen und unterschiedlichen nationalen Anforderungen verringert, der Wettbewerb gefördert und der Zugang zu größeren Märkten ermöglicht würde.

    Ein koordiniertes Vorgehen würde es der Union ermöglichen, künftige globale Standards für die Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten zu steuern und zu stärken, indem die Union als globaler Standardsetzer in einem Bereich eingerichtet wird, in dem dringend Lösungen erforderlich sind, um neu auftretenden Risiken für die Nutzung von Umlaufbahnen und des Weltraums zu begegnen.

    Gleichzeitig würde sich die Union um die Aushandlung von Abkommen über die gegenseitige Anerkennung mit Drittländern bemühen, um den Marktzugang für die EU-Weltraumindustrie zu verbessern.

1.5.3. Aus früheren ähnlichen Maßnahmen gewonnene Erkenntnisse

    Diese Verordnung ist die erste ihrer Art im Bereich Weltraum, mit der eine gezielte Harmonisierung der wichtigsten Aspekte der Genehmigungen für die Durchführung von Weltraumtätigkeiten eingeführt wird. Gleichzeitig baut sie auf bestimmten Elementen des neuen Rechtsrahmens und auf den Erkenntnissen auf, die bei der Umsetzung der Harmonisierungsrechtsvorschriften der Union für Produkte und Dienstleistungen gewonnen wurden.

    Um die Wettbewerbsfähigkeit und Innovation im Weltraumsektor in der Union, insbesondere im Hinblick auf Start-up-Unternehmen, KMU und Forschungseinrichtungen, zu erhalten und zu verbessern, werden in der Verordnung auch Lehren aus den jüngsten Rechtsakten wie dem KI-Gesetz oder der Cyberresilienz-Verordnung berücksichtigt.

    In diesem Sinne wird sie a) eine Reihe unterstützender Maßnahmen umfassen, um Unternehmen, insbesondere Start-ups, Scale-ups, KMU und kleine Midcap-Unternehmen, dabei zu unterstützen, die in dieser Verordnung festgelegten Maßnahmen einzuhalten, einschließlich, aber nicht beschränkt auf Coaching und Mentoring, technische Hilfe und Unterstützung bei der Entwicklung neuer technologischer Lösungen, b) Verhältnismäßigkeit in den Vorschriften wahren und weniger strenge Regelungen auf der Grundlage unterschiedlicher Kriterien wie der Größe des Betreibers im Bereich Weltraum, der Kritikalität der Weltraummission, der verwendeten Weltraumressource oder der genutzten Umlaufbahn vorsehen.

1.5.4. Vereinbarkeit mit dem Mehrjährigen Finanzrahmen sowie mögliche Synergieeffekte mit anderen geeigneten Instrumenten

    In der Verordnung werden zentrale gemeinsame Mindestanforderungen an die Sicherheits-, Resilienz- und Umweltaspekte von Weltraumtätigkeiten für Unionsbetreiber im Bereich Weltraum sowie für Betreiber mit Sitz in Drittländern, die weltraumgestützte Daten in der Union bereitstellen, festgelegt.

    Gleichzeitig baut diese Verordnung auf bestimmten grundlegenden Elementen des neuen Rechtsrahmens auf, wie notifizierte Stellen, Konformitätsbewertungen und die Entwicklung harmonisierter Normen, die jedoch unter Berücksichtigung eines schrittweisen Regulierungsansatzes in diesem Bereich auf die Bedürfnisse des Weltraumbereichs zugeschnitten und angepasst sind.

    Der Vorschlag würde auf den Strukturen und Mechanismen aufbauen, die im Rahmen anderer Rechtsvorschriften über Resilienz und Cybersicherheit wie der Richtlinie 2022/2555 (NIS2-Richtlinie) und der Richtlinie 2022/2557 (CER-Richtlinie) entwickelt wurden, und die Koordinierung mit diesen sicherstellen.

    Was die ökologische Nachhaltigkeit betrifft, so spiegelt die Einbeziehung der Grundsätze der Lebenszyklusanalyse (LCA) in Weltraumtätigkeiten das übergeordnete Ziel der Union wider, mehr Nachhaltigkeit und ökologische Verantwortung im Weltraumsektor zu erreichen.

    Es ist von größter Bedeutung, die Einhaltung der Ökodesign-Verordnung für nachhaltige Produkte (Verordnung (EU) 2024/1781) sicherzustellen, die einen digitalen Produktpass für Produkte erfordert, die unter die vorliegende Verordnung fallen, und somit potenziell auch für Weltraumtätigkeiten gilt. Bei der Regulierung von Produkten, die sich auf diese Tätigkeiten auswirken, werden die Einzelziele und Einschränkungen der Weltraumtätigkeiten berücksichtigt.

    Die Integration der Lebenszyklusanalyse in weltraumbezogene Projekte durch die Anwendung einer gemeinsamen Methode (auf der Grundlage der Empfehlung der Kommission zu PEF- und PEF-Methoden C(2021) 9332 final) erleichtert die Einhaltung der Rechtsrahmen und verbessert Nachhaltigkeitsbewertungen und Offenlegungen, wodurch die Angleichung an die MFR-Ziele und Synergien mit anderen Instrumenten gefördert werden, die darauf abzielen, die Weltraumtätigkeiten der Union auf nachhaltige und verantwortungsvolle Weise voranzubringen.

1.5.5. Bewertung der verschiedenen verfügbaren Finanzierungsoptionen, einschließlich der Möglichkeiten für eine Umschichtung

    Das Management der Handlungsbereiche, die der Agentur zugewiesen werden, passt zu ihrem bestehenden Mandat und gehört zu ihren bestehenden allgemeinen Aufgaben. Für diese Handlungsbereiche werden jedoch auch spezifische Profile oder neue Aufgaben erforderlich sein, die nicht vollständig von den vorhandenen Ressourcen der Agentur bewältigt oder durch Umschichtung gelöst werden können.

    Für bestimmte horizontale Aufgaben (z. B. administrative Unterstützung, Rechtsberatung, Vertragsverwaltung) könnte die Agentur vorhandene Ressourcen nutzen, was zu Effizienzgewinnen führen würde. Synergien werden auch mit bestehenden internen technischen Strukturen (z. B. gesicherte IT-Umgebung für den Austausch von Verschlusssachen mit den Sicherheitsüberwachungszentren der Mitgliedstaaten) geschaffen.

1.6. Laufzeit der vorgeschlagenen Maßnahme/der Initiative und Dauer der finanziellen Auswirkungen

  - ☐ Befristete Laufzeit

    - ☐ Laufzeit: [TT.MM.]JJJJ bis [TT.MM.]JJJJ

    - ☐ Finanzielle Auswirkungen auf die Mittel für Verpflichtungen von JJJJ bis JJJJ und auf die Mittel für Zahlungen von JJJJ bis JJJJ

  - ☑ Unbefristete Laufzeit

      Anlaufphase von 2030 bis 2031

      Anschließend reguläre Umsetzung

1.7. Vorgeschlagene Haushaltsvollzugsart(en)^(38)^(6)

  - ☑ Direkte Mittelverwaltung durch die Kommission

    - ☑ über ihre Dienststellen, einschließlich ihres Personals in den EU-Delegationen

    - ☐ über Exekutivagenturen

  - ☐ Geteilte Mittelverwaltung mit Mitgliedstaaten

  - ☐ Indirekte Mittelverwaltung durch Übertragung von Haushaltsvollzugsaufgaben an:

    - ☐ Drittländer oder die von ihnen benannten Einrichtungen

    - ☐ internationale Organisationen und deren Agenturen (bitte angeben)

    - ☐ die Europäische Investitionsbank und den Europäischen Investitionsfonds

    - ☐ Einrichtungen im Sinne der Artikel 70 und 71 der Haushaltsordnung

    - ☐ öffentlich-rechtliche Körperschaften

    - ☐ privatrechtliche Einrichtungen, die im öffentlichen Auftrag tätig werden, sofern ihnen ausreichende finanzielle Garantien bereitgestellt werden

    - ☐ privatrechtliche Einrichtungen eines Mitgliedstaats, die mit der Umsetzung einer öffentlich-privaten Partnerschaft betraut werden und denen ausreichende finanzielle Garantien bereitgestellt werden

    - ☐ Einrichtungen oder Personen, die mit der Durchführung bestimmter Maßnahmen im Bereich der Gemeinsamen Außen- und Sicherheitspolitik im Rahmen des Titels V des Vertrags über die Europäische Union betraut und die in dem maßgeblichen Basisrechtsakt benannt sind

    - ☐ in einem Mitgliedstaat ansässige Einrichtungen, die dem Privatrecht eines Mitgliedstaats oder dem Unionsrecht unterliegen und im Einklang mit sektorspezifischen Vorschriften für die Betrauung mit der Ausführung von Unionsmitteln oder mit der Erteilung von Haushaltsgarantien in Betracht kommen, insofern diese Einrichtungen von privatrechtlichen, im öffentlichen Auftrag tätig werdenden Einrichtungen kontrolliert und von den Kontrollstellen mit angemessenen finanziellen Garantien mit gesamtschuldnerischer Haftung oder gleichwertigen finanziellen Garantien ausgestattet werden, die bei jeder Maßnahme auf den Höchstbetrag der Unionsunterstützung begrenzt sein können.

    Bemerkungen

2. VERWALTUNGSMAẞNAHMEN

2.1. Überwachung und Berichterstattung

    Die Verordnung wird innerhalb von fünf Jahren nach Inkrafttreten und danach weiterhin alle fünf Jahre bewertet. Darüber hinaus führen die Europäische Kommission und die Agentur mehrere Aufsichtsmaßnahmen durch, um die Wirksamkeit und Effizienz der Maßnahmen kontinuierlich zu bewerten, und zwar im Rahmen der Beaufsichtigung der Kontrolle der Anwendung der Maßnahmen, einschließlich der Überwachung und Analyse neu auftretender Aspekte im Zusammenhang mit der Anwendung der Anforderungen.

    Die Einzelziele und die entsprechenden Indikatoren werden jährlich überwacht.

    Die Europäische Kommission führt insbesondere eine Kurzzeitevaluierung durch, um die Leistung der Agentur in Bezug auf ihre Aufgaben im Rahmen dieser Verordnung zu bewerten. Die Europäische Kommission wird die Ergebnisse dieser Bewertung dem Europäischen Parlament und dem Rat übermitteln.

2.2. Verwaltungs- und Kontrollsystem(e)

2.2.1. Begründung der Haushaltsvollzugsart(en), des Durchführungsmechanismus/der Durchführungsmechanismen für die Finanzierung, der Zahlungsmodalitäten und der Kontrollstrategie, wie vorgeschlagen

    Mit der Verordnung werden neue grundlegende Anforderungen in Bezug auf Weltraumtätigkeiten in der gesamten Union festgelegt und gleichzeitig ein fairer Wettbewerb zwischen den Marktakteuren im Binnenmarkt sichergestellt. Diese neuen Vorschriften erfordern ein Kohärenzverfahren für die grenzüberschreitende Anwendung der Verpflichtungen aus dieser Verordnung sowie direkte Aufsichts- und Durchsetzungsbefugnisse für die Europäische Kommission und technische Bewertungsaufgaben für die Agentur.

    Um diesen neuen Aufgaben gerecht zu werden, müssen die Dienststellen der Europäischen Kommission und die Agentur angemessen mit Ressourcen ausgestattet werden^(39(7). Für die Durchsetzung und erfolgreiche Umsetzung der neuen Verordnung werden schätzungsweise drei VZÄ innerhalb der Europäischen Kommission benötigt (für Aufsichtsaufgaben und für Beschlüsse).

    Für die in der Anlaufphase bis Ende 2027 geplanten vorbereitenden Tätigkeiten werden schätzungsweise zwei VZÄ benötigt, die zusätzlich zu den im derzeitigen mehrjährigen Finanzrahmen (2021-2027) verfügbaren Mitteln beantragt werden.

2.2.2. Angaben zu den ermittelten Risiken und dem/den zu deren Eindämmung eingerichteten System(en) der internen Kontrolle

    Mit der Verordnung wird das Fundament des Binnenmarkts für den Weltraum gelegt. Mehrere und unterschiedliche nationale Regulierungsansätze können den Binnenmarkt fragmentieren, was für Weltraumunternehmen einen hohen Aufwand bedeutet, sich in unterschiedlichen Rechtsrahmen zurechtzufinden und diese anzuwenden.

    Mit der Verordnung werden mehrere Kernanforderungen an die Genehmigung und Registrierung von Weltraumtätigkeiten (technische Vorschriften in den Bereichen Sicherheit, Resilienz und Nachhaltigkeit von Weltraumtätigkeiten) harmonisiert und eine entsprechende Governance-Struktur festgelegt.

    Dieser Ansatz zielt darauf ab, Rechtssicherheit zu schaffen, grenzübergreifende Hindernisse zu beseitigen und den Verwaltungsaufwand und die Kosten zu verringern, die sich aus zahlreichen und unterschiedlichen nationalen Anforderungen ergeben. Dies würde die Art und Weise vereinfachen, wie Betreiber im Bereich Weltraum in der Union tätig sind, insbesondere für neue Marktteilnehmer. Um dem Risiko der Wahl des günstigsten Gerichtsstands vorzubeugen und eine einheitliche Anwendung des neuen Rechtsrahmens zu gewährleisten, werden der Europäischen Kommission neue Aufsichts- und Durchsetzungsbefugnisse übertragen, während die Agentur Befugnisse erhält, um die Kommission durch technische Bewertungen zu unterstützen. Um das Risiko von Verwaltungsaufwand für die Industrie zu verringern, ist eine vereinfachte Regelung für Start-ups, KMU und kleine Midcap-Unternehmen vorgesehen. Um die Weltraumindustrie bei der Umsetzung der Verordnung zu unterstützen, sind darüber hinaus gezielte Unterstützungsmaßnahmen vorgesehen, um einen Teil der möglichen Kosten ihrer Umsetzung für die Industrie, insbesondere für Start-ups und KMU, auszugleichen.

2.2.3. Schätzung und Begründung der Kosteneffizienz der Kontrollen (Verhältnis zwischen den Kontrollkosten und dem Wert der betreffenden verwalteten Mittel) sowie Bewertung des erwarteten Ausmaßes des Fehlerrisikos (bei Zahlung und beim Abschluss)

    nicht zutreffend

2.3. Prävention von Betrug und Unregelmäßigkeiten

    Die für die Europäische Kommission und für Agenturen der Union geltenden Betrugsbekämpfungsmaßnahmen gelten auch für die zusätzlichen Mittel, die für diese Verordnung erforderlich werden.

3. GESCHÄTZTE FINANZIELLE AUSWIRKUNGEN DES VORSCHLAGS/DER INITIATIVE

3.1. Betroffene Rubrik(en) des Mehrjährigen Finanzrahmens und Ausgabenlinie(n) im Haushaltsplan

    Bestehende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM^(40(8) | von EFTA-Ländern^(41(9) | von Kandidatenländern und potenziellen Kandidaten^(42(10) | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

    Neu zu schaffende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM | von EFTA-Ländern | von Kandidatenländern und potenziellen Kandidaten | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

3.2. Geschätzte finanzielle Auswirkungen des Vorschlags auf die Mittel

3.2.1. Übersicht über die geschätzten Auswirkungen auf die operativen Mittel

  - ☑ Für den Vorschlag/die Initiative werden keine operativen Mittel benötigt.

  - ☐ Für den Vorschlag/die Initiative werden die folgenden operativen Mittel benötigt:

3.2.1.1. Mittel aus dem verabschiedeten Haushaltsplan

    in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
| GD <.......> | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(43(11) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <.......> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK <....> des Mehrjährigen Finanzrahmens | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <.......> | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(44(12) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <.......> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| GD <.......> | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Operative Mittel |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) |  |  |  |  | 0,000 |
|  | Zahlungen | (2a) |  |  |  |  | 0,000 |
| Haushaltslinie | Verpflichtungen | (1b) |  |  |  |  | 0,000 |
|  | Zahlungen | (2b) |  |  |  |  | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(45(13) |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  | 0,000 |
| Mittel INSGESAMT für die GD <.......> | Verpflichtungen | =1a+1b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | =2a+2b+3 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK <....> des Mehrjährigen Finanzrahmens | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Operative Mittel INSGESAMT (alle operativen Rubriken) | Verpflichtungen | (4) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | (5) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT (alle operativen Rubriken) | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter den Rubriken 1 bis 6 des Mehrjährigen Finanzrahmens (Referenzbetrag) | Verpflichtungen | = 4+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
|  | Zahlungen | = 5+6 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Rubrik des Mehrjährigen Finanzrahmens | 7 | „Verwaltungsausgaben“^(46(14) |  |  |  |  |  |
| GD DEFIS | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,376 | 0,376 |  |  |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,050 | 0,050 |  |  |
| GD DEFIS INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 0,426 | 0,426 |  |
| GD <.......> | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |  |
| GD <…> INSGESAMT | Mittel | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter der RUBRIK 7 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 0,000 | 0,000 | 0,000 | 0,000 | 0,426 |  |

    in Mio. EUR (3 Dezimalstellen)

|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 7^(47(15) | Verpflichtungen | 0,000 | 0,000 | 0,000 | 0,426 | 0,426 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 0,000 | 0,000 | 0,000 | 0,426 | 0,426 |

3.2.2. Geschätzter Output, der mit operativen Mitteln finanziert wird (nicht auszufüllen im Fall dezentraler Agenturen)

    Mittel für Verpflichtungen, in Mio. EUR (3 Dezimalstellen)

| Ziele und Ergebnisse angeben ⇓ |  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Bei länger andauernden Auswirkungen (siehe 1.6) bitte weitere Spalten einfügen. | INSGESAMT |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art^(48(16) | Durchschnitts- kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Insgesamt Anzahl | Insgesamt Kosten |
| EINZELZIEL Nr. 1^(49(17): [...] |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EINZELZIEL Nr. 2… |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| INSGESAMT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

3.2.3. Übersicht über die geschätzten Auswirkungen auf die Verwaltungsmittel

  - ☐ Für den Vorschlag/die Initiative werden keine Verwaltungsmittel benötigt.

  - ☑ Für den Vorschlag/die Initiative werden die folgenden Verwaltungsmittel benötigt:

3.2.3.1. Mittel aus dem verabschiedeten Haushaltsplan

| BEWILLIGTE MITTEL | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
| RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,376 | 0,376 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,050 | 0,050 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,426 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

3.2.3. Mittel insgesamt

| INSGESAMT BEWILLIGTE MITTEL +EXTERNE ZWECKGEBUNDENE EINNAHMEN | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
| RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,376 | 0,376 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,050 | 0,050 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,426 | 0,426 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,426 | 0,426 |

    Der Mittelbedarf für Personal- und sonstige Verwaltungsausgaben wird durch der Verwaltung der Maßnahme zugeordnete Mittel der GD und/oder durch eine Umschichtung innerhalb der GD gedeckt. Hinzu kommen etwaige zusätzliche Mittel, die der für die Verwaltung der Maßnahme zuständigen GD nach Maßgabe der verfügbaren Mittel im Rahmen der jährlichen Mittelzuweisung zugeteilt werden.

3.2.4. Geschätzter Personalbedarf

  - ☐ Für den Vorschlag/die Initiative wird kein Personal benötigt.

  - ☑ Für den Vorschlag/die Initiative wird das folgende Personal benötigt:

3.2.4.1. Finanziert aus dem verabschiedeten Haushalt

    Schätzung in Vollzeitäquivalenten (VZÄ)^(50(18)

| BEWILLIGTE MITTEL | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 |  |
| --- | --- | --- | --- | --- | --- |
| Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 0 | 0 | 0 | 2 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 |  |
| Externes Personal (in VZÄ) |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 0 | 0 | 0 | 2 |  |

3.2.4.3. Geschätzter Personalbedarf insgesamt

| INSGESAMT BEWILLIGTE MITTEL +EXTERNE ZWECKGEBUNDENE EINNAHMEN | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 |  |
| --- | --- | --- | --- | --- | --- |
| Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 0 | 0 | 0 | 2 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 |  |
| Externes Personal (in Vollzeitäquivalenten) |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 0 | 0 | 0 | 2 |  |

    Für die Durchführung des Vorschlags benötigtes Personal (in VZÄ):

|  | Personal aus den Dienststellen der Kommission | Zusatzpersonal (ausnahmsweise)* |  |  |
| --- | --- | --- | --- | --- |
|  |  | Zu finanzieren aus Rubrik 7 oder Forschung | Zu finanzieren aus einer Haushaltslinie für administrative Unterstützung | Zu finanzieren aus Gebühren |
| Planstellen | 2 |  | Nicht zutreffend |  |
| Externes Personal (VB, ANS, LAK) |  |  |  |  |

    Beschreibung der Aufgaben, die ausgeführt werden sollen durch:

| Beamte und Zeitbedienstete | Einleitung der ersten Koordinierungstätigkeiten, die erforderlich sind, um die Vorbereitung einer Reihe von Sitzungen, Berichtsentwürfen und politischen Arbeiten für die Einrichtung und Umsetzung aller internen Strukturen, Prozesse und Verfahren zu gewährleisten, die erforderlich sind, um die der Agentur durch das Weltraumgesetz übertragenen neuen Zuständigkeiten wahrzunehmen. Die ersten Tätigkeiten können auch die Vorbereitungsarbeiten umfassen, die erforderlich sind, um die Entwicklung und Umsetzung einiger der im Weltraumgesetz vorgesehenen digitalen Lösungen und damit zusammenhängenden Instrumente einzuleiten. |
| --- | --- |
| Externes Personal |  |

3.2.5. Einschätzung der Auswirkungen auf die Investitionen im Zusammenhang mit digitalen Technologien

    Obligatorisch: In die Tabelle unten ist die bestmögliche Einschätzung der für den Vorschlag/die Initiative erforderlichen Investitionen in digitale Technologien einzutragen.

    Wenn dies für die Durchführung des Vorschlags/der Initiative erforderlich ist, sollten die Mittel unter Rubrik 7 ausnahmsweise in der dafür vorgesehenen Haushaltslinie ausgewiesen werden.

    Die Mittel unter den Rubriken 1-6 sollten als „IT-Ausgaben zur Politikunterstützung für operationelle Programme“ ausgewiesen sein. Diese Ausgaben beziehen sich auf die operativen Mittel, die für die Wiederverwendung/den Erwerb/die Entwicklung von IT-Plattformen/Instrumenten verwendet werden, welche in direktem Zusammenhang mit der Durchführung der Initiative und den damit verbundenen Investitionen stehen (z. B. Lizenzen, Studien, Datenspeicherung usw.). Die in dieser Tabelle dargelegten Informationen sollten mit den Angaben in Abschnitt 4 „Digitale Aspekte“ vereinbar sein.

| Mittel INSGESAMT für Digitales und IT | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | MFR 2021-2027 INSGESAMT |
| --- | --- | --- | --- | --- | --- |
| RUBRIK 7 |  |  |  |  |  |
| IT-Ausgaben (intern) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Außerhalb der RUBRIK 7 |  |  |  |  |  |
| IT-Ausgaben zur Politikunterstützung für operationelle Programme | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 7 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |

3.2.6. Vereinbarkeit mit dem derzeitigen Mehrjährigen Finanzrahmen

    Der Vorschlag/Die Initiative

  - ☑ kann durch Umschichtungen innerhalb der entsprechenden Rubrik des Mehrjährigen Finanzrahmens (MFR) in voller Höhe finanziert werden.

  - ☐ erfordert die Inanspruchnahme des verbleibenden Spielraums unter der einschlägigen Rubrik des MFR und/oder den Einsatz der besonderen Instrumente im Sinne der MFR-Verordnung.

  - ☐ erfordert eine Änderung des MFR.

3.2.7. Beiträge Dritter

    Der Vorschlag/Die Initiative

  - ☑ sieht keine Kofinanzierung durch Dritte vor.

  - ☐ sieht folgende Kofinanzierung durch Dritte vor:

    Mittel in Mio. EUR (3 Dezimalstellen)

|  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Insgesamt |
| --- | --- | --- | --- | --- | --- |
| Kofinanzierende Einrichtung |  |  |  |  |  |
| Kofinanzierung INSGESAMT |  |  |  |  |  |

3.3. Geschätzte Auswirkungen auf die Einnahmen

  - ☑ Der Vorschlag/Die Initiative wirkt sich nicht auf die Einnahmen aus.

  - ☐ Der Vorschlag/Die Initiative wirkt sich auf die Einnahmen aus, und zwar

    - ☐ auf die Eigenmittel

    - ☐ auf die übrigen Einnahmen

    - ☐ Bitte geben Sie an, ob die Einnahmen bestimmten Ausgabenlinien zugewiesen sind.

    in Mio. EUR (3 Dezimalstellen)

| Einnahmenlinie: | Für das laufende Haushaltsjahr zur Verfügung stehende Mittel | Auswirkungen des Vorschlags/der Initiative^(51(19) |  |  |  |
| --- | --- | --- | --- | --- | --- |
|  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 |
| Artikel .......... |  |  |  |  |  |

    Bitte geben Sie für die sonstigen zweckgebundenen Einnahmen die betreffende(n) Ausgabenlinie(n) im Haushaltsplan an.

    [...]

    Sonstige Anmerkungen (bei der Ermittlung der Auswirkungen auf die Einnahmen verwendete Methode/Formel oder weitere Informationen).

    [...]

4. DIGITALE ASPEKTE

4.1. Anforderungen von digitaler Relevanz

    Der Gesetzgebungsvorschlag sieht die Entwicklung und Umsetzung einer Reihe digitaler Lösungen und zugehöriger Instrumente vor, um die Mitgliedstaaten zu unterstützen und die Weltraumindustrie bei der fristgerechten Umsetzung des Rechtsakts zu unterstützen. Mit der Nutzung digitaler Lösungen sollen verschiedene Tätigkeiten erleichtert werden, z. B. die Verarbeitung von Daten (Erhebung, Verwaltung, Speicherung), Überwachungs- und Verfolgungstätigkeiten, Berichterstattung und Durchführung von Analysen, und es soll die Interaktion zwischen den einschlägigen Interessenträgern erleichtert werden:

| Beschreibung der Anforderung | Betroffene Interessengruppen | Betroffene(r) Prozess(e) |
| --- | --- | --- |
| Das Unionsregister der Weltraumobjekte (URSO) ist ein digitales Register, das für die Erhebung, die Verarbeitung und den Austausch von Daten über registrierte Betreiber im Bereich Weltraum, die für den Betrieb und die Erbringung weltraumgestützter Dienste in der Union zugelassen sind, verwendet wird. | Agentur der Europäischen Union für das Weltraumprogramm, Anbieter von Weltraumdiensten außerhalb der EU | Einrichtung und Verwaltung eines digitalen Registers |
| Die Kontaktlistendatenbank der Union für Warnmeldungen zu Ereignissen von hohem Interesse ist eine digitale Lösung, die für die Erhebung, die Verarbeitung und den Austausch von Kontaktdaten der einschlägigen Mitarbeiter verwendet wird, die für Kollisionsvermeidungs- und Wiedereintrittstätigkeiten, die von den in der Union tätigen Raumfahrzeugbetreibern gemeldet werden, zuständig sind. | Agentur der Europäischen Union für das Weltraumprogramm, Anbieter von EU- und Nicht-EU-Weltraumdiensten | Einrichtung und Verwaltung einer digitalen Datenbank |
| Das zentrale Informationsportal ist eine digitale Plattform, die für die Erhebung, die Verarbeitung und den Austausch von Daten genutzt wird, um eine Reihe von Diensten für die Verwaltung des Genehmigungsverfahrens für Weltraumtätigkeiten auf nationaler Ebene bereitzustellen. | Europäische Kommission, Agentur der Europäischen Union für das Weltraumprogramm, Mitgliedstaaten, Anbieter von EU-Weltraumdiensten | Einrichtung und Verwaltung einer digitalen Plattform |
| Das elektronische Rückverfolgbarkeitszertifikat wird Anbietern von Weltraumdiensten zur Bescheinigung der Konformität von Weltraumobjekten mit den Anforderungen der Verordnung für die Zwecke der Verwendung dieser Objekte in der Union ausgestellt. | Agentur der Europäischen Union für das Weltraumprogramm, Anbieter von Weltraumdiensten | Einrichtung und Verwaltung der digitalen Lösung |
| Die Datenbank zum Umweltfußabdruck ist eine digitale öffentliche Datenbank, die für Sammlungs- und Verarbeitungstätigkeiten genutzt wird. Außerdem werden der Öffentlichkeit die Daten zur Verfügung gestellt, die für die Berechnung des Umweltfußabdrucks erforderlich sind. | Europäische Kommission, Agentur der Europäischen Union für das Weltraumprogramm, Mitgliedstaaten, Anbieter von EU-Weltraumdiensten | Einrichtung und Verwaltung der digitalen Datenbank |

4.2. Daten

    (1) Unionsregister der Weltraumobjekte (URSO): URSO wird Informationen über Anbieter von Weltraumdiensten sammeln und verarbeiten, die für den Betrieb und die Erbringung weltraumgestützter Dienste in der EU zugelassen oder registriert sind. Die Datenverwaltung wird mit der europäischen Datenstrategie im Einklang stehen, wobei der Schwerpunkt auf dem sicheren Austausch, der sicheren Weiterverwendung und minimaler Doppelarbeit durch den Grundsatz der einmaligen Erfassung liegt. Die Agentur wird URSO einrichten und verwalten, um Transparenz und eine einheitliche Durchsetzung in allen Mitgliedstaaten zu gewährleisten.

    (2) Kontaktlistendatenbank der Union für Warnmeldungen zu Ereignissen von hohem Interesse: Diese Datenbank enthält die Kontaktdaten des für Kollisionsvermeidung und Wiedereintritt zuständigen Personals. Sie wird so konzipiert, dass sie den Standarddatenformaten entspricht und den Datenschutz gewährleistet. Im Einklang mit dem Grundsatz der einmaligen Erfassung wird angestrebt, vorhandene überprüfte Kontaktinformationen wiederzuverwenden, um redundante Einträge so gering wie möglich zu halten. Wenn sich die operativen Zuständigkeiten ändern, werden die Anbieter von Weltraumdiensten der Agentur aktualisierte Datensätze zur Verfügung stellen, die zeitnahe Warnmeldungen und eine Koordinierung der Reaktion ermöglichen.

    (3) Zentrales Informationsportal: Dieses Portal wird das Genehmigungsverfahren für Weltraumtätigkeiten straffen. Es wird auf gemeinsamen Datenstandards für eine nahtlose Integration mit bestehenden Systemen aufbauen. Der Grundsatz der einmaligen Erfassung verringert doppelte Auskunftsersuchen, während ein regelmäßiger Datenaustausch, der durch Lizenzanträge oder Aktualisierungen eingeleitet wird, sicherstellen wird, dass Behörden, die Agentur und die Betreiber die Fortschritte bei der Erteilung von Genehmigungen effektiv verfolgen können.

    (4) Elektronisches Zertifikat: Mit dem elektronischen Zertifikat wird bescheinigt, dass der Anbieter von Weltraumdiensten die Verordnung mit den technischen Spezifikationen enthält. Im Einklang mit der europäischen Datenstrategie wird die Agentur bestrebt sein, vorhandene Register- und Lizenzdaten zu nutzen, um Doppelarbeit zu vermeiden. Das Zertifikat wird ausgestellt, wenn ein Betreiber die Anforderungen der Verordnung erfüllt.

    (5) Datenbank zum Umweltfußabdruck: Die Datenbank zum Umweltfußabdruck wird hochwertige Lebenszyklusinventardaten liefern, die mit den EU-Standards im Einklang stehen und weltraumbezogene Studien über den Umweltfußabdruck von Produkten und Organisationen unterstützen. Sie folgt der europäischen Datenstrategie, indem sie die Weiterverwendung, Interoperabilität und Transparenz von Daten fördert und die Einhaltung der Nachhaltigkeitsziele sicherstellt. Die Datenbank entspricht dem Grundsatz der einmaligen Erfassung und minimiert Redundanz durch die Integration bestehender Datensätze. Die Daten werden von Interessenträgern aus der Industrie, Forschungseinrichtungen und Behörden bereitgestellt, wobei der Zugang öffentlich ist, einschließlich des Zugangs für Unternehmen und politische Entscheidungsträger für die regulatorische Berichterstattung und Nachhaltigkeitsbewertungen. Der Austausch wird durch Einhaltungsverpflichtungen und freiwillige Umweltverträglichkeitsprüfungen ausgelöst, die regelmäßig oder bei Bedarf durchgeführt werden.

4.3. Digitale Lösungen

    Im Rahmen der Verordnung sind folgende digitale Lösungen vorgesehen:

    — Das Unionsregister der Weltraumobjekte (URSO), eine von der Agentur eingerichtete und verwaltete digitale Plattform, einschließlich der Liste der registrierten Anbieter von Weltraumdiensten, die in der Union für den Betrieb und die Erbringung weltraumgestützter Dienste zugelassen sind;

    — die Kontaktlistendatenbank der Union für Warnmeldungen zu Ereignissen von hohem Interesse, ein von der Agentur eingerichtetes und verwaltetes digitales Register, einschließlich der von Raumfahrzeugbetreibern gemeldeten Kontaktdaten des für Kollisionsvermeidung und Wiedereintritt zuständigen Personals;

    — das Zentrale Informationsportal, eine von der Europäischen Kommission mit Unterstützung der Agentur eingerichtete und verwaltete digitale Plattform, die eine bestimmte Anzahl von Diensten für die Verwaltung des Genehmigungsverfahrens für die Durchführung von Weltraumtätigkeiten auf nationaler Ebene bietet (Konzept einer zentralen Anlaufstelle), um Verwaltungsvereinfachung und gestraffte Compliance-Verfahren insbesondere für Start-up-Unternehmen, Scale-ups, KMU und kleine Midcap-Unternehmen sowie die Interoperabilität zwischen der nationalen und der EU-Ebene sicherzustellen;

    — das elektronische Rückverfolgbarkeitszertifikat, ein digitales Zertifikat, das die Agentur Anbietern von Weltraumdiensten zur Bescheinigung der Konformität von Weltraumobjekten mit den Anforderungen der Verordnung für die Zwecke der Verwendung dieser Objekte in der Union ausstellt;

    — PEFCR4Space Calculator, ein Instrument zur Berechnung des Umweltfußabdrucks weltraumbezogener Tätigkeiten gemäß den Leitlinien und Standards der Kategorieregeln für die Berechnung des Umweltfußabdrucks für den Weltraumsektor;

    — PEFCR4Space-Helpdesk, ein Dienst, der Nutzern Unterstützung und Anleitung bei der Umsetzung der speziell für die Weltraumindustrie konzipierten Produktkategorienregeln für die Berechnung des Umweltfußabdrucks von Produkten bietet und ihnen bei der Bewältigung etwaiger Herausforderungen oder Fragen hilft;

    — in der öffentlichen Datenbank zum Umweltfußabdruck werden Lebenszyklus-Inventardaten erfasst, die für die Bewertung des Umweltfußabdrucks im Weltraumsektor erforderlich sind.

4.4. Interoperabilitätsbewertung

    — Unionsregister der Weltraumobjekte (URSO): URSO wird die grenzüberschreitende Interoperabilität durch die Anwendung gemeinsamer Rechtsrahmen und technischer Normen unterstützen, die es der Agentur ermöglichen, Lizenzierungs- und Überwachungsdaten zu registrieren. Sie könnte Lösungen für ein interoperables Europa wie standardisierte Datenkennungen verwenden;

    — Kontaktlistendatenbank der Union für Warnmeldungen zu Ereignissen von hohem Interesse: Die Datenbank wird die sofortige grenzüberschreitende Kommunikation bei Kollisionen oder Wiedereintrittsereignissen unter Verwendung harmonisierter Datenformate für Kontaktangaben und Warnprotokolle gewährleisten. Mit dieser Vereinbarung wird die Notfallkoordinierung zwischen Interessenträgern aus der EU und außerhalb der EU gestrafft, wobei die Metadaten und Authentifizierungslösungen für ein interoperables Europa zur Standardisierung von Datensätzen beitragen;

    — Zentrales Informationsportal: Das Portal soll für eine nahtlose Interaktion zwischen mehreren EU- und nationalen Systemen konzipiert werden, um die Interoperabilität durch standardisierte Datenaustauschformate, Protokolle und eine einheitliche digitale Schnittstelle zu fördern, um den Verwaltungsaufwand zu verringern;

    — Elektronisches Zertifikat: Wird sich auf interoperable digitale Signaturen und standardisierte Compliance-Datenfelder stützen;

    — Datenbank zum Umweltfußabdruck (EF): Die Datenbank der Union zum Umweltfußabdruck (EF-Datenbank) unterstützt grenzüberschreitende digitale öffentliche Dienste, indem sie einen standardisierten Austausch von Daten über die Umweltauswirkungen zwischen Einrichtungen und öffentlichen Einrichtungen in der EU ermöglicht. Sie verbessert die grenzüberschreitende Interoperabilität durch rechtliche, semantische und technische Angleichung, indem Lösungen für ein interoperables Europa wie Metadatenstandards und API-gestützter Datenaustausch genutzt werden. Zu den wichtigsten Hindernissen zählen regulatorische Unterschiede, Unstimmigkeiten im Datenformat und Herausforderungen bei der technischen Integration. Diese Bewertung steht im Einklang mit der Verordnung (EU) 2024/903 (Verordnung für ein interoperables Europa) und unterstützt die Ziele des europäischen Grünen Deals und der Kreislaufwirtschaft.

4.5. Unterstützungsmaßnahmen für die digitale Umsetzung

    Der Legislativvorschlag sieht die Entwicklung und Umsetzung verschiedener digitaler Lösungen und zugehöriger Instrumente vor, um die Mitgliedstaaten zu unterstützen und die Weltraumindustrie bei der fristgerechten Umsetzung des Vorschlags zu unterstützen.

    Die digitalen Lösungen werden für die Erhebung, die Verarbeitung und den Austausch von Daten in Bezug auf die verschiedenen, unter den Vorschlag fallenden Bereiche (Sicherheit, Resilienz und ökologische Nachhaltigkeit) sowie in Bezug auf das Genehmigungsverfahren für die Durchführung von Weltraumtätigkeiten auf nationaler Ebene und die Registrierung von Betreibern aus Drittländern auf Unionsebene genutzt. Die Europäische Kommission und die Agentur werden eine direkte und aktive Rolle bei der Entwicklung und Verwaltung dieser digitalen Lösungen spielen.

<a id="notes"></a>
## Fußnoten

^(1) ^(1) Politische Leitlinien für die nächste Europäische Kommission 2024-2029, vorgestellt von Ursula von der Leyen am 18.7.2025; https://commission.europa.eu/document/e6cd4328-673c-4e7a-8683-f63ffb2cf648_de.

^(2) ^(2) Die Zukunft der europäischen Wettbewerbsfähigkeit: Bericht von Mario Draghi vom 9.9.2024.

^(3) ^(3) Gemeinsame Mitteilung der Kommission und des Hohen Vertreters der Union für Außen- und Sicherheitspolitik an das Europäische Parlament und den Rat (JOIN(2022) 4 final vom 15.2.2022) und Gemeinsame Mitteilung an das Europäische Parlament und den Rat über eine Weltraumstrategie für Sicherheit und Verteidigung (JOIN(2023) 9 final vom 10.3.2023).

^(4) ^(4) Schlussfolgerungen des Rates zur EU-Weltraumstrategie für Sicherheit und Verteidigung, 14512/23, angenommen am 13. November 2023; https://data.consilium.europa.eu/doc/document/ST-14512-2023-INIT/de/pdf.

^(5) ^(5) Schlussfolgerungen 15231/23 zum Thema „Weltraumverkehrsmanagement: Sachstand“, angenommen am 8. Dezember 2023; https://www.consilium.europa.eu/de/press/press-releases/2023/12/08/space-traffic-management-council-adopts-conclusions-on-the-current-state-of-play.

^(6) ^(6) https://www.assemblee-nationale.fr/dyn/16/dossiers/loi_europeenne_espace.

^(7) ^(7) Insbesondere in Positionspapieren von Eurospace (Verband, der die Standpunkte von mehr als 80 Weltraumunternehmen, einschließlich Primes, vertritt), SME4Space (Verband, der die Standpunkte von mehr als 800 Unternehmen, darunter 90 Start-up-Unternehmen, vertritt), YEESS (neu gegründeter Verband, der die Standpunkte von 13 New-Space-Unternehmen vertritt).

^(8) ^(8) Der europäische Grüne Deal – Europäische Kommission (europa.eu).

^(9) ^(9) Langfristige Strategie – Zeithorizont 2050 – Europäische Kommission (europa.eu).

^(10) ^(10) Empfehlung zur Anwendung von Methoden zur Berechnung des Umweltfußabdrucks – Europäische Kommission (europa.eu).

^(11) ^(11) Dies ist beispielsweise offenkundig, was die Auswirkungen im Zusammenhang mit der Verbrennung von Treibstoff, der Entsorgung von Raketenstufen, dem Umweltrisiko beim Wiedereintritt und den Auswirkungen von in Weltraummissionen integrierten Kernenergiequellen angeht.

^(12) ^(12) Richtlinie (EU) 2022/2464 – Richtlinie über die Nachhaltigkeitsberichterstattung von Unternehmen – https://eur-lex.europa.eu/eli/dir/2022/2464/oj.

^(13) ^(13) Rechtssache C-376/98, Bundesrepublik Deutschland gegen Europäisches Parlament und Rat der Europäischen Union [2000], Slg. I-8419, Rechtssache C-380/03, Bundesrepublik Deutschland gegen Europäisches Parlament und Rat der Europäischen Union, Slg. [2006] I-1157.

^(14) ^(14) Links zur Zusammenfassung und zur positiven Stellungnahme des Ausschusses für Regulierungskontrolle werden nach ihrer Veröffentlichung eingefügt.

^(15) ^(1) ABl. C [...] vom [...], S. [...].

^(16) ^(2) ABl. C [...] vom [...], S. [...].

^(17) ^(3) Richtlinie (EU) 2022/2557 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über die Resilienz kritischer Einrichtungen und zur Aufhebung der Richtlinie 2008/114/EG des Rates (CER-Richtlinie) (ABl. L 333 vom 27.12.2022, S. 164, ELI: https://eur-lex.europa.eu/eli/dir/2022/2557/oj).

^(18) ^(4) Richtlinie (EU) 2022/2555 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über Maßnahmen für ein hohes gemeinsames Cybersicherheitsniveau in der Union, zur Änderung der Verordnung (EU) Nr. 910/2014 und der Richtlinie (EU) 2018/1972 sowie zur Aufhebung der Richtlinie (EU) 2016/1148 (NIS-2-Richtlinie) (ABl. L 333 vom 27.12.2022, S. 80, ELI: https://eur-lex.europa.eu/eli/dir/2022/2555/oj).

^(19) ^(5) Verordnung (EU) 2021/696 des Europäischen Parlaments und des Rates vom 28. April 2021 zur Einrichtung des Weltraumprogramms der Union und der Agentur der Europäischen Union für das Weltraumprogramm und zur Aufhebung der Verordnungen (EU) Nr. 912/2010, (EU) Nr. 1285/2013 und (EU) Nr. 377/2014 sowie des Beschlusses Nr. 541/2014/EU (ABl. L 170 vom 12.5.2021, S. 69, ELI: http://data.europa.eu/eli/reg/2021/696/oj).

^(20) ^(6) Verordnung (EU) 2023/588 des Europäischen Parlaments und des Rates vom 15. März 2023 zur Einrichtung des Programms der Union für sichere Konnektivität für den Zeitraum 2023-2027 (ABl. L 79 vom 17.3.2023, S. 1, ELI: http://data.europa.eu/eli/reg/2023/588/oj).

^(21) ^(7) Entscheidung Nr. 676/2002/EG des Europäischen Parlaments und des Rates vom 7. März 2002 über einen Rechtsrahmen für die Funkfrequenzpolitik in der Europäischen Gemeinschaft (Frequenzentscheidung) (ABl. L 108 vom 24.4.2002, S. 1, ELI: http://data.europa.eu/eli/dec/2002/676(1)/oj).

^(22) ^(8) Richtlinie (EU) 2018/1972 des Europäischen Parlaments und des Rates vom 11. Dezember 2018 über den europäischen Kodex für die elektronische Kommunikation (ABl. L 321 vom 17.12.2018, S. 36, ELI: http://data.europa.eu/eli/dir/2018/1972/oj).

^(23) ^(9) Beschluss Nr. 243/2012/EU des Europäischen Parlaments und des Rates vom 14. März 2012 über ein Mehrjahresprogramm für die Funkfrequenzpolitik (ABl. L 81 vom 21.3.2012, S. 7, ELI: http://data.europa.eu/eli/dec/2012/243(2)/oj).

^(24) ^(10) Richtlinie 2008/98/EG des Europäischen Parlaments und des Rates vom 19. November 2008 über Abfälle und zur Aufhebung bestimmter Richtlinien (ABl. L 312 vom 22.11.2008, S. 3, ELI: http://data.europa.eu/eli/dir/2008/98/2024-02-18).

^(25) ^(11) Empfehlung 2003/361/EG der Kommission vom 6. Mai 2003 betreffend die Definition der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen (ABl. L 124 vom 20.5.2003, S. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj).

^(26) ^(12) Richtlinie 2008/114/EG des Rates vom 8. Dezember 2008 über die Ermittlung und Ausweisung europäischer kritischer Infrastrukturen und die Bewertung der Notwendigkeit, ihren Schutz zu verbessern (ABl. L 345 vom 23.12.2008, S. 75, ELI: http://data.europa.eu/eli/dir/2008/114/oj).

^(27) ^(13) Verordnung (EU) 2016/679 des Europäischen Parlaments und des Rates vom 27. April 2016 zum Schutz natürlicher Personen bei der Verarbeitung personenbezogener Daten, zum freien Datenverkehr und zur Aufhebung der Richtlinie 95/46/EG (Datenschutz-Grundverordnung) (ABl. L 119 vom 4.5.2016, S. 1, ELI: http://data.europa.eu/eli/reg/2016/679/oj).

^(28) ^(14) Verordnung (EG) Nr. 765/2008 des Europäischen Parlaments und des Rates vom 9. Juli 2008 über die Vorschriften für die Akkreditierung und Marktüberwachung im Zusammenhang mit der Vermarktung von Produkten und zur Aufhebung der Verordnung (EWG) Nr. 339/93 (ABl. L 218 vom 13.8.2008, S. 30, ELI: http://data.europa.eu/eli/reg/2008/765/oj).

^(29) ^(15) Verordnung (EU) Nr. 1025/2012 des Europäischen Parlaments und des Rates vom 25. Oktober 2012 zur europäischen Normung, zur Änderung der Richtlinien 89/686/EWG und 93/15/EWG des Rates sowie der Richtlinien 94/9/EG, 94/25/EG, 95/16/EG, 97/23/EG, 98/34/EG, 2004/22/EG, 2007/23/EG, 2009/23/EG und 2009/105/EG des Europäischen Parlaments und des Rates und zur Aufhebung des Beschlusses 87/95/EWG des Rates und des Beschlusses Nr. 1673/2006/EG des Europäischen Parlaments und des Rates Text von Bedeutung für den EWR (ELI: http://data.europa.eu/eli/reg/2012/1025/oj).

^(30) ^(16) Verordnung (EU) 2019/881 des Europäischen Parlaments und des Rates vom 17. April 2019 über die ENISA (Agentur der Europäischen Union für Cybersicherheit) und über die Zertifizierung der Cybersicherheit von Informations- und Kommunikationstechnik und zur Aufhebung der Verordnung (EU) Nr. 526/2013 (Rechtsakt zur Cybersicherheit) (Text von Bedeutung für den EWR, ELI: http://data.europa.eu/eli/reg/2019/881/oj).

^(31) ^(17) Verordnung (EU) Nr. 182/2011 des Europäischen Parlaments und des Rates vom 16. Februar 2011 zur Festlegung der allgemeinen Regeln und Grundsätze, nach denen die Mitgliedstaaten die Wahrnehmung der Durchführungsbefugnisse durch die Kommission kontrollieren (ABl. L 55 vom 28.2.2011, S. 13, ELI: http://data.europa.eu/eli/reg/2011/182/oj).

^(32) ^(18) Empfehlung (EU) 2021/2279 der Kommission vom 15. Dezember 2021 zur Anwendung der Methoden für die Berechnung des Umweltfußabdrucks zur Messung und Offenlegung der Umweltleistung von Produkten und Organisationen entlang ihres Lebenswegs (ABl. L 471 vom 30.12.2021, S. 1, ELI: http://data.europa.eu/eli/reco/2021/2279/oj).

^(33) ^(1) Die Zielwerte werden für einen Zeitraum von 10 Jahren nach Inkrafttreten des Gesetzes geschätzt, wobei die durchschnittliche Lebensdauer kommerzieller Satelliten in allen Umlaufbahnen berücksichtigt wird.

^(34) ^(2) Unter Berücksichtigung dessen, dass mehrere nationale Weltraumvorschriften im EU-Raum wie z. B. in Frankreich, Belgien, Dänemark, Finnland und Griechenland die Betreiber für die Erteilung von Lizenzen bereits zur Durchführung von Umweltverträglichkeitsprüfungen verpflichten.

^(35) ^(3) Unter Berücksichtigung dessen, dass Kleinstunternehmen und Hochschulen möglicherweise Ausnahmen unterliegen und etwa 10-20 % der Weltraummissionen in Europa ausmachen.

^(36) ^(4) Ebenda.

^(37) ^(5) Im Sinne des Artikels 58 Absatz 2 Buchstabe a oder b der Haushaltsordnung.

^(38) ^(6) Erläuterungen zu den Haushaltsvollzugsarten und die Haushaltsordnung können über die Website BUDGpedia (in englischer Sprache) abgerufen werden: https://myintracomm.ec.europa.eu/corp/budget/financial-rules/budget-implementation/Pages/implementation-methods.aspx.

^(39) ^(7) Schätzungen zufolge wird die Agentur ab 2028 17 VZÄ für die Verwaltung der neuen Aufgaben und ab 2028 1 VZÄ der ENISA benötigen. Zu den neuen Aufgaben der Agentur gehören die Entwicklung eines Weltraumsiegelsystems der Union für Weltraumtätigkeiten und die Verwaltung der Tätigkeiten im Zusammenhang mit den technischen Bewertungen, um die Kommission bei der Genehmigung und Beaufsichtigung von Unionsbetreibern im Bereich Weltraum, die Ressourcen der Union betreiben, Drittlandsbetreibern im Bereich Weltraum und von internationalen Organisationen zu unterstützen und in diesem Zusammenhang Ermittlungsbefugnisse zur Unterstützung (Inspektionen, Untersuchungen) auszuüben. Die Betriebskosten im Zusammenhang mit den neuen Aufgaben der Agentur werden durch ein System von Registrierungsgebühren, Strafen und Geldbußen gegen Betreiber im Bereich Weltraum (sowohl aus der EU als auch aus Drittstaaten) finanziert. Ein solches System deckt jedoch weder die Personalkosten der Agentur noch die Betriebskosten für Siegel ab.

^(40) ^(8) GM = Getrennte Mittel/NGM = Nichtgetrennte Mittel.

^(41) ^(9) EFTA: Europäische Freihandelsassoziation.

^(42) ^(10) Kandidatenländer und gegebenenfalls potenzielle Kandidaten des Westbalkans.

^(43) ^(11) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(44) ^(12) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(45) ^(13) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(46) ^(14) Der Mittelbedarf sollte auf der Grundlage der Angaben zu den Durchschnittskosten veranschlagt werden, die auf der einschlägigen BUDGpedia-Seite verfügbar sind.

^(47) ^(15) Über das Jahr 2027 hinaus wird vorgeschlagen, die Kosten für die Studien aus dem nachfolgenden MFR zu finanzieren, ohne der Einigung über den MFR und die Programme vorzugreifen.

^(48) ^(16) Outputs sind Produkte, die geliefert, und Dienstleistungen, die erbracht werden (z. B. Zahl der Austauschstudenten, gebaute Straßenkilometer).

^(49) ^(17) Wie in Abschnitt 1.4.2. „Einzelziel(e)“ beschrieben

^(50) ^(18) Bitte unter der Tabelle angeben, wie viele der aufgeführten VZÄ bereits der Verwaltung der Maßnahme zugeordnet sind und/oder durch Personalumschichtung innerhalb der GD dieser Aufgabe zugeteilt werden können. Den Nettobedarf beziffern.

^(51) ^(19) Bei den traditionellen Eigenmitteln (Zölle, Zuckerabgaben) sind die Beträge netto, d. h. abzüglich 20 % für Erhebungskosten, anzugeben.

Anhang I

SICHERHEIT BEIM START GEMÄẞ DEN ARTIKELN 58, 59 UND 60

1. Sicherheit beim Start und Wiedereintritt

1.1. Koordinierungsanforderungen

    Startbetreiber aus der Union setzen die folgenden Koordinierungsanforderungen um:

  - a) Vor dem Start oder Wiedereintritt schließt ein Startbetreiber aus der Union eine Vereinbarung mit

I) dem europäischen Netzmanager und den Anbietern von Flugsicherungsdiensten (ANSP), um sich auf geeignete Maßnahmen zur Minimierung der Auswirkungen der Sperrung der Flugstrecken auf den Luftverkehr zu verständigen und die Verfahren für die Herausgabe der Nachrichten für Luftfahrer (NOTAM) und die Verfahren für die Sperrung der Flugstrecken während der jeweiligen Start- oder Wiedereintrittsfenster festzulegen, und

II) den Seeverkehrsbehörden, um die Verfahren für die Herausgabe der Nachrichten für Seefahrer festzulegen.

  - b) Die Anforderung nach Buchstabe a gilt nicht, wenn der Betreiber des Startplatzes der Union die in Buchstabe a Ziffern i und ii genannten Aspekte bereits mit den ANSP und den Seeverkehrsbehörden abgestimmt hat.

  - c) Die Startbetreiber aus der Union stellen dem Netzmanager und den ANSP rechtzeitig Informationen zur Verfügung, um den Umfang des zu sperrenden Luftraums und die betroffenen Strecken zu ermitteln, damit die Weltraumstarts sicher und effizient in das europäische Flugverkehrsmanagementsystem integriert werden können.

1.2. Kollisionsvermeidung beim Start (LCOLA)

1.2.1. Die LCOLA wird vor dem Start durchgeführt.

1.2.2. Die LCOLA wird mit Unterstützung der in Artikel 64 Absatz 1 genannten maßgeblichen Stelle durchgeführt.

    Der Startbetreiber aus der Union stellt sicher, dass die in Artikel 64 Absatz 1 genannte Stelle die vorhergesagten Ephemeride für die Trägerrakete erhält.

1.2.3. Die Methode zur Berechnung der LCOLA wird von der Kommission gemäß Artikel 59 Absatz 3 Buchstabe a unter Berücksichtigung der Wahrscheinlichkeit einer Kollision der Trägerrakete mit einem Objekt von Interesse entwickelt. Dabei sind folgende Faktoren zu berücksichtigen:

a) ob das Raumfahrzeug bewohnbar ist;

a) die Größe des Objekts;

b) ob das Raumfahrzeug aktiv ist.

1.2.4. Der Startbetreiber aus der Union bewertet und mindert die Kollisionsrisiken im Einklang mit Anhang II Nummer 1.3.

1.2.5. Der Startbetreiber aus der Union legt das Startsperrfenster gemäß der LCOLA-Bewertung fest.

1.3. Unfallrisiko

    Das Unfallrisiko beim Start und beim Wiedereintritt wird durch folgende Maßnahmen begrenzt:

  - a) Die Berechnung des kollektiven Unfallrisikos beim Start und Wiedereintritt erfolgt nach einer genehmigten Methode, die von der Kommission gemäß Artikel 59 Absatz 3 Buchstabe b aus den bestehenden Methoden ausgewählt wird, oder nach einer neuen Methode, die von der Kommission gemäß Artikel 59 Absatz 3 Buchstabe b entwickelt wird. Dabei sind folgende Elemente gebührend zu berücksichtigen:

I) alle Phänomene, bei denen ein Risiko katastrophaler Schäden besteht (Aufstiegsphase, Niedergang der Raketenstufe nach der Abkopplung, Wiedereintritt eines in die Umlaufbahn gebrachten Decks in die Atmosphäre, Phase der Rückführung eines wiederverwendbaren Decks);

II) Flugbahnen vor der Fragmentierung (in der Atmosphäre oder im Weltraum) in Abhängigkeit von den in Betracht gezogenen Flugzeiten und Störungen;

III) die entsprechenden Szenarien für Fragmentierung und Müllentstehung beim Wiedereintritt oder zum Zeitpunkt der Neutralisierung der Trägerrakete und der Rückkehr eines beliebigen Elements der Trägerrakete zur Erde;

IV) die Verteilung des Mülls am Boden und die Bewertung der Auswirkungen;

V) die Zuverlässigkeit der Trägerrakete während der Startphase, gegebenenfalls auch während der Rückführungsphase;

VI) die Zuverlässigkeit des Rückholmanövers des in die Umlaufbahn gebrachten Trägerraketenelements im Fall eines kontrollierten Wiedereintritts.

  - b) Das Unfallrisiko wird auf einen Schwellenwert begrenzt, der im Durchführungsrechtsakt gemäß Artikel 59 Absatz 3 Buchstabe b festgelegt wird. Dabei sind die Unterschiede zwischen den mit den folgenden Risikoszenarien verbundenen Risikoarten gebührend zu berücksichtigen:

I) Risiko beim Start;

II) Risiko beim Wiedereintritt (kontrolliert und unkontrolliert);

III) Risiko für die Phase der Rückführung wiederverwendbarer Komponenten der Trägerrakete.

    Im Durchführungsrechtsakt gemäß Artikel 59 Absatz 3 Buchstabe c werden spezifische quantitative Zuweisungen für ein bestimmtes Risiko katastrophaler Schäden festgelegt, insbesondere für die konkreten Fälle von See- und Luftverkehrsstrecken.

2. Flugsicherheitssystem

2.1. Risikobewertung

2.1.1. In ihren Risikobewertungen ermitteln die Unionsbetreiber im Bereich Weltraum potenzielle Ausfallszenarien, in denen die Trägerrakete zur Gefahr werden könnte.

2.1.2. Die in Nummer 1 genannten Ausfallszenarien umfassen Szenarien für Abweichungen vom Flugkorridor, gefährliche Fallback-Phasen, nichtnominales Flugsteuerungsverhalten und Nichterreichen der Umlaufbahn.

2.1.3. In den Risikobewertungen legen die Startbetreiber aus der Union spezifische Regeln für den kontrollierten oder unkontrollierten Wiedereintritt fest. Im Fall eines kontrollierten Wiedereintritts ermitteln die Startbetreiber aus der Union Ausfallszenarien für das in die Umlaufbahn gebrachte Antriebsobjekt, das zur Gefahr wird, insbesondere für den Fall, dass es nicht gelingt, die Schubhöhe oder -richtung zu steuern.

2.2. Neutralisierung

2.2.1. Das fahrzeugseitige Neutralisierungssystem muss mindestens folgende Anforderungen erfüllen:

a) Das System kann aus der Ferne oder automatisch über einen fahrzeugseitigen Algorithmus aktiviert werden.

b) Bei automatisierten Systemen übermitteln die Startbetreiber aus der Union der zuständigen Behörde detaillierte Daten und die Ergebnisse der Validierungstests.

2.2.2. Für den kontrollierten Wiedereintritt sind besondere Bestimmungen festzulegen.

    Es müssen fahrzeugseitige automatisierte Systeme eingerichtet und Kriterien für einen kontrollierten Wiedereintritt gemäß Nummer 2.1.3 festgelegt werden.

3. Sicherheitsplan für Trägerraketen

    Der Sicherheitsplan für Trägerraketen umfasst mindestens folgende Elemente:

a) die Bestätigung der Koordinierung und Vereinbarung zwischen dem Startbetreiber aus der Union und den ANSP und Seeverkehrsbehörden gemäß Nummer 1.1 Buchstabe a, sofern nicht bereits eine Vereinbarung zwischen dem Betreiber des Startplatzes der Union und den zuständigen Behörden gemäß Nummer 1.1 Buchstabe b getroffen wurde, was durch eine schriftliche Bestätigung belegt wird;

b) das Ergebnis der LCOLA gemäß Nummer 1.2;

c) das Ergebnis der Berechnung des kollektiven Unfallrisikos beim Start und Wiedereintritt gemäß Nummer 1.3;

d) die Risikobewertung des Ausfallszenarios für das Flugsicherheitssystem gemäß Nummer 2.2.

<a id="annex-ii"></a>
## Anhang II

EINDÄMMUNG VON WELTRAUMMÜLL VON TRÄGERRAKETEN GEMÄẞ ARTIKEL 61

1. Eindämmung von Weltraummüll

1.1. Begrenzung der prognostizierten Entstehung von Weltraummüll

1.1.1. Trägerraketen sind so zu konzipieren, dass die Entstehung von Weltraummüll während des Nominalbetriebs gemäß den folgenden Anforderungen begrenzt wird:

  - a) Wird nur ein einzelnes Raumfahrzeug mit einer Trägerrakete in den Weltraum befördert, darf die Gesamtzahl der Orbitalstufen der Trägerraketen und der sich daraus ergebenden Weltraummüllobjekte nicht größer als eins sein.

  - b) Werden mehrere Raumfahrzeuge mit einer einzigen Trägerrakete in den Weltraum befördert, darf die Gesamtzahl zwei nicht überschreiten.

  - c) Trägerraketen, die in den geogeschützten Orbit gebracht werden, müssen mindestens 100 Jahre von den geogeschützten Gebieten ferngehalten werden.

  - d) Trägerraketen, die in die MEO gebracht werden, sind bei Missionsende im Einklang mit den Maßnahmen und dem sicheren Gebiet, wie im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe b festgelegt, zu behandeln.

  - e) Die Verweildauer einer in der LEO platzierten Trägerrakete im Orbit entspricht der im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe a bestimmten Dauer.

  - f) Die Begrenzung des Risikos, dass sich Komponenten von der Trägerrakete lösen und in die Umlaufbahn gelangen, erfolgt durch die im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe a festgelegten Maßnahmen.

1.1.2. Die in Nummer 1.1.1 Buchstaben a und b genannten Anforderungen gelten nicht für das pyrotechnische System und die Fest- oder Hybridtreibstoffe.

1.2. Vermeidung einer Fragmentierung in der Umlaufbahn aufgrund interner Ursachen

1.2.1. Die Wahrscheinlichkeit einer unbeabsichtigten Fragmentierung aufgrund interner Ursachen wird in der im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe c festgelegten Weise begrenzt.

1.2.2. Die Trägerraketen sind so zu konzipieren und zu betreiben, dass am Ende der Weltraummission alle Komponenten wie folgt passiviert werden:

  - a) Alle Energiereserven an Bord müssen dauerhaft erschöpft sein oder sich in einem Zustand befinden, in dem die Erschöpfung der Reserven innerhalb eines angemessenen Zeitraums unvermeidbar ist oder dass keine Gefahr der Entstehung von Müll besteht.

  - b) Alle an Bord befindlichen Mittel zur Energieerzeugung sind dauerhaft zu deaktivieren, und alle Ausrüstungen, die direkt durch Mittel zur Energieerzeugung versorgt werden, sind in einen Zustand zu versetzen, in dem von diesen Ausrüstungen keine Gefahr der Entstehung von Müll ausgeht.

  - c) Nach dem Ende der Lebensdauer muss sich die Trägerrakete in einem stabilen Zustand mit minimaler interner Energie befinden.

1.3. Vermeidung der Fragmentierung durch Kollision

    Im Einklang mit den im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe d festgelegten Anforderungen in Bezug auf Dauer und Schwellenwert werden Risikominderungsmaßnahmen durchgeführt, um die Wahrscheinlichkeit einer Kollision zwischen folgenden Objekten zu verringern:

  - a) Elementen von Trägerraketen und gestarteten Objekten;

  - b) Elementen von Trägerraketen und vorhandenen Weltraumobjekten in der Umlaufbahn (bemannt, unbemannt und Müll).

2. Entsorgung am Ende der Lebensdauer

2.1. Koordinierung des Entwurfs zwischen dem Startbetreiber aus der Union und dem Planer der Raumfahrzeugmission

    Der Startbetreiber aus der Union arbeitet mit dem Planer der Mission für das im Rahmen der jeweiligen Weltraummission in den Weltraum zu befördernde Raumfahrzeug zusammen, um die Startphase der Weltraummission so zu planen, dass die Entsorgung der Orbitalstufe der Trägerrakete erleichtert und die Spezifikation der endgültigen Einschussbahn berücksichtigt wird.

2.2. Entsorgung von Trägerraketen in der LEO

    Die Entsorgung von Trägerraketen in der LEO erfolgt auf eine der folgenden Arten, die in der folgenden Rangfolge auf Grundlage ihrer technischen Durchführbarkeit ausgewählt werden:

  - a) Eine Trägerrakete in der LEO wird durch kontrollierten Wiedereintritt aus der Umlaufbahn entfernt.

      Die Trägerrakete muss so konzipiert sein, dass ein kontrolliertes Zerbrechen der Objekte beim Wiedereintritt („Design for Demise“) oder eine absichtliche Zerstörung der Orbitalstufe der Trägerrakete unter den im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe e festgelegten Bedingungen möglich ist.

  - b) Ist ein kontrollierter Wiedereintritt nicht möglich und das Unfallrisiko bei einem unkontrollierten Wiedereintritt gering, kann die Trägerrakete stattdessen gemäß Nummer 1.1.1 Buchstabe e für einen begrenzten Zeitraum auf eine absinkende Umlaufbahn gebracht werden. Für diesen Fall gilt Folgendes:

I) Das Unfallrisiko wird nach einer standardisierten Methode mit einem begrenzten Risiko von Schäden am Boden gemäß Anhang I Nummer 1.3 Buchstabe a berechnet.

II) Die Trägerrakete muss so konzipiert sein, dass ein kontrolliertes Zerbrechen der Objekte beim Wiedereintritt („Design for Demise“) oder eine absichtliche Zerstörung der Orbitalstufe der Trägerrakete unter den im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe e festgelegten Bedingungen möglich ist.

2.3. Entsorgung von Trägerraketen in der MEO

    Die Entsorgung von Trägerraketen in der MEO erfolgt gemäß Nummer 1.1.1 Buchstabe d für einen begrenzten Zeitraum in einer Umlaufbahn, die geschützte Gebiete und wertvolle Umlaufbahnen nicht beeinträchtigt.

2.4. Entsorgung von Trägerraketen in der GEO

    Die Entsorgung von Trägerraketen in der GEO erfolgt, indem die Trägerrakete in einen Friedhofsorbit gebracht wird, um sicherzustellen, dass sie unter dem Einfluss natürlicher Störungen mindestens 100 Jahre dem geogeschützten Gebiet fernbleibt.

2.5. Wahrscheinlichkeit einer erfolgreichen Entsorgung

2.5.1. Die Startphase einer Weltraummission bzw. die Orbitalstufe einer Trägerrakete sind so zu planen bzw. zu konzipieren, dass die Wahrscheinlichkeit eines erfolgreichen Abschlusses der Entsorgungsmaßnahmen hoch ist.

2.5.2. Die Wahrscheinlichkeit eines erfolgreichen Abschlusses dieser Maßnahmen wird unter Berücksichtigung mindestens der folgenden Elemente berechnet: alle relevanten Systeme, Teilsysteme und Ausrüstungen, einschließlich ihrer potenziellen Redundanz, ihrer Zuverlässigkeit und ihrer Leistungsverschlechterung im Zeitverlauf sowie die Verfügbarkeit der erforderlichen Energie und Ressourcen.

2.5.3. Die Berechnung der Wahrscheinlichkeit erfolgreicher Entsorgungsmaßnahmen und des prozentualen Schwellenwerts erfolgt nach der im Durchführungsrechtsakt gemäß Artikel 61 Absatz 3 Buchstabe f festgelegten Methode.

2.5.4. Startbetreiber aus der Union ermitteln die Systeme und Kapazitäten, die für erfolgreiche Entsorgungsmaßnahmen erforderlich sind, unter anderem:

  - a) Schätzungen und Unsicherheiten im Zusammenhang mit der erfolgreichen Entsorgung;

  - b) die Menge des Treibstoffs, die für das Entsorgungsmanöver oder den Transfer in einen Friedhofsorbit erforderlich ist;

  - c) der Leistungsbedarf für das Entsorgungsmanöver bzw. den Transfer;

  - d) die Steuerungsanforderungen für das Entsorgungsmanöver bzw. den Transfer;

  - e) die Kommunikationsanforderungen für das Entsorgungsmanöver bzw. den Transfer.

2.6. Ausfallreaktionsplan

2.6.1. Bei einem Ausfall, der verhindert, dass die Orbitalstufe der Trägerrakete die Entsorgungsmaßnahmen durchführt, sind alternative Entsorgungsorbits zu wählen, um die Verweildauer in der Umlaufbahn oder das Risiko einer Beeinträchtigung geschützter Gebiete vor dem Verlust kritischer Systeme zu minimieren.

2.6.2. Dies ist vor dem Start im Rahmen einer Ausfallreaktionsplanung festzulegen.

3. Pläne zur Eindämmung von Weltraummüll

3.1. Plan zur Kontrolle von Weltraummüll

    Der Plan zur Kontrolle von Weltraummüll umfasst mindestens die folgenden Elemente:

  - a) Nachweis der Einhaltung der Beschränkungen für die geplante Erzeugung von Weltraummüll gemäß Nummer 1.1.1 Buchstabe a bzw. Nummer 1.1.1 Buchstabe b und Nummer 1.1.1 Buchstabe c sowie Nummer 1.1.2, einschließlich relevanter Test- und Analyseergebnisse;

  - b) Nachweis der Einhaltung der Verweildauer in der Umlaufbahn gemäß Nummer 1.1.1 Buchstaben d, e und f;

  - c) Nachweis der Einhaltung der Anforderung in Bezug auf die Wahrscheinlichkeit einer unbeabsichtigten Fragmentierung gemäß Nummer 1.2.1 und der Maßnahmen zur Risikominderung, wie z. B. Auswahl der Materialien;

  - d) Nachweis der Einhaltung der Maßnahmen zur Passivierung gemäß Nummer 1.2.2, einschließlich relevanter Test- und Analyseergebnisse, und der Anforderung in Bezug auf die Wahrscheinlichkeit einer erfolgreichen Passivierung.

3.2. Plan für die Entsorgung am Missionsende

    Der Plan für die Entsorgung am Missionsende umfasst mindestens folgende Elemente:

  - a) Beschreibung der geplanten Entsorgungsmethode gemäß Nummer 2.2, 2.3 bzw. 2.4 für nominale und nichtnominale Szenarien;

  - b) Bestätigung über die Zusammenarbeit zwischen dem Startbetreiber aus der Union und dem Planer der Raumfahrzeugmission gemäß Nummer 2.1, einschließlich der Spezifikation der endgültigen Einschussbahn;

  - c) Nachweis der Einhaltung der Beschreibung der Einhaltung des Schwellenwerts für die Wahrscheinlichkeit einer erfolgreichen Entsorgung, einschließlich der relevanten Überprüfung und Analyse, gemäß den Nummern 2.5.1, 2.5.2 und 2.5.3;

  - d) Ermittlung von Systemen und Kapazitäten gemäß Nummer 2.5.4;

  - e) Ausfallreaktionsplan gemäß Nummer 2.6.

<a id="annex-iii"></a>
## Anhang III

VERFOLGUNG UND SOFTWARE GEMÄẞ ARTIKEL 63

1. Verfolgung

    Ein Raumfahrzeug muss nach folgenden Grundsätzen verfolgt werden können:

1.1. Die Raumfahrzeugbetreiber aus der Union verfügen entweder selbst über die technischen Mittel oder greifen auf externe Quellen zurück, um die Position des Raumfahrzeugs an die Stelle zu übermitteln, die den Dienst zur Kollisionsvermeidung gemäß Artikel 64 Absatz 1 erbringt.

1.2. Die Fähigkeit, die Position im Sinne der Nummer 1.1 zu übermitteln, muss den Anforderungen der Nummern 1.3 und 1.4 entsprechen.

1.3. Die Ortung in der Umlaufbahn muss so genau wie möglich sein. Dabei ist zu berücksichtigen, dass die Genauigkeit durch das betreffende Gebiet und die Größe des Objekts beeinflusst werden kann.

1.4. Das Verfolgungssystem beruht entweder auf passiver oder aktiver Verfolgung.

1.5. Die Raumfahrzeugbetreiber übermitteln der maßgeblichen Stelle, die den Dienst zur Kollisionsvermeidung im Sinne des Artikels 64 Absatz 1 erbringt, so bald wie möglich nach dem Einschuss alle aktuellen Informationen, die für die Überwachung der Risiken einer Kollision mit den katalogisierten Weltraumobjekten, denen das betreffende Raumfahrzeug begegnen könnte, erforderlich sind.

1.6. Die in Nummer 1.5 genannten Informationen umfassen mindestens die folgenden Angaben:

  - a) Ephemeriden aus den eigenen Systemen des Raumfahrzeugbetreibers der Union für die Umlaufbahn-Wiederherstellung („orbit restitution“) oder aus Weltraumüberwachungssystemen;

  - b) eine Maßnahmenstrategie gemäß Artikel 103;

  - c) Kovarianzen.

2. Softwareanforderungen für das Bodensegment

2.1. Das Bodensegment muss in der Lage sein, eine tägliche Umlaufbahnvorhersage, einschließlich Manövern, für das Raumfahrzeug zu treffen, und zwar für

  - a) 7 Tage im Minutenintervall nach Maßgabe des Formats des Beratenden Ausschusses für Weltraumdatensysteme (CCSDS) in der LEO;

  - b) 14 Tage im Minutenintervall nach Maßgabe des Formats des CCSDS in der MEO;

  - c) 14 Tage im Minutenintervall nach Maßgabe des Formats des CCSDS in der GEO.

2.2. Das Bodensegment stellt eine Rang-7-Kovarianzbildung (Position, Geschwindigkeit, Widerstand) für 7-Tage-Vorhersagen der Flugbahn bereit.

2.3. Das Bodensegment muss in der Lage sein, CCSDS-Datenformate und insbesondere OEM-Nachrichten (Orbital Ephemerides Messages) und CDM-Nachrichten (Conjunction Data Messages, Konjunktionsdatennachrichten) für die Kollisionsvermeidung zu verarbeiten.

<a id="annex-iv"></a>
## Anhang IV

KOLLISIONSVERMEIDUNG GEMÄẞ DEN ARTIKELN 15 UND 64

1. Anforderungen in Bezug auf die Auswahl des Anbieters von Weltraumdiensten zur Kollisionsvermeidung im Sinne des Artikels 15 Absatz 1 Unterabsatz 1 Buchstabe a Ziffer i.

    Drittlandsbetreiber im Bereich Weltraum stellen sicher, dass der von ihnen gemäß Artikel 15 Absatz 1 Unterabsatz 1 Buchstabe a Ziffer i in Anspruch genommene Anbieter von Weltraumdiensten zur Kollisionsvermeidung die folgenden Anforderungen erfüllt:

1.1. Allgemeine Anforderungen

  - a) Die technischen Mittel zur Kollisionsbewertung – ein Kollisionsvermeidungssystem – und Einhaltung der Anforderungen des Abschnitts 1 dieses Anhangs.

      Bei dem Kollisionsvermeidungssystem kann es sich um ein externes oder internes System handeln. Im Fall eines internen Systems müssen geeignete Mechanismen eingerichtet werden, um die Unabhängigkeit des jeweiligen Anbieters von Weltraumdiensten zur Kollisionsvermeidung zu gewährleisten.

  - b) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung stellt seinen Nutzern eine Entscheidung ausreichend früh zur Verfügung, damit Manöver auf der Grundlage hochwertiger Ergebnisse der Konjunktionsbewertung innerhalb eines operativ praktikablen Zeitrahmens durchgeführt werden können.

  - c) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung erbringt Weltraumdienste zur Kollisionsvermeidung für alle Phasen der Mission (vom Start bis zur Entsorgung).

1.2. Anforderungen in Bezug auf die Datenaufnahme

  - a) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung muss in der Lage sein, Umlaufbahnen im Standardformat und die zugehörige Kovarianz, einschließlich geplanter Manöver, in sein System aufzunehmen.

  - b) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung muss in der Lage sein, Daten aus verschiedenen Quellen aufzunehmen, z. B. Ephemeride, die direkt von Raumfahrzeugbetreibern bereitgestellt werden, Umlaufbahnen aus Katalogen von Weltraumobjekten und Konjunktionsdatennachrichten (CDM), die von externen Datenquellen bereitgestellt werden.

  - c) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung muss in der Lage sein, in Ausnahmefällen Kovarianzinformationen zu berechnen, wenn diese nicht in der Datenquelle enthalten sind.

1.3. Anforderungen in Bezug auf die Datenqualitätskontrolle

  - a) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung führt Datenqualitätskontrollen durch, um die Daten der Betreiber im Bereich Weltraum zu bewerten.

  - b) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung kalibriert die Daten der Sensoren.

1.4. Anforderungen in Bezug auf das Kollisionsvermeidungsverfahren

  - a) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung kann bestehende Kataloge und CDM für den operativen Kollisionsvermeidungsdienst nutzen.

  - b) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung unterstützt das Screening von Ephemeriden sowie der Zeitverläufe der operativen und vorhergesagten Positionen und Geschwindigkeiten für alle geplanten Manöver.

  - c) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung nimmt folgende Aufgaben für den Betrieb von Raumfahrzeugen wahr und greift dabei auf verfügbare interne und externe Informationsquellen zurück:

I) Ermittlung von Konjunktionen innerhalb des Screening-Umfangs, angepasst an die Umlaufbahn des geschützten Raumfahrzeugs;

II) Bewertung des Konjunktionsrisikos auf der Grundlage der Kollisionswahrscheinlichkeit und gegebenenfalls anhand von Geometriekriterien (Verfehlweite und Radialentfernung);

III) Erstellung von CDM;

IV) Bereitstellung eines vielfältigen, vom Nutzer wählbaren Satzes von Konjunktionsdaten und „Go/No-Go“-Manövermetriken zur Kollisionsvermeidung, um das Kollisionsrisiko zu bewerten und eine geeignete Vorgehensweise zu entwickeln;

V) Kontrolle, ob durch die Risikominderungsmaßnahmen das zu vermeidende Konjunktionsrisiko verringert wird und sich nicht ein anderes Konjunktionsrisiko unverhältnismäßig erhöht.

  - d) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung wendet allgemein anerkannte Verfahren zur Schätzung der Kollisionswahrscheinlichkeit an, wie z. B. solche, die vom Unionsanbieter von Weltraumdiensten zur Kollisionsvermeidung angewandt werden (vgl. Artikel 64 Absatz 1) und die für eine bestimmte Begegnung geeignet sind.

  - e) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung muss in der Lage sein, sich mit anderen Anbietern von Kollisionsvermeidungsdiensten abzustimmen, insbesondere im Fall von Ereignissen von hohem Interesse.

1.5. Anforderungen in Bezug auf die Aktualität

  - a) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung bewertet regelmäßig das Konjunktionsrisiko.

      Das empfohlene Zeitintervall beträgt einmal pro Tag bei Raumfahrzeugen in der GEO und einmal pro Stunde bei Raumfahrzeugen in der LEO oder MEO (sofern neue Informationen verfügbar sind).

  - b) Der Anbieter von Weltraumdiensten zur Kollisionsvermeidung muss eine Person abstellen, die innerhalb einer Stunde rund um die Uhr Unterstützung leisten kann.

2. Anforderungen in Bezug auf Raumfahrzeugbetreiber aus der Union

2.1. Im Fall manövrierfähiger Raumfahrzeuge müssen die Raumfahrzeugbetreiber aus der Union in der Lage sein, Kollisionsvermeidungsmanöver durchzuführen.

2.2. Bei nicht manövrierfähigen Raumfahrzeugen arbeiten die Raumfahrzeugbetreiber aus der Union nach besten Kräften mit den Anbietern von Weltraumdiensten zur Kollisionsvermeidung im Sinne des Artikels 64 Absatz 1 zusammen.

2.3. Die Raumfahrzeugbetreiber aus der Union stellen dem Unionsanbieter von Weltraumdiensten zur Kollisionsvermeidung im Sinne des Artikels 64 Absatz 1 Informationen über seine operative Umlaufbahn(en) in Form von vorausberechneten Positions- und Geschwindigkeitszeitverläufen für alle geplanten Manöver zur Verfügung, einschließlich realistischer Kovarianzen, und zwar:

  - a) 1 Tag vor der Durchführung geplanter Manöver im Fall nichtautomatisierter Kollisionsvermeidungssysteme;

  - b) schnellstmöglich im Fall automatisierter Kollisionsvermeidungssysteme.

2.4. Der Raumfahrzeugbetreiber aus der Union unterrichtet den Unionsanbieter von Weltraumdiensten im Sinne des Artikels 64 Absatz 1 über

  - a) jede Änderung des aktiven und manövrierfähigen Status seines Raumfahrzeugs;

  - b) jede Änderung in Bezug auf das Ende der Weltraummission;

  - c) außergewöhnliche Operationen;

  - d) jede Änderung der Methode des Wiedereintritts (kontrolliert/halbkontrolliert/unkontrolliert);

  - e) jede Maßnahme, die nach einer Warnung über ein Ereignis von hohem Interesse geplant ist.

2.5. Der für ein manövrierfähiges Raumfahrzeug verantwortliche Raumfahrzeugbetreiber aus der Union gibt eine Kontaktstelle an, die zur Verfügung steht, um wie folgt zu reagieren:

  - a) innerhalb von 8 Stunden rund um die Uhr für LEO;

  - b) innerhalb von 24 Stunden rund um die Uhr für MEO und GEO.

2.6. Der Raumfahrzeugbetreiber aus der Union teilt dem Unionsanbieter von Weltraumdiensten zur Kollisionsvermeidung im Sinne des Artikels 64 Absatz 1 den Radius der Kugel, in dem sich sein Raumfahrzeug befindet, oder einen oberen Schätzwert mit.

2.7. Raumfahrzeugbetreiber aus der Union und der Unionsanbieter von Weltraumdiensten im Sinne des Artikels 64 Absatz 1 legen zum Zeitpunkt der Registrierung von Raumfahrzeugen Folgendes fest:

  - a) in Bezug auf die Elemente, die sich auf die Anforderung des Sicherheitsabstands beziehen, den Grenzwert, bei dessen Überschreitung das Kollisionsrisiko als hoch genug angesehen wird, um eine Warnung für ein Ereignis von hohem Interesse auszulösen;

  - b) spezifische Anforderungen für die verschiedenen Phasen der Mission (Start, Transit, Passivierung, EOL-Operationen).

<a id="annex-v"></a>
## Anhang V

EINDÄMMUNG VON DURCH RAUMFAHRZEUGE VERURSACHTEN WELTRAUMMÜLL GEMÄẞ ARTIKEL 70

1. Begrenzung der Fragmentierung von Raumfahrzeugen

1.1. Begrenzung der voraussichtlichen Entstehung von Weltraummüll

    Um die geplante Entstehung von Weltraummüll im Nominalbetrieb zu begrenzen, sind folgende Anforderungen zu erfüllen:

  - a) Ein Raumfahrzeug ist so zu konzipieren, dass die Entstehung von Weltraummüll gemäß den Anforderungen des Durchführungsrechtsakts gemäß Artikel 70 Absatz 3 Buchstabe a begrenzt wird.

  - b) Jeder geplante Weltraummüll, der sich voraussichtlich für den im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe a festgelegten Zeitraum in der Umlaufbahn befindet, ist im Plan zur Kontrolle von Weltraummüll zu begründen.

  - c) Raumfahrzeugbetreiber aus der Union ergreifen Maßnahmen für die Konzeption von pyrotechnischen Vorrichtungen und Feststoffraketentriebwerken im Einklang mit den Anforderungen, die im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe a festgelegt sind.

1.2. Vermeidung von Fragmentierung durch interne Ursachen, die mit dem Raumfahrzeug selbst zusammenhängen

1.2.1. Um das Risiko einer unbeabsichtigten Fragmentierung durch fahrzeugseitige Energiequellen zu begrenzen, sind folgende Anforderungen zu erfüllen:

  - a) Die Wahrscheinlichkeit einer unbeabsichtigten Fragmentierung eines Raumfahrzeugs in der Erdumlaufbahn ist nach den im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe b Ziffer i festgelegten Anforderungen bis zum Ende seiner Lebensdauer zu begrenzen.

      Die Berechnung des Risikos einer unbeabsichtigten Fragmentierung eines Raumfahrzeugs erfolgt nach einer standardisierten Methode, bei der alle bekannten Ausfallarten berücksichtigt werden.

  - b) Die fahrzeugseitigen Energiequellen des Raumfahrzeugs sind robust zu konzipieren. Dabei sind folgende Faktoren zu berücksichtigen:

    - i) die erwarteten nominalen extremen Umgebungsbedingungen;

    - ii) der nominale mechanische und chemische Ausfall;

    - iii) die potenziellen Auswirkungen von Systemausfallmodi der Raumfahrzeuge und

    - iv) Auswirkungen von fahrzeugseitigen Energiequellen auf die Fähigkeit des Raumfahrzeugs, sich zu passivieren.

  - c) Das Raumfahrzeug ist unter Berücksichtigung der Besonderheiten seiner Teilsysteme, wie z. B. der elektrischen Systeme und der Antriebssysteme, bzw. des Fragmentierungsrisikos der Druckhaltesysteme während der Verweildauer in der Umlaufbahn zu konzipieren.

  - d) Der Betrieb von Raumfahrzeugen in der Umlaufbahn umfasst Verfahren für die Überwachung der relevanten Parameter jedes Teilsystems, das als potenzielle Quelle für die Entstehung von Weltraummüll ermittelt wurde, um Fehlfunktionen zu erkennen.

  - e) Raumfahrzeuge werden nach folgenden Grundsätzen passiviert:

    - i) Bei den Maßnahmen zur Umsetzung der Anforderung in Bezug auf die Passivierung sind die Besonderheiten der jeweiligen Antriebsart zu berücksichtigen.

    - ii) Im Fall einer elektrischen Passivierung ist bei der Konzeption des Raumfahrzeugs sicherzustellen, dass Schaltpläne für die elektrische Passivierung erstellt und spezifiziert werden.

    - iii) Die Raumfahrzeugbetreiber aus der Union aktualisieren vor dem Ende der Lebensdauer des Raumfahrzeugs die Verfahren zur Passivierung, um zu prüfen, ob die Passivierungsfähigkeit des Raumfahrzeugs noch nominal ist.

    - iv) Mit Ausnahme von CubeSats ist bei der Konzeption von Raumfahrzeugen sicherzustellen, dass sie eine Redundanzfunktion für die Passivierung enthalten.

    - v) Die Raumfahrzeugbetreiber aus der Union sorgen auf eine der folgenden Arten für eine Erschöpfung der Energiereserven:

      - (1) durch „harte“ Passivierung, bei der ein Raumfahrzeugbetreiber aus der Union Steuerungen mit Parametern einrichtet, die so eingestellt sind, dass sie nicht zu einer Explosion oder Verpuffung führen können, die so stark ist, dass Weltraummüll entsteht oder das Raumfahrzeug auseinanderbricht;

      - (2) durch „weiche“ Passivierung gemäß den Bedingungen des Durchführungsrechtsakts im Sinne des Artikels 70 Absatz 3 Buchstabe b.

    - vi) Die Raumfahrzeugbetreiber aus der Union deaktivieren die Teile des Raumfahrzeugs, die Energie erzeugen.

    - vii) Nach der Passivierung dürfen keine funkelektrischen Aussendungen der Plattform und der Nutzlast mehr auftreten.

    - viii) Bei der Passivierung darf kein Weltraummüll entstehen, der größer ist als 1 mm, mit Ausnahme der Belüftung des Treibstoffsystems.

  - f) Bei der elektrischen Passivierung werden die Energiequellen isoliert und die Batterie wird entladen.

      Im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe d werden besondere Vorschriften für die Passivierung zum Wiedereintritt festgelegt.

1.3. Vermeidung der Fragmentierung durch Kollision

    Um die durch Kollision verursachte Fragmentierung zu begrenzen, sind folgende Anforderungen zu erfüllen:

  - a) Raumfahrzeuge sind so zu entwerfen und zu bauen und Weltraummissionen sind so zu planen, dass das Kollisionsrisiko nach den im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe b festgelegten Anforderungen begrenzt ist.

  - b) Raumfahrzeuge sind so zu entwerfen und zu bauen, dass das Risiko, dass Weltraummüll oder Meteoroide zur Fragmentierung des Raumfahrzeugs oder seiner Komponenten führen, begrenzt ist. Bei der Verwendung von Tethern sind zusätzliche Maßnahmen zu ergreifen, um das Risiko einer Kollision mit Weltraumobjekten und Meteoroiden nach den im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe b festgelegten Anforderungen zu mindern.

  - c) Die Wahrscheinlichkeit einer Kollision mit einem Weltraumobjekt und Meteoroiden wird vor dem Start für die gesamte Lebensdauer des Raumfahrzeugs berechnet, und die Risiken werden entsprechend dem im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe b festgelegten Schwellenwert begrenzt.

  - d) Die Berechnung der Kollisionswahrscheinlichkeit erfolgt nach der standardisierten Methode, die im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe b festgelegt ist.

2. Zuverlässigkeit des Entwurfs und Kontrolle

2.1. Bestimmungen über die Zuverlässigkeit des Entwurfs

2.1.1. Der Entwurf und die Herstellung eines Raumfahrzeugs und seiner Komponenten und Teilsysteme werden

  - a) durch Tests, Analysen, Demonstration oder Inspektion überprüft;

  - b) durch Abnahmetests, Demonstration oder Inspektion validiert und

  - c) geprüft, analysiert und demonstriert; diese Tests, Analysen und Demonstrationen können je nach Art der Ausrüstung und der Kritikalität der Funktionen variieren.

2.1.2. Es muss eine Kontrolle des Entwurfs, der Herstellung, der Integration und der Implementierung der Raumfahrzeugsysteme eingerichtet werden, um Gefahren, insbesondere solche, die sich aus kritischen Tätigkeiten ergeben, zu beherrschen.

2.2. Operative Verfahren für die Kontrolle der Qualität und Zuverlässigkeit

Die Raumfahrzeugbetreiber aus der Union führen ein Qualitätsmanagementsystem ein.

2.2.1. Die Raumfahrzeugbetreiber aus der Union führen ein Qualitätsmanagementsystem ein.

    Die Einführung eines Qualitätsmanagementsystems umfasst mindestens die Qualitätssicherung, RAMS (Zuverlässigkeit, Verfügbarkeit, Instandhaltungsfähigkeit, Sicherheit), einschließlich Zustandsüberwachung, Ausfallprognosen und Konfigurationsmanagement.

2.2.2. Die Überwachung und Kontrolle von Abweichungen bei der Herstellung und der Durchführung der Weltraummission umfasst Folgendes:

  - a) Einführung eines Systems zur Überwachung und Kontrolle von Abweichungen bei der Herstellung und der Umsetzung, das unter anderem Folgendes abdeckt:

    - i) Abweichungen in Bezug auf die Konfiguration (Definition, Startsystem, Verfahren der Herstellung und der Durchführung);

    - ii) Abweichung aufgrund der Nutzung von Borddaten;

    - iii) die operativen Sequenzen, die die Steuerung des Raumfahrzeugs betreffen, sind für die kritischen Phasen einer Weltraummission (einschließlich, aber nicht beschränkt auf Start- und Frühbetriebsphase, Außerbetriebnahme, kritische Operationen in der Umlaufbahn) vor dem Start zu testen;

    - iv) Druck und Temperatur in den Triebwerken, Tanks, Druckbehältern;

    - v) Parameter (Temperatur und Spannung) von Batterien zur Erkennung von Ausfällen;

    - vi) Parameter zur Erkennung von Fehlerzuständen im System zur Steuerung der Flugbahn und Fluglage.

  - b) Gewährleistung der Rückverfolgbarkeit technischer und organisationsbezogener Ereignisse, die sich auf die Verfahren der technischen Entwicklung und Herstellung auswirken.

2.2.3. Festlegung von Verfahren zur Bewertung kritischer Funktionen unter Verwendung von Borddaten.

  - a) Die Verfahren sehen eine Neubewertung mindestens zu folgenden Zeitpunkten vor:

    - i) auf Ersuchen der zuständigen Behörde während der nominalen Lebensdauer und für die verlängerte Dauer der Mission;

    - ii) bei Feststellung einer Anomalie, die die erfolgreiche Rückholung beeinträchtigen könnte;

    - iii) bei der Bewertung im Hinblick auf eine Verlängerung der Dauer von Weltraummissionen;

    - iv) bei Eintreten einer größeren Veränderung der Weltraumumgebung (z. B. einer katastrophalen Fragmentierung) mit erheblichen Auswirkungen auf die operative Umlaufbahn oder den Entsorgungsansatz.

  - b) Im Rahmen der unter Buchstabe a genannten Verfahren sind mindestens die folgenden Parameter neu zu bewerten:

    - i) die überwachte und aktualisierte Wahrscheinlichkeit einer erfolgreichen Entsorgung anhand von Flugdaten, um sicherzustellen, dass die Wahrscheinlichkeit einer erfolgreichen Entsorgung hoch ist;

    - ii) die voraussichtliche Wahrscheinlichkeit einer erfolgreichen Entsorgung gemäß Abschnitt III Teil A für die verbleibende Zeit in der Umlaufbahn;

    - iii) die voraussichtliche Anzahl von Kollisionsvermeidungsmanövern bis zum Ende der Lebensdauer mit aktualisierten Umgebungsmodellen (und dem entsprechenden Delta V);

    - iv) der Friedhofsorbit und das jeweilige Kollisionsrisiko vom vorgesehenen Rückholzeitpunkt bis zum Wiedereintritt (und Garantie, dass das entsprechende Delta V verfügbar ist).

3. Ende der Lebensdauer

3.1. Wahrscheinlichkeit einer erfolgreichen Entsorgung

3.1.1. Die Raumfahrzeugbetreiber aus der Union berechnen die festgelegten Grenzwerte für die Wahrscheinlichkeit einer erfolgreichen Entsorgung und halten sie ein.

3.1.2. Die Wahrscheinlichkeit einer erfolgreichen Entsorgung muss hoch sein; sie wird nach den im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c festgelegten Anforderungen berechnet.

3.1.3. In der Entwurfsphase nehmen die Raumfahrzeugbetreiber aus der Union die Berechnung der Wahrscheinlichkeit einer erfolgreichen Entsorgung nach einer anerkannten Methode vor, die dem neuesten Stand entspricht und im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c festgelegt ist. Dazu gehören:

  - a) eine Bewertung der Wahrscheinlichkeit, dass Weltraummüll oder ein Meteoroid die erfolgreiche Entsorgung des Raumfahrzeugs verhindert;

  - b) eine Bewertung der Unsicherheiten in Bezug auf die Verfügbarkeit der für die Entsorgung erforderlichen Ressourcen, wie z. B. Treibstoff;

  - c) die inhärente Zuverlässigkeit der für die Entsorgung erforderlichen Ausrüstungen und eine Überwachung der Ausrüstungen, einschließlich der Teilsysteme, Einheiten und Funktionen, die ausschließlich für die Entsorgung verwendet werden;

  - d) Wahrscheinlichkeit von Kollisionen an Anbauten, außer es wird nachgewiesen, dass sie die Entsorgungsfunktionen nicht beeinträchtigen;

  - e) Maßnahmen der Passivierung, auch nach Verlust der Kontrolle oder des Kontakts.

3.1.4. Die Wahrscheinlichkeit einer erfolgreichen Entsorgung wird nach dem Start unter Berücksichtigung etwaiger Änderungen des Betriebszustands des Raumfahrzeugs neu bewertet.

3.1.5. Bei Verwendung von Treibstoffen

  - a) Die vor dem Start berechnete Wahrscheinlichkeit, dass zu jedem Zeitpunkt der Weltraummission bis zur Einleitung der erfolgreichen Manöver für die Außerbetriebnahme der für die Manöver am Ende der Lebensdauer benötigte Treibstoff zur Verfügung steht, muss maximal hoch sein.

  - b) Vor der Entsorgung prüft der Raumfahrzeugbetreiber aus der Union, ob das Luftfahrzeug über den für die Entsorgung erforderlichen Treibstoff verfügt.

3.2. Konzeption des Raumfahrzeugs im Hinblick auf die Entsorgung am Ende der Lebensdauer

3.2.1. Raumfahrzeuge müssen so konzipiert sein, dass sie am Ende der Lebensdauer nach den in Nummer 3.3, Nummer 3.6 bzw. Nummer 3.7 genannten Methoden entsorgt werden können.

3.2.2. Die Entsorgungskapazitäten sind in der Entwurfsphase zu planen und zu prüfen. Bei LEO-Weltraummissionen umfasst dies auch die Konzeption im Hinblick auf die Art des geplanten Wiedereintritts.

3.2.3. Die Entsorgungskapazitäten müssen zu jedem Zeitpunkt der Weltraummission verfügbar sein.

3.2.4. Der Schutz der Entsorgungssysteme vor Weltraummüll und Meteoroiden ist nachzuweisen.

3.2.5. Die Raumfahrzeugbetreiber aus der Union müssen in der Lage sein, Kommunikationsverbindungen und die aktive Verfolgung während der Entsorgungsphase aufrechtzuerhalten.

3.3. Entfernung von Raumfahrzeugen aus der LEO

    Die Entfernung von Raumfahrzeugen aus der LEO erfolgt auf eine oder mehrere der folgenden Arten, die in der folgenden Rangfolge auf Grundlage ihrer technischen Durchführbarkeit ausgewählt werden:

  - a) Durchführung eines kontrollierten Wiedereintritts mit einem klar definierten Zielgebiet auf der Erde, um das Unfallrisiko zu begrenzen;

  - b) Durchführung eines halbkontrollierten Wiedereintritts nach Missionsende, wenn der Entwurf dem Unfallrisiko Rechnung trägt;

  - c) Durchführung eines sofortigen unkontrollierten Wiedereintritts nach Missionsende, wenn der Entwurf dem Unfallrisiko Rechnung trägt;

  - d) natürlicher Bahnabstieg innerhalb der Grenze der kumulativen Wahrscheinlichkeit einer unbeabsichtigten Kollision, der maximalen Verweildauer in der Umlaufbahn und der Grenze für das Unfallrisiko;

  - e) in begründeten Ausnahmefällen kann die Entsorgung bei einer sehr hohen LEO-Orbithöhe in eine Umlaufbahn erfolgen, die geschützte Gebiete und wertvolle Umlaufbahnen nicht beeinträchtigt;

  - f) Entfernung durch ISOS.

3.4. Maximale Verweildauer in der Umlaufbahn vor dem Wiedereintritt im Fall der LEO

3.4.1. Der Raumfahrzeugbetreiber aus der Union teilt für Rahmfahrzeuge in der LEO die erwartete Verweildauer in der Umlaufbahn nach folgenden Ereignissen mit:

  - a) Ende der Weltraummission;

  - b) Abschluss des Verfahrens der Passivierung.

3.4.2. Im Fall der LEO ist die Verweildauer in der Umlaufbahn nach Missionsende und vor dem Wiedereintritt in die Atmosphäre gemäß den im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c festgelegten Anforderungen zu begrenzen.

3.5. Regelungen für den Wiedereintritt im Fall der LEO

3.5.1. Bei Raumfahrzeugen, die gemäß den in Teil 3.4 festgelegten Regelungen entsorgt werden, berücksichtigen die Raumfahrzeugbetreiber aus der Union das „Design for Demise“ als einen der Schritte zur Minimierung des Unfallrisikos.

3.5.2. Die Raumfahrzeugbetreiber aus der Union weisen nach, dass drei Tage nach den Manövern zur Entfernung aus der Umlaufbahn und der Rückkehr zur Erde keine Gefahr einer Kollision mit bemannten Stationen in der Umlaufbahn besteht.

3.5.3. Die Raumfahrzeugbetreiber aus der Union führen eine Bewertung durch, um festzustellen, ob Teile des Raumfahrzeugs den Wiedereintritt in die Atmosphäre und das Auftreffen auf die Erdoberfläche überstehen werden, und legen die Maßnahmen fest, die zur Minderung des Unfallrisikos gemäß Nummer 3.5.4 zu ergreifen sind.

3.5.4. Die Wahrscheinlichkeit von Schäden bei Wiedereintritt wird im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c Ziffer iii unter Berücksichtigung der folgenden Anforderungen näher bestimmt und muss

  - a) so niedrig wie möglich sein;

  - b) als maximale Wahrscheinlichkeit, dass mindestens eine Person verletzt oder getötet wird (kollektives Risiko), ausgedrückt werden;

  - c) Unfälle am Boden sowie im Luft- und Seeverkehr einschließen.

  - d) Im Fall eines vorzeitigen oder unbeabsichtigten Wiedereintritts ergreifen die Raumfahrzeugbetreiber aus der Union vorrangig alle Maßnahmen zur Minderung des Risikos am Boden.

3.5.5. Beim Wiedereintritt wird das Risiko für die Umwelt durch Stoffe analysiert, die den Wiedereintritt möglicherweise überstehen.

3.5.6. Enthält das Raumfahrzeug radioaktive Stoffe, so sind die im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c Ziffer iii festgelegten Bedingungen einzuhalten.

3.5.7. Raumfahrzeuge, die nicht wie geplant einen kontrollierten Wiedereintritt durchführen können, sind zu passivieren, sofern diese Passivierung sicher, zeitnah und kontrolliert erfolgen kann.

3.5.8. Für ein Raumfahrzeug, das einen geplanten Wiedereintritt übersteht und das eine Größe aufweist, wie im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c Ziffer iii festgelegt, müssen sich die Raumfahrzeugbetreiber aus der Union bei einem Wiedereintrittsdienst registrieren, der in der Lage ist,

  - a) den Wiedereintritt zu verfolgen;

  - b) Vorhersagen über den möglichen Landeort zu treffen.

3.5.9. Der Wiedereintrittsdienst im Sinne der Nummer 3.5.8 unterrichtet die zuständigen Luft- und Seeverkehrsbehörden über jeden erwarteten Wiedereintritt.

3.6. Entfernung von Raumfahrzeugen aus der MEO

    Entfernung aus Erdumlaufbahnen außerhalb der geschützten orbitalen Gebiete und Beförderung in eine Umlaufbahn, die für die im Durchführungsrechtsakt gemäß Artikel 70 Absatz 3 Buchstabe c festgelegte Anzahl von Jahren die geschützten Gebiete und wertvollen Umlaufbahnen nicht beeinträchtigt.

3.7. Entfernung von Raumfahrzeugen aus der GEO

    Entfernung aus Erdumlaufbahnen außerhalb der geschützten orbitalen Gebiete und Beförderung in eine Umlaufbahn, die die geschützten Gebiete und wertvollen Umlaufbahnen für einen Zeitraum von 100 Jahren nach Ende der Lebensdauer nicht beeinträchtigt.

3.8. Ausfallreaktion

3.8.1. Der Raumfahrzeugbetreiber aus der Union erstellt einen Ausfallreaktionsplan gemäß Nummer 4.3.

3.8.2. Der Raumfahrzeugbetreiber aus der Union löst die Ausfallreaktion aus, wenn ein für den Entsorgungsprozess kritisches System versagt.

4. Pläne zur Eindämmung von Weltraummüll

4.1. Plan zur Kontrolle von Weltraummüll

4.1.1. Es ist ein Fragmentierungsverhinderungsplan auszuarbeiten, in dem jedes Element berücksichtigt wird, das gespeicherte Energie enthält. Bei der Ausarbeitung solcher Pläne berücksichtigen die Raumfahrzeugbetreiber aus der Union alle Systeme, die am wahrscheinlichsten zu einer unbeabsichtigten Fragmentierung eines Raumfahrzeugs führen, insbesondere:

  - a) elektrische Systeme, insbesondere Batterien;

  - b) Antriebssysteme und zugehörige Komponenten;

  - c) Druckhaltesysteme;

  - d) rotierende Mechanismen.

4.1.2. Bei der Ausarbeitung des Fragmentierungsverhinderungsplans ist ein Ansatz zur Risikobewertung auf Systemebene anzuwenden.

4.1.3. Der Plan zur Kontrolle von Weltraummüll enthält mindestens Folgendes:

  - a) eine Beschreibung der Einhaltung der Beschränkungen für die geplante Erzeugung von Weltraummüll gemäß Nummer 1.1;

  - b) eine Beschreibung der Einhaltung der Anforderung in Bezug auf die Wahrscheinlichkeit einer unbeabsichtigten Fragmentierung gemäß Nummer 1.2;

  - c) eine Beschreibung der Einhaltung der Begrenzung des Risikos einer Fragmentierung durch Kollision gemäß Nummer 1.3;

  - d) eine Beschreibung der Einhaltung der Zuverlässigkeit des Entwurfs des Raumfahrzeugs gemäß Nummer 2.1;

  - e) eine Beschreibung der operativen Verfahren für die Kontrolle der Qualität und Zuverlässigkeit gemäß den Nummern 2.2.1 und 2.2.2.

4.2. Plan zur Entsorgung am Ende der Lebensdauer

    Der Plan für die Entsorgung am Ende der Lebensdauer enthält mindestens Folgendes:

  - a) eine Beschreibung der Einhaltung des Schwellenwerts für die erfolgreiche Entsorgung gemäß Nummer 3.1.2;

  - b) im Fall von Raumfahrzeugbetreibern aus der Union in der LEO eine Beschreibung der gewählten Entsorgungsmethode gemäß den in den Nummern 3.3, 3.4 und 3.5 genannten Optionen;

  - c) im Fall von Raumfahrzeugbetreibern aus der Union in der MEO eine Beschreibung der Einhaltung der in Nummer 3.6 festgelegten Anforderungen;

  - d) im Fall von Raumfahrzeugbetreibern aus der Union in der GEO eine Beschreibung der Einhaltung der in Nummer 3.7 festgelegten Anforderungen.

4.3. Ausfallreaktionsplan

    Der Raumfahrzeugbetreiber aus der Union arbeitet einen Ausfallreaktionsplan aus, der mindestens die folgenden Elemente umfasst:

  - a) die Kriterien für die Auswahl der Methode aus den alternativen Entsorgungsmethoden, mit der das geringste Risiko für ein in der operativen Umlaufbahn verbliebenes Raumfahrzeug verbunden ist;

  - b) die Kriterien für die Einleitung von Notfallmaßnahmen zur Passivierung;

  - c) im Fall von Raumfahrzeugbetreibern aus der Union in der MEO und GEO Schritte, um Raumfahrzeuge in eine alternative Umlaufbahn zu bringen und zu passivieren, bevor weitere kritische Systeme verloren gehen;

  - d) Schritte, um den sicheren Wiedereintritt des Raumfahrzeugs aus der LEO zu gewährleisten und es zu passivieren, bevor weitere kritische Systeme verloren gehen;

  - e) die Komponente bestehender oder künftiger Raumfahrzeuge, die Komponenten gemeinsam haben, die zu einem ähnlichen Ausfall des kritischen Systems führen könnten (Erfahrungswerte);

  - f) einen Entfernungsplan, in dem die Möglichkeit einer Entfernung durch einen ISOS-Anbieter bewertet wird, einschließlich

    - i) eines speziellen operativen Modus für die Erbringung des Dienstes (Entfernung) und Nutzung der integrierten Entfernungsschnittstelle (falls zutreffend), um das Risiko in Verbindung mit einem vom Versorgungsraumfahrzeug erbrachten In-Space-Dienst zu mindern;

    - ii) der technischen Mittel und der spezifischen Missionsart.

    - iii) Ist der Entfernungsplan nicht erfolgreich oder schließt er die Inanspruchnahme von ISOS-Anbietern zur Risikominderung aus und bleibt das Raumfahrzeug manövrierunfähig in einer geschützten Umlaufbahn zurück, müssen die Raumfahrzeugbetreiber die in Artikel 101 Absatz 3 genannten speziellen Schnittstellen für Raumfahrzeugdienste (Spacecraft Service Interfaces, SSI) als Teil der Genehmigungsanforderungen in künftige Raumfahrzeuge einbauen.

<a id="annex-vi"></a>
## Anhang VI

KONSTELLATIONEN GEMÄẞ ARTIKEL 73

1. Anforderungen in Bezug auf Risiken innerhalb der Konstellation

1.1. Für Konstellationen, Megakonstellationen und Gigakonstellationen enthalten die in Artikel 70 Absatz 2 Buchstabe a genannten Pläne zur Kontrolle von Weltraummüll im Hinblick auf das Kollisionsrisiko während der Verweildauer in der Umlaufbahn einen Bericht über Kollisionsrisiken innerhalb der Konstellation, in dem die zur Minderung dieses Risikos getroffenen Maßnahmen aufgeführt sind.

1.2. Für Megakonstellationen und Gigakonstellationen gilt Folgendes:

  - a) Raumfahrzeuge müssen so konzipiert sein und betrieben werden, dass die Durchführung automatisierter Prozesse im Rahmen der Kollisionsvermeidungsstrategie möglich ist.

  - b) Die Raumfahrzeugbetreiber aus der Union ziehen Umlaufbahnen in Betracht, die das Kollisionsrisiko innerhalb der Konstellation minimieren, auch bei Ausfall in der Umlaufbahn, in der Start- und Frühbetriebsphase (Launch and Early Operations, LEOP) und in der Entsorgungsphase.

  - c) In der Entsorgungsphase und nach dem Ende der Lebensdauer analysieren die Raumfahrzeugbetreiber aus der Union das Risiko von Kollisionen innerhalb der Konstellation und halten es auf dem niedrigstmöglichen Niveau, wie im Durchführungsrechtsakt gemäß Artikel 73 Absatz 4 Buchstabe a festgelegt.

2. Zusätzliche Berichtspflichten

2.1. Für Konstellationen, Megakonstellationen und Gigakonstellationen ergreifen die Raumfahrzeugbetreiber aus der Union spezifische Maßnahmen zur Begrenzung der Licht- und Funkverschmutzung, die im Durchführungsrechtsakt gemäß Artikel 73 Absatz 4 Buchstabe b Unterabsatz 1 festgelegt werden.

2.2. Für Megakonstellationen und Gigakonstellationen gilt Folgendes:

  - a) Der in Artikel 70 Absatz 2 Buchstabe a genannte Plan zur Kontrolle von Weltraummüll enthält eine Analyse, aus der hervorgeht, dass besonders darauf geachtet wurde, dass in jeder Phase der Weltraummission Kollisionen mit den internationalen Weltraumstationen vermieden werden.

  - b) In einem Bericht wird nach einem Jahr des Betriebs die Wahrscheinlichkeit von Kollisionen innerhalb der Konstellation und zwischen Konstellationen analysiert und der zum Zeitpunkt der Erteilung der Genehmigung berechneten Wahrscheinlichkeit gegenübergestellt.

  - c) Die Raumfahrzeugbetreiber aus der Union weisen nach einem Jahr des Betriebs die Wirksamkeit der Maßnahmen nach, die sie zur Bekämpfung der Licht- und Funkverschmutzung ergriffen und in ihrem Genehmigungsantrag erläutert haben. Sind diese Maßnahmen nicht wirksam, leiten die Raumfahrzeugbetreiber aus der Union die Entwicklung technischer Lösungen durch Forschung ein, um die gemessene Verschmutzung für die nächste Generation von Raumfahrzeugen in der betreffenden Konstellation zu verringern.

  - d) Die Raumfahrzeugbetreiber aus der Union sind verpflichtet, für den Transit von der Einschussbahn zur endgültigen Umlaufbahn

    - i) einen Transitplan zu erstellen und nachzuweisen, dass die Wahrscheinlichkeit einer Kollision begrenzt ist;

    - ii) einen Bericht über das Funktionieren entscheidender Systeme vorzulegen, bevor die operative Umlaufbahn erreicht wird.

<a id="annex-vii"></a>
## Anhang VII

RESILIENZ ANHANG VII

1. RISIKOBEWERTUNG

1.1. In ihren Risikobewertungen berücksichtigen die Unionsbetreiber im Bereich Weltraum die in Artikel 76 Absatz 4 Unterabsatz 1 genannten wichtigsten Lebenszyklusphasen.

1.2. Unionsbetreiber im Bereich Weltraum, die ein vereinfachtes Risikomanagement anwenden, berücksichtigen die in Artikel 76 Absatz 4 Unterabsatz 1 genannten wichtigsten Lebenszyklusphasen nur in Bezug auf kritische Ressourcen und kritische Funktionen im Sinne des Artikels 79 Absatz 1 Unterabsatz 1.

1.3. In einer Risikobewertung ist nachzuweisen und zu dokumentieren, dass die Unionsbetreiber im Bereich Weltraum für die jeweiligen Segmente, Systeme oder Teilsysteme ausreichende und angemessene Maßnahmen getroffen haben, um dem ermittelten Risiko entgegenzuwirken.

1.4. Mindestens vor dem Start ist eine Risikobewertung durchzuführen. Die Risikobewertung enthält mindestens Folgendes:

  - a) Angaben zur Risikoquelle, seien es böswillige Handlungen wie Angriffe oder Unfälle und Naturkatastrophen;

  - b) eine Beschreibung des Risikokontexts, für den das betreffende Segment, System oder gegebenenfalls Teilsystem anfällig sein kann, z. B. auch im Zusammenhang mit rekonfigurierbaren Satelliten;

  - c) einen Überblick über das Risikobewertungsverfahren;

  - d) eine Beschreibung der elektronischen Kommunikationsnetze;

  - e) Angaben zu den Sicherheitszielen, einschließlich der Kriterienschlüssel und der Risikobereitschaft, die auf die betreffende Weltraummission abgestimmt werden;

  - f) die Risikoszenarien, die zumindest die zu diesem Zeitpunkt bekannten Angriffsvektoren abdecken;

  - g) die anwendbare Maßnahme für jedes ermittelte Risiko und Szenario, einschließlich umfassender unternehmensweiter Informationssicherheitskonzepte und systemspezifischer Sicherheitsanforderungen.

    Die Unionsbetreiber im Bereich Weltraum richten nach der Durchführung der unter Buchstabe g genannten Maßnahmen Risikobewertungsregister ein.

1.5. Die Risikobewertungen werden jährlich und bei Bedarf unter Berücksichtigung der Entwicklung der Bedrohungslage überprüft.

    Die Unionsbetreiber im Bereich Weltraum überprüfen die Risikobewertungen

  - a) nach jeder gemäß Artikel 88 durchgeführten Testreihe;

  - b) nach jeder wesentlichen Änderung an Netz- und Informationssystemen;

  - c) nach jedem erheblichen Sicherheitsvorfall;

  - d) gemäß den aufsichtlichen Anweisungen.

2. KARTIERUNG VON RESSOURCEN

2.1. Ermittlung, Auflistung und Kategorisierung von Ressourcen, einschließlich Systemen und Teilsystemen, sowie von Funktionen, Operationen und Technologien mit folgenden Merkmalen:

  - a) Ressourcen, die für die Durchführung von Weltraumtätigkeiten als kritisch erachtet werden, unter Berücksichtigung aller relevanten Kriterien wie z. B. der maßgeblichen Rolle bei der Durchführung der jeweiligen Weltraummission, bei der Aufrechterhaltung einer wirksamen Kontrolle des Weltraumsegments oder bei der Gewährleistung der Funktionalität und Integrität der Nutzlast;

  - b) Ressourcen, die im Rahmen der Risikobewertung als Single Point of Failure (einzelner Ausfallpunkt) oder Common Mode Failure (Ausfall gleichartiger Komponenten) erkannt wurden;

  - c) Ressourcen, die sensible Daten erzeugen, verwenden oder speichern;

  - d) Ressourcen, für die hoch spezialisierte Fähigkeiten oder Kenntnisse erforderlich sind.

2.2. Festlegung von Verfahren für den Umgang mit den unter Nummer 2.1 genannten Ressourcen der Weltrauminfrastruktur, auch in Übergangsphasen wie dem Transport oder während der Test- und Validierungsphasen.

3. PHYSISCHE RESILIENZ

3.1. Die Unionsbetreiber im Bereich Weltraum treffen alle erforderlichen Maßnahmen, um die Resilienz der Bodenstationen zu gewährleisten. Dies schließt mindestens Folgendes ein:

  - a) angemessene Sicherung der Startplätze und -gelände;

  - b) Instandhaltung aller physischen Ressourcen, insbesondere der Ausrüstungen, um ihre Integrität und Verfügbarkeit zu gewährleisten, und insbesondere in Bezug auf die Raumfahrzeuge während der Herstellungs-, Test-, Transport-, Inbetriebnahme- und Startphase sowie während der Befehlsführung, Steuerung und Telemetrie; dies gilt auch für die Erzeugungs- und Übertragungssysteme in allen Phasen;

  - c) Platzierung der für Befehlsführung, Steuerung und Telemetrie sowie von den Erzeugungs- und Übertragungssystemen genutzten Ressourcen in einer Weise, dass der Zugang beschränkt ist und das Risiko von vorsätzlichen oder nicht vorsätzlichen Störungen verringert wird;

  - d) Gewährleistung der Härtung und Abschirmung gegen natürliche Strahlung auf nominaler Ebene und Bestimmung der Strahlungsgefährdung im Weltraumsegment gemäß den aufsichtlichen Anweisungen;

  - e) Sicherung von Ressourcen in allen Übergangsphasen, insbesondere beim Transport, bei Tests sowie an den Startplätzen, um insbesondere unbefugten Zugang, Manipulationen und Beschädigungen zu verhindern;

  - f) Unterbringung kritischer Backup-Ressourcen in unterschiedlichen geografischen Gebieten und Führung von Inventaren der betreffenden Ausrüstungen, damit diese bei einem Sicherheitsvorfall ohne Weiteres verfügbar sind.

4. ERKENNUNGSMECHANISMEN

4.1. Die von den Unionsbetreibern im Bereich Weltraum eingerichteten Erkennungsmechanismen müssen

  - a) die rasche Erkennung anomaler Tätigkeiten und die Ermittlung von Sicherheitsvorfällen wie Cyberangriffen und elektronischen Störungen ermöglichen;

  - b) Alarmschwellen und -kriterien für die Auslösung von Reaktionsprozessen bei Sicherheitsvorfällen vorsehen;

  - c) den Zustand des Raumfahrzeugs überwachen;

  - d) auf Grundlage der Risikobewertungen, und soweit von den zuständigen Behörden für zweckmäßig erachtet, die Funkfrequenzumgebung im Hinblick auf die nominalen Datenströme für die Dienste und für die Standorte, die für die Befehlsführung, Steuerung und Telemetrie, die Erzeugungs- und Übertragungssysteme sowie die Unterstützung der Erkennung von Sicherheitsvorfällen und die Lokalisierung der Störquellen entscheidend sind, überwachen.

5. SCHUTZ- UND PRÄVENTIVMAẞNAHMEN

5.1. Die Netz- und Informationssysteme müssen

  - a) geeignet sein, um die Vertraulichkeit, Integrität und Verfügbarkeit der Daten zu gewährleisten;

  - b) technologisch resilient sein, was für das Weltraumsegment die Resilienz z. B. gegen Manipulation, Störung (Jamming), Blendangriffe und Spoofing von Sensoren einschließt;

  - c) kryptografische Verfahren nach den in Artikel 85 festgelegten Grundsätzen verwenden;

  - d) über eine geeignete IKT-Architektur verfügen, die die ordnungsgemäße Zuweisung von Raumfahrzeugressourcen und die Integrität der Dienste gewährleistet;

  - e) über ein System für die Sicherheitswartung zur regelmäßigen Installation der neuesten Patches verfügen, einschließlich eines Verfahrens für ein schnelles Patching von Schwachstellen, die nach den Risikobewertungen als kritisch eingestuft werden.

5.2. Die Identitätsangabe eines Geräts, das versucht, mit dem Satelliten zu kommunizieren, um seinen inneren Zustand zu ändern, muss zwecks Authentifizierung überprüft werden.

5.3. Die Konfiguration der Flugsysteme und der zugehörigen Systeme im Bodensegment erfolgt nach vorab festgelegten Grundsätzen und wird in einer Weise überprüft, dass die Installation oder Aktualisierung von Software oder Firmware nicht ohne eine ausdrücklich festgelegte Berechtigung zur Installation solcher Software ausgeführt werden kann.

5.4. Minimale Schutz‑ und Präventivmaßnahmen:

  - a) Verwendung von Lösungen zur Multi-Faktor-Authentifizierung oder kontinuierlichen Authentifizierung, gesicherter Sprach-, Video- und Textkommunikation sowie gegebenenfalls gesicherter Notfallkommunikationssysteme.

  - b) Gewährleistung, dass alle Systeme, die kritische Befehle direkt an das Weltraumsegment senden, je nach Bedarf physisch oder logisch von anderen Netzen getrennt sind.

6. RISIKOMANAGEMENTRAHMEN FÜR DIE LIEFERKETTEN

6.1. Ergreifung aller geeigneten Maßnahmen, um die Sicherheit im Zusammenhang mit der Anschaffung, der Entwicklung und der Wartung der Netz- und Informationssysteme zu gewährleisten, einschließlich Management und Offenlegung von Schwachstellen.

6.2. Festlegung von Kriterien für die Auswahl von Software- und Hardwareprodukten in der Lieferkette unter gebührender Berücksichtigung des Risikos der Veralterung.

6.3. Einführung von Kontrollen der Softwareintegrität für das Boden- und das Weltraumsegment, u. a. durch die Einführung von Kontrollen der Softwareintegrität und Echtheit zum Nachweis der Herkunft.

6.4. Kontrolle der vorübergehend miteinander verbundenen Netz- und Informationssysteme, z. B. für Wartungs- oder Supportzwecke.

7. SCHULUNGEN

7.1. Allgemeine Schulungen

  - a) Programme zur Sensibilisierung für IKT-Sicherheit.

  - b) Pflichtmodule mit Übungen zu grundlegenden Praktiken der Cyberhygiene.

  - c) Spezifische Cybersicherheitsschulungen mit einem Komplexitätsgrad, der den Arbeitsbereichen und Aufgaben des Personals angemessen ist.

  - d) Allgemeine Schulungen zur Sicherheit in den Arbeitsbereichen des Personals.

7.2. Maßgeschneiderte Schulungen

    Die Unionsbetreiber im Bereich Weltraum gewährleisten, dass maßgeschneiderte Schulungen zumindest für Personal angeboten werden, das

  - a) Ausrüstungen, die die Schnittstelle zum Weltraumsegment bilden, betreibt, überwacht und instand hält;

  - b) für die Umsetzung der Betriebskontinuitätsstrategie sowie des Reaktions- und Wiederherstellungsplans im Sinne des Artikel 87 zuständig ist;

  - c) sich mit Fällen befasst, die eine weitere Interaktion mit Dritten erfordern.

8. BEWÄLTIGUNG VON SICHERHEITSVORFÄLLEN

8.1. Protokollierung von Sicherheitsvorfällen.

8.2. Einstufung von Sicherheitsvorfällen nach der Schwere ihrer Auswirkungen.

8.3. Einführung von Reaktionsmaßnahmen, die notwendig und geeignet sind, die Auswirkungen von Sicherheitsvorfällen abzumildern, indem sichergestellt wird, dass die Dienste schnell wieder einsatzbereit und sicher sind.

8.4. Nichtveränderung und Erhaltung von Ressourcen.

8.5. Weiterverfolgung der ergriffenen Maßnahmen.

9. ANFORDERUNGEN IN BEZUG AUF KRITISCHE RESSOURCEN UND RISIKEN IM RAHMEN DES VEREINFACHTEN RISIKOMANAGEMENTS

9.1. Anforderungen gemäß Artikel 76.

9.2. Risikobewertung gemäß Artikel 78 Absatz 2.

9.3. Elemente der Risikobewertungen gemäß Nummer 1.4.

9.4. Entwicklung der Risikoszenarien gemäß Nummer 1.4 Buchstabe f.

9.5. Erstellung und Führung von Inventaren gemäß Artikel 80 Absatz 4 Unterabsatz 1.

9.6. Präventiv- und Schutzmaßnahmen gemäß Artikel 84 Absatz 3.

9.7. Grundsätze für Kryptografie und Verschlüsselung gemäß Artikel 85 Absatz 1 Unterabsatz 1.

9.8. Maßnahmen für das Backup-Management gemäß Artikel 86 Absätze 1 und 3.

9.9. Bewältigung von Sicherheitsvorfällen gemäß Artikel 91.

Anhang VIII

OPERATIONEN UND DIENSTE IM WELTRAUM (ISOS) GEMÄẞ ARTIKEL 101

1. Allgemeine Bestimmungen

1.1. Allgemeine Grundsätze für die Durchführung von ISOS

  - a) Für die Zwecke dieses Anhangs ist ein Kundenobjekt ein Kunden-Weltraumobjekt, das Raumfahrzeuge und Weltraummüll einschließt.

  - b) Der ISOS-Anbieter der Union und der Unionsbetreiber im Bereich Weltraum des Kundenobjekts schließen einen ISOS-spezifischen Vertrag.

  - c) ISOS werden erst durchgeführt, nachdem der ISOS-Anbieter der Union und der Unionsbetreiber im Bereich Weltraum eines Kundenobjekts ausdrücklich und unmissverständlich zugestimmt haben, mit der Durchführung der vereinbarten Operation bzw. Operationen zu beginnen.

  - d) Der in Buchstabe b genannte ISOS-Vertrag muss einen speziellen Dienstleistungsplan enthalten, in dem das Missionskonzept für die betreffenden ISOS und die Infrastruktur sowohl des Kundenobjekts als auch des Versorgungsraumfahrzeugs ausführlich beschrieben sind.

  - e) Das Versorgungsraumfahrzeug und das Kundenobjekt sind so zu entwerfen und zu bauen und die entsprechende Mission ist so zu planen, dass das Kollisionsrisiko begrenzt wird.

  - f) Während der ISOS-Operation muss die physische Trennung zwischen dem Versorgungsraumfahrzeug und dem Kundenobjekt so erfolgen, dass für beide Raumfahrzeuge eine beständige Umlaufbahn gewährleistet ist.

1.2. Koordinierung der Kontrollzentren

a) Die jeweiligen Kontrollzentren des Versorgungsraumfahrzeugs und des Kundenobjekts gewährleisten eine angemessene Koordinierung, indem sie alle Daten, einschließlich Telemetrie, austauschen, die für die Gewährleistung der Sicherheit der betreffenden Operation erforderlich sind.

b) Außer in Fällen, in denen es sich bei dem Kundenobjekt um Weltraummüll handelt, benennen der ISOS-Anbieter der Union und der Unionsbetreiber im Bereich Weltraum eines Kundenobjekts für jede Phase der Durchführung von ISOS das Kontrollzentrum, das Entscheidungsbefugnis für gemeinsame Operationen in dem definierten Gebiet, auch während der Andockphase, besitzt, sowie das Kontrollzentrum, das das zusammengesetzte Objekt nach dem Andocken steuert.

2. Leistungserbringung

2.1. Kompatibilität des Versorgungsraumfahrzeugs und des Dienstes mit der Konfiguration von Kunden-Weltraumobjekten

    Der Entwurf des Versorgungsraumfahrzeugs und das Konzept des operativen Dienstes müssen mit dem Entwurf und dem Betrieb des Kundenobjekts bzw., wenn es sich um Weltraummüll handelt, mit dem Zustand des Müllobjekts kompatibel sein.

2.2. Sorgfaltspflichten in Bezug auf die potenziellen Auswirkungen auf Dritte

2.2.1. Die ISOS-Anbieter der Union ergreifen alle geeigneten Maßnahmen, um Folgendes zu verhindern:

a) Beeinträchtigung eines anderen Objekts als des Kundenobjekts, wodurch Schäden entstehen;

b) Störung, einschließlich Unterbrechung, des Betriebs eines Raumfahrzeugs eines Dritten;

    Sie ergreifen geeignete Maßnahmen, um potenzielle negative Auswirkungen bei der Durchführung von ISOS angemessen zu mindern, falls sie nicht oder nicht unmittelbar verhindert werden können.

2.2.2. Der ISOS-Anbieter der Union legt im Betriebskonzept eine sichere Zone fest, in der die Anwesenheit eines Dritten dazu führt, dass die laufende ISOS-Operation nicht durchgeführt oder eingestellt wird.

2.2.3. Treten Anomalien auf oder führen unvorhergesehene Ereignisse, auch solche, die durch die Durchführung von ISOS verursacht werden, zu potenziellen negativen Auswirkungen auf Weltraumobjekte Dritter, so unterrichtet der ISOS-Anbieter der Union unverzüglich den Betreiber im Bereich Weltraum des betroffenen Weltraumobjekts Dritter.

2.2.4. Der ISOS-Anbieter der Union stimmt sich eng mit dem in Artikel 63 genannten Anbieter von Kollisionsvermeidungsdiensten ab, auch in der Phase der Durchführung der Operation.

2.3. Sicherheit der Operationen

a) Für die Zwecke der Anflugphase und im Hinblick auf die Einleitung der Abkopplung legt der ISOS-Anbieter der Union im Betriebskonzept Bereitschafts- oder Transitpunkte fest.

b) Während der Durchführung der Operation führen die ISOS-Anbieter der Union zu jedem geeigneten Zeitpunkt / in jeder geeigneten Sequenz eine GO/NO-GO-Prüfung durch und setzen die Operation nur dann fort, wenn die GO-Bedingung erfüllt ist. Sind die GO-Bedingungen nicht erfüllt, muss entweder autonom oder durch das Bodensegment ein Abbruchbefehl ausgelöst werden.

c) Während der Anflugphase und nach der Abkopplung müssen die fahrzeugseitigen Systeme des Versorgungsraumfahrzeugs in der Lage sein, das Kollisionsrisiko zwischen dem Versorgungsraumfahrzeug und dem Kundenobjekt in Echtzeit zu bewerten und eigenständig ein Kollisionsvermeidungsmanöver einzuleiten, um das Versorgungsraumfahrzeug auf einen Nichtkollisionskurs zu bringen.

2.4. Qualifikation des Systems und Dienstleistungskonzepts – Vorherige Prüfung

    Mit Ausnahme von nichtreversiblen ISOS-Operationen führen die ISOS-Anbieter der Union zur Feststellung des ordnungsgemäßen Funktionierens des Systems für die geplanten ISOS Tests in der Umlaufbahn zumindest vor der Durchführung der ersten Operation oder im ersten Schritt durch, und nur dann, wenn keine Gefahr für andere Weltraumobjekte besteht.

<a id="annex-ix"></a>
## Anhang IX

QUALIFIZIERTE TECHNISCHE STELLEN FÜR WELTRAUMTÄTIGKEITEN GEMÄẞ ARTIKEL 35

1. Allgemeine Anforderungen in Bezug auf qualifizierte technische Stellen für Weltraumtätigkeiten

1.1. Eine qualifizierte technische Stelle für Weltraumtätigkeiten wird nach nationalem Recht eingerichtet und ist mit Rechtspersönlichkeit ausgestattet, es sei denn, sie ist Teil einer zuständigen Behörde.

1.2. Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss unabhängig sein von

  - a) einem Anbieter von Weltraumdiensten im Sinne des Artikels 2 Absatz 1, wenn diese qualifizierte technische Stelle für Weltraumtätigkeiten eine technische Bewertung in Bezug auf ein Produkt, einen Prozess oder einen Dienst, einschließlich Risikomanagement, betreffend unter diese Verordnung fallende Angelegenheiten durchführt;

  - b) einem Wettbewerber eines Anbieters von Weltraumdiensten im Sinne des Artikels 2 Absatz 1 in Bezug auf die Durchführung der technischen Bewertung eines Produkts, eines Prozesses oder eines Dienstes, einschließlich Risikomanagement, betreffend unter diese Verordnung fallende Angelegenheiten;

  - c) einem Unternehmen, bei dem es sich nicht um einen Anbieter von Weltraumdiensten im Sinne des Buchstabens a oder um einen Wettbewerber im Sinne des Buchstabens b dieses Absatzes handelt und das ein wirtschaftliches Interesse an einem Produkt, einem Prozess oder einem Dienst, einschließlich Risikomanagement, betreffend unter diese Verordnung fallende Angelegenheiten hat.

1.3. Eine Stelle, die einem Wirtschaftsverband oder einem Berufsverband angehört, der Unternehmen, die an Entwurf, Entwicklung, Herstellung, Bereitstellung, Montage, Verwendung, Instandhaltung, Prüfung oder Betrieb eines von einer technischen Stelle zu bewertenden Produkts beteiligt sind, oder Unternehmen, die an der Nutzung oder dem Betrieb von Diensten, Tätigkeiten oder Prozessen beteiligt sind, die von dieser technischen Stelle zertifiziert werden, vertritt, kann nur dann als qualifizierte technische Stelle für Weltraumtätigkeiten im Sinne dieser Verordnung angesehen werden, wenn diese Stelle die Anforderungen in Bezug auf die Unabhängigkeit und das Nichtvorliegen von Interessenkonflikten erfüllt.

1.4. Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss so organisiert und geführt werden, dass die Unabhängigkeit, Objektivität und Unparteilichkeit bei der Ausübung ihrer Tätigkeiten gewährleistet sind.

    Zu diesem Zweck stellt eine qualifizierte technische Stelle für Weltraumtätigkeiten sicher, dass

  - a) Verfahren zur Gewährleistung und Dokumentation ihrer Unparteilichkeit eingerichtet werden und während der gesamten Dauer ihrer Tätigkeiten bestehen und dass diese Verfahren sowohl für die oberste Leitungsebene als auch für das Personal gelten, das Tätigkeiten der technischen Bewertung durchführt;

  - b) die qualifizierte technische Stelle für Weltraumtätigkeiten und ihr Personal die technische Bewertung mit der höchsten beruflichen Integrität und der erforderlichen fachlichen Kompetenz in dem/den spezifischen Tätigkeitsbereich(en) durchführen; sie dürfen keinerlei Druck und Einflussnahme, insbesondere finanzieller Art, ausgesetzt sein, die sich auf ihre Beurteilung oder die Ergebnisse der technischen Bewertung auswirken könnten;

  - c) sie über Strategien und Verfahren verfügt, um zwischen den Aufgaben, die sie als qualifizierte technische Stelle für Weltraumtätigkeiten wahrnimmt, und ihren anderen Aufgaben zu unterscheiden;

  - d) die qualifizierte technische Stelle für Weltraumtätigkeiten, ihre oberste Leitungsebene und das für die Durchführung von Tätigkeiten der technischen Bewertung zuständige Personal sich nicht mit Tätigkeiten befassen, die ihre Unabhängigkeit bei der Beurteilung oder die geforderte Integrität in Bezug auf die technische Bewertung, insbesondere Beratungsdienste, beeinträchtigen können;

  - e) die Vergütung für die oberste Leitungsebene und das für die Durchführung von Tätigkeiten der technischen Bewertung zuständige Personal der qualifizierten technischen Stelle für Weltraumtätigkeiten sich nicht nach der Anzahl der durchgeführten technischen Bewertungen oder deren Ergebnissen richtet;

  - f) die Transparenz des Verfahrens zur Durchführung technischer Bewertungen gewährleistet ist, z. B. durch die Veröffentlichung einer Beschreibung dieser Verfahren auf der entsprechenden Website.

    Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss die für die Erfüllung ihrer Aufgaben erforderlichen organisatorischen sowie qualitätsmanagement-, ressourcen- und prozessbezogenen Anforderungen erfüllen.

    Die Organisationsstruktur und die Arbeitsweise einer qualifizierten technischen Stelle für Weltraumtätigkeiten sowie die Zuweisung von Zuständigkeiten und die Berichterstattung müssen das Vertrauen in die Durchführung der Aufgaben und in die Ergebnisse ihrer technischen Bewertungen gewährleisten.

1.5. Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss jederzeit und für jedes Verfahren der technischen Bewertung gewährleisten, dass

  - a) sie über Personal verfügt, das über die erforderliche Fachkenntnis und über ausreichende einschlägige Erfahrung verfügt, um die bei der technischen Bewertung anfallenden Aufgaben zu erfüllen;

  - b) Verfahren angewandt werden, bei denen alle relevanten Kriterien berücksichtigt werden, die gelten für

    - i) Anbieter von Weltraumdiensten im Sinne des Artikels 2 Absatz 1, z. B. die Kriterien für die Größe dieses Anbieters von Weltraumdiensten, oder den spezifischen Sektor der Weltraumtätigkeiten;

    - ii) die objektiven Elemente wie Struktur, Komplexitätsgrad von Prozessen oder Technologie, Massenfertigungs- oder Seriencharakter der Herstellungsprozesse;

  - c) sie über die erforderlichen Mittel zur Erledigung aller technischen und administrativen Aufgaben, die mit den Tätigkeiten der technischen Bewertung verbunden sind, verfügt und Zugang zu allen benötigten Daten, Ausrüstungen oder Einrichtungen hat.

1.6. Das Personal einer qualifizierten technischen Stelle für Weltraumtätigkeiten, die für die Durchführung von Tätigkeiten der technischen Bewertung zuständig ist, muss über Folgendes verfügen:

  - a) ausreichende Kenntnisse der unter diese Verordnung fallenden Angelegenheiten, der einschlägigen Normen in den unter diese Verordnung fallenden Angelegenheiten oder der einschlägigen Bestimmungen des Unionsrechts;

  - b) fundierte Kenntnis der spezifischen Anforderungen, für die eine Tätigkeit der technischen Bewertung durchgeführt wird;

  - c) eine Fach- und Berufsausbildung, die alle Tätigkeiten der technischen Bewertung in dem Bereich umfasst, für den die qualifizierte technische Stelle für Weltraumtätigkeiten notifiziert wurde;

  - d) die Fähigkeit zur Erstellung von Bescheinigungen, Protokollen und Berichten als Nachweis für durchgeführte technische Bewertungen.

1.7. Eine qualifizierte technische Stelle für Weltraumtätigkeiten ist in der Lage, Aufgaben im Zusammenhang mit unter diese Verordnung fallenden Angelegenheiten mit höchster beruflicher Integrität und der erforderlichen Fachkompetenz in spezifischen Bereichen auszuführen, gleichgültig, ob diese Aufgaben von der qualifizierten technischen Stelle für Weltraumtätigkeiten selbst oder in ihrem Auftrag und in ihrer Verantwortung erfüllt werden.

    Wenn eine qualifizierte technische Stelle für Weltraumtätigkeiten einen Teil ihrer Aufgaben delegiert, muss sie über ausreichende interne Kompetenzen verfügen, um die von externen Stellen in ihrem Auftrag wahrgenommen Aufgaben wirksam beurteilen zu können.

1.8. Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss ständig über administratives, technisches, juristisches und wissenschaftliches Personal verfügen, das Erfahrung und Kenntnisse in Bezug auf einschlägige Technologien für Weltraumtätigkeiten und die in Titel IV der Verordnung festgelegten technischen Anforderungen besitzt.

1.9. Eine qualifizierte technische Stelle für Weltraumtätigkeiten gewährleistet durch dokumentierte Verfahren, dass ihr Personal und relevante Ausschüsse, Zweigstellen, Unterauftragnehmer oder etwaige zugeordnete Stellen oder Personal externer Einrichtungen beim Umgang mit vertraulichen Informationen, die bei der Durchführung der technischen Bewertung in ihren Besitz gelangen, die in Artikel 116 festgelegte Pflicht zur Wahrung des Berufsgeheimnisses befolgen, außer wenn die Offenlegung gesetzlich vorgeschrieben ist.

    Alle Informationen, die das Personal einer qualifizierten technischen Stelle für Weltraumtätigkeiten bei der Wahrnehmung der Aufgaben im Zusammenhang mit unter diese Verordnung fallenden Angelgelegenheiten erhält, unterliegen der beruflichen Schweigepflicht.

1.10. Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss im Besitz einer gültigen Sicherheitsüberprüfungsbescheinigung sein oder in der Lage sein, diese zu gegebener Zeit zu erhalten.

1.11. Eine qualifizierte technische Stelle für Weltraumtätigkeiten muss über eine angemessene Haftpflichtversicherung für die Durchführung ihrer Tätigkeiten der technischen Bewertung verfügen.

1.12. Eine qualifizierte technische Stelle für Weltraumtätigkeiten wirkt an den in Artikel 39 genannten Koordinierungstätigkeiten mit.

1.13. Eine qualifizierte technische Stelle für Weltraumtätigkeiten beteiligt sich direkt oder durch Vertretung an den Tätigkeiten der europäischen Normungsorganisationen oder stellt zumindest sicher, dass sie die einschlägigen Normen in den unter diese Verordnung fallenden Angelegenheit kennt und auf dem neuesten Stand ist.

1.14. Eine qualifizierte technische Stelle für Weltraumtätigkeiten übt ihre Tätigkeiten im Einklang mit einer Reihe kohärenter, gerechter und angemessener Geschäftsbedingungen aus, wobei sie insbesondere in Bezug auf Gebühren die Interessen der KMU berücksichtigt.

2. Spezifische Anforderungen in Bezug auf qualifizierte technische Stellen für Weltraumtätigkeiten, die Aufgaben der Überprüfung und Validierung der Studie über den Umweltfußabdruck wahrnehmen

2.1. Qualifizierte technische Stellen für Weltraumtätigkeiten, die eine technische Bewertung von Angelegenheiten durchführen, die unter Titel IV Kapitel III fallen, müssen zusätzlich zu den in Abschnitt I dieses Anhangs festgelegten Anforderungen die in Abschnitt 8 der Empfehlung C(2021)9332 der Kommission festgelegten Anforderungen erfüllen.

Anhang X

VERSTÖẞE GEGEN DIE REGELUNG GEMÄẞ ARTIKEL 54

1. Für Unionsbetreiber im Bereich Weltraum relevante Verstöße

1.1. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 6 Absatz 1 in Verbindung mit Artikel 7 Absatz 1, wenn er Weltraumdienste erbringt, bevor er eine Genehmigung zur Durchführung von Weltraumtätigkeiten erhalten hat.

1.2. Ein Unionsbetreiber im Bereich Weltraum, der beabsichtigt, die Weltraumdienste eines Drittlandsbetreibers im Bereich Weltraum oder einer internationalen Organisation in Anspruch zu nehmen, verstößt gegen Artikel 6 Absatz 5, wenn er seiner zuständigen Behörde in seinem Genehmigungsantrag nicht die Registrierung dieses Drittlandsbetreibers im Bereich Weltraum oder der internationalen Organisation im URSO nachweist oder, falls das Verfahren der Registrierung im URSO noch nicht abgeschlossen ist, sich nicht eng mit dem Drittlandsbetreiber im Bereich Weltraum oder der internationalen Organisation, der jeweils zuständigen Behörde und der Agentur abstimmt, indem er sich u. a. nach dem Bearbeitungsstand der beantragten Registrierung erkundigt.

1.3. Ein Unionsbetreiber im Bereich Weltraum der Union verstößt gegen Artikel 6 Absatz 6, wenn er die zuständige Behörde nicht unverzüglich über den Bedarf an der Erbringung von Weltraumdiensten durch einen Drittlandsbetreiber im Bereich Weltraum oder eine internationale Organisation unterrichtet, der nach der Erteilung einer Genehmigung entsteht, wie z. B. im Fall von ISOS, und wenn er der zuständigen Behörde nicht den Nachweis der Registrierung dieses Drittlandsbetreibers im Bereich Weltraum oder dieser internationalen Organisation im URSO vorlegt.

1.4. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 7 Absatz 2, wenn er in seinem Genehmigungsantrag kein technisches Dossier mit allen erforderlichen Unterlagen und Nachweisen vorlegt, um die Einhaltung der in Titel IV Kapitel I bis V festgelegten Anforderungen in Bezug auf seine spezifische Weltraummission nachzuweisen.

1.5. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 7 Absatz 3, wenn er in seinem Genehmigungsantrag für die zuständige Behörde nicht angibt, welche qualifizierten technischen Stellen für Weltraumtätigkeiten der Antragsteller für die technische Bewertung der in Titel IV Kapitel I bis V festgelegten Anforderungen in Anspruch zu nehmen beabsichtigt.

1.6. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 9 Absatz 1, wenn er bei Vorlage der in Artikel 9 Absatz 1 Unterabsatz 2 genannten Erklärung nicht sicherstellt, dass er die in Artikel 9 Absatz 1 Buchstaben a und b festgelegten Bedingungen erfüllt, oder wenn er diese Erklärung nicht vorlegt.

1.7. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 9 Absatz 5, wenn er für den Fall, dass bei stichprobenartigen Kontrollen Aspekte festgestellt wurden, die im Widerspruch zu der vom Unionsbetreiber im Bereich Weltraum abgegebenen Erklärung stehen, nicht die von den zuständigen Behörden verlangten Erläuterungen vorlegt und diese Erläuterungen erforderlich sind, damit die zuständige Behörde feststellen kann, ob und in welchem Umfang Risiken mit einem solchen Widerspruch verbunden sind.

1.8. Ein Unionsbetreiber im Bereich Weltraum, der den in Artikel 10 Absätze 2, 3 und 4 genannten vereinfachten Regelungen unterliegt, erfüllt nicht die in diesen Absätzen genannten Bedingungen.

1.9. Ein Antragsteller, der beabsichtigt, Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen zu werden, verstößt gegen Artikel 11 Absatz 2, wenn er der Agentur und der Kommission nicht alle technischen Einzelheiten und Erläuterungen vorlegt, die die Einhaltung der in Titel IV Kapitel I, II, III, IV und V sowie in Artikel 12 Absatz 1 Unterabsatz 1 festgelegten Anforderungen belegen, und gegen Artikel 11 Absatz 3, wenn er der Agentur und der Kommission nicht alle zusätzlichen Informationen oder Präzisierungen vorlegt.

1.10. Ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen verstößt gegen Artikel 11 Absatz 2 und Artikel 12 Absatz 1 Unterabsatz 1, wenn er die in Artikel 12 Absatz 1 Unterabsatz 1 und in Titel IV festgelegten Anforderungen nicht erfüllt.

1.11. Ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen verstößt gegen Artikel 13 Absatz 1, wenn er unvorhergesehene Ereignisse, die eine Änderung seiner Genehmigung erfordern könnten, oder eine geplante oder unmittelbar bevorstehende Einstellung seiner Tätigkeit nicht meldet.

1.12. Ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen befindet sich in einer der in Artikel 13 Absatz 2 Unterabsatz 1 genannten Situationen.

1.13. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 26 Absätze 1 und 2, wenn er den Verträgen über die Bereitstellung weltraumgestützter Daten und Weltraumdienste in der Union nicht das elektronische Zertifikat beifügt.

1.14. Ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen verstößt gegen Artikel 49, wenn er einer Entscheidung über ein Auskunftsersuchen gemäß Artikel 49 Absatz 3 nicht nachkommt oder wenn er die in Artikel 49 Absatz 1 genannten Informationen nicht vorlegt.

1.15. Ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen verstößt gegen Artikel 50 Absatz 5 Unterabsatz 1, wenn er in eine Untersuchung nicht einwilligt und die Ausübung der in Artikel 50 Absatz 4 genannten Befugnisse behindert.

1.16. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 51 Absatz 5, wenn er in die auf Beschluss der Agentur und der Kommission angeordneten Kontrollen vor Ort nicht einwilligt.

1.17. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 53 Absatz 2 in Verbindung mit den Artikeln 49, 50 und 51, wenn er in diese Untersuchung nicht einwilligt.

1.18. Ein Startbetreiber aus der Union verstößt gegen Artikel 58, Artikel 59, Artikel 60 oder Artikel 61 in Bezug auf die Sicherheit von Trägerraketen.

1.19. Ein Raumfahrzeugbetreiber aus der Union verstößt gegen eine der Bestimmungen der Artikel 62 bis 73 in Bezug auf die Sicherheit von Raumfahrzeugen und Weltraumtätigkeiten.

1.20. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 74, wenn er nicht alle Maßnahmen ergreift, um die Konformität der in Auftrag gegebenen Weltraumobjekte oder gegebenenfalls die Konformität von Komponenten mit den Entwurfs- und Herstellungsanforderungen gemäß Titel IV Kapitel I sicherzustellen.

1.21. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Resilienzanforderungen, wenn er die Risikomanagementvorschriften gemäß Artikel 76, Artikel 77, Artikel 78, Artikel 79, Artikel 80, Artikel 81, Artikel 82, Artikel 83, Artikel 84, Artikel 85, Artikel 86, Artikel 87, Artikel 88, Artikel 89, Artikel 90, Artikel 91, Artikel 92 und Artikel 95 Absätze 1, 2 und 3 nicht befolgt.

1.22. Ein Unionsbetreiber im Bereich Weltraum von unionseigenen Ressourcen verstößt in Bezug auf die Meldung erheblicher Sicherheitsvorfälle in Verbindung mit unionseigenen Ressourcen gegen Artikel 93, wenn er diese nicht der in Artikel 93 Absatz 1 genannten Struktur meldet oder wenn er die Meldung nicht in der in Artikel 93 Absatz 7 Unterabsatz 1 vorgegebenen Weise vornimmt.

1.23. Ein Unionsbetreiber im Bereich Weltraum, der die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen betreibt, verstößt gegen Artikel 93, wenn er den zuständigen Behörden nicht gemäß Artikel 93 Absatz 2 eine Meldung übermittelt oder wenn er die Meldung nicht in der in Artikel 93 Absatz 7 Unterabsatz 1 vorgegebenen Weise vornimmt.

1.24. Ein Unionsbetreiber im Bereich Weltraum, der als wesentliche oder wichtige Einrichtung im Sinne der Anhänge I oder II der Richtlinie (EU) 2022/2555 eingestuft ist, verstößt gegen Artikel 93 Absatz 3 Unterabsatz 1, wenn er nicht die in diesem Artikel genannten Meldungen vornimmt, und gegen Artikel 93 Absatz 7 Unterabsatz 1, wenn er die Meldung nicht in der darin festgelegten Weise vornimmt.

1.25. Ein Unionsbetreiber im Bereich Weltraum, der gemäß dem Anhang der Richtlinie (EU) 2022/2557 als kritische Einrichtung eingestuft ist, verstößt gegen Artikel 93 Absatz 3 Unterabsatz 2, wenn er nicht in der vom Mitgliedstaat gemäß diesem Artikel festgelegten Weise eine Meldung übermittelt, und gegen Artikel 93 Absatz 7 Unterabsatz 1, wenn er die Meldung nicht in der darin festgelegten Weise vornimmt.

1.26. Ein Antragsteller, der eine Genehmigung als Unionsbetreiber im Bereich Weltraum beantragt, verstößt gegen Artikel 96 Absätze 4 und 6, wenn er seiner zuständigen Behörde keine Erklärung zum Umweltfußabdruck (Environmental Footprint Declaration, EFD) oder nicht alle in Artikel 96 Absatz 6 genannten Elemente vorlegt.

1.27. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 97, wenn er die in Artikel 97 Absatz 1 genannten Weltraummissionen oder die in Artikel 97 Absatz 2 genannten Tätigkeiten nicht in die Berechnung einbezieht.

1.28. Ein Unionsbetreiber im Bereich Weltraum, der unionseigene Ressourcen betreibt, verstößt gegen Artikel 97 Absatz 3, wenn er nicht die in Artikel 3 Absatz 1 Buchstaben a bis c und e der Verordnung (EU) 2021/696 bzw. – soweit anwendbar – in Artikel 1 der Verordnung (EU) 2023/588 genannten Komponenten einbezieht.

1.29. Ein Antragsteller, der eine Genehmigung als Unionsbetreiber im Bereich Weltraum beantragt, verstößt gegen Artikel 98 Absatz 1, wenn er bei Beantragung der Genehmigung nicht im Besitz des EF-Zertifikats ist.

1.30. Ein Antragsteller, der eine Genehmigung als Unionsbetreiber im Bereich Weltraum beantragt, verstößt gegen Artikel 99, wenn er nicht die in Artikel 99 Absatz 1 Unterabsatz 1 genannten Datensätze übermittelt.

1.31. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 101.

1.32. Ein Unionsbetreiber im Bereich Weltraum verstößt gegen Artikel 112 Absatz 1 Unterabsatz 1, wenn er dem Antrag auf Erteilung eines Weltraumsiegels der Union keine detaillierten technischen Unterlagen beifügt, aus denen hervorgeht, dass die Anforderungen des Kennzeichnungssystems der Union, für das das Weltraumsiegel der Union beantragt wird, erfüllt sind.

1.33. Ein Unionsbetreiber im Bereich Weltraum, der Inhaber eines Weltraumsiegels der Union ist, verstößt gegen Artikel 112 Absatz 3, wenn er die Anforderungen des Kennzeichnungssystems der Union, für das dieses Weltraumsiegel der Union vergeben wurde, nicht weiter erfüllt, und gegen Artikel 112 Absatz 6, wenn er die Agentur nicht über nachträglich festgestellte Unregelmäßigkeiten in Bezug auf die mit dem Siegel versehene Weltraummission, den Dienst oder das Produkt unterrichtet, die sich auf die Erfüllung der Anforderungen des betreffenden Weltraumsiegels der Union auswirken können.

2. Für Drittlandsanbieter von Weltraumdiensten relevante Verstöße

2.1. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 14 Absatz 1, wenn er Weltraumdienste für Unionsbetreiber im Bereich Weltraum und in Bezug auf unionseigene Ressourcen und die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen erbringt, ohne im Unionsregister der Weltraumobjekte registriert zu sein und ohne im Besitz des elektronischen Zertifikats zu sein.

2.2. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 15 Absatz 1, wenn er eine der in Artikel 15 in Verbindung mit Titel IV Kapitel I bis V aufgeführten Anforderungen gemäß Artikel 15 nicht erfüllt.

2.3. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 17 Absatz 3, wenn er der Agentur in seinem Antrag nicht alle für den Nachweis der Konformität erforderlichen Nachweise vorlegt.

2.4. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 22, wenn er es versäumt, im Rahmen des Dialogs mit der Agentur die erforderlichen Erläuterungen, Unterlagen und Nachweise zur Untermauerung seiner Erläuterungen, einschließlich technischer Analysen, vorzulegen und die Konformität sicherzustellen.

2.5. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 23, wenn er nicht schriftlich eine oder mehrere juristische Personen in einem der Mitgliedstaaten als seinen gesetzlichen Vertreter in der Union benennt oder wenn er diesem gesetzlichen Vertreter nicht die Befugnis überträgt, zusätzlich zu oder anstelle des Drittlandsbetreibers im Bereich Weltraum in allen Fragen im Zusammenhang mit der Einhaltung dieser Verordnung für die zuständigen Behörden, die Kommission und die Agentur als Ansprechpartner zur Verfügung zu stehen, und ihn nicht mit allen erforderlichen Befugnissen und Ressourcen für eine effiziente und zeitnahe Zusammenarbeit mit diesen Behörden ausstattet.

2.6. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 25 Absatz 3, wenn er den Verträgen über die Bereitstellung weltraumgestützter Daten und Weltraumdienste in der Union nicht das elektronische Zertifikat beifügt.

2.7. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 25 Absatz 4, wenn er der Agentur nicht die in Artikel 25 Absatz 4 Unterabsatz 1 genannten Angaben übermittelt, die diese benötigt, um das elektronische Zertifikat zu erstellen.

2.8. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 26 Absätze 1 und 2, wenn er den Verträgen über die Bereitstellung weltraumgestützter Daten und Weltraumdienste in der Union nicht das elektronische Zertifikat beifügt.

2.9. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 49, wenn er einer Entscheidung über ein Auskunftsersuchen gemäß Artikel 49 Absatz 3 nicht nachkommt oder wenn er die in Artikel 49 Absatz 1 genannten Informationen nicht vorlegt.

2.10. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 50 Absatz 5 Unterabsatz 1, wenn er in eine Untersuchung nicht einwilligt und die Ausübung der in Artikel 50 Absatz 4 genannten Befugnisse behindert.

2.11. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 51 Absatz 5, wenn er in die auf Beschluss der Agentur und der Kommission angeordneten Kontrollen vor Ort nicht einwilligt.

2.12. Ein Drittlandsbetreiber im Bereich Weltraum, der die Anforderung des Artikels 52 Absatz 1 Buchstabe b erfüllt hat, verstößt gegen Artikel 52, wenn er in die Kontrolle nicht einwilligt oder die Ausübung der in Artikel 52 Absatz 2 festgelegten Befugnisse behindert.

2.13. Ein Drittlandsbetreiber im Bereich Weltraum verstößt gegen Artikel 53 Absatz 2 in Verbindung mit den Artikeln 49, 50 und 51.

3. Für internationale Organisationen relevante Verstöße

3.1. Internationale Organisationen mit spezifischen Fachkenntnissen in den unter diese Verordnung fallenden Angelegenheiten, die von den Mitgliedstaaten für die Durchführung technischer Bewertungen gemäß Artikel 8 Absatz 1 Buchstabe b ausgewählt wurden, verstoßen gegen Artikel 8 Absatz 3 Unterabsatz 1, wenn sie die Anforderungen des Artikels 8 Absatz 3 Unterabsatz 1 der Verordnung Titel III Kapitel I Abschnitt 3 nicht erfüllen.

3.2. Eine internationale Organisation verstößt gegen Artikel 25 Absatz 3, wenn sie den Verträgen über die Bereitstellung weltraumgestützter Daten und Weltraumdienste in der Union nicht das elektronische Zertifikat beifügt.

3.3. Eine internationale Organisation verstößt gegen Artikel 14 Absatz 2.

3.4. Eine internationale Organisation verstößt gegen Artikel 25 Absatz 4, wenn sie der Agentur nicht die in Artikel 25 Absatz 4 Unterabsatz 1 genannten Angaben übermittelt, die diese benötigt, um das elektronische Zertifikat zu erstellen.

3.5. Eine internationale Organisation verstößt gegen Artikel 26 Absätze 1 und 2, wenn sie den Verträgen über die Bereitstellung weltraumgestützter Daten und Weltraumdienste in der Union nicht das elektronische Zertifikat beifügt.

3.6. Eine internationale Organisation verstößt gegen Artikel 49, wenn sie einer Entscheidung über ein Auskunftsersuchen gemäß Artikel 49 Absatz 3 nicht nachkommt oder wenn sie die in Artikel 49 Absatz 1 genannten Informationen nicht vorlegt.

3.7. Eine internationale Organisation verstößt gegen Artikel 50 Absatz 5 Unterabsatz 1, wenn sie in eine Untersuchung nicht einwilligt und die Ausübung der in Artikel 50 Absatz 4 genannten Befugnisse behindert.

3.8. Eine internationale Organisation verstößt gegen Artikel 51 Absatz 5.

3.9. Eine internationale Organisation verstößt gegen Artikel 53 Absatz 2 in Verbindung mit den Artikeln 49, 50 und 51.

3.10. Eine internationale Organisation verstößt gegen Artikel 58, Artikel 59, Artikel 60 oder Artikel 61 in Bezug auf die Sicherheit von Trägerraketen.

3.11. Eine internationale Organisation verstößt gegen die Artikel 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72 oder 73 in Bezug auf die Sicherheit von Raumfahrzeugen und Weltraumtätigkeiten.

3.12. Eine internationale Organisation verstößt gegen Artikel 74, wenn sie nicht alle Maßnahmen ergreift, um die Konformität der in Auftrag gegebenen Weltraumobjekte oder gegebenenfalls die Konformität von Komponenten mit den Entwurfs- und Herstellungsanforderungen gemäß Titel IV Kapitel I sicherzustellen.

3.13. Eine internationale Organisation verstößt gegen die Risikomanagementanforderungen, wenn sie die Vorschriften der Artikel 76, Artikel 77, Artikel 78, Artikel 79, Artikel 80, Artikel 81, Artikel 82, Artikel 83, Artikel 84, Artikel 85, Artikel 86, Artikel 87, Artikel 88, Artikel 89, Artikel 90, Artikel 91 und Artikel 92 nicht befolgt und die in Artikel 95 Absätze 1, 2 und 3 festgelegten Bedingungen nicht erfüllt.

3.14. Eine internationale Organisation verstößt in Bezug auf die Meldung erheblicher Sicherheitsvorfälle in Verbindung mit unionseigenen Ressourcen gegen Artikel 93, wenn sie diese nicht der in Artikel 93 Absatz 1 genannten Struktur meldet oder wenn sie die Meldung nicht in der in Artikel 93 Absatz 7 Unterabsatz 1 vorgegebenen Weise vornimmt.

3.15. Eine internationale Organisation, die die in Artikel 5 Absatz 1 Nummer 21 genannten Ressourcen betreibt, verstößt gegen Artikel 93, wenn sie den zuständigen Behörden nicht gemäß Artikel 93 Absatz 2 eine Meldung übermittelt oder wenn sie die Meldung nicht in der in Artikel 93 Absatz 7 Unterabsatz 1 vorgegebenen Weise vornimmt.

3.16. Eine internationale Organisation verstößt gegen Artikel 97, wenn sie die in Artikel 97 Absatz 1 genannten Weltraummissionen oder die in Artikel 97 Absatz 2 genannten Tätigkeiten nicht in die Berechnung einbezieht.

3.17. Eine internationale Organisation verstößt gegen Artikel 97 Absatz 3, wenn sie nicht die in Artikel 3 Absatz 1 Buchstaben a bis c und e der Verordnung (EU) 2021/696 bzw. – soweit anwendbar – in Artikel 1 der Verordnung (EU) 2023/588 genannten Komponenten einbezieht.

3.18. Eine internationale Organisation verstößt gegen Artikel 98 Absatz 1, wenn sie nicht im Besitz des EF-Zertifikats für die Erbringung von Weltraumdiensten in Bezug auf die in Artikel 5 Absatz 1 Nummern 20 und 21 genannten Ressourcen ist.

3.19. Eine internationale Organisation verstößt gegen Artikel 99, wenn sie der Kommission nicht die in Artikel 99 Absatz 1 Unterabsatz 1 genannten Datensätze übermittelt.

3.20. Eine internationale Organisation verstößt gegen Artikel 101.

4. Für Primäranbieter weltraumgestützter Daten relevante Verstöße

4.1. Ein Primäranbieter weltraumgestützter Daten verstößt gegen Artikel 27 Absatz 2, wenn er keine Warnungen an seine Lieferanten übermittelt und die Agentur oder die zuständige Behörde des Mitgliedstaats, in dem er niedergelassen ist, nicht über erhaltene Warnungen oder Beschwerden betreffend mögliche Unregelmäßigkeiten informiert.

5. Für Anbieter von Weltraumdiensten zur Kollisionsvermeidung relevante Verstöße

5.1. Ein Anbieter von Weltraumdiensten zur Kollisionsvermeidung verstößt gegen Artikel 102 Absatz 1, wenn er der zuständigen Behörde des Unionsbetreibers im Bereich Weltraum keine aktuellen Informationen über das Raumfahrzeug übermittelt, oder gegen Artikel 102 Absatz 2 Unterabsatz 1, wenn er nicht über die darin festgelegten Aspekte Bericht erstattet.

5.2. Ein Anbieter von Weltraumdiensten zur Kollisionsvermeidung verstößt gegen Artikel 103 Absatz 1 Unterabsatz 1, wenn er nicht die in Artikel 103 Absatz 1 Unterabsatz 1 für Kollisionsvermeidungsmanöver genannten Bedingungen erfüllt, oder gegen Artikel 103 Absatz 2, wenn er nicht die Koordinierung gemäß dem genannten Absatz sicherstellt, oder gegen Artikel 103 Absatz 3 Unterabsatz 1, wenn er der Strategie nicht die in Unterabsatz 1 festgelegten Grundsätze zugrunde legt, oder gegen Artikel 103 Absatz 4, wenn er keinen Kontakt zu dem betreffenden Raumfahrzeug herstellt, oder im Fall einer erfolgreichen Herstellung des Kontakts gegen Artikel 103 Absatz 5 Unterabsatz 1, wenn er die Anforderungen des genannten Unterabsatzes nicht befolgt, oder gegen Artikel 103 Absatz 6, wenn er keine Strategie im Einklang mit den in diesem Absatz festgelegten Anforderungen empfiehlt.

6. Für qualifizierte Stellen für Weltraumtätigkeiten relevante Verstöße

6.1. Unbeschadet der Regelung anderer Stellen, die technische Bewertungen gemäß Artikel 8 Absatz 1 Unterabsatz 1 durchführen können, verstößt eine Einrichtung gegen Artikel 34 Absatz 1, wenn sie solche technischen Bewertungen durchführt, ohne als qualifizierte technische Stelle für Weltraumtätigkeiten im Rahmen dieser Verordnung benannt und notifiziert zu sein.

6.2. Eine Einrichtung, die beabsichtigt, technische Bewertungen für eine oder mehrere unter Titel IV Kapitel I bis V fallende Angelegenheiten durchzuführen, verstößt gegen Artikel 34, wenn sie die erforderlichen Unterlagen nicht vorlegt oder aktualisiert oder die in den Absätzen 4 bis 8 dieses Artikels festgelegten Bedingungen nicht erfüllt.

6.3. Eine Einrichtung, die beabsichtigt, eine technische Bewertung in Bezug auf eine oder mehrere unter Titel IV Kapitel I bis V fallende Angelegenheiten durchzuführen, verstößt gegen Artikel 35, wenn sie eine der in Artikel 35 Absätze 1, 2, 3 und 4 in Verbindung mit den Bestimmungen des Anhangs IX festgelegten Bedingungen nicht erfüllt.

6.4. Eine qualifizierte Stelle für Weltraumtätigkeiten verstößt gegen Artikel 35, wenn sie eine der darin festgelegten Anforderungen in Verbindung mit Anhang IX Nummer 1 oder Anhang IX Nummer 2 nicht mehr erfüllt.
