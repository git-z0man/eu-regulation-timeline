---
act: chips-act-2
version: 2026-06-03_com-proposal
stage: com-proposal
language: de
celex: 52026PC0504
title: Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES über einen Rahmen für Maßnahmen zur Stärkung des Halbleiterökosystems der Union und zur Aufhebung der Verordnung (EU) 2023/1781 (Chip-Verordnung 2.0)
retrieved: '2026-09-24'
converter: tools/eurlex2md.py
counts:
  recitals: 124
  articles: 60
  annexes: 7
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52026PC0504
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES über einen Rahmen für Maßnahmen zur Stärkung des Halbleiterökosystems der Union und zur Aufhebung der Verordnung (EU) 2023/1781 (Chip-Verordnung 2.0)

<a id="begr-ndung"></a>
## BEGRÜNDUNG

### 1. KONTEXT DES VORSCHLAGS

#### • Gründe und Ziele des Vorschlags

Halbleiter bilden die Grundlage für alle digitalen Technologien, von intelligenten direkt am Körper tragbaren Geräten (Wearables) und Autos bis hin zu medizinischen Geräten, Verteidigungsgütern und missionskritischer Ausrüstung, aber auch für die Rechenzentren, die die Revolution der künstlichen Intelligenz (KI) vorantreiben. Seit 2020 hat eine Reihe von Versorgungsengpässen und von Versuchen, die EU wirtschaftlich zu nötigen, die Fragilität des europäischen Halbleiterökosystems und die Anfälligkeit seiner Endanwenderbranchen deutlich gemacht. Diese Störungen sind auf globale Krisen wie die COVID-19-Pandemie, einzelne Schocks wie den Nexperia-Fall und das anhaltende strukturelle Missverhältnis zwischen Angebot und Nachfrage auf dem Weltmarkt zurückzuführen. Zusammen haben diese Faktoren gezeigt, wie übermäßige externe Abhängigkeiten ganze Märkte schwächen können.

Gleichzeitig haben zunehmende geopolitische Rivalitäten, einschließlich der Spannungen zwischen China und den USA, und das rasche Aufkommen von KI die strategische Bedeutung von Halbleitern weiter hervorgehoben. Modernste, aber auch handelsübliche Chips sind zunehmend zu einem entscheidenden geopolitischen Vorteil geworden, und entlang der globalen Halbleiterwertschöpfungskette haben sich mehrere Nadelöhre offenbart. Dies hat den Wettlauf um die Kontrolle von Teilen dieser Nadelöhre beschleunigt.

Das Wachstum dieser Branche spiegelt ihre geopolitische Bedeutung wider. Halbleiter sind – nach Erdöl und Fahrzeugen – die am dritthäufigsten gehandelte Ware der Welt. Die damit erzielten weltweiten Umsätze beliefen sich im Jahr 2025 auf 700,9 Mrd. USD^(1). Es wird erwartet, dass der Markt bis 2026 einen Wert von über 1 Billion USD^(2) überschreiten und bis 2030 auf 1,6 Billionen USD anwachsen^(3) wird. Als wichtiger Lieferant und Wegbereiter für fast alle modernen Industriezweige und die sie unterstützenden Infrastrukturen hat sich der Halbleitersektor zu einer strategischen Ressource entwickelt. In einem stärker transaktionsorientierten und selbstbewussteren globalen Umfeld macht diese Position den Halbleitersektor auch zu einer potenziellen Quelle geopolitischer Einflussnahme. Regionen, die selbst über keine nennenswerten Fähigkeiten in den Bereichen Entwurf und Fertigung von Halbleitern verfügen, laufen daher Gefahr, von Komponenten abhängig zu werden, die möglicherweise von anderen nur mit Beschränkungen oder Auflagen geliefert werden.

Das im Februar 2022 vorgeschlagene erste europäische Chip-Gesetz war die erste strategische Reaktion der EU auf kritische Schwachstellen in der globalen Halbleiterwertschöpfungskette, die durch die COVID-19-Pandemie aufgezeigt wurden und die den weltweiten subventionsgetriebenen Wettbewerb durch Drittländer verschärfen. Die EU kam zu dem Schluss, dass ein entschlossenes und koordiniertes Eingreifen unerlässlich ist, um strukturelle Abhängigkeiten in ihrem Halbleiterökosystem anzugehen und die Industrie zu unterstützen. Ohne erhebliche Investitionen in Forschungs- und Fertigungskapazitäten und ohne angemessene Krisenreaktionsmechanismen würde Europa sonst strukturell anfällig bleiben. Das Chip-Gesetz entstand in einer Zeit, in der das Augenmerk stark auf dem grünen und digitalen Wandel lag, und vor dem Hintergrund eines wachsenden europäischen Konsenses über die Notwendigkeit, die wirtschaftliche Wettbewerbsfähigkeit der Region zu stärken und den Rückgang der industriellen Kapazitäten umzukehren. Im Draghi-Bericht vom September 2024 wurden diese Bedenken später genau dargelegt und es wurde dringend eine industrielle Erneuerung gefordert^(4).

Die Bewertung des europäischen Chip-Gesetzes zeigt, dass es bemerkenswerte Ergebnisse erbracht hat. Beispielweise

- · wurden Infrastrukturen errichtet, darunter Kompetenzzentren, ein erster Ansatz für eine Entwurfsplattform und fünf hochmoderne Pilotanlagen, die zu den innovativsten Technologieinfrastrukturen der Welt zählen,

- · wurden mehr als 52 Mrd. EUR für öffentliche und private Investitionen in laufende Produktionsstätten im Rahmen der Säule II gebunden und

- · wurde über das Europäische Halbleitergremium (ESB) im Rahmen der Säule III ein Koordinierungs- und Krisenreaktionsmechanismus eingerichtet, an dem alle Mitgliedstaaten und die Kommission beteiligt sind.

Trotz dieser erheblichen Fortschritte und der Stärken der Union in Schlüsselsegmenten der Halbleiterwertschöpfungskette, wie der Produktion handelsüblicher Halbleiter (Leistungselektronik, Mikrocontroller, Photonik, Sensoren), Fertigungsausrüstung und Werkstoffe, bestehen nach wie vor klare Defizite im Hinblick auf wichtige Fähigkeiten, die geschlossen werden müssen.

Die EU produziert weniger als 10 %^(5) der Halbleiter weltweit und ist bei den fortgeschrittensten und modernsten Chips unter 5 Nanometern – einschließlich KI-Chips – fast vollständig von den Vereinigten Staaten und Asien abhängig. Diese strukturellen Abhängigkeiten erhöhen das Risiko von Lieferstörungen und die Gefahr der Ausübung von Druck und von systemischen Schocks in Schlüsselindustrien der EU – von der Automobil- und Energieindustrie bis hin zu Luftfahrt, Weltraum und Verteidigung. Insgesamt veranschaulichen Halbleiter, wie dringlich es geworden ist, dass Europa die Herausforderung der technologischen Souveränität bewältigt.

Die technologische Souveränität ist zu einer strategischen Notwendigkeit für die EU geworden. Ziel ist es, dafür zu sorgen, dass Europa weiterhin seinen eigenen Weg wählen kann und dafür übermäßige Abhängigkeiten zu verringern und sicherzustellen, dass kritische digitale Infrastrukturen und Technologien sicher und resilient bleiben und mit den europäischen Werten im Einklang stehen.

Die Chip-Verordnung 2.0 wird daher zusammen mit anderen Initiativen wie der Verordnung zur Cloud- und KI-Entwicklung (CADA) Teil des Pakets zur technologischen Souveränität sein.

Europas Ansatz für technologische Souveränität fußt auf Offenheit, Partnerschaft und fairem Wettbewerb. Durch die Stärkung ihrer technologischen Basis kann die EU offen und kooperativ bleiben und gleichzeitig ihre Fähigkeit erhalten, unabhängig zu handeln und ihre Interessen, ihre Sicherheit und ihre demokratischen Grundsätze zu schützen.

In diesem Zusammenhang sind die beiden wichtigsten Probleme, die mit der Überarbeitung des Chip-Gesetzes angegangen werden sollen, die folgenden:

  - a) übermäßige Abhängigkeit von Drittländern bei Entwurf und Fertigung von Halbleitern;

  - b) unzureichende Krisenvorsorgefähigkeiten.

Aufbauend auf den im ersten Chip-Gesetz gesetzten Zielen und auf der Grundlage einer Analyse dieser Herausforderungen und der ihnen zugrunde liegenden Ursachen wurden zwei übergeordnete Ziele für die Chip-Verordnung 2.0 ermittelt:

- 1) Steigerung der Wettbewerbsfähigkeit der europäischen Halbleiterwertschöpfungskette zur Verbesserung ihrer technologischen Souveränität und Resilienz. Dies bedeutet, dass die notwendigen Voraussetzungen für die Wettbewerbsfähigkeit, technologische Souveränität und Resilienz der EU im Bereich der Halbleitertechnologien geschaffen werden müssen, indem i) die industrielle Einführung von Forschungs- und Innovationsergebnissen beschleunigt, ii) die Versorgungssicherheit gewährleistet und iii) strategische Abhängigkeiten in Bezug auf hochmoderne und ausgereifte Halbleitertechnik verringert wird.

- 2) Bessere Krisenvorsorge zur Gewährleistung der Versorgungssicherheit der EU. Dies bedeutet, dass das Funktionieren des Binnenmarkts verbessert werden soll, indem die Krisenvorsorge verbessert und ein einheitlicher Rechtsrahmen geschaffen wird, um die wirtschaftliche Sicherheit der Union zu schützen und ihre Unumgänglichkeit, ihre Resilienz und ihren Erfolg im Bereich der Halbleitertechnologien zu erhöhen.

- Steigerung der Wettbewerbsfähigkeit der europäischen Halbleiterwertschöpfungskette zur Verbesserung ihrer technologischen Souveränität und Resilienz

Da die Abhängigkeit der EU von der Versorgung mit Halbleitern aus dem Ausland stetig zunimmt, ist sie anfälliger für externen Zwang, einschließlich der Möglichkeit, dass die Abhängigkeiten in der Lieferkette als Waffe eingesetzt werden. Ohne eine solide industrielle Basis für den Entwurf und die Fertigung von Halbleitern wäre es möglich, dass die EU nicht in der Lage sein wird, ihr starkes Forschungs- und Innovationsökosystem in Produktivitätssteigerungen und die groß angelegte Industrialisierung neuer Technologien umzusetzen.

Gleichzeitig sind die europäischen Anwenderbranchen mit erheblichen Unsicherheiten in der Lieferkette konfrontiert, die größere Lagerbestände erforderlich machen und Investitionen dämpfen. Dies wiederum untergräbt die allgemeine Wettbewerbsfähigkeit der Fertigungsbranche in der EU. Darüber hinaus erhöhen Abhängigkeiten in Halbleiterlieferketten geo- und sicherheitspolitische Risiken, insbesondere in Krisenzeiten, in denen der Zugang zu kritischen Technologien beschränkt sein kann oder diese in andere Regionen umgelenkt werden können.

Vor diesem Hintergrund war das ursprüngliche Chip-Gesetz überwiegend angebotsorientiert, aber in der Chip-Verordnung 2.0 wird mehr Gewicht auf nachfrageseitige Maßnahmen gelegt. Die beiden Dimensionen verstärken sich gegenseitig, denn die Förderung einer robusten lokalen Nachfrage trägt zur Stärkung des lokalen Halbleiterangebots bei. Auf diese Weise trägt die kombinierte Ausweitung von Angebot und Nachfrage zu einer größeren Resilienz der Industrie, kürzeren und sichereren Lieferketten, einer größeren strategischen Autonomie und einer besseren Abstimmung zwischen den europäischen Produktionskapazitäten und den Bedürfnissen von Schlüsselindustrien bei.

Dieser Ansatz steht in engem Zusammenhang mit breiter angelegten EU-Initiativen, insbesondere dem CADA-Vorschlag, der Maßnahmen zur Stimulierung der Nachfrage nach hochmodernen KI-Chips durch den Aufbau neuer Rechenzentren in der gesamten Union umfasst. Diese Maßnahmen dürften zu einer zusätzlichen Nachfrage nach Halbleitern führen, die die Ziele der nun überarbeiteten Chip-Verordnung unterstützen kann. In der Mitteilung über den Aktionsplan für den KI-Kontinent^(6) wird dargelegt, wie die Union im Rahmen der umfassenderen Bemühungen zum Aufbau von KI-Gigafabriken strategische Autonomie bei der Konzeption und Herstellung von KI-Halbleitern erreichen, Abhängigkeiten im Bereich kritischer Technologien verringern und die Souveränität bei hochmodernen Halbleitern stärken will.

Die Stärkung der europäischen Halbleiterwertschöpfungskette – auch in Bereichen, die für KI von entscheidender Bedeutung sind – ist unerlässlich, um die strategischen Ziele der Union zu erreichen. Gleichzeitig müssen nach wie vor unbedingt die Produktionskapazitäten Europas für handelsübliche Halbleiter gestärkt werden. Ausgereifte und spezialisierte Technologieknoten sind für die europäischen Industrieökosysteme wie Automobilindustrie, Luftfahrt, Verteidigung, Telekommunikation und Cloud-Dienste, in denen die Nachfrage nach zuverlässigen, anwendungsspezifischen Chips weiter wächst, unverzichtbar. Die Stärkung der Resilienz in diesen Segmenten ist daher überaus wichtig, um die industrielle Basis Europas zu schützen und übermäßige Abhängigkeiten zu verringern. Ebenso wichtig ist es, die Chipentwurfsfähigkeiten in Europa zu verbessern und eine engere Zusammenarbeit zwischen Entwicklern, Herstellern und Endanwenderbranchen zu fördern, unter anderem durch Mitgestaltungskonzepte, mit denen sichergestellt wird, dass Halbleiterlösungen für industrielle und strategische Anwendungen optimiert werden.

    Aufbauend auf der Notwendigkeit, sowohl Angebot als auch Nachfrage im europäischen Halbleiterökosystem zu steigern, ist in der Chip-Verordnung 2.0 auch die Einführung strategischer Projekte zur Stärkung wichtiger Segmente der Halbleiterwertschöpfungskette der Union vorgesehen. Diese Projekte werden mithilfe einer koordinierten Mischung aus öffentlichen und privaten Investitionen priorisiert und unterstützt, die eine souveräne und fortgeschrittene Fertigung, den fortgeschrittenen Chipentwurf und die Resilienz der Lieferkette umfassen. Dieser Ansatz ergänzt die oben beschriebenen Maßnahmen, verbessert die grenzüberschreitende Integration entlang der gesamten Wertschöpfungskette und trägt zur Stärkung der strategischen Autonomie und technologischen Souveränität Europas bei.

    In diesem Zusammenhang und im Rahmen des Koordinierungsinstruments für Wettbewerbsfähigkeit (CCT) wird einem strategischen Projekt für fortgeschrittene Fertigung höchster Vorrang eingeräumt, um die Herstellung von KI-Chips und anderen Halbleitern zu unterstützen. Ziel der Initiative ist es, die die Errichtung der ersten Halbleiteranlage in der Union, in der die Herstellung von Spitzenknotenchips mit Chiplet-Integration und fortgeschrittenen 3D-Packaging-Fähigkeiten kombiniert wird. Die Pilotproduktion könnte für den Zeitraum 2030-2033 ins Auge gefasst werden.

Um die Resilienz des Ökosystems weiter zu erhöhen, wird der Anwendungsbereich der Bestimmungen für neuartige Initiativen präzisiert. Diese Bestimmungen gelten für die gesamte Halbleiterwertschöpfungskette, einschließlich auf die Fertigung ausgerichteter Chipentwurfstätigkeiten, Spezialwerkstoffe, Fertigungsausrüstung, Leiterplatten sowie fortgeschrittenes Packaging und Montage. Die Bewertung als neuartig erstreckt sich auch auf die nationale Kofinanzierung strategischer Projekte in Fällen, in denen strategische Projekte im Einklang mit den Wettbewerbsvorschriften ebenfalls als neuartige Projekte eingestuft werden.

In der Chip-Verordnung 2.0 wird eine raschere Industrialisierung von Pilotanlagen hervorgehoben, wodurch erfolgreiche Pilotfertigungsanlagen in kommerziell tragfähige Fertigungskapazitäten umgewandelt werden. Außerdem werden Photonik und photonisch integrierte Schaltungen in die verstärkte Initiative „Chips für Europa 2.0“ aufgenommen, da sie Schlüsseltechnologien für ein breites Spektrum strategischer Sektoren sind, darunter Telekommunikation, Rechenzentren, KI, Gesundheitswesen, Automobilindustrie und Quantentechnik. Die Initiative „Chips für Europa“ hat ihre entscheidende Rolle bei der Stärkung der Führungsposition der Union in der Halbleiterforschung, -innovation und -industrie unter Beweis gestellt. Daher ist es unerlässlich, sie fortzuführen. Durch die Unterstützung bewährter Instrumente wie der Pilotanlagen, des Netzes von Kompetenzzentren, der Entwurfsplattform und der Tätigkeiten im Bereich Quantenchips soll die Initiative „Chips für Europa 2.0“ dafür sorgen, dass Europa seinen Wettbewerbsvorteil behauptet, die Produktion im kommerziellen Maßstab beschleunigt und den Beitrag der Halbleitertechnik zu Nachhaltigkeit und technologischer Souveränität maximiert.

Darüber hinaus werden ergänzende nachfrageseitige Maßnahmen ergriffen, um die Markteinführung europäischer Technologien zu beschleunigen. Eine innovationsfördernde Auftragsvergabe und die Großen Herausforderungen werden dazu beitragen, frühzeitig Nachfrage zu erzeugen, Referenzanwendungen zu ermöglichen und eine schnellere Markteinführung der in der Union entwickelten fortgeschrittenen Chips zu erleichtern. Darüber hinaus kann bei der Vergabe öffentlicher Aufträge, die Halbleiter in Infrastrukturen, Ausrüstungen oder Systemen betreffen, neben Preiserwägungen auch ein Kriterium in Bezug auf die Versorgungssicherheit einbezogen werden, wenn solche Technik in wesentlichen Diensten oder kritischen Infrastrukturen zum Einsatz kommt. Durch die koordinierte Mobilisierung der öffentlichen Nachfrage werden diese Maßnahmen die angebotsseitigen Instrumente ergänzen, die Einführung sicherer Technologien in der gesamten Union fördern und die Sicherheit und Resilienz nachgelagerter strategischer Sektoren stärken. Im Einklang mit den Klima-, Umwelt- und Energiezielen der Union sollte der energieeffizienten und nachhaltigen Produktion und Verwendung von Chips Vorrang eingeräumt werden. Die Genehmigungsverfahren müssen ebenfalls gestrafft werden, um die industrielle Einführung zu beschleunigen und die internationale Wettbewerbsfähigkeit zu bewahren, und zwar insbesondere auf der Grundlage des Vorschlags der Kommission für eine Verordnung zur Beschleunigung von Umweltprüfungen. Parallel zur Durchführung des derzeitigen Chip-Gesetzes und im Vorgriff auf die Überarbeitung des derzeitigen Rechtsakts zur Cybersicherheit werden im Zuge einer Bewertung der Cybersicherheitsrisiken sowohl technische Schwachstellen als auch nicht technische Faktoren bewertet, die sich auf die Cybersicherheit von Halbleitern auswirken und die bei der Vergabe öffentlicher Aufträge für bestimmte kritische Sektoren verwendet werden.

Um Anreize für eine regionale Führungsposition in der Halbleiterwertschöpfungskette zu schaffen, wird mit diesem Vorschlag für Regionen, die einen soliden regionalen Plan für Investitionen in Halbleitertechnik haben, der auf die strategischen Prioritäten abgestimmt ist, ein Gütesiegel für europäische Halbleiterexzellenzregionen geschaffen. Dazu gehören der Ausbau der Halbleiterfertigung, der FuE-Zusammenarbeit, der Kompetenzentwicklung und nachhaltiger Infrastrukturen. Dies würde internationalen Investoren signalisieren, dass die Region über ein Ökosystem mit hohem Potenzial für das Halbleitergeschäft.

- Bessere Krisenvorsorge zur Gewährleistung der Versorgungssicherheit der EU

Trotz der im Rahmen der Säule III des ersten Chip-Gesetzes geschaffenen Überwachungs- und Krisenreaktionsinstrumente bestehen nach wie vor erhebliche Lücken bei der Fähigkeit der Union, Halbleiterversorgungskrisen wirksam zu bewältigen. Der EU fehlen nach wie vor ausreichend entwickelte Mechanismen, Instrumente und institutionelle Kapazitäten, um Störungen rechtzeitig und auf koordinierte Weise zu antizipieren und zu bewerten.

Um die Vorsorge in der Halbleiterlieferkette zu verbessern, wird die Kommission die Einrichtung einer Unternehmensplattform für die Halbleiterlieferkette (im Folgenden „Plattform“) unterstützen, über die Unternehmen wirtschaftlich nicht sensible Informationen in aggregierter Form austauschen können. Dies wird dazu beitragen, ein Modell für die digitale Lieferkette zu schaffen, die Sichtbarkeit struktureller gegenseitiger Abhängigkeiten zu erhöhen, eine systematische Risikoermittlung zu ermöglichen und die Widerstandsfähigkeit gegenüber Störungen zu steigern. Im Falle von Warnungen könnte die Kommission Informationen von einzelnen Unternehmen und von der Plattform anfordern. Diese Auskunftsersuchen müssen strikt auf das Notwendige beschränkt und verhältnismäßig sein. Unternehmen, die sich an der Plattform beteiligen, werden von der Pflicht zur Beantwortung von Auskunftsersuchen befreit. Parallel zur Chip-Verordnung 2.0 wird die Kommission bis zum zweiten Quartal 2027 einen EU-Konzeptentwurf für das Halbleiterkrisenmanagement entwickeln. Der Konzeptentwurf wird klare Verfahren, Rollen und Zuständigkeiten in den Vorkrisen- und Krisenphasen festlegen und auf der ersten Simulationsübung für Störungen der Halbleiterlieferkette aufbauen, die 2025 mit den Mitgliedstaaten durchgeführt wurde. Diese Bemühungen werden mit der Strategie für eine Union der Krisenvorsorge und dem dazugehörigen Aktionsplan im Einklang stehen.

#### • Kohärenz mit den bestehenden Vorschriften in diesem Bereich

Halbleiter sind entscheidende Voraussetzungen für den sauberen und den digitalen Wandel. Ihre strategische Bedeutung für die EU wird durch geopolitische Spannungen, derzeitige übermäßige Abhängigkeiten der Union bei der fortgeschrittenen Fertigung und beim fortgeschrittenen Entwurf und die zunehmende Instrumentalisierung dieser Abhängigkeiten als Waffe durch Drittländer weiter verstärkt. In diesem Zusammenhang ist die Chip-Verordnung 2.0 unerlässlich, um die politischen Prioritäten der Kommission zu verwirklichen, insbesondere im Rahmen von „Ein neuer Plan für nachhaltigen Wohlstand und nachhaltige Wettbewerbsfähigkeit in Europa“ und „Eine neue Ära für die europäische Verteidigung und Sicherheit“^(7).

Wie im Deal für eine saubere Industrie^(8), im Kompass für Wettbewerbsfähigkeit der EU^(9) und in der Gemeinsamen Mitteilung über die Stärkung der wirtschaftlichen Sicherheit der EU^(10) anerkannt wird, kann der Vorschlag für die Chip-Verordnung 2.0 als Reaktion auf die Notwendigkeit dringender Maßnahmen im Halbleiterbereich betrachtet werden, mit der die Zukunft der EU als Wirtschaftsmacht, Investitionsziel und Zentrum der Fertigungsindustrie gesichert werden soll.

Der Vorschlag steht im Einklang mit den allgemeinen Zielvorstellungen, Zielvorgaben und Wegen für einen erfolgreichen digitalen Wandel der EU bis 2030, die die Kommission in ihrer Mitteilung Der digitale Kompass 2030: der europäische Weg in die digitale Dekade („Mitteilung über den digitalen Kompass“)^(11) und dem anschließenden Beschluss der Kommission über das Politikprogramm für die digitale Dekade^(12) aufgezeigt hatte, wo die Halbleiter als ein eigenes Ziel aufgeführt wurden. Mit diesem Vorschlag soll die Union mit den Fähigkeiten ausgestattet werden, die sie benötigen wird, um dieses für 2030 gesetzte Ziel zu erreichen. Die Überprüfung des Politikprogramms für die digitale Dekade ist für Juni 2026 geplant^(13).

Dieser Vorschlag trägt zur Umsetzung der Erklärung der Halbleiterkoalition (Semicon Coalition) bei, die am 29. September 2025 von den jeweiligen Ministerinnen und Ministern der 27 Mitgliedstaaten unterzeichnet wurde und in der eine verstärkte und zukunftsorientierte Chip-Verordnung 2.0 gefordert wird, um die Position Europas in der globalen Halbleiterwertschöpfungskette zu festigen^(14).

Der Vorschlag teilt auch einige der Ziele der Verordnung zur industriellen Beschleunigung^(15), mit der ein Rahmen für Maßnahmen zur Stärkung der Wettbewerbsfähigkeit der EU, zur Beschleunigung der Dekarbonisierung der Industrie und zum Ausbau der strategischen Fertigungskapazitäten festgelegt wird.

Der Vorschlag steht weitgehend im Einklang mit EU-Initiativen, mit denen ähnliche Ziele verfolgt werden, insbesondere mit dem Programm Digitales Europa, dem Programm Horizont Europa, der Verordnung über kritische Rohstoffe^(16) sowie dem Europäischen Fonds für regionale Entwicklung, InvestEU und Erasmus+.

Von den oben genannten Initiativen steht der Vorschlag insbesondere im Einklang mit dem Programm Digitales Europa und dem Programm Horizont Europa, die im derzeitigen mehrjährigen Finanzrahmen als die beiden Finanzierungsgrundlagen der Säule I dienen. Das Programm Digitales Europa unterstützt digitale Infrastrukturen, während über Horizont Europa vorgelagerte Forschung, Pilotprojekte und Demonstration gefördert werden.

Darüber hinaus ergänzt der Vorschlag auch die Verordnung über kritische Rohstoffe, da mit beiden die strategische Autonomie in verschiedenen Segmenten der Wertschöpfungskette angestrebt wird: Der Schwerpunkt der Chip-Verordnung liegt auf dem Entwurf und der Fertigung von Halbleitern, während die Verordnung über kritische Rohstoffe auf die Versorgung mit kritischen Rohstoffen ausgerichtet ist.

Die Chip-Verordnung steht im Einklang mit den Bestrebungen der EU für strategische Autonomie, wirtschaftliche Sicherheit und Wettbewerbsfähigkeit. Sie steht im Einklang mit der Europäischen Strategie für wirtschaftliche Sicherheit^(17), Ausfuhrkontrollen für Güter mit doppeltem Verwendungszweck^(18), der Verordnung über drittstaatliche Subventionen^(19) und der Plattform für strategische Technologien für Europa (STEP)^(20). Zusammen verringern diese Instrumente strategische Abhängigkeiten, stärken die industriellen Kapazitäten und wirken Verzerrungen entgegen, die durch drittstaatliche Subventionen im Binnenmarkt verursacht werden.

Der Vorschlag steht im Einklang mit den europäischen Rechtsvorschriften zur Cybersicherheit. Bestimmte Kategorien von Chips fallen in den Anwendungsbereich der Cyberresilienzverordnung^(21), und die Investitionen im Rahmen der Chip-Verordnung werden darauf abzielen, deren Ziele zu fördern, indem auf der Stärke der europäischen Industrie im Marktsegment für sichere Chips aufgebaut wird. Der Vorschlag wird auch die vorgeschlagene Überarbeitung des derzeitigen Rechtsakts zur Cybersicherheit insofern ergänzen, als bei der öffentlichen Beschaffung von Halbleitern durch kritische Einrichtungen eine Dimension der Versorgungssicherheit hinzugefügt wird.

Im Aktionsplan für die europäische Automobilindustrie^(22) wurde die Bedeutung der Halbleiterindustrie für eine innovative und digitalisierte Automobilindustrie hervorgehoben.

Die Chip-Verordnung 2.0 ergänzt auch andere Initiativen wie die wichtigen Vorhaben von gemeinsamem europäischem Interesse (IPCEI). Hier steht die Vorbereitung des anstehenden IPCEI-Kandidaten für fortgeschrittene Halbleitertechnik (Advanced Semiconductor Technologies, AST)^(23) voll und ganz im Einklang mit dem Geist der neuen Chip-Verordnung, da es um die industrielle Ersteinführung bahnbrechender Innovationen geht.

Die Chip-Verordnung 2.0 ist so konzipiert, dass sie mit dem derzeitigen mehrjährigen Finanzrahmen (MFR) (2021-2027) und dem nächsten MFR (2028-2034), aber auch mit dem Europäischen Fonds für Wettbewerbsfähigkeit (ECF), dem 10. Rahmenprogramm (RP10) und den nationalen und regionalen Partnerschaftsplänen (NRPPs) vereinbar ist. Ihre Architektur wird ein sofortiges Handeln und eine sofortige Wirkung im Rahmen des derzeitigen MFR ermöglichen und gleichzeitig Kontinuität und Skalierbarkeit im Rahmen des nächsten MFR gewährleisten. Der Vorschlag greift dem Ergebnis des laufenden Gesetzgebungsverfahrens zum MFR nicht vor.

Darüber hinaus lässt die Chip-Verordnung 2.0 die Vorschriften über staatliche Beihilfen und die Wettbewerbsvorschriften, einschließlich des FEI-Rahmens und der IPCEI-Mitteilung, unberührt und wahrt deren unterschiedliche Ziele. IPCEIs und der FEI-Rahmen spielen eine zentrale Rolle bei der Unterstützung von Forschung, Entwicklung, Innovation und industrieller Ersteinführung, insbesondere für hochinnovative und grenzüberschreitende Projekte mit starken Ausstrahlungseffekten.

Die Maßnahmen im Rahmen der Chip-Verordnung 2.0 werden auf dieser Architektur aufbauen, indem der Anwendungsbereich des Rahmens für Neuartiges der Säule II weiter präzisiert und verfeinert wird, um sicherzustellen, dass die gesamte Wertschöpfungskette abgedeckt ist.

#### • Kohärenz mit der Politik der Union in anderen Bereichen

Der Vorschlag steht im Einklang mit der Wettbewerbs- und Industriestrategie der EU, wie sie in den Industriestrategien und im Draghi-Bericht zum Ausdruck kommt, und sie ergänzt den Rahmen für den digitalen und den sauberen Wandel.

Zusammen mit der Verordnung zur Cloud- und KI-Entwicklung (CADA) und einem Strategischen Fahrplan für Digitalisierung und KI im Energiebereich wird dieser Vorschlag Teil des Pakets zur technologischen Souveränität sein. Mit dem Paket soll sichergestellt werden, dass die Union weiterhin in der Lage ist, autonom zu entscheiden, wirksam zu handeln und globale technologische Entwicklungen zu gestalten, und dass sie gleichzeitig offen und wettbewerbsfähig bleibt und für internationale Zusammenarbeit und internationale Regeln eintritt.

Zwischen der Chip-Verordnung, dem vorgeschlagenen Europäischen Fonds für Wettbewerbsfähigkeit (ECF)^(24) und dem künftigen Rechtsakt über Quantentechnologie^(25) wird eine Koordinierung erforderlich sein. Die Kohärenz mit dem Rechtsakt über Quantentechnologie wird die Gelegenheit bieten, einen umfassenden europäischen Rahmen für die Quantenpolitik zu schaffen, der Synergien zwischen mehreren Instrumenten optimal nutzt.

### 2. RECHTSGRUNDLAGE, SUBSIDIARITÄT UND VERHÄLTNISMÄẞIGKEIT

#### • Rechtsgrundlage

Wie beim ersten Chip-Gesetz sind die Rechtsgrundlagen für die Chip-Verordnung 2.0 Artikel 173 Absatz 3 und Artikel 114 des Vertrags über die Arbeitsweise der Europäischen Union (AEUV). Die Union trägt mit ihrer Politik und ihren Maßnahmen zur Verwirklichung der Ziele des Artikels 173 Absatz 1 bei. Gemäß Artikel 173 Absatz 1 AEUV sorgen die Union und die Mitgliedstaaten dafür, dass die notwendigen Voraussetzungen für die Wettbewerbsfähigkeit der Industrie der Union gewährleistet sind. Entsprechend einem System offener und wettbewerbsorientierter Märkte zielt diese Tätigkeit auf Folgendes ab: i) Erleichterung der Anpassung der Industrie an die strukturellen Veränderungen, ii) Förderung eines für die Initiative und Weiterentwicklung der Unternehmen in der gesamten Union, insbesondere der kleinen und mittleren Unternehmen, günstigen Umfelds, iii) Förderung eines für die Zusammenarbeit zwischen Unternehmen günstigen Umfelds und iv) Förderung einer besseren Nutzung des industriellen Potenzials der Politik in den Bereichen Innovation, Forschung und technologische Entwicklung. Ziel des Artikels 114 AEUV ist die Errichtung und das Funktionieren des Binnenmarkts durch den Erlass von Maßnahmen zur Angleichung der nationalen Vorschriften.

Die Chip-Verordnung 2.0 baut auf den Zielen des aktuellen Chip-Gesetzes auf. Das erste spezifische Ziel der Chip-Verordnung 2.0, das Säule I zugrunde liegt, besteht darin, in der Halbleiterindustrie umfangreiche Innovationsfähigkeiten und angemessene technologische Fähigkeiten zur Beschleunigung von Innovationen und zur Anpassung daran zu schaffen. In Bezug auf die Säulen II und III zielt die Verordnung darauf ab, die Resilienz und Versorgungssicherheit der Union im Bereich der Halbleitertechnologien zu erhöhen, indem Investitionen in die fortgeschrittene Halbleiterherstellung unterstützt und koordiniert werden (Säule II) und eine koordinierte Überwachung und Krisenreaktion ermöglicht wird (Säule III).

Die geeignete Rechtsgrundlage für das erste Ziel ist Artikel 173 Absatz 3 AEUV. Im Falle von Artikel 173 Absatz 3 AEUV sollten die ergriffenen Maßnahmen nicht zur Harmonisierung der nationalen Rechts- und Verwaltungsvorschriften führen, sondern die Wettbewerbsfähigkeit und Resilienz der industriellen Basis für Halbleiter stärken. Die Chip-Verordnung 2.0 zielt darauf ab, die europäischen Halbleitertechnologie- und -industrielandschaft zu stärken und resilienter zu machen sowie das Innovationspotenzial des Halbleiterökosystems in der gesamten EU zu steigern. Dazu muss die Abhängigkeit von einer kleinen Zahl von Unternehmen und Regionen außerhalb der EU verringert und müssen die Fähigkeiten der EU für Entwurf und Herstellung fortgeschrittener Halbleiter ausgebaut werden. Die Initiative „Chips für Europa“ (Säule I), die durch die neuen Legislativmaßnahmen weiterhin unterstützt wird, soll dazu beitragen, diese Ziele zu erreichen, indem die Kluft zwischen der Forschungsexzellenz der EU und deren wirksamer, nachhaltiger Nutzung durch die Industrie geschlossen wird.

#### • Subsidiarität (bei nicht ausschließlicher Zuständigkeit)

Die Ziele des Vorschlags können von den Mitgliedstaaten nicht allein erreicht werden, da die Probleme grenzüberschreitender Natur sind und sich nicht auf einzelne Mitgliedstaaten oder eine Gruppe von Mitgliedstaaten beschränken. Die vorgeschlagenen Maßnahmen konzentrieren sich auf Bereiche, in denen aufgrund des Ausmaßes, der Geschwindigkeit und des Umfangs der erforderlichen Anstrengungen ein Tätigwerden auf Unionsebene nachweislich einen Mehrwert bietet.

Eine umfassende Reaktion auf die Halbleiterkrise erfordert ein rasches und koordiniertes gemeinsames Tätigwerden verschiedener Interessenträger in Zusammenarbeit mit den Mitgliedstaaten. Kein einzelner Mitgliedstaat kann dies allein erreichen. Darüber hinaus sind angesichts der Komplexität des Halbleiterökosystems die Folgen der strukturellen Abhängigkeiten und Versorgungsengpässe der Union so weitreichend, dass ein Tätigwerden der EU am besten geeignet ist, um diese Probleme anzugehen.

Ein Tätigwerden auf Unionsebene ist eindeutig am besten geeignet, um zu einer gemeinsamen Vision und Umsetzungsstrategie der europäischen Akteure beizutragen. Dies ist entscheidend, um Größen- und Verbundvorteile zu erzielen und die kritische Masse zu erreichen, die für Spitzenkapazitäten erforderlich ist. Dies wird auch eine Fragmentierung der Bemühungen, einen Subventionswettlauf und suboptimale nationale Lösungen begrenzen, wenn nicht gar vermeiden.

In den Bereichen, auf die sich dieser Vorschlag mit seinen drei Säulen bezieht, ist ein Tätigwerden der Union erforderlich.

- · Was die erste Säule (Initiative „Chips für Europa 2.0“) betrifft, so wird die verstärkte Initiative „Chips für Europa 2.0“ weiterhin die Tätigkeiten der im Rahmen des ersten Chip-Gesetzes eingerichteten Initiative „Chips für Europa“ unterstützen. Dies bedeutet den groß angelegten Aufbau technischer Kapazitäten und Innovationen in der gesamten Union, um die Entwicklung und Einführung hochmoderner Halbleiter- und Quantentechnik der nächsten Generation zu ermöglichen und die chronischen strukturellen Schwachstellen in Europa bei Entwurf und Produktion anzugehen. Nach zwei erfolgreichen wichtigen Vorhaben von gemeinsamem europäischem Interesse (IPCEIs) für Mikroelektronik, mit denen grenzüberschreitende innovative Projekte entlang der gesamten Mikroelektronikwertschöpfungskette unterstützt werden, wird derzeit ein mögliches drittes IPCEI in diesem Bereich konzipiert. Diese Initiativen sind von strategischer Bedeutung für den Sektor. Zum gegenwärtigen Zeitpunkt dürften sie jedoch nicht ausreichen, um für den Aufbau ausreichender Kapazitäten in Form von Pilotanlagen und Entwurfsinfrastrukturen zu sorgen, die allen interessierten Dritten in ganz Europa in großem Maßstab zur Verfügung gestellt werden müssen und die die Union in die Lage versetzen werden, eine größere Rolle im weltweiten verflochtenen Ökosystem zu spielen. Solche Großanlagen können aufgrund des Umfangs der erforderlichen Investitionen und des benötigten Know-hows nur auf Unionsebene bereitgestellt werden.

- · In Bezug auf die zweite Säule (Versorgungssicherheit und Nachfrage) können Maßnahmen zur Beschleunigung von Investitionen in die Halbleiterfertigung nur auf Unionsebene angemessen konzipiert und umgesetzt werden. Dies ist auf den Umfang der erforderlichen Investitionen zurückzuführen und darauf, dass diese Fertigungsanlagen definitionsgemäß den gesamten Binnenmarkt bedienen, das gesamte Ökosystem stärken und die Versorgungssicherheit in Krisen gewährleisten werden. Darüber hinaus würden Maßnahmen im Zuge strategischer Projekte entwickelt, indem eine Mischung aus öffentlichen und privaten Investitionen mit hoher privater Beteiligung gefördert wird.

- · Im Bereich der dritten Säule (Überwachung und Krisenreaktion) wird eine verstärkte Zusammenarbeit auf Unionsebene gewährleisten, dass die benötigten Informationen gesammelt werden und diese auch vergleichbar sind. Gemeinsam werden die Mitgliedstaaten und die Kommission in der Lage sein, Engpässe zu antizipieren, im Falle schwerwiegender Engpässe die Krisenstufe zu aktivieren und die erforderlichen Maßnahmen zu ergreifen, um eine solche Krise wirksamer zu bewältigen, als es bei einem Flickenteppich nationaler Maßnahmen der Fall wäre.

#### • Verhältnismäßigkeit

Der Vorschlag zielt darauf ab, das europäische Halbleiterökosystem durch i) kurzfristige Vorsorge- und Überwachungsmaßnahmen zur Erhöhung der Transparenz der Halbleiterlieferketten zu stärken, ii) mittelfristige Maßnahmen für die Versorgungssicherheit durch Verbesserung der Produktionskapazitäten für Halbleiter in Europa zu treffen und iii) längerfristige auf eine Führungsposition in den Bereichen Technologie und Innovation ausgerichtete Maßnahmen zur Schaffung von Entwurfs- und Produktionseinrichtungen für fortgeschrittene und neue Halbleitertechnologien zu ergreifen.

Vor diesem Hintergrund konzentriert sich der Vorschlag auf diejenigen Bestandteile des Halbleiterökosystems, die am stärksten zur Resilienz der Lieferkette der Union beitragen. Durch die Fokussierung ausschließlich auf das Halbleiterökosystem und nicht auf den größeren Bereich der Elektronikkomponenten und -systeme oder auf Anwendungsbereiche, in denen Halbleiter und/oder Elektronikkomponenten und -systeme zum Einsatz kommen, sollen die Maßnahmen auf eine der derzeit größten Schwachstellen der Wirtschaft und der Gesellschaft als Ganzes in Europa beschränkt werden.

Mit der Initiative „Chips für Europa 2.0“ werden die Mechanismen geschaffen, die erforderlich sind, um die längerfristige Wettbewerbs- und Innovationsfähigkeit der europäischen Industrie durch i) Forschungs- und Entwurfskapazitäten, ii) Test- und Versuchs-Pilotanlagen, iii) Kapazitäten für Quantenchips und photonisch integrierte Schaltungen, iv) Kompetenzzentren und v) einen Fonds für Start-ups, Scale-ups und KMU sicherzustellen.

Im Rahmen der Säule II, die auf die neue Versorgungssicherheit durch Verbesserung der Produktionskapazitäten der Union für Halbleiter abzielt, kann eine Anlage als europäische Halbleitertechnologieinitiative anerkannt werden. Auf der Grundlage dieser Anerkennung müssen die Mitgliedstaaten für beschleunigte Genehmigungsverfahren für diese Produktionsstätten und Fertigungsbetriebe sorgen.

Die neuen Vorsorgemaßnahmen der Säule III beruhen auf der Überwachung und dem Informationsaustausch zwischen den Mitgliedstaaten und der Union, um Störungen in der Lieferkette zu antizipieren. Bei (voraussichtlichen) Störungen können koordinierte Maßnahmen ergriffen werden, um Lieferengpässe bei Halbleitern und andere Störungen zu mindern oder zu verhindern.

#### • Wahl des Instruments

Eine Verordnung gilt als das am besten geeignete Instrument, da sie es ermöglicht, Anforderungen festzulegen, die unmittelbar für die nationalen Behörden und die betroffenen Wirtschaftsakteure gelten. Dies wird dazu beitragen, dass die Anforderungen zeitnah und einheitlich umgesetzt werden, was zu mehr Rechtssicherheit führt und die Kontinuität zum ersten Chip-Gesetz gewährleistet.

Bei dem vorgeschlagenen Rechtsakt handelt es sich um eine Verordnung des Europäischen Parlaments und des Rates. Dies ist das geeignetste Rechtsinstrument für Säule I des Vorschlags, mit der die Initiative „Chips für Europa 2.0“ ins Leben gerufen wird, denn nur eine Verordnung mit ihren unmittelbar geltenden Rechtsvorschriften kann das Maß an Einheitlichkeit bieten, das für die Fortsetzung und Durchführung einer Unionsinitiative zur Förderung einer Industriebranche im gesamten Binnenmarkt erforderlich ist. Die Wahl einer Verordnung als Rechtsinstrument für Säule II ist durch die Notwendigkeit einer einheitlichen Anwendung der neuen Vorschriften, insbesondere der Definition von „europäischen Halbleitertechnologieinitiativen“ und „strategischen Projekten“, sowie eines einheitlichen Verfahrens für deren Anerkennung und Förderung gerechtfertigt. Darüber hinaus stellt eine Verordnung das geeignetste Instrument für Säule III dar, da dieser Teil einen Mechanismus vorsieht, mit dem schwerwiegende Störungen der Halbleiterversorgung in der Union antizipiert und bewältigt werden sollen. Außerdem sollte der Mechanismus keine Umsetzung durch nationale Maßnahmen erfordern und wird unmittelbar anwendbar sein.

### 3. ERGEBNISSE DER EX-POST-BEWERTUNG, DER KONSULTATION DER INTERESSENTRÄGER UND DER FOLGENABSCHÄTZUNG

#### • Ex-post-Bewertung/Eignungsprüfungen bestehender Rechtsvorschriften

Gemäß Artikel 40 des derzeitigen Chip-Gesetzes legte die Kommission dem Europäischen Parlament und dem Rat zum 20. September 2026 einen ersten Bericht über die Evaluierung und Überprüfung der Verordnung vor. Zweck der Evaluierung war es, zu einem kritischen, unvoreingenommenen und evidenzbasierten Urteil über die Fortschritte des Chip-Gesetzes und seine Fähigkeit zur Stärkung des Halbleiterökosystems der Union zu kommen^(26).

Die Evaluierung erstreckte sich auf die drei Säulen des Chip-Gesetzes und säulenübergreifende Elemente. Sie betrachtete die Auswirkungen des Chip-Gesetzes auf die Wirtschaft, die Governance und soziale Faktoren und umfasste eine Folgenabschätzung zur Chip-Verordnung 2.0. Es wurden die Kosten und der Nutzen jeder Säule des Chip-Gesetzes ermittelt und quantifiziert. Ferner wurden die bei der Durchführung der Verordnung gewonnenen Erkenntnisse dargelegt und anhaltende und neu auftretende Probleme aufgezeigt, die sich auf die Funktionsweise der Verordnung auswirken. Die Evaluierung erstreckte sich auf den Zeitraum vom Inkrafttreten des Chip-Gesetzes am 21. September 2023 bis Ende November 2025.

Die Evaluierung ergab, dass das Chip-Gesetz unverzichtbar für die Schaffung eines europäischen Regulierungs- und Politikrahmens für Halbleiter war, der zuvor nicht bestand und innerhalb kürzester Zeit eingerichtet wurde. Mit dem Chip-Gesetz wurden erhebliche öffentliche und private Investitionen mobilisiert, modernste Infrastrukturen auf EU-Ebene eingerichtet und Governance-Mechanismen für die Koordinierung und Krisenvorsorge eingeführt. Das Vertrauen der Interessenträger in die allgemeine strategische Ausrichtung ist nach wie vor hoch, und das Gesetz wird weithin als notwendige Reaktion auf geopolitischen, technologischen und wirtschaftlichen Druck betrachtet.

Gleichzeitig ist der Übergang von einzelnen zu systemweiten Ergebnissen und Auswirkungen noch nicht abgeschlossen. Die Haupthindernisse sind eher struktureller und wirtschaftlicher als operativer Natur. Sie stehen im Zusammenhang mit der Fähigkeit der Union, Innovationen in der Industrie umzusetzen, Scale-ups zu finanzieren, die Lieferkettenresilienz zu stärken und Erkenntnisse auf Systemebene zu gewinnen.

Das Chip-Gesetz hat entscheidend zum Aufbau von Technologieinfrastrukturen und Kapazitäten für die Frühphasenfertigung beigetragen. Die Einrichtung von Pilotanlagen, Kompetenzzentren und gemeinsamen Infrastrukturen auf EU-Ebene hat ein koordiniertes Vorgehen ermöglicht. Diese Initiativen verbessern bereits den Zugang zu fortgeschrittenen Instrumenten und unterstützen eine starke grenzüberschreitende Zusammenarbeit. Die Auswirkungen anderer Komponenten (d. h. Quantenchip-Pilotprojekte und die Entwurfsplattform) werden erst zu einem späteren Zeitpunkt sichtbar werden. In jedem Fall erkennen zahlreiche Interessenträger den Beitrag des Chip-Gesetzes zur Stärkung der europäischen FuI-Basis und zur Verbesserung der Koordinierung zwischen den Mitgliedstaaten an.

Im Gegensatz dazu befinden sich die Fortschritte beim Ausbau der Fertigung und die daraus resultierende größere strategische Autonomie noch in einem frühen Stadium, was zum Teil auf lange Vorlaufzeiten zwischen Investitionsentscheidungen und der tatsächlichen Produktion in den Fertigungsstätten zurückzuführen ist. Europa ist in kritischen Segmenten, insbesondere an fortgeschrittenen Technologieknoten, nach wie vor strukturell von Anbietern aus Drittländern abhängig. Die Abwanderung oder Verzögerung größerer Investitionsprojekte zeigt auch, dass sich die Souveränität noch nicht wesentlich verbessert hat.

Bei allen Bewertungskriterien stellt die Kluft zwischen Labor und Fertigung eine große Herausforderung dar. Mit dem Chip-Gesetz ist es bereits gelungen, Technologien auf einen höheren Reifegrad anzuheben, und angesichts seines kürzlichen Inkrafttretens dürften sich in den kommenden Jahren stabile Wege zur Massenfertigung entwickeln. Zahlreiche Ergebnisse sind auf technischer Ebene wirksam und werden die industriellen Kapazitäten schaffen, die erforderlich sind, um dann später die Versorgung Europas zu sichern. Die Herausforderung, vor der die EU steht, ist nicht mehr in erster Linie die Innovationsentwicklung, sondern die Industrialisierung und Skalierung.

Die Bewertung ergab ferner, dass begrenztes privates Kapital die Expansion europäischer Halbleiterunternehmen nach wie vor einschränkt. Mit dem Chip-Gesetz wurden zwar öffentliche Mittel in beispiellosem Umfang mobilisiert, aber private Investitionen (insbesondere in der Spätphase sowie institutionelle Investitionen) sind im Vergleich zu konkurrierenden Regionen nach wie vor unzureichend. Die Unterstützung von Scale-ups wird durch strukturelle Merkmale des europäischen Finanzsystems eingeschränkt, darunter das Fehlen einer echten Kapitalmarktunion, bestehende Vorschriften für Pensionsfonds und konservative Anlagepraktiken. Dies schwächt die europäische Wertschöpfung und schafft Anreize für Scale-ups, den Standort des Unternehmens zu wechseln oder es an Nicht-EU-Unternehmen zu verkaufen. Das Chip-Gesetz hat die Innovationskapazität in der Frühphase verbessert, aber die dem (EIC-Accelerator-Teil des) Chip-Fonds zugewiesenen Mittel wurden in den ersten beiden Jahren aufgebraucht und haben sich als unzureichend erwiesen. Gebraucht werden thematische Instrumente mit geduldigem Kapital, um Start-ups im Halbleiterbereich bei ihrer Expansion zu unterstützen, und es müssen umfassendere Maßnahmen konzipiert werden, um die Voraussetzungen für die Entstehung von Technologieunternehmen mit hohem Potenzial zu schaffen.

Darüber hinaus ergab die Bewertung, dass die derzeitigen Instrumente zur Bewältigung von Schwachstellen im Hinblick auf die Versorgungssicherheit und die wirtschaftliche Sicherheit auf EU-Ebene nützlich sind, aber weiter gestärkt werden sollten. Einerseits wird der Ausbau der Fertigung in erster Linie von Investitionsentscheidungen der Industrie bestimmt, die durch nationale Finanzierungsrahmen unterstützt werden. Schwächen auf der Nachfrageseite untergraben die Resilienz weiter. Andererseits beeinträchtigen fragmentierte Märkte, geringe Produktionsmengen in Schlüsselsektoren und eine begrenzte Koordinierung der Beschaffung die wirtschaftliche Lebensfähigkeit der europäischen Produktion. Ohne Nachfragebündelung und zuverlässige Marktsignale besteht die Gefahr, dass neue Kapazitäten nicht ausreichend genutzt werden.

Die Bewertung kam zu dem Schluss, dass die Einblicke der EU in die Halbleiterlieferketten der EU und weltweit zu begrenzt sind, um eine starke Krisenvorsorge zu unterstützen. Das ESB hat die Koordinierung erheblich verbessert, und es wurden Frühwarnmechanismen eingerichtet. Es sollte jedoch ein stärker integrierter Ansatz für die Überwachung von Werkstoffen, Ausrüstung, Entwurfswerkzeugen und nachgeschalteten Anwendern in Betracht gezogen werden. Die Datenerhebung ist nach wie vor fragmentiert und empfindlich, was die Fähigkeit einschränkt, Störungen vorherzusehen. Die Säule III lässt daher eine Betrachtung auf Systemebene nur teilweise zu.

Insgesamt hat das Chip-Gesetz sein ursprüngliches Ziel, europäische Kapazitäten aufzubauen, rasch und glaubwürdig erreicht. Die Wirksamkeit in Bezug auf Autonomie und Resilienz hängt jedoch davon ab, ob Europa Infrastrukturen nun in industrielle Produktion umwandeln, Innovationen skalieren und durch Koordinierung gewonnene umsetzbare Erkenntnisse erzielen kann.

#### • Konsultation der Interessenträger

Im Einklang mit den Leitlinien für eine bessere Rechtsetzung nahm die Kommission eine umfassende Konsultation der Interessenträger vor, um mithilfe einer Reihe von Methoden, konsultierten Parteien und Instrumenten zuverlässige Informationen zu sammeln.

Die Kommission führte mehrere Tätigkeiten durch: eine öffentliche Konsultation zwischen dem 5. September 2025 und dem 28. November 2025 (105 Beiträge und 39 Positionspapiere wurden eingereicht); eine Aufforderung zur Stellungnahme für die Folgenabschätzung (209 Beiträge und 85 Positionspapiere wurden eingereicht); eine gezielte Umfrage unter Interessenträgern (64 Beiträge); Befragungen (mit Befragten, die ein breites, strategisch ausgewähltes Spektrum von Organisationen vertreten und am europäischen Halbleiterökosystem beteiligt bzw. davon betroffen sind); 16 thematische Workshops, die zwischen September und Dezember 2025 unter Beteiligung verschiedener Interessenträger aus dem gesamten europäischen Halbleiterökosystem durchgeführt wurden; sechs Workshops mit den Mitgliedstaaten, die zwischen Januar und März 2026 durchgeführt wurden.

Die Interessenträger wiesen auf eine übermäßige Abhängigkeit von Lieferanten aus Drittländern hin, insbesondere bei Hochleistungschips. Zu den größten Hindernissen für die Entwicklung einer KI-Chip-Wertschöpfungskette in der EU gehören unzureichende Fertigungskapazitäten, begrenzte Investitionsinstrumente, der Mangel an qualifizierten Arbeitskräften und die schwache Inlandsnachfrage von Hyperscalern und KI-Unternehmen. Strukturelle Kostennachteile wurden auch in der gesamten Wertschöpfungskette festgestellt: Fabriken mit Sitz in der EU sind im Vergleich zu Wettbewerbern in Ostasien mit höheren Bau- und Betriebskosten, längeren Fristen für Genehmigungen, Bau und Inbetriebnahme sowie geringeren Agglomerationseffekten konfrontiert.

Finanzierungsengpässe verschärfen diese Herausforderungen weiter. Ein Mangel an Risikokapital und Risikofinanzierung wurde als großes Hindernis für Chipentwurfsunternehmen ermittelt, gleichzeitig wiesen integrierte Gerätehersteller und andere produktionsorientierte Unternehmen auf langwierige Genehmigungsverfahren und hohe Energiekosten als erhebliche Hindernisse hin. Darüber hinaus bestehen nach wie vor systemische Hindernisse in Form von Finanzierungslücken in der Spätphase, fragmentierter Governance und Abhängigkeit von Fertigungsbetrieben außerhalb der EU, die Unternehmen daran hindern, Prototypen zu kommerziellen Produkten zu skalieren – ein Problem, das durch die öffentliche Konsultation bestätigt wurde.

Beim Fachkräftemangel handelt es sich den Interessenträgern zufolge um ein bereichsübergreifendes Problem. Es wurde betont, dass Pipelines für Halbleiterkompetenzen jahrzehntelange Investitionshorizonte erfordern, viele einschlägige Programme jedoch mit kürzeren Haushaltszyklen arbeiten, wodurch ihre längerfristigen Auswirkungen begrenzt werden. Die Interessenträger wiesen auch darauf hin, dass die Koordinierung zwischen der EU und den nationalen Ebenen verbessert werden könnte.

Die Ergebnisse der öffentlichen Konsultation sind im zusammenfassenden Bericht enthalten, der mit den Antworten auf die Aufforderung zur Stellungnahme auf dem Portal „Ihre Meinung zählt“ veröffentlicht wurde.

#### • Folgenabschätzung

Im Einklang mit den Leitlinien für eine bessere Rechtsetzung stützt sich dieser Legislativvorschlag auf eine Folgenabschätzung, in der das Problem und die Teilprobleme im Zusammenhang mit der Notwendigkeit analysiert werden, die Wettbewerbsfähigkeit der Halbleiterökosysteme der EU zu stärken. In der Folgenabschätzung werden mögliche Politikoptionen zur Bewältigung der Problemursachen ermittelt und ihre voraussichtlichen Auswirkungen bewertet. Die Folgenabschätzung wurde so strukturiert, dass sie die Konsultation der dienststellenübergreifenden Lenkungsgruppe der Kommission zur Chip-Verordnung 2.0 widerspiegelt.

Der Ausschuss für Regulierungskontrolle gab am 28. Januar 2026 eine ablehnende Stellungnahme zur Folgenabschätzung ab. Der Ausschuss empfahl Folgendes:

- · Weiterentwicklung der Problemanalyse, einschließlich einer umfassenderen Bewertung der gegenwärtigen und der erforderlichen Fähigkeiten und Produktionskapazitäten der EU über kritische Elemente der Halbleiterwertschöpfungskette hinweg, sowohl für ausgereifte als auch für modernste Chips;

- · Präzisierung und bessere Definition der Ziele, insbesondere in Bezug auf Grad und Umfang der angestrebten technologischen Souveränität für verschiedene Arten von Chips;

- · Stärkung der Interventionslogik, indem klar aufgezeigt wird, in welchem Verhältnis verschiedene Maßnahmen zueinander stehen, einschließlich angebots- und nachfrageseitiger Instrumente, und wie diese gemeinsam dazu beitragen, das gewünschte Maß an Souveränität zu erreichen;

- · genauere Festlegung der vorgeschlagenen Maßnahmen, damit ihre Auswirkungen angemessen bewertet werden können, einschließlich klarerer Informationen über die Gesamtkosten der Intervention, deren Verteilung und die Risiken im Zusammenhang mit potenziellen Ineffizienzen bei der Mittelzuweisung; und

- · Verbesserung der Transparenz in Bezug auf die Unsicherheiten im Zusammenhang mit dem nächsten MFR und Vorlage einer gründlicheren Analyse der Kohärenz der Maßnahmen mit bestehenden und künftigen politischen Initiativen.

Auf alle obigen Punkte wurde so umfassend wie möglich eingegangen. Nachdem die überarbeitete Folgenabschätzung erneut vorgelegt wurde, gab der Ausschuss am 30. März 2026 eine befürwortende Stellungnahme mit Vorbehalten ab. Die Vorbehalte des Ausschusses betrafen folgende Aspekte:

- · Die Maßnahme zur Schaffung von Anreizen für vertrauenswürdige Chips ist nicht ausführlich genug beschrieben, um ihre Auswirkungen angemessen bewerten zu können;

- · in dem Bericht wird die Kohärenz mit bestehenden und künftigen politischen Initiativen und Instrumenten nicht ausreichend analysiert und nicht klar erläutert, wie das Zusammenspiel zwischen angebots- und nachfrageseitigen Maßnahmen Synergien gewährleisten wird;

- · die Analyse des Risikos einer ineffizienten Ressourcenzuweisung ist nicht ausreichend dargelegt.

Die Stellungnahmen des Ausschusses sowie die endgültige Folgenabschätzung und ihre Zusammenfassung werden zusammen mit diesem Vorschlag veröffentlicht.

Die Folgenabschätzung stützt sich auf drei spezifische Ziele, mit denen die ermittelten Problemursachen beseitigt werden sollen. Für jedes spezifische Ziel werden drei Politikoptionen auf der Grundlage der Ebene des politischen Eingreifens, des Umfangs, der Effizienz und Kohärenz sowie des Grundsatzes der Verhältnismäßigkeit und des Subsidiaritätsprinzips dargelegt.

Bei der Politikoption 0 (PO0) würde das derzeitige Chip-Gesetz ohne Änderungen weiter angewandt. Das bestehende FEI-Programm im Rahmen der Säule I und derselbe Ansatz für die Förderung von Investitionen durch staatliche Beihilfen würde beibehalten (unter Verwendung des Rahmens für Neuartiges gemäß den geltenden Vorschriften für staatliche Beihilfen). Es gäbe keine zusätzlichen Haushaltsmittel der Union für Säule II. Im Rahmen der Säule III würde der derzeitige Krisenreaktionsmechanismus beibehalten, der sich (außer in einer Krise) auf ein System der freiwilligen Datenerhebung aus dem Privatsektor stützt. Diese Politikoption würde keine politischen Maßnahmen über den Anwendungsbereich des derzeit geltenden Chip-Gesetzes hinaus beinhalten.

Bei der Politikoption 1 (PO1) – dem horizontalen („marktfördernden“) politischen Ansatz – würde der Schwerpunkt auf der Verbesserung der allgemeinen Rahmenbedingungen liegen. Dies würde eine verstärkte Unterstützung von Forschung, Entwicklung und Innovation, Investitionen in Kompetenzen und die Schaffung eines günstigen Investitionsumfelds umfassen. Für die Massenfertigung und den Entwurf, insbesondere für KI-Chips, würde keine zusätzliche Finanzierung auf Unionsebene eingeführt. Bei diesem Ansatz wäre die EU langfristig darauf angewiesen, Anbieter aus Drittländern, die in der Lage sind, modernste Chips herzustellen, und globale Chipentwurfsunternehmen anzuziehen.

Die Politikoption 2 (PO2) – der vertikale („proaktive“) industriepolitische Ansatz – würde auf den horizontalen Maßnahmen aufbauen, diese jedoch durch gezielte finanzielle Interventionen ergänzen, insbesondere durch strategische Projekte, die im Rahmen des vorgeschlagenen Europäischen Fonds für Wettbewerbsfähigkeit gefördert werden können. Dieser Ansatz baut auf europäischen Technologieressourcen auf, die im Rahmen des ersten Chip-Gesetzes geschaffen wurden, insbesondere Pilotanlagen, und setzt dies durch industrielle Einführung um. Durch die Schaffung einer klaren auf EU-Ebene angesiedelten Dimension für die Finanzierung von Industrieprojekten und die Ermöglichung grenzüberschreitender Investitionen in der gesamten Wertschöpfungskette würde dieser Ansatz darauf abzielen, die Fragmentierung zu verringern und gleichzeitig die Wettbewerbsfähigkeit, Resilienz und technologische Souveränität Europas zu stärken. Der Mehrwert bestünde in dem Bestreben, so „Made in Europe“-Technologien zu schaffen.

Insgesamt wird PO2 bevorzugt, da sie die wirksamste und verhältnismäßigste Antwort auf die festgestellten Probleme bietet, gleichzeitig die Subsidiarität wahrt und den Verwaltungsaufwand minimiert. Mit ihr wird auf die Ergebnisse der Bewertung reagiert, in der eine stärkere Integration von FuI- und industriellen Einführungstätigkeiten, Wege einer rascheren Industrialisierung und wirksamere Mechanismen zur Gewinnung von Erkenntnissen zu Lieferketten gefordert werden.

#### • Effizienz der Rechtsetzung und Vereinfachung

Die bevorzugte Politikoption (PO2) führt zu einer Vereinfachung, indem ein koordinierter Rahmen für strategische Projekte auf EU-Ebene eingeführt wird. Eine einzige Projektpipeline für groß angelegte Halbleiterinvestitionen verhindert die Duplizierung von Verwaltungsschritten und sich wiederholende Dokumentationspflichten. Durch die Präzisierung des Anwendungsbereichs der „Neuartigkeit“ werden neuartige Verfahren sowohl für die Mitgliedstaaten als auch für die Unternehmen weiter vereinfacht. Darüber hinaus wird das Konzept eines Konsortiums für eine europäische Chip-Infrastruktur im Rahmen der Chip-Verordnung 2.0 aus Gründen der Vereinfachung gestrichen, da es nach dem derzeit geltenden Gesetz nie verwendet wurde. Ein weiterer Effizienzgewinn ergibt sich aus schnelleren und berechenbareren Genehmigungsverfahren. Die Genehmigungs- und Entwurfsphasen für fortgeschrittene Halbleiteranlagen in der EU sind im Durchschnitt 7,5 Monate länger als in wichtigen konkurrierenden Rechtsordnungen. Unter der Annahme, dass die Gesamtkosten in jedem Jahr der Verzögerung um rund 5 % wachsen, bedeutet dies zusätzliche Kosten in Höhe von rund 3,125 % der Gesamtinvestition. Dies entspräche beispielsweise rund 625 Mio. EUR für eine fortgeschrittene Fertigungsanlage im Wert von 20 Mrd. EUR. Durch die Verringerung des wiederholten Austauschs mit den Behörden und die Klärung der Genehmigungspfade führt PO2 zu erheblichen impliziten Kosteneinsparungen, die die mit der Einhaltung der Vorschriften verbundenen Kosten überwiegen. Ein weiterer Vorteil der Vereinfachung besteht darin, dass krisenbedingte Ad-hoc-Auskunftsersuchen durch eine strukturierte Unternehmensplattform für die Halbleiterlieferkette ersetzt werden. Dies verringert Doppelarbeit und verbessert die Koordinierung zwischen den Mitgliedstaaten.

Im Rahmen des „One-in-one-out“-Ansatzes verursacht PO2 einen begrenzten zusätzlichen Verwaltungsaufwand, der weitgehend durch strukturelle Vereinfachungen ausgeglichen wird. Neu hinzugefügte Elemente für Unternehmen bestehen in erster Linie in der Offenlegung von Schwachstellen in der Lieferkette. Der diesbezügliche Aufwand wird auf bis zu 10 Personentage pro Antrag geschätzt, was etwa 2 783 EUR pro Großunternehmen ausmacht und Gesamtkosten von bis zu 1,34 Mio. EUR pro Antrag bei einem umfassenden Szenario ergibt. Diese Mehrbelastung wird durch gestrichene Elemente in Form von weniger dringenden und sich überschneidenden Datenabrufen bei Krisen, einem gestrafften Informationsaustausch und einem geringeren internen Überwachungsaufwand aufgrund der teilweisen Auslagerung von Marktforschungstätigkeiten an die Plattform ausgeglichen. Für die Unternehmen bedeutet dies einen Netto-Verwaltungsaufwand, der darin besteht, mit der Beteiligung an der Plattform zu beginnen und Schwachstellen offenzulegen. Dies wird jedoch weitgehend durch die Versorgungssicherheit ausgeglichen, die dieser Datenaustausch mit sich bringen wird. Darüber hinaus werden in der ersten Phase Bewertungen lediglich auf qualitativer Grundlage vorgenommen, es sei denn, es liegt eine offizielle Krise vor.

#### • Grundrechte

Artikel 16 der Charta der Grundrechte der Europäischen Union (im Folgenden „Charta“) sieht die Anerkennung der unternehmerischen Freiheit vor. Die Maßnahmen im Rahmen der Säulen I und II dieses Vorschlags schaffen Innovationskapazitäten und fördern die Sicherheit der Versorgung mit Halbleitern, wodurch die unternehmerische Freiheit im Einklang mit dem Unionsrecht und den nationalen Rechtsvorschriften und Gepflogenheiten gestärkt werden kann. Allerdings können einige Maßnahmen im Rahmen der Säule III, die erforderlich sind, um der Tatsache Rechnung zu tragen, dass schwerwiegende Störungen der Halbleiterversorgung in der Union die unternehmerische Freiheit und die Vertragsfreiheit, die durch Artikel 16 der Charta geschützt sind, sowie das Eigentumsrecht, das durch Artikel 17 der Charta geschützt ist, vorübergehend einschränken können. Jede Einschränkung jener Rechte durch diesen Vorschlag wird gemäß Artikel 52 Absatz 1 der Charta gesetzlich geregelt sein und den Wesensgehalt jener Rechte und Freiheiten achten sowie den Grundsatz der Verhältnismäßigkeit wahren.

Die Verpflichtung, der Kommission bestimmte Informationen offenzulegen, sofern bestimmte Bedingungen erfüllt sind, achtet den Wesensgehalt der unternehmerischen Freiheit und beeinträchtigt diese nicht unverhältnismäßig (Artikel 16 der Charta). Alle Auskunftsersuchen entsprechen der dem Gemeinwohl dienenden Zielsetzung der Union, mögliche Maßnahmen zur Eindämmung einer Krise infolge von Lieferengpässen bei Halbleitern zu ermitteln. Solche Auskunftsersuchen sind geeignet und wirksam, um dieses Ziel zu erreichen, weil damit die für die Bewertung der derzeitigen Krise erforderlichen Informationen eingeholt werden. Die Kommission fordert grundsätzlich Informationen nur von den Vertretungsorganisationen an und kann lediglich dann zusätzlich Anfragen an einzelne Unternehmen richten, wenn dies erforderlich ist. Angesichts der schwerwiegenden wirtschaftlichen und gesellschaftlichen Folgen von Halbleiterknappheit und der entsprechenden Bedeutung von Abhilfemaßnahmen sind Auskunftsersuchen im Hinblick auf das angestrebte Ziel verhältnismäßig. Darüber hinaus werden die Beschränkungen der unternehmerischen Freiheit und des Eigentumsrechts angemessene Garantien vorgesehen. Ein Auskunftsersuchen kann nur in einer Krisensituation gestellt werden, in der die Kommission mit einem Durchführungsrechtsakt die Krisenstufe aktiviert hat.

Die Verpflichtung zur Annahme und Priorisierung vorrangiger Aufträge achtet den Wesensgehalt der unternehmerischen Freiheit und der Vertragsfreiheit (Artikel 16 der Charta) sowie des Eigentumsrechts (Artikel 17 der Charta) und wahrt den Grundsatz der Verhältnismäßigkeit. Diese Verpflichtung entspricht der dem Gemeinwohl dienenden Zielsetzung der Union, zu gewährleisten, dass kritische Sektoren, die infolge der Halbleiterknappheit von Lieferstörungen betroffen sind, den Betrieb aufrechterhalten. Die Verpflichtung ist angemessen und wirksam, um dieses Ziel zu erreichen, weil damit sichergestellt wird, dass die verfügbaren Ressourcen vorrangig für die an diese Sektoren gelieferten Erzeugnisse eingesetzt werden. Keine andere Maßnahme ist so wirksam. In einer Krisensituation ist es verhältnismäßig, bestimmte Unternehmen zu verpflichten, bestimmte Aufträge anzunehmen und vorrangig zu behandeln. Zu diesen Unternehmen gehören Halbleiterfertigungsanlagen, die die Anerkennung als „europäische Halbleitertechnologieinitiativen“ beantragt haben, andere Halbleiterfertigungsanlagen, die eine solche Möglichkeit als Gegenleistung für den Erhalt öffentlicher Unterstützung akzeptiert haben, oder Unternehmen entlang der Halbleiterlieferkette, die einem vorrangigen Auftrag aus einem Drittland unterliegen, soweit die Versorgungssicherheit in kritischen Sektoren beeinträchtigt ist. Angemessene Garantien stellen sicher, dass etwaige negative Auswirkungen der Priorisierungspflicht auf das Recht auf unternehmerische Freiheit, die Vertragsfreiheit und das Eigentumsrecht nicht auf eine Verletzung dieser Rechte hinauslaufen. Eine Verpflichtung zur vorrangigen Behandlung bestimmter Aufträge kann nur in einer Krisensituation auferlegt werden, in der die Kommission mit einem Durchführungsrechtsakt die Krisenstufe aktiviert hat. Das betreffende Unternehmen kann die Kommission ersuchen, den vorrangigen Auftrag zu überprüfen, wenn es den Auftrag nicht ausführen kann oder wenn die Ausführung des Auftrags eine unzumutbare wirtschaftliche Belastung darstellen und eine besondere Härte mit sich bringen würde. Darüber hinaus ist das der Verpflichtung unterliegende Unternehmen von jeglicher Haftung für Schäden befreit, die wegen der Verletzung vertraglicher Verpflichtungen aufgrund der Erfüllung der Verpflichtung entstehen.

### 4. AUSWIRKUNGEN AUF DEN HAUSHALT

Haushaltsauswirkungen ergeben sich aus der Personalausstattung der Kommissionsdienststellen und der Unterstützung bei der Einrichtung einer Unternehmensplattform für die Halbleiterlieferkette. Der Vorschlag erfordert personelle Ressourcen für die im Vorschlag vorgesehenen Aufgaben, für die die Kommission zuständig wäre. Einige der Aufgaben können erfüllt werden, indem vorhandenes Personal, das derzeit mit ähnlichen Aufgaben befasst ist, z. B. im Zusammenhang mit der Programmüberwachung, dem Aufbau von Kontakten mit Interessenträgern und der Berichterstattung über Tätigkeiten im Bereich Forschung und Entwicklung und Kapazitätsaufbau im Rahmen der Säule I, umgeschichtet wird. Für andere Aufgaben wird zusätzliches Personal benötigt, z. B. für die Überwachung strategischer Projekte, einschließlich Überwachung von Etappenzielen und Ergebnissen, Konformitätsprüfungen (staatliche Beihilfen, Vergabe öffentlicher Aufträge), grenzübergreifende Koordinierung mit den Mitgliedstaaten, administrative (nicht fiskalische) Aufsicht und Berichterstattung an den Rat/das Parlament. Darüber hinaus beinhaltet der Vorschlag zusätzliche Aufgaben im Zusammenhang mit der Unternehmensplattform für die Halbleiterlieferkette, z. B. die Überwachung der Halbleiterlieferketten, Analyse- und Krisenvorsorgefunktionen, die Bearbeitung von Auskunftsersuchen (RFIs) und die Überprüfung und Aggregation von Daten in der Vorkrisenphase sowie die sektorenübergreifende Koordinierung mit Interessenträgern aus der Industrie.

Die Unterstützung für die Einrichtung und den Betrieb einer Unternehmensplattform für die Halbleiterlieferkette erfordert operative Ausgaben in Höhe von 70 Mio. EUR. Die Kommission würde die Plattform unterstützen.

Weitere Einzelheiten zu den Auswirkungen auf den Haushalt enthält der diesem Vorschlag beiliegende Finanz- und Digitalbogen zu Rechtsakten.

Zusätzlich zu den oben genannten Auswirkungen auf den Haushalt können operative und administrative Mittel für die Umsetzung der Initiative „Chips für Europa 2.0“ und strategischer Projekte im MFR 2028-2034 erst zu einem späteren Zeitpunkt beantragt werden.

### 5. SONSTIGE ASPEKTE

#### • Durchführungspläne sowie Überwachungs-, Bewertungs- und Berichterstattungsmodalitäten

Die Kommission wird für die regelmäßige Überwachung der Durchführung der Maßnahme zuständig sein. Dies kann durch externe Studien sowie Daten der Mitgliedstaaten und Marktdaten unterstützt werden. Die Kommission wird eine umfassende Bewertung der Wirksamkeit, Effizienz, Kohärenz, Verhältnismäßigkeit und Subsidiarität der Chip-Verordnung 2.0 durchführen. Innerhalb von vier bis fünf Jahren nach Geltungsbeginn der Verordnung wird dem Europäischen Parlament, dem Rat, dem Europäischen Wirtschafts- und Sozialausschuss und dem Ausschuss der Regionen ein Bewertungsbericht mit den wichtigsten Ergebnissen vorgelegt. Diesem Bericht kann die Kommission gegebenenfalls Vorschläge zur Verbesserung oder Anpassung der Chip-Verordnung 2.0 beifügen.

Dieser Überprüfungsmechanismus folgt dem Ansatz, der im Rahmen des ersten Chip-Gesetzes festgelegt wurde. Er gewährleistet Kontinuität, Vergleichbarkeit der Ergebnisse und eine langfristige Perspektive der politischen Ergebnisse. Die Kommission wird in enger Zusammenarbeit mit den Mitgliedstaaten die Umsetzung und Anwendung der Rechtsvorschriften regelmäßig überwachen und dabei besonders auf die Wirksamkeit der erlassenen Maßnahmen achten. Die Überwachungstätigkeiten werden sich auf quantitative und qualitative Indikatoren auf der Grundlage von Daten stützen, die von Interessenträgern der gesamten Halbleiterwertschöpfungskette, den Mitgliedstaaten und den einschlägigen EU-Einrichtungen bereitgestellt werden. Der Gesamterfolg der Initiative wird anhand von Belegen für eine verbesserte Versorgungssicherheit bewertet. Dazu gehören Fortschritte im Hinblick auf einschlägige messbare Aspekte wie den Anteil der EU an der weltweiten Halbleiterproduktion und Veränderungen bei der Marktkonzentration. Die Durchführung der Chip-Verordnung 2.0 und ihrer flankierenden Maßnahmen wird es ermöglichen, die spezifischen Ziele, den erwarteten Nutzen und die damit verbundenen Auswirkungen systematisch zu verfolgen.

Zur Durchführung der Bewertung stellen die Mitgliedstaaten und die zuständigen nationalen Behörden der Kommission auf deren Ersuchen erforderliche, sachdienliche Informationen zur Verfügung.

#### • Ausführliche Erläuterung einzelner Bestimmungen des Vorschlags

1.1. Kapitel I – Allgemeine Bestimmungen

In Kapitel I wird der Gegenstand der Verordnung dargelegt. Darüber hinaus enthält es die Begriffsbestimmungen, die in diesem Rechtsinstrument durchweg verwendet werden. Mit der Verordnung wird die Initiative „Chips für Europa“ (jetzt Initiative „Chips für Europa 2.0“) fortgesetzt und weiterentwickelt. Im Rahmen der Säule I werden die notwendigen Voraussetzungen für die Stärkung der Kapazitäten der Union für industrielle Innovation geschaffen und Maßnahmen zur Ankurbelung der Nachfrage festgelegt. Im Rahmen der Säule II werden die Kriterien für die Anerkennung und Unterstützung europäischer Halbleitertechnologieinitiativen, bei denen es sich um neuartige Initiativen handelt, und strategischer Projekte festgelegt, die die Versorgungssicherheit und die Resilienz des Halbleiterökosystems der Union fördern. Im Rahmen der Säule III werden Maßnahmen zur Verbesserung des Koordinierungsmechanismus zwischen den Mitgliedstaaten und der Kommission festgelegt, der ursprünglich mit der Verordnung (EU) 2023/1781 (Chip-Gesetz) eingerichtet wurde.

1.2. Kapitel II – Initiative „Chips für Europa 2.0“

In Kapitel II liegt der Schwerpunkt auf der Initiative „Chips für Europa 2.0“, mit der die Wettbewerbsfähigkeit, Resilienz und Innovationskapazität der Union gestärkt werden sollen. Durch Investitionen in die Initiative „Chips für Europa 2.0“ sollte die Union ihre Forschungs- und Technologieentwicklungen wirksamer in nachfrageorientierte, anwendungsbezogene, sichere und energieeffiziente Halbleitertechnologien höchster Qualität umwandeln können. Gleichzeitig sollte die Union ihrer Zulieferindustrie die Möglichkeit bieten, von solchen Investitionen zu profitieren.

Zu diesem Zweck enthält dieses Kapitel die allgemeinen Bestimmungen und Ziele der Initiative „Chips für Europa“, die ursprünglich mit der Verordnung (EU) 2023/1781 eingerichtet wurde. Die Initiative „Chips für Europa 2.0“ zielt darauf ab, in der gesamten Union einen umfassenden Kapazitätsaufbau im Bereich der bestehenden hochmodernen Halbleitertechnologien und der Halbleitertechnologien der nächsten Generation zu unterstützen. Die Initiative „Chips für Europa 2.0“ hat nun sechs Komponenten: 1) Entwurfskapazitäten für integrierte Halbleitertechnik, 2) Pilotanlagen zur Vorbereitung einer innovativen Produktion sowie Erprobungs- und Versuchseinrichtungen, 3) fortgeschrittene technologische und ingenieurstechnische Kapazitäten zur Beschleunigung der Entwicklung von Quantenchips, 4) ein Netz der Kompetenzzentren und Kompetenzentwicklung, 5) Tätigkeiten im Rahmen des „Chip-Fonds“ für den Zugang von Start-ups, Scale-ups und KMU zu Kapital, und 6) Aufbau und Stärkung fortgeschrittener Kapazitäten für den Entwurf, die Prototypentwicklung und die industrielle Einführung photonisch integrierter Schaltungen in der gesamten Union. Die Initiative „Chips für Europa 2.0“ legt einen starken Schwerpunkt auf Industrialisierung und nachfragefördernde Maßnahmen wie die Großen Herausforderungen, das Nachfrageforum und die Nachfragebeschleuniger.

Die Initiative „Chips für Europa 2.0“ soll durch Mittel aus dem Programm Horizont Europa und dem Programm Digitales Europa im Zuge des derzeitigen MFR, insbesondere des neuen spezifischen Ziels 6 des Programms Digitales Europa, unterstützt und im Einklang mit den Verordnungen zur Einrichtung dieser Programme und gegebenenfalls deren Nachfolgern durchgeführt werden, unbeschadet der MFR-Verhandlungen.

Die Verordnung sieht einen Verfahrensrahmen vor, um die kombinierte Finanzierung durch die Mitgliedstaaten, unbeschadet der Vorschriften über staatliche Beihilfen, den Unionshaushalt und private Investitionen zu erleichtern.

Das Kapitel enthält auch Bestimmungen über die Durchführung. Mit der Umsetzung der Initiative „Chips für Europa 2.0“ wird in erster Linie auch das Gemeinsame Unternehmen für Chips und gegebenenfalls das gemeinsame Unternehmen oder jede andere ähnliche Einrichtung oder Initiative betraut, das/die an dessen Stelle tritt und durch Unionsrecht im Rahmen eines nachfolgenden mehrjährigen Finanzrahmens eingerichtet wird. Anhang I enthält die technische Beschreibung der Maßnahmen. Anhang III enthält messbare Indikatoren für die Überwachung der Durchführung und die Berichterstattung über die Fortschritte bei der Verwirklichung der Ziele der Initiative „Chips für Europa 2.0“. Der Kommission wird die Befugnis übertragen, delegierte Rechtsakte zur Änderung der Liste der messbaren Indikatoren zu erlassen. Die Initiative „Chips für Europa 2.0“ baut auf den vorhandenen Stärken Europas in der globalen Halbleiterwertschöpfungskette auf und verstärkt Synergien mit Maßnahmen, die derzeit von der Union und den Mitgliedstaaten unterstützt werden. Um ihre positiven Auswirkungen zu maximieren, sollte die Initiative „Chips für Europa 2.0“ daher die Schaffung von Synergien mit den in Anhang IV beschriebenen Unionsprogrammen ermöglichen.

1.3. Kapitel III – Versorgungssicherheit und Nachfrage

In Kapitel III Abschnitt 1 wird der Rahmen für europäische Halbleitertechnologieinitiativen und strategische Projekte festgelegt. Die Kommission kann Projekte innerhalb der Halbleiterwertschöpfungskette in der Union oder in einem Drittland als strategische Projekte anerkennen, wenn die Projekte die folgenden Kriterien erfüllen: Sie schaffen einen erheblichen Mehrwert für die EU, indem sie einen wesentlichen Beitrag zu Zielen von gemeinsamem Unionsinteresse leisten; sie weisen eine klare grenzüberschreitende Dimension auf; sie tragen zur Verbesserung der Unumgänglichkeit, der Resilienz und des Erfolgs der Halbleiterwertschöpfungskette der Union bei; und sie tragen dazu bei, die technologische Souveränität und die technologische Führungsposition Europas erheblich zu stärken.

Die Technologiebereiche, die als potenzielle Bereiche für die Anerkennung strategischer Projekte ermittelt wurden, sind in Anhang II aufgeführt.

Abschnitt 2 des Kapitels enthält Bestimmungen für die Beschleunigung von Genehmigungsverfahren für europäische Halbleitertechnologieinitiativen und strategische Projekte. Ferner wird darin die Nutzung europäischer Unternehmensbrieftaschen als zentrale Zugangsportale für die Einreichung eines einheitlichen Genehmigungsantrags für europäische Halbleitertechnologieinitiativen und strategische Projekte beschrieben.

In Kapitel III Abschnitt 3 werden die Ziele des Gütesiegels für Halbleiterexzellenzregionen sowie die Zielvorstellung für den Investitionsplan der europäischen Halbleiterregion und dessen Umfang beschrieben.

Kapitel III Abschnitt 4 dreht sich um Maßnahmen zur Stärkung der Resilienz der Lieferketten, insbesondere bei der Vergabe öffentlicher Aufträge für kritische Infrastrukturen und in bestimmten Wirtschaftszweigen, die als risikoanfällige Sektoren ermittelt wurden.

1.4. Kapitel IV – Überwachung und Krisenreaktion

Kapitel IV enthält einen Mechanismus für die koordinierte Überwachung der Halbleiterwertschöpfungskette und für die Reaktion auf Störungen bei der Lieferung von Halbleitern, die sich auf das reibungslose Funktionieren des Binnenmarkts auswirken.

In Abschnitt 1 wird ein umfassendes System zur strategischen Kartierung des Halbleitersektors der EU festgelegt, mit dem Schwachstellen, Abhängigkeiten und der künftige Bedarf zur Erhöhung der Lieferkettenresilienz ermittelt werden sollen. Die Kommission muss in Zusammenarbeit mit dem ESB eine eingehende Analyse der kritischen Aspekte durchführen. Dazu gehören wichtige von Halbleitern abhängende Wirtschaftszweige und Infrastrukturen (z. B. im Gesundheitswesen, in der Verteidigung und im digitalen Sektor), Lieferkettensegmente (vom Entwurf bis zur Fertigung und zu Werkstoffen), technologische Abhängigkeiten (insbesondere von Drittländern), der Fachkräftemangel und potenzielle Risiken, einschließlich solcher, die sich aus unzureichenden Investitionen oder geopolitischen Störungen ergeben. Bei der Kartierung werden auch die möglichen Auswirkungen von Kriseninterventionen (z. B. vorrangige Aufträge oder Ausfuhrkontrollen gemäß den Artikeln 41 bis 43) bewertet. Die Ergebnisse werden dem ESB regelmäßig als Grundlage für politische Entscheidungen übermittelt.

Um Risiken proaktiv zu überwachen, muss die Kommission auf der Grundlage der Kartierungsergebnisse eine Liste von Frühwarnindikatoren (z. B. für Versorgungsengpässe, Nachfragespitzen oder geopolitische Spannungen) erstellen und regelmäßig aktualisieren. Das Verfahren beruht in erster Linie auf öffentlich zugänglichen Daten und auf nicht vertraulichen Beiträgen aus der Industrie. Die Kommission kann jedoch zusätzliche auf freiwillige Auskünfte von Halbleiterunternehmen erbitten, wenn Lücken bestehen, und zwar zum Schutz der Vertraulichkeit über standardisierte, sichere Kanäle. Alle erhobenen Daten unterliegen strengen Vertraulichkeitsvorschriften (Artikel 50), und die Kommission stellt Leitlinien bereit, um einen kohärenten und sicheren Informationsaustausch zu gewährleisten. Der Rahmen und die Methodik für die Kartierung werden ebenfalls regelmäßig überprüft, um sie an sich wandelnde sektorale Herausforderungen anzupassen. Schließlich zielt dieses System darauf ab, Störungen zu antizipieren, strategische Investitionen zu lenken und die Autonomie der EU im Halbleiterbereich zu stärken.

In Abschnitt 1 werden auch die Einrichtung und die Ziele der Unternehmensplattform für die Halbleiterlieferkette beschrieben. Die Plattform wird ein digitaler Zwilling der Halbleiterlieferkette sein, mit dessen Hilfe ihre Transparenz und Resilienz erhöht werden soll. Der gesetzliche Vertreter der Plattform wird die Kommission über gegenwärtige oder zu erwartende Störungen der Halbleiterlieferkette informieren.

Abschnitt 2 enthält die Vorschriften für die Aktivierung der Halbleiterkrisenstufe sowie die Notmaßnahmen, die zur Bewältigung der Krise ergriffen werden können.

Dabei geht es zunächst um die Verpflichtung der zuständigen nationalen Behörden, die Kommission so bald wie möglich zu warnen, wenn sie ein Risiko einer schwerwiegenden Lieferstörung oder eine andere glaubwürdige Bedrohung der Verfügbarkeit von Halbleitern feststellen. Dadurch wird eine präventive Phase ausgelöst, in der die Kommission rasch handeln und eine außerordentliche Sitzung des ESB einberufen muss. Zu den Aufgaben des ESB gehört es, die Schwere der Störung zu bewerten, und zwar unter anderem mithilfe präventiver Auskunftsersuchen und durch die Erörterung der Frage, ob ein offizielles Krisenverfahren eingeleitet werden soll. Darüber hinaus kann die Kommission Drittländer konsultieren, um nach gemeinsamen Lösungen zu suchen, und die nationalen Behörden auffordern, die Krisenvorsorge der wichtigsten Marktteilnehmer zu bewerten.

Wird eine gemeinsame Auftragsvergabe für notwendig erachtet, muss sie den EU-Vorschriften für die Vergabe öffentlicher Aufträge (Richtlinien 2014/23/EU, 2014/24/EU und 2014/25/EU) entsprechen, um Transparenz und Wettbewerb zu bewahren. Die Erhebung von Informationen ist ein weiteres wichtiges Werkzeug. Die Kommission kann präventive Auskunftsersuchen an die Unternehmensplattform für die Halbleiterlieferkette richten, wobei Schutzvorkehrungen für sensible Geschäftsinformationen zu treffen sind. Die Kommission kann präventive Auskunftsersuchen auch an einzelne Unternehmen richten, wenn diese nicht an der Plattform beteiligt sind. Die Antworten werden dem ESB und den betreffenden Mitgliedstaaten übermittelt, um eine kollektive Bewusstseinsbildung zu gewährleisten.

Die Krisenstufe wird in diesem Rahmen nur dann ausgerufen, wenn zwei Bedingungen erfüllt sind: 1) schwerwiegende Störungen der Lieferkette, die zu erheblichen Versorgungsengpässen führen, und 2) schwerwiegende Auswirkungen auf kritische Sektoren (z. B. Gesundheitswesen, Verteidigung oder digitale Infrastruktur), die die gesellschaftliche, wirtschaftliche oder sicherheitspolitische Stabilität bedrohen. Nach Anhörung des ESB kann die Kommission dem Rat, der mit qualifizierter Mehrheit beschließt, die Aktivierung der Krisenstufe vorschlagen. Die Krisenstufe dauert bis zu 12 Monate, mit möglichen Verlängerungen, wenn dies gerechtfertigt ist, und erfordert eine regelmäßige Berichterstattung an das ESB und das Europäische Parlament. In dieser Phase müssen die Mitgliedstaaten ihre nationalen Maßnahmen über das ESB koordinieren, um fragmentierte Reaktionen zu vermeiden. Nach dem Ende der Krise muss die Kommission die Überwachung der Lieferkette innerhalb von sechs Monaten unter Berücksichtigung der gewonnenen Erkenntnisse aktualisieren. Die Bestimmungen über die Aktivierung der Krisenstufe bleiben entsprechend der Einigung der beiden gesetzgebenden Organe gegenüber den Bestimmungen des ersten Chip-Gesetzes unverändert und sind weiterhin zweckmäßig.

In Abschnitt 3 werden die Maßnahmen dargelegt, die zur Bewältigung von Halbleiterkrisen in der Union erforderlich sind.

Nach Artikel 41 kann die Kommission von Unternehmen der Halbleiterlieferkette Produktions- und Störungsdaten anfordern, um die Krise und mögliche Lösungen zu bewerten. Solche Ersuchen dürfen nur gestellt werden, wenn dies unbedingt erforderlich ist, und dürfen die nationale Sicherheit nicht gefährden.

Artikel 42 ermöglicht es der Kommission, Halbleiterhersteller zu verpflichten, Aufträgen für krisenkritische Produkte Vorrang vor bestehenden Verträgen einzuräumen.

Mit Artikel 43 wird eine gemeinsame Beschaffung eingeführt, bei der die Kommission als Zentraleinkäufer für mehrere Mitgliedstaaten fungiert, die mit schwerwiegenden Engpässen konfrontiert sind. Dieser Mechanismus stärkt die Verhandlungsposition und verhindert, dass EU-Länder um ein begrenztes Angebot konkurrieren.

Der Kommission wird die Befugnis übertragen, die Krisenstufe im Wege eines Durchführungsrechtsakts zu aktivieren, wenn konkrete, ernsthafte und zuverlässige Beweise für eine Halbleiterkrise vorliegen. Eine solche Halbleiterkrise tritt ein, wenn bei der Lieferung von Halbleitern schwerwiegende Störungen auftreten, die zu erheblichen Engpässen führen, welche erhebliche negative Auswirkungen auf einen oder mehrere wichtige Sektoren der Union nach sich ziehen oder die Bereitstellung, Reparatur und Wartung wesentlicher Produkte verhindern, die von kritischen Sektoren verwendet werden. In dem Durchführungsrechtsakt wird die Dauer der Krisenstufe oder ihre Verlängerung festgelegt. Vor Ablauf der Krisenstufe muss die Kommission unter Berücksichtigung der Stellungnahme des ESB prüfen, ob die Krisenstufe verlängert werden sollte. Während der Krisenstufe wird das ESB außerordentliche Sitzungen abhalten, damit die Mitgliedstaaten eng mit der Kommission zusammenarbeiten und nationale Maßnahmen in Bezug auf die Halbleiterlieferkette koordinieren können.

1.5. Kapitel V – Governance

Kapitel V enthält den Rahmen für den Fortbestand des ESB, das sich aus Vertretern der Mitgliedstaaten zusammensetzt und dessen Vorsitz die Kommission führt. Das ESB berät die öffentlichen Körperschaften des Gemeinsamen Unternehmens für Chips in Bezug auf die Initiative „Chips für Europa 2.0“ (Säule I). Es wird die Kommission bei der Bewertung von Anträgen für europäische Halbleitertechnologieinitiativen und strategische Projekte beraten und unterstützen (Säule II). Es wird sich mit der Kommission über die Fortschritte bei der Umsetzung des Investitionsplans der Halbleiterregion austauschen, die Ermittlung spezifischer kritischer Sektoren und Technologien erörtern und vorbereiten sowie Überwachungs- und Krisenreaktionsfragen behandeln (Säule III). Schließlich unterstützt es die einheitliche Anwendung der vorgeschlagenen Verordnung und erleichtert die Zusammenarbeit zwischen den Mitgliedstaaten. Das ESB unterstützt die Kommission bei der internationalen Zusammenarbeit und bei strategischen Halbleiterpartnerschaften. Es koordiniert darüber hinaus einschlägige Krisenstrukturen, die im Rahmen des Unionsrechts eingerichtet wurden, und tauscht mit ihnen Informationen aus. Das ESB tritt in unterschiedlichen Zusammensetzungen zusammen und hält gesonderte Sitzungen für seine Aufgaben im Rahmen der Säule I und für seine Aufgaben im Rahmen der Säulen II und III ab. Die Kommission kann ständige oder vorübergehende Untergruppen des ESB einrichten und Organisationen, die die Interessen der Halbleiterindustrie vertreten, sowie andere Interessenträger als Beobachter zu solchen Untergruppen einladen. Das ESB sollte veranlassen, dass der Lenkungsausschuss der Industrieallianz für Halbleiter, der die Tätigkeiten der Industrieallianz für Prozessoren und Halbleitertechnik übernehmen wird, eingeladen wird, mindestens einmal jährlich aktuelle Informationen vorzulegen.

Auf nationaler Ebene benennen die Mitgliedstaaten eine oder mehrere zuständige nationale Behörden und unter anderem eine nationale zentrale Anlaufstelle für die Zwecke der Durchführung der Verordnung.

1.6. Kapitel VI, VII, VIII – Schlussbestimmungen

In Kapitel VI wird die Verpflichtung aller Parteien hervorgehoben, die Vertraulichkeit sensibler Geschäftsinformationen und Geschäftsgeheimnisse zu wahren. Die Verpflichtung gilt für die Kommission, die zuständigen nationalen Behörden und andere Behörden der Mitgliedstaaten sowie für alle Vertreter und Sachverständigen, die an den Sitzungen des ESB und des Ausschusses teilnehmen. Das Kapitel enthält außerdem Vorschriften für wirksame, verhältnismäßige und abschreckende Zwangsgelder und Geldbußen bei Nichteinhaltung der Verpflichtungen aus dieser Verordnung, vorbehaltlich angemessener Garantien. Die Kommission kann Zwangsgelder verhängen, wenn die betreffenden Unternehmen in einer Halbleiterkrise bestimmte Aufträge nicht annehmen und diesen keinen Vorrang einräumen. Außerdem kann die Kommission Geldbußen gegen Unternehmen verhängen, die unrichtige, unvollständige oder irreführende Angaben machen oder die Auskünfte nicht innerhalb der vorgeschriebenen Frist erteilen.

Kapitel VII enthält Vorschriften und Bedingungen für die Ausübung der Befugnisübertragung und der Durchführungsbefugnisse. Mit dem Vorschlag wird der Kommission die Befugnis übertragen, gegebenenfalls Durchführungsrechtsakte zu erlassen, um die Festlegung von Verfahren zu ermöglichen und die einheitliche Anwendung der Verordnung zu gewährleisten, sowie delegierte Rechtsakte zur Änderung des Anhangs I (der darin festgelegten Tätigkeiten im Einklang mit den Zielen der Initiative „Chips für Europa 2.0“) und des Anhangs III (der messbaren Indikatoren und der Bestimmungen über die Einrichtung eines Überwachungs- und Bewertungsrahmens zur Ergänzung dieser Verordnung).

Kapitel VIII erlegt der Kommission die Verpflichtung auf, dem Europäischen Parlament und dem Rat regelmäßige Berichte zur Bewertung und Überprüfung der Verordnung zu übermitteln.

(Text von Bedeutung für den EWR)

DAS EUROPÄISCHE PARLAMENT UND DER RAT DER EUROPÄISCHEN UNION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union, insbesondere auf Artikel 173 Absatz 3 und Artikel 114,

auf Vorschlag der Europäischen Kommission,

nach Zuleitung des Entwurfs des Gesetzgebungsakts an die nationalen Parlamente,

nach Stellungnahme des Europäischen Wirtschafts- und Sozialausschusses^(27),

nach Stellungnahme des Ausschusses der Regionen^(28),

gemäß dem ordentlichen Gesetzgebungsverfahren,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Mit der Verordnung (EU) 2023/1781 des Europäischen Parlaments und des Rates^(29) zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Halbleiterökosystems und zur Änderung der Verordnung (EU) 2021/694 (Chip-Gesetz) wurde ein umfassender Rahmen auf Unionsebene eingerichtet, um das Halbleiterökosystem zu fördern und so die technischen Kapazitäten der Union zu stärken, ihre Resilienz zu verbessern und die Versorgungssicherheit zu gewährleisten.

<a id="rec-2"></a>
(2) Die Bewertung^(30) der Verordnung (EU) 2023/1781 hat ergeben, dass die Verordnung die Mobilisierung erheblicher öffentlicher und privater Investitionen, den Aufbau fortgeschrittener Infrastrukturen und die Einrichtung von Koordinierungs- und Krisenvorsorgemechanismen ermöglicht und so zu einer besseren Zusammenarbeit zwischen den Mitgliedstaaten und zum Funktionieren des Binnenmarkts beigetragen hat. Die Bewertung hat gezeigt, dass die Verordnung (EU) 2023/1781 als Katalysator für ein koordiniertes Vorgehen der Union in Bezug auf Halbleiter gedient hat, indem sie die Forschungs- und Innovationskapazitäten gestärkt, Zugang zu technologischen Infrastrukturen ermöglicht, einen Rahmen für Fertigungskapazitäten sowie einen Krisen- und Reaktionsmechanismus zur Antizipation potenzieller Störungen geschaffen hat. Gleichzeitig wurden bei der Bewertung strukturelle Mängel und anhaltende Herausforderungen festgestellt, die die Wirksamkeit der Verordnung bei der Bewältigung sich wandelnder industrieller und wirtschaftlicher Bedürfnisse einschränken.

<a id="rec-3"></a>
(3) Während sich der mit der Verordnung (EU) 2023/1781 geschaffene Rahmen bei der Förderung von Innovation und Kapazitäten in der Frühphase als wirksam erwiesen hat, befindet sich der Übergang von der technologischen Entwicklung zur Einführung im industriellen Maßstab nach wie vor in einem frühen Stadium. Lange Investitionszyklen, strukturelle Abhängigkeiten in kritischen Segmenten der Wertschöpfungskette und Sachzwänge bei der Ausweitung der Produktion beeinträchtigen nach wie vor die Fähigkeit der Union, ein resilientes und wettbewerbsfähiges Halbleiterökosystem zu schaffen.

<a id="rec-4"></a>
(4) Darüber hinaus hat die Bewertung gezeigt, dass die begrenzte Verfügbarkeit von privatem Kapital, insbesondere für Finanzierungen in einer späteren Phase, und strukturelle Merkmale der Finanzmärkte das Wachstum und die Expansion von Halbleiterunternehmen in der Union behindern. Gleichzeitig verringern die Fragmentierung der Nachfrage in den verschiedenen Industriezweigen, die geringe Größe des Marktes und die unzureichende Koordinierung zwischen den Käufern die geschäftliche Tragfähigkeit von Investitionen in die Fertigung und bergen die Gefahr einer unzureichenden Auslastung neu entstehender Kapazitäten.

<a id="rec-5"></a>
(5) Darüber hinaus ist der Halbleitersektor zu einem Eckpfeiler der wirtschaftlichen Stabilität, technologischen Souveränität und Sicherheit der Union geworden. Die beschleunigte Integration fortgeschrittener digitaler Technologien, insbesondere künstlicher Intelligenz (KI), hat die weltweite Nachfrage nach Halbleitern erheblich gesteigert und gleichzeitig den Wettbewerb auf den internationalen Märkten intensiviert. Diese Entwicklungen haben strukturelle Schwachstellen in den Halbleiterlieferketten der Union offenbart, darunter Abhängigkeiten von wenigen externen Lieferanten, unzureichende inländische Produktionskapazitäten und Fragmentierung zwischen den Mitgliedstaaten.

<a id="rec-6"></a>
(6) Insbesondere die zunehmende Bedeutung von KI-Anwendungen hat zu einem Anstieg der Nachfrage nach hochspezialisierten Chips wie fortgeschrittenen Halbleitern für Logik- und Speicheranwendungen geführt, die für das Training und den Einsatz komplexer KI-Modelle unerlässlich sind. Dieser Trend dürfte sich fortsetzen, bestehende Ungleichgewichte zwischen Angebot und Nachfrage weiter verstärken und die ohnehin schon fragilen globalen Lieferketten zusätzlich belasten. Gleichzeitig haben geopolitische Spannungen, Ausfuhrbeschränkungen und Störungen im Zusammenhang mit globalen Krisen die Risiken im Zusammenhang mit einer übermäßigen Abhängigkeit von der Fertigung in Drittländern und einer begrenzten Diversifizierung weiter verdeutlicht.

<a id="rec-7"></a>
(7) Angesichts dieser Entwicklungen muss der mit der Verordnung (EU) 2023/1781 geschaffene Rahmen gestärkt und ergänzt werden, um den Übergang von der Innovation zum industriellen Maßstab zu unterstützen, die Resilienz und die wirtschaftliche Sicherheit zu stärken und das wirksame Funktionieren des Binnenmarkts zu gewährleisten. Daher sollte die Verordnung (EU) 2023/1781 aufgehoben und durch die vorliegende Verordnung ersetzt werden.

<a id="rec-8"></a>
(8) Da die vorliegende Verordnung den mit der Verordnung (EU) 2023/1781 geschaffenen Rahmen verstärkt und ergänzt, ohne dessen grundlegende Ziele zu ändern, bleiben die Rechtsgrundlagen dieses Rahmens unverändert.

<a id="rec-9"></a>
(9) Daher sollte sich diese Verordnung auch auf Artikel 173 Absatz 3 des Vertrags über die Arbeitsweise der Europäischen Union (AEUV) stützen, damit die Union Maßnahmen zur weiteren Erhaltung und zum Aufbau von Kapazitäten und zur Stärkung ihres Halbleiterökosystems ergreifen kann. Mit diesen Maßnahmen sollte keine Harmonisierung nationaler Rechts- und Verwaltungsvorschriften verbunden sein. Die Union sollte in dieser Hinsicht die Wettbewerbsfähigkeit und Resilienz der technologischen und industriellen Basis für Halbleiter erhöhen und gleichzeitig die Innovationskapazität des Halbleiterökosystems in der gesamten Union stärken, die Abhängigkeit von einigen wenigen Unternehmen in Drittländern und von einigen wenigen geografischen Gebieten verringern und ihre Kapazität zum Entwurf und zur Herstellung, zum Packaging, zur Wiederverwendung und zum Recycling fortgeschrittener Halbleiter stärken. Die erstmals mit der Verordnung (EU) 2023/1781 eingerichtete Initiative „Chips für Europa“ sollte diese Ziele im Rahmen der vorliegenden Verordnung weiterhin unterstützen, indem sie – über die Schließung der Kluft zwischen den fortgeschrittenen Forschungs- und Innovationsfähigkeiten der Union und deren nachhaltiger industrieller Nutzung hinaus – die Anstrengungen weiter intensiviert und für eine wirksame Verwertung dieser Fähigkeiten in Form der industriellen Produktion und Markteinführung in der Union sorgt. Die Initiative „Chips für Europa 2.0“ sollte weiterhin den Kapazitätsaufbau unterstützen, um Entwurf, Produktion und Systemintegration bei Halbleitertechnologien der nächsten Generation zu ermöglichen, sowie weiterhin die Zusammenarbeit zwischen wichtigen Akteuren in der gesamten Union fördern, um die Halbleiterliefer- und ‑wertschöpfungsketten der Union zu stärken, wichtigen Industriesektoren behilflich zu sein und neue Märkte zu schaffen.

<a id="rec-10"></a>
(10) Um das wirksame Funktionieren des Binnenmarkts zu gewährleisten, sollte diese Verordnung darüber hinaus zur Schaffung eines kohärenten Unionsrahmens beitragen, mit dem bestimmte Bedingungen und Koordinierungsmechanismen gemäß Artikel 114 AEUV angeglichen werden. Ein solcher Rahmen ist erforderlich, um Hindernissen für das Funktionieren des Binnenmarkts vorzubeugen, die Fragmentierung zu verringern und eine kohärente und wirksame Reaktion auf Risiken in der Lieferkette zu gewährleisten und dabei gleichzeitig die Kohärenz mit dem Unionsrecht und internationalen Verpflichtungen zu wahren. Dies ist besonders wichtig, wenn man bedenkt, dass Halbleiter eine Basistechnologie sind, die einem breiten Spektrum wirtschaftlicher Tätigkeiten und kritischer Infrastrukturen in der gesamten Union zugrunde liegt. Vor dem Hintergrund erhöhter geopolitischer Spannungen, des strategischen globalen Wettbewerbs und zunehmend wichtiger Fragen der wirtschaftlichen Sicherheit ist das Halbleiterökosystem zu einem Schlüsselfaktor für die Stabilität und das Funktionieren des Binnenmarkts geworden. Der Halbleitersektor ist durch komplexe grenzüberschreitende gegenseitige Abhängigkeiten entlang der Wertschöpfungskette geprägt, wobei sich hochspezialisierte Tätigkeiten auf verschiedene geografische Gebiete konzentrieren, während die nachgelagerten Anwenderbranchen in der gesamten Union verteilt sind. Aufgrund dieser Merkmale dürften Störungen, Beschränkungen oder Verzerrungen, die sich auf die Halbleiterlieferketten auswirken, erhebliche grenzüberschreitende Auswirkungen haben und das Funktionieren des Binnenmarkts beeinträchtigen. Unterschiedliche nationale Maßnahmen zur Bewältigung solcher Risiken können zu Fragmentierung führen, den Wettbewerb verzerren und gleichen Wettbewerbsbedingungen im Binnenmarkt abträglich sein, insbesondere angesichts des integrierten Charakters der Produktions- und Vertriebsnetze. Daher können die Ziele der Gewährleistung der Resilienz, der Sicherheit und des ordnungsgemäßen Funktionierens der Halbleiterlieferketten in der Union von den Mitgliedstaaten allein nicht ausreichend verwirklicht, aufgrund ihres Umfangs und ihrer grenzüberschreitenden Auswirkungen stattdessen aber besser auf Unionsebene erreicht werden.

<a id="rec-11"></a>
(11) Die Verwirklichung dieser Ziele sollte weiterhin vom Europäischen Halbleitergremium unterstützt werden, das sich aus Vertretern der Mitgliedstaaten zusammensetzt und in dem die Kommission den Vorsitz führt, um eine reibungslose, wirksame und harmonisierte Durchführung der vorliegenden Verordnung, die Zusammenarbeit und den Informationsaustausch zu erleichtern. Das Europäische Halbleitergremium sollte die Kommission in bestimmten Fragen beraten und unterstützen, unter anderem bei der einheitlichen Durchführung dieser Verordnung, der Erleichterung der Zusammenarbeit zwischen den Mitgliedstaaten und dem Informationsaustausch zu Angelegenheiten im Zusammenhang mit dieser Verordnung. Das Europäische Halbleitergremium sollte die Kommission auch bei der internationalen Zusammenarbeit im Zusammenhang mit Halbleitern, einschließlich strategischer Halbleiterpartnerschaften, und bei der Erhebung von Informationen beraten. In Sitzungen können verschiedene Untergruppen einbezogen werden.

<a id="rec-12"></a>
(12) Angesichts des globalisierten Charakters der Halbleiterlieferkette ist die internationale Zusammenarbeit mit Drittländern ein wichtiges Element, um das Halbleiterökosystem der Union resilient zu machen. Die im Rahmen dieser Verordnung ergriffenen Maßnahmen sollten die Union auch in die Lage versetzen, als Exzellenzzentrum eine stärkere Rolle in einem besser funktionierenden globalen, durch gegenseitige Abhängigkeiten geprägten Halbleiterökosystem zu spielen. Dabei sollten gegebenenfalls die Standpunkte der Industrieallianz für Halbleiter^(31), die die Tätigkeiten der Industrieallianz für Prozessoren und Halbleitertechnik übernehmen wird, sowie anderer Interessenträger berücksichtigt werden. Im Einklang mit den internationalen Verpflichtungen könnten die Union und die Mitgliedstaaten – auch auf diplomatischer Ebene – mit internationalen strategischen Partnern, die sich einen Vorsprung in der Halbleiterindustrie verschafft haben, zusammenarbeiten, um nach Lösungen zu suchen, mit denen die Versorgungssicherheit gestärkt und künftige Störungen der Halbleiterlieferkette, beispielsweise aufgrund von Ausfuhrbeschränkungen in Drittländern, behoben werden können und die Verfügbarkeit von Rohstoffen und Zwischenprodukten ermittelt werden kann. Die Kommission und die Mitgliedstaaten sollten ihre auf internationaler Ebene unternommenen Anstrengungen koordinieren und zwar in erster Linie mit Unterstützung des Europäischen Halbleitergremiums. Dies kann bei Bedarf auch eine Koordinierung in einschlägigen internationalen Foren, den Abschluss von Investitions- und Handelsabkommen oder andere diplomatische Bemühungen oder die Zusammenarbeit mit einschlägigen Interessenträgern umfassen.

<a id="rec-13"></a>
(13) Die Stärkung der kritischen Infrastrukturen, der Sicherheit, der industriellen Basis und der technologischen Führungsposition der Union erfordert einen sicheren und zuverlässigen Zugang zu modernsten und handelsüblichen Halbleitertechnologien, einschließlich Prozessoren, Speicher-, Analog-, Leistungs-, Sensor-, Funkfrequenz- und Konnektivitätschips, die für die Zukunftsfähigkeit strategischer Sektoren wie Energie, Verteidigung, Automobilindustrie, Luftfahrt, Telekommunikation, Gesundheitswesen, Cloud-Computing und industrielle Automatisierung unverzichtbar sind. Die Union verfügt über starke Fähigkeiten in einem breiten Spektrum ausgereifter Technologieknoten, auch bei Chips für die Automobilindustrie, energieeffizienten und sicheren Chips, und sollte ihre Wettbewerbsfähigkeit, Resilienz und strategische Autonomie in der gesamten Halbleiterwertschöpfungskette weiter verstärken.

<a id="rec-14"></a>
(14) Die Halbleiterindustrie weist einen erheblichen Investitionsbedarf sowohl für Forschungs-, Entwicklungs- und Innovationstätigkeiten als auch für den Bau modernster Anlagen für die Erprobung und Validierung zur Unterstützung der industriellen Produktion auf. Diese kostenintensiven Merkmale wirken sich unmittelbar auf die Wettbewerbs- und Innovationsfähigkeit der Union aus und beeinträchtigen die Versorgungssicherheit und die allgemeine Resilienz ihres Halbleiterökosystems. Gleichzeitig hängen die Wettbewerbsfähigkeit und die Resilienz der Union von der kontinuierlichen Verfügbarkeit und Entwicklung handelsüblicher und ausgereifter Halbleitertechnologien ab, einschließlich Analog-, Leistungs-, Sensor- und Konnektivitätschips sowie Chips für die Automobilindustrie und Luftfahrt, die in strategischen industriellen Wertschöpfungsketten und kritischen Infrastrukturen nach wie vor unverzichtbar sind. Im derzeitigen Kontext eines zunehmenden globalen Wettbewerbs, wachsender geopolitischer Spannungen und struktureller Schwachstellen in der Lieferkette sind Halbleiter zu einer strategischen Ressource geworden, die die Grundlage für die wirtschaftliche Sicherheit, die technologische Führungsposition und die industrielle Resilienz der Union bildet. Angesichts der Lehren aus den jüngsten Engpässen und Störungen der Lieferketten in der Union und weltweit sowie aus Ausfuhrbeschränkungen oder Regulierungsmaßnahmen von Drittländern und der raschen Entwicklung der technologischen Herausforderungen und der Innovationszyklen, die Auswirkungen auf die Halbleiterwertschöpfungskette haben, ist es erforderlich, durch einen weiteren Ausbau der Initiative „Chips für Europa“ die bestehenden Stärken der Union zu festigen, darunter ihre Führungsposition in mehreren Segmenten für handelsübliche Halbleiter, und damit die Markteinführungsrate, Wettbewerbsfähigkeit, Resilienz sowie Forschungs- und Innovationskapazität zu erhöhen.

<a id="rec-15"></a>
(15) Bei der erweiterten Initiative „Chips für Europa 2.0“ sollten die Erfahrungen berücksichtigt werden, die bereits bei der Umsetzung der Initiative „Chips für Europa“ gesammelt wurden, um diese fortzuführen und zu verstärken und so verbleibende strukturelle Schwächen zu beheben und auf neu entstehende strategische Erfordernisse zu reagieren. Insbesondere müssen die Anstrengungen intensiviert werden, damit sich die fortgeschrittenen Forschungs- und Innovationsfähigkeiten der Union wirksam in der industriellen Einführung, der Ausweitung und der kommerziellen Produktion in der Union niederschlagen.

<a id="rec-16"></a>
(16) Die Mitgliedstaaten tragen die Hauptverantwortung dafür, eine starke Basis für Industrie, Wettbewerbsfähigkeit, Nachhaltigkeit und Innovation in der Union zu erhalten. Gleichwohl machen Art und Umfang der Forschungs- und Innovationsherausforderungen bei Halbleitern eine Zusammenarbeit auf Unionsebene erforderlich. Um die Union mit den Forschungs- und Innovationskapazitäten im Bereich der Halbleitertechnik auszustatten, die erforderlich sind, um die führende Rolle ihrer Forschungs- und Industrieinvestitionen aufrechtzuerhalten, und aufbauend auf den Erfahrungen und Erkenntnissen, die bei der Umsetzung der Initiative „Chips für Europa“ gewonnen wurden, ist es erforderlich, diese Kapazitäten weiter zu verstärken und zu erweitern, sodass ihre wirksame industrielle Einführung, ihre Ausweitung und ihre kommerzielle Produktion in der Union sichergestellt werden können. Dazu sollten die Union und die Mitgliedstaaten ihre Anstrengungen weiter koordinieren und gemeinsame Investitionen tätigen.

<a id="rec-17"></a>
(17) Angesichts des zunehmenden globalen Wettbewerbs, wachsender geopolitischer Spannungen und des Risikos von Störungen der Halbleiterlieferkette, einschließlich solcher, die sich aus von Drittländern erlassenen Regulierungsmaßnahmen ergeben und die sich auf den Zugang zu kritischen Halbleitertechnologien und damit verbundener Inputs auswirken können, ist die Stärkung der Fähigkeit der Union, solche Technologien in ihrem Hoheitsgebiet zu entwickeln, herzustellen und einzusetzen, zu einer strategischen Priorität für die Wettbewerbsfähigkeit, die wirtschaftliche Sicherheit und die technologische Souveränität der Union geworden, wie in dem Bericht „Die Zukunft der europäischen Wettbewerbsfähigkeit“ von Mario Draghi hervorgehoben wird. Diese Herausforderungen des Halbleiterökosystems der Union erfordern die Schaffung umfangreicher Kapazitäten und gemeinsame Anstrengungen der Mitgliedstaaten, wobei die Union die Entwicklung und die Einführung umfassender Kapazitäten entlang der gesamten Innovationskette und der industriellen Wertschöpfungskette, einschließlich Pilotanlagen, der Ausweitung der Fertigung und der kommerziellen Einführung, unterstützen muss, um so die wirksame Umsetzung von Forschungsexzellenz in eine industrielle Führungsposition und nachhaltige Produktionskapazitäten in der Union sicherzustellen.

<a id="rec-18"></a>
(18) Wie in der Bewertung der Verordnung (EU) 2023/1781 festgestellt wurde, sind die im Rahmen der in der genannten Verordnung vorgesehenen Initiative „Chips für Europa“ eingerichteten Instrumente, d. h. die Entwurfsplattform, Pilotanlagen, Pilotprojekte für Quantenchips und die Verbreitung von Fachwissen, die EU-Akademie für Chip-Kompetenzen im Rahmen der Allianzen für die branchenspezifische Zusammenarbeit zur Kompetenzförderung und der Kompetenzpakt sowie Kompetenzen, die dem gesamten Halbleiterökosystem zugutekommen, zweckdienlich und sollten im Rahmen der vorliegenden Verordnung weiterhin unterstützt werden. Diese Anstrengungen sollten auch zu dem übergeordneten Ziel der Union beitragen, ihre langfristige Wettbewerbsfähigkeit, Innovationskapazität und industrielle Basis zu stärken, unter anderem durch Synergien mit künftigen Programmen der Union zur Unterstützung der Forschung und Innovation und der industriellen Einführung, wie dem vorgeschlagenen Nachfolgeprogramm von Horizont Europa^(32), dem mit der Verordnung (EU) 2021/695 des Europäischen Parlaments und des Rates eingerichteten Rahmenprogramm für Forschung und Innovation^(33) (Horizont Europa) (RP10) und dem vorgeschlagenen Europäischen Fonds für Wettbewerbsfähigkeit^(34), während die Initiative „Chips für Europa 2.0“ mit allen Bestandteilen und Maßnahmen zu einer möglichst weitgehenden Übertragung und Maximierung der Anwendungsvorteile von Halbleitertechnologien führen sollte, die die Nachhaltigkeitswende entscheidend vorantreiben und neue Produkte hervorbringen sowie eine effizientere, wirksame, saubere und dauerhafte Nutzung von Ressourcen bewirken können, einschließlich Energie und Materialien, die für die Herstellung und die Nutzung von Halbleitern über den gesamten Lebenszyklus erforderlich sind.

<a id="rec-19"></a>
(19) Um ihr allgemeines Ziel zu erreichen und sowohl die angebots- als auch die nachfrageseitigen Herausforderungen des derzeitigen Halbleiterökosystems anzugehen, sollte die Initiative „Chips für Europa 2.0“ aufbauend auf den Erfahrungen und Erkenntnissen aus der Durchführung der Verordnung (EU) 2023/1781, die gezeigt haben, dass die Kapazitäten der Union nicht nur in den Bereichen Forschung und Innovation, sondern auch in Bezug auf die industrielle Einführung und die Ausweitung der Fertigung weiter gestärkt werden müssen, die fünf im Rahmen der Verordnung (EU) 2023/1781 festgelegten operativen Ziele weiterhin unterstützen und verbessern. Außerdem sollte ein neues operatives Ziel eingeführt werden, das darauf abzielt, die Fähigkeiten der Union im Bereich der Photoniktechnologien zu stärken und die Großen Herausforderungen als Instrumente zur Unterstützung groß angelegter, sektorübergreifender Initiativen zur Bewältigung großer technologischer und industrieller Herausforderungen von strategischer Bedeutung für die Union zu unterstützen. Mit der Umsetzung der Initiative „Chips für Europa 2.0“ sollte weiterhin hauptsächlich das Gemeinsame Unternehmen für Chips und gegebenenfalls das gemeinsame Unternehmen oder jede andere ähnliche Einrichtung oder Initiative betraut werden, die an dessen Stelle tritt und durch Unionsrecht im Rahmen eines nachfolgenden mehrjährigen Finanzrahmens eingerichtet wird.

<a id="rec-20"></a>
(20) Erstens sollte die Initiative „Chips für Europa 2.0“ die Entwurfskapazität der Union stärken. Zu diesem Zweck sollte sie weiterhin die virtuelle Entwurfsplattform fördern, die im Rahmen der Initiative „Chips für Europa“ eingerichtet wurde, um die Gemeinschaften von Entwurfsbüros, Start-ups, kleinen und mittleren Unternehmen (KMU) und Anbieter von intellektuellem Eigentum, Werkzeuganbieter und Forschungs- und Technologieorganisationen miteinander zu vernetzen, damit auf der Grundlage einer gemeinsamen Technologieentwicklung virtuelle Prototyplösungen bereitgestellt werden und so der Übergang von der Entwurfsphase zur industriellen Produktion und kommerziellen Einführung in der Union erleichtert wird.

<a id="rec-21"></a>
(21) Zweitens sollte die Initiative „Chips für Europa 2.0“, um die Grundlage für die Stärkung der Versorgungssicherheit und des Halbleiterökosystems der Union zu schaffen, weiterhin den Ausbau bestehender und die Entwicklung neuer fortschrittlicher Pilotanlagen unterstützen, um die Entwicklung und Einführung von hochmodernen Halbleitertechnologien und von Halbleitertechnologien der nächsten Generation zu ermöglichen. Die Pilotanlagen sollten der Industrie eine Möglichkeit bieten, Halbleitertechnologien und Systementwurfskonzepte bei möglichst geringer Umweltbelastung zu testen, zu erproben und zu validieren, um deren Übergang zur Fertigung im industriellen Maßstab in der Union zu beschleunigen. Investitionen der Union zusammen mit denen der Mitgliedstaaten und des Privatsektors in Pilotanlagen sind nach wie vor erforderlich, um anhaltende strukturelle Herausforderungen und Marktversagen zu bewältigen, einschließlich der unzureichenden Verfügbarkeit von Test-, Validierungs- und Ausweitungskapazitäten für die Halbleiterfertigung im industriellen Maßstab in der Union, die nach wie vor Innovationen, die industrielle Einführung und die globale Wettbewerbsfähigkeit behindern.

<a id="rec-22"></a>
(22) Drittens sollten zur Beschleunigung der innovativen Entwicklung von Quantenchips und zugehörigen Halbleitertechnologien, einschließlich solcher, die auf Halbleiterwerkstoffen basieren oder mit Photonik integriert sind, die der Entwicklung des Halbleitersektors dienen, im Rahmen der Initiative „Chips für Europa 2.0“ auch Maßnahmen in Bezug auf Entwurfsbibliotheken für Quantenchips, Pilotanlagen für die Herstellung von Quantenchips sowie Anlagen für die Prüfung und Validierung der in den Pilotanlagen hergestellten Quantenchips unterstützt werden, um ihre industrielle Einführung zu ermöglichen und die technologische Führungsposition der Union bei neu entstehenden Halbleitertechnologien zu stärken.

<a id="rec-23"></a>
(23) Viertens sollte die Initiative „Chips für Europa 2.0“ durch den Ausbau bestehender Zentren oder die Schaffung neuer Anlagen den Mitgliedstaaten weiterhin die Möglichkeit bieten, mindestens ein Kompetenzzentrum für Halbleiter in jedem Mitgliedstaat zu unterstützen, um den Einsatz von Halbleitertechnologien zu fördern, den Zugang zu Entwurfs- und Pilotanlagen zu ermöglichen und Qualifikationsdefizite in der gesamten Union zu überbrücken.

<a id="rec-24"></a>
(24) Fünftens sind Photonik und photonisch integrierte Schaltungen Schlüsseltechnologien für ein breites Spektrum strategischer Sektoren, darunter Telekommunikation, Rechenzentren, künstliche Intelligenz, Sensorik, Gesundheitswesen, Automobilindustrie, Luftfahrt und Quantentechnik. Sie ermöglichen eine sehr schnelle Datenübertragung, eine energieeffiziente Datenverarbeitung und fortgeschrittene Sensorfähigkeiten und sind daher für die technologische Führungsposition, die Wettbewerbsfähigkeit und die Versorgungssicherheit der Union von entscheidender Bedeutung. Die Union hat starke Forschungs- und Innovationsfähigkeiten aufgebaut und ist in mehreren Segmenten der Photonikwertschöpfungskette führend. Es sind jedoch weitere Anstrengungen erforderlich, um die Kapazität der Union zu stärken, photonisch integrierte Schaltungen und zugehörige photonische Halbleitertechnologien zu entwerfen, entsprechende Prototypen zu entwickeln und diese dann in großem Maßstab zu industrialisieren und herzustellen. Um die technologische Entwicklung im Bereich der Photonik und der photonisch integrierten Schaltungen voranzubringen, ist es daher erforderlich, die Entwicklung von Entwurfsbibliotheken und Entwurfswerkzeugen zu unterstützen, die Produktionstechnologien und Werkstoffplattformen zu stärken und Pilotanlagen und frei zugängliche Fertigungsanlagen für mehrere Werkstoffplattformen auszubauen. Diese Maßnahmen sollten die Entwicklung von Prototypen, die Erprobung, Validierung und industrielle Einführung, auch durch fortgeschrittene Integrations- und Packaging-Technologien, erleichtern und dazu beitragen, das Photonikökosystem der Union und ihre technologische Souveränität zu stärken und die industrielle Einführung innovativer Photoniktechnologien in der gesamten Union zu beschleunigen.

<a id="rec-25"></a>
(25) Sechstens sollte die Kommission in enger Zusammenarbeit mit der Europäischen Investitionsbank-Gruppe und gemeinsam mit anderen Durchführungspartnern wie nationalen Förderbanken und -instituten weiterhin den „Chip-Fonds“, d. h. eine spezielle Investitionsfazilität für Halbleiter zur Stärkung des europäischen Halbleiterökosystems durch Unterstützung von Start-ups, Scale-ups und KMU, die sowohl Eigenkapitallösungen als auch Fremdkapitallösungen anbietet, einschließlich einer Mischfinanzierungsfazilität im Rahmen des mit der Verordnung (EU) 2021/523 des Europäischen Parlaments und des Rates^(35) eingerichteten Fonds „InvestEU“, und gegebenenfalls alle anderen einschlägigen Investitionsprogramme im Rahmen des Mehrjährigen Finanzrahmens 2028-2034 unterstützen. Die Tätigkeiten im Rahmen des „Chip-Fonds“ sollten die Entwicklung eines dynamischen und resilienten Halbleiterökosystems unterstützen, indem Möglichkeiten für eine bessere Verfügbarkeit von Mitteln geschaffen werden, um das Wachstum von Start-ups und KMU sowie Investitionen entlang der gesamten Halbleiterwertschöpfungskette – auch für andere Unternehmen der Halbleiterwertschöpfungskette – zu unterstützen. In dieser Hinsicht sollten insbesondere Unterstützung und klare Anleitung für KMU bereitgestellt werden, um sie beim Antragsverfahren zu unterstützen. Es wird erwartet, dass der Europäische Innovationsrat diesbezüglich weitere gezielte Unterstützung in Form von Finanzhilfen und Beteiligungsinvestitionen zugunsten marktschaffender Innovatoren in Bereichen mit hohem Risiko leisten wird.

<a id="rec-26"></a>
(26) Um die technologische Führungsposition und die industrielle Wettbewerbsfähigkeit der Union im Halbleiterbereich weiter zu stärken, ist es angezeigt, das Konzept der Großen Herausforderungen als Teil der Initiative „Chips für Europa 2.0“ einzuführen. Diese Großen Herausforderungen sollten auf die Entwicklung, Integration und industrielle Einführung vielversprechender und kritischer Halbleiter- und verwandter Technologien ausgerichtet werden, die für die Union von zentraler Bedeutung sind. Die Großen Herausforderungen sollten fortgeschrittene Forschungs- und Entwicklungstätigkeiten unterstützen, die darauf abzielen, die Voraussetzungen für die nächste Generation von Halbleitertechnologien zu schaffen, einschließlich solcher, die der KI, dem Cloud-Computing, Rechenzentren und Edge-Infrastrukturen zugrunde liegen, wobei ein besonderer Schwerpunkt auf der Verbesserung der Energieeffizienz, der Sicherung von Kapazitäten im Bereich der Spitzentechnologien und dem Ausbau der Fertigungsstärken der Union liegen sollte. Sie sollten auch wichtigen technologischen Hindernissen gewidmet sein, einschließlich Fragen im Zusammenhang mit Miniaturisierung, Energieeffizienz, Nachhaltigkeit, heterogener Integration, Sicherheit, Zuverlässigkeit und Herstellbarkeit. Um ihre Wirkung zu maximieren, sollten die Großen Herausforderungen zur Stärkung des Halbleiterökosystems in der gesamten Union beitragen und die Zusammenarbeit entlang der Halbleiterwertschöpfungskette, auch mit einschlägigen vertikalen Sektoren, fördern. Insbesondere sollten sie die strukturierte Zusammenarbeit zwischen Halbleiterentwicklern und Anwenderbranchen unterstützen, um einen Wettbewerbsvorteil bei Anwendungen zu erzielen, die für die technologische Souveränität und die industrielle Basis der Union unerlässlich sind. Schließlich sollten die Großen Herausforderungen über bestehende Infrastrukturen, einschließlich Pilotanlagen, hinweg die Integration und Abstimmung der Anstrengungen weiter gewährleisten und ihre Ausrichtung auf die industrielle Anwendung fördern. Sie sollten den Transfer, die Ausreifung und die industrielle Einführung von Technologien erleichtern, die im Rahmen der Initiative „Chips für Europa 2.0“ entwickelt werden, einschließlich Tätigkeiten in Verbindung mit der Prototypentwicklung, Erprobung, Validierung, Demonstration, der industriellen Ersteinführung und Integration in Produktionsumgebungen.

<a id="rec-27"></a>
(27) Die Kompetenzzentren sollten dazu beitragen, den Vorsprung der Union in der Chipforschung, -entwicklung und -innovation sowie bei den Entwurfsfähigkeiten aufrechtzuerhalten. Die Förderung des Potenzials und der Fähigkeiten von Menschen durch Bildungsmaßnahmen in den Bereichen Mathematik, Informatik, Naturwissenschaften und Technik bis zur postdoktoralen Ebene ist für die Verwirklichung dieses Ziels von entscheidender Bedeutung. Insbesondere sollten die Kompetenzzentren Dienstleistungen für die Interessenträger im Halbleiterbereich, einschließlich Start-ups und KMU, erbringen. Beispiele hierfür sind die Erleichterung des Zugangs zu Pilotanlagen und zur virtuellen Entwurfsplattform, die Bereitstellung von Schulungen und Kompetenzentwicklung, die Unterstützung bei der Suche nach Investoren, die Nutzung vorhandener lokaler Kompetenzen oder die Kontaktaufnahme zu den einschlägigen vertikalen Strukturen. Die Dienstleistungen sollten offen, transparent und nicht diskriminierend erbracht werden. Jedes Kompetenzzentrum sollte an das europäische Netz der Kompetenzzentren für Halbleiter angeschlossen sein, ihm angehören und als Zugangspunkt zu anderen Knotenpunkten des Netzes dienen. In diesem Zusammenhang sollten größtmögliche Synergien mit bestehenden ähnlichen Strukturen, wie den Europäischen digitalen Innovationszentren, die im Rahmen des mit der Verordnung (EU) 2021/694 des Europäischen Parlaments und des Rates^(36) eingerichteten Programms Digitales Europa geschaffen wurden, angestrebt werden. So könnten die Mitgliedstaaten beispielsweise ein bestehendes Europäisches digitales Innovationszentrum mit Schwerpunkt auf Halbleitern für die Zwecke der vorliegenden Verordnung als Kompetenzzentrum benennen, sofern nicht gegen das Verbot der Doppelfinanzierung verstoßen wird.

<a id="rec-28"></a>
(28) Um den Zugang zu technischer Sachkenntnis zu erleichtern und die Verbreitung von Fachwissen in der gesamten Union sowie die Unterstützung verschiedener Qualifikationsinitiativen sicherzustellen, sollte das im Zuge der Initiative „Chips für Europa“ eingerichtete Netz von Kompetenzzentren auch im Rahmen der Initiative „Chips für Europa 2.0“ weiter gefördert werden. Zu diesem Zweck sollte das mit der Verordnung (EU) 2021/2085 des Rates^(37) eingerichtete Gemeinsame Unternehmen für Chips das Verfahren für die Fortsetzung der Unterstützung von Kompetenzzentren festlegen, einschließlich der Auswahlkriterien sowie weiterer Einzelheiten zur Durchführung der in dieser Verordnung genannten Aufgaben und Funktionen. Die Kompetenzzentren, die das Netz bilden, sollten vom Gemeinsamen Unternehmen für Chips ausgewählt werden und bei der Festlegung ihrer Organisation, Zusammensetzung und Arbeitsmethoden über weitgehende generelle Autonomie verfügen. Ihre Organisation, Zusammensetzung und Arbeitsmethoden sollten jedoch die Ziele dieser Verordnung einhalten und zu ihnen beitragen.

<a id="rec-29"></a>
(29) Die von der Union geleistete Arbeit im Bereich Kompetenzen und Bildung ist von grundlegender Bedeutung für das weitere Wachstum des Halbleiterökosystems der Union. Zu diesem Zweck sollten der Strategieplan für die Bildung in MINT-Fächern^(38) und dessen Maßnahmen genutzt werden, und Initiativen wie der Kompetenzpakt^(39), Kompetenzakademien^(40), gemeinsame europäische Studienprogramme^(41), die Initiative für die Portabilität von Kompetenzen^(42) und die europäischen Hochschulallianzen^(43) sollten zur Entwicklung spezifischer Maßnahmen für den Halbleitersektor beitragen. Ebenso sollten Synergien mit Initiativen wie dem EU-Talentpool^(44), die die internationale Anwerbung erleichtern, geprüft werden, um Fachkräfte aus Drittstaaten für die Union zu gewinnen.

<a id="rec-30"></a>
(30) Der Zugang zu öffentlich finanzierten Infrastrukturen wie Pilot- und Testanlagen sowie zu den Kompetenzzentren sollte einem breiten Spektrum von Anwendern offenstehen und sollte großen Unternehmen auf transparente Weise, nicht diskriminierend und zu Marktbedingungen (oder auf Kostenbasis zuzüglich einer angemessenen Marge) gewährt werden, während KMU und akademische Einrichtungen bevorzugten Zugang oder Preisnachlässe erhalten können, sodass eine breitere Beteiligung an der Halbleiterinnovation erleichtert wird sowie die Entwicklung und Verbreitung industrieller Fähigkeiten in der gesamten Union unterstützt werden. Darüber hinaus sollten die Forschungs- und Innovationstätigkeiten im Rahmen der Initiative „Chips für Europa 2.0“, einschließlich Technologieinfrastrukturen, auch dem Verteidigungssektor zugutekommen, unbeschadet weiterer Tätigkeiten zur Entwicklung von Verteidigungsgütern und -technologien, die im Rahmen der Verordnung (EU) 2025/2643 stattfinden können.

<a id="rec-31"></a>
(31) Der Erfolg der Initiative „Chips für Europa 2.0“ kann daher nur auf gemeinsamen Anstrengungen der Mitgliedstaaten und der Union aufbauen, um die beträchtlichen Kapitalkosten mitzutragen, die Verfügbarkeit von Ressourcen für virtuellen Entwurf, Tests und Pilotprojekte auszuweiten sowie die Verbreitung von Fachwissen, Fertigkeiten und Kompetenzen zu unterstützen. Angesichts des besonderen Charakters der betreffenden Maßnahmen sollten die Ziele der Initiative „Chips für Europa 2.0“, insbesondere die Tätigkeiten im Rahmen des „Chip-Fonds“, gegebenenfalls auch durch eine Mischfinanzierungsfazilität im Rahmen des Fonds „InvestEU“ unterstützt werden. Die Unterstützung im Rahmen der Initiative „Chips für Europa 2.0“ sollte genutzt werden, um Marktversagen oder suboptimale Investitionsbedingungen infolge der hohen Kapitalintensität, des hohen Risikos und der komplexen Struktur des Halbleiterökosystems auf verhältnismäßige, kosteneffiziente Weise auszugleichen, wobei die Maßnahmen weder private Finanzierung duplizieren oder verdrängen noch den Wettbewerb im Binnenmarkt verfälschen sollten. Die Maßnahmen sollten einen klaren Mehrwert für die gesamte Union aufweisen.

<a id="rec-32"></a>
(32) Darüber hinaus sollte die Initiative „Chips für Europa 2.0“ weiterhin auf der soliden Wissensgrundlage aufbauen und Synergien mit Maßnahmen stärken, die derzeit von der Union und den Mitgliedstaaten durch Programme sowie durch Forschungs- und Innovationsmaßnahmen im Bereich der Halbleiter und der Entwicklung von Teilen der Wertschöpfungskette unterstützt werden, insbesondere durch Horizont Europa und das Programm Digitales Europa, mit dem Ziel, die Union als weltweiten Akteur auf dem Gebiet der Halbleitertechnologie und ihrer Anwendungen zu stärken und im Einklang mit der Mitteilung der Kommission mit dem Titel „Digitaler Kompass 2030: der europäische Weg in die digitale Dekade“^(45) ihren globalen Anteil an der Fertigung zu steigern. Ferner werden voraussichtlich private Investitionen zur Ergänzung der Mittel der Initiative „Chips für Europa 2.0“ mobilisiert, um zum Erreichen der Ziele der Initiative beizutragen. Ergänzend zu diesen Tätigkeiten gäbe es im Rahmen der Initiative „Chips für Europa 2.0“ auch eine enge Zusammenarbeit mit weiteren einschlägigen Interessenträgern, unter anderem der Industrieallianz für Halbleiter.

<a id="rec-33"></a>
(33) Die Forschung und Entwicklung (FuE) in der Union ist zunehmend Praktiken ausgesetzt, die auf die Entwendung von vertraulichen Informationen, Geschäftsgeheimnissen und geschützten Daten abzielen, wie etwa Diebstahl geistigen Eigentums, erzwungene Technologietransfers und Wirtschaftsspionage. Um negative Auswirkungen auf die Interessen der Union und die Ziele der Initiative „Chips für Europa 2.0“ zu verhindern, muss ein Ansatz verfolgt werden, der sicherstellt, dass der Zugang zu wirtschaftlich sensiblen Informationen oder Ergebnissen – einschließlich Daten und Fachkenntnissen – und deren Nutzung, die Sicherheit und die Übertragung des Eigentums an Ergebnissen sowie durch Rechte des geistigen Eigentums geschützte Inhalte, die in Verbindung mit von der Initiative „Chips für Europa 2.0“ unterstützten Tätigkeiten oder als Ergebnis davon generiert werden, geschützt werden. Um diesen Schutz zu gewährleisten, sollten alle durch die Initiative „Chips für Europa 2.0“ unterstützten und aus den Programmen Horizont Europa und Digitales Europa sowie deren Nachfolgern im Zuge künftiger mehrjähriger Finanzrahmen finanzierten Maßnahmen den einschlägigen Bestimmungen dieser Programme entsprechen, zum Beispiel in Bezug auf die Teilnahme von Einrichtungen mit Sitz in mit dem Programm assoziierten Drittländern, Finanzhilfevereinbarungen, Eigentum und Schutzrechte, Sicherheit, Nutzung und Verbreitung, Übertragung und Lizenzierung sowie Zugangsrechte. Bei der Durchführung dieser Programme können bestimmte Bestimmungen festgelegt werden, insbesondere in Bezug auf die Beschränkungen von Übertragungen und Lizenzierungen gemäß Artikel 40 Absatz 4 der Verordnung (EU) 2021/695 und auf die Beschränkung der Teilnahme von Rechtsträgern mit Sitz in bestimmten assoziierten oder sonstigen Drittländern aufgrund von strategischen Vermögenswerten, Interessen, der Autonomie oder Sicherheitsgründen der Union und ihrer Mitgliedstaaten gemäß Artikel 22 Absatz 5 der Verordnung (EU) 2021/695 und gemäß Artikel 12 Absatz 6 der Verordnung (EU) 2021/694. Darüber hinaus sollten die Behandlung wirtschaftlich sensibler Informationen, die Sicherheit, die Vertraulichkeit sowie der Schutz von Geschäftsgeheimnissen und von Rechten des geistigen Eigentums den Rechtsvorschriften der Union, einschließlich der Richtlinien 2004/48/EG und (EU) 2016/943^(46) des Europäischen Parlaments und des Rates und dem nationalen Recht unterliegen. Die Kommission und die Mitgliedstaaten können Technologietransfers aufgrund von Sicherheitsinteressen der Union und nationalen Sicherheitsinteressen im Zusammenhang mit Investitionen in Anlagen, die in den Anwendungsbereich dieser Verordnung fallen, gemäß der Verordnung (EU) 2019/452 des Europäischen Parlaments und des Rates schützen.

<a id="rec-34"></a>
(34) Damit in allen industriellen Wertschöpfungsketten vermehrt in der Union entworfene und/oder in der Union hergestellte Halbleiter verwendet werden, ist es erforderlich, engere Verbindungen zwischen dem Halbleiterangebot und der nachgelagerten industriellen Halbleiternachfrage zu fördern und dabei gleichzeitig die Kohärenz mit den internationalen Verpflichtungen und den Wettbewerbsvorschriften der Union zu wahren. Insbesondere sollte eine verstärkte Koordinierung zwischen Anbietern und Anwendern von Halbleitertechnik die Ermittlung der Gesamtnachfrage, die Entwicklung gemeinsamer technischer Anforderungen und die Entwicklung von Lösungen, die auf die Bedürfnisse der Industrie in der Union zugeschnitten sind, erleichtern. Eine solche Koordinierung ist besonders wichtig in Schlüsselsektoren wie Cloud-Computing, Automobilindustrie, Luftfahrt, Telekommunikation, Verteidigung und Robotik, die durch hohe Anforderungen an Leistung, Sicherheit, Zuverlässigkeit und Energieeffizienz geprägt sind und in denen Halbleiter eine wichtige grundlegende Technologie für Innovation, digitalen Wandel und strategische Autonomie darstellen. In diesen Sektoren kann eine frühzeitige Einbeziehung der Anwender schon in der Entwurfs- und Entwicklungsphase die Zeit bis zur Marktreife erheblich verkürzen, die Systemintegration verbessern und sicherstellen, dass Halbleiterlösungen ihren Zweck erfüllen und auf sich wandelnde Industriestandards und betriebliche Einschränkungen abgestimmt sind. Zu diesem Zweck sollte die Kommission in Zusammenarbeit mit den Mitgliedstaaten und den einschlägigen Interessenträgern die notwendigen Voraussetzungen dafür schaffen, dass die Industrieallianz für Halbleiter die industrielle Kontaktvermittlung, gemeinsame Entwurfstätigkeiten und Kooperationsinitiativen, auch über ein Nachfrageforum, erleichtert, um im Einklang mit den Wettbewerbsvorschriften der Union und in einer Weise, die mit den internationalen Verpflichtungen der Union im Einklang steht, eine Brücke zwischen Angebot und Nachfrage zu schlagen, Innovationsökosysteme zu fördern und die Einführung von Halbleiterlösungen in der Union zu beschleunigen. Bei Halbleitern, die im Verteidigungssektor und in der Weltraumwirtschaft verwendet werden, die hochspezialisiert sind und in extremen und feindseligen Umgebungen zuverlässig funktionieren müssen, sollte die Kommission die Tätigkeiten im Rahmen der EU-Beobachtungsstelle für kritische Technologien für Weltraum und Verteidigung weiterhin koordinieren.

<a id="rec-35"></a>
(35) In der Weltraumwirtschaft und im Verteidigungssektor werden die Tätigkeiten zur Ermittlung von Lücken, Schwachstellen und Bedürfnissen im Rahmen der bereits eingerichteten EU-Beobachtungsstelle für kritische Technologien (OCT) fortgesetzt. Spezifische Technologiefahrpläne der EU für Weltraum und Verteidigung, einschließlich Halbleiter, die auf der OCT Rechnung tragen und Forschung, Innovation und Industrialisierung abdecken, werden in das Arbeitsprogramm der EU für Weltraum- und Verteidigungsentwicklungstätigkeiten einfließen.

<a id="rec-36"></a>
(36) Das Nachfrageforum sollte es potenziellen Anwendern von Halbleitertechnologien ermöglichen, ihren Bedarf und ihre erwarteten Spezifikationen aus einer aggregierten oder branchenweiten Perspektive zu formulieren, und gleichzeitig europäische Halbleitertechnologieinitiativen und strategische Projekte in die Lage versetzen, ihre technologischen Fähigkeiten und vorgeschlagenen Lösungen vorzustellen. Maßnahmen im Zuge der Nachfragebeschleunigung sollten Kooperationsplattformen, Pilotprojekte und Entwurfspartnerschaften erleichtern und die frühzeitige Validierung und Einführung innovativer Halbleiterlösungen in der Union ermöglichen. Sie können auch zum Wachstum innovativer Ökosysteme beitragen und das Entstehen von Leitmärkten in Schlüsselsektoren begünstigen und so die industrielle Wettbewerbsfähigkeit und technologische Souveränität der Union stärken. Alle im Rahmen des Nachfrageforums und der Maßnahmen im Zuge der Nachfragebeschleunigung durchgeführten Tätigkeiten sollten in voller Übereinstimmung mit dem Wettbewerbsrecht der Union und anderen einschlägigen Bestimmungen des Unionsrechts durchgeführt werden, wobei sicherzustellen ist, dass die Zusammenarbeit zwischen Unternehmen nicht zu Wettbewerbsverzerrungen oder zum unerwünschten Austausch wirtschaftlich sensibler Informationen führt.

<a id="rec-37"></a>
(37) Um die breite Einführung von Systemen zur Integration fortgeschrittener Halbleitertechnik in der Union zu fördern, müssen gezielte Maßnahmen zur Verbesserung der Zusammenarbeit und Innovation unterstützt werden. Insbesondere kann die Erleichterung der Schaffung von Regelungen für eine grenzüberschreitende gemeinsame Beschaffung zwischen öffentlichen Auftraggebern oder Vergabestellen dazu beitragen, die Nachfrage zu bündeln, die Marktfragmentierung zu verringern und effizientere Investitionen in komplexe und kostspielige Halbleitersysteme zu ermöglichen. Gleichzeitig ist die Unterstützung der Integration und Einführung innovativer Halbleitertechnik unerlässlich, um ihre Verbreitung in Schlüsselsektoren, einschließlich digitaler Infrastruktur, künstlicher Intelligenz und industrieller Anwendungen, zu beschleunigen und so die technologische Kapazität und Wettbewerbsfähigkeit der Union zu stärken. Um die wirksame Durchführung solcher Maßnahmen zu gewährleisten, sollte die Kommission öffentlichen Auftraggebern technische und rechtliche Leitlinien an die Hand geben. Diese Leitlinien sollten öffentliche Auftraggeber bei der Anwendung von Kriterien für Versorgungssicherheit, Cybersicherheit, Resilienz, Energieeffizienz, Lebenszyklusleistung, Lieferkettentransparenz und Unionsmehrwert bei der Beschaffung von Systemen mit innovativen Halbleiterentwürfen und -lösungen im Einklang mit dem geltenden Unionsrecht und den internationalen Verpflichtungen unterstützen. Insbesondere sollten vorkommerzielle Auftragsvergabe, Innovationspartnerschaften und gemeinsame Vergabeverfahren gefördert werden, die eine frühzeitige Nachfrage nach in der Union entwickelter und/oder hergestellter vertrauenswürdiger Halbleitertechnik schaffen können.

<a id="rec-38"></a>
(38) Angesichts ihrer Bedeutung für die Gewährleistung der Versorgungssicherheit und die Schaffung eines resilienten Halbleiterökosystems sollten europäische Halbleitertechnologieinitiativen und strategische Projekte als im öffentlichen Interesse liegend betrachtet werden. Die Gewährleistung der Sicherheit der Versorgung mit Halbleitern ist auch für die Digitalisierung wichtig, die den grünen Wandel in vielen anderen Sektoren ermöglicht. Um Investitionen in den Halbleitersektor der Union anzuziehen und zur Sicherheit der Versorgung mit Halbleitern und zur Resilienz des Halbleiterökosystems der Union beizutragen, können die Mitgliedstaaten Unterstützungsmaßnahmen, einschließlich Anreize, anwenden und administrative Unterstützung in nationalen Genehmigungsverfahren für europäische Halbleitertechnologieinitiativen vorsehen. Im Mehrjährigen Finanzrahmen 2028-2034 können Pläne für nationale und regionale Partnerschaft vorbehaltlich der Bestimmungen dieser Pläne Teil der Unterstützung sein. Die Möglichkeit der Unterstützung durch die Mitgliedstaaten sollte – soweit zutreffend – die Zuständigkeit der Kommission im Bereich der staatlichen Beihilfen nach den Artikeln 107 und 108 AEUV unberührt lassen. Um die korrekte und effiziente Anwendung der Vorschriften über staatliche Beihilfen sicherzustellen, hat die Kommission in ihrer Mitteilung mit dem Titel „Ein Chip-Gesetz für Europa“^(47) bereits anerkannt, dass die Gewährung staatlicher Beihilfen für Halbleiterproduktionsanlagen auf Einzelfallbasis bewertet werden muss, um die Versorgungssicherheit der Union und die Resilienz der Lieferkette zu gewährleisten und zugleich erhebliche positive Auswirkungen auf die Wirtschaft insgesamt zu erzielen. Darüber hinaus sollten die Verfahren für die Anerkennung als europäische Halbleitertechnologieinitiativen und für die etwaige Genehmigung staatlicher Beihilfen parallel durchgeführt werden, um das Beschlussverfahren zu beschleunigen. Die Mitgliedstaaten sollten die Einrichtung europäischer Halbleitertechnologieinitiativen im Einklang mit dem Unionsrecht unterstützen. Bei der Durchführung von Unterstützungsmaßnahmen für europäische Halbleitertechnologieinitiativen sollten die Mitgliedstaaten die Festlegung von Anforderungen der Nichtdiskriminierung in Bezug auf den Schutz und die Sicherheit geistigen Eigentums, einschließlich Cybersicherheit, und die Vertraulichkeit in Erwägung ziehen und könnten Gegenmaßnahmen empfehlen, um spezifischen Risiken im Zusammenhang mit Eingriffen, erzwungenen Technologietransfers und Diebstahl geistigen Eigentums durch Einrichtungen aus Drittländern entgegenzuwirken.

<a id="rec-39"></a>
(39) Um den Aufbau der erforderlichen entsprechenden Entwurfsfähigkeiten zu fördern, können die Mitgliedstaaten solche Tätigkeiten im Einklang mit den Vorschriften über staatliche Beihilfen, einschließlich aufgrund des Rahmens für staatliche Beihilfen für Forschung, Entwicklung und Innovation^(48) oder der Verordnung (EU) Nr. 651/2014 der Kommission^(49), unterstützen.

<a id="rec-40"></a>
(40) Um den Aufbau des erforderlichen Fertigungsvermögens und der entsprechenden Entwurfsfähigkeit zu unterstützen und damit die Versorgungssicherheit in der Union sicherzustellen und die Resilienz des Halbleiterökosystems der Union zu stärken, kann eine öffentliche Unterstützung sinnvoll sein, sofern dies nicht zu Verzerrungen im Binnenmarkt führt. In diesem Zusammenhang ist es notwendig, bestimmte Bedingungen für die Durchführung spezifischer zur Verwirklichung der Ziele dieser Verordnung beitragender Projekte durch Akteure auf Unionsebene zu harmonisieren und einen Rahmen für die Anerkennung europäischer Halbleitertechnologieinitiativen zu schaffen.

<a id="rec-41"></a>
(41) Europäische Halbleitertechnologieinitiativen sollten in der Union neuartige Fähigkeiten bereitstellen, die zur Unumgänglichkeit, zur Resilienz, zum Erfolg, zur Wettbewerbsfähigkeit und zur Versorgungssicherheit des Halbleiterökosystem der Union beitragen. Das Kriterium für die Einstufung als „neuartige“ Initiative ist, dass mit dieser ein innovatives Element in Bezug auf die Fertigungsprozesse oder das Endprodukt in den Binnenmarkt eingeführt wird, das auf neuen oder bestehenden, auch ausgereiften und hochmodernen Technologieknoten beruhen könnte. Eine Initiative, die eine Innovation in Bezug auf den Herstellungsprozess oder das Endprodukt bietet, die einer in der Union bereits bestehenden oder geplanten Innovation ähnelt, kann dennoch als neuartig anerkannt werden, wenn nachgewiesen werden kann, dass die Initiative erforderlich ist, um die Resilienz und Versorgungssicherheit der Union zu gewährleisten, indem übermäßige strategische Abhängigkeiten von Einfuhren aus Drittländern verringert werden. Eine solche Initiative sollte gesondert bewertet werden, wobei beispielsweise einschlägige Marktanalysen, der Grad der Konzentration der Abhängigkeiten und das Risiko der Schaffung von Überkapazitäten zu berücksichtigen sind.

<a id="rec-42"></a>
(42) Einschlägige Innovationselemente neuartiger Initiativen könnten der Technologieknoten oder das Trägermaterial sein oder aber Ansätze, die zu Verbesserungen bei der Rechenleistung oder anderen Leistungsmerkmalen, der Energieeffizienz, dem Sicherheitsniveau, der Gefahrenabwehr oder der Zuverlässigkeit sowie bei der Integration neuer Funktionen wie etwa der KI, bei der Speicherkapazität oder anderen Funktionen führen. Die Integration verschiedener Prozesse, die zu Effizienzsteigerungen führen, oder die Automatisierung von Packaging und Montage sind ebenfalls Beispiele für Innovation. In Bezug auf Umweltvorteile würden innovative Elemente eine quantifizierbare Verringerung des Energie-, Wasser- oder Chemikalienverbrauchs oder eine Verbesserung der Recyclingfähigkeit umfassen.

<a id="rec-43"></a>
(43) Damit öffentliche Investitionen in europäische Halbleitertechnologieinitiativen und strategische Projekte tatsächlich zu einer Erhöhung der Versorgungssicherheit und der Resilienz der Union führen, sollten Unternehmen, die eine Anerkennung oder Unterstützung im Rahmen dieser Verordnung beantragen, nachweisen, dass sie ihre Lieferkette so gestalten werden, dass die Abhängigkeit der Lieferkette von ausländischen Unternehmen verringert wird. Diese Informationen sollten, sofern dies für die Tätigkeiten der Initiative relevant ist, die Herkunft der wesentlichen Halbleiterfertigungsausrüstungen und -träger und Angaben zum Umfang umfassen, in dem aus Gründen der technischen Leistung eine Beschaffung von Unternehmen aus Drittländern erforderlich ist. Im Falle der Front-End- oder Back-End-Halbleiterfertigung sollten die Unternehmen auch die anderen einschlägigen vor- bzw. nachgelagerten Front-End- oder Back-End-Fertigungsprozesse angeben, die mit der Investition innerhalb und außerhalb der Union verbunden sind.

<a id="rec-44"></a>
(44) Um Investitionen in die Halbleiterfertigung zu erleichtern, sollten die Behörden die notwendigen grundlegenden Voraussetzungen für den nachhaltigen Betrieb solcher Anlagen berücksichtigen, einschließlich des Zugangs zu Energie, Wasser und anderen kritischen Infrastrukturressourcen. Im Interesse der langfristigen Resilienz und Nachhaltigkeit des Halbleiterökosystems in der Union sollte dem erwarteten Ressourcenbedarf und den mit solchen Investitionen verbundenen Umweltauswirkungen angemessen Rechnung getragen werden.

<a id="rec-45"></a>
(45) Bietet eine europäische Halbleitertechnologieinitiative Unternehmen, die vom Betreiber der Anlage unabhängig sind, Produktionskapazität an, so sollte die Initiative eine angemessene und wirksame funktionale Trennung vornehmen, umsetzen und aufrechterhalten, um einen Austausch vertraulicher Informationen zwischen der internen und der externen Produktion zu verhindern. Dies sollte für alle Informationen gelten, die in der Entwurfsphase und im Rahmen der Front-End- oder Back-End-Fertigungsprozesse erlangt werden.

<a id="rec-46"></a>
(46) Um als europäische Halbleitertechnologieinitiative eingestuft zu werden, sollte die Einrichtung der Initiative durch ein inländisches Unternehmen mittel- bis langfristig eine eindeutig positive Auswirkung auf die Halbleiterwertschöpfungskette der Union im Hinblick darauf haben, die Resilienz, Wettbewerbsfähigkeit und Innovationsfähigkeit des Halbleiter-Ökosystems, einschließlich des Wachstums von Start-ups und KMU, sicherzustellen und zum parallelen grünen und digitalen Wandel der Union beizutragen, mit Ausstrahlungseffekten über das Unternehmen oder den betreffenden Mitgliedstaat hinaus. Aus denselben Gründen sollte die Beteiligung an der Unternehmensplattform für die Halbleiterlieferkette (im Folgenden „Plattform“) für Produktionsanlagen – wie Front-End- und Back-End-Produktionsanlagen, aber auch für andere Produktionsanlagen wie zur Herstellung von Ausrüstung, Trägern oder Werkstoffen für die Halbleiterfertigung – verpflichtend sein. Diese Verpflichtung dient der Stärkung der Resilienz, Wettbewerbsfähigkeit und Innovation der Lieferketten des Halbleiterökosystems. Für die Einstufung als europäische Halbleitertechnologieinitiative können verschiedene Tätigkeiten inländischer Unternehmen in Betracht gezogen werden, die positive Ausstrahlungseffekte bewirken sollen, beispielsweise die Gewährung des Zugangs zu Fertigungsanlagen gegen eine marktübliche Gebühr, die Bereitstellung von Process Design Kits für kleinere Entwurfsunternehmen oder für die virtuelle Entwurfsplattform, die Verbreitung von Ergebnissen ihrer FuE-Tätigkeiten, die Forschungszusammenarbeit mit europäischen Universitäten und Forschungsinstituten, die Zusammenarbeit mit nationalen Behörden oder Bildungs- und Berufsbildungseinrichtungen, um zur Kompetenzentwicklung beizutragen, der Beitrag zu unionsweiten Forschungsprojekten, oder das Angebot spezieller Unterstützungsmöglichkeiten für Start-ups und KMU. Auswirkungen, die sich auf mehrere Mitgliedstaaten erstrecken, auch in Bezug auf Kohäsionsziele, sollten als einer der Indikatoren für eindeutig positive Auswirkungen einer europäischen Halbleitertechnologieinitiative auf die Halbleiterwertschöpfungskette in der Union betrachtet werden.

<a id="rec-47"></a>
(47) Um Rechtsklarheit und eine einheitliche Anwendung dieser Verordnung zu gewährleisten, müssen die Bedingungen präzisiert werden, unter denen ein Unternehmen als europäische Halbleitertechnologieinitiative anerkannt werden kann. Die Erfahrungen mit der Umsetzung des Rahmens für integrierte Produktionsstätten und offene EU-Fertigungsbetriebe gemäß der Verordnung (EU) 2023/1781 haben gezeigt, dass bei den Unternehmen und Mitgliedstaaten Unsicherheiten darüber entstanden sind, ob der Status einer Halbleitertechnologieanlage vom Erhalt öffentlicher Unterstützung abhängig ist. Daher sollte ausdrücklich klargestellt werden, dass sich ein Antrag auf einen solchen Status zwar auf eine neuartige Initiative beziehen sollte, die Gewährung des Status jedoch nicht davon abhängig gemacht werden sollte, ob dafür bereits Unterstützung oder administrative Hilfe geleistet wird. Folglich können neuartige Initiativen unabhängig davon, ob sie öffentliche Mittel empfangen, den Status einer europäischen Halbleitertechnologieinitiative erhalten, sofern sie die in dieser Verordnung festgelegten einschlägigen Anforderungen erfüllen.

<a id="rec-48"></a>
(48) Es ist wichtig, dass europäische Halbleitertechnologieinitiativen nicht der extraterritorialen Anwendung von Gemeinwohlverpflichtungen unterliegen, die von Drittländern auferlegt werden und die ihre Fähigkeit beeinträchtigen könnten, das Endprodukt ihrer Infrastruktur, Software, Dienste, Anlagen, Vermögenswerte oder Ressourcen, ihres geistigen Eigentums oder ihrer Fachkenntnisse zu nutzen oder wiederauszuführen, das sie zur Erfüllung ihrer Verpflichtungen aus dieser Verordnung benötigen, insbesondere derjenigen in Verbindung mit der Versorgungssicherheit.

<a id="rec-49"></a>
(49) Angesichts der raschen Entwicklung der Halbleitertechnologien und im Hinblick auf die Stärkung der künftigen industriellen Wettbewerbsfähigkeit der Union sollten europäische Halbleitertechnologieinitiativen in der Union in kontinuierliche Innovation investieren, um konkrete Fortschritte in der Halbleitertechnologie zu erzielen oder Technologien der nächsten Generation vorzubereiten. Solche Initiativen sollten in der Lage sein, neue Entwicklungen zu testen und zu erproben, und zwar dank ihres bevorzugten Zugangs zu den Pilotanlagen der mit der Verordnung (EU) 2023/1781 eingerichteten Initiative „Chips für Europa“ und der Initiative „Chips für Europa 2.0“, der durch im Schnellverfahren bearbeitete Anträge gewährt wird. Durch einen solchen bevorzugten Zugang sollte der effektive Zugang anderer interessierter Unternehmen, insbesondere Start-ups und KMU, zu den Pilotanlagen unter fairen Bedingungen weder ausgeschlossen noch verhindert werden. Unter Berücksichtigung der Bedeutung qualifizierter Arbeitskräfte für die Verwirklichung der Ziele dieser Verordnung sollten europäische Halbleitertechnologieinitiativen die Talentpipeline der Union durch die Entwicklung und den Einsatz von Bildungs- und Qualifizierungsmaßnahmen und durch die Ausweitung des Pools an qualifizierten Arbeitskräften unterstützen.

<a id="rec-50"></a>
(50) Um ein einheitliches und transparentes Verfahren für die Erlangung des Status einer europäischen Halbleitertechnologieinitiative zu ermöglichen, sollte die Kommission den Beschluss über die Zuerkennung dieses Status jeweils auf Antrag einzelner Unternehmen oder von Unternehmenskonsortien erlassen. Der Status sollte sowohl für die Errichtung einer neuen Halbleiterfertigungsinitiative als auch für die erhebliche Ausweitung oder innovative Umgestaltung einer bestehenden Halbleiterfertigungsinitiative gelten. Um der Bedeutung einer koordinierten und kooperativen Umsetzung der geplanten Anlage Rechnung zu tragen, sollte die Kommission gegebenenfalls bei ihrer Bewertung die Bereitschaft eines oder mehrerer Mitgliedstaaten, in dem bzw. denen der Antragsteller seine Initiative einzurichten beabsichtigt, berücksichtigen, die Einrichtung dieser Initiative zu unterstützen. Darüber hinaus könnte die Kommission bei der Bewertung der Tragfähigkeit des Geschäftsplans die Gesamtergebnisse des Antragstellers sowie das Vorliegen geeigneter Maßnahmen zum Schutz geistigen Eigentums und wirtschaftlich sensibler Informationen berücksichtigen.

<a id="rec-51"></a>
(51) Angesichts der mit der Anerkennung als europäische Halbleitertechnologieinitiative verbundenen Rechte sollte die Kommission überwachen, ob Initiativen, denen dieser Status zuerkannt wurde, die in dieser Verordnung festgelegten Anforderungen weiterhin erfüllen. Ist dies nicht mehr der Fall, so sollte die Kommission das Recht haben, den Status und die damit verbundenen Rechte zu überprüfen und diesen Status erforderlichenfalls aufzuheben. Ein etwaiger Beschluss über die Aufhebung dieses Status sollte nur nach Konsultation des Europäischen Halbleitergremiums und mit ordnungsgemäßer Begründung angenommen werden. Dementsprechend sollte das Unternehmen, das eine europäische Halbleitertechnologieinitiative betreibt, die Möglichkeit haben, proaktiv eine Überprüfung der Dauer des Status oder der Durchführungspläne zu beantragen, wenn unvorhergesehene äußere Umstände, wie etwa schwerwiegende Störungen mit unmittelbaren wirtschaftlichen Auswirkungen auf die anerkannte Initiative, Auswirkungen auf seine Fähigkeit haben könnten, die anwendbaren Kriterien zu erfüllen.

<a id="rec-52"></a>
(52) Um die technologische Souveränität, die Resilienz, die Unumgänglichkeit, die Wettbewerbsfähigkeit und den Erfolg der Union im Bereich der Halbleitertechnik zu stärken, müssen von inländischen Unternehmen durchgeführte Projekte von strategischer Bedeutung entlang der gesamten Halbleiterwertschöpfungskette ermittelt und unterstützt werden. Unbeschadet des nächsten mehrjährigen Finanzrahmens (2028-2034) sollte strategischen Projekten im Halbleiterbereich Unterstützung aus Programmen, Fonds und Instrumenten der Union im Einklang mit den in den Verordnungen zur Einrichtung dieser Fonds und Programme festgelegten Zielen gewährt werden. Insbesondere sollte diesen strategischen Projekten das Wettbewerbsfähigkeitssiegel verliehen werden, wenn sie die in der Verordnung (EU) 2026/XXX [zur Einrichtung des Europäischen Fonds für Wettbewerbsfähigkeit (ECF)] ([1]) festgelegten Bedingungen als hochwertige Projekte erfüllen, die zum Ziel des Europäischen Fonds für Wettbewerbsfähigkeit beitragen. Strategische Projekte sollten zu Zielen von gemeinsamem Unionsinteresse beitragen und die Kapazitäten der Union für Entwurf, Herstellung und Integration fortgeschrittener Halbleitertechnik stärken sowie einen klaren Unionsmehrwert und eine grenzüberschreitende Dimension aufweisen, insbesondere durch die Zusammenarbeit zwischen den Mitgliedstaaten oder durch eine koordinierte öffentliche Unterstützung. Sie sollten zur Förderung der Resilienz und Robustheit des Halbleiterökosystems der Union beitragen, unter anderem durch die Beseitigung von Engpässen, die Stärkung der Halbleiterlieferketten und die Verbesserung der Innovation und industriellen Einführung. Die Beteiligung innovativer KMU und kleiner Midcap-Unternehmen an strategischen Projekten wird unterstützt.

<a id="rec-53"></a>
(53) Sowohl strategische Projekte als auch europäische Halbleitertechnologieinitiativen sollten sich nicht nur auf hochmoderne Halbleiterknoten konzentrieren können, sondern auch auf innovative bestehende und ausgereifte Technologieknoten, wenn dies erforderlich ist, um die Wettbewerbsfähigkeit, Resilienz und Versorgungssicherheit der Union bei strategisch wichtigen Halbleitertechnologien und industriellen Anwendungen zu erhalten und auszubauen. Damit strategische Projekte wirksam zur langfristigen Wettbewerbsfähigkeit der Union beitragen, sollten solche Projekte die Entwicklung oder Einführung kritischer Kapazitäten, Technologien oder Fähigkeiten in der Union unterstützen. Dies sollte insbesondere Tätigkeiten umfassen, die strategische Abhängigkeiten verringern und die technologische Führungsposition der Union in Schlüsselsegmenten der Halbleiterwertschöpfungskette stärken, unter anderem durch die Ermöglichung, Förderung oder Sicherung kritischer Technologien und Fähigkeiten innerhalb der Union.

<a id="rec-54"></a>
(54) Werden strategische Projekte über mehrere Standorte hinweg umgesetzt, sollten sie von einem einzigen Konsortium durchgeführt werden und als integrierte Einheit funktionieren, um Kohärenz, Effizienz und eine wirksame Koordinierung der Tätigkeiten zu gewährleisten.

<a id="rec-55"></a>
(55) Angesichts des strategischen Charakters des Halbleitersektors und seiner Bedeutung für die Sicherheit sollten für die Beteiligung an strategischen Projekten angemessene Bedingungen gelten. Im Einklang mit Artikel 136 der Verordnung (EU, Euratom) 2024/2509 des Europäischen Parlaments und des Rates^(50) wäre es möglich, die Beteiligung bestimmter Einrichtungen zu beschränken oder auszuschließen, wenn dies den strategischen Vermögenswerten, den Interessen, der Autonomie oder der Sicherheit der Union zuwiderlaufen würde. Grundsätzlich sollte die Beteiligung an strategischen Projekten auf in der Union niedergelassene Rechtsträger beschränkt werden. Abweichend davon und in hinreichend begründeten Fällen kann die Beteiligung jedoch auf in Drittländern niedergelassene Rechtsträger ausgeweitet werden, sofern dies den anwendbaren Bedingungen und Garantien entspricht und den strategischen Vermögenswerten, den Interessen, der Autonomie oder der Sicherheit der Union nicht zuwiderläuft.

<a id="rec-56"></a>
(56) Um für Flexibilität zu sorgen und den technologischen Entwicklungen sowie den sich wandelnden Markterfordernissen Rechnung zu tragen, sollte in dieser Verordnung eine Liste indikativer Technologiebereiche für strategische Projekte festgelegt werden. Der Kommission sollte die Befugnis übertragen werden, diese Liste gemäß Artikel 290 AEUV zu ändern, um diese Bereiche angesichts des technologischen Wandels und der für den Halbleitersektor relevanten Marktentwicklungen zu aktualisieren. Zur Gewährleistung einer kohärenten und effizienten Ermittlung und Auswahl strategischer Projekte sollte die Kommission unter Berücksichtigung der Stellungnahme des Europäischen Halbleitergremiums vorrangige Bereiche ermitteln und eine Liste von Themen für mögliche Projekte erstellen. Die Durchführung von Maßnahmen zur Unterstützung solcher Projekte sollte gegebenenfalls über das Gemeinsame Unternehmen für Chips im Einklang mit seiner Satzung und seinen Arbeitsprogrammen erfolgen. Um die Souveränität der Union zu stärken und die Sicherheit der Versorgung mit hochmodernen Halbleitern zu gewährleisten, ist es angezeigt, vorrangig einen offenen Fertigungsbetrieb für fortgeschrittene Halbleiterfertigungsfähigkeiten in der Union Vorrang einzurichten, der gegebenenfalls auf der Grundlage des offenen Zugangs für verschiedene Nutzer betrieben werden sollte. Dieses strategische Projekt könnte durch andere strategische Projekte ergänzt werden, z. B. in den Bereichen Speicher, Entwurf und andere Halbleitertechnologien.

<a id="rec-57"></a>
(57) Das Gemeinsame Unternehmen für Chips sollte im Rahmen seines Arbeitsprogramms Maßnahmen zur Unterstützung strategischer Projekte durchführen, unter anderem durch Aufforderungen zur Einreichung von Vorschlägen im Einklang mit seinen geltenden Vorschriften. Die Vorschläge sollten nach den Verfahren und Kriterien bewertet werden, die in dem für das Gemeinsame Unternehmen für Chips geltenden Rahmen festgelegt sind. Um Effizienz zu gewährleisten und doppelte Bewertungen zu vermeiden, sollte sich die Kommission bei der Benennung strategischer Projekte auf die Ergebnisse der vom Gemeinsamen Unternehmen für Chips durchgeführten Bewertung stützen. Projekte, die für eine Finanzierung durch das Gemeinsame Unternehmen für Chips ausgewählt wurden und die in dieser Verordnung festgelegten Kriterien erfüllen, sollten für die Benennung als strategische Projekte in Betracht kommen.

<a id="rec-58"></a>
(58) Die Benennung eines Projekts als strategisches Projekt sollte das Ergebnis von Finanzierungsbeschlüssen im Rahmen des Gemeinsamen Unternehmens für Chips unberührt lassen. Projekte, die nicht für eine Unionsfinanzierung ausgewählt wurden, sollten dennoch vorbehaltlich der Zustimmung des Antragstellers den Status eines strategischen Projekts erhalten können, sodass sie die mit dem Status gemäß dieser Verordnung verbundenen Rechte genießen können und den entsprechenden Verpflichtungen unterliegen. Zu den Rechten gehören die Einbeziehung strategischer Projekte in das Nachfrageforum, der mögliche Erhalt öffentlicher und administrativer Unterstützung und der Erhalt eines Status des überwiegenden öffentlichen Interesses sowie möglicherweise eines Status der höchsten nationalen Bedeutung, der für Genehmigungsverfahren relevant ist; die Verpflichtungen umfassen diejenigen, die auch für europäische Halbleitertechnologieinitiativen gelten, wie die Beteiligung an der Unternehmensplattform für die Halbleiterlieferkette und die Verpflichtung zur Annahme vorrangiger Aufträge. Strategische Projekte sollten dieselben Rechte genießen und denselben Verpflichtungen unterliegen wie europäische Halbleitertechnologieinitiativen, sofern sie die einschlägigen Anforderungen erfüllen, damit ein kohärenter Rechtsrahmen gewahrt bleibt und sie einen möglichst großen Beitrag zu den Zielen der Union im Halbleitersektor leisten. Bei einer solchen Benennung sollte gegebenenfalls auch ihr Status als neuartige Initiative bestätigt und die Dauer dieses Status auf der Grundlage der erwarteten Lebensdauer des Projekts festgelegt werden.

<a id="rec-59"></a>
(59) Damit strategische Projekte auch weiterhin die in dieser Verordnung festgelegten Kriterien erfüllen, sollte die Kommission die Benennung eines Projekts widerrufen können, wenn diese Kriterien nicht mehr erfüllt werden oder die Benennung auf unrichtigen Informationen beruhte. Vor dem Erlass eines solchen Beschlusses sollte die Kommission sicherstellen, dass die betreffenden Unternehmen im Einklang mit dem Grundsatz der guten Verwaltungspraxis Gelegenheit zur Anhörung erhalten, und die Stellungnahme des Europäischen Halbleitergremiums berücksichtigen. Wird die Benennung eines strategischen Projekts widerrufen, so sollte dieses Projekt alle Rechte und Pflichten im Zusammenhang mit diesem Status gemäß dieser Verordnung verlieren. Solche Projekte sollten jedoch für einen begrenzten Zeitraum spezifischen Verpflichtungen im Zusammenhang mit der Versorgungssicherheit unterliegen, sofern dies in dieser Verordnung vorgesehen ist.

<a id="rec-60"></a>
(60) Um eine einfache und rasche Genehmigungserteilung zu gewährleisten, sollten die Mitgliedstaaten sicherstellen, dass die Genehmigungsverfahren für europäische Halbleitertechnologieinitiativen und strategische Projekte in einem einheitlichen Verfahren mit einer einzigen Beantragung organisiert werden. Darüber hinaus sollten die Mitgliedstaaten eine zentrale Anlaufstelle benennen, die als einzige Kontaktstelle für das Projekt dient, um eine effiziente, transparente und zeitnahe Bearbeitung der Anträge zu erleichtern und zu koordinieren.

<a id="rec-61"></a>
(61) Es ist notwendig, dass europäische Halbleitertechnologieinitiativen und strategische Projekte so schnell wie möglich eingerichtet werden, wobei der Verwaltungsaufwand auf ein Minimum zu beschränken ist. Aus diesem Grund sollten die Mitgliedstaaten Anträge im Zusammenhang mit Planung, Bau und Betrieb solcher Anlagen so zügig wie möglich bearbeiten. Um die Einführung europäischer Halbleitertechnologieinitiativen und strategischer Projekte weiter zu beschleunigen, sollten klare und verbindliche Fristen für Genehmigungsverfahren festgelegt werden. Insbesondere sollte die Gesamtdauer solcher Verfahren den festgelegten Zeitraum von zwölf Monaten ab dem Zeitpunkt des Eingangs eines vollständigen Antrags nicht überschreiten, unbeschadet kürzerer Fristen, die von den Mitgliedstaaten festgelegt werden.

<a id="rec-62"></a>
(62) Angesichts des potenziell grenzüberschreitenden Charakters europäischer Halbleitertechnologieinitiativen und strategischer Projekte sollten sich die Mitgliedstaaten nach besten Kräften um eine wirksame Zusammenarbeit und Koordinierung auf der Ebene der zuständigen Behörden, auch zwischen benannten zentralen Anlaufstellen, bemühen, um kohärente und zeitnahe Entscheidungsprozesse zu erleichtern.

<a id="rec-63"></a>
(63) Die Digitalisierung der Genehmigungsverfahren ist wichtig, um die Transparenz, Effizienz und Rechtssicherheit zu verbessern. Die Mitgliedstaaten sollten daher auf nationaler Ebene zentrale Zugangsportale einrichten, die es Antragstellern ermöglichen, ihre Anträge in einem vollständig digitalen Umfeld einzureichen und zu verwalten. Durch die Nutzung interoperabler digitaler Lösungen, einschließlich europäischer Unternehmensbrieftaschen, sollte ein sicherer Datenaustausch, die Weiterverwendung vorhandener Informationen und die nahtlose Interaktion zwischen Antragstellern und zuständigen Behörden erleichtert und gleichzeitig ein hohes Maß an Cybersicherheit und Datenintegrität gewährleistet werden. Um die Transparenz und Berechenbarkeit für die Antragsteller zu verbessern, sollte das zentrale Zugangsportal aktuelle Informationen über den Stand der Anträge, die anwendbaren Verfahren und Fristen sowie Mitteilungen über die von den zuständigen Behörden getroffenen Entscheidungen bereitstellen.

<a id="rec-64"></a>
(64) Ebenso sollten die Mitgliedstaaten zur Unterstützung von Investitionsentscheidungen und zur Verringerung von Informationsasymmetrien einschlägige Informationen über Genehmigungsverfahren, Finanzierungsmöglichkeiten, Dienstleistungen zur Unterstützung von Unternehmen und geltende regulatorische Anforderungen zentral und leicht zugänglich online zur Verfügung stellen. Sie sollten auch für eine angemessene Nutzung bestehender Studien, Genehmigungen und Zulassungen im Zusammenhang mit Planung, Bau und Betrieb europäischer Halbleitertechnologieinitiativen und strategischer Projekte sorgen, sofern dies mit dem Unionsrecht und dem nationalen Recht vereinbar ist, um Doppelarbeit in den Verwaltungsverfahren zu vermeiden und Verzögerungen zu verringern. Angesichts der strategischen Bedeutung und der zeitlichen Sensibilität europäischer Halbleitertechnologieinitiativen und strategischer Projekte sollten die Mitgliedstaaten sicherstellen, dass Verwaltungs- und Gerichtsverfahren im Zusammenhang mit der Genehmigungserteilung als dringend behandelt werden, sofern und soweit dies nach nationalem Recht vorgesehen ist, wobei die Verteidigungsrechte und die Rechte der betroffenen Personen und Gemeinschaften uneingeschränkt zu achten sind.

<a id="rec-65"></a>
(65) Mit der Verordnung (EU) [202X/XX] vom […]^(51) wird ein gemeinsamer Rahmen für die Beschleunigung von Umweltprüfungen geschaffen, um die Einführung von Schlüsseltechnologien in der Union anzukurbeln, Abhängigkeiten zu verringern und die Wettbewerbsfähigkeit zu stärken. In allen Wirtschaftszweigen sollten die Verfahren im Zusammenhang mit Umweltprüfungen für Pläne, Programme und Projekte beschleunigt und gestrafft werden, wobei gleichzeitig ein hohes Schutzniveau für die menschliche Gesundheit und die Umwelt aufrechterhalten werden sollte. In einigen Sektoren können jedoch noch schnellere Umweltprüfungen erforderlich sein. Um die Kohärenz des Rechtsrahmens für Umweltprüfungen zu gewährleisten und gleichzeitig dem zusätzlichen Beschleunigungsbedarf in bestimmten strategischen Sektoren Rechnung zu tragen, wird mit der Verordnung (EU) [202X/XX] ein spezielles Instrumentarium bereitgestellt, das auch im Rahmen der vorliegenden Verordnung genutzt werden sollte. Angesichts der wesentlichen Rolle der Halbleitertechnik bei der Verwirklichung der Klimaziele der Union durch die Einführung neuartiger, nachhaltigerer Technologien und Produktionsverfahren, die Integration von Halbleitern in Netto-Null-Technologien und ihres Beitrags zur Resilienz und wirtschaftlichen Sicherheit der Union sollten europäische Halbleitertechnologieinitiativen und strategische Projekte im Sinne der vorliegenden Verordnung auch als strategische Projekte im Sinne der Verordnung (EU) [202X/XX] gelten und ihnen sollte daher auch das mit der genannten Verordnung eingeführte spezielle Instrumentarium zugutekommen.

<a id="rec-66"></a>
(66) Im Halbleitersektor florieren Unternehmen in spezialisierten lokalen Clustern, die Investitionen anziehen, Innovationen fördern und resiliente industrielle Ökosysteme entstehen lassen können. Regionen und regionale Industriecluster spielen eine entscheidende Rolle bei der Entwicklung und Erleichterung der Schaffung solcher Ökosysteme. Es sollte ein Gütesiegel für europäische Halbleiterexzellenzregionen eingeführt werden, um Regionen in der Union zu ermitteln, anzuerkennen und zu fördern, die eine langfristige, koordinierte Strategie zur Aufnahme, Anziehung und Ausweitung von Investitionen im Zusammenhang mit Halbleitern und Halbleiterwertschöpfungsketten verfolgen. Internationale Investoren sollten in einer europäischen Halbleiterexzellenzregion das ideale Umfeld für die Entwicklung mit Halbleitern verbundener Geschäfte finden können. Ein solches Siegel sollte von der Kommission auf Antrag regionaler Behörden auf der Grundlage der Kohärenz und Glaubwürdigkeit eines Investitionsplans der Halbleiterregion und des Engagements der zuständigen Behörden verliehen werden, und der betreffende Mitgliedstaat sollte dem Antrag zustimmen, um die politische Koordinierung zwischen den verschiedenen Regierungsebenen sicherzustellen.

<a id="rec-67"></a>
(67) Antragstellende Regionen sollten einen Investitionsplan der Halbleiterregion ausarbeiten. Die in diesem Plan vorgeschlagenen Maßnahmen sollten insbesondere auf die Rahmenbedingungen zur Stärkung der Halbleiterfertigung, die FuE-Zusammenarbeit, die Kompetenzentwicklung oder auf nachhaltige Infrastrukturen ausgerichtet sein und ihre Bereitschaft signalisieren, Halbleiterinvestitionsprojekte in ihrer Region aufzunehmen.

<a id="rec-68"></a>
(68) Sobald einer Region das Siegel verliehen wird, sollte sie in den Genuss bestimmter Möglichkeiten kommen, darunter auch verstärkter Partnerschaften mit der Industrie und mit Forschungseinrichtungen, und einer größeren Attraktivität für internationale Investoren, die zuverlässige Standorte mit hohem Potenzial suchen. Anerkannte Regionen sollten sich einem Netz der europäischen Halbleiterexzellenzregionen anschließen können, das es ihnen ermöglicht, Fachwissen auszutauschen, Allianzen zu schmieden und ihre Wirkung in der gesamten Union zu verstärken. Gleichzeitig würde die internationale Anerkennung ihrer Strategien ihren Ruf als erstklassige Standorte für Halbleiterinnovationen und -investitionen stärken.

<a id="rec-69"></a>
(69) Halbleiter sind wesentliche Komponenten, die in von kritischen Einrichtungen genutzte Infrastrukturen, Ausrüstungen und Systeme eingebettet sind, einschließlich solcher, die unter die Richtlinie (EU) 2022/2555 des Europäischen Parlaments und des Rates^(52) fallen. Das Funktionieren, die Sicherheit und die Kontinuität dieser kritischen Einrichtungen hängen zunehmend von der Verfügbarkeit, Integrität und Vertrauenswürdigkeit der Halbleiterkomponenten und ihrer Lieferanten ab. Um die Anfälligkeit der Union für Lieferkettenschocks und Abhängigkeiten von wenigen Lieferanten aus Drittländern zu verringern, müssen Transparenz und Resilienz bei der Beschaffung von Halbleitern im Rahmen der Vergabe öffentlicher Aufträge für kritische Infrastrukturen und Dienstleistungen gestärkt werden. Die Vergabe öffentlicher Aufträge gemäß den Richtlinien 2014/23/EU^(53), 2014/24/EU^(54) und 2014/25/EU^(55) des Europäischen Parlaments und des Rates macht einen erheblichen Teil der Nachfrage in der Union aus und kann eine strategische Rolle bei der Förderung zuverlässiger und resilienter Halbleiterlieferketten spielen. Öffentliche Auftraggeber oder Vergabestellen, die kritische Infrastrukturen beschaffen, sollten Erwägungen der Versorgungssicherheit in den gesamten Beschaffungsprozess einbeziehen und auch berücksichtigen, wie die in die beschafften Ausrüstungen oder Systeme eingebauten Halbleiter wegen ihrer Entwurfs- und Fertigungsmerkmale einen Mehrwert für die Resilienz der Halbleiterlieferkette der Union schaffen. Diese Erwägungen lassen die Rechtsvorschriften der Union zur Cybersicherheit unberührt.

<a id="rec-70"></a>
(70) Die Aufforderung an öffentliche Auftraggeber und Vergabestellen, von den Wirtschaftsteilnehmern eine Erklärung zur Versorgungssicherheit im Hinblick auf den Bezug von Halbleitern zu verlangen, würde die Transparenz in allen Lieferketten erhöhen und eine fundierte Entscheidungsfindung in Vergabeverfahren ermöglichen, ohne einen unverhältnismäßigen Verwaltungsaufwand zu verursachen, und ließe öffentlichen Auftraggebern und Vergabestellen einen Ermessensspielraum im Hinblick darauf, ob sie eine solche Erklärung in allen Vergabeverfahren verlangen wollen. Diese Erklärung sollte erforderlichenfalls Schlüsselelemente enthalten, die eine Bewertung der Robustheit der Lieferkette ermöglichen, einschließlich der Angabe der beteiligten Unternehmen, der Vielfalt der Lieferanten, des Mehrwerts für die Resilienz der Halbleiterlieferkette der Union, der Strategien zur Erhöhung der Resilienz, z. B. durch Doppelquellenbeschaffung unter Einbeziehung inländischer Unternehmen, und der Schwachstellenbewertungen in Bezug auf potenzielle Störungen sowie gegebenenfalls einschlägiger Risikobewertungen, die gemäß dieser Verordnung durchgeführt werden. Damit Erwägungen der Resilienz, der Sicherheit und des Mehrwerts einer europäischen Lieferkette wirksam in Beschaffungsentscheidungen einbezogen werden, können öffentliche Auftraggeber und Vergabestellen in den Auftragsunterlagen Anforderungen an die Versorgungssicherheit im Zusammenhang mit der Beschaffung von Halbleitern festlegen, die in die Infrastrukturen, Ausrüstungen oder Systeme integriert werden, die Gegenstand des öffentlichen Auftrags sind. Dazu können sie technische Spezifikationen, Auswahlkriterien, Zuschlagskriterien oder Klauseln für die Auftragsausführung darin aufnehmen. Der durch die Richtlinien 2014/24/EU, 2014/25/EU und 2009/81/EG geschaffene Rahmen für die Vergabe öffentlicher Aufträge enthält Bestimmungen, die es öffentlichen Auftraggebern ermöglichen, Wirtschaftsteilnehmer auszuschließen, die sich im Zusammenhang mit der Teilnahme an einem Vergabeverfahren einer schwerwiegenden Täuschung schuldig gemacht, einschlägige Auskünfte zurückgehalten oder falsche oder irreführende Informationen übermittelt haben. Diese Bestimmungen gelten weiterhin für Vergabeverfahren, die von nationalen öffentlichen Auftraggebern durchgeführt werden und unter diese Verordnung fallen.

<a id="rec-71"></a>
(71) Da Freihandelsabkommen, Zollunionen und das WTO-Übereinkommen über das öffentliche Beschaffungswesen^(56) Verpflichtungen in Bezug auf den Zugang zu öffentlichen Aufträgen enthalten, sollten in diesem Zusammenhang Unternehmen aus Drittländern, die solche internationalen Abkommen mit der Union geschlossen haben, die diesen Zugang garantieren, als inländische Unternehmen betrachtet werden. Darüber hinaus spiegeln diese internationalen Abkommen sowie strategische Halbleiterpartnerschaften auch eine gegenseitige Verpflichtung der Union und ihrer Partner zur Sicherung internationaler Halbleiterlieferketten wider, weshalb Unternehmen aus diesen Partnerländern der Union eine Gleichstellung gegenüber inländischen Unternehmen gewährt wird.

<a id="rec-72"></a>
(72) Für die Zwecke dieser Verordnung sollten bei der Beurteilung, ob es sich bei einem Unternehmen um ein inländisches oder gleichgestelltes Unternehmen handelt oder nicht, die Eigentumsstruktur und die Kontrolle eines solchen Unternehmens berücksichtigt werden. Zur Beurteilung der Kontrolle sollten Unternehmen als von einem Drittland oder einem Rechtsträger eines Drittlands kontrolliert gelten, wenn dieses Drittland oder dieser Rechtsträger in der Lage ist, direkt oder indirekt einen bestimmenden Einfluss auf seine strategischen Entscheidungen auszuüben, und zwar insbesondere dadurch, dass es/er das Recht oder die Befugnis hat, die Mehrheit der Mitglieder des Verwaltungs-, Leitungs- oder Aufsichtsorgans des zu betreffenden Unternehmens zu bestellen oder abzuberufen; es/er allein durch die Ausübung seiner Stimmrechte die Mehrheit der Mitglieder des Verwaltungs-, Leitungs- oder Aufsichtsorgans des betreffenden Unternehmens für das laufende und das vorhergehende Geschäftsjahr bestellt hat; es/er durch eine Vereinbarung mit anderen Aktionären oder Gesellschaftern des betreffenden Unternehmens allein über die Mehrheit der Stimmrechte der Aktionäre oder Gesellschafter dieses Unternehmens verfügt; es/er das Recht hat, auf das betreffende Unternehmen aufgrund eines mit ihm geschlossenen Vertrages oder aufgrund einer in seiner Gründungsurkunde oder Satzung niedergelegten Bestimmung einen beherrschenden Einfluss auszuüben, sofern das Recht, dem das betreffende Unternehmen unterliegt, es zulässt, dass es solchen Verträgen oder Bestimmungen unterworfen wird; es/er die Befugnis hat, de facto von dem Recht zur Ausübung eines beherrschenden Einflusses über das zu bewertende Unternehmen Gebrauch zu machen, ohne dieses Recht selbst innezuhaben; es/er Nutzungsrechte an der Gesamtheit oder an Teilen des Vermögens des betreffenden Unternehmens hat; es/er die Geschäfte des betreffenden Unternehmens auf einer einheitlichen Grundlage mit Erstellung eines konsolidierten Abschlusses führt; oder es/er gesamtschuldnerisch für die finanziellen Verbindlichkeiten des betreffenden Unternehmens haftet oder für es bürgt.

<a id="rec-73"></a>
(73) Die Verordnung (EU) Nr. 654/2014 des Europäischen Parlaments und des Rates^(57) ermöglicht es der Union, Zugeständnisse oder sonstige Verpflichtungen aus internationalen Handelsübereinkünften auszusetzen oder zurückzunehmen, um auf Verstöße von Drittländern gegen internationale Handelsregeln zu reagieren, die die Handelsinteressen der Union berühren. Jede Ausübung der Rechte der Union nach der Verordnung (EU) 2021/167 sollte sich auch in der Auslegung der Definition des Begriffs „inländisches Unternehmen“ nach der vorliegenden Verordnung niederschlagen.

<a id="rec-74"></a>
(74) Zusätzlich zu den Herausforderungen im Zusammenhang mit der Sicherheit der Versorgung mit Halbleitern wird zunehmend auch auf Cybersicherheitsrisiken aufmerksam gemacht, die mit der Beschaffung kritischer Infrastrukturen, Ausrüstungen oder Systeme von bestimmten Lieferanten verbunden sind. Solche Cybersicherheitsrisiken sollten nicht in den Anwendungsbereich dieser Erklärung fallen, die von Wirtschaftsteilnehmern in Vergabeverfahren im Zusammenhang mit der Bereitstellung oder Nutzung von Halbleitern vorgelegt wird, und unterliegen dem geltenden Rechtsrahmen der Union für die Cybersicherheit. Ungeachtet dessen müssen die Wirtschaftsteilnehmer die einschlägigen Rechtsvorschriften der Union zur Cybersicherheit einhalten und im Einklang mit damit handeln.

<a id="rec-75"></a>
(75) Angesichts der Komplexität und des sich wandelnden Charakters der Halbleiterlieferketten sollte die Kommission in Abstimmung mit dem Europäischen Halbleitergremium und einschlägigen Interessenträgern aus der Industrie erforderlichenfalls Empfehlungen abgeben, in denen spezifische Infrastrukturen, Ausrüstungen oder Systeme aufgeführt werden, für die die Lieferkettenresilienz angesichts potenzieller Risiken in der Lieferkette besonders wichtig ist, und diese Empfehlungen sollten von öffentlichen Auftraggebern und Vergabestellen bei der Vorbereitung und Durchführung von Vergabeverfahren berücksichtigt werden, um so eine einheitliche Umsetzung in der gesamten Union zu unterstützen.

<a id="rec-76"></a>
(76) Um Flexibilität zu wahren und unangemessene Einschränkungen der Vergabeverfahren zu vermeiden, sollte es öffentlichen Auftraggebern und Vergabestellen gestattet sein, die Anforderung in Bezug auf Doppelquellenbeschaffung, an denen inländische Unternehmen beteiligt sind, in hinreichend begründeten Fällen nicht anzuwenden, unter anderem wenn es an Wettbewerb mangelt, keine geeigneten Bieter vorhanden sind oder ihre Beauftragung zu unverhältnismäßigen Kosten oder technischen Unvereinbarkeiten führen würde. Solche Ausnahmen sollten eng ausgelegt und transparent angewandt werden, damit die Ziele der Stärkung der Resilienz der Halbleiterlieferkette und der Gewährleistung des Funktionierens kritischer Einrichtungen nicht untergraben werden.

<a id="rec-77"></a>
(77) Um die wirksame und kohärente Anwendung von Maßnahmen zur Stärkung der Resilienz und Sicherheit der Halbleiterversorgung bei der Vergabe öffentlicher Aufträge sicherzustellen, kann die Kommission Leitlinien herausgeben und die Koordinierung zwischen den einschlägigen Akteuren erleichtern. Diese Leitlinien sollten die Verwendung von Empfehlungen zur Ermittlung von Infrastrukturen, Ausrüstungen oder Systemen, für die eine Halbleiterversorgung durch inländische Unternehmen besonders relevant ist, sowie die Erstellung und Bewertung von Erklärungen zur Versorgungssicherheit unterstützen, einschließlich Elementen im Zusammenhang mit der Kartierung der Lieferkette, dem Anteil der beteiligten inländischen Unternehmen, Resilienzstrategien wie Doppelquellenbeschaffung sowie Schwachstellen- und Risikobewertungen. Die Leitlinien sollten auch die Anwendung gemeinsamer Methoden für die Bewertung von Lieferkettenrisiken erleichtern, insbesondere in Sektoren, die größere Schwachstellen aufweisen, und den Austausch bewährter Verfahren und einschlägiger Informationen fördern, um ein kohärentes Vorgehen in der gesamten Union zu gewährleisten und das wirksame Funktionieren des Binnenmarkts zu unterstützen.

<a id="rec-78"></a>
(78) Um die Transparenz zu erhöhen und die Sicherheit der Versorgung mit Halbleitern in kritischen Sektoren zu gewährleisten, muss die Möglichkeit weiterer Maßnahmen der Union vorgesehen werden, sofern die ermittelten Risiken nicht angemessen beseitigt werden. Kommt die Kommission nach Konsultation des Europäischen Halbleitergremiums zu dem Schluss, dass die den öffentlichen Auftraggebern oder Vergabestellen empfohlenen Maßnahmen zur Bewältigung dieser Risiken unzureichend sind, so sollte sie befugt sein, Durchführungsbeschlüsse darüber zu erlassen, welche Behörden von den Wirtschaftsteilnehmern für welche Verfahren und Produkte die Vorlage einer Erklärung zur Versorgungssicherheit verlangen sollen.

<a id="rec-79"></a>
(79) In der Halbleiterlieferkette treten Störungen auf, die bestimmte nachgelagerte Sektoren wirtschaftlich schädigen können. Kritische Sektoren im Zusammenhang mit der öffentlichen Sicherheit, wie z. B. Energieversorgung, Verteidigung oder öffentliche Verwaltung, aber auch Sektoren, in denen Halbleiter einen großen Prozentsatz des Werts des Endprodukts ausmachen, wie die Automobilindustrie, Rechenzentren oder die industrielle Automatisierung, sind für Störungen in den Halbleiterlieferketten besonders anfällig. Daher sollte die Kommission die Möglichkeit haben, sie als risikoanfällige Sektoren einzustufen.

<a id="rec-80"></a>
(80) Um klarzustellen, welche Informationen aufgenommen werden müssen, sollte die Kommission gegebenenfalls methodische Leitlinien für die Durchführung von Risikobewertungen herausgeben, die sich mit der Schaffung einer Strategie für die Doppelquellenbeschaffung, der Kartierung vor- und nachgelagerter Lieferketten sowie der Schwachstellenanalyse und der Anfälligkeit für Lieferstörungen befassen. Zu diesem Zweck kann die Kommission methodische Empfehlungen für die Durchführung von Risikobewertungen für diese Sektoren abgeben.

<a id="rec-81"></a>
(81) Um ein hohes Maß an Resilienz in der Halbleiterlieferkette der Union zu gewährleisten, muss die Möglichkeit weiterer Maßnahmen der Union vorgesehen werden, sofern die ermittelten Risiken nicht angemessen beseitigt werden. Kommt die Kommission nach Konsultation des Europäischen Halbleitergremiums zu dem Schluss, dass die empfohlenen Maßnahmen zur Bewältigung dieser Risiken unzureichend sind, sollte sie befugt sein, Durchführungsbeschlüsse zu erlassen, in denen geeignete Risikominderungsmaßnahmen festgelegt werden. Diese Maßnahmen können, sofern dies gerechtfertigt und verhältnismäßig ist, Anforderungen an die Diversifizierung der Versorgungsquellen, darunter durch Doppelquellenbeschaffung, oder den Aufbau strategischer Vorräte vorsehen. Sie sollten zielgerichtet und verhältnismäßig sein und den Besonderheiten der betreffenden Sektoren und Unternehmen sowie der Notwendigkeit, das Funktionieren des Binnenmarkts zu bewahren und unnötigen Verwaltungsaufwand zu vermeiden, Rechnung tragen. Die Bewertung der Risiken für die Halbleiterlieferkette sollte auf objektiven und zuverlässigen Nachweisen beruhen. Zu diesem Zweck sollte die Kommission unter anderem öffentlich zugängliche Informationen, im Rahmen von Auskunftsersuchen erhobene Daten sowie Hinweise auf wiederholte oder anhaltende Störungen der Lieferkette berücksichtigen. Durch die Verwendung solcher Nachweise sollte sichergestellt werden, dass alle ergriffenen Maßnahmen fundiert, transparent und den ermittelten Risiken angemessen sind, wobei die Vertraulichkeit sensibler Geschäftsinformationen zu wahren ist.

<a id="rec-82"></a>
(82) Im Interesse der Kontinuität der Versorgung und der Zuverlässigkeit sind öffentliche Auftraggeber und Vergabestellen befugt, Risikobewertungen der Halbleiterlieferketten von Wirtschaftsteilnehmern anzufordern, die an öffentlichen Vergabeverfahren oder anderen öffentlichen Finanzierungsverfahren teilnehmen, die risikoanfällige Sektoren betreffen.

<a id="rec-83"></a>
(83) Das Ziel einer strategischen Kartierung des Halbleitersektors sollte darin bestehen, eine Analyse der Stärken und Schwächen der Union in den globalen Halbleitersektoren vorzulegen, um eine Grundlage für Maßnahmen zur Gewährleistung der Versorgungssicherheit und Resilienz des Halbleiterökosystems der Union zu schaffen. Zu diesem Zweck sollten bei der strategischen Kartierung Faktoren wie etwa Schlüsselprodukte und kritische Infrastrukturen im Binnenmarkt, die von der Versorgung mit Halbleitern abhängen, wesentliche Anwenderbranchen und deren derzeitiger und erwarteter Bedarf, Schlüsselsegmente der Halbleiter-Lieferkette der Union, technologische Merkmale, Abhängigkeiten von Technologien und Anbietern aus Drittländern sowie Engpässe des Halbleitersektors der Union, der derzeitige und erwartete Bedarf an Kompetenzen und der Zugang zu qualifizierten Arbeitskräften aufbauend auf der Arbeit der im Rahmen der Union der Kompetenzen eingerichteten Europäischen Beobachtungsstelle für Kompetenzen und gegebenenfalls die potenziellen Auswirkungen der Maßnahmen des Notfallinstrumentariums ermittelt werden. Die strategische Kartierung sollte auf öffentlich und kommerziell verfügbaren Daten beruhen.

<a id="rec-84"></a>
(84) Um Vorsorge im Hinblick auf künftige Störungen in den verschiedenen Stufen der Halbleiterwertschöpfungskette in der Union und des Handels innerhalb der Union zu treffen, sollte die Kommission mit Unterstützung des Europäischen Halbleitergremiums und auf der Grundlage der Ergebnisse der strategischen Kartierung eine Liste von Frühwarnindikatoren ermitteln und erarbeiten. Solche Indikatoren könnten sich beziehen auf atypische Verlängerungen der Vorlaufzeit, auf die Verfügbarkeit von Rohstoffen, Zwischenprodukten und Humankapital, die für die Fertigung von Halbleitern benötigt werden, oder von geeigneter Fertigungsausrüstung, auf die prognostizierte Nachfrage nach Halbleitern auf dem Unionsmarkt und den Weltmärkten, auf Preissteigerungen, die über die normalen Preisschwankungen hinausgehen, auf Auswirkungen von Unfällen, Angriffen, Naturkatastrophen oder anderen schwerwiegenden Ereignissen, auf Auswirkungen von handelspolitischen Maßnahmen, Zöllen, Ausfuhrbeschränkungen, Handelshemmnissen und anderen handelsbezogenen Maßnahmen sowie auf die Auswirkungen von Unternehmensschließungen, Standortverlagerungen oder Übernahmen wichtiger Marktakteure. Die Überwachungstätigkeiten der Kommission sollten sich auf diese Frühwarnindikatoren konzentrieren.

<a id="rec-85"></a>
(85) Aufgrund der komplexen, sich rasch weiterentwickelnden und miteinander verflochtenen Halbleiterwertschöpfungsketten, an denen verschiedene Akteure beteiligt sind, ist ein koordinierter Ansatz für die Überwachung erforderlich, um die Fähigkeit zur Minderung von Risiken zu verbessern, die die Versorgung mit Halbleitern nachteilig beeinflussen können, und um das Verständnis der Dynamik der Halbleiterwertschöpfungskette zu verbessern. Die Kommission sollte die Halbleiterwertschöpfungskette in Abstimmung mit dem Europäischen Halbleitergremium überwachen und dabei den Schwerpunkt auf Frühwarnindikatoren legen und bewährte Verfahren für die Risikominderung und mehr Transparenz in der Halbleiterwertschöpfungskette ermitteln, sodass dies keinen übermäßigen Verwaltungsaufwand für Unternehmen, insbesondere kleine Midcaps und KMU, darstellt. Einschlägige Erkenntnisse, einschließlich Informationen einschlägiger Interessenträger und Industrieverbände, sollten dem Europäischen Halbleitergremium übermittelt werden, um einen regelmäßigen Informationsaustausch mit dem Gremium und die Einbeziehung der Informationen in eine Übersicht für die Überwachung der Halbleiterwertschöpfungsketten zu ermöglichen.

<a id="rec-86"></a>
(86) Die Unternehmensplattform für die Halbleiterlieferkette (im Folgenden „Plattform“) sollte ein digitaler Zwilling der Halbleiterlieferkette sein, um die Transparenz der Lieferkette zu erhöhen und die Unternehmen besser zu informieren, um so ihre Resilienz zu erhöhen. Es sollte sich um eine von der Industrie geleitete Maßnahme handeln, die den beteiligten Unternehmen zugutekommt, indem sie ihre Widerstandsfähigkeit gegenüber Störungen der Halbleiterlieferkette verbessert und ihre Marktforschungskosten senkt. Die Ergebnisse aus der Plattform sind ein Mehrwert, der den Unternehmen Anreize bieten soll, sich der Plattform anzuschließen und hochwertige Eingabedaten bereitzustellen. Zu diesen Ergebnissen können Anleitungen eines unabhängigen Dritten auf der Grundlage von Marktanalysen, aber auch aggregierte Erkenntnisse über Risiken in der Halbleiterlieferkette, Ergebnisse von Stresstests der Halbleiterlieferkette, Frühwarnungen und Anleitungen für proaktive Maßnahmen gehören, deren alleiniger Zweck darin besteht, die Risikominderung in der Halbleiterlieferkette zu verbessern. Die Beteiligung an der Plattform sollte Unternehmen dazu anregen, proaktiv Maßnahmen zu ergreifen, um ihre Lieferkettenresilienz ohne Eingreifen des öffentlichen Sektors zu verbessern. Für die Kommission würde ein proaktiver und resilienter Privatsektor dafür sorgen, dass das Risiko der Aktivierung der Krisenstufe und des Einsatzes des Notfallinstrumentariums sinkt.

<a id="rec-87"></a>
(87) Die Kommission sollte im Wege einer Aufforderung zur Einreichung von Vorschlägen die Anschubfinanzierung für die Plattform bereitstellen, ihre Einrichtung unterstützen und die Einrichtungskosten decken. In der Aufforderung sollten lediglich Mindestanforderungen festgelegt werden, ohne dass bestimmte technische Lösungen oder genaue Anforderungen an die Datenerhebung vorgeschrieben werden. Es sollte dem Begünstigten der Aufforderung zur Einreichung von Vorschlägen und den beteiligten Unternehmen obliegen, ein Finanzierungsmodell auf der Grundlage eines Geschäftsszenarios umzusetzen, sodass sich die Plattform mittelfristig selbst tragen kann. Der Wert und die Nützlichkeit dieser Art von Plattform lässt sich am Erfolg ähnlicher Initiativen messen, die bereits auf regionaler oder internationaler Ebene oder in anderen Sektoren bestehen.

<a id="rec-88"></a>
(88) Die Plattform sollte so konzipiert werden, dass die größtmögliche Vertraulichkeit wirtschaftlich sensibler Informationen und die Einhaltung des Wettbewerbsrechts der Union [durch die Plattform] gewährleistet sind. Insbesondere sollte die Plattform angemessene Vorkehrungen treffen, um den Informationsaustausch zwischen den beteiligten Unternehmen strikt auf das zur Erreichung der in dieser Verordnung festgelegten Ziele objektiv erforderliche und verhältnismäßige Maß zu beschränken und einen wettbewerbswidrigen Austausch wirtschaftlich sensibler Informationen zwischen Wettbewerbern zu verhindern. Insofern sollten die beteiligten Unternehmen nur Zugang zu ihren eigenen Daten und zu anonymisierten aggregierten Berichten haben.

<a id="rec-89"></a>
(89) Sitzungen, Diskussionen oder Informationsaustausche zwischen beteiligten Unternehmen im Rahmen der Plattform sollten auf das zur Erreichung der Ziele der Plattform unerlässliche Maß beschränkt und angemessen dokumentiert werden. Der Austausch wirtschaftlich sensibler Informationen zwischen den Beteiligten – einschließlich Informationen über aktuelle oder künftige Preise, Kosten, Gewinnspannen, Verkaufsmengen, Produktionsmengen, Kapazitäten oder Marktanteile einzelner Unternehmen – sollte ausgeschlossen sein^(58). Die Plattform sollte so arbeiten, dass die Unabhängigkeit der beteiligten Unternehmen bei ihrer geschäftlichen Entscheidungsfindung gewahrt bleibt. Die beteiligten Unternehmen sollten weiterhin dafür verantwortlich sein, dass sie die Wettbewerbsvorschriften der Union und der Mitgliedstaaten, einschließlich des Artikels 101 AEUV, einhalten.

<a id="rec-90"></a>
(90) Die Plattform sollte die Beteiligung der wichtigsten Halbleiter-Endanwendersektoren auf der Grundlage des erheblichen Mehrwerts, den diese Beteiligung mit sich bringen wird, nachdrücklich fördern. Die Vorteile für die beteiligten Unternehmen des Endanwendersektors könnten darin bestehen, dass sie sich zunehmend ihrer eigenen Risiken in der Halbleiterlieferkette bewusst werden und so in die Lage versetzt werden, proaktive Maßnahmen zur Verwaltung der Halbleiterlieferkette zu ergreifen. Die Liste der wichtigsten Halbleiter-Endanwendersektoren sollte die derzeitigen Sektoren abbilden, die Halbleiter kaufen, um ihre Produkte entweder direkt oder indirekt mit solchen Komponenten herzustellen. Anbieter von Fertigungsdienstleistungen im Elektronikbereich und Händler sollten aufgrund ihrer wichtigen Rolle im Halbleiterökosystem der Union ebenfalls in die Liste aufgenommen werden.

<a id="rec-91"></a>
(91) Aus Sicht des öffentlichen Sektors und zur Gewährleistung eines raschen Informationsflusses im Falle von Störungen der Lieferkette sollten die zuständigen nationalen Behörden der Mitgliedstaaten eine aktualisierte Kontaktliste der in ihrem Hoheitsgebiet niedergelassenen einschlägigen Unternehmen führen, die entlang der Halbleiterlieferkette tätig sind. Diese Kontaktliste sollte es ermöglichen, geeignete Adressaten für Ersuchen um freiwillige Auskunft zu ermitteln. Die Liste sollte nicht erschöpfend sein müssen und sollte so verwendet werden, dass die geltenden Vertraulichkeitsvorschriften vollständig eingehalten werden.

<a id="rec-92"></a>
(92) Eine Reihe von Unternehmen, die Halbleiterdienstleistungen oder -waren anbieten, sind angesichts der Zahl der Unternehmen in der Union, die auf ihre Produkte angewiesen sind, ihres Anteils am Unions- oder Weltmarkt, ihrer Bedeutung für die Gewährleistung eines ausreichenden Angebots oder der möglichen Auswirkungen einer Störung der Versorgung mit ihren Produkten oder Dienstleistungen als für eine wirksame Halbleiterlieferkette im Halbleiterökosystem der Union von wesentlicher Bedeutung einzuschätzen. Die Mitgliedstaaten sollten diese wichtigen Marktakteure in ihren Hoheitsgebieten in Zusammenarbeit mit der Kommission ermitteln und eine entsprechende aktualisierte Liste führen. Im Rahmen der Überwachung sollten die Mitgliedstaaten insbesondere die Integrität der von wichtigen Marktakteuren durchgeführten Tätigkeiten berücksichtigen. Solche Aspekte könnten dem Europäischen Halbleitergremium von dem betreffenden Mitgliedstaat zur Kenntnis gebracht werden.

<a id="rec-93"></a>
(93) Um die Antizipation potenzieller Engpässe zu ermöglichen, sollten die zuständigen nationalen Behörden die Kommission warnen, wenn sie Kenntnis von einem Risiko einer schwerwiegenden Störung der Versorgung mit Halbleitern erlangen oder über konkrete und zuverlässige Informationen über das Eintreten eines anderen einschlägigen Risikofaktors oder Ereignisses verfügen. Um ein koordiniertes Vorgehen sicherzustellen, sollte die Kommission in Fällen, in denen sie von einem Risiko einer schwerwiegenden Störung der Versorgung mit Halbleitern erfährt oder über konkrete und zuverlässige Informationen über das Eintreten eines anderen einschlägigen Risikofaktors oder Ereignisses verfügt, und zwar aufgrund einer Warnung oder von internationalen Partnern, eine außerordentliche Sitzung des Europäischen Halbleitergremiums einberufen, um die Schwere der Störungen und ein mögliches Einleiten des Verfahrens zur Aktivierung der Krisenstufe zu erörtern und zu prüfen, ob es angemessen, notwendig und verhältnismäßig sein könnte, dass die Mitgliedstaaten als Präventivmaßnahme eine koordinierte gemeinsame Beschaffung durchführen, sowie in einen Dialog mit Interessenträgern zu treten, um diese Präventivmaßnahmen zu ermitteln, vorzubereiten und gegebenenfalls zu koordinieren. Das Europäische Halbleitergremium und die Kommission sollten im Rahmen dieses Dialogs die Ansichten von Interessenträgern der Halbleiterwertschöpfungskette berücksichtigen. Das Europäische Halbleitergremium sollte die Kommission in der Frage beraten, ob ein präventives Auskunftsersuchen an die Plattform gerichtet werden sollte. Die Kommission sollte einschlägige Drittländer konsultieren und mit ihnen zusammenarbeiten, um Störungen der Halbleiterlieferkette unter Einhaltung der internationalen Verpflichtungen gemeinsam zu bewältigen.

<a id="rec-94"></a>
(94) Nach der Beratung durch das Europäische Halbleitergremium sollte die Kommission Auskunftsersuchen an Unternehmen und die Plattform richten können. Wie die Erfahrungen mit mehreren Störungen der Lieferkette in der Vergangenheit und die Schwierigkeiten bei der Beschaffung der für die Bewältigung dieser Störungen erforderlichen Informationen gezeigt haben, besteht der Zweck präventiver Auskunftsersuchen in der Warnstufe darin, Störungen der Lieferkette angemessen zu bewältigen, bevor die Krisenstufe aktiviert wird, und Beiträge für eine genaue Bewertung einer möglichen Halbleiterkrise zu liefern.

<a id="rec-95"></a>
(95) Bei Unternehmen, die sich aktiv an der Plattform beteiligen, sollte davon ausgegangen werden, dass sie ihrer Verpflichtung zur Informationsweitergabe an die Kommission im Falle von Störungen der Lieferkette nachgekommen sind, und sie sollten daher vor der Krisenstufe kein direktes Auskunftsersuchen erhalten. Durch ihre aktive Beteiligung an der Plattform zeigen diese Unternehmen ein starkes Engagement dafür, die Risikominderung in der Halbleiterlieferkette aktiv zu verbessern. Unternehmen, die sich aktiv an der Plattform beteiligen, sollten daher vor dem potenziellen zusätzlichen Verwaltungsaufwand, der durch die Beantwortung von Auskunftsersuchen der Kommission entsteht, geschützt werden. Die Kommission sollte dem Europäischen Halbleitergremium vor der Krisenstufe unverzüglich die wichtigsten Ergebnisse der Antworten auf Auskunftsersuchen übermitteln. Um die an der Plattform beteiligten Unternehmen vor ungebührlicher Einflussnahme aus dem Ausland abzuschirmen und Geschäftsgeheimnisse zu schützen, sollte es der Plattform unbeschadet ihrer Verpflichtungen nach Unionsrecht oder nationalem Recht untersagt sein, andere Auskunftsersuchen als die der Kommission zu beantworten.

<a id="rec-96"></a>
(96) Die Halbleiterkrisenstufe sollte aktiviert werden, wenn konkrete, schwerwiegende und zuverlässige Belege für eine solche Krise vorliegen. Eine Halbleiterkrise tritt ein, wenn schwerwiegende Störungen der Versorgung mit Halbleitern oder schwerwiegende Hemmnisse für den Handel mit Halbleitern in der Union bestehen, die zu erheblichen Versorgungsengpässen bei Halbleitern, Zwischenprodukten oder Rohstoffen oder verarbeiteten Werkstoffen führen, und wenn diese erheblichen Versorgungsengpässe die Bereitstellung, Reparatur und Wartung wesentlicher Produkte, die von kritischen Sektoren verwendet werden, z. B. medizinischer und diagnostischer Ausrüstung, in einem Ausmaß verhindern, dass das Funktionieren der kritischen Sektoren aufgrund ihrer Auswirkungen auf Gesellschaft, Wirtschaft und Sicherheit der Union ernsthaft beeinträchtigt würde.

<a id="rec-97"></a>
(97) Um eine flexible und wirksame Reaktion auf eine solche Halbleiterkrise sicherzustellen, sollte die Kommission in Fällen, in denen sie Kenntnis von einer potenziellen Halbleiterkrise erlangt, bewerten, ob die Bedingungen für die Aktivierung der Krisenstufe erfüllt sind. Ergibt diese Bewertung konkrete, schwerwiegende und zuverlässige Belege für eine Halbleiterkrise, so sollte die Kommission dem Rat unter Berücksichtigung der Stellungnahme des Europäischen Halbleitergremiums einen Vorschlag zur Aktivierung der Krisenstufe für einen im Voraus festgelegten Zeitraum von höchstens zwölf Monaten vorlegen können. Die Kommission sollte bewerten, ob die Krisenstufe verlängert oder vorzeitig beendet werden muss, und ein entsprechendes Verfahren einleiten, sofern eine solche Notwendigkeit festgestellt wird, wobei die Stellungnahme des Europäischen Halbleitergremiums zu berücksichtigen ist.

<a id="rec-98"></a>
(98) Die Synergien zwischen den gemäß Kapitel VII der Verordnung (EU) 2025/2643 eingerichteten Mechanismen für die Versorgungssicherheit und der vorliegenden Verordnung sollten dem Verteidigungssektor der Union die erforderliche Flexibilität und den erforderlichen Handlungsspielraum bieten, um zu reagieren und die Versorgungssicherheit zu gewährleisten. Insbesondere sollte die Kommission, durch ihre Möglichkeit, im Rahmen dieser Verordnung und des Kapitels VII der Verordnung (EU) 2025/2643 die Verteidigungsproduktion nach den Bestimmungen beider Verordnungen über vorrangige Aufträge zu priorisieren, darauf hinwirken, Lieferkettenstörungen im Verteidigungssektor in Krisenzeiten zu minimieren.

<a id="rec-99"></a>
(99) Aufgrund des sensiblen Charakters der Aktivierung der Krisenstufe und der möglichen Maßnahmen, die daraufhin ergriffen werden können, einschließlich der erheblichen Auswirkungen, die solche Maßnahmen auf private Unternehmen in der Union haben könnten, sollte dem Rat die Befugnis übertragen werden, in einer Halbleiterkrise einen Durchführungsrechtsakt über die Aktivierung, Verlängerung und Beendigung der Krisenstufe zu erlassen.

<a id="rec-100"></a>
(100) Während der Krisenstufe sind eine enge Zusammenarbeit zwischen der Kommission und den Mitgliedstaaten und die Koordinierung aller nationalen Maßnahmen, die in Bezug auf die Halbleiterlieferkette ergriffen werden, unerlässlich, um Störungen mit der erforderlichen Kohärenz, Resilienz und Wirksamkeit zu bewältigen. Zu diesem Zweck sollte das Europäische Halbleitergremium bei Bedarf außerordentliche Sitzungen abhalten. Alle Maßnahmen, die ergriffen werden, sollten strikt auf die Dauer der Krisenstufe beschränkt sein.

<a id="rec-101"></a>
(101) Für eine rasche, effiziente und koordinierte Reaktion der Union auf eine Halbleiterkrise ist es erforderlich, der Kommission und den Mitgliedstaaten durch das Europäische Halbleitergremium zeitnahe und aktuelle Informationen über den Verlauf der operativen Situation zur Verfügung zu stellen und sicherzustellen, dass wirksame Maßnahmen ergriffen werden können, um die Versorgung der betroffenen kritischen Sektoren mit Halbleitern zu sichern. Bei Aktivierung der Krisenstufe sollten geeignete, wirksame und verhältnismäßige Maßnahmen ermittelt und durchgeführt werden, unbeschadet einer etwaigen Fortsetzung der internationalen Zusammenarbeit mit einschlägigen Partnern im Hinblick auf die Abmilderung der sich wandelnden Krisensituation. Gegebenenfalls sollte die Kommission Unternehmen entlang der Halbleiterlieferkette um Auskunft ersuchen. Darüber hinaus sollte die Kommission, sofern erforderlich und verhältnismäßig, europäische Halbleitertechnologieinitiativen dazu verpflichten können, einen Auftrag zur Herstellung krisenrelevanter Produkte anzunehmen und vorrangig zu behandeln, und die Rolle einer zentralen Beschaffungsstelle übernehmen können, wenn sie von den Mitgliedstaaten damit beauftragt wird. Die Kommission sollte diese Maßnahmen auf bestimmte kritische Sektoren beschränken. Das Europäische Halbleitergremium kann ebenfalls geeignete und wirksame Maßnahmen bewerten und diesbezüglich beraten. Des Weiteren kann das Europäische Halbleitergremium in Bezug auf die Notwendigkeit der Einführung von Schutzmaßnahmen gemäß der Verordnung (EU) 2015/479 des Europäischen Parlaments und des Rates^(59) beraten. Der Einsatz aller Notmaßnahmen sollte verhältnismäßig und auf das zur Bewältigung der Halbleiterkrise im besten Interesse der Union erforderliche Maß beschränkt sein. Die Kommission sollte das Europäische Parlament und den Rat regelmäßig über die ergriffenen Maßnahmen und die entsprechenden Gründe unterrichten. Die Kommission kann nach Konsultation des Europäischen Halbleitergremiums weitere Leitlinien für die Durchführung und den Einsatz der Notmaßnahmen herausgeben.

<a id="rec-102"></a>
(102) Eine Reihe von Sektoren ist für das reibungslose Funktionieren des Binnenmarkts von kritischer Bedeutung. Für die Zwecke dieser Verordnung sollten diese kritischen Sektoren in einem Anhang dieser Verordnung aufgeführt werden. Diese Liste sollte sich auf die Sektoren und Teilsektoren des Anhangs der Richtlinie (EU) 2022/2557 des Europäischen Parlaments und des Rates^(60) beschränken, unter Hinzufügung der Sektoren Verteidigung und Sicherheit aufgrund ihrer wichtigen Rolle bei der Gewährleistung wesentlicher gesellschaftlicher Funktionen. Bestimmte Maßnahmen sollten nur ergriffen werden, um die Versorgung kritischer Sektoren zu sichern. Die Kommission kann die Notmaßnahmen auf bestimmte dieser Sektoren oder auf bestimmte Teile davon beschränken, wenn die Halbleiterkrise deren Betrieb stört oder zu stören droht.

<a id="rec-103"></a>
(103) Der Zweck der Auskunftsersuchen an in der Union niedergelassene Unternehmen entlang der Halbleiterlieferkette in der Krisenstufe ist die Ermöglichung genauer Bewertungen der Halbleiterkrise oder die Ermittlung und Vorbereitung möglicher Gegen- oder Notmaßnahmen auf Unions- oder nationaler Ebene. Dies kann Informationen über das Produktionsvermögen, die Produktionskapazität und die derzeitigen Hauptstörungen und Engpässe betreffen. Dies könnte die folgenden Aspekte einschließen: den typischen und aktuellen Bestand an krisenrelevanten Produkten in den Produktionsanlagen in der Union und in Produktionsanlagen in Drittländern, in denen diese Unternehmen tätig sind, mit denen sie Verträge schließen oder von denen sie Lieferungen beziehen; die typische und aktuelle durchschnittliche Vorlaufzeit für die gängigsten hergestellten Produkte; die erwartete Produktionsleistung für die folgenden drei Monate für jede Produktionsanlage in der Union oder Gründe, die die Ausschöpfung von Produktionskapazität verhindern. Solche Informationen sollten sich auf das beschränken, was erforderlich ist, um die Art der Halbleiterkrise oder mögliche Gegen- oder Notmaßnahmen auf Unions- und nationaler Ebene zu bewerten. Auskunftsersuchen sollten nicht zur Bereitstellung von Informationen führen, deren Offenlegung den nationalen Sicherheitsinteressen der Mitgliedstaaten zuwiderläuft. Die konkreten Auskünfte, die eingeholt werden sollen, können auf der Grundlage vorheriger Antworten auf vor der Krise gestellte Auskunftsersuchen oder einer Stellungnahme einer repräsentativen Zahl einschlägiger Unternehmen im Rahmen einer freiwilligen Konsultation in Zusammenarbeit mit dem Europäischen Halbleitergremium erarbeitet werden. Jedes Ersuchen sollte verhältnismäßig sein, den legitimen Zielen des Unternehmens sowie den Kosten und dem Aufwand der Bereitstellung der Daten Rechnung tragen und angemessene Fristen für die Bereitstellung der verlangten Informationen setzen. Unternehmen sollten verpflichtet sein, dem Ersuchen nachzukommen, und können mit Sanktionen belegt werden, wenn sie dem Ersuchen nicht nachkommen oder unrichtige Informationen bereitstellen. Alle erlangten Informationen sollten ausschließlich für die Zwecke dieser Verordnung verwendet werden und Vertraulichkeitsvorschriften unterliegen. Um eine umfassende Einbeziehung der Mitgliedstaaten, in denen das Unternehmen seine Produktionsstätte hat, zu gewährleisten, sollte die Kommission der zuständigen nationalen Behörde unverzüglich eine Kopie des Auskunftsersuchens übermitteln und die erlangten Informationen an die zuständige nationale Behörde auf deren Ersuchen auf sicherem Wege weitergeben. Erhält ein Unternehmen im Zusammenhang mit seinen Halbleitertätigkeiten von einem Drittland ein Auskunftsersuchen, so sollte es die Kommission unterrichten, damit die Kommission bewerten kann, ob ein Auskunftsersuchen durch die Kommission gerechtfertigt ist.

<a id="rec-104"></a>
(104) Als letztes Mittel, um sicherzustellen, dass kritische Sektoren in Krisenzeiten weiterhin tätig sein können, und nur dann, wenn dies für diesen Zweck erforderlich und verhältnismäßig ist, könnten europäische Halbleitertechnologieinitiativen von der Kommission dazu verpflichtet werden, Aufträge über krisenrelevante Produkte anzunehmen und vorrangig zu behandeln. Potenzielle Begünstigte vorrangiger Aufträge sollten Einrichtungen aus kritischen Sektoren, deren Tätigkeiten aufgrund des Engpasses gestört sind oder gestört zu werden drohen, oder Unternehmen, die diese kritischen Sektoren beliefern, sein. Um sicherzustellen, dass vorrangige Aufträge nur im Bedarfsfall verwendet werden, sollten sie auf Begünstigte beschränkt werden, die nach Durchführung von Risikominderungsmaßnahmen nicht in der Lage waren, die Auswirkungen des Engpasses zu verhindern, z. B. durch ihre Vergabeverfahren, und durch andere Mittel abzufedern, z. B. durch die Nutzung bestehender Lagerbestände. Die Verpflichtung zur Annahme und vorrangigen Behandlung von Aufträgen für krisenrelevante Produkte kann auch auf strategische Projekte und Halbleiterfertigungsanlagen ausgeweitet werden, die diese Möglichkeit im Rahmen des Erhalts öffentlicher Unterstützung akzeptiert haben, wenn diese öffentliche Unterstützung darauf abzielt, die Fähigkeit zur Steigerung der Produktionskapazität zu fördern. Der Beschluss über einen vorrangigen Auftrag sollte im Einklang mit allen in der Union für die Umstände des Falls geltenden rechtlichen Verpflichtungen gefasst werden. Die Verpflichtung zur vorrangigen Behandlung sollte jeder anderen Erfüllungsverpflichtung nach privatem oder öffentlichem Recht vorgehen, wobei den legitimen Zielen des betreffenden Unternehmens sowie den Kosten und dem Aufwand jeder Änderung der Produktionsreihenfolge Rechnung getragen werden sollte. Jeder vorrangige Auftrag sollte zu einem fairen und angemessenen Preis vergeben werden. Die Berechnung dieses Preises kann auf der Grundlage der durchschnittlichen Marktpreise der vergangenen Jahre erfolgen, vorbehaltlich einer Begründung jeder Erhöhung, z. B. unter Berücksichtigung der Inflation oder eines Anstiegs der Energiekosten. Unternehmen, die ihrer Verpflichtung zur Erfüllung vorrangiger Aufträge nicht nachkommen, können mit Sanktionen belegt werden.

<a id="rec-105"></a>
(105) In Bezug auf Anlagen, die einen vorrangigen Auftrag ausführen, kann es für die Kommission, unterstützt durch das Europäische Halbleitergremium, und die Mitgliedstaaten von Vorteil sein, sich über bewährte Verfahren für die Ausführung solcher Aufträge, einschließlich bewährter Verwaltungsverfahren, auszutauschen.

<a id="rec-106"></a>
(106) Das betreffende Unternehmen sollte verpflichtet sein, einen vorrangigen Auftrag anzunehmen und vorrangig zu behandeln. Um sicherzustellen, dass vorrangige Aufträge auf die Kapazitäten und das Produktionsportfolio einer Anlage abgestimmt sind, sollte die Kommission der betreffenden Anlage Gelegenheit geben, sich zur Durchführbarkeit und zu den Einzelheiten des vorrangigen Auftrags zu äußern. Die Kommission sollte den vorrangigen Auftrag nicht erteilen, wenn die Anlage den Auftrag auch bei vorrangiger Behandlung nicht erfüllen kann, sei es aufgrund unzureichenden Produktionsvermögens, aufgrund unzureichender Produktionskapazität oder aus technischen Gründen, oder wenn das Produkt oder die Dienstleistung von der Anlage nicht bereitgestellt bzw. erbracht wird oder weil dies eine unzumutbare wirtschaftliche Belastung und eine besondere Härte für das Unternehmen darstellen würde, einschließlich eines erheblichen Risikos im Zusammenhang mit der Betriebskontinuität.

<a id="rec-107"></a>
(107) Um einen transparenten und klaren Rahmen für die Durchführung vorrangiger Aufträge zu gewährleisten, sollte der Kommission die Befugnis übertragen werden, einen Durchführungsrechtsakt zu erlassen, in dem die praktischen und operativen Modalitäten für die Durchführung vorrangiger Aufträge festgelegt werden. Dieser Durchführungsrechtsakt sollte Vorkehrungen enthalten, mit denen sichergestellt wird, dass vorrangige Aufträge im Einklang mit den Grundsätzen der Notwendigkeit und Verhältnismäßigkeit durchgeführt werden, z. B. einen Mechanismus, der bestehende Aufträge berücksichtigt, und einen Mechanismus, mit dem sichergestellt wird, dass das Volumen vorrangiger Aufträge das erforderliche Maß nicht überschreitet.

<a id="rec-108"></a>
(108) Unter dem außergewöhnlichen Umstand, dass ein entlang der Halbleiterlieferkette in der Union tätiges Unternehmen von einem Drittland ein Ersuchen zur Erfüllung eines vorrangigen Auftrags erhält, sollte das Unternehmen die Kommission über dieses Ersuchen unterrichten, damit bewertet werden kann, ob die Kommission – falls erhebliche Auswirkungen auf die Versorgungssicherheit in kritischen Sektoren bestehen und die anderen Anforderungen der Notwendigkeit, Verhältnismäßigkeit und Rechtmäßigkeit unter den Umständen des Falls erfüllt sind – ebenfalls eine Verpflichtung zur Erfüllung vorrangiger Aufträge auferlegen sollte.

<a id="rec-109"></a>
(109) Angesichts der Bedeutung, die der Gewährleistung der Versorgungssicherheit in kritischen Sektoren, die wesentliche gesellschaftliche Funktionen wahrnehmen, zukommt, sollte die Einhaltung der Verpflichtung zur Erfüllung vorrangiger Aufträge keine Haftung für Schäden gegenüber Dritten aufgrund etwaiger Verstöße gegen vertragliche Pflichten nach sich ziehen, die sich aus der notwendigen vorübergehenden Änderung der Betriebsabläufe des betreffenden Herstellers ergeben können, begrenzt auf das Ausmaß, in dem der Verstoß gegen vertragliche Pflichten für die Einhaltung der vorgeschriebenen Rangfolge erforderlich war. Unternehmen, die möglicherweise in den Anwendungsbereich vorrangiger Aufträge fallen, sollten diese Möglichkeit in den Bedingungen ihrer Geschäftsverträge vorwegnehmen. Unbeschadet der Anwendbarkeit anderer Bestimmungen sollte die Haftung für fehlerhafte Produkte gemäß der Richtlinie 85/374/EWG des Rates^(61) von diesem Haftungsausschluss unberührt bleiben. Im Einklang mit Artikel 52 Absatz 1 der Charta der Grundrechte der Europäischen Union (im Folgenden „Charta“) achtet die Verpflichtung zur vorrangigen Herstellung bestimmter Produkte den Wesensgehalt der unternehmerischen Freiheit und der Vertragsfreiheit gemäß Artikel 16 sowie des Eigentumsrechts gemäß Artikel 17 der Charta und beeinträchtigt sie nicht unverhältnismäßig.

<a id="rec-110"></a>
(110) Bei Aktivierung der Krisenstufe und zur Gewährleistung der Versorgungssicherheit in kritischen Sektoren, die wesentliche gesellschaftliche Funktionen wahrnehmen, können zwei oder mehr Mitgliedstaaten der Kommission das Mandat erteilen, die Nachfrage zu bündeln und bei der Vergabe öffentlicher Aufträge im öffentlichen Interesse im Einklang mit den geltenden Vorschriften und Verfahren der Union in ihrem Namen zu handeln, um dadurch eine Hebelwirkung für die Kaufkraft der Kommission zu erzielen. Die gemeinsame Beschaffung sollte nur zur Behebung von Störungen der Halbleiterlieferkette während einer Krise genutzt werden. Mit dem Mandat kann die Kommission ermächtigt werden, Vereinbarungen über die Beschaffung krisenrelevanter Produkte für bestimmte kritische Sektoren zu schließen. Die Kommission sollte in Abstimmung mit dem Europäischen Halbleitergremium den Nutzen, die Notwendigkeit und die Verhältnismäßigkeit jedes Antrags bewerten. Beabsichtigt die Kommission, dem Antrag nicht nachzukommen, so sollte sie die betreffenden Mitgliedstaaten und das Europäische Halbleitergremium unterrichten und die Gründe für ihre Ablehnung nennen. Die Einzelheiten des Verfahrens sollten in einer Vereinbarung zwischen der Kommission und den teilnehmenden Mitgliedstaaten festgelegt werden, in welcher die Gründe für die Verwendung des Mechanismus der gemeinsamen Beschaffung und der einzugehenden Verbindlichkeiten angegeben sind. Diese Vereinbarung kann die Zahl der zu schließenden Verträge und die Bedingungen für die gemeinsame Beschaffung, wie etwa Preise, Lieferfristen, Mengen und Opt-in- oder Opt-out-Klauseln, umfassen. Die gemeinsame Beschaffung kann zur Unterzeichnung eines einzigen Vertrags, der den Bedarf aller Mitgliedstaaten deckt, oder mehrerer Verträge, die jeweils den Bedarf eines oder mehrerer Mitgliedstaaten decken, führen. Darüber hinaus sollten die teilnehmenden Mitgliedstaaten das Recht haben, Vertreter zu benennen, die das Vergabeverfahren und die Aushandlung der Kaufvereinbarungen anleitend und beratend begleiten. Für die Einführung, die Verwendung oder den Weiterverkauf der erworbenen Produkte sollten die teilnehmenden Mitgliedstaaten zuständig bleiben.

<a id="rec-111"></a>
(111) Während einer Krise infolge von Versorgungsengpässen bei Halbleitern könnte es notwendig werden, dass die Union Schutzmaßnahmen in Betracht zieht. Das Europäische Halbleitergremium sollte Stellung nehmen können, um die Kommission bei ihrer Bewertung der Frage zu unterstützen, ob die Marktlage einen erheblichen Mangel an lebenswichtigen Gütern gemäß der Verordnung (EU) 2015/479 darstellt.

<a id="rec-112"></a>
(112) Der institutionelle Rahmen für Expertengruppen, einschließlich der Transparenzvorschriften für das Gremium und seine Untergruppen, sollte unbeschadet dieser Verordnung für das Europäische Halbleitergremium gelten. Das Europäische Halbleitergremium sollte die Kommission in Bezug auf die Entwicklung einer umfassenden Halbleiterpolitik und zu spezifischen technischen Fragen beraten und unterstützen. Diese Fragen können Folgendes umfassen: die Beratung des Rates der öffentlichen Körperschaften des Gemeinsamen Unternehmens für Chips in Bezug auf die Initiative „Chips für Europa 2.0“; den Austausch von Informationen über die Funktionsweise europäischer Halbleitertechnologieinitiativen und strategischer Projekte; die Erörterung und Vorbereitung der Ermittlung spezifischer Sektoren und Technologien mit potenziell hoher sozialer Wirkung und großer Bedeutung für die Sicherheit, für die eine Zertifizierung vertrauenswürdiger Produkte nötig ist, sowie eine koordinierte Überwachung und Krisenreaktion. Ferner sollte das Europäische Halbleitergremium die einheitliche Anwendung dieser Verordnung sicherstellen sowie die Zusammenarbeit zwischen den Mitgliedstaaten und den Informationsaustausch über Fragen im Zusammenhang mit dieser Verordnung erleichtern. Das Europäische Halbleitergremium sollte auch einen Gedankenaustausch mit der Kommission über die besten Wege, einen wirksamen Schutz und eine wirksame Durchsetzung von Rechten des geistigen Eigentums, vertraulichen Informationen und Geschäftsgeheimnissen unter gebührender Einbeziehung von Interessenträgern in Bezug auf den Halbleitersektor sicherzustellen, führen. Das Europäische Halbleitergremium sollte die Kommission in Fragen der internationalen Zusammenarbeit im Einklang mit internationalen Verpflichtungen unterstützen. Es sollte unbeschadet der Vorrechte des Europäischen Parlaments und des Rates gemäß den Verträgen als Forum für die Koordinierung der nationalen Halbleiterpolitik und einschlägiger Investitionen, das internationale Engagement und die Verbesserung der Zusammenarbeit entlang der globalen Halbleiterwertschöpfungskette dienen, wobei der Schwerpunkt insbesondere auf Programmen für Forschung, Entwicklung und Innovation (FEI) sowie auf Kompetenzaustauschprogrammen liegen sollte. Zu diesem Zweck sollte das Europäische Halbleitergremium die Standpunkte der Industrieallianz für Halbleiter und anderer Interessenträger berücksichtigen. Darüber hinaus sollte sich das Europäische Halbleitergremium mit anderen Krisenreaktions- und Krisenvorsorgestrukturen der Union abstimmen sowie mit ihnen zusammenarbeiten und Informationen austauschen, um ein kohärentes und koordiniertes Vorgehen der Union in Bezug auf Krisenreaktions- und Krisenvorsorgemaßnahmen für Halbleiterkrisen sicherzustellen.

<a id="rec-113"></a>
(113) Den Vorsitz im Europäischen Halbleitergremium sollte ein Vertreter der Kommission führen. Jeder Mitgliedstaat sollte einen hochrangigen Vertreter im Europäischen Halbleitergremium und einen Stellvertreter benennen. Sie könnten auch bis zu drei fachliche Vertreter in Bezug auf verschiedene Aufgaben des Europäischen Halbleitergremiums benennen, z. B. je nachdem, welcher Teil dieser Verordnung in den Sitzungen des Europäischen Halbleitergremiums erörtert wird. Die Mitgliedstaaten sollten sich bemühen, eine wirksame und effiziente Zusammenarbeit im Europäischen Halbleitergremium zu gewährleisten. Die Mitgliedstaaten sollten eine zentrale Anlaufstelle benennen, um einen zuverlässigen und zeitnahen Austausch von Informationen über die Arbeit des Europäischen Halbleitergremiums sicherzustellen. Um wichtige Ratschläge zu den Tätigkeiten des Europäischen Halbleitergremiums einzuholen und eine angemessene Beteiligung von Interessenträgern zu ermöglichen, sollte der Vorsitz Untergruppen einsetzen können und befugt sein, Arbeitsvereinbarungen zu treffen, indem er Experten und Beobachter zur Teilnahme an den Sitzungen auf Ad-hoc-Basis einlädt, oder Interessenträger, insbesondere Organisationen, die die Interessen der Halbleiterindustrie der Union vertreten, wie etwa die Industrieallianz für Halbleiter, als Beobachter in die Untergruppen einzuladen.

<a id="rec-114"></a>
(114) Der Vorsitz sollte den Austausch zwischen dem Europäischen Halbleitergremium und anderen Organen, Einrichtungen und sonstigen Stellen und Experten- und Beratungsgruppen der Union fördern können. Angesichts der Bedeutung der Versorgung mit Halbleitern für andere Sektoren und des sich daraus ergebenden Koordinierungsbedarfs sollte der Vorsitz sicherstellen, dass andere Organe und Einrichtungen der Union als Beobachter an den Sitzungen des Europäischen Halbleitergremiums teilnehmen, sofern dies im Zusammenhang mit dem mit dieser Verordnung eingerichteten Überwachungs- und Krisenreaktionsmechanismus relevant und angemessen ist.

<a id="rec-115"></a>
(115) Den Mitgliedstaaten sollte bei der Anwendung und Durchsetzung dieser Verordnung eine Schlüsselrolle zukommen. In diesem Zusammenhang sollte jeder Mitgliedstaat eine oder mehrere für die wirksame Durchführung dieser Verordnung zuständige nationale Behörden benennen und sicherstellen, dass diese Behörden über angemessene Befugnisse und Ressourcen verfügen. Die Mitgliedstaaten können eine oder mehrere bereits bestehende Behörden benennen. Um die Organisationseffizienz in den Mitgliedstaaten zu erhöhen und eine offizielle Anlaufstelle für die Öffentlichkeit und andere Partner auf Ebene der Union und der Mitgliedstaaten, einschließlich der Kommission und des Europäischen Halbleitergremiums, einzurichten, sollte jeder Mitgliedstaat innerhalb einer der von ihm gemäß dieser Verordnung als zuständig benannten Behörden eine nationale zentrale Anlaufstelle benennen, die für die Koordinierung von Fragen im Zusammenhang mit dieser Verordnung und die grenzübergreifende Zusammenarbeit mit den zuständigen Behörden anderer Mitgliedstaaten zuständig ist.

<a id="rec-116"></a>
(116) Die Union sollte sich bemühen, strategische Halbleiterpartnerschaften mit bestehenden oder aufstrebenden internationalen Partnern zu schließen, um die Versorgungssicherheit der Union und die Zusammenarbeit entlang der Halbleiterwertschöpfungskette zu verbessern. Diese Partnerschaften sollten auch darauf abzielen, den in der Union bestehenden Mangel an Fachwissen und Kompetenzen im Halbleiterbereich zu beheben, indem neue Talente für die Union gewonnen, mobilisiert und gehalten werden. Bei Partnern, mit denen die Union im Rahmen einer Digitalpartnerschaft, eines Handels- und Technologierates oder eines Digitaldialogs im Halbleiterbereich zusammenarbeitet, sollte die strategische Halbleiterpartnerschaft die in diesen Foren vereinbarte politische Steuerung und die dort vereinbarten Prioritäten widerspiegeln.

<a id="rec-117"></a>
(117) Um einen kohärenten Rahmen für den Abschluss künftiger strategischer Halbleiterpartnerschaften zu entwickeln und zu gewährleisten, sollten die Mitgliedstaaten und die Kommission im Rahmen ihres Zusammenwirkens im Europäischen Halbleitergremium unter anderem erörtern, ob die bestehenden Partnerschaften die angestrebten Ziele erreichen, welche Partner Priorität für neue Partnerschaften haben, welchen Inhalt diese Partnerschaften haben und welche Kohärenz und potenziellen Synergieeffekte mit anderen Rahmen der Kommission für internationale Zusammenarbeit und mit der bilateralen Zusammenarbeit der Mitgliedstaaten mit den betreffenden internationalen strategischen Partnern bestehen. Dies sollte unbeschadet der Vorrechte des Rates gemäß den Verträgen erfolgen. Die Union sollte im Einklang mit ihrer Global-Gateway-Strategie^(62) und ihrer internationalen Digitalstrategie^(63) für beide Seiten vorteilhafte Partnerschaften mit aufstrebenden Märkten und Entwicklungsländern anstreben, die zur Diversifizierung ihrer Halbleiterlieferkette beitragen und diesen internationalen strategischen Partnern einen Mehrwert bringen.

<a id="rec-118"></a>
(118) Um die strategische Autonomie und die Führungsposition der Union im Bereich der Halbleitertechnik zu stärken, sollte die Industrieallianz für Prozessoren und Halbleitertechnik aufgelöst werden, und ihre Tätigkeiten sollten von der mit dieser Verordnung eingerichteten Industrieallianz für Halbleiter (im Folgenden „Allianz“) unter Aufsicht der Kommission übernommen werden. Alle Mitglieder und Teilnehmer der bestehenden Industrieallianz für Prozessoren und Halbleitertechnik sollten automatisch Mitglieder und Teilnehmer der Allianz werden. Die Aufgabenbeschreibung, in der die Arbeitsweise, die Aufgaben und die Zusammensetzung der Allianz im Einzelnen festgelegt sind, sollte klarheitshalber auf einer Website der Kommission veröffentlicht werden^(64). Die Allianz sollte Interessenträger aus der gesamten Wertschöpfungskette, einschließlich Industrie, KMU, Forschungseinrichtungen, Wissenschaft und wichtige Anwendersektoren, zusammenbringen, um kritische Lücken in den Fähigkeiten der Union zu ermitteln und die technologischen und industriellen Fortschritte voranzutreiben, die zur Steigerung der Wettbewerbsfähigkeit erforderlich sind. Durch die Förderung von Zusammenarbeit und Innovation sollte die Allianz dazu beitragen, Abhängigkeiten zu verringern, die Resilienz der Lieferketten zu stärken und die Expansion kleinerer Akteure in der Union zu unterstützen. Um die Kohärenz mit der Halbleiterstrategie und den Prioritäten der Union zu gewährleisten und eine reibungslose und wirksame Durchführung dieser Verordnung zu erleichtern, sollte der Lenkungsausschuss der Allianz einen regelmäßigen Dialog mit dem Europäischen Halbleitergremium führen, während seine Arbeitsgruppen auf Anfrage aktuelle Informationen vorlegen können. Diese strukturierte Tätigkeit sollte es dem Ausschuss ermöglichen, Erkenntnisse der Industrie in politische Entscheidungen zu integrieren und sicherzustellen, dass die öffentlichen und privaten Anstrengungen zur Förderung der technologischen Souveränität der Union aufeinander abgestimmt bleiben.

<a id="rec-119"></a>
(119) Zur Gewährleistung einer vertrauensvollen und konstruktiven Zusammenarbeit der zuständigen Behörden auf Unions- und nationaler Ebene sollten alle an der Anwendung dieser Verordnung beteiligten Parteien die Vertraulichkeit der im Rahmen der Durchführung ihrer Tätigkeiten erlangten Informationen und Daten wahren, um insbesondere Rechte des geistigen Eigentums, sensible Geschäftsinformationen und Geschäftsgeheimnisse zu schützen. Alle Informationen, die im Rahmen der Bewerbung auf Anerkennung als europäische Halbleitertechnologieinitiative oder im Rahmen von Auskunftsersuchen oder Mitteilungspflichten gemäß dieser Verordnung erlangt werden, sollten ausschließlich für die Zwecke dieser Verordnung verwendet werden und gemäß Artikel 339 AEUV sowie den internen Vorschriften der Kommission über den sicheren Umgang mit Daten, insbesondere dem Beschluss (EU, Euratom) 2015/443 der Kommission^(65), unter das Berufsgeheimnis fallen. Die Kommission und die zuständigen nationalen Behörden, ihre Beamten, ihre Bediensteten und sonstige Personen, die unter Aufsicht dieser Behörden tätig sind, sowie Beamte und Bedienstete anderer Behörden der Mitgliedstaaten sollten die Vertraulichkeit der bei der Durchführung ihrer Aufgaben und Tätigkeiten erlangten Informationen gewährleisten. Dies sollte auch für das Europäische Halbleitergremium und den Halbleiterausschuss gelten. Die Kommission sollte gegebenenfalls Durchführungsrechtsakte erlassen können, um die praktischen Modalitäten der Behandlung vertraulicher Informationen im Rahmen der Einholung von Informationen festzulegen.

<a id="rec-120"></a>
(120) Die Einhaltung der in dieser Verordnung festgelegten Verpflichtungen sollte mittels Geldbußen und Zwangsgeldern durchsetzbar sein. Zu diesem Zweck sollten angemessene Geldbußen für die Missachtung von Auskunftsersuchen und Mitteilungspflichten gemäß dieser Verordnung festgelegt werden, wobei die unterschiedliche Schwere der Missachtung beider Pflichten zu berücksichtigen ist und für KMU andere Höchstbeträge gelten sollten. Außerdem sollten Zwangsgelder für die Missachtung der Verpflichtung zur Annahme und Erfüllung vorrangiger Aufträge festgelegt werden, die verhältnismäßig sein und das Preisniveau auf dem Markt während der letzten 90 Tage widerspiegeln sollten, wobei für KMU andere Höchstbeträge gelten sollten. Zusätzlich zu den Verjährungsfristen für die Durchsetzung von Sanktionen sollten auch Verjährungsfristen für die Verhängung von Geldbußen und Zwangsgeldern gelten. Darüber hinaus sollte die Kommission dem betreffenden Unternehmen oder den entsprechenden Unternehmensverbänden Anspruch auf rechtliches Gehör einräumen.

<a id="rec-121"></a>
(121) Um dem technologischen Wandel und den Marktentwicklungen Rechnung zu tragen, die für den Halbleitersektor von Bedeutung sind, und um die wirksame Durchführung und Bewertung der Initiative „Chips für Europa 2.0“ sicherzustellen, sollte der Kommission die Befugnis übertragen werden, gemäß Artikel 290 AEUV Rechtsakte zur Änderung dieser Verordnung bezüglich der Maßnahmen, die durch die Initiative „Chips für Europa 2.0“ unterstützt werden, zu erlassen und zwar in einer Weise, die mit den Zielen der Initiative im Einklang steht, sowie bezüglich der messbaren Indikatoren für die Überwachung der Durchführung der Initiative „Chips für Europa 2.0“ und zur Berichterstattung über deren Fortschritte bei der Verwirklichung ihrer Ziele und um diese Verordnung durch die Festlegung des Verfahrens für die Anwendung und der Anforderungen und der Bedingungen für die Gewährung, die Überwachung und den Entzug des Gütesiegels für Exzellenzzentren für Entwurf zu ergänzen. Es ist von besonderer Bedeutung, dass die Kommission im Zuge ihrer Vorbereitungsarbeit angemessene Konsultationen, auch auf der Ebene von Sachverständigen, durchführt und dass diese Konsultationen mit den Grundsätzen in Einklang stehen, die in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung^(66) niedergelegt wurden. Um insbesondere eine gleichberechtigte Beteiligung an der Ausarbeitung der delegierten Rechtsakte zu gewährleisten, erhalten das Europäische Parlament und der Rat alle Dokumente zur gleichen Zeit wie die Sachverständigen der Mitgliedstaaten, und ihre Sachverständigen haben systematisch Zugang zu den Sitzungen der Sachverständigengruppen der Kommission, die mit der Ausarbeitung der delegierten Rechtsakte befasst sind.

<a id="rec-122"></a>
(122) Unbeschadet des Haushaltsverfahrens und ihrer Verwaltungsautonomie sollte die Kommission die Ressourcen optimal nutzen, um sicherzustellen, dass sie ihre Aufgaben und Befugnisse gemäß dieser Verordnung wirksam wahrnehmen kann.

<a id="rec-123"></a>
(123) Da das Ziel der vorliegenden Verordnung, nämlich die Schaffung eines Rahmens für die Stärkung des Halbleiterökosystems auf Unionsebene, von den Mitgliedstaaten nicht ausreichend verwirklicht werden kann und vielmehr wegen des Umfangs und der Wirkungen der Maßnahme auf Unionsebene besser zu verwirklichen ist, kann die Union im Einklang mit dem in Artikel 5 des Vertrags über die Europäische Union verankerten Subsidiaritätsprinzip tätig werden. Entsprechend dem in demselben Artikel genannten Grundsatz der Verhältnismäßigkeit geht diese Verordnung nicht über das zur Verwirklichung dieses Ziels erforderliche Maß hinaus.

<a id="rec-124"></a>
(124) Die Verordnung (EU) 2023/1781 sollte daher aufgehoben werden —

HABEN FOLGENDE VERORDNUNG ERLASSEN:

<a id="chapter-i"></a>
## Kapitel I – Allgemeine Bestimmungen

<a id="art-1"></a>
### Artikel 1 – Gegenstand

- (1) Diese Verordnung schafft einen Rahmen für die Stärkung des Halbleiterökosystems und für die Bewältigung und Vermeidung von Abhängigkeiten, die die Sicherheit der Versorgung mit Halbleitern auf Unionsebene gefährden können, insbesondere durch folgende Maßnahmen:

  - a) Fortführung und Weiterentwicklung der Initiative „Chips für Europa“, die ursprünglich mit der Verordnung (EU) 2023/1781 eingerichtet wurde und in der vorliegenden Verordnung als Initiative „Chips für Europa 2.0“ bezeichnet wird;

  - b) Festlegung der Kriterien für die Anerkennung und Unterstützung europäischer Halbleitertechnologieinitiativen, bei denen es sich um neuartige Initiativen handelt, und strategischer Projekte, die die Unumgänglichkeit, die Resilienz und den Erfolg des Halbleiterökosystems der Union fördern;

  - c) Verbesserung des ursprünglich mit der Verordnung (EU) 2023/1781 eingerichteten Koordinierungsmechanismus zwischen den Mitgliedstaaten und der Kommission, der die Kartierung und Überwachung des Halbleitersektors der Union, die Krisenprävention und Reaktion auf Versorgungsengpässe bei Halbleitern und gegebenenfalls Auskunftsersuchen an und Konsultationen mit Interessenträgern aus der Halbleiterlieferkette betrifft.

- (2) Das erste allgemeine Ziel der vorliegenden Verordnung besteht darin, die notwendigen Voraussetzungen für die Wettbewerbs- und Innovationskapazität der Union im Bereich der Halbleitertechnik zu schaffen und die Anpassung der Branche an strukturelle Veränderungen sicherzustellen.

- (3) Das zweite allgemeine Ziel, das eigenständig ist und das in Absatz 2 festgelegte erste allgemeine Ziel ergänzt, besteht darin, die Krisenvorsorge zur Gewährleistung der Versorgungssicherheit der EU und dadurch das Funktionieren des Binnenmarkts zu verbessern, indem ein einheitlicher Unionsrechtsrahmen festgelegt wird, der die Union im Bereich der Halbleitertechnik unumgänglicher, resilienter und erfolgreicher macht.

- (4) Diese Verordnung gilt unbeschadet der besonderen Beschaffungsverfahren und Einstufungsstandards, die nach Maßgabe der Verordnung (EU) 2025/2643 im Verteidigungssektor gelten.

<a id="art-2"></a>
### Artikel 2 – Begriffsbestimmungen

Für die Zwecke dieser Verordnung gelten folgende Begriffsbestimmungen:

1. „Halbleiter“ bezeichnet eines der Folgenden:

  - a) einen einfachen Werkstoff oder Verbundwerkstoff, einschließlich fortgeschrittener Werkstoffe, dessen elektrische Leitfähigkeit verändert werden kann,

  - b) eine Komponente, die aus mehreren Schichten halbleitender, isolierender und leitender Werkstoffe besteht, welche nach einem vorgegebenen Muster festgelegt sind und genau definierte elektronische und/oder photonische Funktionen ausführen sollen;

2. „Chip“ bezeichnet ein elektronisches Gerät, das auf einem einzigen Stück Halbleiterwerkstoff verschiedene Funktionselemente enthält, typischerweise in Form von Speicher-, Logik-, Prozessor-, Optoelektronik- und Analoggeräten;

3. „Quantenchip“ bezeichnet ein Gerät, mit dem Informationen auf der Ebene einzelner Quantensysteme verarbeitet werden, wobei der Integrationsgrad der Komponenten auf einem einzigen Chip je nach verwendeter Quantenplattform, einschließlich Plattformen für Quanteninformatik, -kommunikation, -sensorik oder -metrologie, variiert;

4. „Technologieknoten“ bezeichnet einen spezifischen Halbleiterfertigungsprozess und seine Entwurfsregeln;

5. „Halbleiterlieferkette“ bezeichnet das System der Tätigkeiten, Organisationen, Akteure, Technologien, Informationen, Ressourcen und Dienstleistungen, die mit der Herstellung von Halbleitern verbunden sind, einschließlich Rohstoffen und verarbeiteten Werkstoffen, wie etwa Gase, Halbleiterfertigungsausrüstung, Entwurf, samt der damit verbundenen Softwareentwicklung, Fertigung, Montage, Prüfung und Packaging;

6. „Halbleiterwertschöpfungskette“ bezeichnet die Reihe der Tätigkeiten im Zusammenhang mit einem Halbleiterprodukt von der Konzeption bis zur Endverwendung, einschließlich Rohstoffen und verarbeiteten Werkstoffen, wie etwa Gase, Halbleiterfertigungsausrüstung, Forschung, Entwicklung und Innovation, Entwurf, samt der damit verbundenen Softwareentwicklung, Fertigung, Prüfung, Montage und Packaging bis hin zur Einbettung und Integration in Endprodukte und zu Verfahren am Ende der Lebensdauer wie Wiederverwendung, Zerlegung und Recycling;

7. „Pilotanlage“ bezeichnet eine Test- und Versuchseinrichtung, die sich mit höheren Technologie-Reifegraden bis hin zur industriellen Einführung befasst, um Produkte, Ausrüstungen, Prozesse oder Systeme zu testen, zu demonstrieren, zu validieren und zu kalibrieren;

8. „kleine und mittlere Unternehmen“ oder „KMU“ bezeichnet kleine oder mittlere Unternehmen im Sinne des Anhangs der Empfehlung 2003/361/EG der Kommission^(67);

9. „kleines Midcap-Unternehmen“ („kleines Midcap“) bezeichnet ein kleines Unternehmen mit mittlerer Kapitalisierung im Sinne des Anhangs der Empfehlung 2025/1099/EG;

10. „neuartige Initiative“ bezeichnet eine der folgenden Initiativen, die in der Union Innovationen in Bezug auf den Fertigungsprozess oder das Endprodukt hervorbringen, soweit in der Union solche Innovationen noch nicht ausreichend vorhanden sind oder ihre Umsetzung noch nicht konkret geplant ist, um die Resilienz und Versorgungssicherheit der Union zu gewährleisten, einschließlich Innovationen, die Verbesserungen der Rechenleistung oder des Niveaus der Sicherheit und Gefahrenabwehr oder der Zuverlässigkeit, der Energieeffizienz und Umweltbilanz oder des Technologieknotens oder Trägermaterials oder im Hinblick auf die Einführung von Produktionsprozessen, die Effizienzsteigerungen ermöglichen, betreffen oder die Recyclingfähigkeit verbessern oder die Produktionsinputs verringern:

  - a) eine neue oder erheblich modernisierte Halbleiterfertigungsanlage,

  - b) eine neue oder erheblich modernisierte Anlage oder ein neuer oder erheblich modernisierter Prozess für die Herstellung von Ausrüstung,

  - c) eine neue oder erheblich modernisierte Anlage oder ein neuer oder erheblich modernisierter Prozess für die Herstellung von Schlüsselkomponenten für solche Ausrüstungen oder für die sonstige Herstellung von Inputs, die überwiegend in der Halbleiterfertigung verwendet werden, wie z. B. von Werkstoffen,

  - d) eine neue oder erheblich modernisierte Anlage für die Elektronikfertigung oder -integration,

  - e) neue, fertigungszentrierte Chipentwurfstätigkeiten;

11. „fertigungszentrierte Chipentwurfstätigkeiten“ bezeichnet die Ausarbeitung von Fertigungsentwürfen, die Ko-Optimierung des Entwurfsprozesses und die endgültige Produktionsübergabe (Tape-out), d. h. die Phase, in der ein Chipentwurf in Form eines physischen Prototyps zur Validierung vor der Massenfertigung freigegeben wird;

12. „Halbleitertechnologien der nächsten Generation“ bezeichnet Halbleitertechnologien, die über den aktuellen Stand der Technik hinausgehen, da sie erhebliche Verbesserungen der Funktionsleistung, der Rechenleistung oder der Energieeffizienz sowie andere erhebliche Energie- und Umweltvorteile bieten;

13. „hochmoderne Halbleitertechnologien“ bezeichnet den aktuellen Stand der Innovation bei Chips und Halbleitertechnologien zum Zeitpunkt der Durchführung von Projekten;

14. „Halbleiterfertigung“ bezeichnet jede der Stufen der Herstellung und Verarbeitung von Halbleiterwafern, einschließlich Entwurf, Trägermaterial, Front-End und Back-End, die erforderlich sind, um ein fertiges Halbleiterprodukt zu liefern;

15. „Front-End“ bezeichnet die gesamte Verarbeitung eines Halbleiterwafers;

16. „Back-End“ bezeichnet das Packaging, die Montage und die Prüfung eines Halbleiterprodukts;

17. „Elektronikfertigung und -integration“ bezeichnet die Fertigung oder Integration von Leiterplatten, von fortgeschrittenen Packaging-Trägern sowie die Elektronikverarbeitung in Bezug auf Montage, Prüfung oder Systemintegration von Halbleitern oder halbleitergestützten Produkten;

18. „Halbleiteranwender“ bezeichnet ein Unternehmen, das Produkte herstellt, in die Halbleiter eingebaut sind;

19. „wichtige Marktakteure“ bezeichnet Unternehmen in der Halbleiterlieferkette der Union, deren zuverlässiges Funktionieren für die Versorgung mit Halbleitern von wesentlicher Bedeutung ist;

20. „kritischer Sektor“ bezeichnet einen der in Anhang V genannten Sektoren;

21. „krisenrelevantes Produkt“ bezeichnet eines der folgenden Produkte, die von einer Halbleiterkrise betroffen und für die Gewährleistung wesentlicher Funktionen eines kritischen Sektors bedeutsam sind:

  - a) Halbleiter oder Chips, die entweder unmittelbar in kritischen Sektoren eingesetzt werden oder die zur Herstellung von in kritischen Sektoren benutzten Geräten verwendet werden,

  - b) Zwischenprodukte, die für die Herstellung von Halbleitern oder Chips erforderlich sind,

  - c) Rohstoffe und verarbeitete Werkstoffe, die für die Herstellung von Halbleitern oder Chips oder Zwischenprodukten erforderlich sind;

22. „Produktionsvermögen“ bezeichnet die Fähigkeit einer Fertigungsanlage, bestimmte Arten von Produkten zu fertigen;

23. „Produktionskapazität“ bezeichnet den höchsten möglichen Output einer Fertigungsanlage;

24. „Geschäftsgeheimnis“ bezeichnet ein Geschäftsgeheimnis im Sinne des Artikels 2 Nummer 1 der Richtlinie (EU) 2016/943;

25. „Genehmigungsverfahren“ bezeichnet ein Verfahren, das alle einschlägigen Genehmigungen für den Bau, die Ausweitung, die Umwandlung und den Betrieb von industriellen Fertigungsprojekten abdeckt, einschließlich Baugenehmigungen, chemikalienbezogene Genehmigungen und Netzanschlussgenehmigungen im Sinne des Artikels 1 [des Vorschlags für eine Richtlinie zur Änderung der Richtlinien (EU) 2018/2001, (EU) 2019/944 und (EU) 2024/1788 im Hinblick auf die Beschleunigung der Genehmigungsverfahren] sowie erforderlichenfalls Umweltprüfungen und -genehmigungen, und das alle Anträge und Verfahren von der Bestätigung der Vollständigkeit des Antrags bis zur Mitteilung der umfassenden Entscheidung über das Ergebnis des Verfahrens umfasst;

26. „Auftrag“ bezeichnet öffentliche Aufträge im Sinne des Artikels 2 Absatz 1 Nummer 5 der Richtlinie 2014/24/EU, Liefer-, Bau- und Dienstleistungsaufträge im Sinne des Artikels 2 Nummer 1 der Richtlinie 2014/25/EU des Europäischen Parlaments und des Rates [Fußnote einfügen] und Konzessionsverträge im Sinne des Artikels 5 Nummer 1 der Richtlinie 2014/23/EU des Europäischen Parlaments und des Rates;

27. „öffentlicher Auftraggeber“ bezeichnet einen öffentlichen Auftraggeber im Sinne des Artikels 6 der Richtlinie 2014/23/EU, des Artikels 2 Absatz 1 Nummer 1 der Richtlinie 2014/24/EU und des Artikels 3 der Richtlinie 2014/25/EU;

28. „Vergabestelle“ bezeichnet einen Auftraggeber im Sinne des Artikels 7 der Richtlinie 2014/23/EU und des Artikels 4 der Richtlinie 2014/25/EU;

29. „sichere Verarbeitungsumgebung“ bezeichnet die physische oder virtuelle Umgebung und die organisatorischen Mittel, mit denen die Einhaltung der Anforderungen des Unionsrechts, darunter der Verordnung (EU) 2016/679 des Europäischen Parlaments und des Rates^(68), insbesondere im Hinblick auf die Rechte der betroffenen Personen, der kartellrechtlichen Vorschriften, der Rechte des geistigen Eigentums und der geschäftlichen und statistischen Vertraulichkeit, der Integrität und der Verfügbarkeit, sowie des geltenden Unionsrechts und des nationalen Rechts gewährleistet wird und die es der Einrichtung, die die sichere Verarbeitungsumgebung bereitstellt, ermöglichen, alle Datenverarbeitungsvorgänge zu bestimmen und zu beaufsichtigen, darunter auch das Anzeigen, Speichern, Herunterladen und Exportieren von Daten und das Berechnen abgeleiteter Daten mithilfe von Rechenalgorithmen;

30. „gesetzlicher Vertreter“ bezeichnet eine natürliche oder juristische Person, die in der Union ansässig oder niedergelassen ist und benannt wurde, um im Namen der gemäß Artikel 34 dieser Verordnung eingerichteten Plattform zu handeln;

31. „inländisches Unternehmen“ bezeichnet

  - a) jedes Unternehmen in der Halbleiterwertschöpfungskette, das seinen Sitz in der Union hat und im Eigentum und unter der Kontrolle eines Unionsunternehmens steht,

  - b) jedes Unternehmen in der Halbleiterwertschöpfungskette, das eines der folgenden Kriterien erfüllt, unabhängig davon, ob es seinen Sitz in der Union hat:

  - c) es steht im Eigentum und unter der Kontrolle eines Unionsunternehmens und hat seinen Sitz außerhalb der Union,

  - d) es steht im Eigentum und unter der Kontrolle eines Unternehmens mit Sitz in einem Drittland oder Gebiet, mit dem die Union ein Abkommen zur Errichtung einer Freihandelszone, einer Zollunion oder einer strategischen Halbleiterpartnerschaft gemäß Artikel 49 geschlossen hat,

  - e) es steht im Eigentum und unter der Kontrolle eines Unternehmens mit Sitz in einem Unterzeichnerstaat des WTO-Übereinkommens über das öffentliche Beschaffungswesen;

32. „Eigentum“ bedeutet, dass Eigentumsanteile von mindestens 50 % der juristischen Person, Stelle oder Organisation gehalten werden, oder dass eine Mehrheitsbeteiligung daran vorliegt;

33. „Kontrolle“ bezeichnet die Kontrolle im Sinne des Artikels 2 Nummer 6 der Verordnung (EU) 2021/697;

34. „Unionsunternehmen“ bezeichnet ein Unternehmen, das nach den Rechtsvorschriften eines Mitgliedstaats niedergelassen ist;

35. „strategische Halbleiterpartnerschaft“ bezeichnet eine zwischen der Union und einem Drittland oder Gebiet eingegangene Verpflichtung, die Zusammenarbeit in Bezug auf die Halbleiterwertschöpfungskette zu verstärken, die mittels eines nicht verbindlichen Instruments durchgeführt wird, in dem konkrete Maßnahmen von beiderseitigem Interesse festgelegt werden;

36. „strategisches Projekt“ bezeichnet ein Projekt, das einen erheblichen Mehrwert für die Union erbringt, indem es einen wesentlichen Beitrag zu Zielen von gemeinsamem Unionsinteresse leistet, das eine klare grenzüberschreitende Dimension aufweist, insbesondere durch technische Zusammenarbeit oder öffentliche Unterstützung, an der mehr als ein Mitgliedstaat beteiligt ist, und das zur Stärkung der Unumgänglichkeit, der Resilienz und des Erfolgs der Halbleiterwertschöpfungskette der Union und der technologischen Souveränität und technologischen Führungsposition der Union beiträgt, indem es kritische Kapazitäten, Technologien oder Fähigkeiten innerhalb der Union ermöglicht, voranbringt oder sichert, unter anderem durch die Verringerung strategischer Abhängigkeiten;

37. „Gemeinsames Unternehmen für Chips“ bezeichnet das mit der Verordnung (EU) 2021/2085 des Rates gegründete gemeinsame Unternehmen und gegebenenfalls jede Nachfolgeeinrichtung oder -initiative, die nach Unionsrecht im Zuge eines nachfolgenden mehrjährigen Finanzrahmens gegründet wird.

<a id="chapter-ii"></a>
## Kapitel II – Initiative „Chips für Europa 2.0“

<a id="art-3"></a>
### Artikel 3 – Initiative „Chips für Europa 2.0“

- (1) Die Initiative „Chips für Europa 2.0“ wird für die Laufzeit des durch die Verordnung (EU, Euratom) 2020/2093 des Rates^(69) festgelegten Mehrjährigen Finanzrahmens 2021-2027 unterstützt.

- (2) Die Initiative „Chips für Europa 2.0“ wird mit Mitteln aus dem Programm Horizont Europa und dem Programm Digitales Europa gemäß den Verordnungen (EU) 2021/694 und (EU) 2021/695 sowie mit nationalen und privaten Mitteln unterstützt.

<a id="art-4"></a>
### Artikel 4 – Ziel der Initiative „Chips für Europa 2.0“

- (1) Das allgemeine Ziel der Initiative „Chips für Europa 2.0“ besteht darin, einen groß angelegten technologischen Kapazitätsaufbau zu erreichen und damit verbundene Forschungs- und Innovationstätigkeiten in der gesamten Halbleiterwertschöpfungskette der Union zu unterstützen, um so

  - a) die technologische Souveränität, die wirtschaftliche Sicherheit, die Resilienz, den Erfolg, die Unumgänglichkeit und die industrielle Wettbewerbsfähigkeit der Union zu stärken, indem für den Transfer und die industrielle Übernahme der im Rahmen der Initiative „Chips für Europa 2.0“ entwickelten Technologien gesorgt wird;

  - b) die Unionsnachfrage nach Halbleitern anzuregen, unter anderem durch Vergabeverfahren, die im Einklang mit dem Unionsrecht und den internationalen Verpflichtungen der Union die Übernahme und Integration in der Union entworfener, entwickelter oder gefertigter Halbleitertechnologien, -komponenten und -systeme fördern;

  - c) die Innovation, Entwicklung und Einführung hochmoderner Halbleitertechnologien zu ermöglichen, einschließlich Photonik als bereichsübergreifender und grundlegender Technologie, insbesondere solcher, die für künstliche Intelligenz (KI), einschließlich Edge-KI, und für wichtige Anwendungsbereiche wie Gesundheit, Energie, industrielle Automatisierung, Robotik, Verkehr, Verteidigung, Automobil- und Luftfahrtsysteme sowie für Rechenzentren und Cloud-Infrastrukturen von entscheidender Bedeutung sind;

  - d) einen Beitrag zur Verwirklichung des ökologischen und digitalen Wandels zu leisten, insbesondere durch die Verringerung der Energie-, Umwelt- und Klimaauswirkungen elektronischer Systeme, die Verbesserung der Nachhaltigkeit von Chips der nächsten Generation und die Stärkung der Prozesse der Kreislaufwirtschaft, durch einen Beitrag zu hochwertigen Arbeitsplätzen innerhalb des Halbleiterökosystems und durch die Berücksichtigung der Grundsätze der konzeptionsintegrierten Sicherheit, die Schutz vor Cybersicherheitsbedrohungen bieten.

- (2) Die Initiative „Chips für Europa 2.0“ hat die folgenden sechs operativen Ziele:

  - a) operatives Ziel 1: Unterstützung fortgeschrittener Entwurfskapazitäten für Halbleitertechnik;

  - b) operatives Ziel 2: Ausbau bestehender und Entwicklung neuer fortgeschrittener Pilotanlagen in der gesamten Union, um die Entwicklung und industrielle Einführung von hochmodernen Halbleitertechnologien und Halbleitertechnologien der nächsten Generation sowie von Pilot-Testumgebungen zur Validierung und Demonstration der Integration und Nutzung solcher Technologien in wichtigen Anwendungen und Anwenderbranchen zu ermöglichen;

  - c) operatives Ziel 3: Aufbau fortgeschrittener technologischer und ingenieurstechnischer Kapazitäten zur Beschleunigung der innovativen Entwicklung hochmoderner Quantenchips und dazugehöriger Halbleitertechnologien;

  - d) operatives Ziel 4: Unterstützung eines unionsweiten Netzes von Kompetenzzentren durch den Ausbau bestehender oder die Schaffung neuer Anlagen;

  - e) operatives Ziel 5: Aufbau und Stärkung fortgeschrittener Kapazitäten für den Entwurf, die Prototypentwicklung und die industrielle Einführung photonisch integrierter Schaltungen und anderer Photoniktechnologien in der gesamten Union;

  - f) operatives Ziel 6: Durchführung von Tätigkeiten, die gemeinsam als „Chip-Fonds“-Tätigkeiten zu bezeichnen sind, um den Zugang zu Finanzmitteln zu erleichtern, unter anderem durch die Bereitstellung klarer Leitlinien, insbesondere für Start-ups, Scale-ups, KMU und kleine Midcaps in der Halbleiterwertschöpfungskette, durch Finanzierungsinstrumente und Investitionsfördermechanismen zur Unterstützung der Eigenkapital-, Fremdkapital- oder Mischfinanzierung im Rahmen des Accelerators des Europäischen Innovationsrats, des Fonds „InvestEU“ und gegebenenfalls anderer Unionsinstrumente und von deren Nachfolgern im Zuge des Mehrjährigen Finanzrahmens 2028-2034.

- (3) Die Initiative „Chips für Europa 2.0“ unterstützt groß angelegte, sektorenübergreifende Initiativen zur Bewältigung großer technologischer und industrieller Herausforderungen, die für die Union von strategischer Bedeutung sind (im Folgenden „Große Herausforderungen“).

- (4) Zur Verwirklichung der Ziele der Initiative „Chips für Europa 2.0“ können auch Tätigkeiten zum Kapazitätsaufbau und damit verbundene Forschungs- und Innovationstätigkeiten durchgeführt werden. Im Zuge des Mehrjährigen Finanzrahmens 2021-2027 werden alle Tätigkeiten zum Kapazitätsaufbau aus dem Programm Digitales Europa und die damit verbundenen Forschungs- und Innovationstätigkeiten aus dem Programm Horizont Europa finanziert.

<a id="art-5"></a>
### Artikel 5 – Operative Ziele der Initiative „Chips für Europa 2.0“

Die Initiative „Chips für Europa 2.0“ wird Folgendes tun:

  - a) im Rahmen ihres operativen Ziels 1:

    - i) Pflege und Ausbau einer unionsweit verfügbaren virtuellen Entwurfsplattform, die eine breite Palette von neuen und bestehenden Entwurfseinrichtungen, -werkzeugen und -diensten umfasst und insbesondere Hochschulen, Start-ups, Scale-ups und KMU den Zugang dazu erleichtert, um das Wachstum und die Expansion von Unternehmen ohne eigene Fertigungsanlagen in der Union zu steigern,

    - ii) Ausbau der Entwurfsfähigkeiten der Union, auch im Hinblick auf Photonik und Quantentechnik, durch die Förderung innovativer Entwicklungen in den Bereichen fortgeschrittener Chipentwurf und fortgeschrittene Chiparchitekturen und zu diesem Zweck Unterstützung ehrgeiziger strategischer Entwurfsprojekte, die für die strategische Autonomie und die Wettbewerbsfähigkeit der Union von großer Bedeutung sind;

  - b) im Rahmen ihres operativen Ziels 2:

    - i) Stärkung der Fähigkeiten im Bereich der Chipproduktionstechnologien der nächsten Generation und der Halbleiterfertigungsausrüstung durch die Einbeziehung von Forschungs- und Innovationstätigkeiten und die Vorbereitung der Entwicklung künftiger Technologieknoten und Halbleiterfertigungsprozesse,

    - ii) Unterstützung von Innovationen in großem Maßstab durch Zugang zu neuen oder bestehenden Pilotanlagen für Erprobung, Tests, Prozesssteuerung, Endprüfung der Geräteeigenschaften, Erprobung und Validierung neuer Technologien und Entwurfskonzepte zur Integration von Schlüsselfunktionen,

    - iii) Unterstützung von Innovationen durch Zugang zu neuen oder erweiterten Pilot-Testumgebungen, in denen verschiedene innovative Technologien oder Produkte kombiniert und integriert werden, um neue Geräte für wichtige Anwendungen und Anwenderbranchen vor ihrer vollständigen Einführung im industriellen Maßstab zu entwickeln und zu validieren, um Risiken zu ermitteln, die Leistung zu validieren und die Durchführbarkeit unter realen Bedingungen sicherzustellen,

    - iv) Unterstützung europäischer Halbleitertechnologieinitiativen durch bevorzugten Zugang zu neuen oder bestehenden Pilotanlagen sowie Sicherstellung des effektiven Zugangs zu neuen Pilotanlagen und Pilot-Testumgebungen unter fairen Bedingungen für ein breites Spektrum von Nutzern des Halbleiterökosystems der Union,

    - v) Vorbereitung auf den Transfer und die industrielle Einführung der im Rahmen dieses operativen Ziels entwickelten Technologien;

  - c) im Rahmen ihres operativen Ziels 3:

    - i) Unterstützung der Entwicklung neuer oder bestehender Pilotanlagen, Reinräume und Fertigungsbetriebe für die Prototypentwicklung und die Herstellung von Quantenchips für die Integration von Quantenschaltungen und Steuerelektronik,

    - ii) Entwicklung von Anlagen für die Prüfung und Validierung fortgeschrittener Quantenchips, die in den Pilotanlagen hergestellt werden, um den Kreis des Innovations-Feedbacks zwischen Entwicklern, Herstellern und Nutzern von Quantenkomponenten zu schließen,

    - iii) Entwicklung innovativer Entwurfsbibliotheken für Quantenchips in engem Zusammenhang mit dem operativen Ziel 1;

  - d) im Rahmen ihres operativen Ziels 4:

    - i) Stärkung der Kapazitäten und Bereitstellung eines breiten Spektrums an Sachkenntnis für Interessenträger, einschließlich als Endnutzer auftretender Start-ups, Scale-ups und KMU, und Erleichterung des Zugangs zu den in diesem Artikel genannten Kapazitäten und Anlagen und deren effektiver Nutzung,

    - ii) Bewältigung des Mangels und Ungleichgewichts bei Kenntnissen und Kompetenzen durch Anwerbung, Mobilisierung und Bindung neuer Talente in den Bereichen Forschung, Entwurf und Herstellung, einschließlich Umschulung und Weiterbildung von Arbeitskräften;

  - e) im Rahmen ihres operativen Ziels 5:

    - i) Stärkung der Fähigkeiten in den Bereichen Produktionstechnologien, Halbleiterfertigungsausrüstung und Werkstoffplattformen für photonisch integrierte Schaltungen durch die Einbeziehung von Forschungs- und Innovationstätigkeiten,

    - ii) Stärkung bestehender und Entwicklung neuer Pilotanlagen und frei zugänglicher Halbleiterfertigungsanlagen für die Prototypentwicklung für photonisch integrierte Schaltungen und deren Herstellung und für zugehörige Photoniktechnologien,

    - iii) Entwicklung und Pflege von Entwurfsbibliotheken und Entwurfsautomatisierungswerkzeugen für photonisch integrierte Schaltungen und zugehörige Photoniktechnologien und Methoden für ihre Integration in Module, die in der gesamten Union zu offenen und diskriminierungsfreien Bedingungen zur Verfügung stehen,

    - iv) Vorbereitung auf den Transfer und die industrielle Einführung der im Rahmen dieses operativen Ziels entwickelten Technologien;

  - f) im Rahmen ihres operativen Ziels 6:

    - i) Unterstützung von Start-ups und Scale-ups in der gesamten Halbleiterwertschöpfungskette beim Zugang zu Finanzmitteln in allen Wachstumsphasen, mit dem besonderen Schwerpunkt auf der Schließung der Finanzierungslücke, die sie daran hindert, die für den weltweiten Wettbewerb erforderliche Größenordnung zu erreichen,

    - ii) Beschleunigung und Verbesserung des Zugangs zu Investitionen in die Halbleiterwertschöpfungskette, insbesondere durch die Mobilisierung von Risiko- und Wachstumskapital, und Erschließung von sowohl öffentlichen als auch privaten Finanzmitteln bei gleichzeitiger Steigerung der Unumgänglichkeit, der Resilienz und des Erfolgs des Halbleiterökosystems in der Union.

Die Verwirklichung dieser Ziele erfolgt gegebenenfalls im Einklang mit der technischen Beschreibung in Anhang I.

<a id="art-6"></a>
### Artikel 6 – Europäisches Netz der Kompetenzzentren für Halbleiter

- (1) Für die Zwecke des operativen Ziels 4 der Initiative „Chips für Europa 2.0“ wird das mit der Verordnung (EU) 2023/1781 eingerichtete europäische Netz der Kompetenzzentren für Halbleiter, Systemintegration und Entwurf (im Folgenden „Netz“) unterstützt. Das Netz setzt sich aus den vom Gemeinsamen Unternehmen für Chips gemäß Absatz 3 ausgewählten Kompetenzzentren zusammen.

- (2) Die Kompetenzzentren führen zum Nutzen der Unionsindustrie und in enger Zusammenarbeit mit ihr, insbesondere KMU und Midcap-Unternehmen, sowie Forschungs- und Technologieorganisationen, Hochschulen, dem öffentlichen Sektor und anderen einschlägigen Interessenträgern entlang der Halbleiterwertschöpfungskette alle oder einige der folgenden Tätigkeiten durch:

  - a) Gewährleistung der Abstimmung zwischen den Tätigkeiten des Kompetenzzentrums und gegebenenfalls der Halbleiterstrategie des Mitgliedstaats, in dem das Kompetenzzentrum niedergelassen ist;

  - b) Sensibilisierung und Bereitstellung des nötigen Fachwissens, der Sachkenntnis und der Kompetenzen für die Interessenträger, um ihnen zu helfen, die Entwicklung von neuen Halbleitertechnologien, Halbleiterfertigung, Ausrüstung, Entwurfsoptionen und Systemkonzepten sowie die Integration neuer Halbleitertechnologien unter effektiver Nutzung der Infrastruktur und anderer verfügbarer Ressourcen des Netzes zu beschleunigen;

  - c) Bereitstellung des Zugangs zu Entwurfsdienstleistungen und Entwurfswerkzeugen im Rahmen des operativen Ziels 1 der Initiative „Chips für Europa 2.0“ sowie zu den Pilotanlagen, die im Rahmen des operativen Ziels 2 der Initiative „Chips für Europa 2.0“ unterstützt werden;

  - d) Sensibilisierung und Bereitstellung von Sachkenntnis, Fachwissen und Dienstleistungen bzw. Gewährung des Zugangs dazu, einschließlich Systementwurfsreife, neuen und bestehenden Pilotanlagen und Unterstützungsmaßnahmen, die für den Aufbau von im Rahmen der Initiative „Chips für Europa 2.0“ unterstützten Fertigkeiten und Kompetenzen erforderlich sind;

  - e) Erleichterung des Transfers von Sachkenntnis und Fachwissen zwischen Mitgliedstaaten und Regionen zur Förderung des Austauschs von Kompetenzen, Kenntnissen und bewährten Verfahren sowie zur Förderung gemeinsamer Programme;

  - f) Entwicklung und Verwaltung besonderer Weiterbildungs- und Umschulungsmaßnahmen zu Halbleitertechnologien und ihren Anwendungen, um die Entwicklung des Talentpools zu unterstützen und die Zahl der Studierenden und die Qualität der Ausbildung in den einschlägigen Studienfächern an Schulen und Universitäten in der Union bis zum Promotionsniveau zu erhöhen;

  - g) Erleichterung der Verbindungen zwischen Studierenden und Halbleiterunternehmen in der gesamten Union unter besonderer Berücksichtigung der Beteiligung von Frauen und unterrepräsentierten Gruppen und aufbauend auf bestehenden Initiativen zur Förderung der allgemeinen und/oder beruflichen Bildung und der Mobilität von Studierenden und Arbeitskräften innerhalb und von außerhalb der Union.

- (3) Die Mitgliedstaaten benennen infrage kommende Kompetenzzentren entsprechend ihren nationalen Verfahren sowie administrativen und institutionellen Strukturen in einem offenen und wettbewerblichen Verfahren.

    Im Arbeitsprogramm des Gemeinsamen Unternehmens für Chips wird das Verfahren für die Unterstützung der Kompetenzzentren, die das Netz bilden, festgelegt, einschließlich der Auswahlkriterien sowie weiterer Einzelheiten zur Durchführung der in diesem Artikel genannten Aufgaben und Funktionen.

    Das Gemeinsame Unternehmen für Chips wählt die Kompetenzzentren, die das Netz bilden, aus.

    Die Mitgliedstaaten und die Kommission maximieren die Synergien mit bestehenden Kompetenzzentren, die im Rahmen anderer Initiativen der Union eingerichtet wurden, wie etwa den in der Verordnung (EU) 2021/694 genannten europäischen digitalen Innovationszentren.

- (4) Die Kompetenzzentren legen ihre Organisation, Zusammensetzung und Arbeitsweise weitgehend nach eigenem Ermessen fest. Die Organisation, Zusammensetzung und Arbeitsweise der Kompetenzzentren entsprechen den Zielen und Vorgaben dieser Verordnung und der Initiative „Chips für Europa 2.0“ und tragen zu ihnen bei.

<a id="art-7"></a>
### Artikel 7 – Große Herausforderungen

- (1) Große Herausforderungen dienen der Entwicklung, der Integration und der Gewährleistung der industriellen Einführung vielversprechender und kritischer Halbleitertechnik und verwandter Technik, die für die Union von zentraler Bedeutung sind, und werden gegebenenfalls im Einklang mit der technischen Beschreibung in Anhang I umgesetzt.

- (2) Die Initiative „Chips für Europa 2.0“ unterstützt die Großen Herausforderungen durch Folgendes:

  - a) Förderung fortgeschrittener Forschungs- und Entwicklungstätigkeiten, die es ermöglichen werden, bei der nächsten Generation von KI-Chips eine Führungsrolle zu übernehmen, Cloud-, Rechenzentrums- und Edge-KI-Infrastrukturen dauerhaft mit beispiellosen Energieeffizienzniveaus zu betreiben, die Unionskapazitäten im Bereich der Spitzentechnologien zu sichern und die Stärken der Union im Bereich der Halbleiterfertigung auszubauen;

  - b) Bewältigung großer Hindernisse bei der Weiterentwicklung der Halbleitertechnik wie Miniaturisierung, Energieeffizienz, Nachhaltigkeit, heterogene Integration, Sicherheit und Zuverlässigkeit sowie Herstellbarkeit;

  - c) Erweiterung des Halbleiterökosystems durch eine enge Zusammenarbeit mit vertikalen Marktsektoren;

  - d) Erzielung eines Wettbewerbsvorteils bei bestimmten Anwendungen, die für die technologische Souveränität und die industrielle Wettbewerbsfähigkeit der Union von entscheidender Bedeutung sind, durch eine strukturierte Zusammenarbeit zwischen Halbleiterentwicklern und Anwenderbranchen;

  - e) Integration der Bemühungen mehrerer Pilotanlagen und deren Ausrichtung auf eine industrielle Anwendung durch höhere Energieeffizienz und fortgeschrittene Halbleiterfähigkeiten;

  - f) Gewährleistung des Transfers und der industriellen Einführung von Technologien, die im Rahmen der Initiative „Chips für Europa 2.0“ entwickelt werden, einschließlich Tätigkeiten, die auf technologische Ausreifung, Einstufung, Prototypentwicklung, Demonstration, industrielle Ersteinführung und Überführung in Produktionsumgebungen abzielen.

- (3) Die Großen Herausforderungen werden in Abstimmung mit den Großen Herausforderungen gemäß der Verordnung (EU) XXXX/XXXX [Verordnung zur Cloud- und KI-Entwicklung (CADA)] sowie mit den Initiativen des mit der Verordnung (EU) 2021/1173 des Rates^(70) gegründeten Gemeinsamen Unternehmens für europäisches Hochleistungsrechnen umgesetzt.

<a id="art-8"></a>
### Artikel 8 – Nachfragebeschleuniger

- (1) Die Kommission und die Mitgliedstaaten fördern die Einführung von in der Union entworfenen oder hergestellten Halbleitern insbesondere auf Schlüsselmärkten wie Cloud-Computing, Automobilindustrie, Luftfahrt, Telekommunikation, Verteidigung und gegebenenfalls auf anderen Märkten.

- (2) Die Nachfragebeschleuniger werden von der Industrieallianz für Halbleiter umgesetzt.

- (3) Die Kommission kann in Zusammenarbeit mit den Mitgliedstaaten und einschlägigen Interessenträgern aus der Industrie und im Einklang mit den Wettbewerbsregeln

  - a) potenzielle Anwender, insbesondere Abnehmer von Halbleitertechnik, bei der Erörterung der Anforderungen und technologischen Spezifikationen der Halbleiterprodukte, die ihre Industrie voraussichtlich benötigen wird, unterstützen;

  - b) die Entwicklung gemeinsamer technischer Fahrpläne ermöglichen sowie Mitgestaltungstätigkeiten zwischen Halbleiterherstellern mit Sitz in der Union und nachgeschalteten industriellen Anwendern unterstützen und anregen, darunter auch mit Systemintegratoren und Ausrüstungsherstellern, damit Halbleiterkomponenten entwickelt werden, die auf industrielle Anwendungen in der Union zugeschnitten sind;

  - c) Kooperationsplattformen, Pilotprojekte oder Entwicklungspartnerschaften erleichtern, die eine frühzeitige Einbeziehung industrieller Anwender in die Konzeption innovativer, in der Union entwickelter Halbleitertechnik ermöglichen.

<a id="art-9"></a>
### Artikel 9 – Nachfrageforum

- (1) Die Kommission richtet ein Nachfrageforum ein, um die Präsentation von Halbleitertechnik, insbesondere durch europäische Halbleitertechnologieinitiativen und strategische Projekte sowie durch integrierte Produktionsstätten und offene EU-Fertigungsbetriebe, die gemäß der Verordnung (EU) 2023/1781 anerkannt sind, im Einklang mit den Wettbewerbsregeln zu erleichtern.

- (2) Das Nachfrageforum wird von der Industrieallianz für Halbleiter umgesetzt.

<a id="art-10"></a>
### Artikel 10 – Innovationsfördernde Chip-Beschaffung

Zur Unterstützung von öffentlichen Auftraggebern oder Vergabestellen und Wirtschaftsteilnehmern, die als Beschaffungsstellen bei Auftragsvergabe, Integration, Einstufung und Ersteinführung von Systemen, die Halbleiter enthalten, auftreten, ergreift das Gemeinsame Unternehmen für Chips die folgenden Maßnahmen:

  - a) Unterstützung der Schaffung von Regelungen für eine grenzüberschreitende gemeinsame Beschaffung zwischen öffentlichen Auftraggebern oder Vergabestellen, soweit zutreffend;

  - b) Unterstützung der Integration und Einführung innovativer Halbleitertechnik.

<a id="art-11"></a>
### Artikel 11 – Synergien mit anderen Programmen

Die Initiative „Chips für Europa 2.0“ wird in Synergie mit Unionsprogrammen gemäß Anhang IV durchgeführt. Die Kommission stellt sicher, dass die Erreichung der in Artikel 4 genannten Ziele der Initiative „Chips für Europa 2.0“ nicht behindert wird, wenn sie den komplementären Charakter der Initiative „Chips für Europa 2.0“ mit Unionsprogrammen zur Geltung bringt.

<a id="art-12"></a>
### Artikel 12 – Durchführung

- (1) Die operativen Ziele 1 bis 5 der Initiative „Chips für Europa 2.0“ und die Großen Herausforderungen werden dem Gemeinsamen Unternehmen für Chips übertragen und durch in seinem Arbeitsprogramm festgelegte Maßnahmen durchgeführt.

- (2) Um dem technologischen Wandel und den Marktentwicklungen, die für den Halbleitersektor bedeutsam sind, Rechnung zu tragen, wird der Kommission die Befugnis übertragen, gemäß Artikel 55 delegierte Rechtsakte zu erlassen, um Anhang I hinsichtlich der dort festgelegten Maßnahmen auf eine Weise, die mit den in Artikel 4 festgelegten Zielen der Initiative „Chips für Europa 2.0“ im Einklang steht, zu ändern.

- (3) Um die wirksame Durchführung und Bewertung der Initiative „Chips für Europa 2.0“ sicherzustellen und dem technologischen Wandel und den Marktentwicklungen gerecht zu werden, wird der Kommission die Befugnis übertragen, delegierte Rechtsakte gemäß Artikel 55 zu erlassen, um Anhang III hinsichtlich der messbaren Indikatoren für die Überwachung der Durchführung und die Berichterstattung über Fortschritte der Initiative „Chips für Europa 2.0“ bei der Verwirklichung ihrer in Artikel 4 festgelegten Ziele zu ändern.

- (4) Um die wirksame Durchführung, Überwachung und Bewertung der Initiative „Chips für Europa 2.0“ sicherzustellen, enthält der jährliche Tätigkeitsbericht des Gemeinsamen Unternehmens für Chips Angaben über Angelegenheiten im Zusammenhang mit den operativen Zielen 1 bis 5 der Initiative „Chips für Europa 2.0“ und den Großen Herausforderungen auf der Grundlage der in Anhang III festgelegten messbaren Indikatoren.

- (5) Die Kommission unterrichtet das Europäische Halbleitergremium regelmäßig über die Fortschritte bei der Durchführung des operativen Ziels 6 der Initiative „Chips für Europa 2.0“.

## Kapitel III

## Versorgungssicherheit und Nachfrage

<a id="chapter-ii-section-1"></a>
## Abschnitt 1 – Halbleiterfertigungsfähigkeiten

<a id="art-13"></a>
### Artikel 13 – Öffentliches Interesse und öffentliche Unterstützung

- (1) Europäische Halbleitertechnologieinitiativen und strategische Projekte werden als Beitrag zur Sicherheit der Versorgung mit Halbleitern und zur Resilienz des Halbleiterökosystems der Union und daher als im Interesse der Union liegend betrachtet.

- (2) Im Interesse der Versorgungssicherheit und der Resilienz des Halbleiterökosystems der Union können die Mitgliedstaaten unbeschadet der Artikel 107 und 108 AEUV zugunsten strategischer Projekte im Einklang mit der Verordnung (EU) XXXX/XXXX [Europäischer Fonds für Wettbewerbsfähigkeit] und anderen einschlägigen Rechtsvorschriften der Union sowie zugunsten europäischer Halbleitertechnologieinitiativen Unterstützungsmaßnahmen anwenden und administrative Unterstützung leisten.

- (3) Darüber hinaus kann die Kommission Unterstützungsmaßnahmen, darunter unter anderem auch Finanzhilfen, auf strategische Projekte im Einklang mit der Verordnung (EU) XXXX/XXXX [Europäischer Fonds für Wettbewerbsfähigkeit] und anderen einschlägigen Rechtsvorschriften der Union anwenden.

<a id="art-14"></a>
### Artikel 14 – Europäische Halbleitertechnologieinitiativen

- (1) Europäische Halbleitertechnologieinitiativen werden von inländischen Unternehmen durchgeführt.

- (2) Europäische Halbleitertechnologieinitiativen müssen nachweisen, dass sie ihre Lieferkette so gestalten werden, dass die Abhängigkeit der Lieferkette von ausländischen Unternehmen verringert und die Versorgungssicherheit der Union gestärkt wird.

- (3) Europäische Halbleitertechnologieinitiativen sind neuartige Initiativen, die zur Unumgänglichkeit, zur Resilienz, zum Erfolg und zur Versorgungssicherheit des Halbleiterökosystem der Union beitragen.

- (4) Zum Zeitpunkt der Einreichung eines Antrags gemäß Artikel 15 Absatz 1 muss eine europäische Halbleitertechnologieinitiative die Voraussetzungen für die Einstufung als neuartige Initiative erfüllen.

- (5) Um den Status einer europäischen Halbleitertechnologieinitiative zu beantragen, brauchen neuartige Initiativen keine Unterstützungsmaßnahmen in Anspruch zu nehmen oder administrative Unterstützung gemäß Artikel 13 zu erhalten.

- (6) Eine europäische Halbleitertechnologieinitiative muss folgende Anforderungen erfüllen:

  - a) ihre Einrichtung hat auf die Halbleiterwertschöpfungskette der Union und die Endmärkte der Union im Hinblick darauf, die Unumgänglichkeit, die Resilienz und den Erfolg des Halbleiterökosystems und das Wachstum von Start-ups und KMU sicherzustellen und zum grünen und digitalen Wandel der Union sowie gegebenenfalls zum Geschäftsmodell der Anlage beizutragen, mittel- bis langfristig eindeutig positive Auswirkungen mit Ausstrahlungseffekten über sich selbst oder den bzw. die betreffenden Mitgliedstaat(en) hinaus, wobei insbesondere berücksichtigt wird, inwieweit die Initiative von ihrer Anlage unabhängigen Unternehmen Produktionskapazität im Front-End- oder Back-End-Bereich oder beidem anbietet, sofern eine ausreichende Nachfrage besteht;

  - b) sie bietet Gewähr dafür, dass sie nicht der extraterritorialen Anwendung gemeinwirtschaftlicher Verpflichtungen von Drittländern in einer Weise unterworfen ist, die die Fähigkeit des Unternehmens, seinen in Artikel 43 Absatz 1 festgelegten Verpflichtungen nachzukommen, untergraben könnte, und sie verpflichtet sich, die Kommission zu unterrichten, wenn eine solche Verpflichtung entstehen sollte;

  - c) sie investiert in der Union in kontinuierliche Innovation, um konkrete Fortschritte im Bereich der Halbleitertechnologie zu erzielen oder Halbleitertechnologien der nächsten Generation vorzubereiten;

  - d) sie unterstützt die Talentpipeline der Union durch die Entwicklung und den Einsatz von Bildungs- und Qualifizierungsmaßnahmen und durch die Ausweitung des Pools an qualifizierten Arbeitskräften;

  - e) falls es sich um eine Produktionsanlage handelt, beteiligt sie sich an der in Artikel 34 genannten Unternehmensplattform für die Halbleiterlieferkette.

- (7) Für die Zwecke von Investitionen in kontinuierliche Innovation gemäß Absatz 6 Buchstabe c des vorliegenden Artikels erhalten europäische Halbleitertechnologieinitiativen bevorzugten Zugang zu den gemäß Artikel 5 Buchstabe b eingerichteten Pilotanlagen. Durch einen solchen bevorzugten Zugang wird der effektive Zugang anderer interessierter Unternehmen, insbesondere Start-ups und KMU, zu den Pilotanlagen unter fairen Bedingungen weder ausgeschlossen noch verhindert.

- (8) Bietet eine europäische Halbleitertechnologieinitiative anderen Unternehmen, die von der Initiative unabhängig sind, Produktionskapazität an, so nimmt die Initiative eine angemessene und wirksame funktionale Trennung der Entwurfs- und Halbleiterfertigungsprozesse vor und erhält diese aufrecht, um den Schutz der in jeder Stufe erhaltenen Informationen sicherzustellen.

<a id="art-15"></a>
### Artikel 15 – Beantragung der Anerkennung als europäische Halbleitertechnologieinitiative

- (1) Jedes Unternehmen oder Unternehmenskonsortium kann bei der Kommission die Gewährung des Status einer europäischen Halbleitertechnologieinitiative beantragen.

- (2) Die Kommission prüft den Antrag unter Berücksichtigung der Stellungnahme des Europäischen Halbleitergremiums in einem fairen und transparenten Verfahren auf der Grundlage aller folgenden Aspekte:

  - a) Einhaltung der in Artikel 14 Absatz 2 festgelegten Kriterien und Übernahme der Verpflichtung, die in Artikel 14 Absatz 6 festgelegten Anforderungen einzuhalten;

  - b) Geschäftsplan mit einer Bewertung der finanziellen und technischen Tragfähigkeit des Projekts unter Berücksichtigung seiner gesamten Lebensdauer, einschließlich Informationen über etwaige geplante öffentliche Unterstützung;

  - c) nachgewiesene Erfahrung des Antragstellers mit dem Betrieb ähnlicher Anlagen;

  - d) Vorlage eines geeigneten Nachweises für die Bereitschaft des Mitgliedstaats bzw. der Mitgliedstaaten, in dem bzw. denen der Antragsteller seine Anlage anzusiedeln gedenkt, die Einrichtung einer solchen Initiative zu unterstützen;

  - e) Vorliegen geeigneter politischer Maßnahmen und geeigneter Lizenzvereinbarungen, einschließlich technischer Schutz- und Durchführungsmaßnahmen, die den Schutz von nicht offengelegten Informationen und Rechten des geistigen Eigentums sicherstellen sollen, insbesondere um die unbefugte Offenlegung von Geschäftsgeheimnissen oder die Preisgabe sensibler aufkommender Technologien zu verhindern.

    Die Kommission stellt Leitlinien zu den nach Unterabsatz 1 erforderlichen Informationen und deren jeweiligem Format bereit.

- (3) Die Kommission bearbeitet die Anträge, erlässt ihre Beschlüsse und benachrichtigt die Antragsteller innerhalb von drei Monaten nach Eingang eines vollständigen Antrags. Ist die Kommission der Auffassung, dass die im Antrag enthaltenen Informationen unvollständig sind, so gibt sie dem Antragsteller Gelegenheit, die zur Vervollständigung des Antrags erforderlichen zusätzlichen Informationen unverzüglich nachzureichen. In dem Beschluss der Kommission wird die Geltungsdauer des Status auf der Grundlage der voraussichtlichen Lebensdauer des Projekts festgelegt.

- (4) Die Kommission überwacht die Fortschritte bei der Einrichtung und dem Betrieb der europäischen Halbleitertechnologieinitiativen und unterrichtet das Europäische Halbleitergremium regelmäßig.

- (5) Der Betreiber der Initiative kann die Kommission ersuchen, die Dauer des Status zu überprüfen oder seine Durchführungspläne im Hinblick auf die Einhaltung der Anforderungen gemäß Artikel 14 Absatz 6 zu ändern, wenn er eine solche Überprüfung aufgrund unvorhergesehener äußerer Umstände für hinreichend gerechtfertigt hält. Auf der Grundlage einer solchen Überprüfung kann die Kommission die Dauer des gemäß Absatz 3 des vorliegenden Artikels gewährten Status ändern oder die Änderung der Durchführungspläne akzeptieren.

- (6) Stellt die Kommission fest, dass eine Initiative die in Artikel 14 Absatz 6 festgelegten Anforderungen nicht mehr erfüllt, so gibt sie dem Betreiber der europäischen Halbleitertechnologieinitiative Gelegenheit, Stellung zu nehmen und geeignete Maßnahmen vorzuschlagen.

- (7) Die Kommission kann einen Beschluss über die Anerkennung des Status einer europäischen Halbleitertechnologieinitiative aufheben, wenn die Anerkennung auf einem Antrag beruhte, der unrichtige Informationen enthielt, oder wenn die europäische Halbleitertechnologieinitiative trotz des Abschlusses des Verfahrens nach Absatz 5 des vorliegenden Artikels die in Artikel 14 Absatz 6 festgelegten Anforderungen nicht erfüllt. Bevor die Kommission einen solchen Beschluss erlässt, konsultiert sie das Europäische Halbleitergremium, nachdem sie ihm die Gründe für die vorgeschlagene Aufhebung mitgeteilt hat. Ein Beschluss über die Aufhebung des Status einer europäischen Halbleitertechnologieinitiative wird ordnungsgemäß begründet und kann vom Betreiber angefochten werden.

- (8) Initiativen, deren Status als europäische Halbleitertechnologieinitiative gemäß Absatz 7 des vorliegenden Artikels aufgehoben wurde, verlieren alle mit der Anerkennung dieses Status verbundenen Rechte, die sich aus dieser Verordnung ergeben. Diese Initiativen unterliegen jedoch während eines Zeitraums, der demjenigen entspricht, der zum Zeitpunkt der Gewährung des Status gemäß Absatz 3 des vorliegenden Artikels ursprünglich festgelegt war, oder – im Fall einer Überprüfung des Status – während der gemäß Absatz 5 des vorliegenden Artikels anzuwendenden Dauer weiterhin der in Artikel 42 Absatz 1 festgelegten Verpflichtung.

<a id="art-16"></a>
### Artikel 16 – Strategische Projekte

- (1) Die Kommission erkennt Halbleiterprojekte, die alle folgenden Anforderungen erfüllen, als strategische Projekte an:

  - a) es erbringt einen erheblichen Mehrwert für die Union, indem es einen wesentlichen Beitrag zu Zielen von gemeinsamem Unionsinteresse leistet;

  - b) das strategische Projekt wird von inländischen Unternehmen durchgeführt;

  - c) strategische Projekte müssen nachweisen, dass sie ihre Lieferkette so gestalten werden, dass die Abhängigkeit der Lieferkette von ausländischen Unternehmen verringert und die Versorgungssicherheit der Union gestärkt wird;

  - d) es weist eine eindeutige grenzüberschreitende Dimension auf, insbesondere durch technische Zusammenarbeit oder öffentliche Unterstützung, an denen mehrere Mitgliedstaaten beteiligt sind;

  - e) es trägt zur Resilienz und Robustheit der Halbleiterwertschöpfungskette der Union bei;

  - f) es trägt zur Stärkung der technologischen Souveränität und der technologischen Führungsposition der Union bei, indem es kritische Kapazitäten, Technologien oder Fähigkeiten innerhalb der Union ermöglicht, voranbringt oder sichert, unter anderem durch die Verringerung strategischer Abhängigkeiten.

- (2) Strategische Projekte mit mehreren Standorten werden von einem einzigen Konsortium betrieben und bilden eine integrierte rechtliche und technische Einheit.

- (3) Die Beteiligung an strategischen Projekten ist auf Rechtsträger aus der Union beschränkt.

- (4) Abweichend von Absatz 3 ist die Beteiligung von in Drittländern niedergelassenen Rechtsträgern zulässig, sofern diese Beteiligung mit den in Absatz 1 genannten Bedingungen vereinbar ist, und eine solche Beteiligung unterliegt den einschlägigen sicherheitsbezogenen Bedingungen der anwendbaren Unionsprogramme.

<a id="art-17"></a>
### Artikel 17 – Festlegung vorrangiger Bereiche für strategische Projekte

- (1) Eine technische Beschreibung der vorrangigen Bereiche für potenzielle strategische Projekte in bestimmten indikativen Technologiebereichen ist in Anhang II enthalten. Zur Aktualisierung der in Anhang II aufgeführten technischen Beschreibungen und indikativen Technologiebereiche, um dem technologischen Wandel und den für den Halbleitersektor relevanten Marktentwicklungen Rechnung zu tragen, wird der Kommission die Befugnis übertragen, gemäß Artikel 55 delegierte Rechtsakte zur Änderung des Anhangs II zu erlassen.

- (2) Die Kommission entscheidet unter Berücksichtigung der Stellungnahme des Europäischen Halbleitergremiums anhand der in Artikel 16 Absatz 1 festgelegten Kriterien und der in Anhang II genannten indikativen Technologiebereiche über die vorrangigen Bereiche für potenzielle strategische Projekte.

<a id="art-18"></a>
### Artikel 18 – Benennung strategischer Projekte

- (1) Die Durchführung von Maßnahmen zur Unterstützung potenzieller strategischer Projekte wird dem Gemeinsamen Unternehmen für Chips übertragen und im Wege von Maßnahmen durchgeführt, die in seinem Arbeitsprogramm festgelegt sind.

- (2) Die Kommission benennt unter Berücksichtigung der Stellungnahme des Europäischen Halbleitergremiums durch einen Beschluss die für eine Finanzierung durch das Gemeinsame Unternehmen für Chips ausgewählten Vorschläge als strategische Projekte, die die in Artikel 16 Absatz 1 genannten Kriterien erfüllen und die ihre Benennung beantragt haben.

- (3) Vorbehaltlich der Zustimmung der Antragsteller können auch Vorschläge, die nicht für eine Finanzierung durch das Gemeinsame Unternehmen für Chips ausgewählt wurden, als strategische Projekte benannt werden, wenn sie die in der Aufforderung zur Einreichung von Vorschlägen festgelegten Bewertungsanforderungen erfüllen und die in Artikel 16 Absatz 1 festgelegten Kriterien erfüllen. Die Möglichkeit einer solchen Benennung muss in den Aufforderungen zur Einreichung von Vorschlägen und den damit verbundenen Antragsverfahren klar angegeben sein, und die Benennung sollte von dem Projekt beantragt werden.

- (4) In dem Beschluss der Kommission wird angegeben, ob ein strategisches Projekt als neuartige Initiative im Sinne dieser Verordnung einzustufen ist, und die Geltungsdauer des Status einer neuartigen Initiative wird auf der Grundlage der voraussichtlichen Lebensdauer des Projekts festgelegt.

- (5) Projekte, die als strategische Projekte benannt sind, genießen die Rechte und unterliegen den Verpflichtungen, die gemäß dieser Verordnung für europäische Halbleitertechnologieinitiativen gelten, wenn sie die Anforderungen des Artikels 14 Absatz 6 erfüllen.

- (6) Das strategische Projekt kann die Kommission ersuchen, die Dauer des Status eines strategischen Projekts zu überprüfen oder die Durchführungspläne des Betreibers im Hinblick auf die Einhaltung der Anforderungen gemäß Artikel 16 Absatz 1 zu ändern, wenn der Betreiber eine solche Überprüfung aufgrund unvorhergesehener äußerer Umstände für hinreichend gerechtfertigt hält. Auf der Grundlage einer solchen Überprüfung kann die Kommission die Dauer des gewährten Status eines strategischen Projekts ändern oder die Änderung der Durchführungspläne akzeptieren.

- (7) Unbeschadet einer etwaigen Aussetzung oder Kündigung von Finanzierungsvereinbarungen zwischen dem Betreiber, der das strategische Projekt durchführt, und dem Gemeinsamen Unternehmen für Chips kann die Kommission unter Berücksichtigung der Stellungnahme des Europäischen Halbleitergremiums die Benennung dieses Projekts durch einen Beschluss widerrufen, wenn sie feststellt, dass ein als strategisches Projekt benanntes Projekt die in Artikel 16 festgelegten Kriterien nicht mehr erfüllt, oder wenn seine Benennung auf einem Antrag beruht, der unrichtige Informationen enthält, die die Einhaltung dieser Kriterien betreffen.

- (8) Bevor die Kommission einen Beschluss gemäß Absatz 6 dieses Artikels erlässt, teilt sie dem Betreiber, der das strategische Projekt durchführt, die Gründe für den vorgesehenen Widerruf mit und gibt ihm Gelegenheit, innerhalb einer angemessenen Frist dazu Stellung zu nehmen. Die Kommission trägt dieser Stellungnahme gebührend Rechnung. Ein Beschluss über den Widerruf des Status eines strategischen Projekts wird ordnungsgemäß begründet und kann angefochten werden.

- (9) Projekte, deren Benennung als strategisches Projekt widerrufen wurde, verlieren alle Rechte und Pflichten im Zusammenhang mit dem Status eines strategischen Projekts gemäß dieser Verordnung. Diese Projekte unterliegen jedoch während einer Dauer, die der bei der Gewährung des Status ursprünglich vorgesehenen Dauer entspricht, weiterhin der Verpflichtung nach Artikel 43 Absatz 1.

<a id="art-19"></a>
### Artikel 19 – Fortgeschrittene Halbleiterfertigung

- (1) Um die Souveränität der Union zu stärken und die Versorgungssicherheit bei Halbleitern zu gewährleisten, behandelt die Kommission im Einklang mit Artikel 17 Absatz 1 ein strategisches Projekt für einen in der Union ansässigen offenen Fertigungsbetrieb für die fortgeschrittene Halbleiterfertigung mit höchster Priorität.

- (2) Der in Absatz 1 genannte offene Fertigungsbetrieb für die fortgeschrittene Halbleiterfertigung bildet eine Anlage oder ein koordiniertes Netz von Anlagen mit mehreren Standorten im Gebiet der Union, die bzw. das die Fertigung und das Packaging fortgeschrittener Halbleitertechnik auf dem Stand der Technik der industriellen Produktion beherrscht.

- (3) Der offene Fertigungsbetrieb für die fortgeschrittene Halbleiterfertigung berücksichtigt die Anforderungen und Ziele potenzieller Abnehmer gemäß Artikel 8.

<a id="art-20"></a>
### Artikel 20 – Koordinierung der Finanzierung

- (1) Die Kommission kann, gegebenenfalls in Zusammenarbeit mit den Mitgliedstaaten, Maßnahmen durchführen, um zusätzliche Privatinvestitionen für europäische Halbleitertechnologieinitiativen und strategische Projekte zu gewinnen. Unbeschadet der Artikel 107 und 108 AEUV und in Synergie mit Unionsprogrammen kann zu solchen Tätigkeiten auch die Bereitstellung und Koordinierung von Unterstützung für europäische Halbleitertechnologieinitiativen und strategische Projekte gehören, die Schwierigkeiten beim Zugang zu Finanzmitteln haben.

- (2) Das Europäische Halbleitergremium leistet auf Ersuchen einer europäischen Halbleitertechnologieinitiative oder eines strategischen Projekts Beratung in Bezug auf die Finanzierung der Initiative oder des Projekts, wobei es neben der bereits gesicherten Finanzierung zumindest die folgenden Elemente berücksichtigt:

  - a) zusätzliche öffentliche und private Finanzierungsquellen, einschließlich Eigenkapital;

  - b) Unterstützung mit Mitteln der Europäischen Investitionsbank oder anderer Finanzinstitute;

  - c) bestehende Instrumente und Programme der Mitgliedstaaten, darunter auch Exportkreditagenturen und nationale Förderbanken und -institute;

  - d) einschlägige Förder- und Finanzierungsprogramme der Union.

<a id="chapter-ii-section-2"></a>
## Abschnitt 2 – Genehmigungsverfahren

<a id="art-21"></a>
### Artikel 21 – Beschleunigung von Genehmigungsverfahren

- (1) Die Mitgliedstaaten stellen sicher, dass Verwaltungsanträge in Bezug auf Planung, Bau und Betrieb europäischer Halbleitertechnologieinitiativen und strategischer Projekte effizient, transparent und zeitnah bearbeitet werden.

- (2) Das Genehmigungsverfahren für europäische Halbleitertechnologieinitiativen oder strategische Projekte darf eine Dauer von zwölf Monaten ab dem Zeitpunkt des Vorliegens eines vollständigen Antrags bei der zentralen Anlaufstelle nicht überschreiten.

- (3) Die in Absatz 2 festgelegte Frist lässt etwaige von den Mitgliedstaaten festgelegte kürzere Fristen unberührt.

- (4) Sofern ein solcher Status im nationalen Recht vorgesehen ist, erhalten europäische Halbleitertechnologieinitiativen und strategische Projekte den Status der höchsten nationalen Bedeutung und werden in Genehmigungsverfahren entsprechend behandelt. Dieser Absatz gilt nur, wenn ein solcher Status im nationalen Recht vorgesehen ist, und verpflichtet die Mitgliedstaaten nicht, einen solchen Status einzuführen.

<a id="art-22"></a>
### Artikel 22 – Zentrale Anlaufstelle für Genehmigungsverfahren

- (1) Die Mitgliedstaaten benennen eine zentrale Anlaufstelle, die für die Zentralisierung und Koordinierung der Beantragung europäischer Halbleitertechnologieinitiativen und strategischer Projekte gemäß diesem Artikel zuständig ist.

- (2) Die Mitgliedstaaten schaffen ein einheitliches Genehmigungsverfahren mit einer einzigen Beantragung bei der gemäß Artikel 22 Absatz 1 benannten zentralen Anlaufstelle, die alle Genehmigungen bearbeitet, die für europäische Halbleitertechnologieinitiativen und strategische Projekte erforderlich sind.

- (3) Die zentrale Anlaufstelle dient als einzige Kontaktstelle für die europäische Halbleitertechnologieinitiative oder das strategische Projekt.

- (4) Spätestens 45 Tage nach Eingang des einheitlichen Genehmigungsantrags bestätigt die benannte zentrale Anlaufstelle entweder, dass der Antrag vollständig ist, oder sie fordert die zur Bearbeitung des Antrags erforderlichen fehlenden Informationen an.

- (5) Wird der Antrag nach Übermittlung der fehlenden Informationen weiterhin als unvollständig betrachtet, so kann die zentrale Anlaufstelle innerhalb von 30 Tagen nach Übermittlung der fehlenden Informationen die Informationen, die weiterhin fehlen, ein zweites Mal anfordern. Die zentrale Anlaufstelle darf keine Informationen in Bereichen anfordern, die nicht Gegenstand der ersten Anforderung zusätzlicher Informationen sind, und sie darf zusätzliche Informationen nur insoweit anfordern, wie dies zur Ergänzung der fehlenden Informationen erforderlich ist.

- (6) Sind für die Errichtung einer europäischen Halbleitertechnologieinitiative Beschlüsse in zwei oder mehr Mitgliedstaaten erforderlich, so unternehmen die betreffenden zentralen Anlaufstellen alle erforderlichen Schritte für eine effiziente und wirksame Zusammenarbeit und Koordinierung untereinander.

<a id="art-23"></a>
### Artikel 23 – Erleichterung des Verwaltungs- und Genehmigungsverfahrens

- (1) Europäische Halbleitertechnologieinitiativen und strategische Projekte im Sinne dieser Verordnung gelten für die Zwecke des Artikels 14 Absatz 1 [des Vorschlags für eine Verordnung zur Beschleunigung von Umweltprüfungen] als strategische Projekte, die zu Resilienz und Dekarbonisierung oder Ressourceneffizienz beitragen. Es gelten die Nummern 1, 2 und 3 des Anhangs der genannten Verordnung.

- (2) Unbeschadet [des Vorschlags für eine Verordnung zur Beschleunigung von Umweltprüfungen] sorgen die Mitgliedstaaten dafür, dass alle Studien und alle Genehmigungen oder Zulassungen, die im Zusammenhang mit Planung, Bau und Betrieb europäischer Halbleitertechnologieinitiativen und mit strategischen Projekten durchgeführt bzw. erteilt wurden, berücksichtigt werden und dass keine doppelten Studien, Genehmigungen oder Zulassungen erforderlich sind, sofern nicht nach Unionsrecht oder nationalem Recht etwas anderes vorgeschrieben ist.

<a id="art-24"></a>
### Artikel 24 – Verwendung europäischer Unternehmensbrieftaschen durch das zentrale Zugangsportal

- (1) Die Mitgliedstaaten richten auf nationaler Ebene ein zentrales Zugangsportal für die Einreichung des in Artikel 22 Absatz 2 genannten einheitlichen Genehmigungsantrags für europäische Halbleitertechnologieinitiativen und strategische Projekte ein.

    Das zentrale Zugangsportal weist die Genehmigungsanträge automatisch der zuständigen Behörde zu, informiert den Antragsteller über sämtliche Schritte des Genehmigungsverfahrens, den Stand des Verfahrens und die Entscheidungen der zuständigen Behörden und geben dem Antragsteller die Möglichkeit, die Einhaltung der geltenden Fristen zu überprüfen.

- (2) Das zentrale Zugangsportal verwendet die gemäß [dem Vorschlag für eine Verordnung über die Einrichtung europäischer Unternehmensbrieftaschen] eingerichteten europäischen Unternehmensbrieftaschen.

- (3) Durch die Verwendung europäischer Unternehmensbrieftaschen ermöglicht das zentrale Zugangsportal Folgendes:

  - a) Interoperabilität und automatisierten Datenaustausch zwischen den einschlägigen Behörden;

  - b) Weiterverwendung von Daten und Dokumenten, die sich bereits im Besitz einschlägiger Behörden befinden;

  - c) ein hohes Maß an Cybersicherheit und Informationsintegrität;

  - d) Transparenz und Rechenschaftspflicht im Genehmigungsverfahren.

- (4) Bei der Einrichtung zentraler Zugangsportale nutzen die Mitgliedstaaten gegebenenfalls bestehende digitale Infrastrukturen, Kataloge und Bausteine der Union, die durch das Unionsrecht festgelegt sind.

- (5) Die in Artikel 22 dieser Verordnung genannte benannte zentrale Anlaufstelle hat zur Wahrnehmung ihrer Aufgaben Zugang zu allen im gemeinsamen Zugangsportal verfügbaren einschlägigen Daten und Informationen.

<a id="art-25"></a>
### Artikel 25 – Online-Zugänglichkeit von Informationen

- (1) Die Mitgliedstaaten gewähren online, zentral und in leichter Weise Zugang zu folgenden Informationen über Prozesse, die für europäische Halbleitertechnologieinitiativen und strategische Projekte von Belang sind:

  - a) die in Artikel 24 genannten europäischen Unternehmensbrieftaschen,

  - b) das Genehmigungsverfahren, einschließlich Informationen über die Beilegung von Streitigkeiten,

  - c) Finanzierungs- und Investitionsdienstleistungen,

  - d) Finanzierungsmöglichkeiten auf Ebene der Union oder der Mitgliedstaaten,

  - e) Dienstleistungen zur Unterstützung von Unternehmen, darunter u. a. Körperschaftsteuererklärungen, lokale Steuervorschriften oder Arbeitsrecht.

- (2) Die Kommission verweist auf ihrer Website in zentralisierter und leicht zugänglicher Weise auf die von den Mitgliedstaaten bereitgestellten Informationen, um einen umfassenden und klaren Überblick über alle einschlägigen Informationen je Mitgliedstaat zu gewährleisten.

<a id="chapter-ii-section-3"></a>
## Abschnitt 3 – Europäische Halbleiterexzellenzregionen

<a id="art-26"></a>
### Artikel 26 – Gütesiegel für europäische Halbleiterexzellenzregionen

- (1) Die Kommission kann beschließen, das Gütesiegel „Europäische Halbleiterexzellenzregion“ im Wege eines Durchführungsrechtsakts zu verleihen. Das Siegel kann auf Antrag einer regionalen Behörde mit ausdrücklicher Zustimmung des betreffenden Mitgliedstaats verliehen werden.

- (2) Der Antrag muss einen Investitionsplan der Halbleiterregion enthalten, aus dem eine gemeinsame strategische Zielsetzung aller einschlägigen Behörden hervorgeht.

- (3) Unbeschadet der für Programme und Instrumente der Union geltenden Vorschriften kann das Gütesiegel für europäische Halbleiterexzellenzregionen bei der Bewertung und Auswahl von Vorhaben, die im Rahmen von Finanzierungsprogrammen der Union vorgeschlagen werden, berücksichtigt werden.

<a id="art-27"></a>
### Artikel 27 – Investitionsplan der europäischen Halbleiterregion

- (1) Der Investitionsplan der europäischen Halbleiterregion gemäß Artikel 26 Absatz 2 enthält eine Beschreibung der Region, einschließlich des geografischen Anwendungsbereichs, und zumindest die folgenden Elemente:

  - a) strategische Zielsetzung und Anwendungsbereich:

    - i) Bewertung des bestehenden industriellen und Halbleiterökosystems in der Region, einschließlich bestehender Halbleiterfertigungsanlagen, relevante Endanwendersektoren, ihre Position in den Halbleiterwertschöpfungsketten unter besonderer Berücksichtigung ihrer Alleinstellungsmerkmale und ihres potenziellen Beitrags zur Resilienz und zum Wachstum in der europäischen Halbleiterwertschöpfungskette,

    - ii) eine strategische Zielsetzung für die Entwicklung der Region im Halbleiterbereich in den nächsten zehn Jahren, gegebenenfalls einschließlich der Umgestaltung bestehender Industrietätigkeiten oder ihrer Verknüpfung mit Tätigkeiten im Halbleiterbereich;

  - b) Verfügbarkeit und Weiterentwicklung der grundlegenden Voraussetzungen und Infrastrukturen in der betreffenden Region:

    - i) eine Beschreibung der Maßnahmen zur Gewährleistung des Zugangs zu ausreichender, zuverlässiger und sauberer Energie, einschließlich Netzkapazitäten und Dekarbonisierungspfaden, im Einklang mit dem im Europäischen Klimagesetz festgelegten Ziel der Klimaneutralität,

    - ii) eine Beschreibung der Verfügbarkeit geeigneter Flächen und Anlagen für Tätigkeiten im Zusammenhang mit der Halbleiterwertschöpfungskette, einschließlich Flächenwidmung, Flächennutzungsplanung und Industriestandorten,

    - iii) eine Beschreibung der Verkehrs-, Kommunikations- und Wasserinfrastrukturen, die für die Tätigkeiten im Zusammenhang mit der Halbleiterwertschöpfungskette in der Region von Belang sind,

    - iv) eine Beschreibung der Maßnahmen zur Vereinfachung und Beschleunigung der Genehmigungs-, Lizenzierungs- und Verwaltungsverfahren, einschließlich der Anbindung an die in Artikel 22 genannte zentrale Anlaufstelle;

  - c) Unterstützung von Innovations- und Forschungstätigkeiten in der betreffenden Region:

    - i) eine Beschreibung der Forschungs- und Innovationstätigkeiten und ihrer weiteren Unterstützung im Hinblick auf die Halbleiterwertschöpfungskette in der Region, einschließlich Synergien mit Forschungs- und Innovationsprogrammen der Mitgliedstaaten und der Union,

    - ii) eine Beschreibung der Zusammenarbeit mit Hochschulen, Forschungs- und Technologieorganisationen, gegebenenfalls einschließlich Verbindungen zu den Tätigkeiten von Pilotanlagen gemäß Artikel 5 Buchstabe b und zu Kompetenzzentren gemäß Artikel 6;

  - d) Unterstützung von Bildung, Kompetenzen und Arbeitskräften sowie deren Weiterentwicklung in der betreffenden Region:

    - i) eine Beschreibung der Maßnahmen zur Gewährleistung der Verfügbarkeit qualifizierter Arbeitskräfte für die Halbleiterbranche auf allen Ebenen, unter Ausnutzung von Synergien mit den Vorteilen des Kompetenzpakts^(71),

    - ii) eine Beschreibung der Partnerschaften zwischen Industrie, Bildungsanbietern und Behörden im Halbleiterbereich,

    - iii) eine Beschreibung der Maßnahmen zur Anwerbung, Bindung und Weiterbildung von Talenten in der Halbleiterbranche, gegebenenfalls auch internationaler Talente;

  - e) Steigerung der Attraktivität für Industrie und Investitionen sowie deren Weiterentwicklung in der betreffenden Region:

    - i) eine Beschreibung der Maßnahmen, mit denen private Investitionen, die für die Halbleiterwertschöpfungskette wichtig sind, angezogen und gehalten werden sollen,

    - ii) eine Beschreibung der Maßnahmen zur Integration kleiner und mittlerer Unternehmen und kleiner Midcap-Unternehmen in das regionale Ökosystem.

<a id="art-28"></a>
### Artikel 28 – Bewertung der Anträge auf das Gütesiegel für europäische Halbleiterexzellenzregionen

- (1) Die Kommission bewertet Anträge auf das Gütesiegel für europäische Halbleiterexzellenzregionen anhand der Kohärenz und Glaubwürdigkeit des Investitionsplans der Halbleiterregion und des Umfangs der Mitwirkung der zuständigen Behörden.

- (2) Die Kommission bearbeitet die Anträge, erlässt ihren in Artikel 26 Absatz 1 genannten Beschluss und teilt dies der Region, dem betreffenden Mitgliedstaat und dem Europäischen Halbleitergremium innerhalb von drei Monaten nach Eingang eines vollständigen Antrags mit.

- (3) Ist die Kommission der Auffassung, dass die im Antrag enthaltenen Informationen unvollständig sind, so teilt sie dies der betreffenden regionalen Behörde und dem betreffenden Mitgliedstaat unverzüglich mit und gibt ihnen Gelegenheit, die zur Vervollständigung des Antrags erforderlichen zusätzlichen Informationen nachzureichen.

- (4) In dem in Artikel 26 Absatz 1 genannten Beschluss der Kommission wird die Geltungsdauer des Gütesiegels für europäische Halbleiterexzellenzregionen auf der Grundlage der Bewertung des vorgelegten Investitionsplans der Halbleiterregion festgelegt.

- (5) Die regionale Behörde und der betreffende Mitgliedstaat überwachen die Fortschritte bei der Umsetzung des Investitionsplans der Halbleiterregion und unterrichten die Kommission und das Europäische Halbleitergremium mindestens einmal jährlich darüber.

- (6) Eine Zusammenfassung des Investitionsplans der Halbleiterregion, die keine wirtschaftlich sensiblen Informationen enthält und die Investitionen anziehen soll, wird auf beiden folgenden Wegen öffentlich zugänglich gemacht:

  - a) auf einer Website der Kommission,

  - b) auf einer Website des betreffenden Mitgliedstaats, der betreffenden Region und/oder der betreffenden zuständigen Behörden.

<a id="art-29"></a>
### Artikel 29 – Netz der europäischen Halbleiterexzellenzregionen

- (1) Es wird ein Netz der europäischen Halbleiterexzellenzregionen (im Folgenden „Netz“) eingerichtet.

- (2) Das Netz organisiert seine Arbeit selbstständig. Es kann seine eigenen Arbeitsmethoden festlegen, einschließlich der Organisation von Sitzungen, der Ernennung eines turnusmäßig unter den teilnehmenden Regionen wechselnden Vorsitzes und der Annahme informeller Vereinbarungen zur Erleichterung der Zusammenarbeit und des Informationsaustauschs.

- (3) Das Netz bringt Regionen zusammen, denen gemäß Artikel 26 das Gütesiegel für europäische Halbleiterexzellenzregionen verliehen wurde.

- (4) Das Netz verfolgt folgende Ziele:

  - a) Erleichterung der Zusammenarbeit und des Austauschs bewährter Verfahren zwischen europäischen Halbleiterexzellenzregionen;

  - b) Förderung des Netzes und seiner Tätigkeiten in Mitglieds- und anderen Regionen durch Öffentlichkeitsarbeit sowie Kommunikations- und Verbreitungsmaßnahmen, um die Sichtbarkeit und Beteiligung zu erhöhen;

  - c) Förderung von Synergien und Komplementaritäten zwischen regionalen Halbleiterökosystemen in der gesamten Union, auch in verschiedenen Segmenten der Halbleiterwertschöpfungskette;

  - d) Steigerung der Sichtbarkeit und Attraktivität der europäischen Halbleiterexzellenzregionen für private Investitionen und internationale Partnerschaften.

- (5) Die Kommission kann die Arbeit des Netzes erleichtern und Sitzungen, Workshops oder andere Tätigkeiten organisieren, um den Informationsaustausch und die Zusammenarbeit zwischen den teilnehmenden Regionen zu unterstützen.

<a id="chapter-ii-section-4"></a>
## Abschnitt 4 – Resilienz in den Lieferketten

<a id="art-30"></a>
### Artikel 30 – Vergabe öffentlicher Aufträge

- (1) Bei Vergabeverfahren, die in den Anwendungsbereich der Richtlinien 2014/23/EU, 2014/24/EU oder 2014/25/EU fallen und die am oder nach dem [OP: bitte Datum einfügen = ein Jahr nach dem Inkrafttreten] eingeleitet werden und Infrastrukturen, Ausrüstungen oder Systeme in Sektoren mit hoher Kritikalität gemäß Anhang I der Richtlinie (EU) 2022/2555 oder in anderen kritischen Sektoren gemäß Anhang II der genannten Richtlinie betreffen, können öffentliche Auftraggeber und Vergabestellen von den Wirtschaftsteilnehmern verlangen, dass sie zusammen mit ihren Angebotsunterlagen eine Erklärung zur Versorgungssicherheit im Hinblick auf den Bezug der in die Infrastrukturen, Ausrüstungen und Systeme eingebauten Halbleiter einreichen.

- (2) Die in Absatz 1 genannte Erklärung enthält Folgendes:

  - a) einen Überblick über die Unternehmen, die an der Lieferung der in das Produkt eingebauten Halbleiter beteiligt sind, einschließlich des Anteils inländischer Unternehmen;

  - b) den Mehrwert für die Union, der durch den Beitrag des Angebots zur Stärkung der europäischen Halbleiterlieferkette nachgewiesen wird, z. B. durch die Einbeziehung neuartiger Initiativen und strategischer Projekte als Anbieter bzw. Lieferanten;

  - c) die Resilienz- und Diversifizierungsstrategie des Bieters für die Halbleiterlieferkette, z. B. seine Strategie für die Doppelquellenbeschaffung mit zumindest einem inländischen Unternehmen, soweit dies möglich und angemessen ist;

  - d) Empfehlungen oder Verpflichtungen gemäß Artikel 31, soweit zutreffend;

  - e) die gemäß Artikel 32 durchgeführte Risikobewertung für die Versorgungssicherheit, soweit zutreffend.

- (3) Wird von Wirtschaftsteilnehmern eine Erklärung zur Versorgungssicherheit verlangt, so können öffentliche Auftraggeber und Vergabestellen in den Auftragsunterlagen Anforderungen an die Versorgungssicherheit bezüglich der Beschaffung von Halbleitern festlegen, die in die Infrastrukturen, Ausrüstungen oder Systeme, die Gegenstand des öffentlichen Auftrags sind, eingebaut sind. Dazu können öffentliche Auftraggeber und Vergabestellen technische Spezifikationen, Auswahlkriterien, Zuschlagskriterien oder Klauseln für die Auftragsausführung darin aufnehmen.

- (4) Die Anforderungen nach Absatz 3

  - a) sind an den Auftragsgegenstand geknüpft,

  - b) räumen dem öffentlichen Auftraggeber oder der Vergabestelle keine uneingeschränkte Wahlfreiheit ein;

  - c) sind in den Auftragsunterlagen oder in der Auftragsbekanntmachung ausdrücklich angegeben;

  - d) sind Nebenbedingungen und nicht entscheidend für die Auftragsvergabe;

  - e) stehen im Einklang mit den internationalen Verpflichtungen der Union.

- (5) Öffentliche Auftraggeber und Vergabestellen übermitteln ihrer zuständigen nationalen Behörde gemäß Artikel 48 dieser Verordnung die Liste der inländischen Unternehmen, die in den von den Wirtschaftsteilnehmern abgegebenen Erklärungen zur Versorgungssicherheit aufgeführt sind.

- (6) Die gemäß Artikel 48 dieser Verordnung zuständige nationale Behörde erstellt eine überprüfte Liste aller inländischen Unternehmen, die in Verfahren zur Vergabe öffentlicher Aufträge in dem Mitgliedstaat festgestellt wurden. Die Listen können unter Einhaltung der erforderlichen Vertraulichkeitsanforderungen gemäß Artikel 50 teilweise oder vollständig zwischen den Mitgliedstaaten ausgetauscht werden.

<a id="art-31"></a>
### Artikel 31 – Weitere Maßnahmen in Bezug auf die Vergabe öffentlicher Aufträge

- (1) Stellt die Kommission im Rahmen der gemäß Artikel 35 durchgeführten Überwachung ein potenzielles Lieferkettenrisiko fest, so kann sie nach Konsultation des Europäischen Halbleitergremiums für die in Artikel 30 Absatz 1 genannten Vergabeverfahren Empfehlungen an öffentliche Auftraggeber und Vergabestellen im Hinblick auf die Versorgung mit Halbleitern durch inländische Unternehmen richten.

- (2) Stellt die Kommission fest, dass die in Absatz 1 genannten Lieferkettenrisiken fortbestehen, so kann sie nach Konsultation des Europäischen Halbleitergremiums und unter Berücksichtigung der Grundsätze der Notwendigkeit und der Verhältnismäßigkeit einen Durchführungsbeschluss erlassen, in dem bestimmt wird, für welche der in Artikel 30 genannten Infrastrukturen, Ausrüstungen oder Systeme die öffentlichen Auftraggeber oder Auftraggeber von Wirtschaftsteilnehmern eine Erklärung zur Versorgungssicherheit verlangen müssen.

- (3) Öffentliche Auftraggeber und Vergabestellen können beschließen, die Anforderungen des in Absatz 2 des vorliegenden Artikels genannten Durchführungsbeschlusses nicht anzuwenden, wenn eine der folgenden Bedingungen erfüllt ist:

  - a) die benötigten Produkte oder Dienstleistungen können nur von bestimmten Wirtschaftsteilnehmern geliefert werden, es gibt keine vernünftige Alternative oder Ersatzlösung und der fehlende Wettbewerb ist nicht das Ergebnis einer künstlichen Einschränkung der Parameter des Auftragsvergabeverfahrens;

  - b) es wurden keine geeigneten Angebote oder keine geeigneten Teilnahmeanträge eingereicht, auch nicht bei einem ähnlichen früheren Auftragsvergabeverfahren, das von demselben öffentlichen Auftraggeber oder derselben Vergabestelle in den zwei Jahren vor Beginn des geplanten neuen Vergabeverfahrens eingeleitet wurde;

  - c) unter Berücksichtigung der nach Artikel 31 Absatz 2 Buchstabe d erklärten Elemente würde ihre Anwendung den öffentlichen Auftraggeber oder die Vergabestelle dazu verpflichten, Waren, Dienstleistungen oder Bauleistungen zu erwerben, die unverhältnismäßig hohe Kosten verursachen oder zu technischer Inkompatibilität bei Betrieb und Wartung führen würden.

  - d) Für die Zwecke des Buchstaben c können öffentliche Auftraggeber und Vergabestellen Kostenunterschiede, die auf der Grundlage von objektiven und transparenten Daten auf über 25 % geschätzt werden, als unverhältnismäßig betrachten.

<a id="art-32"></a>
### Artikel 32 – Risikoanfällige Sektoren

- (1) Nach Konsultation des Europäischen Halbleitergremiums und auf der Grundlage von Nachweisen für Risiken in der Lieferkette kann die Kommission im Wege eines Durchführungsbeschlusses einen oder mehrere der in Anhang V oder Anhang VI aufgeführten Sektoren oder deren Teilsektoren als risikoanfällig einstufen.

- (2) Die Kommission kann methodische Leitlinien für die Durchführung von Risikobewertungen für die Versorgungssicherheit herausgeben und mögliche Risikominderungsmaßnahmen für die als risikoanfällig eingestuften Sektoren empfehlen. Diese Leitlinien betreffen Folgendes:

  - a) Strategie für die Doppelquellenbeschaffung mit zumindest einem inländischen Unternehmen;

  - b) Kartierung der vor- und nachgelagerten Lieferkette;

  - c) Schwachstellenanalyse und Anfälligkeit für Lieferstörungen.

- (3) Die in Absatz 2 genannten Risikobewertungen für die Versorgungssicherheit können von öffentlichen Auftraggebern oder Vergabestellen im Zuge der in Artikel 30 Absatz 1 genannten Vergabeverfahren angefordert werden.

- (4) Kommt die Kommission nach Konsultation des Europäischen Halbleitergremiums zu dem Schluss, dass die empfohlenen Risikominderungsmaßnahmen nach Absatz 2, die zur Gewährleistung der Versorgungssicherheit bei Halbleitern oder Halbleiter enthaltenden Produkten erforderlich sind, von dem als risikoanfällig eingestuften Sektor nicht angemessen umgesetzt werden, so kann sie einen Durchführungsrechtsakt über spezifische Risikominderungsmaßnahmen erlassen, die Sektoren oder Teilsektoren für bestimmte Halbleiterprodukte ergreifen müssen, insbesondere Risikominderungsmaßnahmen in Bezug auf

  - a) die Durchführung einer Risikobewertung,

  - b) die Beschaffung von Halbleitern,

  - c) die Doppelquellenbeschaffung,

  - d) den Aufbau von Lagerbeständen,

  - e) eine Diversifizierung der Lieferquellen für Halbleiter oder zugehörige Komponenten.

- (5) Nach Erlass eines Durchführungsrechtsakts gemäß Absatz 4 kann die Kommission auf der Grundlage von Nachweisen für die ermittelten Lieferkettenrisiken, die bewältigt worden sind, und nach Konsultation des Europäischen Halbleitergremiums die Benennung als risikoanfällig widerrufen.

- (6) Die Kommission stützt ihre nach diesem Artikel durchgeführten Prüfungen auf Nachweise, darunter auf öffentlich zugängliche Informationen, auf Informationen, die im Rahmen von Auskunftsersuchen gemäß Artikel 38 eingeholt werden, oder auf ein wiederholtes Auftreten von Lieferkettenstörungen.

<a id="chapter-iv"></a>
## Kapitel IV – Überwachung und Krisenreaktion

<a id="chapter-iv-section-1"></a>
## Abschnitt 1 – Überwachung

<a id="art-33"></a>
### Artikel 33 – Strategische Kartierung des Halbleitersektors der Union

- (1) Die Kommission führt in Zusammenarbeit mit dem Europäischen Halbleitergremium eine strategische Kartierung des Halbleitersektors der Union durch. Die strategische Kartierung enthält eine Analyse der Stärken und Schwächen der Union im globalen Halbleitersektor und ermittelt Faktoren wie etwa

  - a) Schlüsselprodukte und kritische Infrastrukturen im Binnenmarkt, die von der Versorgung mit Halbleitern abhängig sind;

  - b) wesentliche Anwenderbranchen in der Union und ihre derzeitigen und erwarteten Erfordernisse und Abhängigkeiten, einschließlich einer Analyse der möglichen Risiken für die Versorgungssicherheit, auch im Zusammenhang mit unzureichenden Investitionen;

  - c) Schlüsselsegmente der Halbleiterlieferkette der Union, einschließlich Entwurf, Software für den Entwurf, Werkstoffe, Fertigungsausrüstung, Halbleiterfertigung und ausgelagerter Back-End-Fertigung;

  - d) die technologischen Merkmale, die Abhängigkeiten von Technologien und Anbietern aus Drittländern sowie Engpässe des Halbleitersektors der Union, einschließlich des Zugangs zu Inputs;

  - e) aktueller und erwarteter Bedarf an Kompetenzen und effektivem Zugang zu qualifizierten Arbeitskräften im Halbleitersektor;

  - f) gegebenenfalls die potenziellen Auswirkungen der in den Artikeln 41, 42 und 43 genannten Krisenmaßnahmen auf den Halbleitersektor.

- (2) Die Kommission unterrichtet das Europäische Halbleitergremium regelmäßig über die aggregierten Ergebnisse der strategischen Kartierung.

- (3) Die Kommission erstellt auf der Grundlage der Ergebnisse der gemäß Absatz 1 durchgeführten strategischen Kartierung und nach Konsultation des Europäischen Halbleitergremiums eine Liste von Frühwarnindikatoren. Die Kommission überprüft die Liste der Frühwarnindikatoren nach Konsultation des Europäischen Halbleitergremiums regelmäßig.

- (4) Die Kommission entwickelt nach Konsultation des Europäischen Halbleitergremiums einen Rahmen und eine Methodik für eine strategische Kartierung des Halbleitersektors. Erforderlichenfalls aktualisiert die Kommission den Rahmen und die Methodik.

- (5) Die strategische Kartierung stützt sich insbesondere auf öffentlich und gewerblich verfügbare Daten und einschlägige nicht vertrauliche Informationen von Unternehmen, auf das Ergebnis ähnlicher Analysen sowie auf die gemäß Artikel 57 Absatz 1 durchgeführten Bewertungen. In Fällen, in denen dies nicht ausreicht, um die strategische Kartierung gemäß Absatz 1 durchzuführen, kann die Kommission nach Konsultation des Europäischen Halbleitergremiums freiwillige Auskunftsersuchen an Akteure entlang der Halbleiterwertschöpfungskette in der Union richten. Die Kommission verwendet für die Zwecke solcher Auskunftsersuchen die in Artikel 50 genannten standardisierten und sicheren Mittel für die Erhebung und Verarbeitung von Informationen.

- (6) Alle gemäß dem vorliegenden Artikel erlangten Informationen werden im Einklang mit den in Artikel 50 festgelegten Vertraulichkeitspflichten behandelt.

- (7) Die Kommission nimmt nach Konsultation des Europäischen Halbleitergremiums Leitlinien für die Bereitstellung von Informationen gemäß Absatz 5 an. Erforderlichenfalls aktualisiert die Kommission diese Leitlinien.

<a id="art-34"></a>
### Artikel 34 – Unternehmensplattform für die Halbleiterlieferkette

- (1) Die Kommission sorgt für die Einrichtung der Unternehmensplattform für die Halbleiterlieferkette (im Folgenden „Plattform“), die als digitaler Zwilling der Halbleiterlieferkette dient, um deren Transparenz und Resilienz zu erhöhen. Die Plattform soll zumindest

  - a) Marktinformationen und aggregierte Daten erheben und als Beobachtungsstelle für den Halbleitermarkt dienen;

  - b) Daten von beteiligten Unternehmen in einem interoperablen Format erfassen;

  - c) den beteiligten Unternehmen aggregierte Erkenntnisse über Risiken in der Halbleiterlieferkette und Schwachstellen entlang der Halbleiterwertschöpfungskette bereitstellen, ohne dass solche Erkenntnisse einzelnen Unternehmen zuzuordnen sind;

  - d) Unternehmen, die entlang der Halbleiterlieferkette tätig sind, und Halbleiteranwender einbeziehen, insbesondere in den in Anhang VI genannten Sektoren;

  - e) in der Lage sein, Stresstests der Halbleiterlieferkette durchzuführen;

  - f) Frühwarnungen und Leitlinien für proaktive Maßnahmen für die beteiligten Unternehmen herausgeben, um das Risiko in ihrer Halbleiterlieferkette zu verringern;

  - g) Indikatoren zur Bewertung der Resilienz der europäischen Halbleiterlieferkette entwickeln und als Dashboard-Übersicht darstellen;

  - h) eine sichere Verarbeitungsumgebung bieten.

- (2) Die Beteiligung an der Plattform steht nur inländischen Unternehmen offen.

- (3) Der gesetzliche Vertreter der Plattform unterrichtet die Kommission unverzüglich über gegenwärtige oder zu erwartende Störungen der Halbleiterlieferkette.

<a id="art-35"></a>
### Artikel 35 – Überwachung und Antizipation

- (1) Die Kommission führt in Abstimmung mit dem Europäischen Halbleitergremium eine regelmäßige Überwachung der Halbleiterwertschöpfungskette durch, um Faktoren zu ermitteln, die die Versorgung mit Halbleitern oder den Handel mit Halbleitern stören, beeinträchtigen oder nachteilig beeinflussen können. Für die Zwecke dieser Verordnung umfasst die Überwachung folgende Tätigkeiten:

  - a) Überwachung der gemäß Artikel 33 ermittelten Frühwarnindikatoren,

  - b) Überwachung der Integrität der von den gemäß Artikel 36 ermittelten wichtigen Marktakteuren durchgeführten Tätigkeiten durch die Mitgliedstaaten und Berichterstattung der Mitgliedstaaten über erhebliche Ereignisse, die den regelmäßigen Ablauf dieser Tätigkeiten behindern könnten,

  - c) Ermittlung bewährter Verfahren für die präventive Risikominderung und mehr Transparenz im Halbleitersektor.

    Die Kommission legt nach Konsultation des Europäischen Halbleitergremiums die Häufigkeit der Überwachung auf der Grundlage des Bedarfs des Halbleitersektors fest.

    Die Kommission koordiniert die Tätigkeiten im Zusammenhang mit der Überwachung des Halbleitersektors auf der Grundlage von Informationen, die gemäß Artikel 33 oder Artikel 34 Absatz 3 oder aus anderen Quellen wie etwa von internationalen Partner erhoben wurden.

- (2) Die Kommission ersucht wichtige Marktakteure, eine repräsentative Gruppe von Halbleiteranwendern aus den kritischen Sektoren, repräsentative Organisationen der Halbleiterwertschöpfungskette und andere einschlägige Interessenträger, auf freiwilliger Basis Informationen für die Zwecke der Durchführung von Überwachungstätigkeiten gemäß Absatz 1 Buchstabe a bereitzustellen.

    Die Kommission achtet besonders auf KMU und Midcap-Unternehmen, um den mit der Informationserhebung verbundenen Verwaltungsaufwand so gering wie möglich zu halten.

- (3) Für die Zwecke des Absatzes 1 Unterabsatz 1 Buchstabe b können die Mitgliedstaaten wichtige Marktakteure auf freiwilliger Basis um Informationen ersuchen, sofern dies erforderlich und verhältnismäßig ist.

- (4) Für die Zwecke des Absatzes 3 erstellen und führen die gemäß Artikel 48 benannten zuständigen nationalen Behörden, eine Kontaktliste aller in ihrem Hoheitsgebiet niedergelassenen einschlägigen Unternehmen, die entlang der Halbleiterlieferkette tätig sind. Diese Liste wird der Kommission übermittelt. Die Kommission legt ein standardisiertes Format für die Kontaktliste fest, um die Interoperabilität zu gewährleisten.

- (5) Alle nach dem vorliegenden Artikel erlangten Informationen werden gemäß Artikel 50 behandelt.

- (6) Auf der Grundlage der im Rahmen der Tätigkeiten gemäß Absatz 1 erhobenen Informationen legt die Kommission dem Europäischen Halbleitergremium einen Bericht über die aggregierten Ergebnisse in Form regelmäßiger aktueller Informationen vor. Das Europäische Halbleitergremium tritt zusammen, um die Ergebnisse der Überwachung zu bewerten. Die Kommission lädt repräsentative Organisationen des Halbleitersektors zu diesen Sitzungen ein. Gegebenenfalls kann die Kommission wichtige Marktakteure, Halbleiteranwender aus den kritischen Sektoren, Behörden oder repräsentative Organisationen von Partnerdrittländern sowie Experten aus Wissenschaft und Zivilgesellschaft zu diesen Sitzungen einladen.

<a id="art-36"></a>
### Artikel 36 – Wichtige Marktakteure

Die Mitgliedstaaten ermitteln in Zusammenarbeit mit der Kommission gemäß Artikel 35 in ihrem Hoheitsgebiet niedergelassene wichtige Marktakteure entlang der Halbleiterlieferkette und berücksichtigen dabei Folgendes:

  - a) die Zahl der Unionsunternehmen, die von der von einem Marktakteur bereitgestellten Dienstleistung oder Ware abhängen;

  - b) den Marktanteil eines Marktakteurs auf dem Unions- oder Weltmarkt für solche Dienstleistungen oder Waren;

  - c) die Bedeutung eines Marktakteurs für die Aufrechterhaltung einer ausreichenden Versorgung mit einer Dienstleistung oder Ware in der Union unter Berücksichtigung der Verfügbarkeit alternativer Mittel für die Bereitstellung der Dienstleistung oder Ware;

  - d) die Auswirkungen einer Störung der Versorgung mit der vom Marktakteur bereitgestellten Dienstleistung oder Ware auf die Halbleiterlieferkette der Union und die davon abhängigen Märkte.

<a id="chapter-iv-section-2"></a>
## Abschnitt 2 – Warnungen und Aktivierung der Krisenstufe

<a id="art-37"></a>
### Artikel 37 – Warnungen und Präventivmaßnahmen

- (1) Erlangt eine gemäß Artikel 48 benannte zuständige nationale Behörde Kenntnis vom Risiko einer schwerwiegenden Störung der Versorgung mit Halbleitern oder verfügt sie über konkrete und zuverlässige Informationen über das Eintreten eines anderen einschlägigen Risikofaktors oder Ereignisses, so warnt sie unverzüglich die Kommission.

- (2) Erlangt die Kommission Kenntnis vom Risiko einer schwerwiegenden Störung der Versorgung mit Halbleitern oder verfügt sie über konkrete und zuverlässige Informationen über das Eintreten eines anderen einschlägigen Risikofaktors oder Ereignisses, einschließlich auf der Grundlage von Frühwarnindikatoren, aufgrund einer Warnung gemäß Absatz 1 oder von internationalen Partnern, so führt sie unverzüglich die folgenden Präventivmaßnahmen durch:

  - a) Einberufung einer außerordentlichen Sitzung des Europäischen Halbleitergremiums, um folgende Maßnahmen zu koordinieren:

    - i) Erörterung der Schwere der Störung der Versorgung mit Halbleitern,

    - ii) Erörterung, ob die Einleitung des in Artikel 39 genannten Verfahrens erforderlich und verhältnismäßig sein könnte,

    - iii) Erörterung, ob es angemessen, erforderlich und verhältnismäßig ist, dass die Mitgliedstaaten als Präventivmaßnahme gemeinsam Halbleiter, Zwischenprodukte oder Rohstoffe beschaffen (im Folgenden „gemeinsame Beschaffung“),

    - iv) Aufnahme eines Dialogs mit Interessenträgern der Halbleiterwertschöpfungskette, um Präventivmaßnahmen zu ermitteln, vorzubereiten und gegebenenfalls zu koordinieren,

    - v) Beratung der Kommission in der Frage, ob ein Auskunftsersuchen an die Plattform gemäß Artikel 38 gerichtet werden soll;

  - b) im Namen der Union durchgeführte Konsultation einschlägiger Drittländer oder Zusammenarbeit mit diesen im Namen der Union, um unter Einhaltung internationaler Verpflichtungen kooperative Lösungen zur Bewältigung von Störungen der Lieferkette zu finden; dazu kann gegebenenfalls die Durchführung der Koordinierung in einschlägigen internationalen Foren gehören;

  - c) Ersuchen an die gemäß Artikel 48 benannten zuständigen nationalen Behörden, den Stand der Vorsorge der wichtigen Marktakteure zu bewerten.

- (3) Jede gemeinsame Beschaffung, die im Anschluss an die in Absatz 2 Buchstabe a Ziffer iii genannte Erörterung durchgeführt wird, wird von den Mitgliedstaaten gemäß den in den Artikeln 38 und 39 der Richtlinie 2014/24/EU und in den Artikeln 56 und 57 der Richtlinie 2014/25/EU festgelegten Vorschriften durchgeführt.

<a id="art-38"></a>
### Artikel 38 – Präventive Informationsbeschaffung

- (1) Um das Risiko einer schwerwiegenden Störung der Versorgung mit Halbleitern zu bewerten, kann die Kommission nach Konsultation des Europäischen Halbleitergremiums auf der in Artikel 37 Absatz 2 Buchstabe a genannten außerordentlichen Sitzung Auskunftsersuchen an die Plattform oder an einzelne in der Halbleiterwertschöpfungskette tätige Unternehmen richten, die Dienstleistungen in der Union erbringen oder Produkte auf dem Unionsmarkt anbieten, wenn sie nicht an der Plattform beteiligt sind.

- (2) Bevor die Kommission ein Auskunftsersuchen stellt, kann sie eine freiwillige Konsultation einer repräsentativen Zahl einschlägiger Unternehmen durchführen, um den angemessenen und verhältnismäßigen Inhalt eines solchen Ersuchens zu ermitteln.

- (3) Ein Auskunftsersuchen an ein einzelnes Unternehmen enthält die Rechtsgrundlage und den Zweck des Ersuchens, wird auf das erforderliche Mindestmaß beschränkt und muss in Bezug auf die Menge der Daten und die Häufigkeit des Zugangs zu den angeforderten Daten verhältnismäßig sein. Darin wird die Frist für die Übermittlung der Informationen gesetzt, und es wird auf die möglichen Sanktionen gemäß Artikel 51 für die Bereitstellung unrichtiger, unvollständiger oder irreführender Informationen hingewiesen. Daten werden anonymisiert und gegebenenfalls aggregiert. Ergeht ein Auskunftsersuchen nach Absatz 5 an ein Unionsunternehmen, so unterrichtet die Kommission den Mitgliedstaat, in dem das betreffende Unternehmen niedergelassen ist, über dieses Ersuchen.

- (4) Ein Auskunftsersuchen an den gesetzlichen Vertreter der Plattform enthält dessen Rechtsgrundlage und Zweck, wird auf das erforderliche Mindestmaß beschränkt, muss in Bezug auf die Menge der Daten und die Häufigkeit des Zugangs zu den angeforderten Daten verhältnismäßig sein und berücksichtigt die Ziele der Plattform. Darin wird die Frist für die Übermittlung der Informationen gesetzt und es wird auf mögliche Sanktionen gemäß Artikel 51 hingewiesen.

- (5) Die Inhaber der Unternehmen oder ihre Vertreter und im Fall von juristischen Personen oder Vereinigungen ohne Rechtspersönlichkeit die nach Gesetz oder Satzung zur Vertretung berufenen Personen stellen die verlangten Informationen im Namen des betreffenden Unternehmens bzw. der betreffenden Unternehmensvereinigung bereit.

- (6) Die Kommission legt dem Europäischen Halbleitergremium aggregierte Informationen aus den Antworten auf die Auskunftsersuchen vor.

- (7) Der gesetzliche Vertreter der Plattform beantwortet keine Auskunftsersuchen, die nicht von der Kommission gestellt werden, es sei denn, er ist nach Unionsrecht oder nationalem Recht dazu rechtlich verpflichtet.

- (8) Alle nach dem vorliegenden Artikel erlangten Informationen werden gemäß Artikel 50 behandelt.

<a id="art-39"></a>
### Artikel 39 – Aktivierung der Krisenstufe

- (1) Eine Halbleiterkrise gilt als eingetreten, wenn die beiden folgenden Bedingungen erfüllt sind:

  - a) es bestehen schwerwiegende Störungen in der Halbleiterlieferkette oder schwerwiegende Hemmnisse für den Handel mit Halbleitern in der Union, die zu erheblichen Versorgungsengpässen bei Halbleitern, Zwischenprodukten oder Rohstoffen oder verarbeiteten Werkstoffen führen,

  - b) solche erheblichen Versorgungsengpässe verhindern die Bereitstellung, Reparatur oder Wartung wesentlicher Produkte, die von kritischen Sektoren verwendet werden, in einem Ausmaß, in dem das Funktionieren der kritischen Sektoren aufgrund ihrer Auswirkungen auf Gesellschaft, Wirtschaft und Sicherheit der Union ernsthaft beeinträchtigt würde.

- (2) Erlangt die Kommission gemäß Artikel 37 Absatz 2 Kenntnis von einer potenziellen Halbleiterkrise, so bewertet sie, ob die Bedingungen des Absatzes 1 erfüllt sind. Bei dieser Bewertung werden die potenziellen positiven und negativen Auswirkungen und Folgen der Krisenstufe auf die Halbleiterindustrie und kritische Sektoren der Union berücksichtigt. Ergibt diese Bewertung konkrete und zuverlässige Belege, so kann die Kommission dem Rat nach Konsultation des Europäischen Halbleitergremiums vorschlagen, die Krisenstufe zu aktivieren.

- (3) Der Rat kann die Krisenstufe mit qualifizierter Mehrheit im Wege eines Durchführungsrechtsakts aktivieren. Die Geltungsdauer der Krisenstufe wird in dem Durchführungsrechtsakt festgelegt und beträgt höchstens zwölf Monate.

    Die Kommission berichtet dem Europäischen Halbleitergremium und dem Europäischen Parlament regelmäßig und jedenfalls mindestens alle drei Monate über den Stand der Krise.

- (4) Vor Ablauf der Geltungsdauer, für die die Krisenstufe aktiviert wurde, bewertet die Kommission, ob es angemessen ist, die Krisenstufe zu verlängern. Ergibt eine solche Bewertung konkrete und zuverlässige Belege dafür, dass die Bedingungen für die Aktivierung der Krisenstufe noch erfüllt sind, so kann die Kommission dem Rat nach Konsultation des Europäischen Halbleitergremiums vorschlagen, die Krisenstufe zu verlängern.

    Der Rat kann die Krisenstufe mit qualifizierter Mehrheit im Wege eines Durchführungsrechtsakts verlängern. Die Geltungsdauer der Verlängerung ist begrenzt und wird in dem Durchführungsrechtsakt festgelegt.

    Die Kommission kann vorschlagen, die Krisenstufe einmal oder öfter zu verlängern, wenn dies hinreichend gerechtfertigt ist.

- (5) Während der Krisenstufe bewertet die Kommission nach Konsultation des Europäischen Halbleitergremiums die Angemessenheit einer vorzeitigen Beendigung der Krisenstufe. Wenn die Bewertung dies ergibt, kann die Kommission dem Rat vorschlagen, die Krisenstufe zu beenden.

    Der Rat kann die Krisenstufe im Wege eines Durchführungsrechtsakts beenden.

- (6) Während der Krisenstufe beruft die Kommission erforderlichenfalls auf Antrag eines Mitgliedstaats oder von sich aus außerordentliche Sitzungen des Europäischen Halbleitergremiums ein.

    Die Mitgliedstaaten arbeiten eng mit der Kommission zusammen, unterrichten zeitnah über alle nationalen Maßnahmen, die im Rahmen des Europäischen Halbleitergremiums in Bezug auf die Halbleiterlieferkette ergriffen werden, und koordinieren diese.

- (7) Mit Ablauf der Geltungsdauer, für die die Krisenstufe aktiviert wurde, oder im Fall ihrer vorzeitigen Beendigung gemäß Absatz 5 endet umgehend die Anwendung der gemäß den Artikeln 41, 42 und 43 ergriffenen Maßnahmen.

- (8) Die Kommission aktualisiert die Kartierung und die Überwachung der Halbleiterwertschöpfungsketten gemäß den Artikeln 33 und 35 unter Berücksichtigung der Erfahrungen aus der Krise spätestens sechs Monate nach Ablauf der Geltungsdauer der Krisenstufe.

<a id="chapter-iv-section-3"></a>
## Abschnitt 3 – Reaktion auf Engpässe

<a id="art-40"></a>
### Artikel 40 – Notfallinstrumentarium

- (1) Wird die Krisenstufe gemäß Artikel 39 aktiviert und ist dies zur Bewältigung der Halbleiterkrise in der Union erforderlich, so kann die Kommission die in Artikel 41, 42 oder 43 vorgesehene Maßnahme unter den dort festgelegten Bedingungen ergreifen.

- (2) Die Kommission beschränkt die Anwendung der in den Artikeln 42 und 43 vorgesehenen Maßnahmen nach Konsultation des Europäischen Halbleitergremiums auf die kritischen Sektoren, deren Betrieb aufgrund der Halbleiterkrise von Störungen betroffen oder bedroht ist. Die Anwendung der in Absatz 1 genannten Maßnahmen muss verhältnismäßig und auf das Maß beschränkt sein, das zur Bewältigung schwerwiegender Störungen mit Auswirkungen auf kritische Sektoren in der Union erforderlich ist, und im besten Interesse der Union liegen. Bei der Anwendung dieser Maßnahmen wird vermieden, insbesondere KMU und kleinen Midcaps einen unverhältnismäßigen Verwaltungsaufwand aufzuerlegen.

- (3) Wird die Krisenstufe gemäß Artikel 39 aktiviert und ist dies zur Bewältigung der Halbleiterkrise in der Union geeignet, so kann das Europäische Halbleitergremium

  - a) geeignete und wirksame Notfallmaßnahmen bewerten und diesbezüglich beraten;

  - b) die erwarteten Auswirkungen einer möglichen Einführung von Schutzmaßnahmen auf den Halbleitersektor der Union bewerten, wobei es berücksichtigt, ob die Marktlage einem erheblichen Mangel an lebenswichtigen Gütern gemäß der Verordnung (EU) 2015/479 entspricht, und eine Stellungnahme an die Kommission abgeben.

- (4) Die Kommission unterrichtet das Europäische Parlament und den Rat regelmäßig über alle gemäß Absatz 1 ergriffenen Maßnahmen und erläutert die Gründe für ihren Beschluss.

- (5) Die Kommission kann nach Konsultation des Europäischen Halbleitergremiums Leitlinien für die Durchführung und die Anwendung der Notfallmaßnahmen herausgeben.

<a id="art-41"></a>
### Artikel 41 – Informationsbeschaffung in der Krisenstufe

- (1) Wird die Krisenstufe gemäß Artikel 39 aktiviert, so kann die Kommission alle entlang der Halbleiterlieferkette tätigen Unternehmen auffordern, Informationen über ihr Produktionsvermögen, ihre Produktionskapazitäten und ihre derzeitigen Hauptstörungen bereitzustellen. Die verlangten Informationen werden auf das beschränkt, was erforderlich ist, um die Art der Halbleiterkrise zu bewerten oder mögliche Gegen- oder Notfallmaßnahmen auf Unions- oder nationaler Ebene zu ermitteln und zu bewerten. Die Auskunftsersuchen dürfen nicht zur Bereitstellung von Informationen führen, deren Offenlegung den nationalen Sicherheitsinteressen der Mitgliedstaaten zuwiderlaufen würde.

- (2) Bevor die Kommission ein Auskunftsersuchen stellt, kann sie eine freiwillige Konsultation einer repräsentativen Zahl einschlägiger Unternehmen durchführen, um den angemessenen und verhältnismäßigen Inhalt eines solchen Ersuchens zu ermitteln. Die Kommission erarbeitet das Auskunftsersuchen in Zusammenarbeit mit dem Europäischen Halbleitergremium.

- (3) Die Kommission verwendet die sicheren Mittel und behandelt alle erlangten Informationen gemäß Artikel 50, um das Auskunftsersuchen zu stellen. Zu diesem Zweck übermitteln die gemäß Artikel 48 benannten zuständigen nationalen Behörden der Kommission die gemäß Artikel 35 Absatz 4 erstellte Kontaktliste.

    Die Kommission leitet eine Kopie des Auskunftsersuchens unverzüglich an die gemäß Artikel 48 benannte zuständige nationale Behörde des Mitgliedstaats weiter, in dessen Hoheitsgebiet sich die Produktionsstätte des betreffenden Unternehmens befindet. Auf Verlangen der zuständigen nationalen Behörde übermittelt die Kommission die von dem betreffenden Unternehmen erlangten Informationen im Einklang mit dem Unionsrecht.

- (4) Das Auskunftsersuchen enthält dessen Rechtsgrundlage, wird auf das erforderliche Mindestmaß beschränkt, muss im Hinblick auf die Granularität und den Umfang der Daten sowie die Häufigkeit des Zugangs zu den angeforderten Daten verhältnismäßig sein und berücksichtigt die legitimen Ziele des Unternehmens sowie die Kosten und den Aufwand, die für die Bereitstellung der Daten erforderlich sind; es enthält die Frist, innerhalb derer die Informationen bereitzustellen sind. Außerdem wird darin auf die in Artikel 51 vorgesehenen Sanktionen hingewiesen.

- (5) Die Inhaber der Unternehmen oder ihre Vertreter und im Fall von juristischen Personen oder Vereinigungen ohne Rechtspersönlichkeit die nach Gesetz oder Satzung zur Vertretung berufenen Personen stellen die verlangten Informationen im Namen des betreffenden Unternehmens bzw. der betreffenden Unternehmensvereinigung bereit.

- (6) Stellt ein Unternehmen auf ein Ersuchen nach dem vorliegenden Artikel unrichtige, unvollständige oder irreführende Informationen bereit oder stellt es die Informationen nicht innerhalb der gesetzten Frist bereit, so werden gemäß Artikel 51 festgesetzte Geldbußen verhängt, es sei denn, das Unternehmen hat die verlangten Informationen aus hinreichend gerechtfertigten Gründen nicht bereitgestellt.

- (7) Erhält ein Unionsunternehmen oder ein Tochterunternehmen, das im Eigentum und unter der Kontrolle dieses Unternehmens steht, ein Auskunftsersuchen von einem Drittland im Zusammenhang mit seinen Halbleitertätigkeiten, so übermittelt es der Kommission unverzüglich die von dem Drittland verlangten und die von ihm an das Drittland übermittelten Informationen. Die Kommission unterrichtet das Europäische Halbleitergremium über das Vorliegen eines solchen Ersuchens aus einem Drittland und über die von dem Unternehmen übermittelten Informationen.

<a id="art-42"></a>
### Artikel 42 – Vorrangige Aufträge

- (1) Wird die Krisenstufe gemäß Artikel 39 aktiviert, so kann die Kommission europäische Halbleitertechnologieinitiativen und strategische Projekte dazu verpflichten, einen Auftrag über krisenrelevante Produkte anzunehmen und vorrangig zu behandeln (im Folgenden „vorrangiger Auftrag“). Eine solche Verpflichtung geht jeder anderen Erfüllungsverpflichtung nach privatem oder öffentlichem Recht vor.

- (2) Gegebenenfalls kann die Verpflichtung nach Absatz 1 anderen Halbleiterunternehmen auferlegt werden, die diese Möglichkeit im Rahmen des Erhalts öffentlicher Unterstützung akzeptiert haben.

- (3) Unterliegt ein in der Union niedergelassenes Halbleiterunternehmen einer Maßnahme zur Erfüllung eines vorrangigen Auftrags gegenüber einem Drittland, so unterrichtet es die Kommission. Wirkt sich diese Verpflichtung erheblich auf den Betrieb bestimmter kritischer Sektoren aus, so kann die Kommission das Unternehmen, sofern erforderlich und verhältnismäßig, dazu verpflichten, Aufträge über krisenrelevante Produkte gemäß den Absätzen 5, 6 und 7 anzunehmen und vorrangig zu behandeln.

- (4) Vorrangige Aufträge sind Begünstigten vorbehalten, bei denen es sich um Halbleiteranwender aus kritischen Sektoren oder um Unternehmen, die kritische Sektoren beliefern, handelt, deren Tätigkeiten gestört sind oder gestört zu werden drohen und die nach Durchführung geeigneter Risikominderungsmaßnahmen nicht in der Lage waren, die Auswirkungen des Engpasses durch andere Mittel zu vermeiden und abzufedern. Die Kommission kann einen Begünstigten auffordern, entsprechende Nachweise vorzulegen.

- (5) Die Verpflichtungen nach den Absätzen 1, 2 und 3 werden von der Kommission als letztes Mittel durch einen Beschluss auferlegt. Die Kommission fasst diesen Beschluss nach Konsultation des Europäischen Halbleitergremiums und unter Beachtung aller in der Union für die Umstände des Falls geltenden rechtlichen Verpflichtungen, einschließlich der Grundsätze der Notwendigkeit und Verhältnismäßigkeit. Der Beschluss trägt insbesondere den legitimen Zielen des betreffenden Unternehmens sowie den Kosten, dem Aufwand und den technischen Anpassungen Rechnung, die für jede Änderung der Produktionsreihenfolge erforderlich sind. In ihrem Beschluss nennt die Kommission die Rechtsgrundlage des vorrangigen Auftrags, setzt die Frist für die Erfüllung des Auftrags, legt gegebenenfalls das Produkt und die Menge fest und weist gegebenenfalls auf die in Artikel 51 für die Missachtung dieser Verpflichtung vorgesehenen Sanktionen hin. Der vorrangige Auftrag wird zu einem fairen und angemessenen Preis vergeben.

- (6) Vor der Erteilung vorrangiger Aufträge gemäß Absatz 1 gibt die Kommission dem vorgesehenen Empfänger eines vorrangigen Auftrags Gelegenheit, sich zur Durchführbarkeit und zu den Einzelheiten des Auftrags zu äußern. Die Kommission erteilt den vorrangigen Auftrag nicht, wenn

  - a) das Unternehmen wegen unzureichenden Produktionsvermögens oder wegen unzureichender Produktionskapazität oder aus technischen Gründen nicht in der Lage ist, den vorrangigen Auftrag zu erfüllen, selbst wenn es diesen Auftrag vorrangig behandelt;

  - b) die Annahme des Auftrags eine unzumutbare wirtschaftliche Belastung und eine besondere Härte für das Unternehmen darstellen würde, einschließlich erheblicher Risiken im Zusammenhang mit der Betriebskontinuität.

- (7) Ist ein Unternehmen verpflichtet, einen vorrangigen Auftrag anzunehmen und vorrangig zu behandeln, so haftet es nicht für etwaige Verstöße gegen vertragliche Pflichten, die erforderlich sind, um die vorrangigen Aufträge zu erfüllen. Die Haftungsbefreiung gilt nur insoweit, als der Verstoß gegen vertragliche Pflichten für die Einhaltung der vorgeschriebenen Rangfolge erforderlich war.

- (8) Die Kommission erlässt einen Durchführungsrechtsakt zur Festlegung der praktischen und operativen Modalitäten für die Funktionsweise vorrangiger Aufträge. Dieser Durchführungsrechtsakt wird gemäß dem in Artikel 55 Absatz 6 genannten Prüfverfahren erlassen.

<a id="art-43"></a>
### Artikel 43 – Gemeinsame Beschaffung

- (1) Wird die Krisenstufe gemäß Artikel 39 aktiviert, so kann die Kommission auf Antrag von zwei oder mehr Mitgliedstaaten als zentrale Beschaffungsstelle im Namen aller zur Teilnahme bereiten Mitgliedstaaten (im Folgenden „teilnehmende Mitgliedstaaten“) bei der Vergabe ihrer öffentlichen Aufträge über krisenrelevante Produkte für kritische Sektoren tätig werden (im Folgenden „gemeinsame Beschaffung“). Die Teilnahme an der gemeinsamen Beschaffung lässt andere Vergabeverfahren unberührt. Der Antrag auf gemeinsame Beschaffung enthält die Gründe, auf die er sich stützt, und wird ausschließlich zur Behebung von Störungen der Halbleiterlieferkette, die zur Krise geführt haben, genutzt.

- (2) Die Kommission bewertet unter Berücksichtigung der Standpunkte des Europäischen Halbleitergremiums den Nutzen, die Notwendigkeit und die Verhältnismäßigkeit des Antrags. Beabsichtigt die Kommission, dem Antrag nicht nachzukommen, so unterrichtet sie die betreffenden Mitgliedstaaten und das Europäische Halbleitergremium und nennt die Gründe für ihre Ablehnung.

- (3) Die Kommission arbeitet einen Vorschlag für eine Vereinbarung aus, die von den teilnehmenden Mitgliedstaaten zu unterzeichnen ist. Diese Vereinbarung regelt die in Absatz 1 genannte gemeinsame Beschaffung im Einzelnen; sie enthält die Gründe für die Verwendung des Mechanismus der gemeinsamen Beschaffung und der einzugehenden Verbindlichkeiten und legt das Mandat der Kommission fest, im Namen der teilnehmenden Mitgliedstaaten zu handeln.

- (4) Die Beschaffung im Rahmen der vorliegenden Verordnung wird von der Kommission im Einklang mit den für ihre eigenen Beschaffungsverfahren geltenden Vorschriften der Verordnung (EU, Euratom) 2024/2509 durchgeführt. Die Kommission kann die Befugnis und Zuständigkeit erhalten, im Namen aller teilnehmenden Mitgliedstaaten Verträge mit Wirtschaftsteilnehmern, auch einzelnen Herstellern krisenrelevanter Produkte, über den Erwerb solcher Produkte oder über die Finanzierung der Herstellung oder Entwicklung solcher Produkte im Gegenzug für ein vorrangiges Zugriffsrecht auf das Ergebnis zu schließen.

- (5) Umfasst die Beschaffung krisenrelevanter Produkte eine Finanzierung aus dem Unionshaushalt, so können in besonderen Vereinbarungen mit Wirtschaftsteilnehmern besondere Bedingungen festgelegt werden.

- (6) Die Kommission führt die Beschaffungsverfahren durch und schließt die Verträge mit Wirtschaftsteilnehmern im Namen der teilnehmenden Mitgliedstaaten. Die Kommission fordert die teilnehmenden Mitgliedstaaten auf, Vertreter zu benennen, die an der Vorbereitung der Beschaffungsverfahren teilnehmen. Für die Einführung, die Verwendung oder den Weiterverkauf der erworbenen Produkte bleiben im Einklang mit der in Absatz 3 genannten Vereinbarung die teilnehmenden Mitgliedstaaten zuständig.

- (7) Die Durchführung der gemeinsamen Beschaffung gemäß diesem Artikel lässt andere in der Verordnung (EU, Euratom) 2024/2509 vorgesehene Instrumente unberührt.

<a id="chapter-v"></a>
## Kapitel V – Governance

<a id="chapter-v-section-1"></a>
## Abschnitt 1 – Europäisches Halbleitergremium

<a id="art-44"></a>
### Artikel 44 – Aufgaben des Europäischen Halbleitergremiums

- (1) Das Europäische Halbleitergremium unterstützt die Kommission in Fragen der Halbleiterpolitik der Union und insbesondere durch

  - a) die Beratung des Rates der öffentlichen Körperschaften des Gemeinsamen Unternehmens für Chips in Bezug auf die Initiative „Chips für Europa 2.0“;

  - b) die Beratung der Kommission in strategischen Technologiebereichen innerhalb der Halbleiterwertschöpfungskette;

  - c) die Beratung der Kommission bei der Bewertung der Anträge auf Anerkennung als europäische Halbleitertechnologieinitiativen und strategische Projekte;

  - d) die Aufnahme eines strukturierten Dialogs mit dem Lenkungsausschuss der Industrieallianz für Halbleiter im Hinblick auf die Festlegung einer gemeinsamen Halbleiterstrategie;

  - e) den Gedankenaustausch mit der Kommission über die Fortschritte bei der Umsetzung der Investitionspläne der Halbleiterexzellenzregionen;

  - f) den Gedankenaustausch mit der Kommission über die besten Wege, um im Einklang mit dem Unionsrecht und dem nationalen Recht einen wirksamen Schutz und eine wirksame Durchsetzung von Rechten des geistigen Eigentums, vertraulichen Informationen und Geschäftsgeheimnissen unter gebührender Einbeziehung von Interessenträgern in Bezug auf den Halbleitersektor sicherzustellen;

  - g) die Erörterung und Vorbereitung der Ermittlung spezifischer Sektoren und Technologien mit potenziell hoher sozialer oder ökologischer Wirkung oder Bedeutung für die Sicherheit, für die daher eine Zertifizierung als grüne, vertrauenswürdige und sichere Produkte nötig ist;

  - h) die Befassung mit Fragen der strategischen Kartierung, Überwachung, Warnung sowie Präventivmaßnahmen und Krisenreaktion;

  - i) die Beratung zu den Instrumenten für die Krisenstufe gemäß den Artikeln 40 bis 43;

  - j) die Beratung und Abgabe von Empfehlungen bezüglich der einheitlichen Durchführung dieser Verordnung, die Erleichterung der Zusammenarbeit zwischen den Mitgliedstaaten und des Informationsaustauschs über Fragen im Zusammenhang mit dieser Verordnung;

  - k) die Beratung der Kommission in Fragen der internationalen Zusammenarbeit im Zusammenhang mit Halbleitern.

- (2) Das Gremium berät und unterrichtet die Kommission über die Prioritäten der Mitgliedstaaten im Halbleitersektor und stellt dazu insbesondere regelmäßig aktuelle Informationen über Folgendes bereit:

  - a) ihre nationale Halbleiterpolitik,

  - b) einschlägige öffentliche und private Investitionen im Hoheitsgebiet des von ihnen vertretenen Mitgliedstaats,

  - c) internationale Verpflichtungen, einschließlich Forschung und Entwicklung sowie Innovations- und Kompetenzaustauschprogramme mit Drittländern.

- (3) Das Europäische Halbleitergremium gewährleistet gegebenenfalls die Koordinierung, die Zusammenarbeit und den Informationsaustausch mit den einschlägigen Krisenreaktions- und Krisenvorsorgestrukturen, die nach Unionsrecht geschaffen wurden.

<a id="art-45"></a>
### Artikel 45 – Struktur des Europäischen Halbleitergremiums

- (1) Das Europäische Halbleitergremium setzt sich aus Vertretern aller Mitgliedstaaten zusammen. Den Vorsitz im Europäischen Halbleitergremium führt ein Vertreter der Kommission.

- (2) Jeder Mitgliedstaat benennt einen hochrangigen Vertreter im Europäischen Halbleitergremium. Soweit dies im Hinblick auf die Funktion und Sachkenntnis zweckdienlich ist, kann ein Mitgliedstaat mehr als einen Vertreter in Bezug auf verschiedene Aufgaben des Europäischen Halbleitergremiums haben. Jedes Mitglied des Europäischen Halbleitergremiums hat einen Stellvertreter. Nur Mitgliedstaaten sind stimmberechtigt. Jeder Mitgliedstaat hat unabhängig von der Zahl seiner Vertreter nur eine Stimme.

- (3) Der Vorsitz kann ständige oder nichtständige Untergruppen zur Prüfung spezifischer Fragen einsetzen.

    Der Vorsitz lädt gegebenenfalls repräsentative Organisationen der Halbleiterwertschöpfungskette, den Lenkungsausschuss der Industrieallianz für Halbleiter und dessen jeweilige Arbeitsgruppen, Gewerkschaften und Halbleiteranwender auf Unionsebene ein, als Beobachter zu solchen Untergruppen Beiträge zu liefern.

<a id="art-46"></a>
### Artikel 46 – Arbeitsweise des Europäischen Halbleitergremiums

- (1) Das Europäische Halbleitergremium hält mindestens einmal jährlich eine ordentliche Sitzung ab. Es kann auf Antrag der Kommission oder eines Mitgliedstaats und zur Erledigung seiner Aufgaben nach Artikel 37 und Artikel 39 außerordentliche Sitzungen abhalten.

- (2) Das Europäische Halbleitergremium hält gesonderte Sitzungen für seine in Artikel 44 Absatz 1 genannten Aufgaben ab.

- (3) Der Vorsitz beruft die Sitzungen ein und bereitet die Tagesordnung im Einklang mit den Aufgaben des Europäischen Halbleitergremiums gemäß dieser Verordnung und gemäß seiner Geschäftsordnung vor.

    Die Kommission leistet gemäß Artikel 44 administrative und analytische Unterstützung für die Tätigkeiten des Europäischen Halbleitergremiums.

- (4) Gegebenenfalls bezieht der Vorsitz repräsentative Organisationen des Halbleitersektors ein, lädt Experten mit besonderer Sachkenntnis im betreffenden Fachgebiet, auch von Organisationen der Interessenträger wie dem Netz der europäischen Halbleiterexzellenzregionen, ein und benennt – auch auf Vorschlag von Mitgliedern – Beobachter zur Teilnahme an den Sitzungen. Der Vorsitz kann den Austausch zwischen dem Europäischen Halbleitergremium und anderen Einrichtungen, Ämtern, Agenturen und Experten- und Beratungsgruppen der Union, auch der Industrieallianz für Halbleiter, fördern. Der Vorsitz gewährleistet, dass der Lenkungsausschuss der Industrieallianz für Halbleiter zumindest einmal jährlich eingeladen wird, den aktuellen Stand darzulegen und wichtige Aspekte des europäischen strategischen Ansatzes für die Halbleitertechnik zu erörtern.

- (5) Der Vorsitz lädt einen Vertreter des Europäischen Parlaments als ständigen Beobachter in das Europäische Halbleitergremium ein, insbesondere zu Sitzungen, die Kapitel IV zur Überwachung und Krisenreaktion betreffen. Der Vorsitz gewährleistet die Teilnahme anderer einschlägiger Organe und Einrichtungen der Union als Beobachter im Europäischen Halbleitergremium im Hinblick auf Sitzungen, die Kapitel IV zur Überwachung und Krisenreaktion betreffen.

    Beobachter und Experten haben kein Stimmrecht und nehmen nicht an der Ausarbeitung von Stellungnahmen, Empfehlungen oder Ratschlägen des Europäischen Halbleitergremiums und seiner Untergruppen teil. Gegebenenfalls kann das Europäische Halbleitergremium diese Beobachter und Experten einladen, Informationen und Erkenntnisse beizusteuern.

- (6) Das Europäische Halbleitergremium trifft die erforderlichen Maßnahmen, um die sichere Behandlung und Verarbeitung vertraulicher Informationen gemäß Artikel 50 zu gewährleisten.

<a id="art-47"></a>
### Artikel 47 – Internationale Zusammenarbeit und strategische Halbleiterpartnerschaften

- (1) Das Europäische Halbleitergremium berät die Kommission in Fragen der internationalen Zusammenarbeit im Zusammenhang mit Halbleitern. Dazu erörtert das Europäische Halbleitergremium regelmäßig Folgendes:

  - a) das Ausmaß, in dem die internationale Zusammenarbeit der Union im Halbleiterbereich und strategische Halbleiterpartnerschaften zu Folgendem beitragen:

    - – Verbesserung der Unumgänglichkeit, der Resilienz und des Erfolgs der Union,

    - – Verbesserung der Zusammenarbeit entlang der Halbleiterwertschöpfungskette zwischen der Union und internationalen Partnern, auch im Bereich Forschung und Innovation,

    - – Bewältigung des Wissens- und Fachkräftemangels und des Missverhältnisses zwischen Qualifizierungsangebot und -nachfrage durch Anwerbung, Mobilisierung und Bindung neuer Talente für die Union;

  - b) die Abstimmung und potenzielle Synergien zwischen der bilateralen Zusammenarbeit der Mitgliedstaaten mit einschlägigen internationalen Partnern und den Maßnahmen im Rahmen ihrer internationalen Zusammenarbeit im Halbleiterbereich, einschließlich strategischer Halbleiterpartnerschaften;

  - c) die Frage, welche internationalen Partner mit Blick auf den Abschluss strategischer Halbleiterpartnerschaften Vorrang haben sollten, wobei folgende Kriterien zu berücksichtigen sind:

    - – der potenzielle Beitrag zu Versorgungssicherheit, Unumgänglichkeit, Resilienz und Erfolg unter Berücksichtigung der potenziellen Kapazitäten eines Partners im Zusammenhang mit Halbleitern, der Diversifizierung und der Abhängigkeiten,

    - – ob der Rechtsrahmen eines Partners die Überwachung und Minimierung von Umweltauswirkungen, die Anwendung sozial verantwortlicher Verfahren, die Anwendung transparenter Geschäftspraktiken und die Vermeidung nachteiliger Auswirkungen auf das ordnungsgemäße Funktionieren der öffentlichen Verwaltung und die Rechtsstaatlichkeit gewährleistet,

    - – ob es bestehende Kooperationsabkommen zwischen einem Drittland oder Gebiet und der Union gibt, und – im Falle von Schwellen- und Entwicklungsländern – das Potenzial für die Einführung von Global-Gateway^(72)-Investitionsprojekten,

    - – ob der Rechtsrahmen des Partners oder der einschlägige anwendbare Rahmen die Anwendung von Ausfuhrkontrollen für Technologien vorsieht, die den Zugang zu Gütern und Technologien, die für die Konzeption, Entwicklung, Herstellung oder Verwendung von Gütern in der EU erforderlich sind, oder die Ausfuhr von Gütern und Technologien, die in der EU konzipiert, entwickelt oder hergestellt wurden, beschränken könnten.

- (2) Die Kommission ermöglicht und unterstützt die Zusammenarbeit des Europäischen Halbleitergremiums mit anderen einschlägigen Koordinierungsforen, einschließlich derjenigen, die im Rahmen des Global Gateway^(73) eingerichtet wurden.

- (3) Die Mitgliedstaaten gewährleisten die Kohärenz zwischen ihrer bilateralen Zusammenarbeit mit internationalen Partnern und der internationalen Zusammenarbeit der Union im Halbleiterbereich, einschließlich nicht verbindlicher strategischer Partnerschaften. Sie unterstützen die Kommission auch bei der Durchführung der Kooperationsmaßnahmen im Rahmen der internationalen Zusammenarbeit der Union im Halbleiterbereich, einschließlich strategischer Halbleiterpartnerschaften.

<a id="chapter-v-section-2"></a>
## Abschnitt 2 – Zuständige nationale Behörden

<a id="art-48"></a>
### Artikel 48 – Benennung zuständiger nationaler Behörden und nationaler zentraler Anlaufstellen

- (1) Jeder Mitgliedstaat benennt eine oder mehrere zuständige nationale Behörden zur Gewährleistung der Anwendung und Durchführung dieser Verordnung auf nationaler Ebene.

- (2) Benennt ein Mitgliedstaat mehr als eine zuständige nationale Behörde, so legt er die jeweiligen Zuständigkeiten der betreffenden Behörden eindeutig fest und stellt sicher, dass sie wirksam und effizient zusammenarbeiten, um ihre Aufgaben im Rahmen dieser Verordnung zu erfüllen, auch bezüglich der Benennung und der Tätigkeiten der in Absatz 3 genannten nationalen zentralen Anlaufstelle.

- (3) Jeder Mitgliedstaat benennt eine nationale zentrale Anlaufstelle, die als Verbindungsstelle zur Gewährleistung der grenzübergreifenden Zusammenarbeit mit den zuständigen nationalen Behörden anderer Mitgliedstaaten, mit der Kommission und mit dem Europäischen Halbleitergremium fungiert. Benennt ein Mitgliedstaat nur eine zuständige nationale Behörde, so ist diese zuständige nationale Behörde auch die zentrale Anlaufstelle.

- (4) Jeder Mitgliedstaat teilt der Kommission die Benennung der zuständigen nationalen Behörde oder von mehr als einer zuständigen nationalen Behörde und die Benennung der nationalen zentralen Anlaufstelle mit, einschließlich ihrer genauen Aufgaben und Zuständigkeiten gemäß dieser Verordnung, ihrer Kontaktangaben und etwaiger späterer Änderungen. Die nationale zentrale Anlaufstelle teilt der Kommission eine Funktionsmailbox mit.

- (5) Die Mitgliedstaaten stellen sicher, dass die zuständigen nationalen Behörden, einschließlich der benannten nationalen zentralen Anlaufstelle, ihre Befugnisse unparteiisch, transparent und zeitnah ausüben und dass ihnen die nötigen Befugnisse verliehen und angemessene technische, finanzielle und personelle Ressourcen zur Erfüllung ihrer Aufgaben gemäß dieser Verordnung zur Verfügung gestellt werden.

- (6) Die Mitgliedstaaten stellen sicher, dass die zuständigen nationalen Behörden im Einklang mit dem Unionsrecht und dem nationalen Recht, wenn dies zweckmäßig ist, andere einschlägige nationale Behörden sowie einschlägige interessierte Parteien konsultieren und mit ihnen zusammenarbeiten.

    Die Kommission fördert den Erfahrungsaustausch zwischen den zuständigen nationalen Behörden.

<a id="chapter-v-section-3"></a>
## Abschnitt 3 – Industrieallianz

<a id="art-49"></a>
### Artikel 49 – Industrieallianz für Halbleiter

- (1) Es wird eine Industrieallianz für Halbleiter (im Folgenden „Allianz“) eingerichtet.

- (2) Die Allianz bringt einschlägige Interessenträger zusammen, um die Kommission und die Mitgliedstaaten in Fragen zu unterstützen, die für die Halbleiterbranche der Union von Belang sind, beispielsweise:

  - a) aktuelle Markt- und Branchentrends,

  - b) die Halbleiterentwurfs- und -fertigungskapazitäten der Union,

  - c) neu entstehende Halbleitertechnologien und ihre Auswirkungen,

  - d) Feststellungen und Empfehlungen im Hinblick auf die Bewältigung der industriellen Stärken und Schwächen der Union,

  - e) Strategien zur Beschleunigung der Industrialisierung von Innovationen,

  - f) geopolitische Entwicklungen, die sich auf die Branche auswirken,

  - g) Steigerung der globalen Wettbewerbsfähigkeit der Union,

  - h) Beiträge zur Funktionsweise der Nachfragebeschleuniger,

  - i) Beiträge zur Funktionsweise des Nachfrageforums.

- (3) Mitglieder der Allianz sind Vertreter der Halbleiterwertschöpfungskette der Union, darunter Unternehmen, Start-up-Unternehmen, Forschungs- und Technologieorganisationen und Anwendersektoren, die die folgenden Kriterien erfüllen:

  - a) Sie haben nachgewiesene Erfahrung, Kenntnisse und Fähigkeiten im Halbleiterbereich;

  - b) sie tragen zur Halbleiterversorgungssicherheit der Union bei oder haben des zugesagt;

  - c) sie sind auf dem europäischen Markt einschlägig präsent oder haben zugesagt, eine solche Präsenz in der Union aufzubauen.

- (4) Die Kommission ernennt die Mitglieder der Allianz anhand der in Absatz 4 festgelegten Kriterien.

- (5) Den Vorsitz in der Allianz führt ein Vertreter der Kommission.

- (6) Die Allianz hält mindestens einmal jährlich eine Generalversammlung ab. Sie kann auf Antrag des Vorsitzes der Allianz oder auf Antrag eines Mitglieds des Lenkungsausschusses mit Zustimmung des Vorsitzes außerordentliche Sitzungen abhalten.

- (7) Der Vorsitz beruft die Sitzungen ein und bereitet die Tagesordnung im Einklang mit seiner Geschäftsordnung und den Aufgaben der Allianz gemäß dieser Verordnung vor.

- (8) Die Kommission setzt innerhalb der Allianz einen Lenkungsausschuss ein. Der Lenkungsausschuss führt mindestens einmal jährlich einen strategischen Dialog mit dem Europäischen Halbleitergremium gemäß Artikel 44.

- (9) Der Vorsitz der Allianz oder der Lenkungsausschuss mit Zustimmung des Vorsitzes kann ständige oder nichtständige Arbeitsgruppen zur Prüfung spezifischer Fragen einsetzen.

<a id="chapter-vi"></a>
## Kapitel VI – Vertraulichkeit und Sanktionen

<a id="art-50"></a>
### Artikel 50 – Behandlung vertraulicher Informationen

- (1) Die im Zuge der Durchführung dieser Verordnung erlangten Informationen dürfen nur für die Zwecke dieser Verordnung verwendet werden und sind durch die einschlägigen Rechtsvorschriften der Union und der Mitgliedstaaten geschützt.

- (2) Nicht vertrauliche Informationen, die gemäß dieser Verordnung erlangt werden, werden den nationalen statistischen Stellen und Eurostat für die Zwecke der Erstellung von Statistiken gemäß der Verordnung (EU) 2024/3018 des Europäischen Parlaments und des Rates übermittelt.

- (3) Informationen, die gemäß den Artikeln 14, 33, 35, 38 und 41 sowie Artikel 46 erlangt werden, fallen unter das Berufsgeheimnis und genießen den Schutz, der durch die für die Organe der Union geltenden Vorschriften und das einschlägige nationale Recht gewährt wird, einschließlich des Auslösens der bei Verstößen gegen diese Vorschriften anwendbaren Bestimmungen.

- (4) Die Kommission und die nationalen Behörden, ihre Beamten, ihre Bediensteten und sonstige Personen, die unter Aufsicht dieser Behörden tätig sind, gewährleisten die Vertraulichkeit der bei der Durchführung ihrer Aufgaben erlangten Informationen, sodass insbesondere Rechte des geistigen Eigentums und sensible Geschäftsinformationen oder Geschäftsgeheimnisse geschützt werden. Diese Verpflichtung gilt für alle Vertreter der Mitgliedstaaten, Beobachter, Experten und sonstige Personen, die an Sitzungen des Europäischen Halbleitergremiums gemäß Artikel 44 teilnehmen, sowie die Mitglieder des Halbleiterausschusses gemäß Artikel 56 Absatz 1.

- (5) Die Kommission sieht standardisierte und sichere Mittel für die Erhebung, Verarbeitung und Speicherung der gemäß dieser Verordnung erlangten Informationen vor.

- (6) Sofern erforderlich, können die Kommission und die Mitgliedstaaten mit den zuständigen Behörden von Drittländern, mit denen sie bilaterale oder multilaterale Vertraulichkeitsvereinbarungen getroffen haben, um ein angemessenes Niveau an Vertraulichkeit zu gewährleisten, die gemäß den Artikeln 35, 38 und 39 erlangten Informationen ausschließlich in aggregierter Form austauschen, sodass verhindert wird, dass Rückschlüsse auf die spezifische Situation eines Unternehmens in einem Mitgliedstaat gezogen werden können. Bevor die Kommission oder die Mitgliedstaaten einen Informationsaustausch aufnehmen, teilen sie dem Europäischen Halbleitergremium die Informationen, die weitergegeben werden sollen, und die entsprechende Vertraulichkeitsvereinbarung mit.

    Beim Austausch von Informationen mit den zuständigen Behörden von Drittländern benennt und nutzt die Kommission eine zentrale Anlaufstelle in der Union, um die vertrauliche Übermittlung dieser Informationen oder Daten gemäß den einschlägigen Verfahren der Kommission zu erleichtern.

- (7) Die Kommission kann Durchführungsrechtsakte erlassen, um die praktischen Modalitäten der Behandlung vertraulicher Informationen im Rahmen des Informationsaustauschs gemäß dieser Verordnung festzulegen, sofern dies auf der Grundlage der Erfahrungen bei der Einholung von Informationen erforderlich ist. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 56 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-51"></a>
### Artikel 51 – Sanktionen

- (1) Wird es als erforderlich und verhältnismäßig erachtet, so kann die Kommission einen Beschluss erlassen um

  - a) Geldbußen zu verhängen, wenn ein Unternehmen vorsätzlich oder grob fahrlässig auf ein Ersuchen gemäß Artikel 38 oder Artikel 41 unrichtige, unvollständige oder irreführende Informationen bereitstellt oder die Informationen nicht innerhalb der vorgeschriebenen Frist bereitstellt;

  - b) Geldbußen zu verhängen, wenn ein Unternehmen vorsätzlich oder grob fahrlässig der Verpflichtung zur Unterrichtung der Kommission über eine Drittlandsverpflichtung gemäß Artikel 38 Absatz 8, Artikel 41 Absatz 7 und Artikel 42 Absatz 3 nicht nachkommt;

  - c) Zwangsgelder zu verhängen, wenn ein Unternehmen vorsätzlich oder grob fahrlässig einer Verpflichtung zur vorrangigen Herstellung krisenrelevanter Produkte gemäß Artikel 42 nicht nachkommt.

- (2) Bevor die Kommission einen Beschluss gemäß Absatz 1 erlässt, gibt sie den Unternehmen Gelegenheit, sich gemäß Artikel 54 dazu zu äußern. Bei der Feststellung, ob Geldbußen oder Zwangsgelder als erforderlich und verhältnismäßig erachtet werden, berücksichtigt sie alle von diesen Unternehmen vorgebrachten hinreichend substantiierten Gründe.

- (3) Die in den in Absatz 1 Buchstabe a genannten Fällen verhängten Geldbußen dürfen 300 000 EUR nicht übersteigen.

    Die in den in Absatz 1 Buchstabe b genannten Fällen verhängten Geldbußen dürfen 150 000 EUR nicht übersteigen.

    Handelt es sich bei dem betreffenden Unternehmen um ein KMU, so dürfen die verhängten Geldbußen 50 000 EUR nicht übersteigen.

- (4) Die in dem in Absatz 1 Buchstabe c genannten Fall verhängten Zwangsgelder dürfen 1,5 % des derzeitigen Tagesumsatzes für jeden Arbeitstag, an dem die Missachtung der gemäß Artikel 43 auferlegten Verpflichtung anhält, gerechnet ab dem im Beschluss zur Erteilung des vorrangigen Auftrags festgelegten Tag, nicht übersteigen.

    Handelt es sich bei dem betreffenden Unternehmen um ein KMU, so dürfen die verhängten Zwangsgelder 0,5 % des derzeitigen Tagesumsatzes nicht übersteigen.

- (5) Bei der Festsetzung der Höhe der Geldbuße oder des Zwangsgelds berücksichtigt die Kommission die Art, Schwere und Dauer des Verstoßes, auch in Fällen der Missachtung der Verpflichtung gemäß Artikel 43, einen Auftrag anzunehmen und vorrangig zu behandeln und ob das Unternehmen den vorrangigen Auftrag teilweise erfüllt hat, wobei den Grundsätzen der Verhältnismäßigkeit und Angemessenheit gebührend Rechnung getragen wird.

- (6) Hat das Unternehmen die Anforderung, zu deren Durchsetzung das Zwangsgeld verhängt wurde, erfüllt, so kann die Kommission die endgültige Höhe des Zwangsgelds auf einen Betrag festsetzen, der unter demjenigen Betrag liegt, welcher sich aus dem ursprünglichen Beschluss ergeben würde.

- (7) Der Gerichtshof hat die unbeschränkte Befugnis zur Überprüfung von Beschlüssen der Kommission zur Verhängung von Geldbußen oder Zwangsgeldern. Er kann die verhängten Geldbußen oder Zwangsgelder aufheben, herabsetzen oder erhöhen.

<a id="art-52"></a>
### Artikel 52 – Verjährungsfrist für die Verhängung von Sanktionen

- (1) Die der Kommission mit Artikel 51 übertragenen Befugnisse unterliegen folgenden Verjährungsfristen:

  - a) zwei Jahre bei Verstößen gegen Bestimmungen über Auskunftsersuchen gemäß Artikel 38 oder 41,

  - b) zwei Jahre bei Verstößen gegen Bestimmungen über die Verpflichtung zur Unterrichtung gemäß Artikel 38 Absatz 8, Artikel 41 Absatz 7 und Artikel 42 Absatz 3,

  - c) drei Jahre bei Verstößen gegen Bestimmungen über die Verpflichtung zur vorrangigen Herstellung krisenrelevanter Produkte gemäß Artikel 42.

- (2) Die Verjährungsfrist gemäß Absatz 1 läuft ab dem Tag, an dem der Verstoß begangen wurde. Bei anhaltenden oder wiederholten Verstößen läuft die Verjährungsfrist ab dem Tag, an dem der letzte Verstoß begangen wurde.

- (3) Jedes Tätigwerden der Kommission oder der zuständigen nationalen Behörden der Mitgliedstaaten, das dazu dient, die Einhaltung dieser Verordnung sicherzustellen, unterbricht die Verjährungsfrist.

- (4) Die Unterbrechung der Verjährungsfrist gilt für alle Parteien, die sich für eine Beteiligung an dem Verstoß verantworten müssen.

- (5) Nach jeder Unterbrechung beginnt die Frist von Neuem. Die Verjährung tritt jedoch spätestens mit dem Tag ein, an dem die doppelte Verjährungsfrist verstrichen ist, ohne dass die Kommission eine Geldbuße oder ein Zwangsgeld verhängt hat. Diese Frist verlängert sich um den Zeitraum, in dem die Verjährungsfrist gehemmt ist, weil gegen den Beschluss der Kommission ein Verfahren vor dem Gerichtshof anhängig ist.

<a id="art-53"></a>
### Artikel 53 – Verjährungsfrist für die Durchsetzung von Sanktionen

- (1) Die Befugnis der Kommission zur Durchsetzung von gemäß Artikel 51 gefassten Beschlüssen unterliegt einer Verjährungsfrist von drei Jahren.

- (2) Die Frist läuft ab dem Tag, an dem der Beschluss rechtskräftig wird.

- (3) Die Verjährungsfrist für die Durchsetzung von Geldbußen und Zwangsgeldern wird unterbrochen durch

  - a) die Bekanntgabe eines Beschlusses, durch den der ursprüngliche Betrag der Geldbuße oder des Zwangsgelds geändert oder ein Antrag auf eine solche Änderung abgelehnt wird,

  - b) jede auf die Durchsetzung der Geldbuße oder des Zwangsgelds gerichtete Maßnahme der Kommission oder eines Mitgliedstaats, der auf Ersuchen der Kommission handelt.

- (4) Nach jeder Unterbrechung beginnt die Frist von Neuem.

- (5) Die Verjährungsfrist für die Durchsetzung von Geldbußen und Zwangsgeldern wird gehemmt, solange

  - a) eine Zahlungsfrist bewilligt ist,

  - b) die Durchsetzung aufgrund einer Entscheidung des Gerichtshofs ausgesetzt ist.

<a id="art-54"></a>
### Artikel 54 – Anspruch auf rechtliches Gehör vor der Verhängung von Sanktionen

- (1) Bevor die Kommission einen Beschluss nach Artikel 51 erlässt, gibt sie dem betreffenden Unternehmen Gelegenheit, sich zu Folgendem zu äußern:

  - a) der vorläufigen Beurteilung der Kommission, einschließlich der Beschwerdepunkte,

  - b) den Maßnahmen, die die Kommission in Anbetracht der vorläufigen Beurteilung nach Buchstabe a gegebenenfalls zu treffen beabsichtigt.

- (2) Die betreffenden Unternehmen können sich innerhalb einer Frist, die von der Kommission in ihrer vorläufigen Beurteilung nach Absatz 1 Buchstabe a gesetzt wird und mindestens 14 Tage beträgt, zur vorläufigen Beurteilung der Kommission äußern.

- (3) Die Kommission stützt ihre Beschlüsse nur auf Beschwerdepunkte, zu denen sich die betreffenden Unternehmen äußern konnten.

- (4) Die Verteidigungsrechte des betreffenden Unternehmens werden während des Verfahrens in vollem Umfang gewahrt. Das betreffende Unternehmen hat vorbehaltlich des berechtigten Interesses von Unternehmen an der Wahrung ihrer Geschäftsgeheimnisse das Recht auf Einsicht in die Akte der Kommission im Rahmen einer einvernehmlichen Einsichtnahme. Vom Recht auf Akteneinsicht ausgenommen sind vertrauliche Informationen sowie interne Unterlagen der Kommission oder der Behörden der Mitgliedstaaten. Insbesondere die Korrespondenz zwischen der Kommission und den Behörden der Mitgliedstaaten ist vom Recht auf Einsicht ausgenommen. Dieser Absatz steht der Offenlegung und Verwendung der für den Nachweis einer Zuwiderhandlung erforderlichen Informationen durch die Kommission in keiner Weise entgegen.

<a id="chapter-vii"></a>
## Kapitel VII – Befugnisübertragung und Ausschussverfahren

<a id="art-55"></a>
### Artikel 55 – Ausübung der Befugnisübertragung

- (1) Die Befugnis zum Erlass delegierter Rechtsakte wird der Kommission unter den in diesem Artikel festgelegten Bedingungen übertragen.

- (2) Die Befugnis zum Erlass delegierter Rechtsakte gemäß den Artikeln 12 und 17 wird der Kommission auf unbestimmte Zeit ab dem [OP: bitte Datum des Inkrafttretens einfügen] übertragen.

- (3) Die Befugnisübertragung gemäß Artikel 12 und Artikel 17 kann vom Europäischen Parlament oder vom Rat jederzeit widerrufen werden. Der Beschluss über den Widerruf beendet die Übertragung der in diesem Beschluss genannten Befugnis. Er wird am Tag nach seiner Veröffentlichung im Amtsblatt der Europäischen Union oder zu einem in dem Beschluss über den Widerruf angegebenen späteren Zeitpunkt wirksam. Die Gültigkeit delegierter Rechtsakte, die bereits in Kraft sind, wird von dem Beschluss über den Widerruf nicht berührt.

- (4) Vor dem Erlass eines delegierten Rechtsakts konsultiert die Kommission die von den einzelnen Mitgliedstaaten benannten Sachverständigen im Einklang mit den in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung enthaltenen Grundsätzen.

- (5) Sobald die Kommission einen delegierten Rechtsakt erlässt, übermittelt sie ihn gleichzeitig dem Europäischen Parlament und dem Rat.

- (6) Ein delegierter Rechtsakt, der gemäß Artikel 12 oder Artikel 17 erlassen wurde, tritt nur in Kraft, wenn weder das Europäische Parlament noch der Rat innerhalb einer Frist von zwei Monaten nach Übermittlung dieses Rechtsakts an das Europäische Parlament und den Rat Einwände erhoben haben oder wenn vor Ablauf dieser Frist das Europäische Parlament und der Rat beide der Kommission mitgeteilt haben, dass sie keine Einwände erheben werden. Auf Initiative des Europäischen Parlaments oder des Rates wird diese Frist um zwei Monate verlängert.

<a id="art-56"></a>
### Artikel 56 – Ausschussverfahren

- (1) Die Kommission wird von einem Ausschuss (im Folgenden „Halbleiterausschuss“) unterstützt. Dieser Ausschuss ist ein Ausschuss im Sinne der Verordnung (EU) Nr. 182/2011.

- (2) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 5 der Verordnung (EU) Nr. 182/2011.

- (3) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 8 der Verordnung (EU) Nr. 182/2011 in Verbindung mit deren Artikel 5.

<a id="chapter-viii"></a>
## Kapitel VIII – Schlussbestimmungen

<a id="art-57"></a>
### Artikel 57 – Bewertung und Überprüfung

- (1) Bis zum [OP: Datum einfügen = vier Jahre nach dem Inkrafttreten] und danach alle vier Jahre legt die Kommission dem Europäischen Parlament und dem Rat einen Bericht über die Bewertung und Überprüfung dieser Verordnung vor. Die Berichte werden veröffentlicht.

- (2) Für die Zwecke der Bewertung und Überprüfung dieser Verordnung stellen das Europäische Halbleitergremium, die Mitgliedstaaten und die zuständigen nationalen Behörden der Kommission auf deren Ersuchen Informationen zur Verfügung.

- (3) Bei der Durchführung der Bewertung und Überprüfung dieser Verordnung berücksichtigt die Kommission die Standpunkte und Feststellungen des Europäischen Halbleitergremiums, des Europäischen Parlaments, des Rates und anderer einschlägiger Einrichtungen oder Quellen.

<a id="art-58"></a>
### Artikel 58 – Aufhebung

- (1) Die Verordnung (EU) 2023/1781 wird aufgehoben.

- (2) Bezugnahmen auf die Verordnung (EU) 2023/1781 gelten als Bezugnahmen auf die vorliegende Verordnung und sind nach Maßgabe der Entsprechungstabelle in Anhang VII zu lesen.

<a id="art-59"></a>
### Artikel 59 – Übergangsbestimmungen

Die Verordnung (EU) 2023/1781 gilt weiterhin für integrierte Produktionsstätten und offene EU-Fertigungsbetriebe gemäß den Artikeln 13 und 14 der genannten Verordnung, denen ein solcher Status gemäß Artikel 15 Absatz 3 der genannten Verordnung zuerkannt wurde, für die Geltungsdauer dieses Status oder den Zeitraum gemäß Artikel 15 Absatz 8 Satz 2 der Verordnung.

<a id="art-60"></a>
### Artikel 60 – Inkrafttreten

Diese Verordnung tritt am Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

Diese Verordnung ist in allen ihren Teilen verbindlich und gilt unmittelbar in jedem Mitgliedstaat.

Geschehen zu Brüssel am

Im Namen des Europäischen Parlaments Im Namen des Rates

Die Präsidentin Der Präsident/Die Präsidentin

<a id="finanz-und-digitalbogen-zu-rechtsakten"></a>
## FINANZ- UND DIGITALBOGEN ZU RECHTSAKTEN

### 1. RAHMEN DES VORSCHLAGS/DER INITIATIVE

#### 1.1. Bezeichnung des Vorschlags/der Initiative

    Verordnung des Europäischen Parlaments und des Rates über einen Rahmen für Maßnahmen zur Stärkung des Halbleiterökosystems der Union und zur Aufhebung der Verordnung (EU) 2023/1781 (Chip-Verordnung 2.0)

#### 1.2. Politikbereich(e)

    Ein neuer Plan für nachhaltigen Wohlstand und nachhaltige Wettbewerbsfähigkeit in Europa

#### 1.3. Ziel(e)

##### 1.3.1. Allgemeine(s) Ziel(e)

    Wie in der Begründung dargelegt, werden mit der Chip-Verordnung 2.0 zwei allgemeine Ziele verfolgt:

    1. Steigerung der Wettbewerbsfähigkeit der europäischen Halbleiterwertschöpfungskette zur Verbesserung ihrer technologischen Souveränität und Resilienz durch die Beschleunigung der industriellen Einführung von Forschung und Innovation, die Gewährleistung der Versorgungssicherheit und die Verringerung strategischer Abhängigkeiten bei hochmodernen und ausgereiften Halbleitertechnologien.

    2. Verbesserung der Krisenvorsorge zur Gewährleistung der Versorgungssicherheit der EU durch die Stärkung der Resilienz der europäischen Halbleiterlieferkette und den Schutz der wirtschaftlichen Sicherheit der EU.

##### 1.3.2. Einzelziel(e)

    Einzelziel Nr. 1

    Steigerung der Kapazität, Versorgungssicherheit und Wettbewerbsfähigkeit der Halbleiterindustrie der EU entlang der gesamten Wertschöpfungskette, einschließlich modernster KI-Chips

    Einzelziel Nr. 2

    Entwicklung eines starken Anwendermarkts für alle wichtigen Industriezweige

    Einzelziel Nr. 3

    Ausbau der nachrichtendienstlichen Fähigkeiten für die Krisenvorsorge und Krisenreaktion

##### 1.3.3. Erwartete Ergebnisse und Auswirkungen

    Bitte geben Sie an, wie sich der Vorschlag/die Initiative auf die Begünstigten/Zielgruppen auswirken sollte.

Die Halbleiterindustrie der Union sollte Unterstützung für einen umfangreichen technischen Kapazitätsaufbau im Bereich der hochmodernen Halbleitertechnologien und Halbleitertechnologien der nächsten Generation erhalten, durch die die Fähigkeiten der EU auf den Gebieten des fortgeschrittenen Entwurfs, der Systemintegration und der Halbleiterproduktion gestärkt werden. Auch die Industrie sollte von strategischen Projekten in den Bereichen Entwurf und Fertigung profitieren. Halbleiterfertigungsstätten werden in den Genuss wirksamerer Genehmigungsverfahren kommen.

Die Halbleiteranwender in der Union sollten in allen Sektoren von einer erhöhten Sicherheit der ungestörten Versorgung mit Halbleitern und von Bemühungen zur Förderung engerer Beziehungen zur Halbleiterindustrie profitieren. Darüber hinaus sollte zusätzliche Halbleiterversorgungssicherheit für kritische Sektoren geschaffen werden.

Endnutzer halbleiterabhängiger Produkte sollen mehr Versorgungssicherheit bei attraktiveren Marktpreisen erhalten.

Die Wettbewerbsfähigkeit des europäischen Halbleiterökosystems wird sich verbessern.

##### 1.3.4. Leistungsindikatoren

    Bitte geben Sie an, anhand welcher Indikatoren die Fortschritte und Ergebnisse verfolgt werden sollen.

| Im Rahmen der Initiative „Chips für Europa 2.0“ kommt Leistungsindikatoren größte Bedeutung zu. Anhang III enthält erste Versionen messbarer Indikatoren für die Überwachung der Durchführung und für die Berichterstattung über die Fortschritte bei der Erreichung der allgemeinen Ziele der Initiative „Chips für Europa 2.0“: 1.Gesamte Zuflüsse ausländischer Direktinvestitionen (ADI) mit Halbleiterbezug in die EU. 2.Qualifizierte Arbeitskräfte im Halbleiter- und Photonikbereich, einschließlich der im Rahmen der Initiativen der nationalen Chip-Kompetenzzentren ausgebildeten oder umgeschulten Arbeitskräfte. 3.Öffentliche Unterstützung für Start-ups und Scale-ups. 4.Ausweitung der Finanzierung über privates Beteiligungskapital und Risikokapital. |
| --- |

#### 1.4. Der Vorschlag/Die Initiative betrifft

     eine neue Maßnahme

     eine neue Maßnahme im Anschluss an ein Pilotprojekt/eine vorbereitende Maßnahme^(74)

     die Verlängerung einer bestehenden Maßnahme

     die Zusammenführung mehrerer Maßnahmen oder die Neuausrichtung mindestens einer Maßnahme

#### 1.5. Begründung des Vorschlags/der Initiative

##### 1.5.1. Kurz- oder langfristig zu deckender Bedarf, einschließlich einer detaillierten Zeitleiste für die Durchführung der Initiative

| Die Verordnung soll sofort nach ihrer Annahme, also am Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union uneingeschränkt anwendbar werden. Die Verordnung baut auf den derzeit geltenden Bestimmungen der Verordnung (EU) 2023/1781 (Chip-Gesetz) auf. |
| --- |

##### 1.5.2. Mehrwert aufgrund des Tätigwerdens der EU (kann sich aus unterschiedlichen Faktoren ergeben, z. B. Vorteile durch Koordinierung, Rechtssicherheit, größere Wirksamkeit oder Komplementarität). Für die Zwecke dieses Abschnitts bezeichnet der Ausdruck „Mehrwert aufgrund des Tätigwerdens der EU“ den Wert, der sich aus dem Tätigwerden der EU ergibt und den Wert ergänzt, der andernfalls allein von den Mitgliedstaaten geschaffen worden wäre.

    Die Ziele der Stärkung der Halbleiterentwurfs- und -fertigungskapazitäten der EU und der Verbesserung der Krisenvorsorge können auf Unionsebene wirksamer erreicht werden, da das Ausmaß und der systemische Charakter der Herausforderungen die Kapazitäten einzelner Mitgliedstaaten übersteigen würden. Beträchtliche Größenvorteile ergeben sich durch die Koordinierung von Investitionen in große Fertigungsanlagen, gemeinsame FuE-Infrastrukturen und grenzüberschreitende Frühwarn- und Überwachungssysteme, was bedeutet, dass durch Maßnahmen auf EU-Ebene Ressourcen gebündelt werden, Doppelarbeit verringert wird und effizienter Ergebnissen erreicht werden können als durch ein fragmentiertes Vorgehen auf nationaler Ebene. Maßnahmen wie der Ausbau von Produktionskapazitäten, die Beschleunigung der Genehmigungsverfahren, die Vergabe vorrangiger Aufträge und die gemeinsame Beschaffung zielen darauf ab, eine abgestimmte Reaktion auf künftige Krisen zu gewährleisten.

    Ein gemeinsamer Rahmen bringt auch deshalb klare Vorteile mit sich, weil er unterschiedliche nationale Anreize, Krisenreaktionsprotokolle und die Berichterstattung durch gemeinsame Konzepte ersetzt, die Kohärenz gewährleisten, den Verwaltungsaufwand verringern und Subventionswettläufe oder uneinheitliche regulatorische Anforderungen vermeiden. Das Funktionieren des Binnenmarkts wird verbessert, da koordinierte EU-Maßnahmen Verzerrungen minimieren, einen fairen Wettbewerb beim Anwerben von Halbleiterprojekten gewährleisten, den reibungslosen Verkehr kritischer Inputs und Chips erleichtern und die Resilienz grenzüberschreitender Lieferketten stärken, die von einer nahtlosen Integration zwischen den Mitgliedstaaten abhängen.

##### 1.5.3. Aus früheren ähnlichen Maßnahmen gewonnene Erkenntnisse

    Aus der Bewertung des derzeitigen Chip-Gesetzes lassen sich mehrere Lehren ziehen^(75). Erstens werden für die Umwandlung von Innovationen in Industriekapazitäten politische Mechanismen benötigt, die ausdrücklich eine Brücke zwischen den Infrastrukturen der Pilotanlagen zu Folgeinvestitionen in die Fertigung schlagen. Mit dem Chip-Gesetz wurden zwar erfolgreich Forschungs- und Validierungseinrichtungen von Weltrang geschaffen, die Erfahrung zeigt jedoch, dass technologische Fähigkeiten allein nicht automatisch zu einer marktgerechten Fertigung führen. Künftigen Initiativen würde eine systematischere Einbettung von Übergangsmechanismen zugutekommen, die den Übergang der Pilotanlage zur industriellen Einführung systematischer erleichtern.

    Zweitens sollte die Nachfrageorientierung in den industriepolitischen Instrumenten verankert werden. In der Bewertung wird hervorgehoben, dass angebotsseitige Investitionen allein nicht unbedingt zu Größenvorteilen oder Wettbewerbsvorteilen führen, wenn keine verlässliche Marktakzeptanz besteht. Instrumente zur Förderung der Einführung sollten daher mit Maßnahmen zur Steigerung der Nachfrage einhergehen, wie z. B. einer koordinierten Auftragsvergabe oder mit Verbrauchsanreizen.

    Drittens muss der Zugang zu Finanzmitteln weiterhin im Mittelpunkt der Industriepolitik stehen. Die Bewertung zeigt, dass der Rahmen für Neuartiges zwar die Rechtssicherheit für größere Investitionen verbessert hat, die Interessenträger jedoch nach wie vor mit Verzögerungen infolge der Beihilfevorschriften, langwierigen Anmeldungen und Unsicherheiten auf Projektebene konfrontiert sind. Risikokapitallücken in späteren Phasen und Zwänge im Zusammenhang mit institutionellen Investitionen schränken die Expansionsfinanzierung ebenfalls ein. Diese Faktoren schwächen die Wettbewerbsfähigkeit Europas und bremsen das Wachstum von Unternehmen, die an sich weltweit wettbewerbsfähig sind.

    Schließlich hängt die Krisenvorsorge von der Verfügbarkeit hochwertiger Systeminformationen ab. Die Bewertung zeigt, dass eine wirksame Überwachung von einer stets aktuellen Informationserfassung in der gesamten Wertschöpfungskette abhängt, die sich nicht nur auf die Fertigung, sondern auch auf Materialien, Packaging, Entwurfswerkzeuge und nachgeschaltete Anwender erstreckt. In künftigen Rahmen könnte daher einer verbesserten Datenerhebung, gemeinsamen Dateninfrastrukturen und einer integrierten Berichterstattung Vorrang eingeräumt werden, um eine zeitnahe Risikoerkennung und koordinierte Reaktionen zu ermöglichen.

##### 1.5.4. Vereinbarkeit mit dem Mehrjährigen Finanzrahmen sowie mögliche Synergieeffekte mit anderen geeigneten Instrumenten

    Um ihre positiven Auswirkungen zu maximieren, wird die Initiative „Chips für Europa 2.0“ (Säule I) weiterhin auf der soliden Wissensbasis aufbauen und Synergien mit Maßnahmen verstärken, die derzeit von der Union und den Mitgliedstaaten durch Programme und Maßnahmen im Bereich Halbleiterforschung und -innovation und bei der Entwicklung eines Teils der Lieferkette unterstützt werden. Dies sind insbesondere das Rahmenprogramm Horizont Europa und das Programm Digitales Europa, mit denen das Ziel verfolgt wird, Europa als globalen Akteur in der Halbleitertechnik und deren Anwendung zu stärken und bis 2030 weltweit einen wachsenden Anteil der Fertigung zu erreichen. Ergänzend zu diesen Tätigkeiten wird es eine engere Zusammenarbeit der Initiative „Chips für Europa 2.0“ mit der Industrieallianz für Halbleiter geben.

##### 1.5.5. Bewertung der verschiedenen verfügbaren Finanzierungsoptionen, einschließlich der Möglichkeiten für eine Umschichtung

| Unbeschadet des Ausgangs der Verhandlungen über den nächsten MFR handelt es sich bei den ab 2028 vorgesehenen Mitteln lediglich um Richtwerte. |
| --- |

#### 1.6. Laufzeit der vorgeschlagenen Maßnahme/der Initiative und Dauer der finanziellen Auswirkungen

     befristete Laufzeit

    - – in Kraft ab dem Tag der Annahme der Verordnung des Europäischen Parlaments und des Rates zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Halbleiter-Ökosystems (Chip-Verordnung 2.0)

    - – Finanzielle Auswirkungen auf die Mittel für Verpflichtungen von 2028 bis 2034 und auf die Mittel für Zahlungen von 2028 bis 2038

     unbefristete Laufzeit

    - –  Anlaufphase von JJJJ bis JJJJ

    - –  anschließend reguläre Umsetzung

#### 1.7. Vorgeschlagene Haushaltsvollzugsart(en)

     Direkte Mittelverwaltung durch die Kommission

    - –  über ihre Dienststellen, einschließlich ihres Personals in den EU-Delegationen

    - –  über die Exekutivagenturen

     Geteilte Mittelverwaltung mit Mitgliedstaaten

     Indirekte Mittelverwaltung durch Übertragung von Haushaltsvollzugsaufgaben an:

    - –  Drittländer oder die von ihnen benannten Einrichtungen

    - –  internationale Einrichtungen und deren Agenturen (bitte angeben)

    - –  die Europäische Investitionsbank und den Europäischen Investitionsfonds

    - –  Einrichtungen im Sinne der Artikel 70 und 71 der Haushaltsordnung

    - –  öffentlich-rechtliche Körperschaften

    - –  privatrechtliche Einrichtungen, die im öffentlichen Auftrag tätig werden, sofern ihnen ausreichende finanzielle Garantien bereitgestellt werden

    - –  privatrechtliche Einrichtungen eines Mitgliedstaats, die mit der Einrichtung einer öffentlich-privaten Partnerschaft betraut werden und denen ausreichende finanzielle Garantien bereitgestellt werden

    - –  Einrichtungen oder Personen, die mit der Durchführung bestimmter Maßnahmen im Bereich der Gemeinsamen Außen- und Sicherheitspolitik im Rahmen des Titels V des Vertrags über die Europäische Union betraut und die in dem maßgeblichen Basisrechtsakt benannt sind

    - – in einem Mitgliedstaat ansässige Einrichtungen, die dem Privatrecht eines Mitgliedstaats oder dem Unionsrecht unterliegen und im Einklang mit sektorspezifischen Vorschriften für die Betrauung mit der Ausführung von Unionsmitteln oder mit der Erteilung von Haushaltsgarantien in Betracht kommen, insofern diese Einrichtungen von privatrechtlichen, im öffentlichen Auftrag tätig werdenden Einrichtungen kontrolliert und von den Kontrollstellen mit angemessenen finanziellen Garantien mit gesamtschuldnerischer Haftung oder gleichwertigen finanziellen Garantien ausgestattet werden, die bei jeder Maßnahme auf den Höchstbetrag der Unionsunterstützung begrenzt sein können.

Bemerkungen

Mit Ausnahme von a) Tätigkeiten und Haushaltsmitteln im Zusammenhang mit dem Chip-Fonds und b) Tätigkeiten und Haushaltsmitteln, die im Rahmen des Europäischen Innovationsrats vorgesehen sind, wird die Initiative „Chips für Europa 2.0“ weiterhin im Wege der indirekten Mittelverwaltung durchgeführt, indem das Gemeinsame Unternehmen für Chips und gegebenenfalls das gemeinsame Unternehmen oder eine andere ähnliche Einrichtung oder Initiative, die an dessen Stelle tritt und durch Unionsrecht im Rahmen eines nachfolgenden mehrjährigen Finanzrahmens eingerichtet wird, mit der Aufgabendurchführung betraut wird. Die Mitgliedstaaten und andere teilnehmende Staaten werden indirekte Maßnahmen kofinanzieren.

Andere Teile, wie die Maßnahmen im Rahmen der Säulen 2 und 3, unterliegen der direkten Mittelverwaltung. Sie betreffen Aufgaben, mit denen die Kommission zwecks Beaufsichtigung des GU für Chips betraut wird, sowie für die Prüfung und Bewilligung von Anträgen für Halbleitertechnologieanlagen, die Unterstützung des Europäischen Halbleitergremiums, die Unterstützung der Unternehmensplattform für die Halbleiterlieferkette und – gemeinsam mit den Mitgliedstaaten – die Überwachung der Halbleiterlieferketten sowie ggf. Entscheidungen über Maßnahmen.

### 2. VERWALTUNGSMAẞNAHMEN

#### 2.1. Überwachung und Berichterstattung

Diese Übersicht enthält Ausgaben für Kommissionspersonal. Es gelten die Standardvorschriften für diese Art von Ausgaben. Die Kommission wird die Leistungen, Outputs und Auswirkungen dieses Vorschlags alle vier Jahre nach seinem Inkrafttreten bewerten.

Zudem unterliegt das Gemeinsame Unternehmen für Chips als Einrichtung der Union strengen Überwachungsregeln. Die Überwachung erfolgt durch:

– seine eigene interne Auditstelle und den Auditdienst der Kommission;

– die Beaufsichtigung durch den Verwaltungsrat. Der Exekutivdirektor beaufsichtigt intern den Betrieb des Gemeinsamen Unternehmens;

– verschiedene quantitative und qualitative Leistungsindikatoren, die zur Überwachung der Umsetzung der Initiative und zur Messung seiner Wirkung festgelegt werden;

– Zwischen- und Abschlussbewertungen der Initiative durch externe Sachverständige unter Aufsicht der Kommission;

– das Arbeitsprogramm und den jährlichen Tätigkeitsbericht des Gemeinsamen Unternehmens.

#### 2.2. Verwaltungs- und Kontrollsystem(e)

##### 2.2.1. Begründung der Haushaltsvollzugsart(en), des Durchführungsmechanismus/der Durchführungsmechanismen für die Finanzierung, der Zahlungsmodalitäten und der Kontrollstrategie, wie vorgeschlagen

Mit der Verordnung wird ein überarbeiteter Politikrahmen eingeführt, um Investitionen in Verbesserungen in der fortgeschrittenen Halbleiterfertigung in der Union anzuziehen und die Nachfrage anzuregen, und es werden überarbeitete Vorschriften für ein koordiniertes Vorgehen bei der Überwachung und Krisenreaktion bei Halbleiterengpässen eingeführt. Wichtige Instrumente wie die Großen Herausforderungen, strategische Projekte, das Nachfrageforum, die Nachfragebeschleuniger und die Unternehmensplattform für die Halbleiterlieferkette sind ebenso neue Elemente wie die Anerkennung europäischer Halbleiterexzellenzregionen.

Diese Vorschriften erfordern ein Kohärenzverfahren für die grenzüberschreitende Anwendung der Verpflichtungen aus dieser Verordnung und die Koordinierung der Tätigkeiten der nationalen Behörden und der Kommission mithilfe des Europäischen Halbleitergremiums.

Damit die Kommission diese ihr übertragenen Aufgaben erfüllen kann, müssen die Dienststellen der Kommission angemessen mit Ressourcen ausgestattet werden.

Bei anderen Teilen ist die indirekte Mittelverwaltung gerechtfertigt, da das Gemeinsame Unternehmen für Chips eine öffentlich-private Partnerschaft ist, bei der ein Teil der Kofinanzierung durch Beiträge der Teilnehmerstaaten und durch Beiträge privater Mitglieder in Form von Sachleistungen erfolgt.

Die Entscheidung über den EU-Beitrag zum Gemeinsamen Unternehmen für Chips wird jedes Jahr auf der Grundlage des für das betreffende Jahr angenommenen EU-Haushaltsplans getroffen.

In einer Finanzpartnerschaftsrahmenvereinbarung zwischen der Europäischen Kommission und dem Gemeinsamen Unternehmen für Chips wird festgelegt, dass die Kommission für die jährlich durchzuführenden Aufgaben einen Beitrag leistet, sobald sie eine Beitragsvereinbarung mit dem Gemeinsamen Unternehmen für Chips geschlossen hat und dieses entsprechende Zahlungsanträge an die anderen Mitglieder als die Union gerichtet hat.

Die Kommission wird sicherstellen, dass die für das Gemeinsame Unternehmen für Chips geltenden Vorschriften den Anforderungen der Haushaltsordnung in vollem Umfang entsprechen. Das Gemeinsame Unternehmen hält den Grundsatz der Wirtschaftlichkeit der Haushaltsführung nach Artikel 71 der Verordnung (EU, Euratom) 2024/2509 ein. Das Gemeinsame Unternehmen für Chips hält ferner die für das Gemeinsame Unternehmen geltenden Bestimmungen der Musterfinanzregelung ein. Jede Abweichung von dieser Musterfinanzregelung, die für den besonderen Bedarf des Gemeinsamen Unternehmens erforderlich ist, erfordert die vorherige Zustimmung der Kommission.

Durch Überwachungsmodalitäten, unter anderem durch die Vertretung der Union im Verwaltungsrat und im Rat der öffentlichen Körperschaften des Gemeinsamen Unternehmens für Chips sowie durch Berichterstattungsmodalitäten wird sichergestellt, dass die Kommissionsdienststellen den Anforderungen an die Rechenschaftspflicht sowohl gegenüber dem Kollegium als auch gegenüber der Haushaltsbehörde nachkommen können.

Der Rahmen für die interne Kontrolle des Gemeinsamen Unternehmens für Chips stützt sich auf:

– die Anwendung der internen Kontrollstandards, die Garantien bieten, die denen der Kommission zumindest gleichwertig sind;

– Verfahren für die Auswahl der besten Projekte durch eine unabhängige Bewertung und für deren Umsetzung in Rechtsinstrumente;

– projektbegleitendes Projekt- und Vertragsmanagement;

– Ex-ante-Prüfungen sämtlicher Anträge, einschließlich Berücksichtigung der Prüfbescheinigungen und der Ex-ante-Bescheinigungen über die Kostenmethodik;

– Ex-post-Audits einer Stichprobe von Anträgen im Rahmen der Ex-post-Audits von Horizont Europa;

– die wissenschaftliche Bewertung der Projektergebnisse.

##### 2.2.2. Angaben zu den ermittelten Risiken und dem/den zu deren Eindämmung eingerichteten System(en) der internen Kontrolle

Diesem Vorschlag ist ein Folgenabschätzungsbericht beigefügt, der die Analysen enthält, die dem gewählten politischen Ansatz zugrunde liegen. Die Vorbereitung der Initiative umfasste auch eine öffentliche Konsultation sowie gezielte Konsultationen von Interessenträgern aus der Industrie, der Mitgliedstaaten und von Handelsverbänden, wodurch die Zusammenstellung einschlägiger Daten, Informationen und Rückmeldungen sichergestellt wurde. Dennoch können während der Durchführung unbeabsichtigte Folgen oder unvorhergesehene Auswirkungen auftreten. Diese werden im Rahmen der in der Verordnung festgelegten Überwachungsverfahren ermittelt, sodass die Kommission angemessen und rechtzeitig darauf reagieren kann.

Zusätzlich wurden verschiedene Maßnahmen ergriffen, um das inhärente Risiko von Interessenkonflikten innerhalb des Gemeinsamen Unternehmens zu mindern, insbesondere:

– gleiche Anzahl an Stimmen (ein Drittel) für die Kommission, die beteiligten Staaten (gemeinsam) und private Mitglieder (gemeinsam) im Verwaltungsrat für die standardmäßige Beschlussfassung; gleiche Stimmen (die Hälfte) für die Kommission und die beteiligten Staaten (gemeinsam) im Rat der öffentlichen Körperschaften;

– hochrangige Beschlüsse über Tätigkeiten/Haushaltsmittel im Rahmen der Initiative „Chips für Europa 2.0“ (Kapazitätsaufbau in künftigen Arbeitsprogrammen) werden ausschließlich mit den Mitgliedstaaten vom Rat der öffentlichen Körperschaften gefasst;

– der Teil des Arbeitsprogramms, der sich mit Maßnahmen zum Kapazitätsaufbau befasst, wird vom Rat der öffentlichen Körperschaften ausschließlich mit den Mitgliedstaaten angenommen;

– Auswahl des Exekutivdirektors durch den Verwaltungsrat auf Vorschlag der Kommission;

– Unabhängigkeit des Personals;

– Bewertungen durch unabhängige Sachverständige auf der Grundlage veröffentlichter Bewertungskriterien in Kombination mit Beschwerdemechanismen und vollständigen Interessenerklärungen;

– Verpflichtung des Verwaltungsrats, im Einklang mit der Finanzregelung des Gemeinsamen Unternehmens und dem Beamtenstatut Regeln zur Prävention, Vermeidung und Bewältigung von Interessenkonflikten im Gemeinsamen Unternehmen zu erlassen.

Die fortlaufende Wahrung ethischer und organisatorischer Werte wird zu den wichtigsten Aufgaben des Gemeinsamen Unternehmens gehören und von der Kommission überwacht werden.

Der Exekutivdirektor des Gemeinsamen Unternehmens für Chips ist als Anweisungsbefugter verpflichtet, ein kosteneffizientes System der internen Kontrolle und Verwaltung einzuführen. Das GU-Büro muss der Kommission über den angenommenen internen Kontrollrahmen Bericht erstatten.

Die Kommission wird das Risiko von Verstößen im Rahmen des von ihr zu entwickelnden Berichterstattungssystems sowie der Ergebnisse von Ex-post-Audits der Empfänger von EU-Mitteln des Gemeinsamen Unternehmens für Chips im Rahmen der Ex-post-Audits für die gesamten Programme Horizont Europa und Digitales Europa überwachen.

Die Haushaltsmittel müssen effizient und wirksam verwaltet werden, und Betrug und Mittelverschwendung müssen vermieden werden. Mit dem Kontrollsystem muss jedoch ein ausgewogenes Verhältnis zwischen der Einhaltung einer akzeptablen Fehlerquote und dem erforderlichen Kontrollaufwand hergestellt und die Attraktivität der Unionsprogramme unbeeinträchtigt bleiben.

##### 2.2.3. Schätzung und Begründung der Kosteneffizienz der Kontrollen (Verhältnis zwischen den Kontrollkosten und dem Wert der betreffenden verwalteten Mittel) sowie Bewertung des erwarteten Ausmaßes des Fehlerrisikos (bei Zahlung und beim Abschluss)

    Da die für das Gemeinsame Unternehmen für Chips geltenden Regeln für die Teilnahme am Programm Horizont Europa und am Programm Digitales Europa denen ähneln, die die Kommission in ihren Arbeitsprogrammen anwenden wird, und der Begünstigtenkreis ein ähnliches Risikoprofil wie bei Programmen mit direkter Mittelverwaltung aufweist, kann davon ausgegangen werden, dass die Fehlermarge in etwa derjenigen entspricht, die die Kommission für Horizont Europa und Digitales Europa vorgesehen hat. Das heißt, es dürfte hinreichend gewährleistet sein, dass das Fehlerrisiko im mehrjährigen Ausgabenzeitraum auf Jahresbasis innerhalb einer Spanne von 2-5 % liegen wird – mit dem letztendlichen Ziel, beim Abschluss der Mehrjahresprogramme eine Restfehlerquote von möglichst nahe bei 2 % zu erreichen, wenn die finanziellen Auswirkungen aller Audits und Korrektur- und Wiedereinziehungsmaßnahmen berücksichtigt sind.

#### 2.3. Prävention von Betrug und Unregelmäßigkeiten

Die Kommission wird sicherstellen, dass das Gemeinsame Unternehmen für Chips in allen Phasen des Managementprozesses die Verfahren zur Betrugsbekämpfung anwendet.

Die Kommission gewährleistet bei der Durchführung der nach dieser Verordnung finanzierten Maßnahmen den Schutz der finanziellen Interessen der Union durch geeignete Präventivmaßnahmen gegen Betrug, Korruption und sonstige rechtswidrige Handlungen, durch wirksame Kontrollen und – bei Feststellung von Unregelmäßigkeiten – durch Rückforderung zu Unrecht gezahlter Beträge sowie gegebenenfalls durch wirksame, verhältnismäßige und abschreckende Sanktionen.

Der Rechnungshof ist befugt, bei allen Begünstigten, bei Auftragnehmern und Unterauftragnehmern, die Unionsmittel aus dem Programm erhalten haben, Rechnungsprüfungen anhand von Belegkontrollen und Kontrollen vor Ort durchzuführen.

Das Europäische Amt für Betrugsbekämpfung (OLAF) kann gemäß der Verordnung (Euratom, EG) Nr. 2185/96 bei allen direkt oder indirekt durch Finanzierungen aus Unionsmitteln betroffenen Wirtschaftsteilnehmern Kontrollen und Überprüfungen vor Ort durchführen, um festzustellen, ob im Zusammenhang mit einer Finanzhilfevereinbarung, einem Finanzhilfebeschluss oder einem Vertrag über eine Finanzierung aus Unionsmitteln ein Betrugs- oder Korruptionsdelikt oder eine sonstige rechtswidrige Handlung zum Nachteil der finanziellen Interessen der Union vorliegt. Die gemeinsamen Unternehmen werden auch der Interinstitutionellen Vereinbarung vom 25. Mai 1999 zwischen dem Europäischen Parlament, dem Rat der Europäischen Union und der Kommission der Europäischen Gemeinschaften über die internen Untersuchungen des Europäischen Amtes für Betrugsbekämpfung (OLAF) beitreten müssen.

Die Europäische Staatsanwaltschaft (EUStA) kann gemäß den Bestimmungen und Verfahren der Verordnung (EU) 2017/1939 des Rates Ermittlungen in Bezug auf Straftaten zum Nachteil der finanziellen Interessen der Union durchführen.

### 3. GESCHÄTZTE FINANZIELLE AUSWIRKUNGEN DES VORSCHLAGS/DER INITIATIVE

#### 3.1. Betroffene Rubrik(en) des Mehrjährigen Finanzrahmens und Ausgabenlinie(n) im Haushaltsplan

  - · Bestehende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Anzahl | GM/NGM^(76) | von EFTA-Ländern^(77) | von Kandidatenländern und potenziellen Kandidaten^(78) | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

  - · Neu beantragte Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Anzahl | GM/NGM | von EFTA-Ländern | von Kandidatenländern und potenziellen Kandidaten | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

#### 3.2. Geschätzte finanzielle Auswirkungen des Vorschlags auf die Mittel

##### 3.2.1. Übersicht über die geschätzten Auswirkungen auf die operativen Mittel

  - –  Für den Vorschlag/die Initiative werden keine operativen Mittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden operativen Mittel benötigt:

##### 3.2.1.1. Mittel aus dem verabschiedeten Haushaltsplan

in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Anzahl | 2 |
| --- | --- | --- |

| GD CNECT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Danach | MFR 2028-2034 INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 |  |  |  |
|  | Operative Mittel |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie [ECF] | Verpflichtungen | (1a) | 30,000 |  | 20,000 |  | 10,000 |  | 10,000 |  | 70,000 |
|  | Zahlungen | (2a) | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
|  | Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel^(79) |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  |  |  |  |  | 0 |
| Mittel INSGESAMT | Verpflichtungen | =1a+1b+3 | 30,000 |  | 20,000 |  | 10,000 |  | 10,000 |  | 70,000 |
| für die GD CNECT | Zahlungen | =2a+2b+3 | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Danach | MFR 2028-2034 INSGESAMT |  |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 30,000 |  | 20,000 |  | 10,000 |  | 10,000 |  | 70,000 |
|  | Zahlungen | (5) | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) |  |  |  |  |  |  |  |  | 0 |  |
| Mittel INSGESAMT unter der RUBRIK 2 | Verpflichtungen | =4+6 | 30,000 |  | 20,000 |  | 10,000 |  | 10,000 |  | 70,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | =5+6 | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Danach | MFR 2028-2034 INSGESAMT |  |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 30,000 | 0,000 | 20,000 | 0,000 | 10,000 | 0,000 | 10,000 |  | 70,000 |
|  | Zahlungen | (5) | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) |  |  |  |  |  |  |  |  |  |  |
| Mittel INSGESAMT unter der RUBRIK 2 | Verpflichtungen | =4+6 | 30,000 | 0,000 | 20,000 | 0,000 | 10,000 | 0,000 | 10,000 |  | 70,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | =5+6 | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
|  |  |  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Danach | MFR 2028-2034 INSGESAMT |
|  |  |  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 |  |
| Operative Mittel INSGESAMT (alle operativen Rubriken) | Verpflichtungen | (4) | 30,000 | 0,000 | 20,000 | 0,000 | 10,000 | 0,000 | 10,000 | 0,000 | 70,000 |
|  | Zahlungen | (5) | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT (alle operativen Rubriken) | (6) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 3 | Verpflichtungen | =4+6 | 30,000 | 0,000 | 20,000 | 0,000 | 10,000 | 0,000 | 10,000 |  | 70,000 |
| des Mehrjährigen Finanzrahmens | Zahlungen | =5+6 | 18,000 | 6,000 | 15,000 | 7,000 | 8,000 | 4,000 | 7,000 | 5,000 | 70,000 |
| (Referenzbetrag) |  |  |  |  |  |  |  |  |  |  |  |

| Rubrik des Mehrjährigen Finanzrahmens | 4 | „Verwaltungsausgaben“^(80) |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GD: CNECT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
|  Personalausgaben | 1,972 | 1,972 | 1,972 | 1,972 | 1,972 | 1,972 | 1,972 | 13,804 |  |
|  Sonstige Verwaltungsausgaben |  |  |  |  |  |  |  |  |  |
| GD CNECT INSGESAMT |  | 1,972 | 1,972 | 1,972 | 1,972 | 1,972 | 1,972 | 1,972 | 13,804 |
| GD: COMP | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
|  Personalausgaben | 0,881 | 0,881 | 0,881 | 0,881 | 0,881 | 0,881 | 0,881 | 6,167 |  |
|  Sonstige Verwaltungsausgaben |  |  |  |  |  |  |  |  |  |
| GD COMP INSGESAMT | Mittel | 0,881 | 0,881 | 0,881 | 0,881 | 0,881 | 0,881 | 0,881 | 6,167 |
| Mittel INSGESAMT unter der RUBRIK 4 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 19,971 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Danach | MFR 2028-2034 INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 4 | Verpflichtungen | 32,853 | 2,853 | 22,853 | 2,853 | 12,853 | 2,853 | 12,853 | 0,000 | 89,971 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 20,853 | 8,853 | 17,853 | 9,853 | 10,853 | 6,853 | 9,853 | 5,000 | 89,971 |

Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus dienen lediglich der Veranschaulichung und greifen dem nächsten Mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034 ab und werden danach durch das jährliche Haushaltsverfahren bestimmt. Alle Mittel- und Personalzuweisungen ab 2028 sind vorläufig.

##### 3.2.2. Geschätzter Output, der mit operativen Mitteln finanziert wird (nicht auszufüllen im Fall dezentraler Agenturen)

Mittel für Verpflichtungen, in Mio. EUR (3 Dezimalstellen)

| Ziele und Outputs angeben  |  |  | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Bei länger andauernden Auswirkungen bitte weitere Spalten einfügen (siehe Abschnitt 1.6) | INSGESAMT |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art^(81) | Durchschnittskosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Gesamtzahl | Gesamtkosten |
| EINZELZIEL Nr. 1^(82)… |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EINZELZIEL Nr. 2 … |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| INSGESAMT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

##### 3.2.3. Übersicht über die geschätzten Auswirkungen auf die Verwaltungsmittel

  - –  Für den Vorschlag/die Initiative werden keine Verwaltungsmittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden Verwaltungsmittel benötigt:

#####  3.2.3.1. Mittel aus dem verabschiedeten Haushaltsplan

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| RUBRIK 4 |  |  |  |  |  |  |  |  |
| Personalausgaben | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 19,971 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 4 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 19,971 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 4 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| INSGESAMT | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 2,853 | 19,971 |

Zur Unterstützung der Überwachungs- und Krisenmanagementarbeiten kann die GD CNECT vorbehaltlich der Verfügbarkeit von Ressourcen und Sachkenntnis eine Verwaltungsvereinbarung mit der JRC über etwa 2 VZÄ (VZÄ) schließen. Dieses Finanz- und Digitalbogen enthält keine Mittel für eine solche mögliche Verwaltungsvereinbarung.

Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus dienen lediglich der Veranschaulichung und greifen dem nächsten Mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034 ab und werden danach durch das jährliche Haushaltsverfahren bestimmt. Alle Mittel- und Personalzuweisungen ab 2028 sind vorläufig.

##### 3.2.4. Geschätzter Personalbedarf

  - –  Für den Vorschlag/die Initiative wird kein Personal benötigt.

  - –  Für den Vorschlag/die Initiative wird das folgende Personal benötigt:

##### 3.2.4.1. Finanziert aus dem verabschiedeten Haushalt

Schätzung in Vollzeitäquivalenten (VZÄ)^(83)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
|  Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 12 | 12 | 12 | 12 | 12 | 12 | 12 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| (indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| (direkte Forschung) | 0 |  |  |  |  |  |  |  |
| Sonstige Haushaltslinien (bitte angeben) |  |  |  |  |  |  |  |  |
| • Externes Personal (in VZÄ) |  |  |  |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 5 | 5 | 5 | 5 | 5 | 5 | 5 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung | ·in den zentralen Dienststellen | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| [XX.01.YY.YY] | ·in den EU-Delegationen | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 17 | 17 | 17 | 17 | 17 | 17 | 17 |  |

    Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus dienen lediglich der Veranschaulichung und greifen dem nächsten Mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034 ab und werden danach durch das jährliche Haushaltsverfahren bestimmt. Alle Mittel- und Personalzuweisungen ab 2028 sind vorläufig.

    Für die Durchführung des Vorschlags benötigtes Personal (in VZÄ):

|  | Personal aus den Dienststellen der Kommission | Zusatzpersonal (ausnahmsweise)* |  |  |
| --- | --- | --- | --- | --- |
|  |  | Zu finanzieren aus Rubrik 4 oder Forschung | Zu finanzieren aus einer Haushaltslinie für administrative Unterstützung | Zu finanzieren aus Gebühren |
| Planstellen | 5 | 7 | Nicht zutreffend |  |
| Externes Personal (VB, ANS, LAK) | 2 | 3 |  |  |

    Beschreibung der Aufgaben, die ausgeführt werden sollen durch:

| Beamte und Zeitbedienstete | Einige der Aufgaben können durch Umschichtung von Personal erfüllt werden, das derzeit mit ähnlichen Aufgaben befasst ist, z. B. im Zusammenhang mit der Programmüberwachung, der Pflege von Kontakten mit Interessenträgern und der Berichterstattung über Tätigkeiten der Forschung und Entwicklung und des Kapazitätsaufbaus im Rahmen der Säule I. Zusätzliche Aufgaben im Rahmen des Vorschlags sollten von zusätzlichem Personal erfüllt werden, z. B. Festlegung und Überwachung strategischer Projekte, einschließlich der Überwachung von Etappenzielen und zu erbringenden Leistungen; Konformitätsprüfungen (staatliche Beihilfen, Vergabe öffentlicher Aufträge); grenzübergreifende Koordinierung mit den Mitgliedstaaten; Festlegung der Großen Herausforderungen und Überwachung ihrer Umsetzung; Koordinierung der administrativen (nichtfiskalischen) Aufsicht; Bewertung regionaler Investitionspläne; Bewertung der Eigentumsverhältnisse und Kontrolle inländischer Unternehmen; Konsultation des Europäischen Halbleitergremiums zu strategischen Projekten, Empfehlungen für Chips inländischer Unternehmen bei der Vergabe öffentlicher Aufträge, Konsultationen mit der Allianz im Hinblick auf die Festlegung einer gemeinsamen Strategie für Halbleitertechnologien, Beratung in Bezug auf risikoanfällige Sektoren; Aufbau strategischer Partnerschaften mit Drittländern; Herausgabe von Leitlinien für die Vergabe öffentlicher Aufträge durch Mitgliedstaaten und öffentliche Auftraggeber; Formulierung methodischer Empfehlungen für die Durchführung von Risikobewertungen für die Versorgungssicherheit; Durchführung von Krisenvorsorgeübungen; Einrichtung und Förderung von Nachfrageforen; Unterstützung von Mitgestaltungstätigkeiten zwischen Halbleiterherstellern und nachgeschalteten industriellen Anwendern; Herausgabe technischer und rechtlicher Leitlinien für die Beschaffung von Systemen, die innovative Halbleiterentwürfe und -lösungen beinhalten; Gewährleistung der Kohärenz zwischen der Initiative 2.0 und nationalen/regionalen Strategien; Überwachung der Organisation und Berichterstattung an den Rat/das Parlament. Darüber hinaus beinhaltet der Vorschlag zusätzliche Aufgaben im Zusammenhang mit der Unternehmensplattform für die Halbleiterlieferkette, z. B. die Überwachung der Halbleiterlieferketten, Analyse- und Krisenvorsorgefunktionen, die Erstellung und Bearbeitung von Auskunftsersuchen (RFIs) und die Überprüfung und Aggregation von Daten in der Vorkrisenphase sowie die sektorenübergreifende Koordinierung mit Interessenträgern aus der Industrie. Ein erheblicher Teil der oben genannten zusätzlichen Aufgaben kann durch eine Umschichtung des vorhandenen Personals erfüllt werden. |
| --- | --- |
| Externes Personal | Ebenda |

##### 3.2.5. Übersicht über die geschätzten Auswirkungen auf die Investitionen im Zusammenhang mit digitalen Technologien

    Obligatorisch: In die Tabelle unten ist die bestmögliche Einschätzung der für den Vorschlag/die Initiative erforderlichen Investitionen in digitale Technologien einzutragen.

    Wenn dies für die Durchführung des Vorschlags/der Initiative erforderlich ist, sollten die Mittel unter Rubrik 4 ausnahmsweise in der dafür vorgesehenen Haushaltslinie ausgewiesen werden.

    Die unter die Rubriken 1 bis 3 fallenden Mittel sollten als „IT-Ausgaben zur Politikunterstützung für operationelle Programme“ aufgeführt werden. Diese Ausgaben beziehen sich auf die operativen Mittel, die für die Wiederverwendung/den Erwerb/die Entwicklung von IT-Plattformen/Instrumenten verwendet werden, welche in direktem Zusammenhang mit der Durchführung der Initiative und den damit verbundenen Investitionen stehen (z. B. Lizenzen, Studien, Datenspeicherung usw.). Die in dieser Tabelle dargelegten Informationen sollten mit den Angaben in Abschnitt 4 „Digitale Aspekte“ vereinbar sein.

| Mittel INSGESAMT für Digitales und IT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| RUBRIK 4 |  |  |  |  |  |  |  |  |
| IT-Ausgaben (intern) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Zwischensumme RUBRIK 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |
| IT-Ausgaben zur Politikunterstützung für operationelle Programme | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Zwischensumme außerhalb der RUBRIK 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| INSGESAMT | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

##### 3.2.6. Vereinbarkeit mit dem derzeitigen Mehrjährigen Finanzrahmen

    Der Vorschlag/Die Initiative

  - –  kann durch Umschichtungen innerhalb der entsprechenden Rubrik des Mehrjährigen Finanzrahmens (MFR) in voller Höhe finanziert werden.

  - –  erfordert die Inanspruchnahme des verbleibenden Spielraums unter der einschlägigen Rubrik des MFR und/oder den Einsatz der besonderen Instrumente im Sinne der MFR-Verordnung.

  - –  erfordert eine Änderung des MFR.

    Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus dienen lediglich der Veranschaulichung und greifen dem nächsten Mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034 ab und werden danach durch das jährliche Haushaltsverfahren bestimmt. Alle Mittel- und Personalzuweisungen ab 2028 sind vorläufig.

##### 3.2.7. Beiträge Dritter

    Der Vorschlag/Die Initiative

  - –  sieht keine Kofinanzierung durch Dritte vor.

  - –  sieht folgende Kofinanzierung durch Dritte vor:

Mittel in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Insgesamt |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| Kofinanzierende Einrichtung |  |  |  |  |  |  |  |  |
| Kofinanzierung INSGESAMT |  |  |  |  |  |  |  |  |

#### 3.3. Geschätzte Auswirkungen auf die Einnahmen

  - –  Der Vorschlag/Die Initiative wirkt sich nicht auf die Einnahmen aus.

  - –  Der Vorschlag/Die Initiative wirkt sich auf die Einnahmen aus, und zwar:

- –  auf die Eigenmittel.

- –  auf die übrigen Einnahmen.

- –  Bitte geben Sie an, ob die Einnahmen bestimmten Ausgabenlinien zugeordnet sind.

in Mio. EUR (3 Dezimalstellen)

| Einnahmenlinie: | Für das laufende Haushaltsjahr zur Verfügung stehende Mittel | Auswirkungen des Vorschlags/der Initiative^(84) |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Jahr 2032 | Jahr 2033 | Jahr 2034 |
| Artikel … |  |  |  |  |  |  |  |  |

    Bitte geben Sie für die sonstigen zweckgebundenen Einnahmen die betreffende(n) Ausgabenlinie(n) im Haushaltsplan an.

    Sonstige Anmerkungen (bei der Ermittlung der Auswirkungen auf die Einnahmen verwendete Methode/Formel oder weitere Informationen).

### 4. Digitale Aspekte

In diesem Abschnitt wird auf transeuropäische digitale öffentliche Dienste und ihre Anforderungen an die grenzüberschreitende Interoperabilität eingegangen.

#### 4.1. Anforderungen von digitaler Relevanz

    Allgemeine Beschreibung der Anforderungen von digitaler Relevanz und der damit verbundenen Kategorien (Daten, Digitalisierung und Automatisierung von Prozessen, digitale Lösungen und/oder digitale öffentliche Dienste)

| Anforderung | Beschreibung der Anforderung | Von der Anforderung betroffene(r) oder betreffende(r) Akteur(e) | Allgemeines Verfahren | Kategorien |
| --- | --- | --- | --- | --- |
| Artikel 15 | Beantragung des Status einer europäischen Halbleitertechnologieinitiative | Europäische Kommission | Beantragung | Daten |
| Artikel 22 | Die Mitgliedstaaten schaffen ein einheitliches Genehmigungsverfahren mit einer einzigen Beantragung, die alle Genehmigungen umfasst, die für europäische Halbleitertechnologieinitiativen und strategische Projekte erforderlich sind. | Mitgliedstaaten Zuständige nationale Behörden | Genehmigungserteilung | Daten Digitale Lösung Prozessdigitalisierung und -automatisierung |
| Artikel 24 | Die Mitgliedstaaten richten auf nationaler Ebene ein zentrales Zugangsportal für die Einreichung des einheitlichen Genehmigungsantrags für europäische Halbleitertechnologieanlagen und strategische Projekte ein. | Mitgliedstaaten Zuständige nationale Behörden | Genehmigungserteilung | Prozessdigitalisierung und -automatisierung |
| Artikel 33 | Strategische Kartierung des Halbleitersektors der Union | Europäische Kommission | Überwachung | Daten |
| Artikel 34 | Einrichtung der Unternehmensplattform für die Halbleiterlieferkette | Private Betreiber | Gemeinsame Datennutzung | Digitale Lösung Daten |
| Artikel 35 | Die Kommission führt in Abstimmung mit dem Europäischen Halbleitergremium eine regelmäßige Überwachung der Halbleiterwertschöpfungskette durch, um Faktoren zu ermitteln, die die Versorgung mit Halbleitern oder den Handel mit Halbleitern stören, beeinträchtigen oder nachteilig beeinflussen können. | Europäische Kommission | Überwachung | Daten |
| Artikel 38 | Präventive Informationsbeschaffung | Europäische Kommission | Berichterstattung | Daten |
| Artikel 41 | Informationsbeschaffung in der Krisenstufe | Europäische Kommission | Berichterstattung | Daten |

#### 4.2. Daten

    Allgemeine Beschreibung der erfassten Daten

| Art der Daten | Anforderung(en) | Standard bzw. Norm und/oder Spezifikation (falls zutreffend) |
| --- | --- | --- |
| Daten im Zusammenhang mit der Beantragung des Status einer europäischen Halbleitertechnologieinitiative | Artikel 15 | Nicht zutreffend |
| Genehmigungsanträge | Artikel 22 | Nicht zutreffend |
| Für eine strategische Kartierung des Halbleitersektors der Union benötigte Daten | Artikel 33 | Nicht zutreffend |
| Daten im Zusammenhang mit der Einrichtung der Unternehmensplattform für die Halbleiterlieferkette | Artikel 34 | Nicht zutreffend |
| Für die Überwachung der Halbleiterwertschöpfungskette benötigte Daten | Artikel 35 | Nicht zutreffend |
| Präventive Informationsbeschaffung | Artikel 38 | Nicht zutreffend |
| Informationsbeschaffung in der Krisenstufe | Artikel 41 | Nicht zutreffend |

    Datenströme

    Allgemeine Beschreibung der Datenströme

| Art der Daten | Anforderung(en) | Akteure, die die Daten bereitstellen | Akteure, die die Daten empfangen | Auslöser für den Datenaustausch | Häufigkeit (falls zutreffend) |
| --- | --- | --- | --- | --- | --- |
| Daten im Zusammenhang mit der Beantragung des Status einer europäischen Halbleitertechnologieinitiative | Artikel 15 | Industrie | Europäische Kommission | Nicht zutreffend | Nicht zutreffend |
| Genehmigungsanträge | Artikel 22 | Industrie | Mitgliedstaaten | Nicht zutreffend | Nicht zutreffend |
| Für eine strategische Kartierung des Halbleitersektors der Union benötigte Daten | Artikel 33 | Industrie | Europäische Kommission | Nicht zutreffend | Nicht zutreffend |
| Daten im Zusammenhang mit der Einrichtung der Unternehmensplattform für die Halbleiterlieferkette | Artikel 34 | Industrie | Europäische Kommission | Nicht zutreffend | Nicht zutreffend |
| Für die Überwachung der Halbleiterwertschöpfungskette benötigte Daten | Artikel 35 | Industrie | Europäische Kommission | Nicht zutreffend | Nicht zutreffend |
| Präventive Informationsbeschaffung | Artikel 38 | Industrie | Europäische Kommission | Vorkrisenphase | Nicht zutreffend |
| Informationsbeschaffung in der Krisenstufe | Artikel 41 | Industrie | Europäische Kommission | Krisenstufe | Nicht zutreffend |

    Vereinbarkeit mit der europäischen Datenstrategie

    Erläuterung, inwiefern die Anforderung(en) mit der Europäischen Datenstrategie vereinbar ist/sind.

| Diese Gesetzgebungsinitiative steht im Einklang mit der Nutzung privater Daten durch staatliche Behörden (Business-to-Government – B2G), um faktengestützte politische Entscheidungen zu gewährleisten. Das digitale Genehmigungssystem wird so konzipiert, dass die Interoperabilität und der automatisierte Datenaustausch zwischen den zuständigen Behörden, die Weiterverwendung von Daten und Dokumenten, die sich bereits im Besitz von Behörden befinden, ein hohes Maß an Cybersicherheit und Informationsintegrität sowie Transparenz und Rechenschaftspflicht im Genehmigungsverfahren gewährleistet sind. |
| --- |

    Vereinbarkeit mit dem Grundsatz der einmaligen Erfassung

| Artikel 22 sieht die Schaffung eines einheitlichen Genehmigungsverfahrens mit einer einzigen Beantragung, die alle Genehmigungen umfasst, die für europäische Halbleitertechnologieinitiativen und strategische Projekte erforderlich sind. |
| --- |

#### 4.3. Digitale Lösungen

    Bitte geben Sie für jede digitale Lösung die sie betreffende(n) Anforderung(en) von digitaler Relevanz, eine Beschreibung der vorgeschriebenen Funktionalität der digitalen Lösung, die Stelle, die dafür zuständig sein wird, und andere relevante Aspekte wie Wiederverwendbarkeit und Zugänglichkeit an. Erläutern Sie bitte abschließend, ob bei der digitalen Lösung der Einsatz von KI-Technologien vorgesehen ist.

| Digitale Lösung | Anforderung(en) | Wichtigste vorgeschriebene Funktionen | Zuständige Stelle | Wie wird die barrierefreie Zugänglichkeit gewährleistet? | Wie wird die Wiederverwendbarkeit berücksichtigt? | Einsatz von KI-Technologien |
| --- | --- | --- | --- | --- | --- | --- |
| Digitales Genehmigungssystem | Artikel 22 und 24 | Die Genehmigungsverfahren werden vollständig digital abgewickelt. Das System bietet eine einzige Benutzerschnittstelle, die die Interaktion mit den einschlägigen öffentlichen Diensten ermöglicht. Das digitale Genehmigungssystem ermöglicht die papierlose Einreichung, Nachverfolgung und Entscheidung von Genehmigungsanträgen. | Mitgliedstaaten Zuständige nationale Behörden | Das digitale Genehmigungssystem sollte so konzipiert werden, dass die Benutzerfreundlichkeit und barrierefreie Zugänglichkeit für alle Antragsteller, einschließlich Menschen mit Behinderungen, gewährleistet ist. | Das digitale Genehmigungssystem sollte so konzipiert werden, dass die Weiterverwendung von Daten und Dokumenten, die sich bereits im Besitz von Behörden befinden, gewährleistet ist. | // |
| Unternehmensplattform für die Halbleiterlieferkette | Artikel 34 | Die Plattform sollte Daten von beteiligten Unternehmen erheben, um die Transparenz und Resilienz der Halbleiterlieferkette zu erhöhen. | Private Betreiber | Die Plattform sollte so konzipiert werden, dass die Benutzerfreundlichkeit und barrierefreie Zugänglichkeit für alle Antragsteller, einschließlich Menschen mit Behinderungen, gewährleistet ist. |  | // |

    Digitales Genehmigungssystem

| Digitalpolitik und/oder sektorspezifische Politik (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| EU-Rahmen für Cybersicherheit | Das nationale digitale Genehmigungssystem sollte so konzipiert werden, dass ein hohes Maß an Datenschutz, Cybersicherheit und Informationsintegrität gewährleistet ist. |
| Europäische Unternehmensbrieftaschen | Der zentrale Zugangspunkt des nationalen digitalen Genehmigungssystems verwendet die europäischen Unternehmensbrieftaschen. |

    Unternehmensplattform für die Halbleiterlieferkette

| Digitalpolitik und/oder sektorspezifische Politik (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| EU-Rahmen für Cybersicherheit | Die Unternehmensplattform für die Halbleiterlieferkette sollte so konzipiert werden, dass ein hohes Maß an Datenschutz, Cybersicherheit und Informationsintegrität gewährleistet ist. |

#### 4.4. Interoperabilitätsbewertung

Nicht zutreffend

#### 4.5. Unterstützungsmaßnahmen für die digitale Umsetzung

Nicht zutreffend

<a id="notes"></a>
## Fußnoten

^(1) WSTS Semiconductor Market Forecast Spring 2025, https://www.wsts.org/76/103/WSTS-Semiconductor-Market-Forecast-Spring-2025 .

^(2) Global Semiconductor Sales Increase Substantially in February, https://www.semiconductors.org/global-semiconductor-sales-increase-substantially-in-february/ .

^(3) The next era of semiconductor value creation, McKinsey, https://www.mckinsey.com/industries/semiconductors/our-insights/the-next-era-of-semiconductor-value-creation .

^(4) Die Zukunft der europäischen Wettbewerbsfähigkeit, Teil B, Kapitel 3 – Mario Draghi, https://commission.europa.eu/topics/competitiveness/draghi-report_de .

^(5) IDC, Semiconductors market data by feature size, sector and region, CNECT/2022/MVP/0084 – zweiter Zwischenbericht. Die Wertschöpfungskette umfasst geistiges Eigentum, elektronische Entwurfsautomatisierung (EDA), Sachanlagen, Trägermaterialien, Werkstoffe, Unternehmen ohne eigene Fertigung, integrierte Gerätehersteller (IDMs), Fertigungsbetriebe und Montage-, Packaging- und Prüfungsunternehmen (OSAT). Es werden nur die Umsätze von Unternehmen mit Hauptsitz in der EU berücksichtigt.

^(6) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Aktionsplan für den KI-Kontinent, COM(2025) 165 final vom 9.4.2025.

^(7) Prioritäten der EU-Kommission für die Jahre 2024-2029 .

^(8) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Der Deal für eine saubere Industrie: Ein gemeinsamer Fahrplan für Wettbewerbsfähigkeit und Dekarbonisierung, COM(2025) 85 final vom 26.2.2025.

^(9) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Ein Kompass für eine wettbewerbsfähige EU, COM(2025) 30 final vom 29.1.2025.

^(10) Gemeinsame Mitteilung an das Europäische Parlament und den Rat – Stärkung der wirtschaftlichen Sicherheit der EU, JOIN(2025) 977 final vom 3.12.2025.

^(11) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Digitaler Kompass 2030: der europäische Weg in die digitale Dekade, COM(2021) 118 vom 9.3.2021.

^(12) Beschluss (EU) 2022/2481 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über die Aufstellung des Politikprogramms 2030 für die digitale Dekade (ABl. L 323 vom 19.12.2022, S. 4).

^(13) Umfrage zur Zukunft des Politikprogramms für die digitale Dekade eröffnet, https://digital-strategy.ec.europa.eu/de/consultations/survey-opens-future-digital-decade-policy-programme .

^(14) Semicon Coalition calls for reinforced Chips Act, https://digital-strategy.ec.europa.eu/en/news/semicon-coalition-calls-reinforced-chips-act .

^(15) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Schaffung eines Rahmens von Maßnahmen zur Beschleunigung der Verstärkung der industriellen Kapazitäten und der Dekarbonisierung in strategischen Sektoren sowie zur Änderung der Verordnungen (EU) 2018/1724, (EU) 2024/1735 und (EU) 2024/3110 („Verordnung zur industriellen Beschleunigung“), COM(2026) 100 vom 4.3.2026.

^(16) Verordnung (EU) 2024/1252 des Europäischen Parlaments und des Rates vom 11. April 2024 zur Schaffung eines Rahmens zur Gewährleistung einer sicheren und nachhaltigen Versorgung mit kritischen Rohstoffen und zur Änderung der Verordnungen (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1724 und (EU) 2019/1020 („Verordnung über kritische Rohstoffe“).

^(17) Gemeinsame Mitteilung an das Europäische Parlament, den Europäischen Rat und den Rat über eine „Europäische Strategie für wirtschaftliche Sicherheit“, JOIN(2023) 20 final.

^(18) Exporting dual-use items – Trade and Economic Security .

^(19) Verordnung (EU) 2022/2560 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über den Binnenmarkt verzerrende drittstaatliche Subventionen.

^(20) Plattform für strategische Technologien für Europa, https://strategic-technologies.europa.eu/index_de .

^(21) Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates vom 23. Oktober 2024 über horizontale Cybersicherheitsanforderungen für Produkte mit digitalen Elementen und zur Änderung der Verordnungen (EU) Nr. 168/2013 und (EU) 2019/1020 und der Richtlinie (EU) 2020/1828 („Cyberresilienz-Verordnung“).

^(22) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Aktionsplan für die europäische Automobilindustrie, COM(2025) 95, 5.3.2025.

^(23) Der IPCEI-Kandidat AST wird derzeit so konzipiert, dass er auf bestehenden EU-Initiativen, insbesondere Pilotanlagen und der europäischen Entwurfsplattform, aufbaut und Kontinuität und Beschleunigung gewährleistet anstatt Doppelarbeit zu verursachen. Aufgrund von Megatrends wie KI, Automatisierung, Sicherheit und Nachhaltigkeit könnte der IPCEI-Kandidat AST letztlich eine gemeinsame europäische Antwort auf umwälzende technologische Veränderungen bieten. Der Schwerpunkt liegt auf Schlüsseltechnologiebereichen wie KI-Chips und -Beschleunigern, photonisch integrierten Schaltungen, heterogener Integration und fortgeschrittenem Packaging, Sensoren, Leistungselektronik, energieeffizienten Lösungen und sicherer Kommunikation, wobei die gesamte Halbleiterwertschöpfungskette abgedeckt wird, einschließlich Schlüsseltechnologien wie EDA, Ausrüstung, Prüftechnik, Werkstoffe und Wafer.

^(24) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Einrichtung des Europäischen Fonds für Wettbewerbsfähigkeit (ECF), einschließlich des spezifischen Programms für Forschungs- und Innovationstätigkeiten im Verteidigungsbereich, zur Aufhebung der Verordnungen (EU) 2021/522, (EU) 2021/694, (EU) 2021/697 und (EU) 2021/783 sowie zur Änderung der Verordnungen (EU) 2021/696, (EU) 2023/588 und (EU) [EDIP], COM(2025) 555, 16.7.2025.

^(25) Kommission bittet um Beiträge zur Gestaltung der künftigen Quantenverordnung, https://digital-strategy.ec.europa.eu/de/news/commission-invites-contributions-shape-future-eu-quantum-act .

^(26) Link zum SWD-Anhang des Evaluierungsberichts.

^(27) ABl. C , , S. .

^(28) ABl. C , , S. .

^(29) Verordnung (EU) 2023/1781 des Europäischen Parlaments und des Rates vom 13. September 2023 zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Halbleiter-Ökosystems und zur Änderung der Verordnung (EU) 2021/694 (Chip-Gesetz) (ABl. L 229 vom 18.9.2023, S. 1, ELI: http://data.europa.eu/eli/reg/2023/1781/oj ).

^(30) [Verweis auf den veröffentlichen Bewertungsbericht einzufügen].

^(31) Aufgabenbeschreibung – https://ec.europa.eu/newsroom/dae/redirection/document/78326 .

^(32) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Einrichtung von „Horizont Europa“, dem Rahmenprogramm für Forschung und Innovation, für den Zeitraum 2028-2034 sowie über dessen Regeln für die Beteiligung und die Verbreitung der Ergebnisse und zur Aufhebung der Verordnung (EU) 2021/695.

^(33) Verordnung (EU) 2021/695 des Europäischen Parlaments und des Rates vom 28. April 2021 zur Einrichtung von Horizont Europa, dem Rahmenprogramm für Forschung und Innovation, sowie über dessen Regeln für die Beteiligung und die Verbreitung der Ergebnisse und zur Aufhebung der Verordnungen (EU) Nr. 1290/2013 und (EU) Nr. 1291/2013 (ABl. L 170 vom 12.5.2021, S. 1, ELI: http://data.europa.eu/eli/reg/2021/695/oj ).

^(34) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Einrichtung des Europäischen Fonds für Wettbewerbsfähigkeit (ECF), einschließlich des spezifischen Programms für Forschungs- und Innovationstätigkeiten im Verteidigungsbereich, zur Aufhebung der Verordnungen (EU) 2021/522, (EU) 2021/694, (EU) 2021/697 und (EU) 2021/783 sowie zur Änderung der Verordnungen (EU) 2021/696, (EU) 2023/588 und (EU) [EDIP].

^(35) Verordnung (EU) 2021/523 des Europäischen Parlaments und des Rates vom 24. März 2021 zur Einrichtung des Programms „InvestEU“ und zur Änderung der Verordnung (EU) 2015/1017 (ABl. L 107 vom 26.3.2021, S. 30, ELI: http://data.europa.eu/eli/reg/2021/523/oj ).

^(36) Verordnung (EU) 2021/694 des Europäischen Parlaments und des Rates vom 29. April 2021 zur Aufstellung des Programms „Digitales Europa“ und zur Aufhebung des Beschlusses (EU) 2015/2240 (ABl. L 166 vom 11.5.2021, S. 1, ELI: http://data.europa.eu/eli/reg/2021/694/oj ).

^(37) Verordnung (EU) 2021/2085 des Rates vom 19. November 2021 zur Gründung der gemeinsamen Unternehmen im Rahmen von „Horizont Europa“ und zur Aufhebung der Verordnungen (EG) Nr. 219/2007, (EU) Nr. 557/2014, (EU) Nr. 558/2014, (EU) Nr. 559/2014, (EU) Nr. 560/2014, (EU) Nr. 561/2014 und (EU) Nr. 642/2014 (ABl. L 427 vom 30.11.2021, S. 17, ELI: http://data.europa.eu/eli/reg/2021/2085/oj ).

^(38) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Ein Strategieplan für die Bildung in MINT-Fächern: Kompetenzen für Wettbewerbsfähigkeit und Innovation.

^(39) https://pact-for-skills.ec.europa.eu/index_de .

^(40) https://digital-strategy.ec.europa.eu/de/news/new-digital-skills-academies-support-eus-technological-sovereignty-competitiveness-and-preparedness .

^(41) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen über ein Konzept für einen europäischen Hochschulabschluss.

^(42) https://ec.europa.eu/info/law/better-regulation/have-your-say/initiatives/15892-Fair-labour-mobility-package-Skills-portability-1-digitalised-cross-border-portability-of-qualifications-and-skills_de .

^(43) https://education.ec.europa.eu/education-levels/higher-education/european-universities-initiative/map .

^(44) Verordnung (EU) 2026/1047 des Europäischen Parlaments und des Rates vom 29. April 2026 zur Einrichtung eines EU-Talentpools.

^(45) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Digitaler Kompass 2030: der europäische Weg in die digitale Dekade, COM(2021) 118 final vom 9. März 2021.

^(46) Richtlinie (EU) 2016/943 des Europäischen Parlaments und des Rates vom 8. Juni 2016 über den Schutz vertraulichen Know-hows und vertraulicher Geschäftsinformationen (Geschäftsgeheimnisse) vor rechtswidrigem Erwerb sowie rechtswidriger Nutzung und Offenlegung (ABl. L 157 vom 15.6.2016, S. 1, ELI: http://data.europa.eu/eli/dir/2016/943/oj ).

^(47) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Ein Chip-Gesetz für Europa, COM(2022) 45 final vom 8.2.2022.

^(48) Mitteilung der Kommission – Unionsrahmen für staatliche Beihilfen zur Förderung von Forschung, Entwicklung und Innovation, C(2022) 7388 (ABl. C 414 vom 28.10.2022, S. 1).

^(49) Verordnung (EU) Nr. 651/2014 der Kommission vom 17. Juni 2014 zur Feststellung der Vereinbarkeit bestimmter Gruppen von Beihilfen mit dem Binnenmarkt in Anwendung der Artikel 107 und 108 des Vertrags über die Arbeitsweise der Europäischen Union (ABl. L 187 vom 26.6.2014, S. 1, ELI: http://data.europa.eu/eli/reg/2014/651/oj ).

^(50) Verordnung (EU, Euratom) 2024/2509 des Europäischen Parlaments und des Rates vom 23. September 2024 über die Haushaltsordnung für den Gesamthaushaltsplan der Union (ABl. L, 2024/2509, 26.9.2024, ELI: http://data.europa.eu/eli/reg/2024/2509/oj ).

^(51) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Beschleunigung von Umweltprüfungen, COM(2025) 984 final vom 10.12.2025.

^(52) Richtlinie (EU) 2022/2555 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über Maßnahmen für ein hohes gemeinsames Cybersicherheitsniveau in der Union, zur Änderung der Verordnung (EU) Nr. 910/2014 und der Richtlinie (EU) 2018/1972 sowie zur Aufhebung der Richtlinie (EU) 2016/1148 (NIS‑2-Richtlinie) (ABl. L 333 vom 27.12.2022, S. 80, ELI: http://data.europa.eu/eli/dir/2022/2555/oj ).

^(53) Richtlinie 2014/23/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die Konzessionsvergabe (ABl. L 94 vom 28.3.2014, S. 1, ELI: http://data.europa.eu/eli/dir/2014/23/oj ).

^(54) Richtlinie 2014/24/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die öffentliche Auftragsvergabe und zur Aufhebung der Richtlinie 2004/18/EG (ABl. L 94 vom 28.3.2014, S. 65, ELI: http://data.europa.eu/eli/dir/2014/24/oj ).

^(55) Richtlinie 2014/25/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die Vergabe von Aufträgen durch Auftraggeber im Bereich der Wasser-, Energie- und Verkehrsversorgung sowie der Postdienste und zur Aufhebung der Richtlinie 2004/17/EG, (ABl. L 94 vom 28.3.2014, S. 243, ELI: http://data.europa.eu/eli/dir/2014/25/oj ).

^(56) Protokoll zur Änderung des Übereinkommens über das öffentliche Beschaffungswesen (ABl. L 68 vom 7.3.2014, S. 2, ELI: http://data.europa.eu/eli/prot/2014/115/oj ), das am 6 April 2014 in Kraft trat (ABl. L 89 vom 25.3.2014, S. 5).

^(57) Verordnung (EU) Nr. 654/2014 des Europäischen Parlaments und des Rates vom 15. Mai 2014 über die Ausübung der Rechte der Union in Bezug auf die Anwendung und die Durchsetzung internationaler Handelsregeln und zur Änderung der Verordnung (EG) Nr. 3286/94 des Rates zur Festlegung der Verfahren der Gemeinschaft im Bereich der gemeinsamen Handelspolitik zur Ausübung der Rechte der Gemeinschaft nach internationalen Handelsregeln, insbesondere den im Rahmen der Welthandelsorganisation vereinbarten Regeln (ABl. L 189 vom 27.6.2014, S. 50, ELI: http://data.europa.eu/eli/reg/2014/654/oj ).

^(58) Weitere Informationen siehe Kapitel 6 der Leitlinien zur Anwendbarkeit von Artikel 101 des Vertrags über die Arbeitsweise der Europäischen Union auf Vereinbarungen über horizontale Zusammenarbeit („Horizontale Leitlinien“).

^(59) Verordnung (EU) 2015/479 des Europäischen Parlaments und des Rates vom 11. März 2015 über eine gemeinsame Ausfuhrregelung (kodifizierter Text) (ABl. L 83 vom 27.3.2015, S. 34, ELI: http://data.europa.eu/eli/reg/2015/479/oj ).

^(60) Richtlinie (EU) 2022/2557 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über die Resilienz kritischer Einrichtungen und zur Aufhebung der Richtlinie 2008/114/EG des Rates (ABl. L 333 vom 27.12.2022, S. 164, ELI: http://data.europa.eu/eli/dir/2022/2557/oj ).

^(61) Richtlinie 85/374/EWG des Rates vom 25. Juli 1985 zur Angleichung der Rechts- und Verwaltungsvorschriften der Mitgliedstaaten über die Haftung für fehlerhafte Produkte (ABl. L 210 vom 7.8.1985, S. 29, ELI: http://data.europa.eu/eli/dir/1985/374/oj ).

^(62) Europäische Kommission: Generaldirektion für internationale Partnerschaften, The Global Gateway strategy, Amt für Veröffentlichungen der Europäischen Union, 2025, https://data.europa.eu/doi/10.2841/5607451 .

^(63) Europäische Kommission: Generaldirektion Kommunikationsnetze, Inhalte und Technologien, An international digital strategy for the European Union, Europäische Kommission, 2025, https://data.europa.eu/doi/10.2759/4019528 .

^(64) Europäische Kommission: Generaldirektion Kommunikationsnetze, Inhalte und Technologien, Alliance on Processors and Semiconductors Technologies, https://digital-strategy.ec.europa.eu/en/policies/alliance-processors-and-semiconductor-technologies.

^(65) Beschluss (EU, Euratom) 2015/443 der Kommission vom 13. März 2015 über Sicherheit in der Kommission (ABl. L 72 vom 17.3.2015, S. 41, ELI: http://data.europa.eu/eli/dec/2015/443/oj ).

^(66) ABl. L 123 vom 12.5.2016, S. 1, ELI: http://data.europa.eu/eli/agree_interinstit/2016/512/oj .

^(67) Empfehlung 2003/361/EG der Kommission vom 6. Mai 2003 betreffend die Definition der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen (Bekannt gegeben unter Aktenzeichen C(2003) 1422) (ABl. L 124 vom 20.5.2003, S. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj ).

^(68) Verordnung (EU) 2016/679 des Europäischen Parlaments und des Rates vom 27. April 2016 zum Schutz natürlicher Personen bei der Verarbeitung personenbezogener Daten, zum freien Datenverkehr und zur Aufhebung der Richtlinie 95/46/EG (Datenschutz-Grundverordnung) (ABl. L 119 vom 4.5.2016, S. 1, ELI: http://data.europa.eu/eli/reg/2016/679/oj ).

^(69) Verordnung (EU, Euratom) 2020/2093 des Rates vom 17. Dezember 2020 zur Festlegung des mehrjährigen Finanzrahmens für die Jahre 2021 bis 2027 (ABl. L 433I vom 22.12.2020, S. 11, ELI: http://data.europa.eu/eli/reg/2020/2093/oj ).

^(70) Verordnung (EU) 2021/1173 des Rates vom 13. Juli 2021 zur Gründung des Gemeinsamen Unternehmens für europäisches Hochleistungsrechnen und zur Aufhebung der Verordnung (EU) 2018/1488 (ABl. L 256 vom 19.7.2021, S. 3, ELI: http://data.europa.eu/eli/reg/2021/1173/oj ).

^(71) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Europäische Kompetenzagenda für nachhaltige Wettbewerbsfähigkeit, soziale Gerechtigkeit und Resilienz, COM(2020) 274 final.

^(72) Europäische Kommission: Generaldirektion für internationale Partnerschaften, The Global Gateway strategy, Amt für Veröffentlichungen der Europäischen Union, 2025, https://data.europa.eu/doi/10.2841/5607451 .

^(73) Europäische Kommission: Generaldirektion für internationale Partnerschaften, The Global Gateway strategy, Amt für Veröffentlichungen der Europäischen Union, 2025, https://data.europa.eu/doi/10.2841/5607451 .

^(74) Im Sinne des Artikels 58 Absatz 2 Buchstabe a oder b der Haushaltsordnung.

^(75) Arbeitsunterlage der Kommissionsdienststellen.

^(76) GM = Getrennte Mittel/NGM = Nichtgetrennte Mittel.

^(77) EFTA: Europäische Freihandelsassoziation.

^(78) Kandidatenländer und – sofern zutreffend – potenzielle Kandidaten des Westbalkans.

^(79) Technische und/oder administrative Hilfe und Ausgaben zur Unterstützung der Durchführung von Programmen bzw. Maßnahmen der EU (vormalige BA-Linien), indirekte Forschung, direkte Forschung.

^(80) Der Mittelbedarf sollte auf der Grundlage der Angaben zu den Durchschnittskosten veranschlagt werden, die auf der einschlägigen BUDGpedia-Seite verfügbar sind.

^(81) Outputs sind Produkte, die geliefert, und Dienstleistungen, die erbracht werden (z. B. Zahl der Austauschstudenten, gebaute Straßenkilometer usw.).

^(82) Wie in Abschnitt 1.3.2 „Einzelziel(e)“ beschrieben.

^(83) Bitte unter der Tabelle angeben, wie viele der aufgeführten VZÄ bereits der Verwaltung der Maßnahme zugeordnet sind und/oder durch Personalumschichtung innerhalb der GD dieser Aufgabe zugeteilt werden können. Den Nettobedarf beziffern.

^(84) Bei den traditionellen Eigenmitteln (Zölle, Zuckerabgaben) sind die Beträge netto, d. h. abzüglich 20 % für Erhebungskosten, anzugeben.

<a id="annex-i"></a>
## Anhang I – Maßnahmen im Rahmen der Initiative „Chips für Europa 2.0“

Technische Beschreibung der Initiative „Chips für Europa 2.0“: Tätigkeitsbereich

Die im Rahmen der Initiative „Chips für Europa 2.0“ unterstützten Maßnahmen werden, soweit angezeigt, im Einklang mit den folgenden technischen Beschreibungen durchgeführt:

1. Entwurfskapazitäten für integrierte Halbleitertechnik

Kontext

Mit der Initiative „Chips für Europa 2.0“ sollen über eine cloudbasierte Entwurfsplattform, die in der gesamten Union zur Verfügung steht, umfangreiche innovative Entwurfskapazitäten für Halbleitertechnik gefördert werden. Die Entwurfsplattform soll innovative Entwurfsumgebungen mit erweiterten Bibliotheken und Werkzeugen bieten und viele bestehende und neue Technologien, darunter aufkommende Technologien wie die integrierte Photonik, Quantentechnik sowie KI/neuromorphe Technologien, zusammenbringen. In Verbindung mit bestehenden Werkzeugen der elektronischen Entwurfsautomatisierung soll sie den Entwurf innovativer Komponenten und neuer Systemkonzepte ermöglichen, und sie demonstriert wesentliche Funktionen, wie z. B. neue Ansätze in Bezug auf Hochleistung, Energieeffizienz, Sicherheit und neue dreidimensionale und heterogene Systemarchitekturen.

Die Plattform bietet als strategisches Rückgrat der Initiative „Chips für Europa 2.0“ eine zentrale Anlaufstelle, die Anwender vom Entwurf über die Prototypenentwicklung bis hin zur Fertigung begleitet und Forschung, Bildung und Industrie zusammenführt. Ihr oberstes Ziel ist die Förderung einer neuen Generation von Start-ups, die in der Union tätig sind, aber über keine eigenen Fertigungsanlagen verfügen (fabless). Diese Unternehmen tragen zur Entwicklung innovativer Chips für die Anwenderbranchen der Union bei, erzielen den höchsten Wert entlang der Halbleiterwertschöpfungskette, fördern Innovationen auf schnell wachsenden Märkten und verringern die Abhängigkeit der Union von ausländischen Entwurfsökosystemen.

Stand

Zum Stand Mai 2026 ist ein breites Spektrum von Akteuren beteiligt, darunter ein Plattformkoordinierungsteam (PCT)^(1), Entwurfsbegleitungsteams^(2), Cloudanbieter, Anbieter elektronischer Entwurfsautomatisierung (EDA) und Anbieter geistigen Eigentums. Die Entwurfsplattform wird schrittweise eingeführt: Zunächst wurde ein Plattformkoordinierungsteam ausgewählt und eingerichtet, um die Plattform zu betreiben, die zentrale Cloud-Infrastruktur aufzunehmen und die Anwenderunterstützungsdienste zu koordinieren. Zudem wurden die Entwurfsbegleitungsteams ausgewählt, um den Anwendern während des gesamten Chip-Entwicklungsprozesses maßgeschneiderte, durchgängige Unterstützung zu leisten. Darüber hinaus wurde ein Auftragnehmer für die zentrale Cloud-Infrastruktur ausgewählt, der das geistige Eigentum, die Process Design Kits der Pilotanlagen und quelloffene EDA-Werkzeuge aufnehmen wird.

Derzeit laufen Verhandlungen über die Auswahl und Einbindung wichtiger Anbieter von EDA-Werkzeugen. Diese Verhandlungen sollen bis Herbst 2026 geschlossen werden. Die ersten voll ausgebauten Großanlagen werden voraussichtlich bis Ende 2026 in Betrieb genommen.

Die Entwurfsplattform wird durch weitere Maßnahmen ergänzt, um Entwurfskompetenzen in der Union zu fördern. Dazu gehören die Verwaltung von Finanzhilfen für Start-ups und KMU, die die Plattform nutzen, die Unterstützung der Entwicklung quelloffener EDA-Werkzeuge und für die EUROPRACTICE-Dienste, die mehr als 600 europäischen Hochschulen Zugang zu EDA-Werkzeugen für Ausbildungszwecke zu symbolischen Preisen sowie Zugang zur Fertigung führender Fertigungsbetriebe bieten.

Ausblick

Indem immer mehr Technologien und Entwürfe in die Entwurfsplattform integriert werden, entstehen auf der Plattform zunehmend neue Entwurfsmöglichkeiten. Dazu können auch quelloffene Prozessorarchitekturen und andere innovative Architekturen, Chiplets, programmierbare Chips, neue Arten von Speichern, Prozessoren, Beschleunigern oder Chips mit niedrigem Stromverbrauch gehören.

Die Plattform bindet darüber hinaus auch Photonik und Quantenchips, geistiges Eigentum, Bibliotheken und Entwurfsautomatisierungswerkzeuge in ein vollständig integriertes Systemkonzept ein (siehe auch die nachstehenden Nummern 3 und 5). Ferner werden die Process Design Kits (PDKs) der wichtigsten Pilotanlagen der Initiative „Chips für Europa 2.0“ sowie die PDKs der industriellen Fertigungsanlagen (mit vorheriger Zustimmung) integriert, um den Entwurf von Chips zu erleichtern, die für die Produktionsübergabe (das sogenannte Tape-out) zu solchen Pilotanlagen und industriellen Fertigungsanlagen bereit sind.

Die Dienste der Plattform sollen über die Cloud angeboten werden, um durch die Vernetzung bestehender und neuer Entwicklungszentren in den Mitgliedstaaten den Zugang und die Offenheit für die gesamte Gemeinschaft zu maximieren. Insbesondere soll die Plattform Unterstützung für Start-ups, Scale-ups und KMU bieten. Sie erweitert das Halbleiterökosystem der Union durch Einbindung verschiedener Marktsektoren wie Gesundheit, Mobilität, Energie, Telekommunikation, Sicherheit, Verteidigung und Weltraum. Der Industrialisierung innovativer Komponenten, die auf der Plattform entworfen und in Leitsektoren eingeführt werden, wird größere Aufmerksamkeit gewidmet.

2. Pilotanlagen zur Vorbereitung auf innovative Produktion, Erprobung und Validierung

Kontext

Die Initiative „Chips für Europa 2.0“ soll Pilotanlagen für die Produktion, Erprobung und Validierung unterstützen, die die Lücke zwischen Labor und Fertigung bei der fortgeschrittenen Halbleitertechnik schließen, darunter Architekturen und Werkstoffe für Leistungselektronik, neuromorphe und eingebettete KI-Chips, integrierte Photonik, Graphen und andere auf 2D-Material basierende Technologien, die Elektronik und Mikrofluidik in heterogene Systeme integrieren.

Stand

Zum Stand Mai 2026 sind bereits fünf Pilotanlagen in unterschiedlichen Stadien in Betrieb, während gleichzeitig weitere Ausrüstungen, Maschinen und Werkzeuge implementiert werden, um die Fähigkeiten und Kapazitäten der Pilotanlagen zu erhöhen. Die Technologiebereiche der Pilotanlagen wurden ausgewählt, um die kritischsten Lücken der Union im Halbleiterbereich zu schließen und gleichzeitig auf bestehenden Stärken aufzubauen und die langfristige Wettbewerbsfähigkeit, Versorgungssicherheit und industrielle Resilienz zu gewährleisten. Bei diesen fünf Pilotanlagen handelt es sich um:

- · Logiktechnologie unter 2 nm, die die Stellung der Union hinsichtlich fortgeschrittener Technologieknoten sichern, die in KI, HPC, Rechenzentren und Kommunikation der nächsten Generation zu finden sind,

- · FD-SOI-Technologien, bei denen die Union bereits eine führende Rolle einnimmt und die hochzuverlässige Chips mit niedrigem Stromverbrauch für die Automobilindustrie, Mobilität, industrielle Automatisierung und das Internet der Dinge ermöglichen,

- · fortgeschrittenes Packaging und heterogene Integration, die der Erkenntnis Rechnung tragen, dass künftige Leistungssteigerungen von der Integration auf Systemebene abhängen; die Union weist im Bereich des Packaging zwar eine strategische Schwäche auf, gleichzeitig bietet sich ihr die große Chance, eine führende Rolle bei Chiplets, 3D-Stacking sowie der gemeinsamen Integration von Logik-, Speicher-, Sensor- und Konnektivitätskomponenten zu übernehmen,

- · Werkstoffe mit großer Bandlücke (wie SiC und GaN) zählen zu den Stärken der Union im Bereich der Leistungselektronik und sind für die Energiewende, die Elektromobilität, die Infrastruktur für erneuerbare Energien und hocheffiziente Industriesysteme von entscheidender Bedeutung und

- · photonisch integrierte Schaltungen, die für die Datenübertragungs-, Sensor- und Hochleistungsrechenarchitekturen mit hoher Bandbreite und niedrigem Stromverbrauch in Telekommunikations- und Rechenzentren immer wichtiger werden.

Darüber hinaus sollen sogenannte „Lab-to-Fab-Beschleuniger“ eine rasche Übernahme der im Rahmen der Pilotanlagen entwickelten Technologien durch die Industrie der EU erreichen, insbesondere von Technologien im Zusammenhang mit fortgeschrittenem Packaging und heterogener Integration.

Ausblick

Pilotanlagen sollen weiterhin dabei unterstützen, die Leistungsfähigkeit von IP-Blöcken, virtuellen Prototypen, neuen Entwürfen und neuartigen integrierten heterogenen Systemen u. a. mittels Process Design Kits (PDKs) und auf offene und zugängliche Weise zu erproben, zu testen und zu validieren. Ihre PDKs sollen in die Entwurfsplattform integriert werden, um den Zugang zu Entwurfs- und (virtuellen) Prototypprojekten zu ermöglichen.

Bei den derzeitigen Pilotanlagen soll der Schwerpunkt zunehmend auf der Industrialisierung und dem Einsatz von Pilotanlagentechnologien zur Unterstützung des Halbleiterökosystems der Union liegen.

Neue oder modernisierte Pilotanlagen können im Hinblick auf neu entstehende Herausforderungen gefördert werden, etwa in Bezug auf energieeffiziente KI-Chips, Spitzentechnologien wie komplementäre Feldeffekttransistoren-Geräte (CFET-Geräte) und monolithische integrierte 3D-Schaltungen für eine höhere Leistung und einen niedrigem Stromverbrauch sowie ferroelektrische, resistive und ladungsbasierte Speicher, die einen extrem schnellen Betrieb bei extrem niedrigem Stromverbrauch ermöglichen.

Darüber hinaus können neue oder modernisierte Pilot-Testumgebungen unterstützt werden, wenn verschiedene innovative Technologien oder Produkte für die Entwicklung und Validierung neuer Geräte für wichtige Anwendungen und Anwenderbranchen kombiniert und integriert werden. Ein Beispiel hierfür ist eine Testumgebungen für Miniaturisierungs-, fortgeschrittene Optik- und Laserprojektionstechnologien im Zusammenhang mit Datenbrillen. Pilot-Testumgebungen sollen dazu beitragen, vor einer vollständigen Einführung im industriellen Maßstab Risiken zu ermitteln, die Leistung zu validieren und die Durchführbarkeit unter realen Bedingungen sicherzustellen.

3. Fortgeschrittene technologische und ingenieurstechnische Kapazitäten für Quantenchips

Kontext

Die Initiative „Chips für Europa 2.0“ soll die Entwicklung von Quantenchips und damit verbundenen Technologien unterstützen, einschließlich solcher, die auf Halbleiterwerkstoffen basieren oder in die Photonik integriert ist. Zu den gezielten Maßnahmen gehören Entwurfsbibliotheken für Quantenchips, Pilotanlagen für die Herstellung von Quantenchips und Anlagen für die Prüfung und Validierung der in den Pilotanlagen hergestellten Quantenchips. Ziel ist es, Forschenden, Start-ups und der Industrie in der Union zuverlässigen Zugang zu Anlagen zu verschaffen, in denen die wichtigsten Quantenchiptechnologien hergestellt und validiert werden können.

Stand

Zum Stand Mai 2026 wurden sechs Pilotanlagen für Quantenchips eingerichtet, eine für jede der führenden Technologieplattformen der Union: supraleitende, Spin-, Photonik-, Diamant-, Neutralatom- und Ionenfallen-Chips. Die Projekte konzentrieren sich auf die Einrichtung stabiler Fertigungsprozesse im Pilotmaßstab, die Integration von Erprobungs- und Versuchseinrichtungen, die Entwicklung von Fahrplänen für eine frühzeitige Industrialisierung und die Schaffung der Grundlagen für die künftige Skalierung.

| Pilotanlage | Bezeichnung | Koordinator |
| --- | --- | --- |
| Supraleitend | SUPREME | VTT (FI) |
| Spin | SPINS | IMEC (BE) |
| Photonik | P4Q | Universität Twente (NL) |
| Diamant | DIREQT | CNR (IT) |
| Neutralatome | Q-PLANET | PASCAL (FR) |
| Ionenfalle | CHAMPION-ION | SAL (AT) |

Darüber hinaus wird den Tätigkeiten zur Unterstützung des Entstehens einer europaweiten Quantenentwurfsgemeinschaft im Hinblick auf Bibliotheken und Werkzeuge für Entwurf, Simulation und Überprüfung von Quantenchips Rechnung getragen. Ferner werden grundlegende Technologien unterstützt, darunter auch Teilsysteme für Elektronik, Kryogenik, Packaging und Schnittstellen, die zentrale Quantengeräte vorbereiten, schützen, steuern, verbinden und auslesen.

Ausblick

Fortgeschrittene technologische und ingenieurtechnische Kapazitäten für Quantenchips werden weiterhin auf- und ausgebaut. Dies umfasst Entwurfsfähigkeiten, Entwurfsbibliotheken für Quantenchips, Pilotanlagen, Erprobungs- und Versuchseinrichtungen und grundlegende Technologien. Darüber hinaus sollen erste Bemühungen für eine industrielle Umsetzung der am weitesten entwickelten Technologien unterstützt werden. Die Unterstützung soll nach den jeweiligen Technologieplattformen differenziert ausgestaltet werden. Mit der technologischen Ausreifung von Quantenchips soll auch eine entsprechende Industrialisierung weiter voranschreiten.

4. Netz der Kompetenzzentren und Kompetenzentwicklung im Halbleiterbereich

Kontext

Die Initiative „Chips für Europa 2.0“ soll den Betrieb eines Netzes der Halbleiter-Kompetenzzentren unterstützen. Diese Zentren sollen einen strukturierten Zugang zu technischer Sachkenntnis, Testeinrichtungen und Beratungsdiensten bieten und Unternehmen (insbesondere KMU und Start-ups) dabei unterstützen, ihre Entwurfsfähigkeiten auszubauen, neue Technologien zu erproben und spezialisierte Kompetenzen zu entwickeln. Die Kompetenzzentren sollen eine Schlüsselrolle dabei spielen, Qualifikationsdefiziten in der Union in Bezug auf Halbleitertechnik entgegenzuwirken.

Stand

Zum Stand Mai 2026 wurden in allen Mitgliedstaaten sowie in Norwegen Halbleiter-Kompetenzzentren eingerichtet. Darüber hinaus wurde eine Unterstützungsmaßnahme zur Einrichtung und Koordinierung der Arbeit der nationalen Kompetenzzentren festgelegt. Im Rahmen der Unterstützungsmaßnahme wurde eine Fokusgruppe für Ausbildung und Kompetenzentwicklung eingerichtet, die die Zusammenarbeit zwischen den Kompetenzzentren fördert, um Bildungs- und Weiterbildungsinitiativen umzusetzen, Schulungskonzepte zu entwickeln und spezifische Schulungen und den Zugang zur Entwurfsplattform und zu Pilotanlagen bereitzustellen.

Ausblick

Die Halbleiter-Kompetenzzentren werden weiterhin unterstützt. Es wird geprüft, ob angesichts der Markt- und Technologieentwicklungen neue Kompetenzzentren eingerichtet oder bestehende Kompetenzzentren neu ausgerichtet werden sollten. Die Zusammenarbeit zwischen den Kompetenzzentren im Gesamtnetz soll nach Möglichkeit verstärkt werden. Darüber hinaus soll die Unterstützung der Kompetenzzentren für die Kompetenzentwicklung verstärkt werden, unter anderem durch die Förderung der Zusammenarbeit mit Hochschulen und Anbietern der beruflichen Aus- und Weiterbildung, durch eine enge Zusammenarbeit im Rahmen des Kompetenzpakts und mit der Arbeitsgruppe „Kompetenzen“ der Industrieallianz sowie durch mehr Sichtbarkeit und Attraktivität des Halbleitersektors.

5. Fortgeschrittene Kapazitäten für den Entwurf, die Prototypentwicklung und die industrielle Einführung photonisch integrierter Schaltungen

Kontext

Mit dieser neuen Komponente der Initiative „Chips für Europa“ wird die Entwicklung photonisch integrierter Schaltungen und zugehöriger Technologien unterstützt. Zu den Maßnahmen gehören die Entwicklung von Entwurfsbibliotheken und Entwurfsautomatisierungswerkzeugen für photonisch integrierte Schaltungen sowie der Ausbau bestehender und/oder die Einrichtung neuer Pilotanlagen für die Entwicklung von Prototypen und die Herstellung photonisch integrierter Schaltungen. Die Fähigkeiten im Bereich der Produktionstechnologien, einschließlich Co-Packaging und der heterogenen Integration mit Elektronikchips, Fertigungsausrüstungen und Werkstoffplattformen für photonisch integrierte Schaltungen, werden gestärkt.

Stand

Zum Stand Mai 2026 wurde eine Pilotanlage für photonisch integrierte Schaltungen eingeweiht. Diese Pilotanlage bietet frei zugängliche Fertigungsdienste an 14 Standorten und umfasst mehrere Photonik-Werkstoffplattformen von Silizium und Siliziumnitrid bis hin zu Indiumphosphid. Zu den Diensten gehören Chip-Fertigungsläufe, hybride Integration, Packaging, Tests und Einstufung der Zuverlässigkeit. Ferner sind Technologiedemonstratoren vorgesehen, darunter Co-Packaged-Optik für KI-Rechenzentren, LiDAR-Sensoren, Erzeugung und Steuerung sichtbaren Lichts (Visible Light Engines) für AR/VR und programmierbare photonische Prozessoren. Neben der Pilotanlage werden außerdem Industrie-Demonstratoren für fortgeschrittene Photoniktechnologien entwickelt, die Skalierbarkeit, Zuverlässigkeit und Integrationsfähigkeit aufzeigen sollen.

Ausblick

Photonisch integrierte Schaltungen und zugehörige Technologien werden weiterhin unterstützt. Dies umfasst Entwurfswerkzeuge, Entwurfsbibliotheken, Pilotanlagen, Demonstratoren und Schulungsdienste. Besonderes Augenmerk gilt dem Transfer und der industriellen Einführung von Technologien, die im Rahmen dieser Komponente der Initiative „Chips für Europa 2.0“ entwickelt werden.

6. Tätigkeiten im Rahmen des „Chip-Fonds“ für den Zugang von Start-ups, Scale-ups und KMU zu Kapital,

Kontext

Mit der Initiative „Chips für Europa 2.0“ wird die Schaffung eines florierenden Halbleiter- und Quanteninnovations-Ökosystems unterstützt, indem der Zugang zu Risikokapital für Start-ups, Scale-ups und KMU gefördert wird, damit sie wachsen und ihre Marktpräsenz nachhaltig ausbauen können.

Stand

Zum Stand Mai 2026 wird der Chip-Fonds über zwei thematische Investitionsfazilitäten umgesetzt: das Accelerator-Programm des Europäischen Innovationsrats, das im Rahmen von Horizont Europa risikoreichen technologieintensiven Start-ups eine Mischfinanzierung aus Zuschüssen und Eigenkapital bereitstellt sowie den vom Europäischen Investitionsfonds verwalteten Fonds „InvestEU“ – der durch eine Garantie des Programms „Digitales Europa“ abgesichert wird – für Eigenkapitalinvestitionen über Finanzintermediäre von der Gründungs- bis zur Wachstumsphase. Die für das Accelerator-Programm bereitgestellten Mittel in Höhe von 300 Mio. EUR wurden in nur zwei Jahren vollständig eingesetzt; insgesamt werden dadurch 24 hochinnovative Start-ups mit insgesamt 62 Mio. EUR an Zuschüssen und 238 Mio. EUR an empfohlenen Beteiligungsinvestitionen unterstützt. Im Rahmen der InvestEU-Komponente des Chip-Fonds wurden vier Finanzpartner ausgewählt und mit ihnen 68 Mio. EUR an Mitteln unterzeichnet oder genehmigt; dadurch erhielten bislang 31 Unternehmen von der Frühphase bis zur Wachstumsphase Beteiligungsinvestitionen in Höhe von 116 Mio. EUR.

Ausblick

Die Unterstützung für Start-ups wird fortgesetzt. Gleichzeitig wird der Schwerpunkt vermehrt auf Scale-ups und Finanzierungen in späteren Phasen gelegt. Es werden zunehmend erhebliche Mittel aus dem „Scaleup Europe Fund“ für technologieintensive Scale-ups bereitgestellt, um zusätzliches privates Risikokapital zu mobilisieren.

7. Große Herausforderungen

Kontext

Diese neue Komponente der Initiative „Chips für Europa 2.0“ unterstützt groß angelegte, sektorenübergreifende Initiativen zur Bewältigung großer technologischer und industrieller Herausforderungen, die für die Union von strategischer Bedeutung sind (im Folgenden „Große Herausforderungen“), die sich potenziell auf mehrere Ökosysteme auswirken. Die Großen Herausforderungen dürften zu technologischen Fortschritten sowohl bei den etablierten und als auch bei Spitzentechnologien, zur durchgängigen Produktintegration über den gesamten Produktentwicklungszyklus hinweg und zu deren vorkommerzieller Industrialisierung führen.

Stand

Zum Stand Mai 2026 wurden im Rahmen der Initiative keine früheren Tätigkeiten unter dem Motto „Große Herausforderungen“ durchgeführt.

Ausblick

Mögliche Große Herausforderungen, die gezielt angegangen werden können, sind unter anderem die Entwicklung neuer Rechentechnik, bei der sich der Energieverbrauch drastisch – beispielsweise um das1 000-Fache – senken lässt. Eine solche Große Herausforderung würde zu energieeffizienten, sicheren und verteilten KI-Infrastrukturen führen, die Hochleistungs-KI-Beschleuniger (wie Speicher auf HBM-Niveau, gestapelte Logikchips (stacked logic), optische und HF-Verbindungen), agentische und eingebettete KI-Systeme, kontextbezogene Intelligenz am Netzrand (contextual edge intelligence) und sichere Infrastrukturen mit niedrigem Stromverbrauch ermöglichen. Die Entwicklung energieeffizienter Chips, einschließlich KI-Chips, soll außerdem zur Bewältigung der im Rahmen der Verordnung zur Cloud- und KI-Entwicklung (CADA) festgelegten Großen Herausforderung beitragen, nämlich eine Vorreiterrolle bei energie- und ressourceneffizienten Recheninfrastrukturen einzunehmen, um deren Nachhaltigkeit in großem Maßstab zu verbessern^(3). Zwischen den FuE-Tätigkeiten zur Bewältigung dieser beiden komplementären Herausforderungen soll eine enge Verknüpfung hergestellt und die Möglichkeit vorgesehen werden, koordinierte Aufforderungen zur Einreichung von Vorschlägen zu veröffentlichen.

Eine weitere Große Herausforderung ist die Entwicklung von Prozessoren und Beschleunigern, die in der EU konzipiert und gegebenenfalls hergestellt werden und Teil eines Cloud- und KI-Stacks würden. Diese Große Herausforderung wird wiederum mit einer im Rahmen des CADA definierten Großen Herausforderung verknüpft sein und zu deren Bewältigung beitragen, nämlich der Verwirklichung der Autonomie auf allen Ebenen des Cloud- und KI-Stacks mit dem Ziel, Abhängigkeiten bei kritischen Technologien zu beseitigen^(4). Die Große Herausforderung kann insbesondere auf Lösungen abzielen, die von aufstrebenden Start-ups entwickelt werden, und kann die innovationsfördernde Auftragsvergabe umfassen. Auch diesbezüglich soll zwischen den FuE-Tätigkeiten zur Bewältigung dieser beiden komplementären Herausforderungen eine enge Verknüpfung hergestellt und die Möglichkeit vorgesehen werden, koordinierte Aufforderungen zur Einreichung von Vorschlägen zu veröffentlichen.

Eine dritte Große Herausforderung kann im Bereich der physischen KI angesiedelt sein, um die grundlegenden Technologien bereitzustellen, die ein breites Spektrum künftiger Anwendungen, Dienste und autonomer Systeme ermöglichen sollen, die beispielsweise von humanoiden Robotern bis hin zu Industrierobotern und deren Einsatz insbesondere in den Bereichen Medizintechnik, Gesundheitswesen, Fertigung, Luftfahrt, Weltraum und Verteidigung reichen. FuI im Bereich der physischen KI sollen zu Fortschritten bei etablierten Technologien wie Leistungshalbleitern, Mikrocontrollern sowie Analog-/Mixed-Signal- und Sensortechnik führen. Auf die FuI-Tätigkeiten sollen die industrielle Fertigung und die Kommerzialisierung eingebetteter fortgeschrittener KI in autonomen Maschinen, Robotern, Breitbandnetzen und vernetzten Geräten der nächsten Generation folgen.

Eine vierte Große Herausforderung könnte Datenbrillen und virtuelle Welten zum Gegenstand haben. In einer kürzlich veröffentlichten Mitteilung der Kommission werden die Strategie und die vorgeschlagenen Maßnahmen für virtuelle Welten und das Web 4.0 dargelegt^(5). In diesem Zusammenhang sind Optik, Photonik und Halbleitertechnik von entscheidender Bedeutung für die Entwicklung von Sensor- und Visualisierungsgeräten, die Anwendungen der virtuellen Welten wie intelligente Brillen unterstützen. FuI-Tätigkeiten sollen zu erheblichen Verbesserungen der Qualität, Leistungsfähigkeit und Effizienz der Verarbeitung und Kommunikation von Inhalten virtueller Welten führen. Eine Große Herausforderung im Bereich der Datenbrillen soll darauf abzielen, einschlägige Komponenten mit extrem niedrigem Stromverbrauch, wie Leistungselektronik, Sensoren, Kameras, Audiogeräte, Laser, Spezialbrillen, Displays, neuromorphe Chips oder KI-Chips, in funktionsfähige Prototypen und Demonstratoren zu integrieren.

Große Herausforderungen können sich auch auf Marktziele beziehen, z. B. die Produktionsübergabe der Chips von 100 Start-ups ohne eigene Fertigungsanlagen, darunter von 10 Einhörnern, bis 2035. Eine weitere Art Großer Herausforderungen kann sich mit Leitmärkten und der Ankurbelung der Nachfrage befassen, z. B. durch die Entwicklung von Hardwareplattformen für die Automobilindustrie oder des vollständigen Stacks für KI-(Giga-)Fabriken. Große Herausforderungen können auch neue Halbleiterproduktionstechnik betreffen, z. B. mehr Recycling und die Förderung der Kreislauffähigkeit von Werkstoffen oder die Entwicklung fortgeschrittener Technik zur Kühlung von Halbleitern.

Die Industrialisierung neuer Technik soll ein wesentlicher Bestandteil der Großen Herausforderungen sein.

<a id="annex-ii"></a>
## Anhang II – Vorrangige Bereiche für strategische Projekte

Technische Beschreibung möglicher vorrangiger Bereiche für strategische Projekte: Tätigkeitsbereich

1. Europäische Fertigung fortgeschrittener Halbleiter^(6)

Die Maßnahmen zur Schaffung einer nachhaltigen Nachfrage nach fortgeschrittenen Halbleitern sollen durch den Aufbau eines europäischen Ökosystems für fortgeschrittene Technologien verstärkt werden. Die Souveränität und Versorgungssicherheit der EU im Bereich der fortgeschrittenen Chipproduktion und Innovation sind von entscheidender Bedeutung, um ein florierendes und wettbewerbsfähiges Halbleiterökosystem in der EU zu fördern, das zur Verringerung der Abhängigkeit von ausländischen Lieferketten beiträgt. Dies ist besonders wichtig, um der gestiegenen Nachfrage nach KI- und Cloud-Infrastrukturen gerecht werden zu können. Darüber hinaus sind fortgeschrittene Chips für strategische Industriesektoren wie Verteidigung, Gesundheit, Weltraum, Robotik, Gesundheitswesen, sichere Kommunikation, Drohnen und autonome Fahrzeuge unerlässlich. Sie sind zudem kritische Inputs für neu entstehende hochwertige Bereiche wie Photonik und Quantenchips.

Ziel dieses strategischen Projekts ist die Errichtung einer Halbleiterfertigungsanlage in der EU, in dem die Herstellung von Spitzenknotenchips mit Chiplet-Integration und 2,5D/3D-Packaging kombiniert wird. Es baut auf einer soliden Forschungsgrundlage auf, die mit der Initiative „Chips für Europa“ im Rahmen des Chip-Gesetzes validiert wurde. Die Fertigungsanlage steht im Einklang mit den europäischen Werten und wahrt somit auch die Garantien für die Vertraulichkeit, Integrität und Rückverfolgbarkeit von Chips, insbesondere für sensible und strategische Anwendungen und Infrastrukturen. Europäische Unternehmen könnten zur Schaffung von Nachfrage beitragen, indem sie Wachstumsanreize noch nicht aus eigener Fertigung stammende Chips und für den KI-gestützten Systementwurf bieten. Je nach gewählter Option werden die öffentlichen und privaten Investitionen auf 20 bis 40 Mrd. EUR geschätzt. Es könnten 3 bis 4 Mrd. EUR an öffentlichen und privaten Investitionen mobilisiert werden, um das Wachstum von Chipentwurfsunternehmen ohne eigene Fertigungsanlagen in der gesamten EU durch Mittel aus dem nächsten MFR, von den Mitgliedstaaten sowie von einschlägigen Industriezweigen und privaten Investoren zu fördern.

Dieses Projekt soll in enger Zusammenarbeit mit innereuropäischen und außereuropäischen Interessenträgern, darunter vertrauenswürdigen Technologie- und Fertigungspartnern, entwickelt werden, und es soll den Aufbau von Spitzenkapazitäten ermöglichen, die strukturelle Abhängigkeiten von Lieferanten aus Drittländern verringern, die Versorgungssicherheit beispielsweise in den Bereichen KI, Verteidigung, Weltraum, Gesundheitswesen, Telekommunikation und Automobilindustrie erhöhen und die technologische Souveränität der EU stärken.

Als erster Schritt könnte eine informelle Aufforderung zur Interessenbekundung veröffentlicht werden. Im Anschluss an die Auswertung der eingegangenen Interessenbekundungen könnte eine Aufforderung zur Einreichung von Vorschlägen folgen.

2. KI-Chips und KI-Systeme für EU-Recheninfrastrukturen

Die Union ist derzeit auf KI-Chips und integrierte Systeme aus Drittstaaten angewiesen; dies führt bei der Einfuhr kritischer KI-Technologien aus Drittstaaten zu erheblichen Kapitalabflüssen. Zur Stärkung der technologischen Souveränität der Union müssen daher wettbewerbsfähige heimische Kapazitäten sowohl auf Chipebene als auch auf allen Ebenen des Rechenstacks aufgebaut werden.

Ziel dieses strategischen Projekts ist es, auf der Grundlage fortgeschrittener europäischer Technologien KI-Chips und Rechensysteme zu entwerfen, zu entwickeln, als Prototypen zu erstellen und in die Produktion zu übergeben (Tape-out). Der Entwurf von KI-Chips soll zur Entwicklung von Demonstratoren und Prototypen führen, die in einer gemeinsamen Testumgebung anhand klarer Vergleichswerte bewertet werden können. Es werden Prototypen vollständig integrierter KI-Racksysteme entwickelt, einschließlich KI-Beschleunigern, Speichern mit hoher Bandbreite (HBM-Speichern), Leiterplatten, Netzwerken mit extrem niedriger Latenz und vollständigem Software-Stack, und für eine vergleichende Bewertung der vereinbarten Arbeitsbelastung bereitgestellt. Prototypen von Systemen auf Rack-Ebene werden in einer gemeinsamen EU-Testumgebung demonstriert. Die abschließenden Tests und Bewertungen sollen anhand klar definierter zentraler Leistungsindikatoren in gemeinsamen EU-Testumgebungen erfolgen, die von einer neutralen Einrichtung betrieben werden.

Dieses strategische Projekt soll die Abhängigkeit von Lieferanten aus Drittländern verringern und die technologische Souveränität entlang des gesamten KI-Stacks erhöhen. Es soll das EU-Ökosystem für den Entwurf, die Integration und Optimierung von Hochleistungs-KI-Systemen stärken, indem FuE-Tätigkeiten, Datenverarbeitung und Tests in der Union durchgeführt werden und dadurch Kompetenzen, Know-how und Lieferketten in Europa verankert werden. Die Einführung der KI-Systeme soll eine zusätzliche Nachfrage schaffen, um weitere Investitionen in die Fertigung in Europa zu rechtfertigen.

Als erster Schritt könnte eine informelle Aufforderung zur Interessenbekundung veröffentlicht werden. Im Anschluss an die Auswertung der eingegangenen Interessenbekundungen könnte eine Aufforderung zur Einreichung von Vorschlägen folgen.

3. Fahrzeug-Anwendungsprozessoren für autonomes Fahren

Die Automobilindustrie befindet sich derzeit in einem grundlegenden Wandel, der in erster Linie durch das Aufkommen elektrischer, vernetzter und autonomer Fahrzeuge vorangetrieben wird. Dieser Wandel erfordert eine stärker zentralisierte, integrierte und flexiblere elektrische/elektronische (E/E-)Architektur, um dem hohen Rechenbedarf autonomer Fahrsysteme gerecht zu werden, eine reibungslose Fahrzeugkonnektivität zu gewährleisten, das Energiemanagement von Elektrofahrzeugen zu unterstützen und neue Mobilitätsdienste zu ermöglichen. Derzeit sind die europäischen Originalgerätehersteller (OEMs) der Automobilindustrie hinsichtlich der Anwendungsprozessoren für das autonome Fahren auf außereuropäische Lieferanten angewiesen, wodurch Abhängigkeiten, potenziell ausnutzbare Schwachstellen sowie mögliche Sicherheitsrisiken entstehen.

Ziel dieses strategischen Projekts ist es, RISC-V-basierte Hochleistungs-Anwendungsprozessoren für Fahrzeuge zu entwerfen, zu entwickeln, als Prototypen zu erstellen und in die Produktion zu übergeben (Tape-out). Diese Prozessoren sollen fortgeschrittene Rechnerarchitektur-Techniken, Mehrkern-Konfigurationen und die Unterstützung von Speicherschnittstellen mit hoher Bandbreite umfassen, die den komplexen Rechenanforderungen der Systeme für autonomes Fahren gerecht werden. Darüber hinaus sollen KI- und ML-Beschleuniger mit speziellen Erweiterungen der Befehlssatzarchitektur (Instruction Set Architecture, ISA) für effiziente datenintensive Berechnungen entwickelt werden. Diese Beschleuniger werden für die Anwendung in Fahrzeugen optimiert und unterstützen fortgeschrittene KI-Modelle, deren Schwerpunkt auf Energieeffizienz, verringerter Latenz und Echtzeitverarbeitung liegt. Das Endergebnis soll dabei die Chip-Produktionsübergabe im industriellen Maßstab sein, wobei ein wettbewerbsfähiger RISC-V-Anwendungsprozessor zusammen mit Speicher, Beschleunigern und weiteren relevanten IP-Blöcken unter Nutzung fortschrittlicher Packaging-Technologien integriert wird. Die Hardwareentwicklung wird durch ein ausgereiftes Toolset unterstützt. Automobilhersteller sollen die Entwicklungsergebnisse in einer Betriebsumgebung als qualifizierte Geräte einsetzen können.

Das strategische Projekt soll dem Aspekt der technologischen Souveränität Europas in Bezug auf KI-Prozessoren und -Beschleuniger in der Automobilindustrie Rechnung tragen. Dadurch soll die Abhängigkeit europäischer Originalgerätehersteller der Automobilindustrie von ausländischen Lieferanten verringert werden. Die Einführung der Anwendungsprozessoren und Beschleuniger soll eine zusätzliche Nachfrage schaffen, um weitere Investitionen in die Fertigung in Europa zu rechtfertigen.

Als erster Schritt könnte eine informelle Aufforderung zur Interessenbekundung veröffentlicht werden. Im Anschluss an die Auswertung der eingegangenen Interessenbekundungen könnte eine Aufforderung zur Einreichung von Vorschlägen folgen.

4. Europäische Speicherchipfertigungsanlange

Speicherchips wie DRAM, NAND und neu entstehende nichtflüchtige Speicher sind wesentliche Komponenten, die in Rechenzentren, KI-Systemen, in Automobilelektronik, Telekommunikationsausrüstung, industrieller Automatisierung und Verteidigungsanwendungen benötigt werden. Derzeit konzentriert sich der globale Speichermarkt weitgehend auf Asien (Südkorea, Taiwan, China) sowie die Vereinigten Staaten. Der EU fehlen eigene Speicherfertigungskapazitäten, wodurch kritische europäische Lieferketten in hohem Maße anfällig für geopolitische Schocks, Handelskonflikte und Naturkatastrophen sind. Diese Abhängigkeit ist 2026 in kritischer Weise zutage getreten, da die steigende Nachfrage nach KI-fähigen Speicherchips mit hoher Bandbreite (High-bandwidth Memory, HBM) die Hersteller dazu veranlasst hat, Fertigungskapazitäten von Standard-DRAM und NAND umzuverteilen, was zu Preissteigerungen in einigen Marktsegmenten und infolge von Kontingentierungen zu gravierenden Lieferengpässen für die europäische Industrie geführt hat. Das Fehlen einer europäischen Speicherfertigungsanlage stellt daher eine strategische Schwachstelle für die digitale Souveränität, die wirtschaftliche Resilienz und die Verteidigungsbereitschaft der EU dar. Ein strategisches Projekt für eine europäische Speicherfertigungsanlage wäre nicht nur erforderlich, um die Versorgung wichtiger Industriezweige zu sichern, sondern auch, um fortgeschrittenes Fertigungs-Know-how in Europa zu verankern, Innovationen entlang der gesamten Halbleiterwertschöpfungskette zu fördern und die übergeordneten Ziele der EU in den Bereichen Industrie, Digitales und wirtschaftliche Sicherheit zu unterstützen.

Das strategische Projekt für den Aufbau europäischer Speicherfertigungsanlagen erfordert einen Konsortialansatz, bei dem öffentliche Mittel der EU und der teilnehmenden Mitgliedstaaten mit erheblichen privaten Investitionen kombiniert werden, die angesichts der Kapitalintensität moderner Speicherfertigungsanlagen zwischen 15 und 30 Mrd. EUR liegen dürften. Zur Schaffung einer differenzierten Marktposition könnte ein europäisch geführtes Gemeinschaftsunternehmen in Betracht gezogen werden, das sich beispielsweise auf eingebettete Speicher, Speicher mit niedrigem Stromverbrauch oder neu entstehende Speichertechnologien für KI- und Edge-Computing-Anwendungen konzentriert. Dabei könnte schrittweise vorgegangen werden, um die Risiken zu verringern und die erforderlichen Fähigkeiten schrittweise aufzubauen, etwa beginnend mit einer Pilot-/FuE-Anlage, gefolgt von einer Skalierung bis zur Produktion im großen Maßstab.

Eine Aufforderung zur Interessenbekundung könnte ausgearbeitet werden, um industrielle Partner, Technologieanbieter und an einer Aufnahme interessierte Mitgliedstaaten zu finden, die bereit sind, sich an dieser strategischen Initiative zu beteiligen.

5. Entwurf modernster Chips

Der Bau von Fertigungsanlagen ist zwar unerlässlich, ein erheblicher Teil des wirtschaftlichen Mehrwerts, der Gewinnmargen und der technologischen Kontrolle in der Halbleiterlieferkette entfällt jedoch auf Chipentwurf, Architektur und geistiges Eigentum. Europa verfügt über bedeutende Stärken in den Bereichen Forschung, Halbleiter für die Automobilindustrie und Halbleiterausrüstungen; beim Entwurf fortgeschrittenster Logikchips im großen Maßstab, insbesondere auf der Grundlage modernster Architekturen und Prozessknoten, ist es jedoch vergleichsweise schwach aufgestellt. Infolgedessen ist die EU bei fortgeschrittenen Rechen- und KI-Fähigkeiten in hohem Maße auf außereuropäische Unternehmen angewiesen. Ohne eigene Kapazitäten für einen hochmodernen Chipentwurf läuft Europa Gefahr, von ausländischen Architekturen abhängig zu bleiben, sodass kritische Infrastrukturen, der Verteidigungssektor und KI-bezogene Industriezweige weiterhin geopolitischen Beschränkungen, Lieferabhängigkeiten und Anbieterbindungen ausgesetzt sind. Eine Stärkung der Chipentwurfsfähigkeiten würde es der EU nicht nur ermöglichen, selbst einen größeren Anteil der Wertschöpfung innerhalb der Halbleiterwertschöpfungskette zu erzielen, sondern auch europäische Prioritäten wie Sicherheit, Datenschutz, Resilienz und Energieeffizienz unmittelbar in fortgeschrittene Hardware zu integrieren.

Mit einem strategischen Projekt für den Entwurf modernster Chips sollen souveräne Fähigkeiten von Weltrang innerhalb der EU für den Entwurf modernster Logikchips geschaffen werden. Der Schwerpunkt soll dabei mehr auf geistigem Eigentum, Architektur und Überprüfung als auf der eigentlichen Fertigung liegen. Zu den Schwerpunktbereichen könnten gehören:

- · Fortgeschrittene KI-Beschleuniger für Cloud-, Edge- und industrielle Anwendungen (auch für Geomodellierung und digitale Zwillinge)

- · Hochleistungsprozessoren für Hochleistungsrechnen und Rechenzentren

- · Konzeptionsintegrierte Sicherheit für Chips (Secure-by-design-Chips) in den Bereichen kritische Infrastrukturen, Verteidigung, Luftfahrt und Weltraum

- · Bereichsspezifische Prozessoren für autonome Fahrzeuge, Robotik und industrielle Automatisierung

- · Anwendungsspezifische integrierte Schaltungen (ASIC) und Ein-Chip-Systeme (SoC) für die 5G/6G-Telekommunikation

- · RISC-V-Prozessoren mit offener Architektur für Spitzenknoten

- · Fortgeschrittene Chiplet-Plattformen für die 2,5D/3D-Integration in Automobil-, Luftfahrt-, Weltraum- und Telekommunikationsanwendungen

Die Umsetzung kann in Form einer groß angelegten öffentlich-privaten Partnerschaft erfolgen, in deren Rahmen Mittel in Höhe von insgesamt 8 bis 12 Mrd. EUR von der EU, den Mitgliedstaaten und dem Privatsektor mobilisiert werden, die in Konsortien organisiert werden, deren Schwerpunkt auf Halbleiterherstellern ohne eigene Fertigungsanlagen liegt und an denen ASIC-Entwurfshäuser, Anbieter elektronischer Entwurfsautomatisierungswerkzeuge, Anbieter geistigen Eigentums, Forschungsinstitute und Endanwenderbranchen (Originalgerätehersteller der Automobil- und Luftfahrtindustrie, Telekommunikationsbetreiber und führende Verteidigungsunternehmen) beteiligt sind. Die Investitionen sollen Chip-Architektur- und -Entwurfsteams, fortgeschrittene Entwurfswerkzeuge und IP-Bibliotheken, Prototypentwicklung, Überprüfung, Software-Stacks und Industrialisierung abdecken. Das Projekt soll durch Partnerschaften mit führenden Fertigungsbetrieben oder europäischen Pilotanlagen (mindestens 2 nm-Technik) einen garantierten Zugang zur fortgeschrittenen Fertigung erhalten. Ein schrittweises Vorgehen könnte mit der Erfassung bestehender Fähigkeiten und der Auswahl von Zielanwendungen beginnen, gefolgt von Entwurfs- und Validierungsprogrammen, Pilot-Produktionsübergaben, Entwicklung von Ökosystemen und kommerzieller Einführung sowie gezielten Maßnahmen zur Ausbildung von Fachkräften und zur Gewinnung von erstklassigen Ingenieuren.

Im Rahmen einer Aufforderung zur Interessenbekundung könnten Industriekonsortien aufgefordert werden, Vorschläge für Projekte zum Entwurf modernster Chips mit klarer strategischer Bedeutung einzureichen, wobei die Antragsteller den Zielanwendungsbereich, die erwartete technologische Differenzierung, die erforderlichen Investitionen, den Zugang zu Entwurfs- und Fertigungsinfrastrukturen, den Zeitplan für Prototypenerstellung und Vermarktung sowie den Beitrag zur Resilienz und Wettbewerbsfähigkeit Europas darlegen sollten.

6. Stärkung zentraler Segmente der Wertschöpfungskette

Die Union hat eine Reihe von Schwachstellen entlang der Halbleiterwertschöpfungskette. Viele dieser Schwachstellen sind bereits bekannt, wie z. B. die oben bereits erwähnten, während andere weniger offensichtlich sind und/oder als weniger wichtig eingestuft werden. Letztere können jedoch infolge bestimmter Ereignisse zutage treten, wodurch ihre tatsächlichen Auswirkungen und die bestehenden Abhängigkeiten sichtbar werden, wie der Fall Nexperia gezeigt hat (siehe Arbeitsunterlage der Kommissionsdienststellen).

Es wird weder möglich noch zweckmäßig sein, sämtliche potenziellen Schwachstellen entlang der Halbleiterwertschöpfungskette Rechnung zu beheben. Die Union sollte jedoch die Möglichkeit haben, manche Schwachstellen zu verringern und zentrale Bereiche der Wertschöpfungskette zu stärken, insbesondere wenn Störungen bestehende Abhängigkeiten sichtbar gemacht haben oder das Risiko solcher Störungen fortbesteht.

Diese Art strategischer Projekte zielt darauf ab, einen bestimmten zentralen Bereich der Halbleiterwertschöpfungskette zu stärken. Solche Maßnahmen sind nicht auf die fortgeschrittensten Teile der Wertschöpfungskette beschränkt und können beispielsweise die Produktion von handelsüblichen Chips, Back-End-Prozesse, die Montage von Leiterplatten sowie Werkstoffe und Ausrüstungen betreffen. Ein Beispiel für ein mögliches strategisches Projekt könnte die Einrichtung einer OSAT^(7)-Anlage sein, die überwiegend den Bedarf europäischer Anwenderbranchen deckt. Ein weiteres Beispiel wäre der Aufbau einer Anlage für fortgeschrittenes Packaging, die (neue) Front-End-Fertigungsanlagen ergänzt. Die Hauptbeteiligten an strategischen Projekten sollen Unternehmen mit Sitz in der Union sein, und die wichtigsten Investitionen sollen in der Regel, wenn auch nicht zwingend, in der Union getätigt werden.

Gegenstand dieser Art strategischer Projekte sollen vermutete und nachgewiesene Schwachstellen entlang der Halbleiterwertschöpfungskette sein. Durch gezielte Maßnahmen zur Stärkung zentraler Segmente der Wertschöpfungskette sollen die technologische Souveränität Europas gestärkt und die Abhängigkeiten von außereuropäischen Akteuren verringert werden.

Der Europäische Halbleiterausschuss soll eine zentrale Rolle bei der Festlegung der Teile der Wertschöpfungskette spielen, die gestärkt werden müssen. Als nächster Schritt könnte eine informelle Aufforderung zur Interessenbekundung veröffentlicht werden. Im Anschluss an die Auswertung der eingegangenen Interessenbekundungen könnte eine Aufforderung zur Einreichung von Vorschlägen folgen.

<a id="annex-iii"></a>
## Anhang III – Messbare Indikatoren für die Überwachung der Durchführung und die Berichterstattung über die Fortschritte bei der Verwirklichung der Ziele dieser Verordnung

Die Kommission ist für die regelmäßige Überwachung der Durchführung dieser Verordnung verantwortlich und kann sich dabei womöglich auf externe Studien sowie auf Daten der Mitgliedstaaten und Marktdaten stützen. Die Kommission soll eine umfassende Bewertung der Wirksamkeit, Effizienz, Kohärenz, Verhältnismäßigkeit und Subsidiarität dieser Verordnung durchführen. Dem Europäischen Parlament, dem Rat, dem Europäischen Wirtschafts- und Sozialausschuss und dem Ausschuss der Regionen wird gemäß Artikel 60 dieser Verordnung ein Bewertungsbericht mit den wichtigsten Ergebnissen vorgelegt. Die Kommission kann diesem Bericht gegebenenfalls Vorschläge zur Verbesserung oder Anpassung der Verordnung beifügen.

Die Kommission wird in enger Zusammenarbeit mit den Mitgliedstaaten die Umsetzung und Anwendung der Rechtsvorschriften regelmäßig überwachen und dabei besonders auf die Wirksamkeit der erlassenen Maßnahmen achten. Die Überwachungstätigkeiten werden sich auf quantitative und qualitative Indikatoren auf der Grundlage von Daten stützen, die von Interessenträgern der gesamten Halbleiterwertschöpfungskette, den Mitgliedstaaten und den einschlägigen Einrichtungen der Union bereitgestellt werden.

Die messbaren Indikatoren bauen auf den beiden allgemeinen Zielen dieser Verordnung auf.

Allgemeine Überwachungsindikatoren:

- · Gesamte Zuflüsse ausländischer Direktinvestitionen (ADI) mit Halbleiterbezug in die Union,

- · Qualifizierte Arbeitskräfte im Halbleiter- und Photonikbereich, einschließlich der im Rahmen der Initiativen der nationalen Chip-Kompetenzzentren ausgebildeten oder umgeschulten Arbeitskräfte,

- · Öffentliche Unterstützung für Start-ups und Scale-ups und

- · Ausweitung der Finanzierung über privates Beteiligungskapital und Risikokapital.

Spezifische Überwachungsindikatoren:

Erste spezifische Überwachungsindikatoren für die Steigerung der Kapazität, Versorgungssicherheit und Wettbewerbsfähigkeit der Halbleiterindustrie der EU entlang der gesamten Wertschöpfungskette, einschließlich modernster KI-Chips:

- · Anteil der Union am globalen Halbleitermarktvolumen (in EUR) in den verschiedenen Bereichen der Wertschöpfungskette:

  - · Entwurf, geistiges Eigentum und EDA,

  - · Fertigung,

  - · Herstellung von Ausrüstungen,

  - · OSAT (Packaging),

  - · Werkstoffe/Gase,

- · Führende Unternehmen aus der Union in den einzelnen Bereichen der Wertschöpfungskette,

- · Installierte Waferherstellungskapazität in der Union (wpm).

Zweiter spezifischer Überwachungsindikator für die Entwicklung eines starken Anwendermarkts für alle wichtigen Industriezweige: Chipverbrauch nach Schlüsselsektoren (Automobilindustrie, Energie, Gesundheit, Verteidigung, Telekommunikation, KI/Rechenzentren/Cloud) (in EUR).

Dritter spezifischer Überwachungsindikator für den Ausbau der nachrichtendienstlichen Kapazitäten für die Krisenvorsorge und Krisenreaktion: Abdeckung (in %) der Halbleiterwertschöpfungskette der Union, die von der Unternehmensplattform für die Halbleiterlieferkette überwacht wird.

<a id="annex-iv"></a>
## Anhang IV – Synergien dieser Verordnung mit anderen Programmen

- (1) Synergien zwischen der Initiative „Chips für Europa 2.0“ und den spezifischen Zielen 1 bis 5 des Programms „Digitales Europa“ sollen sicherstellen, dass

  - a) der angestrebte thematische Schwerpunkt der Initiative „Chips für Europa 2.0“ auf Halbleiter- und Quantentechnologien komplementär ist;

  - b) die spezifischen Ziele 1 bis 5 des Programms „Digitales Europa“ den Aufbau digitaler Kapazitäten im Bereich fortschrittlicher digitaler Technologien, einschließlich Hochleistungsrechnen, künstlicher Intelligenz und Cybersicherheit unterstützen, und dass sie auch fortgeschrittene digitale Fertigkeiten unterstützen;

  - c) die Initiative „Chips für Europa 2.0“ in den Kapazitätsaufbau investieren wird, um fortschrittliches Entwurfs-, Produktions- und Systemintegrationsvermögen in Bezug auf hochmoderne Halbleitertechnologien, Halbleitertechnologien der nächsten Generation und Quantentechnologien der nächsten Generation für die innovative Unternehmensentwicklung zu stärken, damit die Halbleiterliefer- und -Wertschöpfungsketten in der Union verbessert, wichtige Industriesektoren unterstützt und neue Märkte geschaffen werden.

- (2) Synergien mit Horizont Europa müssen Folgendes sicherstellen:

  - a) Auch wenn sich bestimmte thematische Bereiche der Initiative „Chips für Europa 2.0“ und von Horizont Europa überschneiden, unterscheiden und ergänzen sich die Art der zu unterstützenden Maßnahmen, die jeweils erwarteten Ergebnisse sowie die jeweilige Interventionslogik;

  - b) Horizont Europa bietet umfangreiche Unterstützung für Forschung, technologische Entwicklung, Demonstrationsprojekte, Pilotprojekte, Konzeptnachweise, Tests und Prototypentwicklung, einschließlich der vorkommerziellen Einführung innovativer digitaler Technologien, insbesondere durch

    - i) ein eigenes Budget für den Cluster „Digitalisierung, Industrie und Weltraum“ im Rahmen der Säule „Globale Herausforderungen und industrielle Wettbewerbsfähigkeit Europas“ zur Entwicklung grundlegender Technologien (KI und Robotik, Internet der nächsten Generation, Hochleistungsrechnen und Big Data, digitale Schlüsseltechnologien (einschließlich Mikroelektronik), Kombination digitaler und anderer Technologien),

    - ii) die Förderung von Forschungsinfrastrukturen im Rahmen der Säule „Wissenschaftsexzellenz“,

    - iii) die Integration digitaler Technologien in allen „Globalen Herausforderungen“ (Gesundheit, Sicherheit, Energie und Mobilität, Klima usw.) und

    - iv) Unterstützung für bahnbrechende Innovationen durch Scale-ups (von denen viele digitale und andere Technologien kombinieren werden) im Rahmen der Säule „Innovatives Europa“.

  - c) die Initiative „Chips für Europa 2.0“ konzentriert sich ausschließlich auf den Aufbau großflächiger Kapazitäten im Bereich der Halbleiter- und Quantentechnologien in der gesamten Union. Sie wird in Folgendes investieren:

    - i) die Förderung von Innovation durch die Unterstützung zweier eng miteinander verknüpfter technologischer Kapazitäten, die den Entwurf neuartiger Systemkonzepte und deren Prüfung und Validierung in Pilotanlagen ermöglichen,

    - ii) die gezielte Unterstützung für den Aufbau von Schulungskapazitäten und die Verbesserung angewandter fortgeschrittener digitaler Kompetenzen und Fertigkeiten, um die Entwicklung und Einführung von Halbleitern durch technologische Entwicklung und Endanwenderbranchen zu unterstützen, und

    - iii) ein Netz nationaler Kompetenzzentren, die Expertise und Innovationsdienste für Endanwendergemeinschaften und -industrien bereitstellen und den Zugang dazu erleichtern, um neue Produkte und Anwendungen zu entwickeln und Marktversagen zu beheben.

  - d) die technologischen Kapazitäten der Initiative „Chips für Europa 2.0“ werden der Forschungs- und Innovationsgemeinschaft zur Verfügung gestellt werden, auch für Maßnahmen, die im Rahmen von Horizont Europa unterstützt werden;

  - e) sobald die im Rahmen von Horizont Europa entwickelten neuartigen digitalen Technologien im Halbleiterbereich zur Reife kommen, werden diese Technologien soweit möglich schrittweise mithilfe der Initiative „Chips für Europa 2.0“ aufgegriffen und eingeführt werden;

  - f) Die im Rahmen von Horizont Europa (Verordnung (EU) 2021/695) aufgestellten Programme zur Entwicklung von Lehrplänen für Fertigkeiten und Kompetenzen, darunter solche, die von den Kolokationszentren der Wissens- und Innovationsgemeinschaften des Europäischen Innovations- und Technologieinstituts durchgeführt werden, werden durch Kapazitätsaufbau in Bezug auf angewandte fortgeschrittene digitale Fertigkeiten im Bereich der Halbleiter- und Quantentechnologien ergänzt, die im Rahmen der Initiative „Chips für Europa 2.0“ unterstützt werden;

  - g) es werden starke Koordinierungsmechanismen für die Planung und Durchführung eingerichtet, sodass alle Verfahren für Horizont Europa wie für die Initiative „Chips für Europa 2.0“ so weit wie möglich aufeinander abgestimmt werden; alle betreffenden Kommissionsdienststellen werden in ihre Governance-Strukturen einbezogen sein.

- (3) Synergien mit der vorgeschlagenen Verordnung zur Cloud- und KI-Entwicklung (CADA) tragen zu einem kohärenten Ansatz zur Stärkung der technologischen Souveränität der Union bei, indem sowohl dem Angebot an als auch der Nachfrage nach fortgeschrittener Halbleitertechnik Rechnung getragen werden, insbesondere durch:

  - a) Nutzbarmachung der durch die Cloud- und KI-Entwicklung entstehenden Nachfrage nach Halbleitern: Mit dieser Verordnung wird die Fähigkeit der Union gestärkt, der durch den Ausbau der Cloud- und KI-Infrastrukturen, einschließlich Rechenzentren und großer Rechenanlagen, entstehenden Nachfrage nach hochleistungsfähigen und energieeffizienten Halbleitern gerecht zu werden;

  - b) Unterstützung der Einführung von KI-Fabriken und KI-Gigafabriken: Diese Verordnung fördert die Verfügbarkeit fortgeschrittener und spezialisierter Halbleiter, die für Hochleistungsrechnen und Anwendungen der künstlichen Intelligenz erforderlich sind, um so die Einführung und den Ausbau von KI-Fabriken und KI-Gigafabriken in der Union zu ermöglichen und zur Entwicklung von KI im industriellen Maßstab und zu wissenschaftlichen Fähigkeiten beizutragen;

  - c) Förderung sicherer und resilienter digitaler Infrastrukturen: Diese Verordnung soll dazu beitragen, die Verfügbarkeit der Komponenten sicherzustellen, die für die Entwicklung vertrauenswürdiger und souveräner Cloud- und KI-Umgebungen für kritische Anwendungsfälle erforderlich sind, und die Nutzung sicherer und zuverlässiger Hardwarekomponenten durch die Stärkung der Resilienz und Sicherheit der Halbleiterwertschöpfungsketten zu fördern;

  - d) Unterstützung des Aufbaus digitaler Infrastrukturen auf der Grundlage der technischen Fähigkeiten der Union sowie Verringerung externer Abhängigkeiten;

  - e) Beitrag zu den Nachhaltigkeitszielen für den Ausbau der digitalen Infrastruktur: Diese Verordnung unterstützt die Entwicklung und Herstellung ressourcen- und energieeffizienter Halbleiter, um dem zunehmenden Einsatz von Rechenzentren und Cloud-Infrastrukturen Rechnung zu tragen, der voraussichtlich zu einer steigenden Nachfrage nach energieeffizienten digitalen Technologien führen wird.

- (4) Synergien mit Unionsprogrammen mit geteilter Mittelverwaltung, einschließlich des Europäischen Fonds für regionale Entwicklung, des Europäischen Sozialfonds+, des Europäischen Landwirtschaftsfonds für die Entwicklung des ländlichen Raums und des Europäischen Meeres-, Fischerei- und Aquakulturfonds, gewährleisten die Entwicklung und Stärkung regionaler und lokaler Innovationsökosysteme, den industriellen Wandel sowie den digitalen Wandel der Gesellschaft und der öffentlichen Verwaltungen. Das umfasst die Unterstützung des digitalen Wandels der Industrie und der Verbreitung von Ergebnissen sowie die Einführung neuartiger Technologien und innovativer Lösungen. Die Initiative „Chips für Europa 2.0“ wird die transnationale Vernetzung und Kartierung von Kapazitäten ergänzen und unterstützen und sie KMU und Endanwenderbranchen in allen Regionen der Union zugänglich machen.

- (5) Synergien mit der Fazilität „Connecting Europe“ müssen Folgendes sicherstellen:

  - a) Der Schwerpunkt der Initiative „Chips für Europa 2.0“ liegt auf dem großflächigen Aufbau digitaler Kapazitäten und Infrastrukturen im Halbleiterbereich; sie zielt dabei auf eine breite unionsweite Aufnahme und Einführung entscheidender bestehender oder getesteter innovativer digitaler Lösungen innerhalb eines Unionsrahmens in Bereichen von öffentlichem Interesse oder von Marktversagen ab. Die Initiative „Chips für Europa 2.0“ soll hauptsächlich durch koordinierte und strategische Investitionen mit den Mitgliedstaaten in den Aufbau digitaler Kapazitäten für Halbleitertechnik, die unionsweit gemeinsam genutzt werden sollen, und in unionsweite Maßnahmen umgesetzt werden. Dies ist besonders wichtig für die Elektrifizierung und autonomes Fahren und zielt darauf ab, die Entwicklung wettbewerbsfähigerer Endanwenderbranchen, insbesondere in den Sektoren Mobilität und Verkehr, zu begünstigen und zu erleichtern;

  - b) die Kapazitäten und Infrastrukturen der Initiative „Chips für Europa 2.0“ sind für die Prüfung innovativer neuer Technologien und Lösungen zur Verfügung zu stellen, die in den Sektoren Mobilität und Verkehr genutzt werden können. Die Fazilität „Connecting Europe“ soll die Verbreitung und Einführung innovativer neuer Technologien und Lösungen im Bereich Mobilität und Verkehr sowie in anderen Bereichen unterstützen;

  - c) es sind Koordinierungsmechanismen zu schaffen, insbesondere durch geeignete Verwaltungsstrukturen.

- (6) Synergien mit dem Programm „InvestEU“ müssen Folgendes sicherstellen:

  - a) Im Rahmen der Verordnung (EU) 2021/523 ist eine Unterstützung durch marktgestützte Finanzierung vorgesehen, auch zur Verfolgung der politischen Ziele der Initiative „Chips für Europa 2.0“; eine solche marktgestützte Finanzierung könnte mit der Gewährung von Finanzhilfen kombiniert werden;

  - b) eine Mischfinanzierungsfazilität im Rahmen des Fonds „InvestEU“ wird durch Mittel aus dem Programm „Horizont Europa“ oder dem Programm „Digitales Europa“ in Form von Finanzierungsinstrumenten im Rahmen von Mischfinanzierungsmaßnahmen unterstützt.

- (7) Synergien mit Erasmus+ müssen Folgendes sicherstellen:

  - a) Die Initiative „Chips für Europa 2.0“ unterstützt die Entwicklung und den Erwerb fortgeschrittener digitaler Kompetenzen, die für die Entwicklung und Einführung hochmoderner Halbleitertechnik in Zusammenarbeit mit den einschlägigen Industrien erforderlich sind;

  - b) der den fortgeschrittenen Kompetenzen gewidmete Teil von Erasmus+ ergänzt die Interventionen im Rahmen der Initiative „Chips für Europa 2.0“, indem der Kompetenzerwerb in allen Bereichen und auf allen Ebenen durch Mobilitätserfahrungen bereichert wird.

- (8) Synergien mit anderen Programmen und Initiativen der Union zu Kompetenzen und Qualifikationen müssen sichergestellt werden.

- (9) Synergien mit den Rechtsvorschriften der Union zur Cybersicherheit müssen Folgendes sicherstellen:

  - a) Investitionen, die im Rahmen der Initiative „Chips für Europa 2.0“ unterstützt werden, tragen zur Stärkung der Sicherheit und Resilienz der Halbleiterlieferketten in der Union bei;

  - b) die Initiative „Chips für Europa 2.0“ ergänzt die Ziele der Cyberresilienzverordnung und der Cybersicherheitsverordnung, indem sie die Entwicklung und Einführung vertrauenswürdiger Halbleitertechnik fördert;

  - c) die Koordinierung mit der Umsetzung der Richtlinie (EU) 2022/2555 (Richtlinie über Netz- und Informationssicherheit, NIS2) wird gewährleistet, gegebenenfalls auch durch die Förderung vertrauenswürdiger Chips in kritischen Sektoren.

- (10) Synergien mit wichtigen Vorhaben von gemeinsamem europäischem Interesse (IPCEI) und den einschlägigen Rahmen für staatliche Beihilfen müssen Folgendes sicherstellen:

  - a) Die im Rahmen der Initiative „Chips für Europa 2.0“ unterstützten Maßnahmen stehen weiterhin im Einklang mit den bestehenden Beihilfe- und Wettbewerbsvorschriften, einschließlich des FEI-Rahmens und der IPCEI-Mitteilung;

  - b) IPCEIs, einschließlich des IPCEI-Kandidaten für fortgeschrittene Halbleitertechnik (Advanced Semiconductor Technologies, AST), können dazu beitragen, Forschungs- und Innovationstätigkeiten mit der industriellen Einführung und Herstellungskapazitäten zu verbinden und so die Verfolgung der Ziele der Initiative „Chips für Europa 2.0“ zu ergänzen;

  - c) mit der Initiative „Chips für Europa 2.0“ werden Lücken hinsichtlich ergänzender Investitionen zur Unterstützung neuartiger Halbleiterfertigungsanlagen und damit verbundener technischer Kapazitäten geschlossen.

- (11) Synergien mit den nationalen Strategien, Fahrplänen und Investitionsplänen im Halbleiterbereich müssen Folgendes sicherstellen:

  - a) Die nationalen Strategien und Investitionspläne der Mitgliedstaaten im Halbleiterbereich sind auf die Ziele der Initiative „Chips für Europa 2.0“ abgestimmt;

  - b) nationale Investitionen und Investitionen der Union tragen zur Stärkung regionaler und grenzüberschreitender Halbleiterökosysteme in der gesamten Union bei;

  - c) Koordinierungsmechanismen unterstützen die Erfassung der Halbleiterkapazitäten und erleichtern die Zusammenarbeit zwischen den Mitgliedstaaten, um die Resilienz der Halbleiterwertschöpfungsketten der Union zu stärken und unnötige Doppelinvestitionen zu vermeiden.

<a id="annex-v"></a>
## Anhang V – Kritische Sektoren

- (1) Energie

- (2) Verkehr

- (3) Banken

- (4) Finanzmarktinfrastruktur

- (5) Gesundheit

- (6) Trinkwasser

- (7) Abwasser

- (8) Digitale Infrastruktur

- (9) Öffentliche Verwaltung

- (10) Weltraum

- (11) Produktion, Verarbeitung und Vertrieb von Lebensmitteln

- (12) Verteidigung

- (13) Sicherheit

<a id="annex-vi"></a>
## Anhang VI – Industriezweige, in denen Halbleiter verwendet werden

- (1) Automobilindustrie

- (2) Rechenzentren, Cloud und KI

- (3) Industrielle Automatisierung und Robotik

- (4) Luftfahrt

- (5) Weltraum, Verteidigung und Sicherheit

- (6) Infrastrukturen für die elektronische Kommunikation

- (7) Rechner in anspruchsvollen Industrieumgebungen und Internet der Dinge

- (8) Gesundheitswesen und medizinische Geräte

- (9) Anbieter von Fertigungsdienstleistungen im Elektronikbereich und Händler

- (10) Systeme für erneuerbare und CO₂-arme Energie

<a id="annex-vii"></a>
## Anhang VII – Entsprechungstabelle

| Verordnung (EU) 2023/1781 | Vorliegende Verordnung |
| --- | --- |
| Artikel 1 | Artikel 1 |
| Artikel 2 | Artikel 2 |
| Artikel 3 | Artikel 3 |
| Artikel 4 | Artikel 4 |
| Artikel 5 | Artikel 5 |
| Artikel 6 | Artikel 11 |
| Artikel 7 | – |
| Artikel 8 | – |
| Artikel 9 | – |
| Artikel 10 | – |
| Artikel 11 | Artikel 6 |
| Artikel 12 | Artikel 12 |
| Artikel 13 bis 14 | Artikel 14 |
| Artikel 15 | Artikel 15 |
| Artikel 16 | Artikel 13 |
| Artikel 17 | – |
| Artikel 18 | Artikel 21 |
| Artikel 19 | Artikel 33 |
| Artikel 20 | Artikel 35 |
| Artikel 21 | Artikel 36 |
| Artikel 22 | Artikel 37 |
| Artikel 23 | Artikel 39 |
| Artikel 24 | Artikel 40 |
| Artikel 25 | Artikel 41 |
| Artikel 26 | Artikel 42 |
| Artikel 27 | Artikel 43 |
| Artikel 28 | Artikel 44 |
| Artikel 29 | Artikel 45 |
| Artikel 30 | Artikel 46 |
| Artikel 31 | Artikel 48 |
| Artikel 32 | Artikel 50 |
| Artikel 33 | Artikel 51 |
| Artikel 34 | Artikel 52 |
| Artikel 35 | Artikel 53 |
| Artikel 36 | Artikel 54 |
| Artikel 37 | Artikel 55 |
| Artikel 38 | Artikel 56 |
| Artikel 39 | – |
| Artikel 40 | Artikel 57 |
| Artikel 41 | Artikel 60 |

^(1) Das Plattformkoordinierungsteam (Platform Coordination Team) übernimmt die Rolle als Aufnahmeeinrichtung für die virtuelle Infrastruktur und die zentralen Dienste der Entwurfsplattform, es koordiniert den Zugang zu einem breiten Spektrum von Instrumenten, Ressourcen und Diensten und unterstützt das Gemeinsame Unternehmen für Chips (GU Chips) bei der Beschaffung der Cloud-Plattform.

^(2) Entwurfsbegleitungsteams (Design Enablement Teams) unterstützen die Anwender bei der Einrichtung und Anpassung von Entwurfsumgebungen und -abläufen sowie beim Einsatz von Werkzeugen der elektronischen Entwurfsautomatisierung (EDA-Werkzeugen) in der Cloud.

^(3) Siehe Artikel 4 der Verordnung zur Cloud- und KI-Entwicklung.

^(4) Siehe Artikel 5 der Verordnung zur Cloud- und KI-Entwicklung.

^(5) Mitteilung der Kommission an das Europäische Parlament, den Rat, den europäischen Wirtschafts- und Sozialausschuss und den Ausschuss und den Ausschuss der Regionen „EU-Initiative für das Web 4.0 und virtuelle Welten: mit Vorsprung in den nächsten technologischen Wandel“, COM(2023) 442 final vom 11. Juli 2023.

^(6) In diesem Abschnitt wird eine mögliche Anwendung Artikels 19 weiter ausgeführt.

^(7) Bei OSAT-Unternehmen (Outsourced Semiconductor Assembly and Test, d. h. Auslagerung der Halbleitermontage und -prüfung) sind spezialisierte externe Dienstleister, die die abschließenden, für die Chipherstellung entscheidenden Arbeitsschritte übernehmen, d. h. auf das Packaging von Halbleiterchips und auf das Testen ihrer Funktionalität vor der Auslieferung an die Kunden.
