---
act: cloud-ai-development-act
version: 2026-06-03_com-proposal
stage: com-proposal
language: de
celex: 52026PC0502
title: Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Cloud- und KI-Ökosystems (Verordnung zur Cloud- und KI-Entwicklung)
retrieved: '2026-09-24'
converter: tools/eurlex2md.py
counts:
  recitals: 91
  articles: 47
  annexes: 3
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52026PC0502
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Cloud- und KI-Ökosystems (Verordnung zur Cloud- und KI-Entwicklung)

<a id="begr-ndung"></a>
## BEGRÜNDUNG

### 1. KONTEXT DES VORSCHLAGS

#### • Gründe und Ziele des Vorschlags

In den letzten Jahren haben sich Cloud- und KI-Technologien, -Dienste und -Anwendungen von neuen Konzepten zu unverzichtbaren Eckpfeilern entwickelt, die das Funktionieren unserer Wirtschaft und Gesellschaft untermauern. KI eröffnet beispiellose Möglichkeiten, die von der Automatisierung und datengesteuerten Entscheidungsfindung bis hin zu personalisierten Dienstleistungen reichen, während das Cloud-Computing die Rechenressourcen, Softwarebausteine und Schnittstellen bereitstellt, die für eine effiziente Entwicklung und Einführung von KI erforderlich sind. Die rasche Verbreitung von KI hat zu einer beispiellosen und weiter wachsenden Nachfrage nach Rechenfähigkeiten geführt. Folglich sind Recheninfrastrukturen keine bloßen technischen Anlagen mehr, sondern sie sind zu strategischen Ressourcen geworden, die für die wirtschaftliche Sicherheit, Souveränität, Resilienz und Wettbewerbsfähigkeit der Union von entscheidender Bedeutung sind.

Wie Mario Draghi in seinem Bericht über die Zukunft der europäischen Wettbewerbsfähigkeit festgestellt hat, muss sich die EU auf jenen Gebieten behaupten, auf denen es auf technologische Souveränität ankommt, wie z. B. Sicherheit und Verschlüsselung („souveräne Cloud“-Lösungen), und auf diese Weise kritische externe Abhängigkeiten verringern, indem sie die eigenen heimischen Cloud- und KI-Kapazitäten und -Infrastrukturen stärkt. Zu diesem Zweck wird die Europäische Kommission im Draghi-Bericht aufgefordert, gezielte Maßnahmen zu ergreifen, um die Kontrolle über Datenverarbeitungs- und Cloud-Computing-Dienste zurückzugewinnen und zu behalten, die einheimischen Rechenkapazitäten zu erhöhen und eine schwungvolle Finanz- und Talentdynamik anzustoßen, um Innovationen voranzutreiben.

Diese Ziele wurden später im Aktionsplan für den europäischen KI-Kontinent festgeschrieben, der einen strategischen Fahrplan zur Sicherung einer Führungsrolle Europas im Bereich der KI enthielt. Erreicht werden kann dies nur durch die Verknüpfung der folgenden fünf Schlüsselbereiche: Recheninfrastrukturen, Daten, Kompetenzen, Entwicklung und Einsatz von KI-Algorithmen und Vereinfachung der Rechtsvorschriften. Der laufende Aufbau von KI-Fabriken und KI-Gigafabriken zielt darauf ab, europäischen Unternehmen und europäischen Forschenden, die KI-Fähigkeiten benötigen, einen breiten Zugang zu Hochleistungsrechenressourcen der nächsten Generation zu ermöglichen. Ergänzend dazu muss die EU ihre Cloud- und Rechenzentrumskapazitäten ausweiten, um die breitere Einführung und Verbreitung von KI zu unterstützen.

Die begrenzten Kapazitäten der Rechenzentren in der Union erschweren es der Union erheblich, vom digitalen Wandel zu profitieren und KI-gestützte Lösungen einzuführen, insbesondere solche, die Rechenkapazitäten mit geringer Latenz erfordern. Die rasche Errichtung von Rechenzentren in der EU wird konkret durch mehrere Hindernisse ausgebremst. Angesichts dessen, dass der Bedarf an Datenspeicherung und Datenverarbeitung – insbesondere infolge des Anstiegs der KI-Rechenlasten – weiter zunimmt, sehen sich europäische Unternehmen mangels verfügbarer Rechenzentrumskapazitäten in der EU heute dazu gezwungen, kritische Arbeitslasten über Infrastrukturen ausländischer Hyperscaler zu lenken. Dies macht die EU zu einem weniger attraktiven Ziel für Technologieinvestitionen als andere Regionen mit reichlich vorhandenen und kostengünstigeren Rechenressourcen.

Die derzeitige Cloud- und KI-Landschaft wird durch eine ausgeprägte Abhängigkeit von einem begrenzten Pool von Anbietern aus Drittländern geprägt. Während der EU-Markt für Cloud-Computing-Dienste weiter erheblich wächst, ist der Marktanteil der EU-Anbieter von 29 % im Jahr 2017 auf 15 % im Jahr 2022 zurückgegangen und stagniert seitdem.

Derzeit kontrollieren drei außereuropäische Hyperscaler mehr als 70 % des europäischen Cloud-Marktes. Große etablierte Marktteilnehmer unterliegen den Rechtsordnungen von Drittländern, in denen Gesetze mit extraterritorialer Wirkung gelten, darunter Vorschriften über Datenzugriff und Datenübermittlung, die im Widerspruch zu den Grundrechten und dem Datenschutzrahmen der EU stehen können. Diese Abhängigkeit birgt auch Risiken für die europäischen Nutzer im Hinblick auf Betriebsstörungen, insbesondere wenn die Erbringung der Dienste durch einseitige Entscheidungen von Akteuren aus Drittländern beeinträchtigt werden könnte.

Vor diesem Hintergrund hat Europa zwar Forschungs- und Entwicklungskapazitäten von Weltrang, dynamische Open-Source-Gemeinschaften und eine starke industrielle Basis in den Bereichen Cloud und KI, dieses vorhandene Potenzial bleibt aber weitgehend unerschlossen.

Deshalb hat die Kommission den Vorschlag für eine Verordnung zur Cloud- und KI-Entwicklung (im Folgenden „Vorschlag“) ausgearbeitet, mit dem die begrenzte und geografisch konzentrierte Verfügbarkeit von Rechenkapazitäten in der EU und die Risiken im Zusammenhang mit der Abhängigkeit von Cloud- und KI-Diensten außereuropäischer Anbieter angegangen werden sollen. Mit dem Vorschlag wird Folgendes angestrebt:

- 1. Steigerung der Rechenkapazitäten und der in der EU entwickelten und eingeführten KI durch innovative und nachhaltige Cloud- und KI-Technik,

- 2. Gewährleistung attraktiver Bedingungen für den unionsweiten Aufbau nachhaltiger und innovativer Rechenkapazitäten,

- 3. Ausräumung von Bedenken hinsichtlich der Datensouveränität und der Betriebskontinuität bei Cloud- und KI-Diensten,

- 4. Beitrag zum Schutz der öffentlichen Ordnung durch eine resilientere Bereitstellung von Cloud-Computing-Diensten, insbesondere im öffentlichen Sektor.

Der Vorschlag trägt der Notwendigkeit eines koordinierten „Ökosystemansatzes“ Rechnung, um die EU im Cloud- und KI-Bereich wettbewerbsfähiger und resilienter zu machen. Er kombiniert angebotsseitige Maßnahmen zur Stärkung der heimischen Fähigkeiten, nachfrageseitige Maßnahmen zur Förderung der Einführung und grundlegende Voraussetzungen zur Förderung von Innovationen und Investitionen im Cloud- und KI-Bereich. Ein besonderer Schwerpunkt liegt auf Quelloffenheit als Hebel zur Stärkung der technologischen Souveränität im Einklang mit der Open-Source-Strategie der EU, mit der offene europäische Alternativen im gesamten europäischen Technologie-Stack gefördert werden sollen.

Erstens werden mit dem Vorschlag Projekte unterstützt, die aus den in diesem Rahmen eingeleiteten und gemeinsam mit den Mitgliedstaaten durchgeführten Forschungs- und Innovationsinitiativen hervorgehen. Diese Initiative wird Netze, Cloud, KI und Software in kohärente Ökosysteme integrieren, um Folgendes anzugehen:

- 1. künftige Herausforderungen im Zusammenhang mit energieeffizienten Recheninfrastrukturen,

- 2. Autonomie im gesamten Cloud-Computing-Stack,

- 3. fortgeschrittene Fähigkeiten der EU im Bereich der fortgeschrittenen KI-Technologien wie Grenz-KI, physische KI und industrielle KI,

- 4. Übernahme von Cloud und KI im öffentlichen und privaten Sektor.

Ein besonderer Schwerpunkt des Vorschlags liegt auf groß angelegten sektorenübergreifenden Initiativen zur Bewältigung der strategisch wichtigsten technologischen und industriellen Herausforderungen (im Folgenden „Große Herausforderungen“). Damit wird die Durchführbarkeit dieser Bemühungen demonstriert und der Weg für ähnliche künftige Initiativen geebnet, um die Voraussetzungen für Investitionen in Infrastrukturen und Technologien der nächsten Generation zu schaffen.

Zweitens wirkt der Vorschlag der wachsenden Lücke bei den Rechenzentrumskapazitäten entgegen, indem ein Rahmen geschaffen wird, der die Errichtung von Rechenzentren EU-weit vereinfacht und harmonisiert und gleichzeitig ihre Nachhaltigkeit gewährleistet. Ziel ist es, die EU-Kapazitäten in den nächsten fünf bis sieben Jahren zu verdreifachen und so bis 2035 das benötigte Kapazitätsniveau zu erreichen und gleichzeitig für eine ausgewogene geografische Verteilung auf alle Mitgliedstaaten zu sorgen. Dazu sieht der Vorschlag einen Mechanismus zur Ermittlung und Unterstützung strategischer Rechenzentrumsprojekte für vor, die eine beträchtliche Innovation und Nachhaltigkeit bieten oder zu einer ausgewogenen Verteilung der Rechenkapazitäten beitragen.

Drittens sollen mit dem Vorschlag die Risiken gemindert werden, die sich aus der Abhängigkeit der EU von Drittländern bei Cloud-Computing-Diensten ergeben, und zwar durch einen einheitlichen EU-weiten Souveränitätsrahmen. Dazu sieht er harmonisierte und überprüfbare Kriterien für verschiedene Souveränitätsniveaus von Cloud-Computing-Diensten vor. Außerdem enthält er einen Rahmen für die Bewertung und förmliche Anerkennung von Diensten auf einem bestimmten Souveränitätsniveau. Schließlich werden darin die Mitgliedstaaten dazu verpflichtet, Souveränitätsrisikobewertungen durchzuführen, um zu bestimmen, welchen Souveränitätsniveaus die Dienste, die bestimmte Teilsektoren und Anwendungsfälle bedienen, entsprechen sollten, um in Bezug auf die Vertraulichkeit der Daten und die Betriebsautonomie einen angemessenen Schutz zu gewährleisten und Schäden zu verhindern, die die öffentliche Ordnung untergraben könnten.

Ergänzend zur Überarbeitung der Cybersicherheitsverordnung (CSA2), mit der Risiken in der Lieferkette angegangen werden, stellt dieser Vorschlag sicher, dass öffentliche Auftraggeber souveräne Cloud-Computing-Dienste nutzen können. Zusammen schließen dieser Vorschlag und die CSA2 seit Langem bestehende Lücken im Hinblick auf die Souveränität und nicht technische Risiken. Gleichzeitig müssen Cloud-Computing-Dienste in Europa hohen Cybersicherheitsstandards entsprechen, was einen soliden Cybersicherheitsrahmen erfordert, der eine umfassende Antwort auf die heutigen geopolitischen Sicherheitsherausforderungen darstellt. In diesem gesetzgeberischen Kontext werden auch die Arbeiten am europäischen System für die Cybersicherheitszertifizierung von Cloud-Diensten (EUCS) wieder aufgenommen.

Schließlich bietet der Vorschlag öffentlichen Auftraggebern einen Rahmen, damit sie fundierte Vergabeentscheidungen treffen und ihre Kaufkraft als Hebel zur Verringerung bestehender Abhängigkeiten einsetzen können, unter anderem durch die Anwendung sektorspezifischer Zuschlagskriterien, die einen Mehrwert für die EU erbringen, und durch eine gemeinsame Auftragsvergabe zur Förderung von Innovation und Wachstum, wobei der Schwerpunkt auf der Schaffung konkreter Möglichkeiten für kleinere Anbieter mit Sitz in der EU liegt.

Zusammengenommen schaffen die in diesem Vorschlag enthaltenen Maßnahmen die Grundlagen für ein resilientes und leistungsstarkes Cloud- und KI-Ökosystem in der EU. Sie positionieren Europa nicht nur als Verbraucher fortgeschrittener digitaler Technologien, sondern als globale Drehscheibe für vertrauenswürdige, souveräne und skalierbare digitale Infrastrukturen, die Europa in die Lage versetzen, die Standards, Fähigkeiten und Märkte der nächsten Technologiewelle zu gestalten.

#### • Kohärenz mit den bestehenden Vorschriften in diesem Bereich

Der Vorschlag steht im Einklang mit den Vorschriften über den Anbieterwechsel zwischen Datenverarbeitungsdiensten, die mit der Datenverordnung eingeführt wurden. Durch die Ermöglichung des Anbieterwechsels und die Beseitigung wichtiger Ursachen der Anbieterbindung soll die Datenverordnung sicherstellen, dass Anbieter von Cloud-Computing-Diensten in der EU in Bezug auf Qualität, Innovation und Preise miteinander im Wettbewerb stehen. Sie soll es Cloud-Nutzern ermöglichen, den ihren Bedürfnissen am besten entsprechenden Anbieter frei zu wählen und Angebote verschiedener Anbieter im Rahmen eines Multi-Cloud-Ansatzes miteinander zu kombinieren.

Die Datenverordnung enthält jedoch keine Elemente zur Gestaltung eines wettbewerbsfähigeren Angebots an europäischen Cloud-Computing-Diensten oder zur Förderung des Markteintritts vielfältigerer Anbieter von Cloud-Computing-Diensten.

Die Datenverordnung ebnet zwar den Weg für eine mögliche Verringerung der Abhängigkeiten von außereuropäischen Anbietern, sie eröffnet aber keinen Entwicklungspfad hin zu einem souveräneren und vertrauenswürdigeren EU-Cloud-Computing-Sektor. Ihre Bestimmungen über den Cloud-Wechsel und die Interoperabilität ermöglichen es den Nutzern jedoch, verstärkt europäische Cloud-Computing-Dienste zu verwenden. Die Datenverordnung ist daher eine Voraussetzung für den Vorschlag.

Der Vorschlag steht auch im Einklang mit dem Gesetz über digitale Märkte (DMA). Das Gesetz über digitale Märkte erfasst Cloud-Computing-Dienste als zentrale Plattformdienste, was bedeutet, dass Anbieter von Cloud-Computing-Diensten, die als Torwächter benannt werden, eine Reihe von Verpflichtungen erfüllen müssten, um die Fairness und Bestreitbarkeit der Märkte zu erhöhen. Bislang wurde kein Anbieter von Cloud-Computing-Diensten für seine Dienste als Torwächter benannt. Am 18. November 2025 leitete die Kommission jedoch im Rahmen des Gesetzes über digitale Märkte drei Marktuntersuchungen zu Cloud-Computing-Diensten ein. In zwei dieser Marktuntersuchungen wird geprüft, ob zwei Anbieter als Torwächter für ihre Cloud-Computing-Dienste benannt werden sollten (d. h. ob sie als wichtige Zugangstore zwischen gewerblichen Nutzern und Endnutzern fungieren). Im Rahmen der dritten Marktuntersuchung wird geprüft, ob mit dem Gesetz über digitale Märkte wirksam gegen Praktiken vorgegangen werden kann, die die Wettbewerbsfähigkeit und Fairness im Cloud-Computing-Sektor in der EU einschränken könnten.

Bestimmte Anbieter von Cloud-Computing-Diensten könnten zwar sowohl im Rahmen dieses Vorschlags als auch im Rahmen des Gesetzes über digitale Märkte reguliert werden, das Gesetz über digitale Märkte hat aber andere Ziele und enthält keine Maßnahmen, die geeignet wären, die Einführung souveräner Cloud-Computing-Dienste aktiv zu fördern. Das Gesetz über digitale Märkte soll lediglich einen fairen und bestreitbaren Cloud-Markt in der Union aufrechterhalten und fördern, indem es bestimmte Verhaltensweisen der als Torwächter benannten Unternehmen reguliert, und greift somit auf einer anderen Ebene ein als dieser Vorschlag, der vor allem die Einführung und Nutzung der erbrachten Dienste betrifft.

Mit dem Vorschlag werden auch die wichtigsten Ziele der KI-Verordnung bekräftigt. Die KI-Verordnung harmonisiert die Vorschriften für KI-Systeme und KI-Modelle mit allgemeinem Verwendungszweck, die in der EU in Verkehr gebracht werden sollen, wodurch das Funktionieren des Binnenmarkts verbessert und die Einführung einer auf den Menschen ausgerichteten und vertrauenswürdigen KI entlang der Wertschöpfungskette gefördert wird. Die KI-Verordnung gewährleistet ein hohes Schutzniveau im Hinblick auf die Gesundheit, die Sicherheit und die Grundrechte. Sie erstreckt sich aber nicht auf Aspekte der Souveränität.

Der Vorschlag ergänzt den umfassenderen Rahmen der EU für die Digitalpolitik, zu dem die Open-Source-Strategie der EU, das Politikprogramm für die digitale Dekade und die Strategie „KI anwenden“ gehören.

In der Open-Source-Strategie der EU wird vorgeschlagen, Quelloffenheit für die Zwecke der Souveränität, Wettbewerbsfähigkeit und Sicherheit durch eine Reihe gezielter Maßnahmen zu fördern, von denen einige in der Verordnung zur Cloud- und KI-Entwicklung vorgesehen werden.

Das Politikprogramm für die digitale Dekade hat vier Kernpunkte, unter die seine Ziele jeweils fallen, nämlich i) eine digital befähigte Bevölkerung und hoch qualifizierte digitale Fachkräfte, ii) sichere und nachhaltige digitale Infrastrukturen, iii) digitaler Umbau der Unternehmen und iv) Digitalisierung öffentlicher Dienste. Konkret enthält das Politikprogramm für die digitale Dekade ein Ziel für die Überwachung der Errichtung von Randknoten, sieht aber weder ein Ziel für die Messung der Fortschritte beim Aufbau von Rechenkapazitäten oder Rechenzentren in der EU noch konkrete Unterstützungsmaßnahmen für deren Einrichtung vor. Dieser Vorschlag ergänzt das Politikprogramm für die digitale Dekade, indem er die bestehende jährliche Überwachung nutzbar macht und so Synergien mit dem bestehenden Rahmen schafft. Er trägt auch dazu bei, alle vier Kernpunkte des Politikprogramms für die digitale Dekade voranzubringen, und zwar vor allem durch die Festlegung konkreter Maßnahmen, die auf die Entwicklung innovativer KI-gestützter Technologien, den Einsatz erweiterter Rechenkapazitäten und die Schaffung eines Vertrauensrahmens für eine verstärkte Nutzung von Cloud und KI ausgerichtet sind.

Darüber hinaus enthält die Strategie „KI anwenden“ konkrete Maßnahmen zur Nutzung des transformativen Potenzials der KI, wobei der Schwerpunkt auf der Förderung der raschen Einführung in wichtigen Wirtschaftszweigen und im öffentlichen Sektor liegt. Außerdem werden damit Unterstützungsmaßnahmen zur Stärkung der technologischen Souveränität der EU eingeführt, mit denen bereichsübergreifende Herausforderungen bei der Entwicklung und Einführung von KI angegangen werden. Der Vorschlag untermauert diese Ziele und trägt zu ihrer Umsetzung bei, indem gezielte Maßnahmen eingeführt werden, die darauf abzielen, die Entwicklung und Einführung von Cloud- und KI-Diensten zu unterstützen, den Zugang zu Rechenkapazitäten zu steigern und Vertrauen in Cloud-Computing-Dienste aufzubauen.

Der Vorschlag steht voll und ganz im Einklang mit der Mitteilung über eine internationale Digitalstrategie für die EU vom Juni 2025. Er schafft einen transparenten, diskriminierungsfreien Konzeptentwurf für die digitale Autonomie, der es der EU ermöglicht, resiliente, souveräne Technologieinfrastrukturen in der Union aufzubauen und gleichzeitig ein vertrauenswürdiges, rechtlich fundiertes Modell für internationale Partnerschaften und eine multilaterale Governance im Ausland zu haben. Er steht voll und ganz im Einklang mit den internationalen Verpflichtungen und Partnerschaften der Union und wird den Zugang zum Binnenmarkt für Einrichtungen aus Partnerländern gewährleisten, die die erforderliche Unionsvertrauenswürdigkeitsstufe erreichen.

#### • Kohärenz mit der Politik der Union in anderen Bereichen

Der Vorschlag ergänzt den umfassenderen politischen Rahmen der EU für Cybersicherheit und digitale Resilienz.

Dieser Vorschlag ist in Verbindung mit dem Vorschlag für die Überarbeitung des bisherigen Chip-Gesetzes zu betrachten, der seinerseits Maßnahmen zur Förderung von Investitionen in fortgeschrittene Halbleiter, zur Erhöhung der Resilienz der Lieferketten und zur Steigerung der Nachfrage durch eine verstärkte Zusammenarbeit zwischen der Halbleiterlieferkette und den Endmärkten vorsieht.

Mit der Richtlinie über die Sicherheit von Netz- und Informationssystemen (NIS2) wird das Cybersicherheitsrisikomanagement der Anbieter von Cloud-Computing-Diensten und Rechenzentren in der EU verbessert, was zu mehr Vertrauen führt. Sie enthält jedoch keine Maßnahmen zur Förderung der Übernahme und Verwendung solcher Dienste und betrifft ausschließlich die technische Cybersicherheit im Gegensatz zu umfassenderen Souveränitätserwägungen.

Wie bereits dargelegt, ergänzt der Vorschlag den Schwerpunkt der Cybersicherheitsverordnung, der auf der Cybersicherheit in der Cloud liegt, durch Souveränitätserwägungen. Mit der Zertifizierung im Rahmen der Cybersicherheitsverordnung können zwar technische Cybersicherheitskriterien bestimmt werden, sie ist jedoch nicht geeignet, um Souveränitätsbedenken auszuräumen, die über solche technischen Aspekte hinausgehen. Die Agentur der Europäischen Union für Cybersicherheit (ENISA) hat in der Zwischenzeit weiter an der Entwicklung eines europäischen Systems für die Cybersicherheitszertifizierung von Cloud-Diensten (EUCS) gearbeitet, das aber noch nicht angenommen wurde. Sobald es fertiggestellt ist, könnte es auch im Rahmen für souveräne Cloud-Computing-Dienste Verwendung finden, um sicherzustellen, dass ein geprüfter Dienst den höchsten Cybersicherheitsstandards entspricht. Darüber hinaus wird durch die vorgeschlagene Überarbeitung des bisherigen Rechtsakts zur Cybersicherheit die Vertrauenswürdigkeit der IKT-Lieferkette für Hardware und Software gestärkt.

Der Vorschlag unterstützt auch die Ziele der Verordnung über die digitale operationale Resilienz im Finanzsektor (DORA). In der DORA-Verordnung werden Einhaltungspflichten für Anbieter von Cloud-Computing-Diensten festgelegt. Sie gilt indirekt auch für Anbieter von Cloud-Computing-Diensten, wenn diese Dienstleistungen für bestimmte Finanzunternehmen erbringen oder eine hinreichend wichtige Rolle im Hinblick auf die Betriebsstabilität spielen. Sie hat einen sektoralen Anwendungsbereich und gilt spezifisch für den Finanzsektor. Nach der DORA-Verordnung müssen Anbieter von Cloud-Computing-Diensten ein IKT-Risikomanagement einführen und regelmäßige Tests ihrer Reaktion auf Sicherheitsvorfälle durchführen, um den Anforderungen an kritische Drittdienstleister nachzukommen. Die betreffenden Finanzinstitute, die öffentlicher Natur sein könnten, müssen beim Umgang mit den Anbietern von Cloud-Computing-Diensten, mit denen sie zusammenarbeiten, gewisse Sorgfaltspflichten erfüllen.

Der Vorschlag unterstützt auch die Ziele der Strategie für eine Union der Krisenvorsorge, in der die Abhängigkeit von kritischen digitalen Infrastrukturen als ein systemisches Risiko eingestuft und ein ressortübergreifender Ansatz gefordert wird, um im Krisenfall die Kontinuität wesentlicher Dienste aufrecht zu erhalten. Der mit dieser Verordnung geschaffene Souveränitätsrahmen und insbesondere der Risikobewertungsmechanismus gemäß Artikel 29 tragen unmittelbar zum Aspekt der digitalen Vorsorge in dieser Strategie bei, indem sichergestellt wird, dass die Cloud- und KI-Dienste, von denen das Krisenmanagement, die Koordinierung des Katastrophenschutzes und die Katastrophenbewältigung abhängen, mit der geeigneten Unionsvertrauenswürdigkeitsstufe bereitgestellt werden. Der Vorschlag steht daher im Einklang mit den übergeordneten politischen Resilienz- und Vorsorgezielen der Union und dient deren Verfolgung.

Der Vorschlag steht im Einklang mit den geltenden Vorschriften über die Verarbeitung personenbezogener Daten, einschließlich der Datenschutz-Grundverordnung (DSGVO) und des Datenschutzrahmens EU-USA. Der Datenschutzrahmen EU-USA regelt zwar transatlantische Datenübermittlungen, er beseitigt jedoch nicht die Souveränitätsbedenken hinsichtlich der Abhängigkeit von Anbietern aus Drittländern. Der Vorschlag ergänzt somit den Datenschutzrahmen EU-USA, denn der Begriff der Souveränität geht weit über Datenübermittlungen hinaus und erfasst auch die Betriebsautonomie.

Außerdem ergänzt der Vorschlag die Richtlinien über die Vergabe öffentlicher Aufträge. Behörden in der EU sind in hohem Maße auf außereuropäische Anbieter von Cloud-Computing-Diensten angewiesen, und die daraus erwachsenden Problemfaktoren erfordern einen differenzierten und zielgerichteten sektoralen Ansatz, der von den bestehenden Richtlinien über die Vergabe öffentlicher Aufträge nicht abgedeckt wird und der auch durch einen übergreifenden Ansatz nur schwer ausreichend berücksichtigt werden könnte. Der Vorschlag sieht daher einen sektorspezifischen Souveränitätsansatz vor, dessen zahlreiche Aspekte nicht mit den bestehenden horizontalen Rechtsvorschriften angegangen werden können, in denen lediglich allgemeine Grundsätze für die Gestaltung von Vergabeverfahren vorgegeben werden. Der Vorschlag enthält ergänzende Zuschlagskriterien, die auch auf die Besonderheiten von Cloud-Computing-Diensten und den Umgang mit kritischen Abhängigkeiten von Drittländern in diesem Sektor zugeschnitten sind.

Der Vorschlag ergänzt die Verordnung über digitale Netze, mit der die Entwicklung robuster, schneller, sicherer und hochmoderner digitaler Netze unterstützt wird, und kommt somit der Errichtung von Rechenzentren in der EU zugute, die eine Hochgeschwindigkeits-, Gigabit- und noch darüber hinausreichende Konnektivität voraussetzen. Der Vorschlag baut auf den Konnektivitätsfortschritten im Zusammenhang mit der Verordnung über digitale Netze auf und konzentriert sich daher auf den weiteren Aufbau von Rechenzentrumskapazitäten und nicht auf einen vorherigen oder parallelen Ausbau der dafür erforderlichen Konnektivitätsinfrastruktur. Die Verordnung über digitale Netze betrifft auch die Konvergenz der Netzinfrastrukturen, darunter auch Szenarien, in denen ein Anbieter von Cloud-Computing-Diensten ein elektronisches Kommunikationsnetz betreibt und diesbezüglich bislang keinen besonderen Verpflichtungen nach dem europäischen Kodex für die elektronische Kommunikation unterlag, obwohl er in dessen Anwendungsbereich fällt. Somit werden durch die Verordnung über digitale Netze die Verfahren für die Konnektivität zwischen Anbietern verschiedener Netze und anderen Marktteilnehmern im Rahmen einer umfassenderen Zusammenarbeit im Ökosystem präzisiert.

Der Vorschlag trägt zur Verwirklichung der Ziele der Energieeffizienzrichtlinie bei, nämlich den Rechenzentrumssektor zu einer höheren Energieeffizienz zu führen. Abgesehen von Transparenz- und Reputationserwägungen werden damit jedoch keine Anreize für Betreiber von Rechenzentren geschaffen, ihre Nachhaltigkeitsleistung zu verbessern, und es werden auch keine Maßnahmen zum beschleunigten EU-weiten Aufbau nachhaltiger Rechenzentren oder zur Erhöhung der diesbezüglichen Investitionen festgelegt.

Auch der EU-Verhaltenskodex für die Energieeffizienz von Rechenzentren betrifft keine Maßnahmen zur Errichtung eines Rechenzentrums, sondern konzentriert sich vollständig auf die Verfahren für dessen Betrieb. Daher enthält der Vorschlag Maßnahmen zur Schaffung von Anreizen für die Errichtung energieeffizienter Rechenzentren entsprechend dem Strategischen Fahrplan für Digitalisierung und KI im Energiebereich, mit dem der Energieverbrauch im Zusammenhang mit digitalen Technologien optimiert und gleichzeitig der parallele grüne und digitale Wandel in der EU beschleunigt werden soll. Zur Feststellung, welche Rechenzentren nachhaltig sind, wird in dem Vorschlag auf das im Rahmen der Energieeffizienzrichtlinie entwickelte Bewertungssystem zurückgegriffen.

Ferner ergänzt der Vorschlag das Paket „Europäische Netze“, mit dem sichergestellt werden soll, dass ausreichende Stromnetze vorhanden und verfügbar sind, um künftige Lasten breit zu verteilen. In dieser Hinsicht konzentriert sich der Vorschlag auf Rechenzentren als Endkunden der Netzkapazität und sorgt dafür, dass bei der Standortwahl der Rechenzentren auch die Stromnetzverfügbarkeit berücksichtigt wird und dass Informationen rechtzeitig im Voraus ausgetauscht werden, um in die Netzplanung einfließen zu können, damit eine rechtzeitige Anbindung der Rechenzentren gewährleistet werden kann.

Im Paket „Europäische Netze“ wird dargelegt, wie die Mitgliedstaaten Netzanschlüsse beschleunigen können, einschließlich einer effizienteren Strukturierung ihrer Warteschlange für den Netzanschluss, indem beispielsweise auch die Reife eines Projekts und seine stromnetzfreundlichen Nutzungen – im Gegensatz zur bloßen Bearbeitung in der Reihenfolge der Beantragung – berücksichtigt werden. In dem Vorschlag wird auf diesen Erwägungen aufgebaut.

Der Vorschlag ergänzt auch die Erneuerbare-Energien-Richtlinie und kann sie zu seinem Vorteil nutzen. Rechenzentren können von der gesteigerten Verfügbarkeit erneuerbarer Energie und deren Speicherung profitieren, auch wenn sie selbst nicht von der Richtlinie erfasst werden. Die Nähe zu Beschleunigungsgebieten für erneuerbare Energien könnte ebenfalls ein wichtiger Faktor für die Wahl von Standorten für die schnellere Errichtung von Rechenzentren sein.

Die Verordnung zur industriellen Beschleunigung enthält Maßnahmen zur Beschleunigung der Genehmigungsverfahren; ferner wird darin der Grundsatz „ein Projekt, ein Verfahren“ festgelegt und ein einheitliches digitales Verfahren für das gesamte Genehmigungsverfahren eingeführt. Nach der Verordnung zur industriellen Beschleunigung müssen die Mitgliedstaaten auch mindestens ein Beschleunigungsgebiet oder -cluster für die industrielle Fertigung ausweisen, für das weitere Maßnahmen zur Erleichterung der Geschäftstätigkeit gelten, und für einen vorrangigen Zugang zu Materialien und für den Zugang zu EU-Finanzmitteln sorgen. Da die vorgeschlagenen Maßnahmen zur industriellen Beschleunigung jedoch nur für Fertigungsanlagen gelten und weder den besonderen Bedürfnissen von Rechenzentren noch ihren Vorteilen Rechnung tragen, wurden Rechenzentren aus dem Anwendungsbereich der Verordnung zur industriellen Beschleunigung ausgenommen. Der vorliegende Vorschlag geht auf diese Unterschiede ein und ergänzt die allgemeinen Maßnahmen zur industriellen Beschleunigung durch Maßnahmen, die auf die beschleunigte Errichtung von Rechenzentren zugeschnitten sind.

### 2. RECHTSGRUNDLAGE, SUBSIDIARITÄT UND VERHÄLTNISMÄẞIGKEIT

#### • Rechtsgrundlage

Die Rechtsgrundlage dieses Vorschlags ist Artikel 114 des Vertrags über die Arbeitsweise der Europäischen Union (AEUV), der die EU ermächtigt, Maßnahmen zur Verbesserung des Funktionierens des Binnenmarkts durch die Harmonisierung nationaler Bestimmungen zu erlassen.

Die derzeitige Fragmentierung bei der Errichtung von Rechenzentren ist auf unterschiedliche nationale Vorgehensweisen in Bezug auf Kapazitätsausbau, Nachhaltigkeitsanforderungen und Genehmigungsverfahren zurückzuführen. Daraus ergibt sich ein Risiko weitreichender regulatorischer Unterschiede, die den Binnenmarkt untergraben könnten.

Unterschiede in den Verfahren zur Vergabe öffentlicher Aufträge für Cloud-Computing-Dienste sowie uneinheitliche Souveränitätskriterien können verhindern, dass Anbieter nahtlos in den Mitgliedstaaten tätig werden, was zu Ineffizienzen auf dem Markt und zu ungleichen Wettbewerbsbedingungen führt.

Angesichts dieser Herausforderungen ist ein Tätigwerden auf EU-Ebene in Form eines Legislativvorschlags gemäß Artikel 114 AEUV gerechtfertigt, da dieser darauf abzielt, Hindernisse im Binnenmarkt zu beseitigen und gleiche Wettbewerbsbedingungen für Anbieter von Cloud-Computing-Diensten zu schaffen.

Darüber hinaus stützt sich der Vorschlag auf Artikel 173 Absatz 3 AEUV, der die Rechtsgrundlage für Maßnahmen zur Stärkung der industriellen Wettbewerbsfähigkeit und Innovationskapazität der EU bildet. Aufgrund des derzeitigen Mangels an Rechenkapazitäten in der EU wird die Fähigkeit der europäischen Wirtschaft eingeschränkt, in vollem Maße von der Nutzung von Cloud- und KI-Technologien zu profitieren, insbesondere von solchen, die geringe Latenz und Hochleistungsrechnen voraussetzen. Durch die Erhöhung der Verfügbarkeit energieeffizienter Rechenkapazitäten und die Entwicklung und Einführung modernster Cloud- und KI-Technologien trägt diese Initiative im Einklang mit den Zielen des Artikels 173 Absatz 3 AEUV unmittelbar zur Stärkung der industriellen Wettbewerbsfähigkeit und der technologischen Führungsrolle Europas bei.

Angesichts des doppelten Ziels des Vorschlags, nämlich Verzerrungen im Binnenmarkt abzubauen und die industrielle Wettbewerbsfähigkeit der EU zu stärken, wird er als ein einziges Rechtsinstrument auf der doppelten Rechtsgrundlage des Artikels 114 und Artikels 173 Absatz 3 AEUV erlassen. Diese gemeinsame Rechtsgrundlage bietet eine einheitliche regulatorische Antwort auf die miteinander verknüpften Herausforderungen der Marktfragmentierung und des strategischen Aufbaus industrieller Kapazitäten im Cloud- und KI-Ökosystem der EU.

#### • Subsidiarität (bei nicht ausschließlicher Zuständigkeit)

EU-Maßnahmen bieten einen klaren Mehrwert bei der Lösung des Problems der begrenzten und geografisch konzentrierten Verfügbarkeit von Rechenkapazitäten. Durch ein gemeinsames Vorgehen bei der beschleunigten Errichtung von Rechenzentren ermöglicht dies eine kohärente Planung und einen geografisch ausgewogenen Aufbau von Rechenkapazitäten, wobei gleichzeitig ein Unterbietungswettbewerb verhindert und die regulatorische Komplexität für Investoren und Betreiber von Rechenzentren verringert wird.

Die EU ist in einer einzigartigen Position, um dafür zu sorgen, dass die Investitions- und Beschleunigungspolitik die gemeinsamen Prioritäten widerspiegelt und eine Fragmentierung verhindert. Maßnahmen auf EU-Ebene würden sicherstellen, dass alle Unternehmen und öffentlichen Verwaltungen Zugang zu ausreichenden Rechenkapazitäten haben, um ihren Bedürfnissen gerecht zu werden, und sie sind eine Voraussetzung dafür, dass Europa ein KI-Kontinent wird.

Bei der Bewältigung der Abhängigkeit von Cloud-Computing-Diensten außereuropäischer Anbieter bieten EU-Maßnahmen Vorteile, die über das hinausgehen, was die Mitgliedstaaten einzeln erreichen könnten, insbesondere hinsichtlich der Behebung des zugrunde liegenden Marktversagens wegen unvollständiger Informationen. Dies wird das Funktionieren des Binnenmarkts verbessern und es den Anbietern von Cloud-Computing-Diensten ermöglichen, über ihre nationalen Märkte hinauszuwachsen.

#### • Verhältnismäßigkeit

Mit dem Vorschlag wird ein gezielter und verhältnismäßiger Ansatz verfolgt, um den kritischen Engpässen im Binnenmarkt entgegenzutreten, und zwar insbesondere dem Rechenkapazitätsdefizit und der übermäßigen Abhängigkeit von Anbietern aus Drittländern. Die vorgeschlagenen Lösungen sind auf Maßnahmen beschränkt, die für die Verwirklichung der Kernziele des Vorschlags unverzichtbar sind, nämlich die Stärkung der technologischen Souveränität der EU, die Förderung eines wettbewerbsbestimmten Cloud- und KI-Marktes in der EU und die Förderung einer besseren Verfügbarkeit nachhaltiger Rechenressourcen in der EU.

Mit seiner Konzentration auf harmonisierte Normen für souveräne Cloud-Computing-Dienste, eine gestraffte Errichtung von Rechenzentren und EU-weite Kooperationsmechanismen vermeidet der Vorschlag eine übermäßige Regulierung und wirkt gleichzeitig den strukturellen Hindernissen direkt entgegen, die in ganz Europa Fortschritte im digitalen Bereich behindern. Die gewählten Maßnahmen stellen das am besten geeignete und am wenigsten einschneidende Mittel zur Behebung des festgestellten Marktversagens und der bestehenden Regulierungsmängel dar, weil sie auf vorhandenen EU-Instrumenten aufbauen und nur dann neue Bestimmungen einführen, wenn dies für eine kohärente und effiziente Umsetzung erforderlich ist.

Der Vorschlag wird direkte Befolgungskosten verursachen, und zwar sowohl in Form von Verwaltungs- als auch Anpassungsausgaben. Zu tragen sind diese Kosten hauptsächlich von nationalen und lokalen Behörden sowie von Unternehmen wie Betreibern von Rechenzentren, Anbietern von Cloud-Computing-Diensten sowie deren Unterauftragnehmern und von privatwirtschaftlichen Einrichtungen in den in Anhang I der NIS-2-Richtlinie aufgeführten Sektoren, damit sie die in dieser Verordnung festgelegten Verpflichtungen erfüllen können.

Die Auslotung verschiedener Optionen und ihrer erwarteten Kosten und Nutzeffekte hat jedoch zu einer ausgewogenen Gestaltung des Instruments geführt. Die Kosten der Behörden werden durch die Senkung der Gesamtbetriebskosten der IT-Systeme und durch schnellere und zuverlässigere Vergabeverfahren ausgeglichen, während die Kosten der Unternehmen durch eine bessere Vorhersehbarkeit der regulatorischen Ausrichtung und eine geringere Fragmentierung der nationalen Ansätze zusammen mit einer Verwaltungsvereinfachung ausgeglichen werden.

#### • Wahl des Instruments

Die Kommission schlägt eine Verordnung als optimales Rechtsinstrument für die Verwirklichung der mit dem Vorschlag angestrebten Ziele vor, da sie eine einheitliche Anwendung und unmittelbare Wirkung in allen Mitgliedstaaten gewährleistet. Eine Verordnung sorgt für die notwendige Rechtssicherheit und Kohärenz im Hinblick auf die vollständige Harmonisierung des Rechtsrahmens für Cloud-Computing-Dienste. Dieses Vorgehen ist unerlässlich, um Hindernisse im Binnenmarkt zu beseitigen, insbesondere in Bereichen wie Souveränität und Nachhaltigkeitsstandards, in denen abweichende nationale Vorschriften andernfalls die technologische Souveränität und Wettbewerbsfähigkeit der EU untergraben könnten. Angesichts der geopolitischen Dringlichkeit und der Notwendigkeit, strategische Abhängigkeiten von Anbietern aus Drittländern zu verringern, gewährleistet eine Verordnung eine rasche, koordinierte und EU-weite Reaktion und verhindert Verzögerungen oder Unstimmigkeiten, die sich aus einem voneinander unabhängigeren Vorgehen der Mitgliedstaaten ergeben könnten.

### 3. ERGEBNISSE DER EX-POST-BEWERTUNG, DER KONSULTATION DER INTERESSENTRÄGER UND DER FOLGENABSCHÄTZUNG

#### • Konsultation der Interessenträger

Zwischen Oktober 2024 und November 2025 wurde eine umfassende Konsultation der Interessenträger durchgeführt, die die folgenden Konsultationstätigkeiten umfasste.

Zwischen April und Juli 2025 führte die Kommission eine öffentliche Konsultation durch, die aus einem Online-Fragebogen und einer Aufforderung zur Stellungnahme bestand, damit die Interessenträger detaillierte Positionspapiere vorlegen konnten, in denen sie ihre Ansichten und Empfehlungen zu den Zielen und den vorgeschlagenen Maßnahmen des Vorschlags darlegen konnten und gleichzeitig direkte Erkenntnisse beisteuerten, die in die Konzeption der Politikoptionen einfließen sollten. Insgesamt gingen 436 Antworten ein: 243 auf den Konsultationsfragebogen und 193 auf die Aufforderung zur Stellungnahme.

Die Konsultation wurde durch eine Reihe von Workshops, Seminaren und Rundtischgesprächen ergänzt. Dazu zählten: i) die 6. Generalversammlung und das Allianzforum der Europäischen Allianz für Industriedaten, Edge und Cloud, ii) Rundtischgespräche, vor allem mit Finanzinvestoren über Investitionen in das Cloud-Computing, über politische Maßnahmen zur Erleichterung der Integration von Rechenzentren in das EU-Stromnetz, mit Geschäftsführern europäischer Cloud-Diensteanbieter über die Entwicklung souveräner Cloud-Angebote in der EU und mit der amerikanischen Handelskammer, iii) Seminare mit Unternehmen der Branche, Hochschulen und Behörden über die wirtschaftliche Dynamik des KI-Stacks und iv) Präsentationen für die Branche über die künftige Cloud- und KI-Politik der EU.

Ferner führte die Kommission einen kontinuierlichen Dialog mit den zuständigen Behörden der Mitgliedstaaten, die in der informellen Cloud-Kooperationsgruppe der Mitgliedstaaten im Rahmen der Europäischen Allianz für Industriedaten, Edge und Cloud zusammenkommen, ergänzt durch gezielte bilaterale Zusammenkünfte.

Darüber hinaus führte die Kommission weitere bilaterale Gespräche mit Drittländern, darunter Japan, die Schweiz und das Vereinigte Königreich, um die in Betracht gezogenen politischen Optionen vorzustellen und zu erörtern und gleichzeitig Einblicke in bewährte Verfahren zu gewinnen und die externen Auswirkungen der Maßnahmen zu bewerten.

Schließlich hatte die Kommission mehr als 100 bilaterale Zusammenkünfte mit einem breiten Spektrum von Interessenträgern, darunter Branchenvertreter, akademische Einrichtungen, Denkfabriken und Organisationen der Zivilgesellschaft, die die Formulierung der vorgeschlagenen politischen Optionen unterstützten.

#### • Einholung und Nutzung von Expertenwissen

Die Kommission beauftragte ein Konsortium unter der Leitung der Technopolis Group mit der Durchführung einer Studie zur Unterstützung der Phase der Sammlung und Analyse von Nachweisen für die Folgenabschätzung, die dem Vorschlag vorausging. Die Studie umfasste zahlreiche Aktivitäten zur Einbeziehung der Interessenträger, darunter mehr als 60 gezielte Befragungen, aber auch Umfragen (mit über 250 Antworten) und Workshops (mit über 100 Teilnehmern).

#### • Folgenabschätzung

Diesem Vorschlag ist eine umfassende Folgenabschätzung beigefügt, deren Endfassung dem Ausschuss für Regulierungskontrolle am 30. April 2026 vorgelegt wurde. Am 8. Mai 2026 gab der Ausschuss eine befürwortende Stellungnahme ab, der ein Verlangen nach weiteren Verbesserungen beigefügt war.

#### • Grundrechte

Der Vorschlag wurde einer umfassenden Bewertung seiner Auswirkungen auf die Grundrechte unterzogen, wobei ein besonderer Schwerpunkt auf dem Schutz personenbezogener Daten gemäß Artikel 8 der Charta der Grundrechte der Europäischen Union lag. Mit dem Vorschlag wird ein Rahmen für souveräne Cloud-Computing-Dienste eingeführt, der strikte Garantien dafür vorsieht, dass die Verarbeitung personenbezogener Daten, die EU-Bürgerinnen und -Bürger betreffen, im Einklang mit den Datenschutzstandards der EU, einschließlich der DSGVO, erfolgt. Durch die Festlegung dieser Standards minimiert der Vorschlag die Risiken im Zusammenhang mit einer nicht konformen Datenverarbeitung und stärkt gleichzeitig das Vertrauen in die digitalen Infrastrukturen.

Eines der Hauptziele des Vorschlags besteht darin, die Abhängigkeit von Anbietern aus Drittländern zu verringern, deren Tätigkeiten den Rechtsordnungen von Drittländern unterliegen können, in denen ein Datenzugriff und eine Datenübermittlung gestattet werden könnte. Folglich wird mit dem Vorschlag der Schutz personenbezogener Daten verbessert, indem sichergestellt wird, dass diese Daten weiterhin unter der wirksamen Aufsicht der EU-Behörden, einschließlich der Datenschutzbehörden der Mitgliedstaaten und des Europäischen Datenschutzausschusses, stehen. Dieser Ansatz stärkt die Rechtssicherheit und wahrt das in der Charta verankerte Recht auf Privatsphäre.

Darüber hinaus fördert der Vorschlag einen vom Wettbewerb geprägten Binnenmarkt für Cloud-Computing-Dienste, in dem die Anbieter uneingeschränkt an die EU-Rechtsvorschriften gebunden sind und den geltenden Verpflichtungen unterliegen. Dies verbessert nicht nur die dauerhafte Verfügbarkeit von Daten, sondern stellt auch sicher, dass die in der EU geltenden rechtlichen Verpflichtungen, z. B. im Zusammenhang mit den Rechten betroffener Personen und der Regulierungsaufsicht, konsequent eingehalten werden. Durch die Steigerung der Marktpräsenz von Anbietern mit Sitz in der EU wird mit dem Vorschlag auch der Schutz der Grundrechte weiter in das digitale Ökosystem integriert, weil stärkere Garantien gegen unbefugten Zugriff auf personenbezogene Daten oder deren Missbrauch bestehen. Die Verhältnismäßigkeit dieser Maßnahmen wurde sorgfältig geprüft, um ein Gleichgewicht zwischen Innovationsfähigkeit und dem zwingenden Schutz der Rechte im Einklang mit den Grundsätzen der Charta herzustellen.

### 4. AUSWIRKUNGEN AUF DEN HAUSHALT

Auf die Haushaltsauswirkungen des Vorschlags wird im beigefügten Finanzbogen ausführlich eingegangen. Für eine wirksame Umsetzung der Initiative sind 25 Vollzeitäquivalente (VZÄ) erforderlich, die aus 9 Planstellen und 16 Stellen für Vertragsbedienstete bestehen. Diese Personalkonfiguration soll durch eine Kombination aus Umschichtungen und zusätzlichen Einstellungen erreicht werden. Insbesondere werden 15 vorhandene Bedienstete innerhalb der Kommission versetzt, um die Initiative zu unterstützen und ihre Sachkenntnis und Erfahrung bei der Verwaltung ähnlicher Maßnahmen zu nutzen. Das erforderliche Personal wird von der GD CNECT und der GD DIGIT gestellt, wo es derzeit schon einschlägigen Referaten angehört, oder es wird innerhalb der Kommissionsdienststellen umgeschichtet. Zur Ergänzung dieser vorhandenen Humanressourcen werden für die Initiative 10 zusätzliche VZÄ benötigt: 6 VZÄ für die GD CNECT und 4 VZÄ für die GD DIGIT. Diese zusätzlichen Bediensteten werden beantragt, um den derzeitigen Personalbestand aufzustocken und so die erfolgreiche Umsetzung der Initiative und die wirksame Durchführung neuer Tätigkeiten und Aufgaben zu gewährleisten.

Die zusätzlichen Verwaltungsausgaben im Zusammenhang mit den im Vorschlag beschriebenen neuen Aufgaben werden hauptsächlich durch Einnahmen aus Gebühren finanziert, die unter interne zweckgebundene Einnahmen fallen, wodurch ein nachhaltiges und tragfähiges Finanzierungsmodell gewährleistet wird. Insbesondere sollen Gebühreneinnahmen genutzt werden, um die Erfüllung von Aufgaben im Zusammenhang mit der gemeinsamen Auftragsvergabe und der Verwaltung der EuroCloud-Initiative zu unterstützen, die interessierten Mitgliedstaaten die gemeinsame Nutzung ungenutzter Cloud- und Rechenzentrumskapazitäten erleichtern soll.

### 5. WEITERE ANGABEN

#### • Durchführungspläne sowie Monitoring-, Bewertungs- und Berichterstattungsmodalitäten

Die Kommission sollte die Anwendung der vorgeschlagenen Verordnung überwachen und ihre Wirksamkeit im Laufe der Zeit bewerten. Fünf Jahre nach dem Inkrafttreten sollte die Kommission die Funktionsweise dieser vorgeschlagenen Verordnung überprüfen und dem Europäischen Parlament und dem Rat darüber Bericht erstatten. Diese Berichte werden veröffentlicht und geben detailliert Auskunft über die tatsächliche Anwendung und Durchsetzung der vorgeschlagenen Verordnung.

#### • Ausführliche Erläuterung einzelner Bestimmungen der vorgeschlagenen Verordnung

Titel I der vorgeschlagenen Verordnung enthält die allgemeinen Bestimmungen, einschließlich des Gegenstands (Artikel 1) und der Begriffsbestimmungen (Artikel 2).

Titel II enthält die Bestimmungen, die den Rahmen für die Durchführung von Entwicklungs- und Einführungstätigkeiten im gesamten Cloud- und KI-Ökosystem festlegen. Der Rahmen ist in die Cloud- und KI-Führungsinitiativen gegliedert und wird durch weitere Unterstützungsmaßnahmen verstärkt. Kapitel I Artikel 3 enthält das allgemeine Ziel der Cloud- und KI-Führungsinitiativen, mit denen Forschungs- und Innovationstätigkeiten unterstützt und große Kapazitäten im gesamten Cloud- und KI-Ökosystem der Union geschaffen werden sollen. In Artikel 4 werden die operativen Ziele der Cloud- und KI-Führungsinitiativen festgelegt. Mit Artikel 5 wird ein Netz der KI-Erfahrungs- und Beschleunigungszentren eingeführt, das auf den europäischen digitalen Innovationszentren aufbaut und die Verwirklichung der Ziele der Cloud- und KI-Führungsinitiativen unterstützen soll. In Artikel 6 werden die Durchführungsmechanismen der Cloud- und KI-Führungsinitiativen festgelegt. Laut Artikel 7 müssen die Mitgliedstaaten innerhalb eines Jahres nach dem Inkrafttreten der Verordnung eine nationale Cloud- und KI-Strategie annehmen, die mit den Zielen der Verordnung im Einklang steht. In Artikel 8 werden Kriterien für Projekte festgelegt, die von der Kommission als vorrangiges Grenz-KI-Projekt anerkannt werden können. Artikel 9 unterstützt die Zuweisung von KI-Rechenressourcen für vorrangige Grenz-KI-Projekte ebenso wie für industrielle und physische KI-Projekte sowie die Entwicklung und Einführung von KI-Modellen für den öffentlichen Sektor.

Titel III enthält Bestimmungen über Rechenzentrumskapazitäten. In Kapitel I Artikel 10 werden die Verpflichtungen der Mitgliedstaaten festgelegt, Beschleunigungsgebiete für Rechenzentren in ihrem Hoheitsgebiet auszuweisen, wenn sie Rechenzentrumskapazitäten aufbauen. In Artikel 11 werden die innerhalb der Beschleunigungsgebiete für Rechenzentren geltenden Bedingungen beschrieben. Artikel 12 verpflichtet die Mitgliedstaaten dazu, in Beschleunigungsgebieten für Rechenzentren zentrale Informationsstellen für Betreiber von Rechenzentrumsprojekten zu benennen oder, soweit möglich, zu modernisieren oder in bereits bestehende zentrale Informationsstellen zu integrieren, sowie weitere Grundsätze festzulegen, die in Bezug auf die Zuständigkeiten der Informationsstellen einzuhalten sind. Artikel 13 betrifft die vereinfachten Verwaltungs- und Genehmigungsverfahren für Rechenzentrumsprojekte, die in Beschleunigungsgebieten für Rechenzentren durchgeführt werden. In Kapitel II Artikel 14 werden das Verfahren für Interessenbekundungen sowie die Bedingungen für strategische Rechenzentrumsprojekte und deren Benennung durch die Kommission festgelegt. In Kapitel III Artikel 15 wird ein Verfahren festgelegt, mit dem die Kommission die Fortschritte der Union in Bezug auf die Erhöhung der verfügbaren Rechenkapazitäten, das Volumen der Nachfrage nach Rechenzentrumskapazitäten und das Ausmaß der Kapazitätslücke überwachen kann.

Titel IV enthält die Bestimmungen über Autonomie und Einführung. In Kapitel I Abschnitt 1 Artikel 16 wird ein Unionsrahmen für Cloud-Computing-Souveränität eingeführt, der aus vier Vertrauenswürdigkeitsstufen besteht, und es werden die in Anhang II der Verordnung aufgeführten Anforderungen eingeführt, die erfüllt sein müssen, damit Cloud-Computing-Dienste in die Unionsvertrauenswürdigkeitsstufen 1 bis 4 eingestuft werden können. Mit Artikel 17 wird ein Verfahren für die Anerkennung von Anbietern von Cloud-Computing-Diensten als Anbieter der Unionsvertrauenswürdigkeitsstufe 1, 2, 3 oder 4 eingeführt, demzufolge diese bei der zuständigen nationalen Behörde am Niederlassungsort einen Antrag auf Anerkennung stellen müssen. Artikel 18 enthält Bedingungen und ein Verfahren für eine mögliche Anerkennung von Drittländern als Länder, die ausreichende Garantien bieten, damit Cloud-Computing-Dienste, die von diesem Drittland kontrolliert werden, in die Unionsvertrauenswürdigkeitsstufe 3 eingestuft werden können. In Abschnitt 2 Artikel 19 werden die Bedingungen für die Selbstbewertung der Konformität festgelegt, mit der die Übereinstimmung mit den Anforderungen der Unionsvertrauenswürdigkeitsstufe 1 dokumentiert wird. In Abschnitt 3 Artikel 20 wird der Rahmen für die Bewertung festgelegt, die von Prüfstellen durchgeführt wird, um die Einhaltung der Anforderungen der Unionsvertrauenswürdigkeitsstufen 2 bis 4 zu prüfen. Artikel 21 enthält die Anforderungen an Prüfbelege, die im Zuge der Bewertung der Anforderungen der Unionsvertrauenswürdigkeitsstufen 2 bis 4 von Dritten zu erstellen sind. In Artikel 22 wird die Verpflichtung der Kommission festgelegt, ein Zentralverzeichnis für jene Dienste einzurichten und zu unterhalten, die anerkanntermaßen die Unionsvertrauenswürdigkeitsstufen 1 bis 4 bieten. Artikel 23 enthält Transparenzpflichten für Anbieter von Cloud-Computing-Diensten, wonach diese alle wesentlichen Änderungen melden müssen, aus denen sich eine Änderung ihrer Anerkennung als Anbieter der Unionsvertrauenswürdigkeitsstufen 1 bis 4 ergeben könnte. Artikel 24 enthält die Vorschriften über Sanktionen und Schadenersatz für Verstöße von Anbietern von Cloud-Computing-Diensten. In Abschnitt 4 Artikel 25 werden die Verpflichtungen der Mitgliedstaaten zur Benennung einer zuständigen nationalen Behörde festgelegt. In Artikel 26 werden die Befugnisse der von den Mitgliedstaaten benannten zuständigen nationalen Behörden festgelegt. In Abschnitt 5 Artikel 27 werden die Grundsätze der Amtshilfe zwischen den zuständigen nationalen Behörden der Mitgliedstaaten im Zusammenhang mit dem Informationsaustausch und der Untersuchung für die Zwecke dieser Verordnung festgelegt. Artikel 28 enthält die Grundsätze der grenzüberschreitenden Zusammenarbeit zwischen den zuständigen nationalen Behörden der Mitgliedstaaten im Zusammenhang mit Durchsetzungsmaßnahmen. Kapitel II Abschnitt 1 Artikel 29 enthält die Verpflichtungen der Mitgliedstaaten und der Einrichtungen der Union zur Durchführung von Risikobewertungen, um das erforderliche Maß an Konformität mit den Unionsvertrauenswürdigkeitsstufen 2-4 für verschiedene Tätigkeiten des öffentlichen Sektors zu bestimmen. Artikel 30 verpflichtet öffentliche Auftraggeber, die Cloud-Computing-Dienste in Auftrag geben, dabei als Mindestanforderung die Unionsvertrauenswürdigkeitsstufe 1 zu verlangen. Hat eine Risikobewertung ergeben, dass die Tätigkeiten dieser öffentlichen Auftraggeber für die Aufrechterhaltung der öffentlichen Ordnung von Bedeutung sind, so dürfen sie nur solche Dienstleistungen in Auftrag geben und benutzen, die anerkanntermaßen die Unionsvertrauenswürdigkeitsstufe 2, 3 oder 4 bieten. Nach Abschnitt 2 Artikel 31 können privatwirtschaftliche Einrichtungen im Sinne der NIS-2-Richtlinie Folgenabschätzungen durchführen, die einem ähnlichen Zweck dienen wie die von Einrichtungen der Union und öffentlichen Stellen durchgeführten Folgenabschätzungen. In Abschnitt 3 Artikel 32 werden öffentliche Auftraggeber der Mitgliedstaaten dazu verpflichtet, bei der Vergabe öffentlicher Aufträge für Cloud-Computing-Dienste und KI-Systeme, die in den Anwendungsbereich der Verordnung fallen, Kriterien für den Mehrwert für die Union anzuwenden. In Artikel 33 werden die Mitgliedstaaten dazu verpflichtet, ihre innovationsfördernde Auftragsvergabe für Cloud-Computing-Dienste und KI-Systeme zu überwachen; zudem wird ein schlanker Berichterstattungsrahmen eingeführt und es werden Verbindungen zu nationalen Cloud- und KI-Strategien hergestellt, wonach die Mitgliedstaaten Pläne zur Erreichung der Ziele dieses Artikels aufstellen müssen. Mit Kapitel III Artikel 34 wird der Europäische Cloud-Verbund des öffentlichen Sektors (im Folgenden „EuroCloud-Verbund“) eingerichtet und sein Anwendungsbereich und Zweck festgelegt. Artikel 35 enthält die Bedingungen für die gemeinsame Nutzung von Rechenzentrumsdiensten und Cloud-Computing-Diensten innerhalb des EuroCloud-Verbunds. In Artikel 36 wird festgelegt, wie die Kommission die in Verbindung mit dem EuroCloud-Verbund entstehenden Kosten decken kann, einschließlich der Gründung des EuroCloud-Verbunds und der Plattform zur Erleichterung der gemeinsamen Nutzung von Diensten durch ihre Mitglieder. In Kapitel IV Artikel 37 werden die Bedingungen festgelegt, unter denen die Kommission Auftragsvergabetätigkeiten für Einrichtungen der Union, für öffentliche Auftraggeber aus den Mitgliedstaaten und für von der Kommission ausgewählte Partnerorganisationen durchführen kann, auch unter Festlegung der erforderlichen Ausnahmen von der Haushaltsordnung. Artikel 38 enthält die erforderlichen Regelungen für die Umsetzung des Rahmens für die gemeinsame Auftragsvergabe, einschließlich des Governance-Mechanismus. Artikel 39 enthält die geltenden Vorschriften für die Vergabe öffentlicher Aufträge. Artikel 40 enthält den Mechanismus für den Ausgleich der Kosten, die der Kommission beim Betrieb des Rahmens für die gemeinsame Auftragsvergabe entstehen, durch Gebühren, die von den teilnehmenden öffentlichen Auftraggebern erhoben werden. In Kapitel VI Artikel 41 werden die Verpflichtungen der Einrichtungen der Union und der öffentlichen Stellen zur Förderung und Erleichterung der Nutzung quelloffener Lösungen gegenüber proprietären Lösungen festgelegt. Artikel 42 enthält die Anforderungen an die gemeinsame Nutzung und Weiterverwendung von Software, die von Einrichtungen der Union und öffentlichen Stellen oder für diese entwickelt wurde. In Artikel 43 wird die Kommission dazu verpflichtet, einen Katalog quelloffener Lösungen bereitzustellen und zu führen. Artikel 44 enthält die Vorschriften für die Einrichtung eines Netzes der Open-Source-Programmbüros der Mitgliedstaaten.

Titel V enthält die Schlussbestimmungen, einschließlich der Befugnis der Kommission zum Erlass von delegierten Rechtsakten (Artikel 45) und Durchführungsrechtsakten (Artikel 46), der Überprüfungsklausel (Artikel 47) und der Festlegung des Inkrafttretens und des Geltungsbeginns der Verordnung (Artikel 48).

(Text von Bedeutung für den EWR)

DAS EUROPÄISCHE PARLAMENT UND DER RAT DER EUROPÄISCHEN UNION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union, insbesondere auf Artikel 114 und Artikel 173 Absatz 3,

auf Vorschlag der Europäischen Kommission,

nach Zuleitung des Entwurfs des Gesetzgebungsakts an die nationalen Parlamente,

nach Stellungnahme des Europäischen Wirtschafts- und Sozialausschusses^(1),

nach Stellungnahme des Ausschusses der Regionen^(2),

gemäß dem ordentlichen Gesetzgebungsverfahren,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Die Union ist bestrebt, im Bereich der künstlichen Intelligenz (KI) eine weltweite Führungsrolle zu erringen. Dadurch, dass sie schnellere Innovationen, Effizienzsteigerungen und eine intelligentere Entscheidungsfindung ermöglicht, bringt KI erhebliche wirtschaftliche, ökologische und gesellschaftliche Vorteile und erweist sich als eine grundlegende Triebkraft der Wettbewerbsfähigkeit. Um die Vorteile der KI in allen wichtigen Wirtschaftszweigen in vollem Umfang nutzbar zu machen, sollte die Union ehrgeizig und vorausschauend handeln, ihre Innovationsfähigkeiten ausbauen, ihre Wettbewerbsfähigkeit und Versorgungssicherheit verbessern und gleichzeitig ihre technologische Souveränität und strategische Autonomie bei modernsten digitalen Technologien stärken.

<a id="rec-2"></a>
(2) Die Union hat bereits solide Grundlagen geschaffen, um Europa als einen Kontinent zu positionieren, der bei der Entwicklung und Einführung von KI führend vorangeht, und zwar insbesondere mit der Mitteilung über den Aktionsplan für den KI-Kontinent^(3) und die Strategie „KI anwenden“^(4). Außerdem hat die Union mit der Verordnung (EU) 2023/2854 des Europäischen Parlaments und des Rates über harmonisierte Vorschriften für einen fairen Datenzugang und eine faire Datennutzung^(5) (im Folgenden „Datenverordnung“) und mit der Strategie für eine Datenunion^(6) den erforderlichen Rahmen geschaffen, um einen sicheren und interoperablen Binnenmarkt für Daten zu schaffen, der die Entwicklung von KI untermauert.

<a id="rec-3"></a>
(3) Das Europäische Parlament, der Rat, die Kommission und die Mitgliedstaaten haben sich verpflichtet, bei der Verwirklichung der technologischen Souveränität der Union auf offene Weise zusammenzuarbeiten, insbesondere durch sichere und zugängliche Digital- und Dateninfrastrukturen, die andere technologische Entwicklungen ermöglichen, um die Wettbewerbsfähigkeit und Nachhaltigkeit der Industrie und Wirtschaft der Union, insbesondere von kleinen und mittleren Unternehmen (KMU)^(7) und kleinen Midcap-Unternehmen^(8), sowie die Resilienz der Wertschöpfungsketten der Union zu unterstützen und das Start-up-Ökosystem zu fördern, unter anderem auch durch das reibungslose Funktionieren der bisherigen europäischen digitalen Innovationszentren (EDIHs), die nun neu ausgerichtet werden als Erfahrungs- und Beschleunigungszentren für KI (im Folgenden „KI-Zentren“).

<a id="rec-4"></a>
(4) Die Union ist zunehmend von einer begrenzten Zahl von Anbietern von Cloud-Computing-Diensten aus Drittländern abhängig geworden. Die Stärkung der Fähigkeit der Union, selbst eigene Cloud- und KI-Technologien in ihrem Hoheitsgebiet zu entwickeln und einzuführen, ist zu einer strategischen Priorität für die Wettbewerbsfähigkeit, die Versorgungssicherheit und die technologische Souveränität der Union geworden, was im Bericht von Mario Draghi über die Zukunft der europäischen Wettbewerbsfähigkeit^(9) hervorgehoben wurde und im Einklang mit der Mitteilung zur Stärkung der wirtschaftlichen Sicherheit der EU^(10) steht. Diese Herausforderungen für das Cloud- und KI-Ökosystem der Union machen einen groß angelegten technologischen Kapazitätsaufbau, Unterstützung im Zusammenhang mit Forschungs- und Innovationstätigkeiten und kollektive Anstrengungen der Mitgliedstaaten erforderlich, wobei die Union die Entwicklung und Einführung von Cloud- und KI-Technologien und umfangreichen Cloud-Computing-Kapazitäten unterstützt.

<a id="rec-5"></a>
(5) Die bestehenden Abhängigkeiten führen nicht nur zu geringen Marktanteilen für europäische Anbieter von Cloud-Computing-Diensten, sondern bergen auch erhebliche Risiken für die Betriebsautonomie, Resilienz und Sicherheit in der Union. Der Rat hat gefordert, dass eine künftige Verordnung zur Cloud- und KI-Entwicklung gemeinsame Kriterien für souveräne Cloud-Computing-Dienste enthalten muss, die es ermöglichen, die Markttransparenzrisiken und die mit Abhängigkeiten verbundenen Risiken anzugehen, einschließlich der extraterritorialen Auswirkungen von Rechtsvorschriften, die von Drittländern erlassen wurden^(11).

<a id="rec-6"></a>
(6) Es sollte ein Rahmen für die Steigerung der Resilienz und Sicherheit der Union im Bereich der Cloud- und KI-Technologien geschaffen werden, der das Cloud- und KI-Ökosystem der Union durch die Verringerung von Abhängigkeiten, die Erhöhung der technologischen Souveränität, die Anregung von Investitionen und die Verbesserung der Fähigkeiten, Sicherheit, Anpassungsfähigkeit und Resilienz der Cloud- und KI-Lieferkette der Union stärkt.

<a id="rec-7"></a>
(7) Der Rahmen dient verschiedenen Zielen und beruht auf zwei verschiedenen Rechtsgrundlagen.

<a id="rec-8"></a>
(8) Erstens ist es notwendig, die Wettbewerbsfähigkeit, Kapazitäten und Resilienz der technologischen und industriellen Basis der Union im Cloud- und KI-Bereich im Einklang mit Artikel 173 Absatz 3 des Vertrags über die Arbeitsweise der Europäischen Union (AEUV) zu stärken. Mit solchen Maßnahmen sollte keine Harmonisierung nationaler Rechts- oder Verwaltungsvorschriften verbunden sein. Zu diesem Zweck werden mit dieser Verordnung die Cloud-Führungsinitiative und die KI-Führungsinitiative (im Folgenden „Cloud- und KI-Führungsinitiativen“) eingerichtet, um die Entwicklung modernster Cloud- und KI-Technologien und -Anlagen zu fördern und ihre breite Einführung sicherzustellen, um so die Lücke zwischen den fortgeschrittenen Forschungs- und Innovationskapazitäten der Union und ihrer nachhaltigen Nutzung zu schließen.

<a id="rec-9"></a>
(9) Zweitens können die verfügbaren Rechenkapazitäten und die Resilienz des Cloud- und KI-Ökosystems am besten durch Harmonisierungsmaßnahmen der Union auf der Grundlage des Artikels 114 AEUV verbessert werden. Ein einheitlicher und kohärenter Rechtsrahmen für die Harmonisierung bestimmter Bedingungen für Anbieter und Betreiber von Cloud-Computing-Diensten, die sich auch auf den Kapazitätsaufbau und die Erbringung von Cloud-Computing-Diensten erstrecken, ist erforderlich, um das Funktionieren des Binnenmarkts zu gewährleisten.

<a id="rec-10"></a>
(10) Die Begriffsbestimmung für „Cloud-Computing-Dienst“ in dieser Verordnung sollte der Begriffsbestimmung in Artikel 6 Nummer 30 der Richtlinie (EU) 2022/2555 des Europäischen Parlaments und des Rates^(12) entsprechen, in der ein „Cloud-Computing-Dienst“ definiert wird als ein digitaler Dienst, der auf Abruf die Verwaltung und den umfassenden Fernzugang zu einem skalierbaren und elastischen Pool gemeinsam nutzbarer Rechenressourcen ermöglicht, auch wenn diese Ressourcen auf mehrere Standorte verteilt sind. Diese Begriffsbestimmung für „Cloud-Computing-Dienst“ umfasst auch den Zugang auf Abruf zu KI-Systemen im Sinne des Artikels 3 Nummer 1 der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates (im Folgenden „Verordnung über künstliche Intelligenz“)^(13), die an einem entfernten Ort gehostet und betrieben werden. Diese Dienstleistung umfasst nur die Lieferung und Bereitstellung eines KI-Systems. Das KI-System selbst und das ihm zugrunde liegende Modell sind dagegen vom Anwendungsbereich dieser Begriffsbestimmung ausgeschlossen.

<a id="rec-11"></a>
(11) Die Cloud- und KI-Führungsinitiativen sollten die Wettbewerbsfähigkeit und Resilienz der technologischen und industriellen Basis der Union im Cloud- und KI-Bereich stärken und gleichzeitig die Innovationskapazitäten ihres Cloud- und KI-Ökosystems steigern und im Einklang mit den im Aktionsplan für den KI-Kontinent und in der Strategie „KI anwenden“ festgelegten Zielen die Einführung großer digitaler Infrastrukturen bewirken. Insbesondere sollten die Cloud- und KI-Führungsinitiativen die Cloud- und Rechenzentrumskapazitäten der Union steigern und zugleich modernste Cloud- und KI-Technologien vorantreiben und eine breite Cloud- und KI-Einführung in der gesamten Wirtschaft der Union fördern. Überdies sollten sie mit fortgeschrittenen Forschungsarbeiten im Hinblick auf eine sektorspezifische Einführung von Grenz-KI, physischer KI und industrieller KI einhergehen. Mit der Strategie „KI anwenden“ sollten die im Aktionsplan für den KI-Kontinent festgelegten Bestrebungen und Ziele erweitert und erforderlichenfalls aktualisiert werden, um den neuesten technologischen Entwicklungen und Fortschritten bei den Cloud- und KI-Führungsinitiativen Rechnung zu tragen.

<a id="rec-12"></a>
(12) Zur Verfolgung dieser allgemeinen Ziele sollten die Cloud- und KI-Führungsinitiativen ergänzende operative Ziele unterstützen, die als auf Unionsebene zu ergreifende, direkt umsetzbare Initiativen konzipiert werden sollten.

<a id="rec-13"></a>
(13) Damit Rechenzentren als Schlüsselvoraussetzungen für einen nachhaltigen digitalen Wandel dienen können, sollten die Cloud- und KI-Führungsinitiativen auch die Forschungs- und Innovationskapazitäten im Hinblick auf die Entwicklung von Rechenzentrumstechnik unterstützen, die die Grundsätze der Energie- und Ressourceneffizienz durch Technikgestaltung über alle Abläufe hinweg berücksichtigt, um eine umfassende Nachhaltigkeit zu erreichen. Dazu gehört das Vorantreiben ressourcen- und nutzungseffizienter Rechentechnik, wie z. B. die Optimierung der Energie- und Wassereffizienz, der Einsatz neu entstehender Quanteninformatiktechnologien, die Entwicklung KI-gestützter Technologien zur Steigerung der Servereffizienz, die Integration der Recheninfrastruktur in die Energienetze, die Förderung der Einführung sauberer Energie und die Vor-Ort-Energieerzeugung in Rechenzentren. Die Cloud- und KI-Führungsinitiativen sollten auch Zugang zu Pilotanlagen für Rechenzentrumstechnik gewähren, um die Übernahme von Innovationen auf dem Markt zu steuern und zu beschleunigen. Solche Pilotprojekte sollten als Demonstrationsanlagen für modernste Rechenzentrums- und -Halbleitertechnologien, Quanteninformatik-Prototypen und KI-gestützte Werkzeuge für den Betrieb von Rechenzentren dienen.

<a id="rec-14"></a>
(14) Die Cloud- und KI-Führungsinitiativen sollten auch Forschungs- und Entwicklungstätigkeiten und die Einführung von Cloud-Stack-Technologien unterstützen, um die bestehende Kapazitätslücke zu schließen und die technologische Autonomie der Union zu stärken. Insbesondere sollten die Cloud- und KI-Führungsinitiativen die Entwicklung von Cloud-Computing-Stacks als Alternativen für strategische Sektoren fördern. Ferner sollten sie die Entwicklung von KI-optimierten Servern und Software erleichtern, darunter auch von Prozessoren und Beschleunigern, die in der Union entworfen und hergestellt werden, wie z. B. derjenigen, die im Rahmen der Verordnung (EU) 2026/XXX^(14) des Europäischen Parlaments und des Rates entwickelt werden. Darüber hinaus sollten sowohl die Cloud- und KI-Führungsinitiativen im Rahmen dieser Verordnung als auch die Initiative „Chips für Europa 2.0“, die durch die obige Verordnung unterstützt wird, die Mitgestaltung und Queroptimierung der Hardware- und Softwareentwicklung und die Integration von KI-Recheninfrastrukturen fördern. Die Cloud- und KI-Führungsinitiativen sollten überdies die ergänzende Entwicklung und Einführung einer intelligenten und sicheren Middleware-Cloudplattform für gemeinsame europäische Datenräume im Einklang mit der Strategie für eine Datenunion unterstützen.

<a id="rec-15"></a>
(15) Außerdem sollten die Cloud- und KI-Führungsinitiativen die Entwicklung von Technologien fördern, die auf offenen Standards, offenen Spezifikationen und Quelloffenheit beruhen, und die Entwicklung innovativer, wettbewerbsfähiger und resilienter Cloud- und KI-Technologien vorantreiben. Sie sollten die Arbeit an offenen Standards und Spezifikationen und die Schaffung von Grundlagen für quelloffene Software zur Unterstützung des Entwurfs, der Entwicklung und der Pflege quelloffener Komponenten fördern und dafür insbesondere Governance- und Koordinierungsmechanismen bereitstellen und die Bündelung von Ressourcen erleichtern. Ferner sollten die Cloud- und KI-Führungsinitiativen einen Katalog von Software-Werkzeugen, einschließlich quelloffener Software, erstellen, um ein Zusammenführen bestehender Kataloge für den privaten und öffentlichen Sektor zu ermöglichen und eine zentrale Anlaufstelle für quelloffene Ressourcen in der Union aufzubauen.

<a id="rec-16"></a>
(16) Grenz-KI-Technologien schreiten rasch voran und werden voraussichtlich tiefgreifende Auswirkungen auf die Wirtschaft und Gesellschaft der Union haben. Da diese Technologien zu kritischen strategischen Vermögenswerten geworden sind, ist die Stärkung der Fähigkeit der Union, sie selbst zu entwickeln und zu steuern, von entscheidender Bedeutung, damit sich der KI-Übergang im Einklang mit den Werten, Sicherheitsstandards und langfristigen wirtschaftlichen Interessen der Union vollzieht. Durch die Unterstützung von Pionierprojekten sollte die Union wesentliche Durchbrüche ausweiten, um so einen Wettbewerbsvorteil in der globalen digitalen Wirtschaft zu erlangen. Die Förderung der Entwicklung von Grenz-KI-Technologien als strategische Vermögenswerte sollte auch die derzeitige Abhängigkeit von Technologien aus Drittländern verringern und das KI-Ökosystem der Union stärken helfen.

<a id="rec-17"></a>
(17) Das Aufkommen physischer KI, d. h. von KI-Systemen und -Modellen, die in der Lage sind, ihr physisches Umfeld wahrzunehmen und komplexe Aufgaben in diesem Umfeld auszuführen, stellt eine vielversprechende Grenze dar, an der fortgeschrittene digitale Intelligenz in greifbare Systeme wie Roboter, autonome Drohnen und selbstfahrende Fahrzeuge integriert wird. Physische KI ist ein entscheidender Faktor, um externe Abhängigkeiten zu verringern und die industrielle Wettbewerbsfähigkeit und strategische Autonomie zu steigern. Sie erfordert ein spezielles Konzept für Daten- und Recheninfrastrukturen. Deshalb ist es notwendig, die Erhebung und Aufbereitung hochwertiger Daten und den Zugang zu Rechenressourcen zu erleichtern. Darüber hinaus wird eine gezielte Unterstützung der Erprobung und Validierung von Modellen und Systemen der physischen KI in vielfältigen realen Umgebungen benötigt, um deren Robustheit und Zuverlässigkeit zu gewährleisten.

<a id="rec-18"></a>
(18) Der digitale Umbau der Schlüsselindustrien der Union ist eine zentrale Säule der Strategie „KI anwenden“. Die Beschleunigung der KI-Einführung in solchen strategischen Sektoren ist von entscheidender Bedeutung, um die globale Wettbewerbsfähigkeit aufrechtzuerhalten und den gesellschaftlichen Nutzen zu steigern. Die Cloud- und KI-Führungsinitiativen sollten die Entwicklung und Verbreitung industrieller KI in den strategischen Industrie- und Dienstleistungssektoren der Union beschleunigen und gleichzeitig die technologische Entwicklung hochleistungsfähiger sektorspezifischer KI-Modelle vorantreiben, die so konzipiert sind, dass sie den betrieblichen Anforderungen der Wirtschaftszweige entsprechen, die im Rahmen der Strategie „KI anwenden“ Priorität haben, wie Gesundheitswesen, Verkehr, einschließlich Luft- und Raumfahrt, Automobilindustrie, Fertigung, Verteidigung und Weltraum, Klima und Umwelt sowie Agrar- und Ernährungswirtschaft. Darüber hinaus sollten die Cloud- und KI-Führungsinitiativen auch die Entwicklung von Dienstleistungssektoren, die zu den Prioritäten der Strategie „KI anwenden“ zählen, sowie wissenschaftliche Entdeckungen als Prioritäten der europäischen Strategie für KI in der Wissenschaft, ganz im Einklang mit der Mitteilung COM(2025) 724 final, beschleunigen.

<a id="rec-19"></a>
(19) Im Gesundheitswesen sollten diese Fortschritte die Genauigkeit klinischer Entscheidungen verbessern und den Arzneimittelsektor tiefgreifend verändern. Im Automobilsektor sollten sie die Entwicklung, Erprobung und Einführung innovativer Softwareplattformen unterstützen, die zur industriellen Führungsrolle der Union bei softwaredefinierten Fahrzeugen und beim autonomem Fahren beitragen. Die Cloud- und KI-Führungsinitiativen sollten auch Hindernisse bei der Erprobung und Einführung von KI-Modellen verringern helfen, insbesondere in Städten und Regionen, die zur Entwicklung einer Führungsrolle der Union bei softwaredefinierten Fahrzeugen und beim autonomen Fahren beitragen. Überdies sollten die Mitgliedstaaten die Entwicklung, Erprobung und Einführung von KI-Systemen für autonomes Fahren erleichtern, und zwar unter anderem durch ihre Zusammenarbeit mit den KI-Zentren, der Automobilindustrie, Zulieferern, Städten und Regionen, um die sichere und vertrauenswürdige Einführung KI-gestützter Lösungen für eine vernetzte und autonome Mobilität in vielfältigen europäischen Umgebungen zu ermöglichen. Auf dem Gebiet der Fertigung sollte die Kommission die sektorenübergreifende Datenbündelung durch vertrauenswürdige Dritte erleichtern, damit spezialisierte KI-Modelle trainiert werden können, und so – unter strikter Beachtung der Rechte des geistigen Eigentums – für eine ausreichende Menge an verfügbaren Trainingsdaten sorgen. Es sollten sichere und nachprüfbare Rechenkonzepte erkundet werden, um den Einsatz von KI auch in sensiblen Kontexten zu ermöglichen. Im Verteidigungssektor, in dem sich KI zu einer bahnbrechenden Technologie mit beträchtlichen Auswirkungen auf die Sicherheit und Verteidigung entwickelt, könnten die Cloud- und KI-Führungsinitiativen die Entwicklung fortgeschrittener Fähigkeiten unterstützen und die speziellen Instrumente der Union zur Unterstützung der Verteidigungsindustrie, einschließlich des Europäischen Verteidigungsfonds (EVF) und des Programms für die europäische Verteidigungsindustrie (EDIP), in großem Umfang ergänzen, ohne darin einzugreifen. Im Weltraumsektor sollten die digitalen Fortschritte die Art und Weise verändern, wie Weltraumressourcen, -dienste und -datenströme betrieben und verwendet werden, und im Verkehrsbereich sollten die digitalen Fortschritte gerade in der Luftfahrt die Art und Weise verändern, wie der Betrieb verwaltet wird, wobei mit KI die über Jahrzehnte angehäuften Missions-, Betriebs- und Beobachtungsdaten nutzbar gemacht werden könnten. Im Klima- und Umweltbereich sollte eine Geodaten-KI entwickelt werden, die sich insbesondere die Erdbeobachtungsdaten des Programms Copernicus und ganz allgemein die Fähigkeiten der Weltraum- und Konnektivitätsprogramme der Union^(15) zunutze machen könnte. In der Landwirtschaft kann KI die von Sensoren, Satelliten und landwirtschaftlichen Maschinen erfassten Daten in verwertbare Erkenntnisse für Landwirte verwandeln. Sie kann die Wettbewerbsfähigkeit und Resilienz steigern, indem sie beispielsweise Ertragsprognosen verbessert, eine frühzeitige Erkennung von Schädlingen und Krankheiten ermöglicht, die Bewässerung und den Einsatz von Düngemitteln optimiert und eine nachhaltigere Lebensmittelerzeugung unterstützt. Da der Einsatz von KI in industriellen Umfeldern eine strenge Validierung in realen Umgebungen voraussetzt, sollte die Union den Beteiligten aus der Industrie cloudgestützte KI-Werkzeuge und Testumgebungen zur Verfügung stellen.

<a id="rec-20"></a>
(20) Die Union sollte auch die Verfügbarkeit hochsicherer Recheninfrastrukturen für das Trainieren, das Testen und den Einsatz verteidigungsbezogener KI-Modelle und -Systeme fördern.

<a id="rec-21"></a>
(21) In dem Maße wie KI-Agenten immer leistungsfähiger werden und KI-Anwendungen immer stärker in reale Geschäftsszenarien eingebettet werden, geht die Branche rasch zu einem neuen Paradigma über, das solche Systeme mit autonomen Ausführungsfähigkeiten versieht. Angesichts der strengen technischen Anforderungen an KI-Plattformen macht dieser Übergang zu einem neuen Paradigma einen robusten technischen Rahmen erforderlich, der die Sicherheit, Genauigkeit und Rechtmäßigkeit solcher Systeme gewährleistet. Dementsprechend sollten die Cloud- und KI-Führungsinitiativen das Ziel verfolgen, souveräne und sichere KI-Plattformen für die groß angelegte Einführung und Orchestrierung fortgeschrittener KI-Agenten einzurichten. Diese Plattformen sollten durch innovative Orchestrierungsrahmen unterstützt werden, die Transparenz und Rechenschaftspflicht beim Zusammenwirken vieler KI-Agenten gewährleisten. Ebenso ist es notwendig, die Entwicklung strenger Test- und Versuchsmethoden für KI-Agenten und die Orchestrierung zu erleichtern, um ein unbeabsichtigtes autonomes Verhalten zu minimieren.

<a id="rec-22"></a>
(22) Die Cloud- und KI-Führungsinitiativen sollten die Entwicklung und Einführung von KI-Modellen und -Systemen im gesamten öffentlichen Sektor der Union fördern. Solche KI-Modelle und -Systeme sollten insbesondere eingesetzt werden, um eine bessere Entscheidungsfindung zu unterstützen, Verwaltungsverfahren zu vereinfachen und unnötigen Aufwand zu verringern, und zwar vor allem in wichtigen öffentlichen Bereichen wie dem Gesundheitswesen, in denen die Weiterverwendung von Daten für KI-Modelle und -Werkzeuge unter Wahrung der Sicherheit und des Datenschutzes erleichtert werden sollte. Zu diesem Zweck ist es angebracht, Maßnahmen zu ergreifen, um die Qualität der Daten des öffentlichen Sektors zu verbessern und den Austausch und die Weiterverwendung von Trainingsdaten und KI-Modellen im gesamten öffentlichen Sektor der Union zu fördern und somit eine Fragmentierung zu vermeiden und die Ausweitung erfolgreicher, nutzerorientierter Lösungen zu ermöglichen.

<a id="rec-23"></a>
(23) Die Cloud- und KI-Führungsinitiativen sollten dazu beitragen, die Einführung von KI und Cloud-Computing in großem Maßstab, auch auf regionaler und lokaler Ebene, zu beschleunigen. Eine breite Einführung von KI im privaten und öffentlichen Sektor sollte durch das Netz der KI-Zentren gefördert werden. Ausgehend von diesem Netz sollten ergänzende Unterstützungsmaßnahmen ausgearbeitet werden, die dazu beitragen, das im Beschluss (EU) 2022/2481 des Europäischen Parlaments und des Rates^(16) (im Folgenden „Politikprogramm 2030 für die digitale Dekade“) festgelegte Ziel des digitalen Umbaus der Unternehmen zu erreichen. Überdies sollte ein Lehrplan eigens für Cloud-Computing- und KI-Kompetenzen aufgestellt werden, um Arbeitskräften sowohl im öffentlichen wie auch im privaten Sektor fortgeschrittene Kompetenzen zu vermitteln, die Abhängigkeit von außereuropäischen Anbietern zu verringern und Fähigkeiten der nächsten Generation aufzubauen – ganz im Einklang mit der Unionspolitik auf dem Gebiet der Bildung, Ausbildung und Kompetenzen sowie der Mitteilung zur Union der Kompetenzen^(17).Dieser Lehrplan sollte, soweit zutreffend, auf einschlägigen europäischen Initiativen aufbauen, darunter auf der Akademie für KI-Kompetenzen, den KI-Zentren und der Akademie für ein interoperables Europa, und Beteiligte mit der erforderlichen Sachkenntnis einbeziehen.

<a id="rec-24"></a>
(24) Die Cloud- und KI-Führungsinitiativen sollten auch auf die Einführung von Cloud-Computing-Diensten durch europäische Anbieter von Cloud-Computing-Diensten im öffentlichen und privaten Sektor hinwirken, damit die Cloud-Einführung dem Ziel der Stärkung der technologischen Autonomie der Union dient, und zwar insbesondere in Sektoren wie Gesundheitswesen und Bildung, in denen kritische Daten verarbeitet werden. Bei der Verfolgung dieses Ziels könnte auf die Arbeitsergebnisse einschlägiger Konsortien für europäische digitale Infrastrukturen (EDICs), darunter auch auf gemeinsame Infrastrukturen, gemeinsame Normen und bewährte Verfahren, zurückgegriffen werden. Die Cloud- und KI-Führungsinitiativen sollten die Einrichtung des Europäischen Cloud-Verbunds des öffentlichen Sektors (im Folgenden „EuroCloud-Verbund“) im Rahmen dieser Verordnung unterstützen, um die gemeinsame Nutzung sicherer und resilienter Rechenzentrumsdienste und Cloud-Computing-Dienste des öffentlichen Sektors zu erleichtern. Darüber hinaus sollten die Cloud- und KI-Führungsinitiativen die Auftragsvergabetätigkeiten der Kommission für die Organe, Einrichtungen und sonstige Stellen der Union (im Folgenden „Einrichtungen der Union“), aber auch für nationale öffentliche Auftraggeber in der gesamten Union unterstützen, da die Vergabe von Aufträgen für digitale Dienstleistungen nicht nur die Digitalisierung öffentlicher Stellen voranbringen, sondern diese auch in die Lage versetzen sollte, ihre Kaufkraft einzusetzen und die Einführung resilienter und sicherer digitaler Lösungen zu beschleunigen.

<a id="rec-25"></a>
(25) Die Mitgliedstaaten sollten KI-Erfahrungs- und Beschleunigungszentren (im Folgenden „KI-Zentren“) einrichten, um eine angemessene Betreuung in ihrem Hoheitsgebiet sicherzustellen. KI-Zentren sollen als regionale und lokale Beschleuniger für die Übernahme und den Einsatz von KI, Cloud-Computing und anderen fortgeschrittenen Technologien in der gesamten Union dienen und KMU, kleine Midcaps und öffentliche Stellen bei ihrem digitalen Umbau unterstützen. Um die Integration von KI in strategische Industriezweige zu erleichtern, sollten KI-Zentren auch Synergien mit den im Rahmen der Strategie für eine Datenunion eingeleiteten Initiativen anstreben. Durch die Bereitstellung von Sachkenntnis, Testmöglichkeiten, Kompetenzen und Innovationsförderung sollten die KI-Zentren die Wettbewerbsfähigkeit und Resilienz der industriellen Basis der Union im KI-Bereich stärken und gleichzeitig die Innovationskapazitäten und die breite Einführung von KI und anderen fortgeschrittenen Technologien in der gesamten Union fördern. Ihr Netz sollte auf dem bestehenden Netz europäischer digitaler Innovationszentren aufbauen. Das Netz sollte eng mit anderen Initiativen zur Förderung der Einführung von KI und anderen fortgeschrittenen Technologien wie den Test- und Versuchseinrichtungen und KI-Fabriken zusammenarbeiten. Es sollte auf kompetenzbezogenen Initiativen aufbauen, wie etwa auf der groß angelegten Kompetenzpartnerschaft für Digitales im Rahmen des Kompetenzpakts und auf den Kompetenzakademien, einschließlich der Akademie für KI-Kompetenzen.

<a id="rec-26"></a>
(26) Mit der Umsetzung der Cloud- und KI-Führungsinitiativen sollten die Kommission und die Mitgliedstaaten betraut werden. Die Umsetzung der Cloud- und KI-Führungsinitiativen sollte außerdem gegebenenfalls einer anderen Struktur anvertraut werden, die über geeignete Sachkenntnis und angemessene Ressourcen verfügt. Insbesondere sollte es – unbeschadet des nächsten mehrjährigen Finanzrahmens (2028-2034) – möglich sein, die Umsetzung der Cloud- und KI-Führungsinitiativen gemeinsamen Unternehmen wie dem mit der Verordnung (EU) 2021/2085 des Rates^(18) gegründeten Gemeinsamen Unternehmen für intelligente Netze und Dienste (im Folgenden „GU SNS“) oder dem mit der Verordnung (EU) 2021/1173 des Rates^(19) gegründeten Gemeinsamen Unternehmen für europäisches Hochleistungsrechnen (im Folgenden „GU EuroHPC“) und gegebenenfalls deren Nachfolgern zu übertragen.

<a id="rec-27"></a>
(27) Die operativen Ziele der Cloud- und KI-Führungsinitiativen sollten insbesondere anhand ehrgeiziger, zukunftsorientierter Zielsetzungen verwirklicht werden, die darauf ausgerichtet sind, in den Bereichen Infrastrukturentwicklung, Cloud-Computing und KI den aktuellen Stand der Technik zu übertreffen. Die Cloud- und KI-Führungsinitiativen sollten daher wichtige strategische „Große Herausforderungen“ unterstützen, deren Schwerpunkt auf der Entwicklung und Einführung modernster Cloud- und KI-Technologien und -Infrastrukturen liegt, die für die Union von großer Bedeutung sind. Diese Großen Herausforderungen sollten auf jenen aufbauen, die in der Verordnung (EU) 2026/XXX [Chip-Verordnung 2.0] über einen Rahmen für Maßnahmen zur Stärkung des europäischen Halbleiter-Ökosystems festgelegt wurden und darauf abzielen, Halbleitertechnologien zu ermöglichen, die als Voraussetzungen für KI, Cloud-Computing, Rechenzentren und Edge-Infrastrukturen gelten.

<a id="rec-28"></a>
(28) Die Cloud- und KI-Führungsinitiativen können im Einklang mit der Verordnung (EU) 2021/694^(20), der Verordnung (EU) 2021/695^(21) und der Verordnung (EU) 2021/523^(22) mit Mitteln aus Unionsprogrammen und anderen Instrumenten, insbesondere aus dem Programm Horizont Europa und dem Programm Digitales Europa, sowie aus dem Programm InvestEU unterstützt werden. Auch im Zuge des Mehrjährigen Finanzrahmens 2028-2034 könnten die Cloud- und KI-Führungsinitiativen aus nachfolgenden Unionsprogrammen – vorbehaltlich ihrer Annahme und gemäß ihren jeweiligen Rechtsgrundlagen – weiterhin unterstützt werden.

<a id="rec-29"></a>
(29) Zusätzlich zur Finanzierung aus Unionsprogrammen können die Cloud- und KI-Führungsinitiativen von den Mitgliedstaaten unterstützt werden, und zwar durch Forschungs-, Entwicklungs- und Innovationsmaßnahmen, soweit dies im Einklang mit den geltenden Vorschriften über staatliche Beihilfen geschieht und die Kohärenz zwischen den nationalen Strategien und der Politik der Union sichergestellt wird, sowie auch durch Investitionen des Privatsektors. Insbesondere sollten Interessenträger des Privatsektors dazu ermuntert werden, die Cloud- und KI-Führungsinitiativen bei der Aufstellung ihrer eigenen Investitionsstrategien für Cloud-Computing und KI zu berücksichtigen. Auf diese Weise können private Investitionen dazu beitragen, einen kohärenten und koordinierten Investitionspfad zu schaffen, der mit den übergeordneten politischen Zielen und den langfristigen Umsetzungszielen der Cloud- und KI-Führungsinitiativen im Einklang steht.

<a id="rec-30"></a>
(30) Die Kommission sollte sich bei der Umsetzung der Cloud- und KI-Führungsinitiativen von Interessenträgern mit entsprechender Sachkenntnis beraten lassen. Die Kommission sollte insbesondere die Zusammenarbeit mit bestehenden Experten- und Beratungsforen wie der Allianz für Industriedaten, Edge und Cloud, der KI-Anwendungsallianz und der Industrieallianz für Halbleiter ausbauen. Die Allianz für Industriedaten, Edge und Cloud sollte als Forum für den Austausch der verschiedenen Interessenträger im Bereich der Edge- und Cloud-Technologien der nächsten Generation dienen und Unternehmen, Vertreter der Mitgliedstaaten und andere einschlägige Sachverständige einbeziehen. Sie sollte der Kommission dabei helfen, strategische Investitionsfahrpläne aufzustellen, um die nächste Generation hochsicherer, verteilter, interoperabler und ressourceneffizienter Rechentechnologien zu ermöglichen. Die KI-Anwendungsallianz sollte als Koordinierungsforum für KI-Interessenträger und politische Entscheidungsträger fungieren, um die Gespräche über das Potenzial der KI in strategischen Sektoren der Union voranzubringen. Die KI-Anwendungsallianz sollte an der Verwirklichung der Ziele der Strategie „KI anwenden“ mitwirken, insbesondere durch die Organisation von Branchenworkshops, die Ermittlung und Bewertung neuer KI-Anwendungsfälle in strategischen Sektoren und Vorschläge für konkrete unterstützende politische Maßnahmen. Neben der KI-Anwendungsallianz sollte die KI-Beobachtungsstelle robuste Indikatoren zur Bewertung der Auswirkungen der KI auf strategische Sektoren bereitstellen, technische Entwicklungen und Trends beobachten und die Veränderungen verfolgen, die sie auf dem Arbeitsmarkt verursachen können.

<a id="rec-31"></a>
(31) Die Cloud- und KI-Führungsinitiativen sollten Synergien mit anderen Maßnahmen verstärken, die derzeit von der Union und den Mitgliedstaaten unterstützt werden, unter anderem auch im Rahmen des Programms Horizont Europa und des Programms Digitales Europa sowie der Verordnung (EU) 2021/1173 des Rates und der Verordnung (EU) 2026/XXX [Chip-Verordnung 2.0] über einen Rahmen für Maßnahmen zur Stärkung des europäischen Halbleiter-Ökosystems. Die Kommission und die Mitgliedstaaten sollten für Kohärenz, Komplementarität und Synergien zwischen den Cloud- und KI-Führungsinitiativen und einschlägigen nationalen und regionalen Strategien, Programmen und Investitionsplänen sorgen, auch denjenigen, die im Rahmen nationaler Reformprogramme, Strategien für intelligente Spezialisierung, Aufbau- und Resilienzpläne und anderer nationaler oder regionaler Finanzierungsinstrumente zur Unterstützung der Ziele der Cloud- und KI-Führungsinitiativen durchgeführt werden. Eine solche Koordinierung sollte darauf abzielen, die Wirkung öffentlicher Investitionen zu maximieren, Doppelfinanzierung zu vermeiden, die Abstimmung der Prioritäten auf allen Regierungs- und Verwaltungsebenen zu fördern und die Ausweitung und Verbreitung von Ergebnissen in der gesamten Union zu erleichtern.

<a id="rec-32"></a>
(32) Damit die politischen Maßnahmen der Union und der Mitgliedstaaten aufeinander abgestimmt werden, sollten die Mitgliedstaaten entsprechend dem Aktionsplan für den KI-Kontinent und der Strategie „KI anwenden“ eigene nationale Strategien aufstellen, die dazu beitragen, die Unionsziele für die Cloud- und KI-Entwicklung zu erreichen. Die nationalen Strategien sollten insbesondere dem in der Strategie „KI anwenden“ festgelegten Grundsatz „Zuerst KI“ Rechnung tragen, mit dem Organisationen nachdrücklich dazu angehalten werden, über ihre Geschäftsprozesse nachzudenken und dabei die Erfordernisse der KI und die durch KI eröffneten Chancen ebenso wie die potenziellen Risiken zu berücksichtigen. Die nationalen Cloud- und KI-Strategien sollten auch auf die damit verbundenen Digitalziele gemäß dem Beschluss (EU) 2022/2481^(23) abgestimmt werden, insbesondere in Bezug auf die Einführung von Cloud-Computing-Diensten, Big Data und KI durch mindestens 75 % der Unternehmen in der Union für ihre Geschäftstätigkeiten und die Errichtung von mindestens 10 000 klimaneutralen, hochsicheren Randknoten mit geringer Latenz in der Union. Die im Rahmen der nationalen Strategien beschlossenen Maßnahmen könnten auch in die nationalen strategischen Fahrpläne für die digitale Dekade (im Folgenden „nationale Fahrpläne“) einfließen.

<a id="rec-33"></a>
(33) Wenn ein Mitgliedstaat bereits eine nationale Strategie angenommen hat, die die in dieser Verordnung festgelegten Ziele angemessen abdeckt, so sollte er nicht dazu verpflichtet sein, eine andere weitere Strategie aufzustellen. Stellt ein Mitgliedstaat jedoch im Hinblick auf diese Ziele Lücken in seiner bestehenden Strategie fest, so sollte er diese Strategie entsprechend aktualisieren. Das mit der Verordnung über künstliche Intelligenz eingerichtete Europäische Gremium für Künstliche Intelligenz (im Folgenden „KI-Gremium“) spielt eine zentrale Rolle bei der Gewährleistung der kohärenten und wirksamen Umsetzung der KI-Politik der Union. Da das Cloud-Computing die Grundlage und Voraussetzung für den KI-Einsatz bildet, sollte das KI-Gremium als Plattform dienen, um die Zusammenarbeit und Koordinierung der Tätigkeiten im Zusammenhang mit der KI-Einführung zwischen der Union und den Mitgliedstaaten zu erleichtern. Zur Wahrnehmung dieser Aufgabe sollte das KI-Gremium über die erforderliche Sachkenntnis verfügen und sich auf eine angemessene Beteiligung stützen können.

<a id="rec-34"></a>
(34) Angesichts des beispiellosen Umfangs der Ressourcen, die für die Entwicklung von Grenz-KI erforderlich sind, ist es notwendig, Kriterien für die Einstufung eines Projekts als vorrangiges Grenz-KI-Projekt festzulegen. Solche Projekte sollten die Entwicklung und Ausweitung von Grenz-KI-Technologien – insbesondere im Bereich der Cybersicherheit – unterstützen. Angesichts ihrer technischen Komplexität und ihrer Kapitalintensität machen die Projekte ein kooperatives Vorgehen auf Unionsebene erforderlich. Es ist daher geboten, sie zu einer breiten Einbeziehung von Einrichtungen aus der gesamten Union zu verpflichten, und zwar insbesondere über die mit dem Beschluss (EU) 2022/2481 eingerichteten EDICs oder eine andere rechtliche Struktur, die einen erheblichen Teil der Unionsinteressen vertreten kann.

<a id="rec-35"></a>
(35) Die Union und die Mitgliedstaaten sollten der Zuweisung ausreichender KI-Rechenressourcen für vorrangige Grenz-KI-Projekte eine strategische Bedeutung beimessen. Der Unionsanteil daran sollte im Rahmen der verfügbaren europäischen Hochleistungsrechenkapazitäten („EuroHPC“) bleiben und proportional zu den KI-Rechenressourcen sein, die von den Mitgliedstaaten zu den benannten vorrangigen Grenz-KI-Projekten beigetragen oder zugesagt werden. Die Union und die Mitgliedstaaten sollten auch ausreichende Rechenzeit für KI-Projekte für industrielle Innovationen, für Projekte für physische KI und für KI-Projekte des öffentlichen Sektors bereitstellen. Die in der Verordnung (EU) 2021/1173 des Rates festgelegten Vorschriften und Verfahren bleiben hiervon unberührt. Die Zugangsregelung des GU EuroHPC sollte so gestaltet werden, dass sie eine effiziente, transparente und zeitnahe Zuweisung solcher Rechenressourcen ermöglicht, ohne die Kontinuität des laufenden Betriebs und die Rechte von Projekten zu beeinträchtigen, die ihnen bereits zugewiesene KI-Rechenressourcen des GU EuroHPC nutzen.

<a id="rec-36"></a>
(36) Zur Verwirklichung der KI-Bestrebungen der Union ist es notwendig, digitale Infrastrukturen auszubauen, darunter auch Cloud- und Edge-Kapazitäten, die das Trainieren, die Feinabstimmung, die Einführung und den Echtzeitbetrieb ermöglichen, und die entsprechenden Investitionen zu tätigen. Die unionsweite Errichtung von Rechenzentren ist im Rückstand und nach wie vor nur auf eine geringe Zahl etablierter Knotenpunkte konzentriert, was zu strukturellen Ungleichgewichten zwischen den Mitgliedstaaten und zu Ineffizienzen wie höheren Kosten, erhöhter Latenz in Randgebieten, ungleichen Chancen für Unternehmen und einem langsameren digitalen Wandel führt. Die Steigerung und die geografisch ausgewogene Verteilung der Rechenzentrumskapazitäten in der gesamten Union sind auch wichtig, um die Abhängigkeiten von externen Infrastrukturen zu verringern, die Risiken für die wirtschaftliche Sicherheit zu mindern und die Wettbewerbsfähigkeit, Resilienz und Souveränität der Union zu untermauern.

<a id="rec-37"></a>
(37) Rechenzentren sind kritische Infrastrukturen für die Union und können einen erheblichen wirtschaftlichen Wert schaffen, einschließlich wertvoller Investitionen und Arbeitsplätze; sie können auch Innovationsökosysteme unterstützen – insbesondere, wenn sie mit den lokalen Bedürfnissen verknüpft werden und bewährten Verfahren folgen. Bei ordnungsgemäßer Verwaltung kann die Ausweitung der Rechenzentrumskapazitäten in der Union erhebliche wirtschaftliche und strategische Vorteile bringen, zur Modernisierung des Energiesystems beitragen, die Zunahme sauberer Energie fördern und die nachhaltige Energienutzung unterstützen. All dies hängt von der Einführung eines angemessenen Rahmens ab, der negative Folgen wie Energieversorgungsschwierigkeiten, negative Umweltauswirkungen und entgangene Chancen verhindert. Beschleunigungsgebiete für Rechenzentren (im Folgenden „Beschleunigungsgebiete“) sollten zu diesem Ziel beitragen, indem sie einen groß angelegten und zügigen Infrastrukturaufbau innerhalb eines klaren und gestrafften Rechtsrahmens ermöglichen.

<a id="rec-38"></a>
(38) Wenn Kapazitäten im Hoheitsgebiet der Mitgliedstaaten aufgebaut werden, sollten Beschleunigungsgebiete ausgewiesen werden, in denen die Entwicklung, Ausweitung und Modernisierung von Rechenzentren erleichtert werden kann. Die Ausweisung solcher Gebiete sollte dazu beitragen, die Kapazitätslücke in der Union zu schließen, die Wettbewerbsfähigkeit, Autonomie und technologische Resilienz der Union zu steigern und gleichzeitig für die Einhaltung des geltenden Unionsrechts zu sorgen, einschließlich der Anforderungen in Bezug auf Energieeffizienz und Umweltschutz. Eine ausreichende und rechtzeitige Energieversorgung in den Beschleunigungsgebieten ist eine grundlegende Voraussetzung für ihren wirksamen Ausbau und für die Entwicklung von Rechenzentrumskapazitäten in gesamten Union. Zuverlässige und genaue Informationen über den künftigen Energiebedarf tragen zu einem kosteneffizienten Stromnetzausbau bei. Die Mitgliedstaaten sollten daher für jedes Beschleunigungsgebiet eine Analyse erstellen, in der sein gegenwärtiger und künftiger Energiebedarf ermittelt wird. Eine solche Analyse sollte dazu dienen, Informationen für die nationale Netzplanung bereitzustellen und so zu gezielten, vorausschauenden Netzinvestitionen und schnelleren Energieanschlüssen für das Beschleunigungsgebiet beizutragen. Bei der Festlegung des Anwendungsbereichs sollten die Mitgliedstaaten die Verfügbarkeit der einschlägigen Verkehrs- und Netzinfrastruktur berücksichtigen. Die Ergebnisse dieser Bewertungen sollten in die nationalen Netzentwicklungspläne einfließen, um bei der künftigen Netzplanung Punkte, an denen in der Zukunft Energiebedarf bestehen wird, angemessen erfassen zu können. Damit Beschleunigungsgebiete die richtigen Rahmenbedingungen für den Kapazitätsaufbau bieten, sollten die Mitgliedstaaten klare und effiziente Verfahren für den Stromnetzanschluss und flexible Netzanschlussverträge fördern und gegenüber den Betreibern von Rechenzentren die Bedingungen für den Netzanschluss gemäß der Richtlinie (EU) 2019/944 klarstellen. Ein anstehender Legislativvorschlag für zukunftssichere Stromrechnungen in der EU wird Anreize für eine optimale und kosteneffiziente Nutzung der Stromnetzinfrastrukturen und für einen systemfreundlichen Verbrauch geben. Strombezugsverträge sind wichtige Instrumente für Rechenzentren, da sie eine langfristige Preisstabilität bieten und es den Betreibern von Rechenzentren ermöglichen, sauberen Strom in großem Maßstab zu beziehen, was einen zuverlässigen Betrieb ebenso wie den Übergang zu einem sauberen Energiesystem unterstützt. Die Mitgliedstaaten sollten daher – auch in Beschleunigungsgebieten – den Abschluss von Strombezugsverträgen fördern, indem sie ungerechtfertigte Hindernisse und unverhältnismäßige oder diskriminierende Verfahren oder Entgelte beseitigen, um so vorhersehbare Preise zu gewährleisten.

<a id="rec-39"></a>
(39) Bei der Festlegung von Nachhaltigkeitsanforderungen für Rechenzentren, die in Beschleunigungsgebieten für Rechenzentren errichtet werden, sollten die Mitgliedstaaten sicherstellen, dass die in der Delegierten Verordnung (EU) 2024/1364 der Kommission^(24) im Einklang mit der Richtlinie (EU) 2023/1791 des Europäischen Parlaments und des Rates^(25) festgelegten wesentlichen Leistungsindikatoren verwendet werden. Ziel ist es, kohärente Umweltstandards zu gewährleisten, die Energieeffizienz zu steigern und die Verwirklichung der übergeordneten Klima-, Umwelt- und Nachhaltigkeitsziele der Union in Beschleunigungsgebieten zu unterstützen. Um darüber hinaus eine spekulative Reservierung von Ressourcen in Beschleunigungsgebieten zu verhindern und einen fairen, angemessenen und diskriminierungsfreien Zugang zu gewährleisten, der einen wirksamen Wettbewerb bewahrt und die rechtzeitige und effiziente Entwicklung von Beschleunigungsgebieten unterstützt, sollten die Mitgliedstaaten dafür sorgen, dass die Zuweisung und Nutzung von Ressourcen innerhalb dieser Gebiete unter fairen, angemessenen und diskriminierungsfreien Bedingungen erfolgt und keine spekulativen Reservierungs- oder Abschottungspraktiken entstehen, die geeignet wären, einen wirksamen Wettbewerb oder die wirksame Entwicklung oder Nutzung dieser Gebiete zu behindern.

<a id="rec-40"></a>
(40) Um den Aufbau von Rechenzentrumsprojekten in Beschleunigungsgebieten zu erleichtern und zu beschleunigen, sollten die Mitgliedstaaten zentrale Informationsstellen benennen oder, soweit möglich, die gemäß der Verordnung (EU) 2024/1309 des Europäischen Parlaments und des Rates^(26) benannten Stellen diesbezüglich modernisieren oder integrieren.

<a id="rec-41"></a>
(41) Mit der Verordnung (EU) 202X/XXX [zur Beschleunigung von Umweltprüfungen]^(27) wird ein gemeinsamer Rahmen für die Beschleunigung von Umweltprüfungen geschaffen, um die Einführung von Schlüsseltechnologien in der Union anzukurbeln, Abhängigkeiten zu verringern und die Wettbewerbsfähigkeit zu steigern. In allen Wirtschaftszweigen sollten die Verfahren im Zusammenhang mit Umweltprüfungen für Pläne, Programme und Projekte beschleunigt und gestrafft werden, wobei gleichzeitig ein hohes Schutzniveau für die menschliche Gesundheit und die Umwelt aufrechterhalten werden sollte. In einigen Sektoren können jedoch noch schnellere Umweltprüfungen erforderlich sein. Um die Kohärenz des Rechtsrahmens für Umweltprüfungen zu gewährleisten und gleichzeitig der Notwendigkeit einer beschleunigten Einführung in bestimmten strategischen Sektoren Rechnung zu tragen, wird mit der Verordnung (EU) 202X/XXX [zur Beschleunigung von Umweltprüfungen] ein spezielles Instrumentarium geschaffen. Angesichts ihrer Rolle bei der Verwirklichung der Klima- und Umweltziele der Union aufgrund ihres Beitrags zur Verbesserung der Energieeffizienz, durch den die Integration sauberer Energie ermöglicht wird und die für intelligentere Netze, Verkehrssysteme und CO2-arme Technologien erforderlichen Infrastrukturen bereitgestellt werden, sowie angesichts ihres Beitrags zur Resilienz und wirtschaftlichen Sicherheit der Union, durch den eine zuverlässige Infrastruktur in der Union zum Schutz kritischer Dienste gewährleistet und die Fähigkeit der Union zur Aufrechterhaltung eines unabhängigen Betriebs gestärkt wird, sollten Rechenzentrumsprojekte, die in Beschleunigungsgebieten durchgeführt werden, als strategische Projekte im Sinne der Verordnung (EU) 202X/XXX [zur Beschleunigung von Umweltprüfungen] angesehen werden und daher von dem mit der genannten Verordnung festgelegten speziellen Instrumentarium profitieren. Die Mitgliedstaaten sollten eine aggregierte Grundgenehmigung einführen, die die besonderen Merkmale jedes ausgewiesenen Beschleunigungsgebietes widerspiegelt. Diese aggregierte Grundgenehmigung, die von Behörden erteilt wird, sollte die üblicherweise für solche Tätigkeiten in dem Gebiet erforderlichen Genehmigungen abdecken, mit Ausnahme der Genehmigungen für den Stromnetzanschluss.

<a id="rec-42"></a>
(42) Die Kommission sollte die Möglichkeit haben, Rechenzentrumsprojekte, die einen erheblichen Beitrag zur Entwicklung des Digitalsektors und des Energiesektors der Union leisten und eindeutige Kriterien erfüllen, als strategische Projekte zu benennen. Angesichts der großen Bedeutung der strategischen Rechenzentrumsprojekte können die Mitgliedstaaten unbeschadet der Artikel 107 und 108 AEUV zugunsten dieser Projekte Unterstützungsmaßnahmen in verhältnismäßiger Weise anwenden. Bei der Planung solcher Unterstützungsmaßnahmen sollten die Mitgliedstaaten gegebenenfalls die einschlägigen Rahmen für die Leistung öffentlicher Unterstützung zugrunde legen. Strategische Projekte sollten ein Marktversagen auf verhältnismäßige Weise beheben, ohne private Finanzierungen zu duplizieren oder zu verdrängen, und gleichzeitig einen klaren Mehrwert für die Union aufweisen.

<a id="rec-43"></a>
(43) Unbeschadet des nächsten mehrjährigen Finanzrahmens (2028-2034) sollte strategischen Rechenzentrumsprojekten Unterstützung aus Programmen, Fonds und Finanzierungsinstrumenten der Union im Einklang mit den in den Verordnungen zur Einrichtung dieser Fonds und Programme festgelegten Zielen gewährt werden. Insbesondere sollte diesen strategischen Projekten das Wettbewerbsfähigkeitssiegel verliehen werden, wenn sie die in der Verordnung (EU) 2026/XXX [zur Einrichtung des Europäischen Fonds für Wettbewerbsfähigkeit (ECF)]^(28) festgelegten Bedingungen als hochwertige Projekte erfüllen, die zum Ziel des Europäischen Fonds für Wettbewerbsfähigkeit beitragen.

<a id="rec-44"></a>
(44) Um den strategischen Aufbau von Rechenzentrumskapazitäten in der gesamten Union zu fördern, sollte die Kommission die verfügbaren Rechenkapazitäten und das Volumen der Nachfrage nach Rechenzentrumskapazitäten beobachten und das Ausmaß der Kapazitätslücke in der gesamten Union ermitteln. Diese Beobachtung kann der Kommission als Grundlage für ihre möglichen Empfehlungen dienen. Um die Mitgliedstaaten bei der Beschleunigung des Aufbaus von Rechenzentrumskapazitäten zu unterstützen, kann die Kommission gegebenenfalls Maßnahmen zur Schließung der festgestellten Kapazitätslücke in der Union empfehlen. Im Einklang mit dem Politikprogramm 2030 für die digitale Dekade sollte die Kommission auch die Ziele der digitalen Dekade überprüfen, um den technischen, wirtschaftlichen oder gesellschaftlichen Entwicklungen sowie der Entwicklung der diesbezüglichen Prioritäten der Union Rechnung zu tragen.

<a id="rec-45"></a>
(45) Diese Verordnung sollte für die Organe, Einrichtungen und sonstigen Stellen der Union (im Folgenden „Einrichtungen der Union“) gelten, wenn sie Verfahren für die Vergabe von Aufträgen für Cloud-Computing-Dienste und KI-Systeme durchführen, die in den Anwendungsbereich dieser Verordnung fallen.

<a id="rec-46"></a>
(46) Die Union ist nach wie vor in kritischer Weise von einer begrenzten Zahl von Anbietern von Cloud-Computing-Diensten abhängig, die der Kontrolle von Drittländern oder in Drittländern niedergelassenen Rechtsträgern unterliegen. Dadurch ist die Union kritischen strategischen Abhängigkeiten und Konzentrationsrisiken ausgesetzt; dazu gehören auch Schwachstellen, die sich aus der extraterritorialen Anwendung der Rechtsvorschriften von Drittländern ergeben, sowie potenzielle Störungen, die die Kontinuität, Qualität und Resilienz von Cloud-Computing-Diensten beeinträchtigen, eine verminderte Kontrolle und Aufsicht über personenbezogene und nicht personenbezogene Daten und Infrastrukturen sowie das Risiko einer unzulässigen wirtschaftlichen oder politischen Einflussnahme durch die Kontrolle, die Drittländer oder in Drittländern niedergelassene Rechtsträger über Cloud-Computing-Dienste ausüben. Vor diesem Hintergrund ist die Fähigkeit der Union und ihrer Mitgliedstaaten, die Kontrolle über Infrastrukturen, Daten, Vermögenswerte und Technologiesysteme unter den Rechtsordnungen der Union und der Mitgliedstaaten zu behalten, zu einem zwingenden politischen Ziel geworden.

<a id="rec-47"></a>
(47) Das bestehende Unionsrecht regelt Anforderungen an die Cybersicherheit, den Datenschutz, die Interoperabilität und die Datenübertragbarkeit, die auch für Cloud-Computing-Dienste gelten. Es gibt jedoch keinen übergreifenden Rechtsrahmen der Union, der ein einheitliches Verständnis dafür schaffen würde, was hinsichtlich der Minderung solcher Risiken unter einem vertrauenswürdigen Cloud-Computing-Dienst zu verstehen ist. Einige Mitgliedstaaten haben nationale Ansätze zur Festlegung nationaler souveräner Dienste entwickelt oder sind dabei, solche zu entwickeln. Die grenzüberschreitenden Probleme im Zusammenhang mit der mangelnden Souveränität der Union im Cloud-Computing-Ökosystem können durch nationale Maßnahmen jedoch nicht angemessen behoben werden, und es besteht die Gefahr, dass der Binnenmarkt der Union dadurch fragmentiert wird und die gemeinsamen Ziele der Autonomie und Souveränität untergraben werden.

<a id="rec-48"></a>
(48) Als Reaktion auf die wachsenden Bedenken der Union hinsichtlich ihrer Souveränität haben Anbieter von Cloud-Computing-Diensten angepasste Versionen ihrer Dienstangebote eingeführt. Diese Versionen lösen jedoch nicht die Kernprobleme der Souveränität, die die extraterritoriale Anwendung der Rechtsvorschriften von Drittländern und eine mögliche Verschlechterung oder Störung der Dienste betreffen. Folglich wird die Union auf diese Weise keine Autonomie oder Kontrolle über ihre Daten, Vermögenswerte und digitalen Infrastrukturen erlangen. Der derzeitige Rahmen muss daher durch gezielte Maßnahmen auf Unionsebene ergänzt werden, nämlich durch die Einführung eines einheitlichen Mechanismus, der die langfristige Strategie der Union für technologische Autonomie, Kontrolle und Resilienz im Cloud- und KI-Ökosystem stärken kann.

<a id="rec-49"></a>
(49) Vor diesem Hintergrund machen die beträchtlich zunehmenden Bedenken hinsichtlich der öffentlichen Ordnung – einschließlich beispielsweise der Risiken für die wirtschaftliche Sicherheit – eine wirksame und kohärente Umsetzung von Schutzmaßnahmen für aus dem Unionshaushalt unterstützte Tätigkeiten notwendig. In Bezug auf Einrichtungen der Union sind in Artikel 136 der Verordnung (EU, Euratom) 2024/2509^(29) der Anwendungsbereich, die Vorschriften und die Verfahren für die Ermittlung und Durchführung sensibler Verfahren zur Vergabe öffentlicher Aufträge festgelegt worden.

<a id="rec-50"></a>
(50) Zum Schutz der öffentlichen Ordnung ist es daher erforderlich, die Bedingungen festzulegen, die öffentliche Auftraggeber der Union und der Mitgliedstaaten bei ihren Verfahren zur Vergabe öffentlicher Aufträge für Cloud-Computing-Dienste anwenden sollten. Die Betrachtung der möglichen Risiken bildet die Grundlage für die Wahl geeigneter Risikominderungsmaßnahmen zur Aufrechterhaltung der öffentlichen Ordnung in der Union und den Mitgliedstaaten. Die kritische Abhängigkeit der Union und der Mitgliedstaaten von einer begrenzten Zahl von Anbietern von Cloud-Computing-Diensten, die der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers unterliegen, kann zu Missbrauchsrisiken (d. h. Manipulation, Fernzugriff und Fernsteuerung, Sabotage, Ausnutzung als Druckmittel), Informationszugriffsrisiken (d. h. Zugang zu sensiblen Informationen, unbefugte Kommunikation, Technologieabfluss, Datenmanipulation oder -exfiltration, Spionage) und Abhängigkeitsschwachstellen (d. h. Ausübung politischen und/oder wirtschaftlichen Zwangs, z. B. durch Anbieter- oder Technologiebindungen, Embargos oder Sanktionen, Monopolpreise, die den finanziellen Interessen der Union und der Mitgliedstaaten schaden) führen.

<a id="rec-51"></a>
(51) Um diesen Risiken zu begegnen und geeignete Risikominderungsmaßnahmen zu treffen, muss ein Unionsrahmen für Cloud-Computing-Souveränität geschaffen werden, in dem Kriterien für vertrauenswürdige Cloud-Computing-Dienste festgelegt werden. Um dem nuancierten und mehrschichtigen Charakter der Souveränität Rechnung zu tragen, sollte der Rahmen vier verschiedene Stufen vertrauenswürdiger Dienstangebote (im Folgenden „Unionsvertrauenswürdigkeitsstufen“) vorsehen.

<a id="rec-52"></a>
(52) Die Unionsvertrauenswürdigkeitsstufen sollten einen verhältnismäßigen Rahmen bilden, der sicherstellt, dass die öffentliche Ordnung gewahrt bleibt, indem die Kontrolle und Aufsicht durch öffentliche Stellen aufrechterhalten wird. Für die meisten öffentlichen Dienstleistungen würden nicht die höchsten Vertrauenswürdigkeitsstufen nötig sein. In einigen besonderen Fällen kann die Unionsvertrauenswürdigkeitsstufe 3 oder 4 als notwendig und verhältnismäßig für die Aufrechterhaltung der öffentlichen Ordnung angesehen werden. Mit der von den Mitgliedstaaten und den Einrichtungen der Union durchzuführenden Risikobewertung wird sichergestellt, dass die Grundsätze der Verhältnismäßigkeit und der Subsidiarität eingehalten werden, indem die spezifischen Fälle geprüft werden, in denen für den Schutz der öffentlichen Ordnung die höchste Vertrauenswürdigkeitsstufe erforderlich ist.

<a id="rec-53"></a>
(53) Es ist wichtig, dass die zuständigen nationalen Behörden am Niederlassungsort des Anbieters von Cloud-Computing-Diensten bewerten können, ob Anbieter von Cloud-Computing-Diensten, die ihre Cloud-Computing-Dienste für Einrichtungen der Union und öffentliche Stellen erbringen wollen, die dafür angemessene Vertrauenswürdigkeitsstufe bieten. Es wurde ein Mechanismus für die Anerkennung von Cloud-Computing-Diensten geschaffen, die entweder eine EU-Konformitätserklärung für die Unionsvertrauenswürdigkeitsstufe 1 abgegeben oder aber eine „positive“ Stellungnahme und einen Prüfbericht von einer Prüfstelle erhalten haben. Sobald der Anerkennungsmechanismus positiv abgeschlossen worden ist, wird unionsweit anerkannt, dass der Cloud-Computing-Dienst die angemessene Unionsvertrauenswürdigkeitsstufe bietet. Im Interesse der Klarheit, Einfachheit und Wirksamkeit sollten die Befugnisse zur Überwachung und Durchsetzung der Verpflichtungen im Zusammenhang mit dem Unionsrahmen für Cloud-Computing-Souveränität den zuständigen Behörden des Mitgliedstaats, in dem sich die Hauptniederlassung des Anbieters von Cloud-Computing-Diensten befindet, übertragen werden.

<a id="rec-54"></a>
(54) Im Hinblick auf den Nachweis der Konformität mit der Unionsvertrauenswürdigkeitsstufe 1 sollten Anbieter von Cloud-Computing-Diensten die alleinige Verantwortung für die Durchführung von Selbstbewertungen der Konformität anhand der einschlägigen Kriterien für diese Unionsvertrauenswürdigkeitsstufe haben. Solche Selbstbewertungen sollten auf dokumentierten Nachweisen, internen Kontrollverfahren und einer kontinuierliche Überwachung beruhen, die die Einhaltung der geltenden Kriterien ausreichend belegen.

<a id="rec-55"></a>
(55) Unabhängige Prüfungen sind ein wichtiges Instrument zur Überwachung der Konformität von Cloud-Computing-Diensten, die von Anbietern von Cloud-Computing-Diensten erbracht werden. Angesichts der Notwendigkeit, dass die geltenden Kriterien für die Unionsvertrauenswürdigkeitsstufen 2, 3 oder 4 von unabhängigen sachverständigen Dritten überprüft werden müssen, sollten die Anbieter von Cloud-Computing-Diensten – mittels unabhängiger Prüfungen – nachweisen müssen, dass sie die in dieser Verordnung festgelegten Kriterien erfüllen. Anbieter von Cloud-Computing-Diensten sollten ihre Prüfstelle frei wählen können, solange die Prüfstelle die erforderliche Unabhängigkeit und die Einhaltung der Anforderungen dieser Verordnung nachweist. Um sicherzustellen, dass die Prüfungen wirksam, effizient und rechtzeitig durchgeführt werden, sollten die Anbieter von Cloud-Computing-Diensten den Stellen, die die Prüfungen durchführen, die erforderliche Zusammenarbeit und Unterstützung leisten, indem sie der Prüfstelle unter anderem Zugang zu allen relevanten Daten und Räumlichkeiten gewähren, die für eine ordnungsgemäße Durchführung der Prüfung erforderlich sind, und indem sie mündliche oder schriftliche Anfragen beantworten. Außerdem sollten die Prüfstellen andere objektive Informationsquellen nutzen können. Anbieter von Cloud-Computing-Diensten sollten die Durchführung der Prüfung nicht untergraben. Die Prüfungen sollten im Einklang mit bewährten Verfahren der Branche und einer hohen Berufsethik und Objektivität sowie unter gebührender Berücksichtigung von Prüfungsnormen und -kodizes durchgeführt werden. Die Prüfstellen sollten die Vertraulichkeit, Sicherheit und Integrität der Informationen garantieren, die sie bei der Erfüllung ihrer Aufgaben erhalten, einschließlich Geschäftsgeheimnissen. Diese Garantie sollte kein Mittel sein, um die Anwendbarkeit der Prüfvorschriften dieser Verordnung zu umgehen. Die Prüfstellen sollten über die erforderliche Sachkenntnis in Bezug auf das Risikomanagement und die technische Kompetenz für die Prüfung von Cloud-Computing-Diensten verfügen. Sie sollten die grundlegenden Unabhängigkeitsanforderungen für verbotene prüfungsfremde Dienstleistungen, Prüfstellenwechsel und nicht an Bedingungen geknüpfte Gebühren erfüllen. Sind ihre Unabhängigkeit und technische Kompetenz nicht über jeden Zweifel erhaben, sollten Prüfstellen auf den Prüfauftrag verzichten oder ihre Funktion niederlegen.

<a id="rec-56"></a>
(56) Der Prüfbericht sollte begründet werden, um eine aussagekräftige Bilanz über die durchgeführten Tätigkeiten und die während der Prüfung erzielten Schlussfolgerungen ziehen zu können. Er sollte Informationen darüber enthalten, welche Maßnahmen die Anbieter von Cloud-Computing-Diensten getroffen haben, um die geltenden Kriterien und ihre Verpflichtungen aus dieser Verordnung zu erfüllen, und gegebenenfalls diesbezügliche Verbesserungsvorschläge aufführen. Der Prüfbericht sollte eine Stellungnahme enthalten, die auf den Schlussfolgerungen aus den Prüfbelegen beruht. Eine „positive Stellungnahme“ sollte abgegeben werden, wenn alle Belege zeigen, dass der Anbieter die in dieser Verordnung festgelegten Prüfkriterien und Verpflichtungen erfüllt. Eine „negative Stellungnahme“ sollte abgegeben werden, wenn die Prüfstelle der Auffassung ist, dass der Anbieter die in dieser Verordnung festgelegten Kriterien nicht erfüllt. Falls in der Stellungnahme keine Schlussfolgerung in Bezug auf spezifische Aspekte, die Teil des Prüfungsumfangs sind, gezogen werden konnte, sollte in die Stellungnahme eine Erklärung aufgenommen werden, warum dies nicht möglich war. Falls zutreffend, sollte der Bericht eine Beschreibung spezifischer Punkte enthalten, die nicht geprüft werden konnten, sowie eine Erklärung, warum diese nicht geprüft werden konnten.

<a id="rec-57"></a>
(57) Die Einrichtung eines Zentralverzeichnisses der von der Union als vertrauenswürdig anerkannten Cloud-Computing-Dienste wird benötigt, um die sichere und effiziente Speicherung, die Zugänglichkeit und den Austausch einschlägiger Informationen zwischen Kunden des öffentlichen Sektors, die Dienste mit Unionsvertrauenswürdigkeitsstufen nutzen, Prüfstellen, zuständigen Behörden und der Kommission zu erleichtern.

<a id="rec-58"></a>
(58) Um die andauernde Richtigkeit und Zuverlässigkeit des Status von Cloud-Computing-Diensten als Dienste mit Unionsvertrauenswürdigkeitsstufen gemäß dem Cloud-Souveränitätsrahmen zu gewährleisten, sollten die Anbieter dazu verpflichtet werden, der Prüfstelle und den zuständigen Behörden am Niederlassungsort zügig alle relevanten Informationen oder wesentlichen Änderungen der Umstände zu melden. Diese Informationen sollten es der Prüfstelle ermöglichen, ihren Prüfbericht und ihre Stellungnahme nötigenfalls neu zu bewerten, zu ändern oder zurückzuziehen, was sie anschließend der jeweils zuständigen Behörde am Niederlassungsort mitteilen muss, damit diese ihre Anerkennung des Cloud-Computing-Dienstes als Dienst mit einer bestimmten Unionsvertrauenswürdigkeitsstufe überprüfen kann. Die Informationen sollten der betreffenden zuständigen Behörde dieselbe Überprüfung bezüglich ihrer Anerkennung des Cloud-Computing-Dienst ermöglichen.

<a id="rec-59"></a>
(59) Um eine wirksame und kohärente Anwendung des Cloud-Souveränitätsrahmens zu gewährleisten, sollten die Mitgliedstaaten eine oder mehrere zuständige Behörden benennen, die für die Anerkennung des Prüfverfahrens und -rahmens und für die Beaufsichtigung anerkannter Anbieter von Cloud-Computing-Diensten zuständig sind. Diese Behörden sollten mit den erforderlichen Befugnissen, Ressourcen, Fachkenntnissen und technischen Mitteln ausgestattet werden, damit sie ihre Aufgaben wirksam, unparteiisch und unabhängig wahrnehmen können. Die Mitgliedstaaten sollten dafür sorgen, dass die Zuständigkeiten dieser Behörden eindeutig festgelegt werden und dass sie eng miteinander, mit anderen einschlägigen nationalen Behörden, darunter auch den Datenschutzbehörden und Cybersicherheitsbehörden, und gegebenenfalls mit der Kommission zusammenarbeiten, um eine einheitliche Beaufsichtigung zu gewährleisten und den Austausch einschlägiger Informationen und bewährter Verfahren in der gesamten Union zu erleichtern. Die Mitgliedstaaten sollten die Möglichkeit haben, eine oder mehrere bestehende Behörden als zuständige Behörden zu benennen.

<a id="rec-60"></a>
(60) Das Leisten von Amtshilfe zwischen den zuständigen Behörden ist von wesentlicher Bedeutung, um die wirksame grenzüberschreitende Überwachung und Durchsetzung dieser Verordnung in der gesamten Union sicherzustellen, was unter anderem auch den rechtzeitigen Informationsaustausch, die Koordinierung von Ermittlungsmaßnahmen und die Unterstützung bei der Wahrnehmung von Aufgaben innerhalb der Union einschließt. Darüber hinaus ist für eine wirksame Durchsetzung eine robuste grenzüberschreitende Zusammenarbeit zwischen den zuständigen Behörden erforderlich, um die einheitliche Anwendung dieser Verordnung in allen Mitgliedstaaten und den zeitnahen Austausch einschlägiger Informationen zur Bewältigung systemischer Risiken innerhalb der Union sicherzustellen.

<a id="rec-61"></a>
(61) Das Ziel der Union, ihre Autonomie zu stärken, sollte in einer Weise verfolgt werden, die offen und kooperativ bleibt und mit den internationalen Verpflichtungen und Partnerschaften der Union vereinbar ist. Die mit den Unionsvertrauenswürdigkeitsstufen 1, 2 und 3 verfolgten politischen Ziele sollten daher als die Fähigkeit der Union verstanden werden, erforderlichenfalls autonom zu handeln und sich gleichzeitig mit ihren internationalen Partnern abzustimmen und eine gegenseitig vorteilhafte Zusammenarbeit zu fördern. Vor diesem Hintergrund kann die Kommission für die Unionsvertrauenswürdigkeitsstufe 3 beschließen, dass ein Cloud-Computing-Dienst, der der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers unterliegt, dennoch anhand der Prüfkriterien geprüft werden kann, falls das Drittland besondere Schutzvorkehrungen getroffen hat, die sicherstellen, dass keine Risiken eines unbefugten Zugriffs auf Daten der Union oder einer möglichen Störung Qualität oder Kontinuität der Dienste besteht. Die Kommission sollte prüfen, ob für das Drittland ein Angemessenheitsbeschluss nach Artikel 45 der Verordnung (EU) 2016/679 gilt. Insbesondere sollte festgestellt werden, ob der Angemessenheitsbeschluss allgemein für das Drittland insgesamt oder nur für bestimmte Sektoren oder zertifizierte Organisationen gilt. Ferner sollte geprüft werden, ob sich der Anwendungsbereich des Angemessenheitsbeschlusses auf die spezifischen Verarbeitungstätigkeiten erstreckt, die im Zusammenhang mit der Erbringung der Dienste durchgeführt werden, oder ob Datenübermittlungen weiterhin den Anforderungen zur Umsetzung geeigneter Schutzvorkehrungen unterliegen.

<a id="rec-62"></a>
(62) Zur Gewährleistung eines kohärenten und risikobasierten Ansatzes für die Autonomie der Union sollten die Mitgliedstaaten und die Einrichtungen der Union eine oder mehrere Risikobewertungen durchführen, um die Tätigkeiten des öffentlichen Sektors zu bestimmen, die die öffentliche Ordnung betreffen. In der Risikobewertung sollte bestimmt werden, welche Unionsvertrauenswürdigkeitsstufe für die betreffenden Tätigkeiten wegen ihrer Bedeutung für die Aufrechterhaltung der öffentlichen Ordnung in Sektoren, die unter die Richtlinie (EU) 2022/2555 fallen, und in den Bereichen nationale Sicherheit, innere Sicherheit, Außengrenzenmanagement, Verteidigung, Justiz oder Strafverfolgung, einschließlich der Verhütung, Ermittlung, Aufdeckung und Verfolgung von Straftaten, angemessen sind. Im Hinblick auf die Gewährleistung einer einheitlichen Anwendung dieser Verordnung und die Bewahrung der Integrität des digitalen Binnenmarkts wird die Kommission Leitlinien herausgeben, um die Mitgliedstaaten bei der Durchführung ihrer Risikobewertungen zu unterstützen. Wenngleich die Bestimmung des Grades der Sensibilität von Informationen, die von einem Cloud-Computing-Dienst, der eine Unionsvertrauenswürdigkeitsstufe bietet, gehostet werden dürfen, in die Zuständigkeit und den Ermessensspielraum der Mitgliedstaaten fällt, sollten die Unionsvertrauenswürdigkeitsstufen 3 und 4 das sichere Hosten von EU-Verschlusssachen ermöglichen, um für Kohärenz in der gesamten Union zu sorgen.

<a id="rec-63"></a>
(63) In ihren Risikobewertungen bewerten Einrichtungen der Union und Mitgliedstaaten die Sensibilität, Kritikalität und Größenordnung der in einer Cloud-Umgebung verarbeiteten personenbezogenen und nicht personenbezogenen Daten. Eine solche Verarbeitung kann normale Geschäftsinformationen, wirtschaftlich sensible Informationen, betriebskritische Daten, personenbezogene Daten im Sinne der Verordnung (EU) 2016/679, aber auch Daten umfassen, die sektorspezifischen Verpflichtungen nach dem Unionsrecht, einschließlich der Richtlinie (EU) 2022/2555 und der Verordnung (EU) 2022/2554, unterliegen. Die Leitlinien der Kommission ermöglichen den Einrichtungen der Union und den Mitgliedstaaten ein gewisses Maß an Flexibilität bei der Bestimmung der angemessenen Unionsvertrauenswürdigkeitsstufe und der Kategorien von Informationen und Nutzern, für die diese Stufen angemessen sind. Gleichzeitig können unterschiedliche nationale Ansätze für die Klassifizierung und Zuordnung von Datensensibilitäts- und Vertrauenswürdigkeitsanforderungen eine unionsweit einheitliche Anwendung des Souveränitätsrahmens untergraben. Um eine harmonisierte Umsetzung in der gesamten Union zu gewährleisten, sollte die Kommission in Zusammenarbeit mit den betreffenden Behörden zentral koordinierte Leitlinien für die Zuordnung zwischen Unionsvertrauenswürdigkeitsstufen und Informationskategorien herausgeben, wobei die Sensibilität, Kritikalität und Größenordnung der in der Cloud-Umgebung verarbeiteten Daten, die systemische Bedeutung der Tätigkeiten der öffentlichen Auftraggeber und die geltenden unionsrechtlichen Verpflichtungen zu berücksichtigen sind. Darüber hinaus sollten die Kriterien der Unionsvertrauenswürdigkeitsstufen die im Unionsrecht vorgesehenen Verpflichtungen zur grenzüberschreitenden Zusammenarbeit unberührt lassen. Für den Fall, dass Cloud-Computing-Dienste zur Verarbeitung personenbezogener Daten benutzt werden, sieht die Verordnung (EU) 2016/679 die Verpflichtung vor, organisatorische und technische Maßnahmen zur Einhaltung der genannten Verordnung zu vereinbaren. Wenn der Anbieter von Cloud-Computing-Diensten bei der Erbringung seiner Dienste auf Unterauftragnehmer zurückgreift, gelten für die Unterauftragnehmer dieselben Vereinbarungen. Wenn spezifische technische und organisatorische Maßnahmen gemäß der vorliegenden Verordnung umgesetzt werden sollten, damit personenbezogene Daten im Einklang mit der vorliegenden Verordnung verarbeitet werden, könnten solche spezifischen Maßnahmen in den verbindlichen Vereinbarungen gemäß der Verordnung (EU) 2016/679 vorgesehen werden und als Nachweis dafür herangezogen werden, dass die erforderlichen Unionsvertrauenswürdigkeitsstufen eingehalten werden.

<a id="rec-64"></a>
(64) Der freie Datenverkehr innerhalb der Union ist eine wesentliche Voraussetzung für das reibungslose Funktionieren des Binnenmarkts. Im Hinblick auf die Förderung des freien Datenverkehrs innerhalb der Union und des Funktionierens des Binnenmarkts ist es angezeigt, dass die Mitgliedstaaten dafür sorgen, dass Daten nicht auf das Hoheitsgebiet eines einzelnen Mitgliedstaats beschränkt werden, sondern überall in der Union ohne ungerechtfertigte Einschränkungen gespeichert und verarbeitet werden können. Die Union bewahrt einen offenen und diskriminierungsfreien Rahmen für den Marktzugang im Einklang mit dem AEUV und unter Einhaltung ihrer internationalen Verpflichtungen. Dazu gehören Verpflichtungen im Rahmen des Übereinkommens der Welthandelsorganisation über das öffentliche Beschaffungswesen (im Folgenden „WTO-GPA“) sowie Verpflichtungen aus bilateralen Handelsabkommen. Dennoch behält sich die Union das Recht vor, erforderlichenfalls und in hinreichend begründeten Fällen gemäß Artikel III:2(a) WTO-GPA Maßnahmen einzuführen oder aufrechtzuerhalten, die zum Schutz der öffentlichen Sittlichkeit, Ordnung oder Sicherheit erforderlich sind, wobei auch notwendige und verhältnismäßige Zugangsbeschränkungen bei Verfahren zur Vergabe öffentlicher Aufträge zulässig sind. Die Ermittlung und Bewältigung von Risiken, die sich aus kritischen Abhängigkeiten, unbefugtem Zugang zu Daten der Union, Technologieabfluss, Sabotage und Spionage durch Akteure aus Drittländern ergeben, ist für die Aufrechterhaltung der öffentlichen Ordnung der Union unverzichtbar. Die Aufrechterhaltung des Schutzes der öffentlichen Ordnung der Union und ihrer Mitgliedstaaten erfordert eine umsichtige, aber entschlossene politische, rechtliche und operative Reaktion bei Vergabeverfahren, die sowohl auf nationaler als auch auf Unionsebene durchgeführt werden, unter vollständiger Einhaltung internationaler Verpflichtungen. Zum Schutz und zur Aufrechterhaltung der öffentlichen Ordnung der Union und ihrer Mitgliedstaaten sollten öffentliche Auftraggeber, deren Tätigkeiten anhand der Risikobewertung des Mitgliedstaats ermittelt wurden, daher Aufträge nur an Cloud-Computing-Dienste vergeben, die eine angemessene Vertrauenswürdigkeit der Stufen 2 bis 4 bieten. Eine Mindestvertrauenswürdigkeitsstufe, die mit der Unionsvertrauenswürdigkeitsstufe 1 in der gesamten Union vorgeschrieben wird, ist erforderlich, um eine einheitliche Grundlage aus Garantien für den öffentlichen Sektor zu schaffen und so Schwachstellen im öffentlichen Sektor bezüglich des Zugriffs aus Drittländern auf Daten der Union und der Störung von Diensten zu verringern.

<a id="rec-65"></a>
(65) Um die Resilienz zu steigern und die Abhängigkeit von einem einzigen Anbieter von Cloud-Computing-Diensten zu begrenzen, sollten Einrichtungen der Union und Mitgliedstaaten im Rahmen ihrer Verfahren zur Vergabe öffentlicher Aufträge prüfen, ob eine Mehranbieter- oder Multi-Cloud-Strategie angemessen sein könnte. Die Entscheidung über die Annahme und Umsetzung einer Multi-Cloud-Architektur sollte auf einer kontextspezifischen Risikobewertung beruhen. Bei dieser Bewertung sollten alle relevanten betrieblichen, regulatorischen oder resilienzbezogenen Umstände ermittelt werden, die für die Annahme einer Mehranbieter- oder Multi-Cloud-Strategie sprechen.

<a id="rec-66"></a>
(66) Die Vergabe öffentlicher Aufträge dient häufig als primäres Marktsteuerungssignal. Von oder an Behörden gestellte Anforderungen im Zusammenhang mit der Festlegung bestimmter Vertrauenswürdigkeitsstufen, die Cloud-Computing-Dienste bieten müssen, werden in der Regel von privatwirtschaftlichen Unternehmen, die in regulierten Wirtschaftszweigen tätig sind, übernommen und haben Ausstrahlungseffekte, die dann im Laufe der Zeit zu einer breiteren Neuausrichtung des Marktes beitragen. Diese Entwicklungen machen deutlich, wie wichtig es ist, dass privatwirtschaftliche Einrichtungen, die in den in Anhang I der Richtlinie (EU) 2022/2555 aufgeführten Sektoren tätig sind, dieselben Bewertungen durchführen können wie Einrichtungen der Union und Mitgliedstaaten.

<a id="rec-67"></a>
(67) Bei der Durchführung von Verfahren zur Vergabe öffentlicher Aufträge für Cloud-Computing-Dienste und KI-Systeme sollten öffentliche Auftraggeber einen klaren europäischen Mehrwert als Teil der qualitativen Bewertung des Angebots verlangen. Dieser Mehrwert sollte darin bestehen, dass ein Beitrag zur Stärkung der digitalen Lieferkette in der Union geleistet wird, dass Technologien der Union integriert werden, dass eine Innovation erfolgt, die für die Erbringung der Dienstleistung in der Union erforderlich ist und dass die Dienstleistung mit in der Union entworfenen oder hergestellten Hardwarekomponenten erbracht wird. Das Kriterium des europäischen Mehrwerts sollte für die Auftragsvergabe nicht ausschlaggebend sein und so angewandt werden, dass der Vorrang technischer und finanzieller Kriterien, die in direktem Zusammenhang mit den Leistungsanforderungen stehen, gewahrt bleibt. Zu diesem Zweck könnten öffentliche Auftraggeber in ihrer allgemeinen Bewertungsmethode den europäischen Mehrwert mit höchstens 15 von 120 Punkten gewichten und müssten dabei sicherstellen, dass diese Gewichtung verhältnismäßig und den zentralen Zuschlagskriterien untergeordnet bleibt.

<a id="rec-68"></a>
(68) Eine innovationsfördernde Auftragsvergabe für Cloud-Computing-Dienste und KI-Systeme ist von entscheidender Bedeutung, wenn es darum geht, die technologische Entwicklung zu fördern, die digitale Resilienz und Wettbewerbsfähigkeit zu stärken und die Behörden in die Lage zu versetzen, von sicheren, effizienten und vertrauenswürdigen digitalen Lösungen zu profitieren, die sich zusammen mit den sich rasch wandelnden technologischen und gesellschaftlichen Bedürfnissen weiterentwickeln. Die Mitgliedstaaten sollten daher bestrebt sein, in mindestens 25 % der betreffenden innovationsfördernden Cloud- und KI-Auftragsvergabeverfahren Aufträge an KMU zu vergeben. Zu diesem Zweck sollten die Mitgliedstaaten der Kommission aktiv über ihre Einführung innovativer Cloud-Computing-Dienste und KI-Systeme Bericht erstatten.

<a id="rec-69"></a>
(69) In ihrer gemeinsamen Erklärung zum Aufbau der nächsten Cloud-Generation in Europa für Unternehmen und den öffentlichen Sektor vom 15. Oktober 2020^(30) und ihrer Berliner Erklärung zur digitalen Gesellschaft und wertebasierten digitalen Verwaltung vom 8. Dezember 2020^(31) bekundeten die Mitgliedstaaten großes Interesse an der Festlegung eines gemeinsamen Ansatzes zur Bündelung von Cloud-Kapazitäten durch eine unionsweite Vernetzung von Cloud-Computing-Infrastrukturen und an der Entwicklung eines sicheren und interoperablen Europäischen Cloud-Verbunds des öffentlichen Sektors. In seinen Schlussfolgerungen zur Zukunft der Digitalpolitik der EU vom 21. Mai 2024^(32) bestätigte der Rat der Europäischen Union die große Relevanz und Bedeutung, die der Verwirklichung dieses gemeinsamen Ansatzes zukommt, indem er die Kommission aufforderte, die Entwicklung interoperabler öffentlicher digitaler Dienste und die grenzüberschreitende Vernetzung der Infrastrukturen öffentlicher Verwaltungen, einschließlich Cloud- und Edge-Infrastrukturen, weiterhin zu unterstützen, um deren Resilienz, Effizienz und Nachhaltigkeit zu steigern. Zur Verwirklichung dieses gemeinsamen Ansatzes muss der Europäische Cloud-Verbund des öffentlichen Sektors (im Folgenden „EuroCloud-Verbund“) eingerichtet werden. Der EuroCloud-Verbund sollte nationale und europäische Cloud-Initiativen, die hochgradig vertrauenswürdige und sichere Cloud-Kapazitäten für den öffentlichen Sektors bieten, zusammenführen und die gemeinsame Nutzung solcher Kapazitäten zwischen Einrichtungen der Union und öffentlichen Stellen erleichtern. Bei einer Bewertung dieser Verordnung kann die Kommission zu einem späteren Zeitpunkt prüfen, ob beitretende Länder, Bewerberländer und mögliche Bewerber sowie internationale Organisationen mit Sitz in der Union im Einklang mit dem Unionsrecht am EuroCloud-Verbund teilnehmen könnten.

<a id="rec-70"></a>
(70) Die Mitglieder des EuroCloud-Verbunds sollten bestimmte Anforderungen erfüllen, um Wettbewerbsverzerrungen gegenüber privaten Wirtschaftsteilnehmern zu vermeiden, die dadurch entstehen, dass ein privater Dienstleistungserbringer in eine vorteilhafte Position gegenüber seinen Wettbewerbern versetzt wird.

<a id="rec-71"></a>
(71) Die Teilnahme am EuroCloud-Verbund sollte auf öffentliche Einrichtungen beschränkt bleiben, an denen keine private Partei direkt beteiligt ist. In diesem Zusammenhang sollte eine direkte private Beteiligung ausgeschlossen werden, wenn die weitergebende Stelle – entweder direkt oder indirekt über einen zwischengeschalteten Rechtsträger – auch Eigentümerin der Hardware im Sinne des Artikels 3 Nummer 5 der Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates^(33) ist, über die der Dienst bereitgestellt wird, und diesen Dienst auch selbst erbringt. Es sollte davon ausgegangen werden, dass die weitergebende Stelle die Kontrolle über diesen zwischengeschalteten Rechtsträger ausübt, wenn die folgenden kumulativen Bedingungen erfüllt sind: Erstens sollte die weitergebende Stelle einen entscheidenden Einfluss sowohl auf die strategischen Ziele als auch auf die wesentlichen Entscheidungen des zwischengeschalteten Rechtsträgers ausüben, der Eigentümer der Hardware ist und den Dienst erbringt. Zweitens sollte es keine direkte private Kapitalbeteiligung an diesem zwischengeschalteten Rechtsträger geben. Drittens sollten mehr als 80 % der Tätigkeiten des zwischengeschalteten Rechtsträgers in Erfüllung der Aufgaben durchgeführt werden, die ihm von der weitergebenden Stelle übertragen wurden.

<a id="rec-72"></a>
(72) Die weitergebende Stelle sollte geeignete technische, operative und organisatorische Maßnahmen treffen, um eine wirksame, sichere und resiliente Erbringung der Dienste zu gewährleisten. Dies sollte insbesondere Konzepte in Bezug auf die Risikoanalyse und die Sicherheit der Informationssysteme einschließen, darunter auch Konzepte für die Zugriffskontrolle, für die Bewältigung von Sicherheitsvorfällen und die Aufrechterhaltung der Betriebskontinuität sowie für die Förderung der Interoperabilität und Konnektivität.

<a id="rec-73"></a>
(73) Schließlich sollte die gemeinsame Nutzung von Rechenzentrumsdiensten und Cloud-Computing-Diensten innerhalb des EuroCloud-Verbunds in eine Zusammenarbeit des öffentlichen Sektors eingebettet werden. Eine solche Zusammenarbeit sollte ausschließlich durch Erwägungen des öffentlichen Interesses geleitet werden und für eine Hilfeleistung keinerlei Gegenleistung vorsehen. So sollte insbesondere die gemeinsame Nutzung von Diensten innerhalb des EuroCloud-Verbunds gebührenfrei sein, es sei denn, die Gebühren sind strikt auf das beschränkt, was erforderlich und verhältnismäßig ist, um die Kosten zu decken, die der weitergebenden Stelle dadurch entstehen, dass ihre Dienste von der begünstigten nutzenden Stelle genutzt werden. Diese Kosten sollten auf die zusätzlichen Kosten beschränkt sein, die durch die gemeinsame Nutzung von Kapazitäten entstehen, unter anderem für die Zuweisung und Isolierung von Ressourcen, die Zugangsverwaltung, die Ermöglichung der Integration und Interoperabilität von Ressourcen, die Gewährleistung der Einhaltung der geltenden Anforderungen des Unionsrechts und die Verwaltung der gemeinsamen Nutzung. Die von der weitergebenden Stelle zur Deckung dieser Kosten erhobenen Gebühren sollten nicht als Gegenleistung für die Erbringung einer Dienstleistung betrachtet werden und kein Entgelt oder öffentlichen Auftrag im Sinne der Richtlinie 2014/24/EU des Europäischen Parlaments und des Rates^(34) und der Verordnung (EU, Euratom) 2024/2509 darstellen. Unter diesen Bedingungen sollte die gemeinsame Nutzung von Diensten öffentlicher Rechenzentren und von Cloud-Computing-Diensten innerhalb des EuroCloud-Verbunds nicht unter die Vorschriften der Union für die Vergabe öffentlicher Aufträge fallen.

<a id="rec-74"></a>
(74) Öffentliche Auftraggeber der Mitgliedstaaten stoßen bei der Auftragsvergabe für digitale Lösungen wie z. B. für Rechenzentrumsdienste, Cloud-Computing-Dienste, Software und KI-Systeme häufig auf erhebliche Schwierigkeiten. Begrenzte finanzielle Ressourcen, verminderte Kaufkraft, unzureichendes technisches Fachwissen oder mangelnde Sachkenntnis in Bezug auf die Auftragsvergabe behindern öffentliche Stellen dabei, tatsächlich Zugang zu solchen Dienstleistungen zu erhalten. Auftragsvergabetätigkeiten, die von der Kommission in Abstimmung mit den öffentlichen Auftraggebern der Mitgliedstaaten durchgeführt werden, können eine entscheidende Rolle dabei spielen, die kollektive Kaufkraft nutzbar zu machen und den Zugang zu diesen Dienstleistungen und Waren zu günstigen Bedingungen sicherzustellen. Die Kommission kann bereits heute gemeinsame Vergabeverfahren mit öffentlichen Auftraggebern der Mitgliedstaaten gemäß Artikel 168 Absatz 2 der Verordnung (EU, Euratom) 2024/2509 durchführen. Ferner kann die Kommission bereits heute als Großhändler auftreten und Waren und Dienstleistungen erwerben, lagern und weiterverkaufen oder an von ihr ausgewählte Partnerorganisationen spenden. Damit diese Stellen das Potenzial des Binnenmarkts voll ausschöpfen können, insbesondere im Hinblick auf Größenvorteile und den Vorteilsausgleich, sollten die Möglichkeiten der Kommission, als zentrale Beschaffungsstelle aufzutreten, auch auf öffentliche Auftraggeber der Mitgliedstaaten und auf von der Kommission ausgewählte Partnerorganisationen ausgeweitet werden, und zwar als eine Form der Auftragsvergabe, die über die in Artikel 168 Absatz 3 der Verordnung (EU, Euratom) 2024/2509 genannten Möglichkeiten hinausgeht. Die Kommission sollte die Möglichkeit haben, alle Vergabeverfahren zu nutzen, die öffentlichen Auftraggebern der Mitgliedstaaten und von der Kommission ausgewählten Partnerorganisationen zur Verfügung stehen, und auch Beschaffungstätigkeiten einzubeziehen, die von der Kommission für die Organe, Einrichtungen und sonstigen Stellen der Union durchgeführt werden. Öffentliche Auftraggeber der Mitgliedstaaten, Partnerorganisationen und Organe, Einrichtungen und sonstige Stellen der Union sollten in diesen Vergabeverfahren als „teilnehmende Stellen“ gelten.

<a id="rec-75"></a>
(75) Um die Flexibilität und die Verwaltungseffizienz zu steigern, sollte abweichend von der Verordnung (EU, Euratom) 2024/2509 die Möglichkeit vorgesehen werden, während der Geltungsdauer eines dynamischen Beschaffungssystems weitere teilnehmende Stellen hinzuzufügen. Nach dieser Ausnahmeregelung sollten teilnehmende Stellen, die erst nach der Einrichtung eines dynamischen Beschaffungssystems der Vereinbarung beitreten, die Möglichkeit haben, sich diesem System – mit vorheriger Genehmigung durch die Kommission – während seiner Geltungsdauer jederzeit anzuschließen, bevor eine künftige Aufforderung zur Angebotsabgabe veröffentlicht wird. Diese Möglichkeit sollte strikt auf neu beitretende teilnehmende Stellen beschränkt sein und die Rechte und Pflichten der bereits am System teilnehmenden Stellen und die Integrität bereits abgeschlossener oder laufender Vergabeverfahren unberührt lassen.

<a id="rec-76"></a>
(76) Die Kommission sollte den Mitgliedstaaten den Entwurf einer Vereinbarung vorlegen, in der die praktischen Modalitäten für die Auftragsvergabetätigkeiten festgelegt werden. Angesichts der potenziell großen Zahl teilnehmender Stellen sollte dieser Vereinbarungsentwurf zunächst zwischen der Kommission und den teilnahmewilligen Mitgliedstaaten ausgehandelt und geschlossen werden. Darin sollten die Bedingungen und das Verfahren festgelegt werden, nach denen Einrichtungen der Union sowie andere Mitgliedstaaten, öffentliche Auftraggeber der Mitgliedstaaten und von der Kommission ausgewählte Partnerorganisationen anschließend der Vereinbarung beitreten und davon profitieren können. Die Vereinbarung tritt gemäß ihren Bestimmungen und vorbehaltlich der Zustimmung von mindestens zwei Mitgliedstaaten in Kraft. Auch wenn die Kommission so weit wie möglich bestrebt sein sollte, den gemeinsamen Bedürfnissen der teilnehmenden Stellen gerecht zu werden, sollte dies nicht als Verpflichtung ausgelegt werden, spezifische Bedürfnisse einer begrenzten Zahl von ihnen zu befriedigen.

<a id="rec-77"></a>
(77) Wenn teilnehmende Stellen einer Vereinbarung über die Durchführung zentraler Beschaffungstätigkeiten, einschließlich Nebenbeschaffungstätigkeiten, beitreten, so sollten sie die im geltenden Unionsrecht vorgesehenen Verfahren zur Vergabe öffentlicher Aufträge gemäß der Richtlinie 2014/24/EU und der Verordnung (EU, Euratom) 2024/2509 nicht anwenden. Bei öffentlichen Auftraggebern aus Mitgliedstaaten, die eine solche Vereinbarung über die Organisation zentraler Beschaffungstätigkeiten schließen, sollte davon ausgegangen werden, dass sie ihre Verpflichtungen gemäß den nationalen Rechtsvorschriften zur Umsetzung der Richtlinie 2014/24/EU erfüllen, wenn sie Bauleistungen, Waren oder Dienstleistungen von einem öffentlichen Auftraggeber erwerben, der für das Vergabeverfahren zuständig ist.

<a id="rec-78"></a>
(78) Mit der Vereinbarung sollte ein Lenkungsausschuss eingesetzt werden, der sich aus der Kommission und Vertretern der Mitgliedstaaten zusammensetzt. Der Ausschuss ist für die strategische Beaufsichtigung der Auftragsvergabetätigkeiten zuständig, einschließlich der strategischen Ausrichtung der Planung der Vergabe öffentlicher Aufträge und der einzelnen Vergabeverfahren. Der Lenkungsausschuss sollte auch die Einbeziehung der teilnehmenden Stellen beaufsichtigen. Der Lenkungsausschuss sollte nicht für die Durchführung der Auftragsvergabetätigkeiten verantwortlich sein, für die weiterhin die Kommission zuständig sein sollte, einschließlich der Festlegung von Gebühren. Der Lenkungsausschuss sollte die am besten geeignete Methode für die Auswahl zusätzlicher Vertreter der Einrichtungen der Union, der öffentlichen Auftraggeber aus den Mitgliedstaaten und der von der Kommission ausgewählten Partnerorganisationen festlegen.

<a id="rec-79"></a>
(79) Die Bestimmungen über die Zuständigkeiten und der geltende Rahmen für die öffentliche Auftragsvergabe zwischen der Kommission als zentraler Beschaffungsstelle und den teilnehmenden Stellen, die darüber Aufträge vergeben, sollten in der Vereinbarung präzisiert werden. Wenn eine teilnehmende Stelle bestimmte Teile des Vergabeverfahrens autonom durchführt, so sollte sie für diese Phasen des autonomen Verhaltens allein verantwortlich bleiben. Ein öffentlicher Auftraggeber, der als zentrale Beschaffungsstelle auftritt und über die Kommission Dienstleistungen oder Waren erworben hat, sollte diese Dienstleistungen anderen öffentlichen Auftraggebern anbieten dürfen, ohne die im geltenden Unionsrecht vorgesehenen Verfahren zur Vergabe öffentlicher Aufträge anzuwenden. In diesem Fall ist der öffentliche Auftraggeber verpflichtet, die ursprünglichen Vertragsbestimmungen auch in jedem nachfolgenden Vertrag einzuhalten.

<a id="rec-80"></a>
(80) Damit die erforderlichen Ressourcen verfügbar bleiben, leisten die teilnehmenden Stellen einen Beitrag zu den Kosten, die durch die Vergabeverfahren und etwaigen Nebentätigkeiten entstehen. Zu diesem Zweck sollte die Kommission befugt sein, von den teilnehmenden Stellen Gebühren zu erheben. Diese Gebühren sollten in einer Höhe festgesetzt werden, die grundsätzlich ausreicht, um alle direkten und indirekten Kosten zu decken, die der Kommission im Zusammenhang mit den Auftragsvergabetätigkeiten, einschließlich etwaiger Nebendienstleistungen, entstehen. Diese Gebühren sollten in Übereinstimmung mit der Praxis vergleichbarer Auftragsvergaberahmen festgelegt werden. Die anfänglichen Einrichtungskosten können aus dem Gesamthaushalt der Union bestritten und sodann von den teilnehmenden Stellen über einen bestimmten Zeitraum erstattet werden. Einnahmen aus Gebühren sollten als interne zweckgebundene Einnahmen gemäß Artikel 21 Absatz 3 Buchstabe a der Verordnung (EU, Euratom) 2024/2509 gelten.

<a id="rec-81"></a>
(81) Quelloffenheit spielt eine wichtige Rolle bei der Gewährleistung der Transparenz, Sicherheit und Effizienz bei der Nutzung digitaler Technologien im öffentlichen Sektor. Der Zugang zum Quellcode ermöglicht die Überprüfbarkeit, fördert die Zusammenarbeit und Weiterverwendung und verringert Abhängigkeiten von einem einzigen Anbieter, wodurch das Risiko einer Anbieterbindung begrenzt wird. Die Förderung der Verwendung quelloffener Software ist daher von wesentlicher Bedeutung, um Innovationen zu unterstützen, einen besseren Gegenwert für öffentliche Ausgaben zu erzielen und die digitale Autonomie der Union zu stärken. In diesem Zusammenhang hat die Auswahl von Cloud-Computing-Diensten oder Software erhebliche Auswirkungen nicht nur auf die Kosteneffizienz, sondern auch auf die Sicherheit, Interoperabilität, Rechenschaftspflicht und technologische Autonomie.

<a id="rec-82"></a>
(82) Um die effiziente, transparente und interoperable Nutzung digitaler Technologien im gesamten öffentlichen Sektor der Union zu gewährleisten, müssen öffentliche Verwaltungen beim Aufbau ihres Cloud- und KI-Ökosystems oder -Stacks offene Standards und Komponenten fördern, die unter einer Open-Source-Lizenz bereitgestellt werden.

<a id="rec-83"></a>
(83) Immer mehr Einrichtungen der Union und öffentliche Stellen teilen die von ihnen oder für sie entwickelte Software und stellen sie im Rahmen einer Open-Source-Lizenz zur Weiterverwendung zur Verfügung. Dies kann als im öffentlichen Interesse liegend angesehen werden und kann den Gegenwert für öffentliche Ausgaben maximieren, die durch Doppelarbeit verursachten Kosten senken und Innovationen in der gesamten Union fördern. Software wird jedoch häufig in verschiedenen Verzeichnissen oder Katalogen zur Verfügung gestellt und zugänglich gemacht, was die Durchsuchbarkeit, die Auffindbarkeit und somit letztlich die Weiterverwendung behindert. Deshalb ist es notwendig, dass Einrichtungen der Union und öffentliche Stellen, die freiwillig Software zur Weiterverwendung zur Verfügung zu stellen, auch dazu verpflichtet werden, dies in einem Katalog oder Verzeichnis zu tun, der bzw. das mit dem EU-Katalog quelloffener Lösungen (im Folgenden „EU-OSS-Katalog“) verknüpft ist. Der EU-OSS-Katalog sollte als zentralisierter Katalog dienen, in dem alle öffentlichen Verwaltungen nach Software, die von Einrichtungen der Union und öffentlichen Stellen zur Weiterverwendung zur Verfügung gestellt wird, suchen und darauf zugreifen können. Durch die Bereitstellung des EU-Katalogs quelloffener Lösungen in dem in Artikel 8 der Verordnung (EU) 2024/903^(35) genannten Portal für ein interoperables Europa wird sichergestellt, dass solche Lösungen leicht mit weiteren einschlägigen Informationen und Schulungen verknüpft werden können.

<a id="rec-84"></a>
(84) Um eine wirksame und einheitliche Umsetzung der Verpflichtungen zur Durchführung einer Open-Source-Bewertung und zur Bereitstellung von Software zur Weiterverwendung in der gesamten Union zu gewährleisten, ist es erforderlich, ein Netz der Open-Source-Programmbüros (im Folgenden „OSPO-Netz“) einzurichten, das die einschlägigen Strukturen innerhalb der Einrichtungen der Union und der Mitgliedstaaten zusammenführt. Dieses OSPO-Netz sollte die Koordinierung zwischen den auf lokaler, regionaler oder nationaler Ebene eingerichteten Open-Source-Programmbüros und den von Einrichtungen der Union eingerichteten Open-Source-Programmbüros fördern. Das OSPO-Netz sollte den Austausch von Informationen und bewährten Verfahren erleichtern.

<a id="rec-85"></a>
(85) Um der technologischen Entwicklung Rechnung zu tragen und einen effizienten Rahmen für Maßnahmen zur Stärkung des Cloud- und KI-Ökosystems auf Unionsebene aufrechtzuerhalten, sollte der Kommission die Befugnis übertragen werden, gemäß Artikel 290 AEUV Rechtsakte in Bezug auf Folgendes zu erlassen: Änderung des Anhangs I, um den einschlägigen Markt- und Technologieentwicklungen in Bezug auf die Cloud- und KI-Führungsinitiativen Rechnung zu tragen, und Änderung des Anhangs II, um die Kriterien für die Unionsvertrauenswürdigkeitsstufen zu aktualisieren; Ergänzung dieser Verordnung durch Festlegung detaillierter Vorschriften für die Durchführung von Prüfungen; Änderung des Anhangs III; Angabe einer Unionsvertrauenswürdigkeitsstufe für einen öffentlichen Auftraggeber; Verlangen einer Folgenabschätzung und von Risikominderungsmaßnahmen für private Unternehmen, die in Sektoren mit hoher Kritikalität tätig sind.

<a id="rec-86"></a>
(86) Beim Erlass delegierter Rechtsakte nach dieser Verordnung ist es von besonderer Bedeutung, dass die Kommission im Zuge ihrer Vorbereitungsarbeit angemessene Konsultationen, auch auf der Ebene von Sachverständigen, durchführt, die mit den Grundsätzen in Einklang stehen, die in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung^(36) niedergelegt wurden. Um insbesondere für eine gleichberechtigte Beteiligung an der Vorbereitung delegierter Rechtsakte zu sorgen, sollten das Europäische Parlament und der Rat alle Dokumente zur gleichen Zeit wie die Sachverständigen der Mitgliedstaaten erhalten, und ihre Sachverständigen sollten stets Zugang zu den Sitzungen der Sachverständigengruppen der Kommission haben, die mit der Vorbereitung der delegierten Rechtsakte befasst sind.

<a id="rec-87"></a>
(87) Zur Gewährleistung einheitlicher Bedingungen für die Durchführung dieser Verordnung sollten der Kommission Durchführungsbefugnisse übertragen werden. Diese Befugnisse sollten im Einklang mit der Verordnung (EU) Nr. 182/2011 des Europäischen Parlaments und des Rates^(37) ausgeübt werden.

<a id="rec-88"></a>
(88) Aufgrund der Bedeutung dieser Verordnung für den Schutz personenbezogener Daten sollte erforderlichenfalls der Europäische Datenschutzbeauftragte gemäß Artikel 42 Absatz 1 der Verordnung (EU) 2018/1725^(38) konsultiert werden.

<a id="rec-89"></a>
(89) Falls es sich bei einer der in der vorliegenden Verordnung vorgesehenen Maßnahmen um eine staatliche Beihilfe handelt, gelten die Bestimmungen über solche Maßnahmen unbeschadet der Anwendung der Artikel 107 und 108 AEUV.

<a id="rec-90"></a>
(90) Diese Verordnung sollte die Anwendung der Artikel 101 und 102 AEUV und die Durchsetzungsbefugnisse der Wettbewerbsbehörden unberührt lassen.

<a id="rec-91"></a>
(91) Da die Ziele dieser Verordnung von den Mitgliedstaaten nicht ausreichend verwirklicht werden können, sondern vielmehr wegen des Umfangs und der Wirkungen der Maßnahmen auf Unionsebene besser zu verwirklichen sind, kann die Union im Einklang mit dem in Artikel 5 EUV verankerten Subsidiaritätsprinzip tätig werden. Entsprechend dem in demselben Artikel genannten Grundsatz der Verhältnismäßigkeit geht diese Verordnung nicht über das für die Verwirklichung dieser Ziele erforderliche Maß hinaus —

HABEN FOLGENDE VERORDNUNG ERLASSEN:

TITEL I ALLGEMEINE BESTIMMUNGEN

## Kapitel I Gegenstand und Begriffsbestimmungen

<a id="art-1"></a>
### Artikel 1 – Gegenstand

- (1) Diese Verordnung schafft einen Rahmen für die Stärkung des Cloud- und KI-Ökosystems auf Unionsebene, insbesondere durch folgende Maßnahmen:

  - a) Einrichtung der Cloud-Führungsinitiative und der KI-Führungsinitiative (im Folgenden „Cloud- und KI-Führungsinitiativen“),

  - b) Festlegung des Rahmens für die beschleunigte Errichtung von Rechenzentren in der gesamten Union,

  - c) Schaffung der Voraussetzungen für ein souveränes Cloud- und KI-Angebot zur Wahrung der öffentlichen Ordnung der Union,

  - d) Verringerung der Abhängigkeiten bei kritischen Technologien,

  - e) Förderung des Einsatzes von Cloud-Computing-Diensten im gesamten öffentlichen Sektor.

- (2) Das erste allgemeine Ziel dieser Verordnung besteht darin, die notwendigen Voraussetzungen für die Wettbewerbs- und Innovationskapazität des Cloud- und KI-Ökosystems der Union sicherzustellen.

- (3) Das zweite allgemeine Ziel, das eigenständig ist und das in Absatz 2 festgelegte erste allgemeine Ziel ergänzt, besteht darin, das Funktionieren des Binnenmarkts zu verbessern, indem ein einheitlicher Unionsrechtsrahmen zur Erhöhung der Resilienz und strategischen Autonomie der Union im Bereich der Cloud- und KI-Technologien festgelegt wird.

<a id="art-2"></a>
### Artikel 2 – Begriffsbestimmungen

Für die Zwecke dieser Verordnung bezeichnet der Ausdruck

- 1. „Cloud-Computing-Dienst“ einen Cloud-Computing-Dienst im Sinne des Artikels 6 Nummer 30 der Richtlinie (EU) 2022/2555;

- 2. „Anbieter von Cloud-Computing-Diensten“ einen Rechtsträger, der einen Cloud-Computing-Dienst bereitstellt;

- 3. „KI-System“ ein KI-System im Sinne des Artikels 3 Nummer 1 der Verordnung (EU) 2024/1689;

- 4. „Grenz-KI“ KI-Modelle oder auf solchen Modellen beruhende KI-Systeme, die vielfältige Aufgaben erfüllen können und sich dem aktuellen Stand der Technik annähern, diesen erreichen oder ihn übertreffen;

- 5. „KI-Agent“ ein KI-System oder einen koordinierten Satz von KI-Systemen, das bzw. der seine Umgebung mit einem gewissen Maß an Autonomie wahrnehmen und darauf reagieren kann, wobei Instrumente nach Bedarf eingesetzt werden, um bestimmte Ziele zu erreichen und sich an veränderliche Eingaben und Kontexte anzupassen;

- 6. „öffentliche Stelle“ eine öffentliche Stelle im Sinne des Artikels 2 Nummer 1 der Richtlinie (EU) 2019/1024;

- 7. „Einrichtungen der Union“ die Organe, Einrichtungen und sonstigen Stellen der Union, die durch den Vertrag über die Europäische Union, den Vertrag über die Arbeitsweise der Europäischen Union (AEUV) oder den Vertrag zur Gründung der Europäischen Atomgemeinschaft oder gemäß diesen Verträgen geschaffen wurden;

- 8. „kleine und mittlere Unternehmen“ oder „KMU“ kleine oder mittlere Unternehmen im Sinne des Artikels 2 des Anhangs der Empfehlung 2003/361/EG der Kommission;

- 9. „kleines Midcap-Unternehmen“ oder „kleines Midcap“ ein Unternehmen mit mittlerer Kapitalisierung im Sinne der Nummer 2 des Anhangs der Empfehlung (EU) 2025/1099 der Kommission;

- 10. „Rechenzentrum“ ein Rechenzentrum im Sinne des Anhangs A Abschnitt 2.6.3.1.16 der Verordnung (EG) Nr. 1099/2008 des Europäischen Parlaments und des Rates;

- 11. „Betreiber eines Rechenzentrums“ den Betreiber eines Rechenzentrums im Sinne des Artikels 2 Nummer 7 der Delegierten Verordnung (EU) 2024/1364;

- 12. „Rechenzentrumsdienst“ einen Rechenzentrumsdienst im Sinne des Artikels 6 Nummer 31 der Richtlinie (EU) 2022/2555;

- 13. „Software“ eine Software im Sinne des Artikels 3 Nummer 4 der Verordnung (EU) 2024/2847;

- 14. „Hardware“ eine Hardware im Sinne des Artikels 3 Nummer 5 der Verordnung (EU) 2024/2847;

- 15. „Komponente“ eine Komponente im Sinne des Artikels 3 Nummer 6 der Verordnung (EU) 2024/2847;

- 16. „Hersteller“ einen Hersteller im Sinne des Artikels 3 Nummer 13 der Verordnung (EU) 2024/2847;

- 17. „Prüfstelle“ eine einzelne Organisation, ein Konsortium oder eine andere Kombination von Organisationen, einschließlich etwaiger Unterauftragnehmer, die bzw. das der geprüfte Anbieter von Cloud-Computing-Diensten mit der Durchführung einer unabhängigen Prüfung beauftragt hat;

- 18. „geprüfter Dienst“ einen Cloud-Computing-Dienst, der für die Zwecke der Erlangung eines Prüfberichts und einer Stellungnahme geprüft wird;

- 19. „Prüfkriterien“ die Kriterien gemäß Anhang II dieser Verordnung, anhand deren die Prüfstelle bewertet, ob der geprüfte Anbieter und sein geprüfter Dienst alle kumulativen Kriterien erfüllen, die erfüllt sein müssen, damit er als Anbieter der Unionsvertrauenswürdigkeitsstufe 2, 3 oder 4 anerkannt werden kann;

- 20. „Prüfbelege“ sämtliche Informationen, die von einer Prüfstelle zur Untermauerung der Prüfungsfeststellungen und -schlussfolgerungen und zur Abgabe einer Stellungnahme verwendet werden, einschließlich Daten aus Dokumenten, Datenbanken oder IT-Systemen, Befragungen oder Tests;

- 21. „Kontrolle“ Kontrolle im Sinne des Artikels 2 Nummer 6 der Verordnung (EU) 2021/697;

- 22. „öffentliche Auftraggeber“ öffentliche Auftraggeber im Sinne des Artikels 2 Absatz 1 Nummer 1 der Richtlinie 2014/24/EU;

- 25. „Open-Source-Lizenz“ eine Open-Source-Lizenz im Sinne des Artikels 2 Nummer 12 der Verordnung (EU) 2024/903.

TITEL II FORSCHUNGS-, ENTWICKLUNGS- UND EINFÜHRUNGSTÄTIGKEITEN FÜR DAS CLOUD- UND KI-ÖKOSYSTEM

## Kapitel I Cloud- und KI-Führungsinitiativen

<a id="art-3"></a>
### Artikel 3 – Allgemeines Ziel der Cloud- und KI-Führungsinitiativen

- (1) Mit den Cloud- und KI-Führungsinitiativen wird das allgemeine Ziel verfolgt, Forschungs- und Innovationstätigkeiten zu fördern und umfangreiche Kapazitäten im gesamten Cloud- und KI-Ökosystem der Union aufzubauen, indem

  - a) die Entwicklung und Einführung modernster Cloud- und KI-Technologien, einschließlich ressourceneffizienter Rechenzentrumstechnik der nächsten Generation, Technologien für offene Cloud-Computing-Stacks, Grenz-KI sowie physischer und industrieller KI gefördert werden;

  - b) die Rechenzentrums- und Cloud-Kapazitäten der Union gestärkt werden, um der wachsenden Nachfrage im Zusammenhang mit KI gerecht zu werden, Innovationen zu fördern und die Resilienz der digitalen Infrastruktur sicherzustellen;

  - c) die Nachfrage in der Union angekurbelt wird und die Einführung und Verbreitung von Cloud- und KI-Technologien im gesamten öffentlichen Sektor und im Privatsektor im Einklang mit dem mit dem Beschluss (EU) 2022/2481 festgelegten Digitalziel des digitalen Umbaus der Unternehmen gefördert werden.

- (2) Mit den Cloud- und KI-Führungsinitiativen werden die folgenden operativen Ziele verfolgt:

  - a) Unterstützung der Entwicklung und Einführung fortgeschrittener Rechenzentrumstechnik, die die Grundsätze der Energieeffizienz und der Ressourceneffizienz durch Technikgestaltung über alle Abläufe hinweg berücksichtigt (operatives Ziel 1);

  - b) Unterstützung der Entwicklung und Einführung von Cloud-Computing-Stacks zur Unterstützung der technologischen Autonomie der Union (operatives Ziel 2);

  - c) Ausbau der Fähigkeiten der Union im Bereich der Grenz-KI (operatives Ziel 3);

  - d) Ausbau der Fähigkeiten der Union im Bereich physischer KI-Modelle und -Systeme und Förderung ihrer Einführung in allen strategischen Sektoren der Union (operatives Ziel 4);

  - e) Beschleunigung der Entwicklung und Verbreitung industrieller KI in allen strategischen Sektoren der Union (operatives Ziel 5);

  - f) Unterstützung der Entwicklung fortgeschrittener Plattformen für die groß angelegte Einführung von KI-Agenten (operatives Ziel 6);

  - g) Förderung der Entwicklung und Übernahme von KI-Modellen und -Systemen in allen strategischen Sektoren der Union (operatives Ziel 7);

  - h) Förderung der Übernahme von KI-Technologien auf regionaler und lokaler Ebene und der Nutzung von Cloud-Computing-Diensten, die von europäischen Anbietern von Cloud-Computing-Diensten angeboten werden (operatives Ziel 8).

<a id="art-4"></a>
### Artikel 4 – Operative Ziele der Cloud- und KI-Führungsinitiativen

- (1) Im Rahmen des operativen Ziels 1 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Förderung von Energie- und Wassereffizienztechnik für Rechenzentren, einschließlich innovativer Kühlung, Gleichstrom-Rechenzentren der nächsten Generation, Lösungen für die Nutzung von Abwärme und Energiespeichersystemen;

  - b) Förderung der Integration neu entstehender Quanteninformatiktechnologien für den Betrieb der Cloud- und KI-Recheninfrastrukturen;

  - c) Entwicklung KI-gestützter Technologien zur Optimierung der Servereffizienz, der Auslastung und des Betriebs der Recheninfrastrukturen;

  - d) Entwurf und Optimierung von Cloud- und Edge-KI-Infrastrukturen, um eine wirksame Integration in die Energienetze zu gewährleisten und ihre Flexibilität zu erhöhen;

  - e) Nutzung von Rechenzentren als Ankerkunden für fortgeschrittene Energiemanagementsysteme, die neben effizienten Energiespeicherlösungen verschiedene Energiequellen nutzen, darunter auch kleine modulare Reaktoren und sauberen Wasserstoff;

  - f) Einsatz von Prüfständen und Pilotanlagen zur Integration und Erprobung der entsprechend den Buchstaben a bis e entwickelten Technologien für energieeffiziente Halbleiter- und Quanteninformatik-Prototypen.

- (2) Im Rahmen des operativen Ziels 2 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Entwicklung und Erprobung sicherer, resilienter und leistungsfähiger offener Cloud-Computing-Stacks, die Edge-Computing auf Endgeräten, Konnektivität, Daten- und KI-Werkzeuge sowie Backend- und Dienstschichten für strategische Sektoren umfassen;

  - b) Entwicklung von KI-optimierten Servern und Basissoftware auf der Grundlage von Prozessoren, Beschleunigern und Quantenbeschleunigern, die in der Union entworfen und hergestellt werden, sowie von ultradichten und Langzeitdatenspeichern der nächsten Generation;

  - c) Verbesserung der Datenverfügbarkeit für KI über quelloffene Middleware-Plattformen zur Unterstützung gemeinsamer europäischer Datenräume;

- (3) d)Förderung der Schaffung von Grundlagen für quelloffene Software zur Im Rahmen des operativen Ziels 3 unterstützen die Cloud- und KI-Führungsinitiativen Pionierprojekte im Bereich der Grenz-KI, bei denen Grenz-KI-Modelle und -Systeme als strategische Vermögenswerte entwickelt werden, auch in Schlüsselsektoren wie der Cybersicherheit.

  - Im Unterstützung quelloffener Komponenten;

  - e) Erstellung eines Katalogs europäischer offener Cloud-Computing-Lösungen, die entsprechend den Buchstaben a bis d dieses Absatzes entwickelt wurden.

- (4) Rahmen des operativen Ziels 4 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Beschleunigung der Entwicklung eines europäischen physischen KI-Stacks, der das Training von Modellen sowie die Entwicklung und Einführung von Systemen unterstützt, insbesondere für Robotik, autonome Fahrzeuge und Drohnen;

  - b) Erleichterung des Zugangs zu spezifischen Datensätzen für physische KI sowie deren Erfassung und Aufbereitung;

  - c) Unterstützung der Entwicklung, Erprobung und Validierung physischer KI-Modelle und -Systeme in realen Umgebungen.

- (5) Im Rahmen des operativen Ziels 5 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Beschleunigung der Entwicklung und Nutzung von sektoralen KI-Modellen und -Systemen in allen strategischen Industriezweigen der Union;

  - b) Erleichterung des Zugangs zu den erforderlichen Rechenressourcen und KI-Werkzeugen, die für die Entwicklung und praktische Umsetzung von KI-Modellen und -Systemen benötigt werden und die auf die Bedürfnisse der Industriezweige zugeschnitten sind;

  - c) Ermöglichung einer sicheren umfassenden Datenbündelung für kooperatives KI-Training durch Technologien zur Verbesserung der Privatsphäre und zur Wahrung der Vertraulichkeit.

- (6) Im Rahmen des operativen Ziels 6 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Unterstützung der Entwicklung fortgeschrittener resilienter und sicherer Plattformen für die Entwicklung, Einführung und Orchestrierung fortgeschrittener KI-Agenten in großem Maßstab;

  - b) Erleichterung der Entwicklung gezielter Test- und Versuchsmethoden für fortgeschrittene KI-Agenten und deren Orchestrierung während ihres gesamten Lebenszyklus.

- (7) Im Rahmen des operativen Ziels 7 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Beschleunigung der technologischen Entwicklung und Einführung von KI-Modellen und -Systemen in kritischen Bereichen des öffentlichen Sektors;

  - b) Entwicklung von KI-Modellen und -Systemen, die die wirksame Erbringung öffentlicher Dienstleistungen und deren Zugänglichkeit für die breite Öffentlichkeit erhöhen, die Entscheidungsfindung verbessern und die Verwaltungsverfahren vereinfachen;

  - c) Förderung des Austauschs und der Weiterverwendung von Trainingsdaten und KI-Modellen in den öffentlichen Diensten der Union;

  - d) Erleichterung der sicheren, datenschutzfreundlichen Weiterverwendung von Gesundheitsdaten für KI-Modelle und -Werkzeuge im Gesundheitswesen;

  - e) Erleichterung der Entwicklung, Erprobung und Einführung von KI-Modellen und -Werkzeugen in der Automobilindustrie, auch für autonomes Fahren.

- (8) Im Rahmen des operativen Ziels 8 sollen die Cloud- und KI-Führungsinitiativen Folgendes umsetzen:

  - a) Förderung der weitverbreiteten Übernahme von KI durch Organisationen des privaten und öffentlichen Sektors, einschließlich KMU und kleiner Midcap-Unternehmen, über das Netz der KI-Erfahrungs- und Beschleunigungszentren (im Folgenden „KI-Zentren“);

  - b) Entwicklung eines gemeinsamen Cloud- und KI-Lehrplans auf der Grundlage des Netzes der KI-Zentren und anderer einschlägiger europäischer Initiativen;

  - c) Förderung der gemeinsamen Nutzung von Rechenzentrumsdiensten und Cloud-Computing-Diensten des öffentlichen Sektors durch Unterstützung eines Europäischen Cloud-Verbunds des öffentlichen Sektors (im Folgenden „EuroCloud-Verbund“);

  - d) Unterstützung der Auftragsvergabe für Rechenzentrumsdienste und Cloud-Computing-Dienste für Einrichtungen der Union und öffentliche Stellen.

<a id="art-5"></a>
### Artikel 5 – KI-Erfahrungs- und Beschleunigungszentren

- (1) Jeder Mitgliedstaat richtet KI-Erfahrungs- und Beschleunigungszentren (im Folgenden „KI-Zentren“) ein. Diese KI-Zentren bauen auf den gemäß Artikel 16 der Verordnung (EU) 2021/694 eingerichteten europäischen digitalen Innovationszentren und gegebenenfalls auf etwaigen nach Unionsrecht eingerichteten Nachfolgeeinrichtungen auf.

- (2) Die Ziele der KI-Zentren sind Folgende:

  - a) Unterstützung der Integration und Ausweitung von KI-Anwendungsfällen in strategischen Industriezweigen und öffentlichen Sektoren;

  - b) Beschleunigung der weitverbreiteten Übernahme von Cloud- und KI-Technologien auf regionaler und lokaler Ebene, insbesondere in KMU, kleinen Midcaps und öffentlichen Stellen, im Einklang mit dem Grundsatz „Zuerst KI“;

  - c) Nutzung der einschlägigen Infrastruktur, um die Entwicklung und Feinabstimmung von KI-Modellen und -Systemen zu beschleunigen.

- (3) Die KI-Zentren werden insbesondere mit folgenden Aufgaben betraut:

  - a) Unterstützung von Organisationen bei der Beschleunigung ihres digitalen Umbaus durch den Zugang zu und die Nutzung von KI-Technologien, unter anderem durch die Vernetzung von Organisationen mit europäischen Anbietern von Cloud- und KI-Technologien;

  - b) Sicherstellung oder Bereitstellung des Zugangs zu einschlägigen Weiterqualifizierungs- und Umschulungsprogrammen in enger Zusammenarbeit mit der Akademie für KI-Kompetenzen;

  - c) Erleichterung des Transfers von Sachkenntnis zwischen den Regionen;

  - d) Unterstützung der Expansion von Ablegern und Start-ups aus Universitäten, Gründerzentren und anderen Beschleunigern durch Erleichterung des Zugangs zu Kunden, Unternehmen und Organisationen, die auf der Suche nach spezialisierten KI-Diensten sind.

- (4) Die Kommission kann Durchführungsrechtsakte erlassen, in denen das Verfahren für die Einrichtung von KI-Zentren und weitere Regelungen für das Profil der teilnehmenden Organisation, Auswahlkriterien und Einzelheiten zur Durchführung der Aufgaben und Funktionen festgelegt werden. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

- (5) KI-Zentren legen ihre Organisation, Zusammensetzung und Arbeitsweise im Einklang mit den in dieser Verordnung festgelegten Zielen weitgehend nach eigenem Ermessen fest.

- (6) Es wird ein Netz der KI-Zentren eingerichtet, um die Zusammenarbeit und den Austausch bewährter Verfahren zwischen KI-Zentren zu unterstützen und spezialisierte Dienste in Regionen bereitzustellen, in denen die erforderlichen Kompetenzen oder Rechenkapazitäten vor Ort nicht verfügbar sind.

- (7) Die Mitgliedstaaten und die Kommission arbeiten mit bestehenden Netzen zusammen, die im Rahmen anderer Initiativen der Union, einschließlich solcher im Bereich Halbleiter und Daten, eingerichtet wurden.

<a id="art-6"></a>
### Artikel 6 – Umsetzung der Cloud- und KI-Führungsinitiativen

- (1) Mit der Umsetzung der operativen Ziele der Cloud- und KI-Führungsinitiativen werden die Kommission und die Mitgliedstaaten sowie gegebenenfalls gemeinsame Unternehmen oder andere Strukturen betraut, die in der Lage sind, diese Ziele zu erreichen.

- (2) Die operativen Ziele der Cloud- und KI-Führungsinitiativen werden durch groß angelegte, sektorenübergreifende Initiativen zur Bewältigung großer technologischer und industrieller Herausforderungen von strategischer Bedeutung für die Union (im Folgenden „Große Herausforderungen“) gemäß Anhang I umgesetzt.

- (3) Die Cloud- und KI-Führungsinitiativen können im Einklang mit der Verordnung (EU) 2021/694 und der Verordnung (EU) 2021/695 mit Mitteln aus Unionsprogrammen, einschließlich des Programms Horizont Europa und des Programms Digitales Europa, unterstützt werden.

- (4) Um dem technologischen Wandel und den Marktentwicklungen Rechnung zu tragen, wird der Kommission die Befugnis übertragen, gemäß Artikel 45 delegierte Rechtsakte zu erlassen, um Anhang I in einer Weise, die mit den in Artikel 4 festgelegten Zielen der Cloud- und KI-Führungsinitiativen im Einklang steht, zu ändern.

<a id="art-7"></a>
### Artikel 7 – Nationale Cloud- und KI-Strategien

- (1) Bis zum [ein Jahr nach dem Inkrafttreten] legen die Mitgliedstaaten nationale Cloud- und KI-Strategien (im Folgenden „nationale Strategien“) fest.

- (2) Die nationalen Strategien umfassen mindestens Folgendes:

  - a) die Hauptziele und Prioritäten für die Cloud- und KI-Einführung im Einklang mit dem Grundsatz „Zuerst KI“ sowie einen Governance- und Überwachungsrahmen zur Verwirklichung dieser Ziele und Prioritäten;

  - b) Maßnahmen zur Beschleunigung der Cloud- und KI-Entwicklung und -Einführung auf nationaler, regionaler und lokaler Ebene, insbesondere bei öffentlichen Stellen, KMU und kleinen Midcaps, unter anderem durch die Unterstützung der in Artikel 5 genannten KI-Zentren als Zugangspunkte zum europäischen KI-Innovationsökosystem;

  - c) Maßnahmen zur Unterstützung der breiten Einführung und Nutzung von KI in strategischen Industriezweigen und öffentlichen Sektoren, auch in den Bereichen Gesundheit, Energie und Mobilität;

  - d) Maßnahmen zur Unterstützung des Aufbaus von Rechenzentrumskapazitäten mit besonderem Schwerpunkt auf hochwertigen Rechenzentren, die erhebliche wirtschaftliche und gesellschaftliche Vorteile bieten und gleichzeitig hohe Umwelt- und Energieeffizienzstandards einhalten;

  - e) Maßnahmen für Investitionen in Hochleistungsrecheninfrastrukturen, einschließlich KI-Fabriken, KI-Gigafabriken und Quantencomputern, als strategische nationale und grenzüberschreitende Vermögenswerte zur Unterstützung der Forschung, Entwicklung und Einführung industrieller KI in allen strategischen Sektoren;

  - f) Maßnahmen zur Unterstützung der Entwicklung von Cloud- und KI-Fähigkeiten und zur Förderung von Exzellenz und Innovation, unter anderem durch Maßnahmen im Bereich der Vergabe öffentlicher Aufträge und der innovationsfördernden Auftragsvergabe gemäß Artikel 33;

  - g) Maßnahmen zur Unterstützung der Entwicklung von Technologien der Cloud-Computing-Stacks auf der Grundlage offener Hardware und Software, um die technologische Souveränität zu stärken und die Wettbewerbsfähigkeit strategischer europäischer Industriezweige zu verbessern;

  - h) Maßnahmen zur Gewährleistung der Zugänglichkeit hochwertiger Daten für die KI-Entwicklung, insbesondere durch die Vermeidung von Datenengpässen, auf die Organisationen stoßen.

- (3) Die nationalen Strategien müssen mit den Zielen dieser Verordnung im Einklang stehen.

- (4) Die Mitgliedstaaten stellen sicher, dass ihre nationalen Strategien mit den entsprechenden Digitalzielen gemäß Artikel 4 des Beschlusses (EU) 2022/2481 im Einklang stehen und zu deren Verwirklichung beitragen.

- (5) Die Mitgliedstaaten notifizieren der Kommission ihre nationalen Strategien binnen drei Monaten nach deren Annahme. Die Mitgliedstaaten bewerten ihre nationalen Strategien regelmäßig, mindestens aber alle drei Jahre, auf der Grundlage wesentlicher Leistungsindikatoren und aktualisieren diese erforderlichenfalls. Die Kommission beobachtet die Annahme und Überarbeitung der nationalen Strategien.

- (6) Das mit der Verordnung (EU) 2024/1689 eingerichtete Europäische Gremium für Künstliche Intelligenz (im Folgenden „KI-Gremium“) berät und unterstützt die Mitgliedstaaten bei der Koordinierung der nationalen Strategien. Das KI-Gremium erleichtert den Austausch bewährter Verfahren zwischen den Mitgliedstaaten.

<a id="art-8"></a>
### Artikel 8 – Kriterien für vorrangige Grenz-KI-Projekte

    Die Kommission kann Projekte, die aufgrund offener Aufforderungen zur Interessenbekundung ausgewählt wurden und die Bewältigung der in Anhang I genannten Großen Herausforderung 3 unterstützen, durch einen Beschluss als vorrangige Grenz-KI-Projekte anerkennen, sofern die folgenden Kriterien erfüllt sind:

  - a) Es handelt sich um ein Pionierprojekt, dessen Schwerpunkt auf der Unterstützung und Ausweitung von Grenz-KI-Technologien liegt;

  - b) es wird von einem gemäß dem Beschluss (EU) 2022/2481 gegründeten Konsortium für eine europäische Digitalinfrastruktur oder einem anderen Rechtsträger, der nach dem Unionsrecht für eine Finanzierung infrage kommt, unter Beteiligung von mindestens drei Mitgliedstaaten durchgeführt;

  - c) die teilnehmenden Mitgliedstaaten bündeln Rechenzeit und andere einschlägige Ressourcen, um die Durchführung des benannten Projekts zu unterstützen.

<a id="art-9"></a>
### Artikel 9 – Rechenunterstützung für KI-Projekte

- (1) Die Union und die Mitgliedstaaten sorgen dafür, dass im Rahmen der verfügbaren Kapazitäten ausreichende KI-Rechenressourcen aus ihren Rechenkapazitäten zugewiesen werden, um die Entwicklung vorrangiger Grenz-KI-Projekte, die den in Artikel 8 festgelegten Kriterien entsprechen, zu unterstützen.

- (2) Die Union stellt KI-Rechenressourcen in einem Umfang, der zumindest den von den Mitgliedstaaten für vorrangige Grenz-KI-Projekte zugewiesenen KI-Rechenressourcen entspricht, bereit, sofern ausreichende KI-Rechenkapazitäten im Rahmen des Unionsanteils an der europäischen Zugangszeit zu Hochleistungsrechnern zur Verfügung stehen.

- (3) Die Union und die Mitgliedstaaten bemühen sich, ausreichende Rechenressourcen für KI-Projekte für industrielle Innovationen, für physische KI und für den öffentlichen Sektor bereitzustellen.

TITEL III RECHENZENTRUMSKAPAZITÄTEN

## Kapitel I Beschleunigungsgebiete für Rechenzentren

<a id="art-10"></a>
### Artikel 10 – Ausweisung von Beschleunigungsgebieten für Rechenzentren

- (1) Werden im Hoheitsgebiet eines Mitgliedstaats Rechenzentrumskapazitäten aufgebaut, so weist dieser Mitgliedstaat bis zum [Amt für Veröffentlichungen: Bitte Datum sechs Monate nach dem Inkrafttreten dieser Verordnung einfügen] mindestens ein Beschleunigungsgebiet für Rechenzentren (im Folgenden „Beschleunigungsgebiet“) in seinem Hoheitsgebiet aus. Bei der Ausweisung von Beschleunigungsgebieten berücksichtigen die Mitgliedstaaten folgende Aspekte:

  - a) die Lage und Größe des Standorts oder Gebiets sowie die Mindest- und Höchstgröße der Anlagen, die dort errichtet werden könnten;

  - b) die derzeit verfügbare und künftige Stromnetzkapazität sowie die Möglichkeiten der Speicherung vor Ort und der Erzeugung sauberer Energie mit den entsprechenden Bedingungen;

  - c) die verfügbare und künftige Netzanbindungskapazität;

  - d) die Kapazität des Gebiets, die schrittweise erfolgende Abschaltung herkömmlicher Kupferkabelnetze zu unterstützen;

  - e) die verfügbaren und künftigen Anlagen, die Abwärme aus Rechenzentren weiterverwenden können;

  - f) alle Maßnahmen, die ergriffen wurden, um die Erteilung der erforderlichen Genehmigungen für den Bau und den Betrieb von Rechenzentren in dem betreffenden Gebiet zu beschleunigen;

  - g) die bevorzugte Weiterverwendung von Industriebrachen gegenüber der Nutzung von neu zu erschließenden Flächen;

  - h) die Möglichkeiten für ein nachhaltiges Funktionieren des Standorts oder Gebiets,, insbesondere im Hinblick auf die Vermeidung oder Minimierung von Umweltauswirkungen und die Unterstützung der Verringerung von CO2-Emissionen sowie seine Klimaresilienz.

- (2) Die Mitgliedstaaten ergreifen gegebenenfalls folgende Maßnahmen, um die Entwicklung von Beschleunigungsgebieten zu fördern:

  - a) Durchführung und mindestens alle drei Jahre Überprüfung einer umfassenden Analyse des Energiebedarfs und der entsprechenden Auswirkungen auf die Treibhausgasemissionen bestehender und künftiger Beschleunigungsgebiete und Ermittlung der erforderlichen Energieinfrastrukturkapazität für das ordnungsgemäße Funktionieren und die Entwicklung von Rechenzentrumsprojekten in den Beschleunigungsgebieten. Eine solche Analyse wird zumindest bei der Ausweisung der Beschleunigungsgebiete gemäß Absatz 1 durchgeführt;

  - b) Sicherstellung, dass die von den Übertragungsnetzbetreibern gemäß Artikel 51 der Richtlinie (EU) 2019/944 des Europäischen Parlaments und des Rates und den Verteilernetzbetreibern gemäß Artikel 32 der Richtlinie (EU) 2019/944 aufgestellten Netzentwicklungspläne der gemäß Buchstabe a des vorliegenden Absatzes erstellten Analyse gebührend Rechnung tragen, wobei das Potenzial vorgezogener Investitionen zur Deckung des künftigen Systembedarfs zu berücksichtigen ist.

- (3) Die nationalen, regionalen und lokalen Behörden, die für die Ausarbeitung von Raumordnungs- und Entwicklungsplänen zuständig sind, ziehen in Erwägung, in diese Pläne Bestimmungen für die Entwicklung von Rechenzentrumsprojekten, die in Beschleunigungsgebieten durchgeführt werden, und der erforderlichen Infrastrukturen aufzunehmen. Die Mitgliedstaaten stellen sicher, dass den Betreibern von Rechenzentren alle einschlägigen Raumplanungsdaten zur Verfügung stehen. Werden diese Pläne einer Prüfung gemäß der Richtlinie 2001/42/EG des Europäischen Parlaments und des Rates und gemäß Artikel 6 der Richtlinie 92/43/EWG unterzogen, so werden diese Prüfungen kombiniert. Bei der kombinierten Prüfung werden gegebenenfalls auch die Auswirkungen auf potenziell betroffene Wasserkörper im Sinne der Richtlinie 2000/60/EG des Europäischen Parlaments und des Rates untersucht.

- (4) Bei der Ausweisung von Beschleunigungsgebieten sorgen die Mitgliedstaaten für die Einbeziehung und Koordinierung aller einschlägigen nationalen, regionalen und lokalen Behörden und Stellen, einschließlich der Betreiber im Sinne des Artikels 2 Nummer 29 der Richtlinie (EU) 2018/1972 des Europäischen Parlaments und des Rates, der Übertragungsnetzbetreiber im Sinne des Artikels 2 Nummer 35 der Richtlinie (EU) 2019/944 und der Verteilernetzbetreiber im Sinne des Artikels 2 Nummer 29 der Richtlinie (EU) 2019/944.

<a id="art-11"></a>
### Artikel 11 – Bedingungen innerhalb der Beschleunigungsgebiete

- (1) Bei der Festlegung der Nachhaltigkeitsanforderungen für Rechenzentren, die in Beschleunigungsgebieten errichtet werden, verwenden die Mitgliedstaaten die in Anhang II Buchstaben a bis n der Delegierten Verordnung (EU) 2024/1364 gemäß der Richtlinie (EU) 2023/1791 festgelegten wesentlichen Leistungsindikatoren.

- (2) Die Mitgliedstaaten stellen sicher, dass die Zuweisung und Nutzung von Ressourcen innerhalb von Beschleunigungsgebieten zu fairen, angemessenen und nichtdiskriminierenden Bedingungen erfolgt und nicht zu spekulativen Reservierungs- oder Abschottungspraktiken führt, die geeignet sind, einen wirksamen Wettbewerb oder die wirksame Entwicklung oder Nutzung dieser Gebiete zu behindern.

<a id="art-12"></a>
### Artikel 12 – Zentrale Informationsstellen

- (1) Der Betreiber eines Rechenzentrums hat das Recht, während des gesamten Lebenszyklus des Rechenzentrumsprojekts in einem Beschleunigungsgebiet auf Anfrage von einer zentralen Informationsstelle bei allen für die Errichtung des Rechenzentrums erforderlichen Genehmigungen unterstützt zu werden. Zu diesem Zweck benennen die Mitgliedstaaten eine oder mehrere zentrale Informationsstellen für Rechenzentrumsbetreiber von Rechenzentrumsprojekten in Beschleunigungsgebieten. Die Mitgliedstaaten können zu diesem Zweck eine gemäß der Verordnung (EU) 2024/1309 eingerichtete zentrale Informationsstelle benennen. Die Aufgaben, Verfahren und Mechanismen dieser zentralen Informationsstellen gemäß der Verordnung (EU) 2024/1309, auch in Bezug auf den digitalen Zugang, die Verwaltungskoordinierung und die Streitbeilegung, finden ebenfalls Anwendung.

- (2) Die Rolle einer zentralen Informationsstelle kann unter anderem die Koordinierung, Erleichterung, Überwachung und Weitergabe von Informationen über das Verfahren in Bezug auf Folgendes umfassen:

  - a) Raumplanung und Baugenehmigungen,

  - b) Umweltprüfungen gemäß der Verordnung (EU) 2026/XXXX [zur Beschleunigung von Umweltprüfungen],

  - c) Genehmigungen in Bezug auf Wasserentnahme, Abwassereinleitung sowie Wärmenutzung und -rückgewinnung,

  - d) Einhaltung der geltenden Verwaltungs- und Berichtspflichten,

  - e) Information der Öffentlichkeit mit dem Ziel, die öffentliche Akzeptanz des Rechenzentrumsprojekts zu erhöhen,

  - f) Anträge auf Anschluss an die Strom-, Wärme- oder Kommunikationsnetze oder an andere relevante Netze.

- (3) Die zentrale Informationsstelle hilft bei der Prüfung, ob ein Rechenzentrumsprojekt als strategisches Projekt im Sinne von Artikel 14 eingestuft werden kann.

- (4) Bei der in diesem Artikel genannten administrativen Unterstützung und Hilfestellung widmet die zentrale Informationsstelle KMU besondere Aufmerksamkeit und richtet gegebenenfalls einen speziellen Kanal für die Kommunikation mit KMU ein, um Orientierungshilfe zu geben und Anfragen im Zusammenhang mit der Durchführung dieser Verordnung zu beantworten.

<a id="art-13"></a>
### Artikel 13 – Erleichterung von Verwaltungs- und Genehmigungsverfahren

- (1) Rechenzentrumsprojekte, die in Beschleunigungsgebieten durchgeführt werden, gelten als strategische Projekte im Sinne des Artikels 14 der Verordnung (EU) 2026/XXX [zur Beschleunigung von Umweltprüfungen] und profitieren von dem im Anhang der genannten Verordnung festgelegten Instrumentarium.

- (2) Für jedes ausgewiesene Beschleunigungsgebiet erstellen und erteilen die Mitgliedstaaten eine aggregierte Grundgenehmigung, mit der die Errichtung von Rechenzentren in diesem Beschleunigungsgebiet genehmigt wird. Diese aggregierte Grundgenehmigung umfasst die Genehmigungen und behördlichen Zulassungen, die für die Rechenzentrumsprojekte innerhalb des Beschleunigungsgebiets erforderlich sind, mit Ausnahme anlagenspezifischer Genehmigungen.

- (3) Vor Erteilung der in Absatz 2 genannten aggregierten Grundgenehmigung führen die Mitgliedstaaten alle erforderlichen Verfahren und Prüfungen durch, einschließlich etwaiger einschlägiger Umweltprüfungen, Planungsverfahren und Bewertungen, die auf der Ebene des Beschleunigungsgebiets gelten.

- (4) Rechenzentren, die in Beschleunigungsgebieten errichtet werden, müssen nur für Tätigkeiten, die nicht unter die aggregierte Grundgenehmigung gemäß Absatz 2 fallen, zusätzliche Genehmigungen einholen.

- (5) Die Mitgliedstaaten stellen sicher, dass Verwaltungsanträge in Bezug auf Planung, Bau und Betrieb von Rechenzentren, die in Beschleunigungsgebieten errichtet werden, effizient, transparent und zeitnah bearbeitet werden. Das Genehmigungsverfahren für Rechenzentrumsprojekte, die in Beschleunigungsgebieten für Rechenzentren durchgeführt werden, darf eine Dauer von zwölf Monaten ab dem Zeitpunkt des Vorliegens eines vollständigen Antrags nicht überschreiten. Die Frist lässt etwaige von den Mitgliedstaaten festgelegte kürzere Fristen unberührt. Sofern ein solcher Status im nationalen Recht vorgesehen ist, erhalten Rechenzentrumsprojekte den Status der höchsten nationalen Bedeutung und werden in Genehmigungsverfahren entsprechend behandelt. Dieser Absatz gilt nur, wenn ein solcher Status im nationalen Recht vorgesehen ist, und verpflichtet die Mitgliedstaaten nicht, einen solchen Status einzuführen.

## Kapitel II Strategische Projekte

### Abschnitt 1 Benennung strategischer Rechenzentrumsprojekte

<a id="art-14"></a>
### Artikel 14 – Benennung strategischer Rechenzentrumsprojekte

- (1) Die Kommission kann Rechenzentrumsprojekte, die aufgrund offener Aufforderungen zur Interessenbekundung ausgewählt wurden, durch einen Beschluss als strategische Projekte benennen, sofern sie mindestens zwei der folgenden Kriterien erfüllen:

  - a) Durch das Projekt wird eine Infrastruktur geschaffen und betrieben, die wesentliche Funktionen des öffentlichen Sektors, einschließlich Forschung und Bildung, Gesundheitsversorgung, öffentliche Sicherheit und Gefahrenabwehr, unmittelbar unterstützt und verbessert;

  - b) das Projekt weist höchst nachhaltige oder innovative Merkmale auf, einschließlich Technologien und Lösungen, die im Rahmen des Titels II entwickelt werden;

  - c) das Projekt trägt zur Sicherheit und Stabilität des Stromnetzes und zur Deckung des vom betreffenden Netzbetreiber bestimmten Bedarfs des Stromnetzes bei, insbesondere bei Projekten, die die Kolokation großer Anlagen zur Erzeugung und Speicherung sauberer Energie umfassen;

  - d) das Projekt unterstützt die Integration von in der Union entworfenen und/oder hergestellten Chips, Prozessoren und Beschleunigern, Servern oder Quantencomputern in Rechenzentrumssysteme oder die Verwaltung von Rechenzentrumsanlagen, wodurch die Lieferketten der Union für Halbleiter, Quantentechnik und Rechenzentren gestärkt werden und ein Beitrag zu den Zielen der vorliegenden Verordnung und der Verordnung (EU) 2023/1781 geleistet wird;

  - e) das Projekt dient der Behebung eines erheblichen Mangels an Rechenkapazitäten in einem Gebiet, in dem ein solcher Mangel gemäß Artikel 15 festgestellt wurde, und trägt erheblich zum Wachstum, zur Entwicklung und zur Förderung der lokalen Wirtschaft bei.

- (2) In seinem Vorschlag legt der Antragsteller alle erforderlichen und sachdienlichen Informationen vor, um nachzuweisen, dass das Projekt die einschlägigen Kriterien erfüllt.

- (3) Die Dauer der Benennung als strategisches Projekt richtet sich nach dessen voraussichtlicher Lebensdauer. Der Antragsteller nimmt in den Vorschlag die Informationen auf, die erforderlich sind, um die voraussichtliche Lebensdauer des Projekts zu belegen, auf deren Grundlage die Dauer der Benennung als strategisches Projekt festgelegt wird.

- (4) Stellt die Kommission fest, dass ein als strategisches Projekt benanntes Projekt die einschlägigen Kriterien nicht mehr erfüllt, oder dass seine Benennung auf einem Antrag beruhte, der unrichtige Angaben zur Einhaltung dieser Kriterien enthielt, so kann sie die Benennung dieses Projekts durch einen Beschluss widerrufen. Projekte, deren Benennung als strategisches Projekt widerrufen wurde, verlieren alle Rechte im Zusammenhang mit dem Status gemäß dieser Verordnung.

## Kapitel III Überwachung

<a id="art-15"></a>
### Artikel 15 – Überwachung der Kapazitätslücke

- (1) Zur Überwachung der Fortschritte bei der Verwirklichung der Ziele des Beschlusses (EU) 2022/2481 ermittelt und überwacht die Kommission

  - a) die in der Union verfügbaren Rechenkapazitäten, einschließlich der Edge-Computing-Kapazitäten,

  - b) das Volumen der Nachfrage nach Rechenzentrumskapazitäten,

  - c) das Ausmaß der Kapazitätslücke und die unterversorgten Gebiete, die von der Kommission in Zusammenarbeit mit den Mitgliedstaaten bestimmt und anschließend als Beschleunigungsgebiete für den Aufbau von Rechenzentrumskapazitäten ausgewiesen werden könnten.

TITEL IV AUTONOMIE

## Kapitel I Rahmen für Cloud-Computing-Souveränität

### Abschnitt 1 Unionsvertrauenswürdigkeitsstufen

<a id="art-16"></a>
### Artikel 16 – Anwendungsbereich

- (1) Mit diesem Kapitel wird ein Unionsrahmen für Cloud-Computing-Souveränität geschaffen, der vier Unionsvertrauenswürdigkeitsstufen umfasst, deren Kriterien in Anhang II festgelegt sind und die Anbieter von Cloud-Computing-Diensten erfüllen müssen, um ihre Cloud-Computing-Dienste für Einrichtungen der Union und öffentliche Stellen bereitstellen zu dürfen.

- (2) Der Kommission wird die Befugnis übertragen, gemäß Artikel 45 delegierte Rechtsakte zur Änderung der in Anhang II festgelegten Unionsvertrauenswürdigkeitsstufen und der in Anhang III festgelegten Belege zu erlassen.

- (3) Um sicherzustellen, dass Anhang II und Anhang III mit neuen rechtlichen oder technischen Entwicklungen Schritt halten, überprüft die Kommission diese mindestens alle 18 Monate.

<a id="art-17"></a>
### Artikel 17 – Anerkennung von Anbietern von Cloud-Computing-Diensten

- (1) Ein Anbieter von Cloud-Computing-Diensten, der anerkennen lassen will, dass er eine Unionsvertrauenswürdigkeitsstufe anbietet, stellt bei der zuständigen nationalen Behörde am Niederlassungsort einen Antrag auf Anerkennung. Bei der Einreichung eines Antrags auf Anerkennung fügt der Anbieter von Cloud-Computing-Diensten alle nach den Absätzen 3 oder 4 erforderlichen einschlägigen Belege bei.

- (2) Die zuständige Behörde am Niederlassungsort ist die bewertende zuständige nationale Behörde. Eine bewertende zuständige nationale Behörde, bei der ein Antrag eines Antragstellers auf Anerkennung eingegangen ist, kann erforderlichenfalls eine oder mehrere zuständige Behörden der anderen Mitgliedstaaten ersuchen, am Verfahren für die Anerkennung des Antragstellers gemäß diesem Artikel mitzuwirken. Innerhalb von 15 Tagen nach Eingang eines solchen Antrags bestätigt die nationale Behörde, die ein Ersuchen um Zusammenarbeit erhalten hat, entweder, dass sie mit der bewertenden zuständigen nationalen Behörde zusammenarbeitet, oder lehnt das Ersuchen ab.

- (3) Für die Unionsvertrauenswürdigkeitsstufe 1 legt der sich beantragende Anbieter von Cloud-Computing-Diensten der bewertenden zuständigen nationalen Behörde die in Artikel 19 Absatz 2 genannte EU-Konformitätserklärung und alle erforderlichen Belege vor.

    Abweichend vom ersten Unterabsatz wird die von Anbietern von Cloud-Computing-Diensten, bei denen es sich um KMU handelt, gemäß Artikel 19 Absatz 2 ausgestellte EU-Konformitätserklärung in allen Mitgliedstaaten direkt und automatisch anerkannt, ohne dass eine vorherige Anerkennung durch die bewertende zuständige nationale Behörde erforderlich ist.

- (4) Für die Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 legt der Anbieter von Cloud-Computing-Diensten der bewertenden zuständigen nationalen Behörde den Prüfbericht, die in Artikel 20 genannten „positive“ Stellungnahme und alle Belege vor, die der Prüfstelle während des Prüfverfahrens vorgelegt wurden.

- (5) Innerhalb von 60 Tagen nach Eingang eines vollständigen Antrags gemäß Absatz 1 bewertet die bewertende zuständige nationale Behörde die gemäß den Absätzen 3 oder 4 vorgelegten Belege und

  - a) arbeitet den Entwurf eines Anerkennungsbescheids aus und teilt den zuständigen Behörden der anderen Mitgliedstaaten so bald wie möglich eine Überprüfungsfrist von 60 Tagen mit, nach der sie ihre beabsichtigte Anerkennung des Cloud-Computing-Dienstes in der gesamten Union als einen mit einer gültigen Unionsvertrauenswürdigkeitsstufe gebotenen Dienst zu bestätigen beabsichtigt. Die Mitteilung der Überprüfungsfrist an die zuständigen Behörden der anderen Mitgliedstaaten enthält die in den Absätzen 3 oder 4 genannten Belege oder

  - b) die bewertende zuständige Behörde kann, sofern die vorgelegten Belege nicht ausreichen, um ihr die Anerkennung des Cloud-Computing-Dienstes zu ermöglichen, vom Antragsteller weitere Informationen anfordern und ihn auffordern, diese Informationen innerhalb einer bestimmten Frist vorzulegen. Die 60-Tage-Frist gemäß Absatz 3 wird von dem Tag, an dem diese Informationen angefordert werden, bis zu dem Tag, an dem sie vorliegen, ausgesetzt. Die Aussetzung beträgt insgesamt jedoch höchstens 30 Tage, es sei denn, die Art der angeforderten Informationen oder außergewöhnliche Umstände rechtfertigen eine längere Aussetzung; oder

  - c) sie lehnt den Antrag auf Anerkennung ab. Bevor die bewertende zuständige Behörde den Antrag auf Anerkennung ablehnt, gibt sie dem potenziellen Anbieter von Cloud-Computing-Diensten Gelegenheit, innerhalb von 30 Tagen schriftlich zu den Schlussfolgerungen der Bewertung Stellung zu nehmen. Die bewertende zuständige Behörde trägt dieser Stellungnahme in der Endfassung ihrer Schlussfolgerungen angemessen Rechnung.

- (6) Während der in Absatz 5 Buchstabe a genannten Überprüfungsfrist kann die zuständige nationale Behörde eines anderen Mitgliedstaats bei der bewertenden zuständigen nationalen Behörde einen begründeten Einspruch erheben oder um Klarstellung ersuchen, wenn sie der Auffassung ist, dass der Entwurf des Anerkennungsbescheids nicht der in Anhang II festgelegten gültigen Unionsvertrauenswürdigkeitsstufe entspricht.

- (7) Wird innerhalb der in Absatz 5 Buchstabe a genannten Überprüfungsfrist kein begründeter Einspruch erhoben und kein Klarstellungsersuchen übermittelt, so gelten die Schlussfolgerungen der bewertenden zuständigen nationalen Behörde als von allen Mitgliedstaaten angenommen; in diesem Fall erlässt die bewertende zuständige nationale Behörde den Anerkennungsbescheid, mit dem der geprüfte Dienst in der gesamten Union auf der angemessenen Unionsvertrauenswürdigkeitsstufe anerkannt wird.

- (8) Wird innerhalb der in Absatz 5 Buchstabe a genannten Überprüfungsfrist ein Klarstellungsersuchen übermittelt, so trägt die bewertende zuständige nationale Behörde diesem Ersuchen gebührend Rechnung und fordert vom Antragsteller gemäß Absatz 5 Buchstabe b gegebenenfalls neue Informationen an oder bestätigt bzw. ändert ihren ursprünglichen Entwurf des Bescheids. Stellt dies die ersuchende zuständige Behörde nicht zufrieden, kann sie einen begründeten Einspruch erheben.

- (9) Wird innerhalb der in Absatz 5 Buchstabe a genannten Überprüfungsfrist oder nach dem in Absatz 8 genannten Verfahren ein begründeter Einspruch erhoben, so prüft die bewertende zuständige nationale Behörde den Einspruch und behält sodann entweder ihren ursprünglichen Bescheidentwurf bei oder zieht ihn zurück. Die bewertende zuständige nationale Behörde unterrichtet die zuständigen Behörden der anderen Mitgliedstaaten hiervon innerhalb von 15 Tagen nach Abschluss der in Absatz 5 Buchstabe a genannten Überprüfungsfrist oder innerhalb von 15 Tagen nach Eingang des begründeten Einspruchs nach dem in Absatz 8 genannten Verfahren, je nachdem, welches Verfahren anwendbar ist.

- (10) Beabsichtigt die bewertende zuständige nationale Behörde, ihren Bescheidentwurf beizubehalten, so kann die betroffene zuständige nationale Behörde die Kommission mit der Angelegenheit befassen. Die Kommission prüft die Befassung und kann die betreffenden zuständigen nationalen Behörden um Informationen ersuchen. Die Kommission erlässt einen verbindlichen Beschluss, in dem sie bestimmt, ob die bewertende zuständige nationale Behörde den Anerkennungsbescheid erlassen darf.

- (11) Die bewertende zuständige nationale Behörde kann ihre Anerkennung widerrufen, wenn sie feststellt, dass ein Anbieter von Cloud-Computing-Diensten, dessen Dienst in der gesamten Union als Dienst mit einer bestimmten Unionsvertrauenswürdigkeitsstufe anerkannt wurde, vorsätzlich oder fahrlässig unrichtige oder irreführende Informationen übermittelt hat.

- (12) Die Kommission kann Durchführungsrechtsakte in Bezug auf praktische Modalitäten für die in diesem Artikel genannten Verfahren erlassen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

- (13) Die Kommission kann zur Wahrnehmung der ihr gemäß Absatz 10 übertragenen Aufgaben verlangen, dass die zuständigen nationalen Behörden am Niederlassungsort so bald wie möglich und innerhalb einer angemessenen Frist alle einschlägigen Informationen über den betreffenden Anbieter von Cloud-Computing-Diensten und den Antrag auf Anerkennung übermitteln.

- (14) Bei der Übermittlung eines Auskunftsersuchens gibt die Kommission den Zweck des Ersuchens an, präzisiert, welche Informationen benötigt werden, und setzt die Frist für die Übermittlung der Informationen.

<a id="art-18"></a>
### Artikel 18 – Assoziierte Drittländer

- (1) Die Kommission kann im Wege von Durchführungsrechtsakten Beschlüsse zur Bestimmung von Drittländern erlassen, für die anhand der Kriterien für die Unionsvertrauenswürdigkeitsstufe 3 gemäß Anhang II die Anbieter von Cloud-Computing-Diensten, die der Kontrolle dieses Drittlands oder eines in diesem Drittland niedergelassenen Rechtsträger unterliegen, geprüft werden können, sofern dieses Drittland die folgenden kumulativen Kriterien erfüllt:

  - a) Es ist Gegenstand eines nach Artikel 45 der Verordnung (EU) 2016/679 erlassenen einschlägigen Angemessenheitsbeschlusses;

  - b) es hat keine Vorschriften, die es ihm ermöglichen, Kontrolle über den Anbieter von Cloud-Computing-Diensten in einer Weise auszuüben, die den Anforderungen an den rechtmäßigen Zugang zu nicht personenbezogenen Daten gemäß Artikel 32 Absätze 2 und 3 der Verordnung (EU) 2023/2854 zuwiderlaufen würde;

  - c) es hat keine Vorschriften, um den Anbieter von Cloud-Computing-Diensten zu zwingen, die Dienstkontinuität oder -bereitstellung zu beeinträchtigen oder zu stören. Es hat auch keine Vorschriften, die den Anbieter von Cloud-Computing-Diensten dazu verpflichten, restriktive Maßnahmen wie Sanktionsregelungen, Embargos oder gleichwertige rechtliche oder administrative Maßnahmen umzusetzen, durchzusetzen, auszuführen oder einzuhalten, es sei denn, diese spezifischen Maßnahmen sind nach dem nationalen Recht der Mitgliedstaaten oder dem Unionsrecht rechtmäßig;

  - d) es hat keine Vorschriften, um die Bereitstellung modernster Technologien und Dienste durch einen Anbieter von Cloud-Computing-Diensten zu behindern;

  - e) sein Markt steht Cloud-Computing-Diensten der Union offen;

  - f) das Drittland gewährt einen gleichwertigen Zugang zu Verfahren zur Vergabe öffentlicher Aufträge für Cloud-Computing-Dienste, die der Kontrolle eines Mitgliedstaats, einer Einrichtung der Union oder eines in der Union niedergelassenen Rechtsträgers unterliegen.

    Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

- (2) Geht aus den verfügbaren Informationen hervor, dass das Drittland die Anforderungen nach Absatz 1 nicht mehr erfüllt, so hebt die Kommission den in Absatz 1 genannten Beschluss auf, ändert ihn oder setzt ihn aus.

- (3) Die Kommission veröffentlicht auf ihrer Website eine Liste der Drittländer, die die Anforderungen nach Absatz 1 erfüllen, und eine Liste der Drittländer, die dies nicht mehr tun.

### Abschnitt 2 Konformitätsbewertungsverfahren

<a id="art-19"></a>
### Artikel 19 – Selbstbewertung der Konformität

- (1) Anbieter von Cloud-Computing-Diensten, die gemäß Artikel 17 anerkennen lassen wollen, dass sie die Unionsvertrauenswürdigkeitsstufe 1 anbieten, führen eine Selbstbewertung der Konformität anhand der in Anhang II festgelegten Kriterien für die Unionsvertrauenswürdigkeitsstufe 1 durch.

- (2) Im Anschluss an die in Absatz 1 genannte Selbstbewertung stellt der Anbieter von Cloud-Computing-Diensten eine EU-Konformitätserklärung aus, aus der hervorgeht, dass die Einhaltung der Kriterien für die Unionsvertrauenswürdigkeitsstufe 1 nachgewiesen wurde. Mit der Ausstellung einer solchen Erklärung übernimmt der Anbieter von Cloud-Computing-Diensten die Verantwortung dafür, dass der Cloud-Computing-Dienst die in Anhang II festgelegten Kriterien für die Unionsvertrauenswürdigkeitsstufe 1 erfüllt.

- (3) Der Anbieter von Cloud-Computing-Diensten macht die EU-Konformitätserklärung öffentlich zugänglich.

### Abschnitt 3 Prüfungen durch unabhängige Dritte

<a id="art-20"></a>
### Artikel 20 – Unabhängige Prüfung

- (1) Anbieter von Cloud-Computing-Diensten, die gemäß Artikel 17 anerkennen lassen wollen, dass sie die Unionsvertrauenswürdigkeitsstufe 2, 3 oder 4 anbieten, müssen sich auf eigene Kosten Prüfungen durch unabhängige Dritte unterziehen, um von einer Prüfstelle einen Prüfbericht und eine Stellungnahme zu erhalten. Ein geprüfter Anbieter, der einem Prüfverfahren auf einer höheren Unionsvertrauenswürdigkeitsstufe unterzogen wird, muss auch alle anwendbaren kumulativen Kriterien gemäß Anhang II erfüllen, die für die niedrigeren Unionsvertrauenswürdigkeitsstufen gelten. Werden Anforderungen einer niedrigeren Vertrauenswürdigkeitsstufe nicht erfüllt, so schließt dies die Einhaltung der höheren Unionsvertrauenswürdigkeitsstufen aus.

- (2) Geprüfte Anbieter arbeiten mit Prüfstellen zusammen und leisten ihnen die erforderliche Unterstützung, damit sie diese Prüfungen wirksam, effizient und zeitnah durchführen können, unter anderem indem sie ihnen Zugang zu allen einschlägigen Daten und Räumlichkeiten gewähren und mündliche oder schriftliche Fragen beantworten. Geprüfte Anbieter dürfen die Durchführung der Prüfung nicht behindern, übermäßig beeinflussen oder untergraben.

- (3) Die Prüfstellen gewährleisten ein angemessenes Maß an Vertraulichkeit und die Wahrung des Berufsgeheimnisses in Bezug auf die Informationen, die sie von den geprüften Anbietern und von Dritten im Rahmen der Prüfungen erhalten, auch nach Abschluss der Prüfungen. Diese Anforderung darf die Durchführung der Prüfungen und andere Bestimmungen dieser Verordnung nicht beeinträchtigen. Gemäß Artikel 23 gibt die Prüfstelle nur Informationen weiter, die für die Berichterstattung erforderlich sind und keine Informationen enthalten, die nach vernünftigem Ermessen als vertraulich angesehen werden könnten.

- (4) Die Prüfungen gemäß Absatz 1 werden von Prüfstellen durchgeführt, die

  - a) unabhängig von dem betreffenden Anbieter von Cloud-Computing-Diensten und den mit ihm verbundenen juristischen Personen sind und sich in keinem Interessenkonflikt mit ihnen befinden, insbesondere

    - i) haben sie in den 12 Monaten vor Beginn der Prüfung keine prüfungsfremden Leistungen im Zusammenhang mit den geprüften Sachverhalten für den betreffenden Anbieter von Cloud-Computing-Diensten und für mit diesem verbundene juristische Personen erbracht und sich verpflichtet, ihnen solche Dienstleistungen in den 12 Monaten nach Abschluss der Prüfung nicht zu erbringen,

    - ii) haben sie in den zehn Jahren vor Beginn der Prüfung keine Prüfdienstleistungen gemäß diesem Artikel für den betreffenden Anbieter von Cloud-Computing-Diensten oder eine mit diesem Anbieter verbundene juristische Person erbracht,

    - iii) haben sie die Prüfung nicht gegen Honorare durchgeführt, die vom Ergebnis der Prüfung abhängen;

  - b) nachweislich über Sachkenntnis, technische Kompetenz und Fähigkeiten im Bereich der Prüfung von Cloud-Computing-Diensten verfügen;

  - c) nachweislich mit Objektivität und gemäß der Berufsethik arbeiten, insbesondere aufgrund der Einhaltung von Verhaltenskodizes oder der einschlägigen Normen.

- (5) Die Prüfstellen, die die Prüfungen durchführen, erstellen für jede Prüfung einen Prüfbericht. Dieser Bericht enthält eine schriftliche Begründung sowie mindestens Folgendes:

  - a) Name, Anschrift und Anlaufstelle des geprüften Anbieters sowie den abgedeckten Zeitraum,

  - b) Name und Anschrift der Prüfstelle(n), die die Prüfung durchführt bzw. durchführen,

  - c) Interessenerklärung,

  - d) Beschreibung der konkret geprüften Aspekte und der angewandten Methode,

  - e) Beschreibung und Zusammenfassung der wichtigsten Erkenntnisse aus der Prüfung,

  - f) Auflistung der Dritten, die im Rahmen der Prüfung konsultiert wurden,

  - g) eine „positive“ oder „negative“ Stellungnahme und alle Informationen darüber, ob der geprüfte Dienst des geprüften Anbieters die geltenden Prüfkriterien für die Unionsvertrauenswürdigkeitsstufe 2, 3 oder 4 gemäß Anhang II erfüllt;

  - h) falls die Stellungnahme „negativ“ ist, operative Empfehlungen für besondere Maßnahmen im Hinblick auf die Einhaltung aller Pflichten und Verpflichtungszusagen und den empfohlenen Zeitrahmen dafür;

  - i) falls die Stellungnahme „positiv“ ist, die gemäß Artikel 17 anzuerkennende Unionsvertrauenswürdigkeitsstufe, die für den geprüften Dienst des geprüften Anbieters gemäß den in Anhang II festgelegten anwendbaren Kriterien anerkannt wird.

- (6) War die Prüfstelle nicht in der Lage, bestimmte Aspekte zu prüfen oder auf der Grundlage ihrer Untersuchungen eine Stellungnahme abzugeben, so muss der Prüfbericht eine Erläuterung der Umstände und der Gründe enthalten, aus denen diese Aspekte nicht geprüft werden konnten.

- (7) Die Prüfstelle kann ihren Prüfbericht und ihre Stellungnahme widerrufen, wenn der geprüfte Anbieter vorsätzlich oder fahrlässig unrichtige oder irreführende Prüfbelege vorgelegt hat.

- (8) Der geprüfte Anbieter legt jährlich den Prüfbericht und die zugehörige „positive“ Stellungnahme zur Überprüfung derselben oder einer anderen Prüfstelle vor, die bewertet, ob der geprüfte Dienst weiterhin die in Anhang II festgelegten anwendbaren Kriterien erfüllt. Auf der Grundlage der jährlichen Überprüfung kann die Prüfstelle den ursprünglichen Prüfbericht und die ursprüngliche Stellungnahme bestätigen, aktualisieren oder widerrufen.

- (9) Der Kommission wird die Befugnis übertragen, gemäß Artikel 45 delegierte Rechtsakte zur Ergänzung dieser Verordnung zu erlassen, um Vorschriften für die Durchführung von Prüfungen, die Verfahrensschritte, Prüfstellen und ihre technischen Kompetenzen, Prüfmethoden und Muster für die Prüfberichte festzulegen.

<a id="art-21"></a>
### Artikel 21 – Inhalt und Qualität der Prüfbelege

- (1) Zur Erstellung des Prüfberichts und der Stellungnahme bewertet die Prüfstelle anhand der in Anhang III aufgeführten Prüfbelege, ob der geprüfte Dienst die in Anhang II festgelegten Kriterien erfüllt. Der Kommission wird die Befugnis übertragen, gemäß Artikel 45 delegierte Rechtsakte zur Änderung des Anhangs III zu erlassen, in denen sie die erforderlichen Belege für die Bewertung der Prüfkriterien gemäß Anhang II festlegt.

- (2) Die Prüfbelege müssen

  - a) relevant und ausreichend sein, damit die Prüfstelle einen Prüfbericht erstellen und eine Stellungnahme abgeben kann, und

  - b) nach dem fachlichen Urteil und der kritischen Grundhaltung der Prüfstelle verlässlich sein.

<a id="art-22"></a>
### Artikel 22 – Zentralverzeichnis der Cloud-Computing-Dienste

- (1) Die Kommission richtet ein spezielles Verzeichnis der gemäß Artikel 17 anerkannten Cloud-Computing-Dienste (im Folgenden „Zentralverzeichnis“) ein und führt dieses.

- (2) Die zuständige nationale Behörde am Niederlassungsort, die einen Cloud-Computing-Dienst gemäß Artikel 17 anerkannt hat, trägt den Cloud-Computing-Dienst in das Zentralverzeichnis ein.

- (3) Der Widerruf eines Prüfberichts und einer Stellungnahme durch eine Prüfstelle oder der Widerruf einer Anerkennung durch eine zuständige Behörde werden im Zentralverzeichnis veröffentlicht und bleiben dort fünf Jahre lang zugänglich.

- (4) Das Zentralverzeichnis ist öffentlich zugänglich und wird von der Kommission und den zuständigen nationalen Behörden am Niederlassungsort auf einer eigens dafür eingerichteten und leicht zugänglichen Website regelmäßig aktualisiert.

<a id="art-23"></a>
### Artikel 23 – Transparenzpflichten

- (1) Erhält der anerkannte Anbieter von Cloud-Computing-Diensten Kenntnis von Informationen oder wesentlichen Änderungen der Umstände, die sich auf den Prüfbericht und die „positive“ Stellungnahme nach Artikel 20 oder die Anerkennung nach Artikel 17 auswirken könnten, so meldet er dies so bald wie möglich der Prüfstelle und der zuständigen nationalen Behörde am Niederlassungsort.

- (2) Aufgrund der Meldung nach Absatz 1 beurteilt die Prüfstelle, ob der Prüfbericht oder die Stellungnahme geändert oder widerrufen werden muss. Ändert oder widerruft die Prüfstelle den Prüfbericht oder die Stellungnahme, so meldet sie dies so bald wie möglich der zuständigen nationalen Behörde am Niederlassungsort.

- (3) Aufgrund der Meldung nach Absatz 1 oder 2 beurteilt die zuständige nationale Behörde am Niederlassungsort, ob ihre Anerkennung geändert oder widerrufen werden muss. Ändert oder widerruft die zuständige nationale Behörde am Niederlassungsort die Anerkennung des Cloud-Computing-Dienstes, so teilt sie dies den zuständigen nationalen Behörden der anderen Mitgliedstaaten und der Kommission so bald wie möglich mit.

<a id="art-24"></a>
### Artikel 24 – Sanktionen und Schadenersatz

- (1) Die Mitgliedstaaten erlassen Vorschriften über Sanktionen, die bei Verstößen gegen dieses Kapitel durch Anbieter von Cloud-Computing-Diensten, die in ihre Zuständigkeit fallen, zu verhängen sind, und treffen alle für die Umsetzung der Sanktionen erforderlichen Maßnahmen. Die vorgesehenen Sanktionen müssen wirksam, verhältnismäßig und abschreckend sein. Die Mitgliedstaaten teilen der Kommission diese Vorschriften und Maßnahmen so bald wie möglich mit und melden ihr alle nachfolgenden diesbezüglichen Änderungen.

- (2) Bei der Verhängung von Sanktionen aufgrund von Verstößen gegen diese Verordnung berücksichtigen die Mitgliedstaaten die folgenden nicht erschöpfenden Kriterien:

  - a) Art, Schwere, Umfang und Dauer des Verstoßes,

  - b) Maßnahmen, die die verstoßende Partei ergriffen hat, um den durch den Verstoß verursachten Schaden zu mindern oder zu beheben,

  - c) frühere Verstöße der verstoßenden Partei,

  - d) finanzielle Vorteile, die die verstoßende Partei durch den Verstoß erzielt, oder die Verluste, die sie durch ihn vermieden hat, sofern diese Vorteile oder Verluste zuverlässig festgestellt werden können,

  - e) etwaige andere erschwerende oder mildernde Umstände im jeweiligen Fall,

  - f) den Jahresumsatz der verstoßenden Partei im vorangegangenen Geschäftsjahr in der Union.

- (3) Nutzer von Cloud-Computing-Diensten haben das Recht, im Einklang mit dem Unionsrecht und nationalen Recht Schadenersatz von Anbietern von Cloud-Computing-Diensten für etwaige Schäden oder Verluste zu fordern, die aufgrund eines Verstoßes dieser Anbieter gegen die Verpflichtungen gemäß diesem Kapitel entstanden sind.

### Abschnitt 4 Zuständige nationale Behörden

<a id="art-25"></a>
### Artikel 25 – Zuständige nationale Behörden

- (1) Bis zum [Amt für Veröffentlichungen: Bitte Datum 1 Jahr nach dem Inkrafttreten einfügen] benennen die Mitgliedstaaten eine oder mehrere für die Durchsetzung dieses Kapitels zuständige nationale Behörden. Dazu können die Mitgliedstaaten eine oder mehrere bestehende Behörden (im Folgenden „zuständige Behörden“) benennen.

- (2) Die Mitgliedstaaten teilen der Kommission die Namen der zuständigen Behörden und ihre Aufgaben und Befugnisse mit. Die Kommission führt ein öffentliches Register dieser Behörden.

- (3) Die Mitgliedstaaten stellen sicher, dass ihre zuständigen Behörden ihre Aufgaben im Rahmen dieser Verordnung unparteiisch, transparent und zeitnah erfüllen. Die Mitgliedstaaten sorgen dafür, dass ihren zuständigen Behörden alle erforderlichen Ressourcen zur Ausführung ihrer Aufgaben zur Verfügung stehen, einschließlich ausreichender technischer, finanzieller und personeller Ressourcen für eine angemessene Beaufsichtigung aller in ihren Zuständigkeitsbereich fallenden Anbieter von Cloud-Computing-Diensten.

- (4) Für die Durchsetzung dieses Kapitels ist ausschließlich der Mitgliedstaat zuständig, in dem der Anbieter von Cloud-Computing-Diensten seine Hauptniederlassung hat, d. h. in dem er seine Hauptverwaltung oder seinen eingetragenen Sitz hat, von dem aus die wichtigsten finanziellen Tätigkeiten und die betriebliche Kontrolle erfolgen.

<a id="art-26"></a>
### Artikel 26 – Befugnisse der zuständigen nationalen Behörden

- (1) Soweit dies für die Wahrnehmung ihrer Aufgaben nach Artikel 17 erforderlich ist, verfügen die zuständigen Behörden am Niederlassungsort über folgende Untersuchungsbefugnisse:

  - a) die Befugnis, von allen Anbietern von Cloud-Computing-Diensten sowie von allen anderen Personen, die zu Zwecken ihrer gewerblichen, geschäftlichen, handwerklichen oder beruflichen Tätigkeit handeln und bei denen nach vernünftigem Ermessen davon ausgegangen werden kann, dass sie Kenntnis von Informationen über eine mutmaßliche Zuwiderhandlung gegen diese Verordnung haben, einschließlich Prüfstellen, zu verlangen, dass sie diese Informationen so bald wie möglich übermitteln,

  - b) die Befugnis, in allen Räumlichkeiten, die diese Anbieter oder diese Personen, die zu Zwecken ihrer gewerblichen, geschäftlichen, handwerklichen oder beruflichen Tätigkeit handeln, für Zwecke ihrer gewerblichen, geschäftlichen, handwerklichen oder beruflichen Tätigkeit nutzen, Nachprüfungen durchzuführen oder eine Justizbehörde in ihrem Mitgliedstaat zur Anordnung solcher Nachprüfungen aufzufordern, oder andere Behörden aufzufordern, dies zu tun, um Informationen über eine mutmaßliche Zuwiderhandlung unabhängig vom Speichermedium zu untersuchen, sicherzustellen oder Kopien davon anzufertigen oder zu erhalten,

  - c) die Befugnis, alle Mitarbeiter oder Vertreter dieser Anbieter oder Personen, die zu Zwecken ihrer gewerblichen, geschäftlichen, handwerklichen oder beruflichen Tätigkeit handeln, aufzufordern, Erklärungen zu allen Informationen im Zusammenhang mit einer mutmaßlichen Zuwiderhandlung abzugeben, und die Antworten mit ihrer Einwilligung mit beliebigen technischen Mitteln aufzuzeichnen.

- (2) Soweit dies für die Wahrnehmung ihrer Aufgaben nach Artikel 17 erforderlich ist, verfügen die zuständigen nationalen Behörden am Niederlassungsort über folgende Durchsetzungsbefugnisse:

  - a) die Befugnis zur Anordnung der Einstellung von Zuwiderhandlungen und gegebenenfalls Verhängung von Abhilfemaßnahmen, die in einem angemessenen Verhältnis zur Zuwiderhandlung stehen und erforderlich sind, um die Zuwiderhandlung wirksam zu beenden, oder zur Aufforderung einer Justizbehörde in ihrem Mitgliedstaat, dies zu tun,

  - b) die Befugnis zur Verhängung von Geldbußen wegen Nichteinhaltung dieser Verordnung, auch der nach Absatz 1 erlassenen Untersuchungsanordnungen, oder zur Aufforderung einer Justizbehörde in ihrem Mitgliedstaat, dies zu tun,

  - c) die Befugnis zur Verhängung eines Zwangsgelds gemäß Artikel 24, um sicherzustellen, dass eine Zuwiderhandlung nach einem gemäß Buchstabe a erlassenen Beschluss oder die Nichtbefolgung einer der gemäß Absatz 1 erlassenen Untersuchungsanordnungen beendet wird, oder zur Aufforderung einer Justizbehörde in ihrem Mitgliedstaat, dies zu tun.

- (3) Die von zuständigen nationalen Behörden am Niederlassungsort in Ausübung ihrer in den Absätzen 1 und 2 genannten Befugnisse ergriffenen Maßnahmen müssen wirksam, abschreckend und verhältnismäßig sein, wobei insbesondere die Art, Schwere, Wiederholung und Dauer der Zuwiderhandlung oder der mutmaßlichen Zuwiderhandlung, auf die sich diese Maßnahmen beziehen, sowie gegebenenfalls die wirtschaftliche, technische und operative Leistungsfähigkeit des betreffenden Diensteanbieters zu berücksichtigen sind.

- (4) Die Mitgliedstaaten legen spezifische Bedingungen und Verfahren für die Ausübung der Befugnisse gemäß den Absätzen 1 und 2 fest und stellen sicher, dass jede Ausübung dieser Befugnisse angemessenen Garantien unterliegt, die im anwendbaren nationalen Recht unter Einhaltung der allgemeinen Grundsätze des Unionsrechts festgelegt sind. Diese Maßnahmen dürfen nur im Einklang mit dem Recht auf Achtung des Privatlebens und mit den Verteidigungsrechten, einschließlich des Rechts auf rechtliches Gehör und auf Akteneinsicht, und vorbehaltlich des Rechts aller betroffenen Parteien auf einen wirksamen gerichtlichen Rechtsbehelf getroffen werden.

### Abschnitt 5 Amtshilfe und Zusammenarbeit

<a id="art-27"></a>
### Artikel 27 – Amtshilfe

- (1) Im Hinblick auf eine einheitliche und effiziente Anwendung dieses Kapitels arbeiten die zuständigen Behörden und die Kommission eng zusammen und leisten einander Amtshilfe. Die Amtshilfe umfasst auch den Austausch von Informationen.

- (2) Eine zuständige Behörde kann andere zuständige Behörden ersuchen, ihr vorliegende spezifische Informationen über einen bestimmten Anbieter von Cloud-Computing-Diensten zur Verfügung zu stellen, oder ihre Untersuchungsbefugnisse nach Artikel 26 in Bezug auf spezifische Informationen, die sich in ihrem Mitgliedstaat befinden, auszuüben. Gegebenenfalls kann die zuständige Behörde, die ein solches Ersuchen erhält, andere zuständige Behörden oder andere Behörden des betreffenden Mitgliedstaats mit einbeziehen.

- (3) Die zuständige Behörde, an die ein Ersuchen nach Absatz 2 ergeht, kommt diesem Ersuchen nach und unterrichtet die zuständige Behörde am Niederlassungsort so bald wie möglich und spätestens zwei Monate nach Eingang des Ersuchens über die ergriffenen Maßnahmen, es sei denn, es liegen hinreichend gerechtfertigte Gründe vor.

<a id="art-28"></a>
### Artikel 28 – Grenzüberschreitende Zusammenarbeit

- (1) Hat eine zuständige Behörde am Bestimmungsort Grund zu der Annahme, dass ein Anbieter von Cloud-Computing-Diensten die Anforderung nach Anhang II dieser Verordnung nicht mehr erfüllt, so kann sie die zuständige Behörde am Niederlassungsort ersuchen, die Angelegenheit zu prüfen und die erforderlichen Untersuchungs- und Durchsetzungsmaßnahmen zu ergreifen, um die Einhaltung der Anforderungen sicherzustellen.

- (2) Auch die Kommission kann die in Artikel 25 genannte zuständige Behörde ersuchen, die Angelegenheit zu prüfen und die erforderlichen Untersuchungs- und Durchsetzungsmaßnahmen zu ergreifen, um die Einhaltung der Vorschriften sicherzustellen.

- (3) Ersuchen nach Absatz 1 oder 2 sind hinreichend zu begründen und müssen von der zuständigen Behörde am Niederlassungsort gebührend berücksichtigt werden. Ist die zuständige Behörde am Niederlassungsort der Auffassung, dass die vorgelegten Informationen unzureichend sind, so kann sie zusätzliche Informationen anfordern. Die Frist gemäß Absatz 4 ruht, bis diese zusätzlichen Informationen vorliegen.

- (4) Die zuständige Behörde am Niederlassungsort teilt der zuständigen Behörde, die das Ersuchen übermittelt hat, und der Kommission so bald wie möglich, in jedem Fall aber spätestens zwei Monate nach Eingang des Ersuchens gemäß Absatz 1 oder 2, ihre Bewertung der mutmaßlichen Zuwiderhandlung sowie eine Erläuterung etwaiger Untersuchungs- oder Durchsetzungsmaßnahmen mit, die im Zusammenhang mit der Angelegenheit ergriffen wurden oder geplant sind, um die Einhaltung dieser Verordnung sicherzustellen.

## Kapitel II Nachfrageseitige Maßnahmen

### Abschnitt 1 Vergabe öffentlicher Aufträge

<a id="art-29"></a>
### Artikel 29 – Risikobewertungen

- (1) Bis zum [Bitte Datum 1 Jahr nach dem Inkrafttreten einfügen] und danach alle zwei Jahre oder bei Bedarf führen die Mitgliedstaaten und Einrichtungen der Union Risikobewertungen durch, in deren Rahmen

  - a) die Tätigkeiten des öffentlichen Sektors ermittelt werden, für die Cloud-Computing-Dienste verwendet werden, die zur Aufrechterhaltung der öffentlichen Ordnung in Sektoren, die unter Anhang I oder II der Richtlinie (EU) 2022/2555 fallen, und in den Bereichen nationale Sicherheit, innere Sicherheit, Außengrenzenmanagement, Verteidigung, Justiz oder Strafverfolgung, einschließlich Verhütung, Ermittlung, Aufdeckung und Verfolgung von Straftaten, beitragen;

  - b) festgelegt wird, welche der in Anhang II dieser Verordnung festgelegten Unionsvertrauenswürdigkeitsstufen 2, 3 oder 4 für die ermittelten Tätigkeiten des öffentlichen Sektors angemessen ist.

    Teilen sich Einrichtungen der Union und Mitgliedstaaten die Zuständigkeiten in Bezug auf die Tätigkeiten des öffentlichen Sektors, so können sie gegebenenfalls die einschlägige(n) Risikobewertung(en) gemeinsam durchführen.

- (2) Bei der Durchführung ihrer Risikobewertungen berücksichtigen die Mitgliedstaaten und die Einrichtungen der Union zumindest die folgenden Aspekte:

  - a) die Sensibilität, Kritikalität und Größenordnung der verarbeiteten nicht personenbezogenen Daten, einschließlich der potenziellen Auswirkungen auf die öffentliche Ordnung und der Art, des Umfangs, der Umstände und des Zwecks der Verarbeitung personenbezogener Daten sowie der unterschiedlichen Eintrittswahrscheinlichkeit und Schwere des Risikos für die Rechte und Freiheiten der betroffenen Personen;

  - b) das Risiko und die sich daraus ergebenden Auswirkungen eines nach Unionsrecht unrechtmäßigen Zugangs eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers zu solchen Daten auf die öffentliche Ordnung;

  - c) das Risiko einer möglichen Störung des Dienstes und die sich daraus ergebenden Auswirkungen auf die öffentliche Ordnung.

- (3) Die Kommission legt im Wege von Durchführungsrechtsakten gemäß Artikel 46 Absatz 2 die anzuwendende Methode, die zu verwendenden Muster und die Elemente fest, die von den Mitgliedstaaten und den Einrichtungen der Union bei der Durchführung der in Absatz 1 genannten Risikobewertungen zu berücksichtigen sind. In der Methode wird festgelegt, wie die Mitgliedstaaten die höchste Vertrauenswürdigkeitsstufe für die kritischsten Tätigkeiten des öffentlichen Sektors, einschließlich, aber nicht beschränkt auf Verteidigung, verwenden sollen.

- (4) Innerhalb von drei Monaten nach der Durchführung der in Absatz 1 genannten Risikobewertungen übermitteln die Mitgliedstaaten der Kommission die Ergebnisse dieser Risikobewertungen und geben an, wo sie von den in Absatz 3 genannten Durchführungsrechtsakten abweichen.

- (5) Kommt die Kommission nach der Auswertung der Ergebnisse der Risikobewertung(en) eines Mitgliedstaats zu dem Schluss, dass die für die Tätigkeit des öffentlichen Sektors in einer Risikobewertung ermittelte Unionsvertrauenswürdigkeitsstufe nicht angemessen ist oder den Bedenken hinsichtlich der öffentlichen Ordnung nicht angemessen Rechnung trägt, so kann die Kommission Durchführungsrechtsakte gemäß Artikel 46 Absatz 2 erlassen, in denen die für die Tätigkeit des öffentlichen Sektors erforderlichen Unionsvertrauenswürdigkeitsstufen festgelegt werden.

- (6) Erfordert die Risikobewertung die Migration zu einem anderen Cloud-Computing-Dienst, so migriert der Mitgliedstaat oder die Einrichtung der Union innerhalb eines angemessenen Übergangszeitraums von höchstens 12 Monaten, wobei die für eine solche Migration geltenden Anforderungen an die technische Durchführbarkeit, die Dienstkontinuität und die Datenübertragbarkeit zu berücksichtigen sind.

- (7) Die Mitgliedstaaten arbeiten untereinander und mit der Kommission im Rahmen etablierter Kohärenzverfahren zusammen und fördern die Zusammenarbeit und den wirksamen Austausch von Informationen und bewährten Verfahren.

- (8) Für die Zwecke des Absatzes 3 ist die Kommission befugt, von Anbietern von Cloud-Computing-Diensten zu verlangen, dass sie alle erforderlichen Informationen zur Verfügung stellen.

- (9) Bei ihren Risikobewertungen prüfen die Mitgliedstaaten und die Einrichtungen der Union, ob im Rahmen ihrer Auftragsvergabe für Cloud-Computing-Dienste eine Mehranbieter-Strategie oder eine Multi-Cloud-Strategie angemessen ist.

<a id="art-30"></a>
### Artikel 30 – Vergabe öffentlicher Aufträge

- (1) Dieser Artikel gilt für öffentliche Auftraggeber, die Cloud-Computing-Dienste für ihre ausschließliche Nutzung beschaffen. Unbeschadet des Artikels 136 der Verordnung (EU, Euratom) 2024/2509 gilt dieser Artikel auch für Einrichtungen der Union, die Aufträge für Cloud-Computing-Dienste für ihre ausschließliche Nutzung vergeben.

- (2) Einrichtungen der Union und öffentliche Stellen, deren Tätigkeiten des öffentlichen Sektors der in Artikel 29 Absatz 1 genannten Risikobewertung zufolge nicht zur Aufrechterhaltung der öffentlichen Ordnung beitragen, nutzen Cloud-Computing-Dienste, die gemäß Artikel 17 mit der Unionsvertrauenswürdigkeitsstufe 1 eingestuft wurden.

- (3) Öffentliche Auftraggeber, einschließlich der in ihrem Namen handelnden Stellen, deren Tätigkeiten gemäß Artikel 29 Absatz 1 zur Aufrechterhaltung der öffentlichen Ordnung in Sektoren beitragen, die unter Anhang I oder II der Richtlinie (EU) 2022/2555 fallen, und die Tätigkeiten in den Bereichen nationale Sicherheit, innere Sicherheit, Außengrenzenmanagement, Verteidigung, Justiz oder Strafverfolgung, einschließlich der Verhütung, Ermittlung, Aufdeckung und Verfolgung von Straftaten, ausführen, vergeben Aufträge ausschließlich für Cloud-Computing-Dienste, die mit der Unionsvertrauenswürdigkeitsstufe 2, 3 oder 4 eingestuft wurden.

- (4) Abweichend von Absatz 2 oder 3 können öffentliche Auftraggeber in Ausnahmefällen und in hinreichend begründeten Fällen beschließen, keine Aufträge für Cloud-Computing-Dienste zu vergeben, die mit der Unionvertrauenswürdigkeitsstufe 1, 2, 3 oder 4 eingestuft wurden, wenn einer oder mehrere der folgenden Umstände vorliegen:

  - a) Die Dienstleistung, die Gegenstand der Ausschreibung ist, kann nicht von anerkannten Cloud-Computing-Diensten erbracht werden, die in dem in Artikel 22 genannten Zentralverzeichnis verfügbar sind, und es gibt keinen angemessenen oder vernünftigen alternativen oder vergleichbaren Cloud-Computing-Dienst, und das Fehlen eines solchen Dienstes ist nicht das Ergebnis einer künstlichen Einschränkung der Parameter des Verfahrens zur Vergabe öffentlicher Aufträge;

  - b) der öffentliche Auftraggeber hat im Vorjahr ein ähnliches Vergabeverfahren eingeleitet, aber keine geeigneten Angebote geeigneter Teilnehmer erhalten;

  - a) die Anwendung der Anforderungen dieser Verordnung würde den öffentlichen Auftraggeber dazu zwingen, Aufträge für Dienstleistungen zu unverhältnismäßig hohen Kosten zu vergeben.

### Abschnitt 2 Privatwirtschaftliche Einrichtungen

<a id="art-31"></a>
### Artikel 31 – Folgenabschätzungen

- (1) Die in Anhang I der Richtlinie (EU) 2022/2555 genannten Einrichtungen, bei denen es sich nicht um öffentliche Stellen handelt, können ähnliche Bewertungen wie die in Artikel 29 genannten durchführen.

- (2) Die Kommission kann Leitlinien zur Methode für die Durchführung der Folgenabschätzungen gemäß diesem Artikel und zu möglichen Risikominderungsmaßnahmen herausgeben, die von privatwirtschaftlichen Einrichtungen, die in Sektoren mit hoher Kritikalität tätig sind, zu ergreifen sind.

- (3) Gelangt die Kommission aufgrund besonderer Umstände in hinreichend begründeten Fällen und in Absprache mit den Mitgliedstaaten zu dem Schluss, dass für Einrichtungen, bei denen es sich nicht um öffentliche Stellen handelt, die in Sektoren mit hoher Kritikalität tätig sind, eine Folgenabschätzung erforderlich ist, so kann die Kommission gemäß Artikel 45 delegierte Rechtsakte zur Ergänzung dieser Verordnung erlassen, in denen die Notwendigkeit einer solchen Folgenabschätzung präzisiert wird und die Risikominderungsmaßnahmen, die diese Einrichtungen, bei denen es sich nicht um öffentliche Stellen handelt, ergreifen müssen, festgelegt werden.

### Abschnitt 3 Sonstige Maßnahmen im Zusammenhang mit der Vergabe öffentlicher Aufträge

<a id="art-32"></a>
### Artikel 32 – Mehrwert für die Union

- (1) Bei der Vergabe öffentlicher Aufträge für innovative Cloud-Computing-Dienste und KI-Systeme berücksichtigen die öffentlichen Auftraggeber im Rahmen der Qualitätsbewertung des Angebots nicht preisbezogene Zuschlagskriterien, anhand deren sie den Beitrag des Bieters zur Entwicklung eines europäischen Cloud- und KI-Ökosystems bewerten können.

- (2) Bei der Anwendung nicht preisbezogener Zuschlagskriterien gemäß Absatz 1 stellen die öffentlichen Auftraggeber sicher, dass die nicht preisbezogenen Zuschlagskriterien

  - a) an den Auftragsgegenstand geknüpft sind,

  - b) dem öffentlichen Auftraggeber keine uneingeschränkte Wahlfreiheit einräumen,

  - c) in den Auftragsunterlagen oder in der Auftragsbekanntmachung ausdrücklich angegeben sind,

  - d) Nebenbedingungen und nicht entscheidend für die Auftragsvergabe sind.

- (3) Ohne den Ermessensspielraum der öffentlichen Auftraggeber hinsichtlich der Anwendung zusätzlicher Kriterien zu beeinträchtigen, müssen die öffentlichen Auftraggeber anhand der in Absatz 1 genannten nicht preisbezogenen Zuschlagskriterien bewerten können, inwieweit

  - a) der Bieter zur Stärkung der Lieferkette für digitale Technologien in der Union beiträgt, einschließlich der Verwendung von in der Union entwickelter oder hergestellter Software oder Hardware;

  - b) der Bieter in der Union entwickelte Technologien integriert hat, einschließlich Forschungs- und Entwicklungsergebnissen aus von der Union finanzierten Forschungs- und Entwicklungsprogrammen, und in der Union entwickelte Instrumente wie Normen, Spezifikationen, Software, Modelle oder andere Technologien nutzt;

  - c) die für die Erbringung der Dienstleistung erforderliche Innovation zur Stärkung der Versorgungssicherheit und zur Entwicklung eines europäischen Cloud- und KI-Ökosystems beiträgt;

  - d) der Dienst im Hinblick auf die Marktverfügbarkeit und die technischen Anforderungen so weit wie möglich durch kritische Computer-, Speicher- und Netzwerkhardwarekomponenten erbracht wird, die in der Union entwickelt und/oder hergestellt wurden, oder, wenn dies nicht möglich ist, durch Hardwarekomponenten aus einem Drittland, das zur Stärkung der Versorgungssicherheit und zur Entwicklung eines europäischen Cloud- und KI-Ökosystems beiträgt.

<a id="art-33"></a>
### Artikel 33 – Überwachung der innovationsfördernden Auftragsvergabe in den Bereichen Cloud und KI

- (1) Die Mitgliedstaaten überwachen ihre innovationsfördernde Auftragsvergabe für Cloud-Computing-Dienste und KI-Systeme und erstatten darüber Bericht.

- (2) Die Mitgliedstaaten ergreifen geeignete Maßnahmen, um sicherzustellen, dass die in Absatz 1 genannte Überwachung und Berichterstattung aktiv genutzt werden, um Hindernisse für die Teilnahme von KMU an Vergabeverfahren zu ermitteln, den Zugang von KMU zu den Beschaffungsmärkten zu verbessern, die Gestaltung vereinfachter, verhältnismäßiger und KMU-freundlicher Beschaffungsstrategien, gegebenenfalls einschließlich der Aufteilung in Lose, zu unterstützen, wie auch die Teilnahme von KMU an dem in der Richtlinie 2014/24/EU vorgesehenen Innovationsverfahren und die vorkommerzielle Auftragsvergabe für Cloud-Computing-Dienste und KI-Systeme zu fördern.

- (3) Auf der Grundlage der Überwachung nach Absatz 1 übermitteln die Mitgliedstaaten der Kommission jährlich folgende Informationen:

  - a) die Größe der an einer solchen Auftragsvergabe beteiligten Wirtschaftsteilnehmer,

  - b) Trends bei der Teilnahme von KMU, einschließlich der Zahl der an KMU vergebenen Aufträge, ihres prozentualen Anteils am Gesamtauftragswert und, soweit verfügbar, des Anteils der grenzüberschreitenden Beteiligung von KMU,

  - c) Maßnahmen zur Verbesserung des Zugangs von KMU zu den Verfahren zur Vergabe öffentlicher Aufträge.

- (4) Die Mitgliedstaaten verfolgen das Ziel, mindestens 25 % ihrer Aufträge für Cloud-Computing-Dienste und KI-Systeme an innovative KMU zu vergeben. Die Mitgliedstaaten nehmen in ihre nationalen Strategien nach Artikel 7 Pläne auf, wie sie dieses Ziel zu erreichen beabsichtigen.

- (5) Einrichtungen der Union und öffentliche Auftraggeber fördern

  - a) vorherige Marktkonsultationen,

  - b) die Vermittlung zwischen öffentlichen Auftraggebern und europäischen KMU und Start-up-Unternehmen, die innovative Lösungen bereitstellen,

  - c) die Ausarbeitung von Vertragsklauseln für öffentliche Aufträge, die für innovative KMU günstig sind.

## Kapitel III Europäischer Cloud-Verbund des öffentlichen Sektors

<a id="art-34"></a>
### Artikel 34 – Einrichtung des Europäischen Cloud-Verbunds des öffentlichen Sektors

- (1) Hiermit wird der Europäische Cloud-Verbund des öffentlichen Sektors (im Folgenden „EuroCloud-Verbund“) eingerichtet. Der EuroCloud-Verbund steht Einrichtungen der Union und öffentlichen Stellen auf freiwilliger Basis zur Teilnahme offen. Einrichtungen der Union und öffentliche Stellen können bei der Kommission beantragen, dem EuroCloud-Verbund beizutreten.

- (2) Der EuroCloud-Verbund erleichtert die gemeinsame Nutzung von Rechenzentrumsdiensten und Cloud-Computing-Diensten des öffentlichen Sektors durch Einrichtungen der Union und öffentliche Stellen unter den in den Artikeln 35 und 36 festgelegten Bedingungen.

- (3) Die Kommission richtet eine Plattform für den EuroCloud-Verbund ein und stellt mindestens Folgendes bereit:

  - a) einen Katalog mit Informationen über verfügbare Rechenzentrumsdienste und Cloud-Computing-Dienste des öffentlichen Sektors,

  - b) eine Plattform für den Austausch und die Orchestrierung von Rechen-, Speicher- und Netzwerkressourcen und -diensten.

- (4) Der Kommission wird die Befugnis übertragen, Durchführungsrechtsakte zu erlassen, um das Verfahren für die Teilnahme am EuroCloud-Verbund und das Muster für den Inhalt und andere Einzelheiten des Teilnahmeantrags festzulegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-35"></a>
### Artikel 35 – Gemeinsame Nutzung von Rechenzentrumsdiensten und Cloud-Computing-Diensten des öffentlichen Sektors

- (1) Ein Mitglied des EuroCloud-Verbunds (im Folgenden „weitergebende Stelle“) kann Rechenzentrumsdienste und Cloud-Computing-Dienste gemeinsam mit einem anderen Mitglied des EuroCloud-Verbund (im Folgenden „nutzende Stelle“) nutzen, wenn die weitergebende Stelle direkt – oder indirekt über einen zwischengeschalteten Rechtsträger – Eigentümerin der Hardware ist, über die der Dienst bereitgestellt wird, und die Dienstleistung erbringt, die der nutzenden Stelle zur Verfügung gestellt wird. Ist die weitergebende Stelle indirekt Eigentümerin der Hardware und erbringt sie die Dienste über einen zwischengeschalteten Rechtsträger, so muss die weitergebende Stelle die Kontrolle über diesen zwischengeschalteten Rechtsträger ausüben.

- (2) Die weitergebende Stelle trifft geeignete technische, operative und organisatorische Maßnahmen, um eine wirksame, sichere und resiliente Erbringung der Dienste zu gewährleisten.

- (3) Vor einer gemeinsamen Nutzung von Rechenzentrums- und Cloud-Computing-Diensten innerhalb des EuroCloud-Verbunds weist die weitergebende Stelle gegenüber der Kommission nach, dass sie die in den Absätzen 1 und 2 genannten Bedingungen erfüllt.

- (4) Die Kommission prüft die von der weitergebenden Stelle bereitgestellten Informationen und gestattet der weitergebenden Stelle, Rechenzentrums- und Cloud-Computing-Dienste innerhalb des EuroCloud-Verbunds zur gemeinsamen Nutzung bereitzustellen, wenn die in den Absätzen 1 und 2 festgelegten Bedingungen erfüllt sind.

- (5) Die weitergebende Stelle kann der nutzenden Stelle eine Gebühr in Rechnung stellen. Die Höhe der Gebühr ist auf die Kosten beschränkt, die der weitergebenden Stelle im Zusammenhang mit der gemeinsamen Nutzung des Dienstes entstehen, und stellt kein Entgelt im Sinne des Artikels 2 der Richtlinie 2014/24/EU und der Verordnung (EU, Euratom) 2024/2509 dar.

- (6) Der Kommission wird die Befugnis übertragen, Durchführungsrechtsakte zur Festlegung der in Absatz 2 genannten technischen, operativen und organisatorischen Maßnahmen zu erlassen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-36"></a>
### Artikel 36 – Gebühren für die Verwaltung des EuroCloud-Verbunds

- (1) Die Kosten der von der Kommission gemäß diesem Kapitel durchgeführten Tätigkeiten werden gemeinsam von den Mitgliedern des EuroCloud-Verbunds durch von der Kommission erhobene Gebühren finanziert.

- (2) Werden die Kosten zunächst aus dem Gesamthaushaltsplan der Union bestritten, so werden sie von den EuroCloud-Mitgliedern über einen Zeitraum von höchstens drei Jahren ab dem Zeitpunkt, ab dem sie von der Union bestritten wurden, erstattet.

- (3) Einnahmen aus Gebühren gelten als interne zweckgebundene Einnahmen gemäß Artikel 21 Absatz 3 Buchstabe a der Verordnung (EU, Euratom) 2024/2509. Diese Einnahmen werden zur Deckung der Kosten der von der Kommission gemäß diesem Kapitel durchgeführten Tätigkeiten verwendet, einschließlich der Prüfung von Anträgen auf Beitritt zum EuroCloud-Verbund und der Einrichtung der in Artikel 34 Absatz 3 genannten Plattform. Alle nach der Deckung dieser Kosten verbleibenden Einnahmen werden in den Gesamthaushalt der Union eingestellt.

- (4) Die Kommission erlässt Durchführungsrechtsakte zur Festlegung von Durchführungsbestimmungen für die Ermittlung der geschätzten Kosten, die Höhe der einzelnen Gebühren und die Modalitäten und Bedingungen ihrer Entrichtung. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

## Kapitel IV Auftragsvergabe für Rechenzentrumsdienste, Cloud-Computing-Dienste, Software und KI-Systeme durch die Kommission

<a id="art-37"></a>
### Artikel 37 – Auftragsvergabetätigkeiten der Kommission

- (1) Die Kommission kann Auftragsvergabetätigkeiten zur Beschaffung von Rechenzentrumsdiensten, Cloud-Computing-Diensten, Software und KI-Systemen für sich selbst und für Einrichtungen der Union sowie für öffentliche Auftraggeber der Mitgliedstaaten im Einklang mit der Verordnung (EU, Euratom) 2024/2509 durchführen, vorbehaltlich der in diesem Kapitel festgelegten Ausnahmen. Abweichend von Artikel 168 der Verordnung (EU, Euratom) 2024/2509 können von der Kommission ausgewählte Partnerorganisationen nach Artikel 168 Absatz 3 der genannten Verordnung ebenfalls an den in diesem Kapitel festgelegten Auftragsvergabetätigkeiten teilnehmen. Öffentliche Auftraggeber der Mitgliedstaaten, Einrichtungen der Union und von der Kommission ausgewählte Partnerorganisationen gelten als „teilnehmende Stellen“ im Sinne dieses Kapitels.

- (2) Öffentliche Auftraggeber können in eigenem Namen oder als zentrale Beschaffungsstellen im Sinne des Artikels 2 Absatz 1 Nummer 16 der Richtlinie 2014/24/EU an den Vergabeverfahren teilnehmen, wenn sie als solche eingestuft werden können. Besondere Regeln und Verpflichtungen für ihre Teilnahme können auferlegt werden, wenn sie als zentrale Beschaffungsstellen der in Artikel 38 genannten Vereinbarung beitreten.

- (3) Zusätzlich zu den Auftragsvergabetätigkeiten gemäß Artikel 168 der Verordnung (EU, Euratom) 2024/2509 kann die Kommission als zentrale Beschaffungsstelle für öffentliche Auftraggeber der Mitgliedstaaten und von ihr ausgewählter Partnerorganisationen auftreten, indem sie

  - a) Aufträge für Rechenzentrumsdienste, Cloud-Computing-Dienste, Software und KI-Systeme im Auftrag oder im Namen eines oder mehrerer öffentlicher Auftraggeber der Mitgliedstaaten und von der Kommission ausgewählter Partnerorganisationen durch den Abschluss von Rahmenverträgen oder den Betrieb dynamischer Beschaffungssysteme für Dienstleistungen vergibt, die für die teilnehmenden Stellen bestimmt sind;

  - b) die Tätigkeit eines Großhändlers durch den Erwerb solcher Dienstleistungen und Lieferungen und deren Weiterverkauf oder – in Ausnahmefällen – deren Spende an einen oder mehrere öffentliche Auftraggeber der Mitgliedstaaten ausübt.

- (4) Bei der Durchführung von Auftragsvergabetätigkeiten kann die Kommission den teilnehmenden Stellen ergänzende Unterstützung leisten, darunter durch

  - a) technische Infrastruktur, die es den teilnehmenden Stellen ermöglicht, für Rechenzentrumsdienste, Cloud-Computing-Dienste, Software und KI-Systeme vergebene Aufträge zu nutzen oder Aufträge zu vergeben, einschließlich Einzelaufträgen im Rahmen bestehender Rahmenvereinbarungen;

  - b) Beratung und Unterstützung bei der Vorbereitung und Durchführung von Vergabeverfahren;

  - c) Vorbereitung und Durchführung von Vergabeverfahren im Auftrag oder im Namen der betreffenden Einrichtungen;

  - d) Rechnungsstellung und sonstige Verwaltungsdienste im Zusammenhang mit den vergebenen Aufträgen.

- (5) Diese ergänzende Unterstützung kann direkt von der Kommission, über einen Unterauftragnehmer oder im Wege der Delegation an Einrichtungen oder Agenturen der Union geleistet werden. Der Beitritt teilnehmender Stellen zu der in Artikel 38 genannten Vereinbarung kann von der Annahme einer oder mehrerer unterstützender Nebendienstleistungen abhängig gemacht werden.

- (6) Die Kommission kann eine Plattform für die gemeinsame Auftragsvergabe einrichten und verwalten, die Dienste umfasst, die zur Erleichterung der Auftragsvergabetätigkeiten im Rahmen dieses Kapitels genutzt werden können.

<a id="art-38"></a>
### Artikel 38 – Modalitäten der Auftragsvergabetätigkeiten der Kommission

- (1) Vor jeder Auftragsvergabetätigkeit gemäß Artikel 37 schließen die Kommission und mindestens zwei Mitgliedstaaten eine Vereinbarung, in der die praktischen Modalitäten der von der Kommission gemäß diesem Kapitel durchgeführten Auftragsvergabetätigkeiten festgelegt werden. Die Vereinbarung regelt die während ihrer Geltungsdauer durchzuführenden Vergabeverfahren, und es wird davon ausgegangen, dass sie die Anforderungen an Vereinbarungen über gemeinsame Vergabeverfahren und Beauftragungen gemäß Artikel 168 Absätze 2 und 3 der Verordnung (EU, Euratom) 2024/2509 erfüllt.

- (2) Die Vereinbarung stellt eine Beauftragung der Kommission dar, Aufträge im Sinne des Artikels 168 Absatz 3 Buchstabe e der Verordnung (EU, Euratom) 2024/2509 im Auftrag oder im Namen der teilnehmenden Stellen zu vergeben.

- (3) Die Vereinbarung enthält die praktischen Modalitäten für die Teilnahme von Rechtsträgern, das Beschlussfassungsverfahren für die Wahl des Verfahrens und die geltenden Bedingungen, die Bewertung von Teilnahmeanträgen und Angeboten, die Vergabe von Aufträgen sowie das anwendbare Recht und die zuständige Gerichtsbarkeit. Die Kommission bleibt für die Durchführung und Verwaltung der Auftragsvergabetätigkeiten verantwortlich, einschließlich für Entscheidungen über die Einleitung eines Vergabeverfahrens, die Art des Verfahrens und des Vertrags sowie die Auftragsvergabe selbst.

- (4) Durch die Vereinbarung wird ein Lenkungsausschuss eingesetzt, der sich aus der Kommission und einem Vertreter jedes teilnehmenden Mitgliedstaats auf nationaler Ebene zusammensetzt. Die Mitgliedstaaten können der Vereinbarung zu einem späteren Zeitpunkt beitreten und sind dann auch im Lenkungsausschuss vertreten. Der Lenkungsausschuss kann zusätzliche Vertreter anderer Einrichtungen der Union, öffentlicher Auftraggeber der Mitgliedstaaten und von der Kommission ausgewählter Partnerorganisationen ernennen.

- (5) Der Lenkungsausschuss ist für die strategische Beaufsichtigung der Auftragsvergabetätigkeiten sowie dafür zuständig, die strategische Ausrichtung der Vergabeplanung für einen bestimmten Zeitraum vorzuschlagen und die strategische Ausrichtung jedes Vergabeverfahrens vor dessen Einleitung durch die Kommission zu billigen, um sicherzustellen, dass diese mit dem durch diese Verordnung geschaffenen Rahmen im Einklang stehen.

- (6) Sobald die Vereinbarung in Kraft getreten ist, können die öffentlichen Auftraggeber der teilnehmenden Mitgliedstaaten, die Einrichtungen der Union und die von der Kommission ausgewählten Partnerorganisationen der Vereinbarung beitreten und Nutzen daraus ziehen; sie gelten dann als teilnehmende Einrichtungen an den Verfahren, an denen sie teilnehmen möchten. Der Lenkungsausschuss kann festlegen, dass die Vereinbarung die Form eines Beitrittsvertrags hat.

- (7) Die Teilnahme eines öffentlichen Auftraggebers eines Mitgliedstaats setzt nicht die Teilnahme dieses Mitgliedstaats voraus.

- (8) Der Lenkungsausschuss legt transparente und diskriminierungsfreie Bedingungen für den Beitritt der öffentlichen Auftraggeber der Mitgliedstaaten zur Vereinbarung fest, insbesondere in Bezug auf Größe, Mindestbeträge und andere objektive Kriterien. Der Lenkungsausschuss legt ferner die Regeln und Verfahren für die Beendigung der Teilnahme eines öffentlichen Auftraggebers eines Mitgliedstaats, der seinen Verpflichtungen aus der Vereinbarung nicht nachgekommen ist, an der Vereinbarung fest.

- (9) Abweichend von Artikel 168 Absatz 2 der Verordnung (EU, Euratom) 2014/2509 kann der Lenkungsausschuss die Teilnahme öffentlicher Auftraggeber aus EFTA-Staaten und Bewerberländern der Union genehmigen, ohne dass diese Möglichkeit in einem bilateralen oder multilateralen Vertrag vorgesehen sein muss.

- (10) Der Lenkungsausschuss kann den Beitritt zu der Vereinbarung davon abhängig machen, dass die teilnehmenden Stellen eine oder mehrere unterstützende Nebendienstleistungen gemäß Artikel 37 annehmen.

- (11) Der Lenkungsausschuss gibt sich auf Vorschlag der Kommission eine Geschäftsordnung.

<a id="art-39"></a>
### Artikel 39 – Geltender Rahmen für die öffentliche Auftragsvergabe

- (1) Es wird davon ausgegangen, dass eine teilnehmende Einrichtung ihre Verpflichtungen nach geltendem Unionsrecht über die Vergabe öffentlicher Aufträge erfüllt hat, wenn sie Waren oder Dienstleistungen mittels Aufträgen erwirbt, die von der Kommission nach diesem Kapitel vergeben werden, auch über Rahmenverträge, die von der Kommission als zentraler Beschaffungsstelle geschlossen werden, oder über dynamische Beschaffungssysteme, die von der Kommission als zentraler Beschaffungsstelle betrieben werden, oder wenn sie in Artikel 37 genannte unterstützende Nebendienstleistungen in Anspruch nimmt.

- (2) Die für die Organe der Union geltenden Verfahrensvorschriften gelten für die Verfahren zur Vergabe von Einzelverträgen auf der Grundlage von Rahmenverträgen oder dynamischen Beschaffungssystemen.

- (3) Ein öffentlicher Auftraggeber, der Rechenzentrumsdienste, Cloud-Computing-Dienste, Software und KI-Systeme von der Kommission als zentraler Beschaffungsstelle erworben hat, stellt in seinen Vereinbarungen mit den öffentlichen Auftraggebern, für die er tätig ist, sicher, dass alle vertraglichen Anforderungen, an die er selbst gebunden ist, eingehalten werden.

- (4) Die Kommission kann beschließen, ein Vergabeverfahren einzuleiten, das den teilnehmenden Stellen offensteht, ohne dass diese das zuvor ausdrücklich beantragt haben.

- (5) Abweichend von Artikel 168 der Verordnung (EU, Euratom) 2024/2509 können teilnehmende Stellen während der gesamten Geltungsdauer eines dynamischen Beschaffungssystems bei der Kommission die Teilnahme an dem System beantragen. Ein solcher Antrag wird von der Kommission genehmigt, sofern die kumulierten Anträge 50 % der ursprünglich geschätzten Mengen der geplanten Käufe nicht überschreiten. Die Teilnahme wird innerhalb von zehn Arbeitstagen nach Eingang des Antrags genehmigt und ermöglicht die Teilnahme der betreffenden teilnehmenden Stellen an künftigen Aufforderungen zur Angebotsabgabe.

- (6) Die in Absatz 5 genannte Möglichkeit steht nur teilnehmenden Stellen offen, die der in Artikel 38 genannten Vereinbarung nach der Einführung des dynamischen Beschaffungssystems beitreten.

<a id="art-40"></a>
### Artikel 40 – Gebühren für Auftragsvergabetätigkeiten

- (1) Die Kosten der gemäß diesem Kapitel durchgeführten Auftragsvergabetätigkeiten werden gemeinsam von den teilnehmenden Stellen durch von der Kommission erhobene Gebühren finanziert.

- (2) Die Kosten der Einrichtung der in Artikel 37 genannten gemeinsamen Auftragsvergabetätigkeiten, einschließlich der Entwicklung der Plattform für die gemeinsame Auftragsvergabe, können zunächst aus dem Gesamthaushaltsplan der Union bestritten werden. In diesem Fall werden sie von den teilnehmenden Stellen über einen Zeitraum von höchstens drei Jahren ab dem Zeitpunkt, ab dem sie von der Union bestritten wurden, erstattet. Die Kommission kann Durchführungsrechtsakte zur Festlegung der praktischen und operativen Modalitäten für die Erstattung durch die teilnehmenden Stellen erlassen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

- (3) Einnahmen aus Gebühren gelten als interne zweckgebundene Einnahmen gemäß Artikel 21 Absatz 3 Buchstabe a der Verordnung (EU, Euratom) 2024/2509. Diese Einnahmen werden zur Deckung der Kosten der gemäß Artikel 37 durchgeführten Auftragsvergabetätigkeiten verwendet. Alle nach der Deckung dieser Kosten verbleibenden Einnahmen werden in den Gesamthaushalt der Union eingestellt.

- (4) Die Gebühren werden im Voraus festgelegt, stehen in einem angemessenen Verhältnis zu den geschätzten Kosten der Tätigkeiten, für die Gebühren erhoben werden, und werden auf kosteneffiziente Weise festgelegt, spiegeln die Praktiken vergleichbarer Auftragsvergaberahmen wider und reichen aus, um diese Kosten zu decken.

- (5) Die Kommission erlässt Durchführungsrechtsakte zur Festlegung von Durchführungsbestimmungen für die Ermittlung der Gebühren, in denen Folgendes präzisiert wird:

  - a) die geschätzten Kosten, die den Auftragsvergabetätigkeiten zuzurechnen sind, für die Gebühren erhoben werden,

  - b) die einzelnen Beträge der zu erhebenden Gebühren,

  - c) die Modalitäten und Bedingungen der Gebührenentrichtung,

  - d) die Bedingungen, unter denen diese Gebühren zu entrichten sind.

    Diese Durchführungsrechtsakte werden gemäß dem in Artikel 46 Absatz 2 genannten Prüfverfahren erlassen.

## Kapitel V Quelloffenheit

<a id="art-41"></a>
### Artikel 41 – Förderung quelloffener Lösungen und „Zuerst Open-Source“-Grundsatz

    Die Union und die Mitgliedstaaten ergreifen die erforderlichen Maßnahmen, um Einrichtungen der Union und öffentliche Stellen darin zu bestärken, beim Aufbau ihres Cloud- und KI-Ökosystems oder -Stacks offene Standards und Komponenten, die unter einer Open-Source-Lizenz bereitgestellt werden, zu verwenden und deren Weiterverwendung zu erleichtern, wobei Funktionsmerkmale ebenso wie die Sicherheit, Gesamtkosten und andere einschlägige, hinreichend begründete objektive Kriterien zu berücksichtigen sind.

<a id="art-42"></a>
### Artikel 42 – Weitergabe und Weiterverwendung von Software

    Um Software, an der sie Rechte des geistigen Eigentums innehat, zur Weiterverwendung im Rahmen einer Open-Source-Lizenz bereitzustellen, verwendet eine Einrichtung der Union oder eine öffentliche Stelle einen Katalog oder ein Verzeichnis, der bzw. das mit dem in Artikel 43 genannten EU-OSS-Katalog verknüpft ist und über diesen zugänglich gemacht wird.

<a id="art-43"></a>
### Artikel 43 – EU-Katalog quelloffener Lösungen

- (1) Die Kommission stellt einen EU-Katalog quelloffener Lösungen (im Folgenden „EU-OSS-Katalog“) als zentralisierten Katalog für den Zugang zu Software, die von Einrichtungen der Union und öffentlichen Stellen zur Weiterverwendung zur Verfügung gestellt wird, bereit und führt diesen.

- (2) Der EU-OSS-Katalog wird auf dem in Artikel 8 der Verordnung (EU) 2024/903 genannten Portal für ein interoperables Europa gehostet und ist elektronisch kostenlos zugänglich.

- (3) Die Kommission entscheidet auf der Grundlage objektiver und relevanter Kriterien auf Ersuchen von Einrichtungen der Union oder öffentlichen Stellen, die Eigentümer eines Katalogs oder Verzeichnisses sind oder diesen bzw. dieses führen, darüber, ob dieser Katalog oder dieses Verzeichnis mit dem EU-OSS-Katalog verknüpft und über diesen zugänglich gemacht wird.

<a id="art-44"></a>
### Artikel 44 – Netz der Open-Source-Programmbüros

- (1) Die Kommission richtet ein Netz der Open-Source-Programmbüros (im Folgenden „OSPO-Netz“) ein, um die Zusammenarbeit bei der Umsetzung der Verpflichtungen aus diesem Kapitel zu erleichtern.

- (2) Open-Source-Programmbüros, die von öffentlichen Stellen auf lokaler, regionaler oder nationaler Ebene in einem Mitgliedstaat eingerichtet werden, und solche, die von Einrichtungen der Union eingerichtet werden, können bei der Kommission den Beitritt zum OSPO-Netz beantragen.

- (3) Das OSPO-Netz hat folgende Aufgaben:

  - a) Erleichterung des Austauschs von Informationen, Erfahrungen und bewährten Verfahren zwischen den Mitgliedstaaten und der Kommission, insbesondere durch Erörterung gemeinsamer technischer, rechtlicher und organisatorischer Herausforderungen, auch im Zusammenhang mit der Lizenzierung, Sicherheit und Pflege quelloffener Software sowie der Auftragsvergabe für quelloffene Software;

  - b) Förderung der gemeinsamen Nutzung und Weiterverwendung quelloffener Software durch öffentliche Stellen;

  - c) freiwillige und unverbindliche Mitwirkung an der Ausarbeitung von Leitlinien, Mustern oder Empfehlungen für die gemeinsame Nutzung und Weiterverwendung quelloffener Software;

  - d) Zusammenarbeit bei quelloffenen Projekten von gemeinsamem Interesse für Einrichtungen der Union und öffentliche Stellen und entsprechender Austausch.

- (4) Die Kommission unterstützt und koordiniert das OSPO-Netz.

- (5) Die Kommission beruft mindestens zweimal jährlich eine Sitzung der Mitglieder des OSPO-Netzes ein und führt darin den Vorsitz. Die Sitzungen des OSPO-Netzes können online stattfinden.

TITEL V SCHLUSSBESTIMMUNGEN

**Artikel 44 – Ausübung der Befugnisübertragung**

- (1) Die Befugnis zum Erlass delegierter Rechtsakte wird der Kommission unter den in diesem Artikel festgelegten Bedingungen übertragen.

- (2) Die Befugnis zum Erlass delegierter Rechtsakte gemäß Artikel 6 Absatz 4, Artikel 16 Absatz 2, Artikel 20 Absatz 9, Artikel 21 Absatz 1 und Artikel 31 Absatz 3 wird der Kommission auf unbestimmte Zeit ab dem [Tag des Inkrafttretens] übertragen.

- (3) Die Befugnisübertragung gemäß Artikel 6 Absatz 4, Artikel 16 Absatz 2, Artikel 20 Absatz 9, Artikel 21 Absatz 1 und Artikel 31 Absatz 3 kann vom Europäischen Parlament oder vom Rat jederzeit widerrufen werden. Der Beschluss über den Widerruf beendet die Übertragung der in diesem Beschluss angegebenen Befugnis. Er wird am Tag nach seiner Veröffentlichung im Amtsblatt der Europäischen Union oder zu einem in dem Beschluss über den Widerruf angegebenen späteren Zeitpunkt wirksam. Die Gültigkeit delegierter Rechtsakte, die bereits in Kraft sind, wird von dem Beschluss über den Widerruf nicht berührt.

- (4) Vor dem Erlass eines delegierten Rechtsakts konsultiert die Kommission die von den einzelnen Mitgliedstaaten benannten Sachverständigen im Einklang mit den in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung enthaltenen Grundsätzen.

- (5) Sobald die Kommission einen delegierten Rechtsakt erlässt, übermittelt sie ihn gleichzeitig dem Europäischen Parlament und dem Rat.

- (6) Ein delegierter Rechtsakt, der gemäß Artikel 6 Absatz 4, Artikel 16 Absatz 2, Artikel 20 Absatz 9, Artikel 21 Absatz 1 und Artikel 31 Absatz 3 erlassen wurde, tritt nur in Kraft, wenn weder das Europäische Parlament noch der Rat innerhalb einer Frist von zwei Monaten nach Übermittlung dieses Rechtsakts an das Europäische Parlament und den Rat Einwände erhoben haben oder wenn vor Ablauf dieser Frist das Europäische Parlament und der Rat beide der Kommission mitgeteilt haben, dass sie keine Einwände erheben werden. Auf Initiative des Europäischen Parlaments oder des Rates wird diese Frist um drei Monate verlängert.

<a id="art-46"></a>
### Artikel 46 – Ausschussverfahren

- (1) Die Kommission wird von einem Ausschuss unterstützt. Dieser Ausschuss ist ein Ausschuss im Sinne der Verordnung (EU) Nr. 182/2011.

- (2) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 5 der Verordnung (EU) Nr. 182/2011.

<a id="art-47"></a>
### Artikel 47 – Überprüfung

- (1) Bis zum [Tag des Inkrafttretens plus 4 Jahre] und danach alle fünf Jahre bewertet die Kommission diese Verordnung und erstattet dem Europäischen Parlament, dem Rat und dem Europäischen Wirtschafts- und Sozialausschuss darüber Bericht.

- (2) Dem in Absatz 1 genannten Bericht wird gegebenenfalls ein Vorschlag zur Änderung dieser Verordnung beigefügt.

- (3) Bei der in Absatz 1 genannten Bewertung berücksichtigt die Kommission die Standpunkte und Feststellungen des Europäischen Parlaments, des Rates und anderer einschlägiger Stellen oder Quellen und widmet kleinen und mittleren Unternehmen und der Stellung neuer Wettbewerber besondere Aufmerksamkeit.

<a id="art-48"></a>
### Artikel 48 – Inkrafttreten und Anwendung

Diese Verordnung tritt am zwanzigsten Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

Sie gilt ab dem [ein Jahr nach dem Inkrafttreten].

Diese Verordnung ist in allen ihren Teilen verbindlich und gilt unmittelbar in jedem Mitgliedstaat.

Geschehen zu Brüssel am

Im Namen des Europäischen Parlaments Im Namen des Rates

Die Präsidentin Der Präsident/Die Präsidentin

<a id="finanz-und-digitalbogen-zu-rechtsakten"></a>
## FINANZ- UND DIGITALBOGEN ZU RECHTSAKTEN

### 1. RAHMEN DES VORSCHLAGS/DER INITIATIVE

#### 1.1. Bezeichnung des Vorschlags/der Initiative

    Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Schaffung eines Rahmens für Maßnahmen zur Stärkung des europäischen Cloud- und KI-Ökosystems (Verordnung zur Cloud- und KI-Entwicklung).

    Kurztitel: Verordnung zur Cloud- und KI-Entwicklung (CADA)

    (Text von Bedeutung für den EWR)

#### 1.2. Politikbereich(e)

    Der Vorschlag betrifft Politikbereiche im Zusammenhang mit der Entwicklung von Cloud-Computing-Diensten, wobei der Schwerpunkt auf der Gewährleistung eines reibungslosen und rechtzeitigen Übergangs zu hochwertigen, resilienten und zukunftsorientierten digitalen Ökosystemen liegt. Ziel ist es, die Regulierungsbedingungen für einen Binnenmarkt für Cloud-Computing-Dienste zu schaffen, einen Anreiz für Investitionen in Cloud-Infrastruktur sowie KI-Forschung und -Entwicklung zu bieten und neue Anforderungen zu unterstützen, die sich aus innovativen Technologien ergeben. Mit der Modernisierung der bestehenden Rahmen soll die Initiative effiziente Investitionen erleichtern, einen nachhaltigen Wettbewerb fördern und technologische Abhängigkeiten verringern und so die langfristige Wettbewerbsfähigkeit und die Resilienz der EU in der globalen Cloud- und KI-Landschaft zu unterstützen. Mit dem Vorschlag sollen außerdem die noch bestehenden Hindernisse bei der grenzüberschreitenden Bereitstellung von Cloud-Computing-Diensten beseitigt und die Kohärenz und Vorhersehbarkeit der Regulierung in den Mitgliedstaaten verbessert werden.

#### 1.3. Ziel(e)

##### 1.3.1. Allgemeine(s) Ziel(e)

    Das allgemeine Ziel dieser Initiative besteht darin, das Funktionieren des Binnenmarkts für Cloud-Computing-Dienste zu gewährleisten und die notwendigen Voraussetzungen für die Wettbewerbsfähigkeit und strategische Autonomie der Union zu schaffen.

##### 1.3.2. Einzelziel(e)

    Einzelziel Nr. 1: Steigerung der in der EU eingesetzten Rechenkapazitäten durch innovative und nachhaltige Technologien. Bis 2030 sollte die EU ihre derzeitige Rechenzentrumskapazität mindestens verdreifachen und energieeffizienten Technologien in neuen Anlagen Vorrang einräumen. Da die Nachfrage weiter steigt, sollte dies als Zwischenziel betrachtet werden, damit die EU mit ihrer Rechenkapazität bis 2035 ihren eigenen Bedarf decken kann.

    Einzelziel Nr. 2: Gewährleistung attraktiver Bedingungen für den Aufbau nachhaltiger und innovativer Rechenkapazitäten. Während das erste Ziel auf den Aufbau von Kapazitäten ausgerichtet ist, geht es bei diesem Ziel um die Bedingungen für solche Investitionen und die Einführung. Bis 2030 sollten die Betreiber in der gesamten EU alle Genehmigungen für den Bau und den Betrieb eines Rechenzentrums in weniger als 18 Monaten erhalten können, einschließlich des Zugangs zu Grund und Boden sowie Genehmigungen für den Zugang zu Energie und Konnektivität; diese Aspekte sind für Investoren besonders wichtig.

    Einzelziel Nr. 3: Verringerung der allgemeinen Abhängigkeit von außereuropäischen Cloud-Computing-Diensten. Bis 2035 dürfte diese Intervention den Marktanteil europäischer Anbieter von Cloud-Computing-Diensten auf dem europäischen Markt erhöhen. Um die strategische Autonomie der Union zu stärken, müssen Abhängigkeiten verringert werden, und es muss sichergestellt werden, dass den europäischen Nutzerinnen und Nutzern glaubwürdige europäische Alternativen zu etablierten Unternehmen außerhalb Europas zur Verfügung stehen. Eine stärkere europäische Versorgungsbasis verbessert die Fähigkeit der Union, autonom zu handeln, und steigert langfristig die Resilienz, Wettbewerbsfähigkeit und Versorgungssicherheit.

    Einzelziel Nr. 4: Beitrag zum Schutz der öffentlichen Ordnung durch Stärkung der Resilienz im Hinblick auf die Bereitstellung von Cloud-Computing-Diensten, insbesondere im öffentlichen Sektor. Bis 2035 sollten hochkritische Anwendungsfälle im öffentlichen Sektor mithilfe souveräner Cloud-Computing- und KI-Dienste gehandhabt werden, um die Vertraulichkeit der Daten und die operative Autonomie zu gewährleisten sowie Schäden zu verhindern, die die öffentliche Ordnung untergraben könnten. Hochkritische Anwendungsfälle sind solche von besonderer systemischer Bedeutung, die wesentliche Funktionen unterstützen oder die Verarbeitung sensibler Daten beinhalten. Dafür zu sorgen, dass die Daten geschützt sind und die Kontinuität der Dienste gewährleistet ist, ist ein Schlüsselelement für die Verwirklichung der strategischen Autonomie. Aus diesem Grund stellen diese Anwendungsfälle eine Priorität für den Übergang zu Diensten dar, deren Erbringung außerhalb der Reichweite der Politik von Drittländern liegt, bei der das Risiko eines Datenzugriffs oder von Unterbrechungen der Dienstkontinuität besteht, d. h. zu souveränen Diensten.

##### 1.3.3. Erwartete Ergebnisse und Auswirkungen

    Bitte geben Sie an, wie sich der Vorschlag/die Initiative auf die Begünstigten/Zielgruppen auswirken sollte.

    Die vorgeschlagene Verordnung zur Cloud- und KI-Entwicklung dürfte erhebliche Auswirkungen auf mehrere Begünstigte haben, darunter den öffentlichen Sektor, das europäische Cloud- und KI-Ökosystem sowie die Bürgerinnen und Bürger. Ziel der Initiative ist es, das Cloud- und KI-Ökosystem auf Unionsebene zu stärken, eine Vorreiterrolle bei der Energie- und Ressourceneffizienz von Rechenzentren zu übernehmen, europäische offene Cloud- und KI-Stacks zu entwickeln und die Einführung von Cloud-Computing-Diensten zu fördern. Dies dürfte zur Entwicklung fortgeschrittener KI-Technik und Grenz-KI, zur Beschleunigung industrieller KI-Modelle und -Systeme in strategischen Sektoren und zur Unterstützung sektorenübergreifender Initiativen zur Bewältigung großer technologischer und industrieller Herausforderungen führen. Darüber hinaus zielt der Vorschlag darauf ab, die Einrichtung von Rechenzentren in der gesamten Union zu beschleunigen, die Kapazität der Rechenzentren in der EU in den nächsten fünf bis sieben Jahren zu verdreifachen und für die Einrichtung ressourceneffizienter Rechenzentren zu sorgen. Mit der Verordnung sollen außerdem die Autonomie gefördert, die Abhängigkeit von kritischen Technologien verringert und die Einführung von Cloud-Computing-Diensten im gesamten öffentlichen Sektor angekurbelt werden, damit kritische Sektoren souveräne Cloud-Computing-Dienste nutzen können. Ferner wird der Vorschlag zur Einrichtung eines europäischen Cloud-Verbunds des öffentlichen Sektors, zu gemeinsamen Auftragsvergabetätigkeiten und zur Förderung quelloffener Lösungen führen. Insgesamt zielt der Vorschlag darauf ab, diese Begünstigten zu stärken und ein wettbewerbsfähiges, innovatives und autonomes europäisches Cloud- und KI-Ökosystem zu fördern, das wirtschaftlichen Wohlstand, soziales Wohlergehen und strategische Autonomie voranbringt. Der Vorschlag soll sich positiv auf die globale Wettbewerbsfähigkeit des europäischen KI- und Cloud-Sektors und die Attraktivität der EU für Unternehmen und Forschende aus Drittländern auswirken.

##### 1.3.4. Leistungsindikatoren

    Bitte geben Sie an, anhand welcher Indikatoren die Fortschritte und Ergebnisse verfolgt werden sollen.

    Ziel 1: Steigerung der Rechenkapazitäten in der EU durch innovative und nachhaltige Technologien.

  - a) Installierte Rechenkapazität (MW IT-Last) nach MS

  - b) Aggregierte Rechenleistung für allgemeine Zwecke und KI-optimierte Rechenleistung, auch gemessen in FLOPs

  - c) EU-Anteil an der weltweit installierten Rechenkapazität

  - d) Auslastung der Rechenkapazitäten in der EU; Maßnahmen in Bezug auf PUE, WUE, standortbezogene Emissionen und damit verbundene Umweltauswirkungen von Rechenzentren

  - e) Einführung innovativer und energieeffizienter Technologien (Einleitung von Pilotprojekten und Übernahme neuer Lösungen)

  - f) Anteil sauberer Energie in Rechenzentren und Abwärmenutzung

  - g) Jährliche öffentliche und private Gesamtinvestitionen in Rechenzentren mit Sitz in der EU

  - h) Anteil der neuen Rechenzentrumskapazitäten, die außerhalb bestehender Zentren und in unterversorgten Regionen eingerichtet werden

    Ziel 2: Gewährleistung attraktiver Bedingungen für den Aufbau nachhaltiger und innovativer Rechenkapazitäten.

  - a) Durchschnittliche Genehmigungszeit für neue Rechenzentrumsprojekte

  - b) Gesamtverwaltungsaufwand für die Betreiber

  - c) Anteil der Projekte, die aufgrund regulatorischer oder infrastruktureller Hindernisse verzögert/abgebrochen wurden

  - d) Anzahl der Mitgliedstaaten mit vereinfachten Genehmigungsrahmen

  - e) Kostenwettbewerbsfähigkeitsindex

    Ziel 3: Verringerung der Abhängigkeit von außereuropäischen Cloud-Computing- und KI-Diensten.

  - a) Anteil der von europäischen Diensteanbietern erzielten Gesamteinnahmen aus Cloud-Computing-Diensten in der EU

  - b) Anzahl der öffentlichen Stellen, die von souveränen Anbietern versorgt werden, nach MS

  - c) Anteil der installierten Rechenzentrumskapazitäten in der EU, der sich im Eigentum europäischer Anbieter befindet

  - d) Anteil der ungenutzten Kapazität in den MS

    Ziel 4: Beitrag zum Schutz der öffentlichen Ordnung durch Stärkung der Resilienz im Hinblick auf die Bereitstellung von Cloud-Computing-Diensten, insbesondere im öffentlichen Sektor.

  - a) Anzahl der geprüften Cloud-Dienste auf Stufe 2, 3, 4

  - b) Quote der Einhaltung der Souveränitätsregelung durch öffentliche Auftraggeber (in %)

  - c) Jährlicher Wert der Vergabe öffentlicher Aufträge für souveräne Cloud-Computing-Dienste in der EU

  - d) Anzahl der im Verzeichnis als quelloffen veröffentlichten Lösungen des öffentlichen Sektors und Anzahl der Downloads durch Dritte.

#### 1.4. Der Vorschlag/Die Initiative betrifft

     eine neue Maßnahme

     eine neue Maßnahme im Anschluss an ein Pilotprojekt/eine vorbereitende Maßnahme^(39)

     die Verlängerung einer bestehenden Maßnahme

     die Zusammenführung mehrerer Maßnahmen oder die Neuausrichtung mindestens einer Maßnahme

#### 1.5. Begründung des Vorschlags/der Initiative

##### 1.5.1. Kurz- oder langfristig zu deckender Bedarf, einschließlich einer detaillierten Zeitleiste für die Durchführung der Initiative

    Die Verordnung zur Cloud- und KI-Entwicklung wird voraussichtlich innerhalb von 20 Tagen nach ihrer Veröffentlichung im Amtsblatt in Kraft treten. Die Anwendung sollte innerhalb von einem Jahr nach der Veröffentlichung beginnen, mit zu beachtenden Ausnahmen für Vorschriften, die einen zusätzlichen Übergangszeitraum erfordern.

##### 1.5.2. Mehrwert aufgrund des Tätigwerdens der EU (kann sich aus unterschiedlichen Faktoren ergeben, z. B. Vorteile durch Koordinierung, Rechtssicherheit, größere Wirksamkeit oder Komplementarität). Für die Zwecke dieses Abschnitts bezeichnet der Ausdruck „Mehrwert aufgrund des Tätigwerdens der EU“ den Wert, der sich aus dem Tätigwerden der EU ergibt und den Wert ergänzt, der andernfalls allein von den Mitgliedstaaten geschaffen worden wäre.

    Die Entwicklung von Rechenkapazitäten in der EU erfolgt derzeit auf nationaler Ebene. Jeder Mitgliedstaat arbeitet in einem eigenen Rahmen mit unterschiedlichen Verfahren und Anforderungen für die Einrichtung von Rechenzentren, die den lokalen Bedingungen und Bedürfnissen Rechnung tragen. Die nationalen Strategien für die Beschleunigung von Rechenzentren bergen jedoch die Gefahr einer weiteren Fragmentierung und eines Unterbietungswettbewerbs in Bezug auf die Nachhaltigkeit. Darüber hinaus erfordert eine zunehmende Zahl von Anwendungen mit geringer Latenzzeit nahe gelegene Rechenkapazitäten. Generell ist die EU mit einem Mangel an Rechenkapazitäten konfrontiert, ein Problem, das sich negativ auf ihre Wettbewerbsfähigkeit auswirken könnte und Maßnahmen auf EU-Ebene erfordert, um ein Regelungs- und Investitionsumfeld aufrechtzuerhalten, in dem sich Betreiber von Rechenzentren und Investoren leicht bewegen können, auch grenzüberschreitend.

    Um diese Kapazitätslücke zu schließen und es europäischen Unternehmen und öffentlichen Verwaltungen zu ermöglichen, Rechenkapazitäten wirksam zu nutzen und gleichzeitig Nachhaltigkeit zu gewährleisten, sind Maßnahmen auf EU-Ebene erforderlich. Die Abhängigkeit von Cloud-Computing-Diensten außereuropäischer Anbieter hat in der gesamten EU dieselben Ursachen und betrifft Unternehmen und öffentliche Verwaltungen in allen Mitgliedstaaten. Europäische Diensteanbieter haben Schwierigkeiten, in der gesamten EU zu expandieren, beispielsweise aufgrund unterschiedlicher nationaler Vertrauenswürdigkeitsstandards, insbesondere bei der Vergabe öffentlicher Aufträge. Unterschiedliche nationale Vergabeverfahren verkomplizieren den Markt für europäische Anbieter, und die zugrunde liegende Unvollständigkeit von Informationen stellt ein Marktversagen dar, das eine Reaktion auf EU-Ebene erfordert. Auch in der öffentlichen Konsultation wurden Maßnahmen der EU zur Bewältigung dieser Herausforderungen gefordert.

    Es wird erwartet, dass EU-Maßnahmen einen klaren Mehrwert bei der Lösung des Problems der begrenzten und geografisch konzentrierten Verfügbarkeit von Rechenkapazitäten bieten werden. Durch einen gemeinsamen Ansatz für die Einrichtung von Rechenzentren würde dies eine kohärente Planung und den Aufbau von Rechenkapazitäten in geografisch ausgewogener Weise ermöglichen und gleichzeitig einen Unterbietungswettbewerb vermeiden sowie die regulatorische Komplexität für Investoren und Betreiber von Rechenzentren verringern. Die EU ist in einer einzigartigen Position, um sicherzustellen, dass die Investitions- und Beschleunigungspolitik die gemeinsamen Prioritäten widerspiegelt und eine Fragmentierung verhindert. Maßnahmen auf EU-Ebene würden sicherstellen, dass alle Unternehmen und öffentlichen Verwaltungen Zugang zu ausreichenden Rechenkapazitäten haben, um ihren Bedürfnissen gerecht zu werden, und sie sind eine Voraussetzung dafür, dass Europa ein KI-Kontinent wird.

    Bei der Bewältigung der Abhängigkeit von Cloud-Computing-Diensten außereuropäischer Anbieter dürften die EU-Maßnahmen Vorteile mit sich bringen, die über das hinausgehen, was die Mitgliedstaaten einzeln erreichen könnten, insbesondere bei der Behebung des zugrunde liegenden Marktversagens durch unvollständige Informationen. Dies würde das Funktionieren des Binnenmarkts verbessern und es den Anbietern von Cloud-Computing-Diensten ermöglichen, über ihre nationalen Märkte hinauszuwachsen.

##### 1.5.3. Aus früheren ähnlichen Maßnahmen gewonnene Erkenntnisse

    Der Vorschlag stützt sich auf die praktischen Erfahrungen bei der Umsetzung der bestehenden Vorschriften in diesem Bereich. Die Erfahrung hat gezeigt, dass rechtliche Garantien erforderlich sind, aber nicht ausreichen, um die Abhängigkeit von Anbietern aus Drittländern zu ändern. Die Durchsetzung der DSGVO und der Europäische Datenschutzbeauftragte veranlassten öffentliche Stellen und Anbieter zu strengeren vertraglichen Kontrollen und Vorschriften für internationale Datenübermittlungen. Diese Maßnahmen führten jedoch eher zu Compliance-Lösungen als zu konkreten Änderungen. Ebenso hat sich gezeigt, dass die Notwendigkeit der Datenlokalisierung einige der Souveränitätsanforderungen, die für bestimmte Anwendungsfälle, insbesondere im öffentlichen Sektor, bestehen, nur teilweise aus der Welt schaffte. Bei den Vorbereitungsarbeiten für die EUCS-Cloud-Zertifizierung wurde ferner demonstriert, dass zwischen Cybersicherheit und Souveränitätsanforderungen unterschieden werden muss. Die Verordnung baut auch auf dem Cybersicherheitsverordnung 2.0 sowie auf Bestimmungen der Datenverordnung auf, deren Schwerpunkt auf den Kosten des Anbieterwechsels, Interoperabilität, Übertragbarkeit und missbräuchlichen Vertragsklauseln liegt, und ergänzt diese. Schließlich stützt sich der Vorschlag auf eine umfassende Strategie zur Konsultation der Interessenträger.

##### 1.5.4. Vereinbarkeit mit dem Mehrjährigen Finanzrahmen sowie mögliche Synergieeffekte mit anderen geeigneten Instrumenten

    Der Vorschlag ist mit dem mehrjährigen Finanzrahmen vereinbar, da er in erster Linie einen neuen Rechtsrahmen bieten und sich gleichzeitig auf bestehende oder geplante Finanzierungsinstrumente der EU stützen würde. Die wichtigsten Finanzierungssynergien sollten sich mit dem 10. Rahmenprogramm und dem Europäischen Fonds für Wettbewerbsfähigkeit (ECF) ergeben, insbesondere im Rahmen des Bereichs „Digitale Führungsrolle“. Das 10. Rahmenprogramm sollte die vorgelagerte Forschungs- und Innovationsdimension im Rahmen der Säule 1 unterstützen, während der ECF als wichtigstes Einführungsinstrument dienen und so dazu beitragen sollte, die Forschungsergebnisse des 10. Rahmenprogramms in operative Fähigkeiten umzusetzen. Andere Instrumente könnten diese Bemühungen weiter verstärken. IPCEIs würden weiterhin große grenzüberschreitende Projekte unterstützen, bei denen Cloud-, Edge-, Chip-, Cybersicherheits- oder KI-Infrastrukturen eine Koordinierung zwischen den Investitionen der Mitgliedstaaten und des Privatsektors erfordern. Die EDICs könnten Gruppen von Mitgliedstaaten, die eine gemeinsame digitale Infrastruktur betreiben möchten, nützliche Steuerungsinstrumente an die Hand geben. Die Instrumente der Kohäsionspolitik, z. B. der Europäische Fonds für regionale Entwicklung (EFRE) und der Kohäsionsfonds, tragen zur regionalen Wettbewerbsfähigkeit bei und können diese unterstützen sowie territoriale Ungleichheiten durch die Kofinanzierung digitaler Infrastrukturen in weniger entwickelten Regionen angehen. Es werden auch Synergien mit InvestEU erwartet, indem das Investitionsumfeld verbessert wird sowie bankfähige Projekte unterstützt und Finanzierungsinstrumente zur Mobilisierung privater und öffentlicher Investitionen ergänzt werden. Gegebenenfalls würde der Vorschlag auch auf den Reformen und Investitionen aufbauen, die in den nationalen Aufbau- und Resilienzplänen, einschließlich der nationalen Reformprogramme und der länderspezifischen Empfehlungen, festgelegt sind. Schließlich könnten auch andere ECF-Politikbereiche sektorspezifische Anwendungen unterstützen.

##### 1.5.5. Bewertung der verschiedenen verfügbaren Finanzierungsoptionen, einschließlich der Möglichkeiten für eine Umschichtung

    Bei der Bewertung der verfügbaren Finanzierungsoptionen wurden sowohl Umschichtungen der bestehenden Ressourcen der Kommission als auch der Bedarf an zusätzlichen Finanzmitteln berücksichtigt. Für die Umsetzung der Initiative wird ein Bedarf von insgesamt 25 VZÄ geschätzt. Davon fallen 8 VZÄ aus der GD DIGIT und 7 VZÄ aus der GD CNECT in den Bereich der Umschichtung, was Aufgaben widerspiegelt, die durch die Neugewichtung bestehender Tätigkeiten und die Nutzung bestehender politischer Sachkenntnis abgedeckt werden können. Dies bedeutet, dass 15 der 25 geschätzten VZÄ durch Umschichtungen gedeckt werden könnten. Mit diesen umgeschichteten Stellen würden hauptsächlich Tätigkeiten unterstützt, die eng mit bestehenden Aufgabenbereichen verbunden sind, wie politische Koordinierung, rechtliche Analyse, Einbeziehung der Interessenträger, Überwachung des Binnenmarkts, Programmverwaltung, administrative Unterstützung und Zusammenarbeit mit den Mitgliedstaaten. Für die übrigen Aufgaben wurden alternative Finanzierungsoptionen geprüft. Dazu gehören die gezielte Aufstockung der einschlägigen Haushaltslinien und die Verwendung bestehender Programmmittel. Da jedoch mehrere Aufgaben möglicherweise mit erheblichen Betriebskosten verbunden sein werden, werden ebenfalls Gebühren als wichtiger Finanzierungsmechanismus eingeführt, um die Auswirkungen auf den EU-Haushalt zu begrenzen. Insbesondere waren solche Gebühren für Tätigkeiten im Zusammenhang mit gemeinsamen Auftragsvergabetätigkeiten und der Verwaltung des EuroCloud-Verbunds für die gemeinsame Nutzung ungenutzter Kapazitäten durch interessierte Mitgliedstaaten vorgesehen worden.

    Für die verbleibenden 10 VZÄ wären zusätzliche Finanzmittel erforderlich, da sie sich auf neue oder erheblich erweiterte Zuständigkeiten beziehen, die über die derzeitigen Annahmen hinsichtlich der Arbeitsbelastung hinausgehen.

    Insgesamt kombiniert der vorgeschlagene Ansatz Umschichtungen, gebührenbasierte Finanzierung und begrenzte zusätzliche Ressourcen. Eine Umschichtung würde die Haushaltsdisziplin und die Nutzung der vorhandenen Sachkenntnis der Kommission gewährleisten. Gebühren dürften den Druck auf den EU-Haushalt verringern und die Haushaltsneutralität für die ressourcenintensivsten Aufgaben unterstützen. Zusätzliche Mittel sind daher für neue Funktionen vorgesehen, die nicht durch Gebühren oder interne Neuzuweisungen finanziert werden können.

#### 1.6. Laufzeit der vorgeschlagenen Maßnahme/der Initiative und Dauer der finanziellen Auswirkungen

     Befristete Laufzeit

    - –  Laufzeit: [TT.MM.]JJJJ bis [TT.MM.]JJJJ

    - –  Finanzielle Auswirkungen auf die Mittel für Verpflichtungen von JJJJ bis JJJJ und auf die Mittel für Zahlungen von JJJJ bis JJJJ

     Unbefristete Laufzeit

  - – Anlaufphase von 2028 bis 2030,

  - – Anschließend reguläre Umsetzung

#### 1.7. Vorgeschlagene Haushaltsvollzugsart(en)

     Direkte Mittelverwaltung durch die Kommission

    - –  über ihre Dienststellen, einschließlich ihres Personals in den EU-Delegationen

    - –  über die Exekutivagenturen

     Geteilte Mittelverwaltung mit Mitgliedstaaten

     Indirekte Mittelverwaltung durch Übertragung von Haushaltsvollzugsaufgaben an:

    - –  Drittländer oder die von ihnen benannten Einrichtungen

    - –  internationale Einrichtungen und deren Agenturen (bitte angeben)

    - –  die Europäische Investitionsbank und den Europäischen Investitionsfonds

    - –  Einrichtungen im Sinne der Artikel 70 und 71 der Haushaltsordnung

    - –  öffentlich-rechtliche Körperschaften

    - –  privatrechtliche Einrichtungen, die im öffentlichen Auftrag tätig werden, sofern ihnen ausreichende finanzielle Garantien bereitgestellt werden

    - –  privatrechtliche Einrichtungen eines Mitgliedstaats, die mit der Einrichtung einer öffentlich-privaten Partnerschaft betraut werden und denen ausreichende finanzielle Garantien bereitgestellt werden

    - –  Einrichtungen oder Personen, die mit der Durchführung bestimmter Maßnahmen im Bereich der Gemeinsamen Außen- und Sicherheitspolitik im Rahmen des Titels V des Vertrags über die Europäische Union betraut und die in dem maßgeblichen Basisrechtsakt benannt sind

    - –  in einem Mitgliedstaat ansässige Einrichtungen, die dem Privatrecht eines Mitgliedstaats oder dem Unionsrecht unterliegen und im Einklang mit sektorspezifischen Vorschriften für die Betrauung mit der Ausführung von Unionsmitteln oder mit der Erteilung von Haushaltsgarantien in Betracht kommen, insofern diese Einrichtungen von öffentlich-rechtlichen Körperschaften oder von privatrechtlichen, im öffentlichen Auftrag tätig werdenden Einrichtungen kontrolliert und von den Kontrollstellen mit angemessenen finanziellen Garantien mit gesamtschuldnerischer Haftung oder gleichwertigen finanziellen Garantien ausgestattet werden, die bei jeder Maßnahme auf den Höchstbetrag der Unionsunterstützung begrenzt sein können.

### 2. VERWALTUNGSMAẞNAHMEN

#### 2.1. Überwachung und Berichterstattung

    Die Verordnung wird fünf Jahre nach ihrem Inkrafttreten überprüft und bewertet. Die Kommission wird die Ergebnisse dieser Bewertung dem Europäischen Parlament und dem Rat übermitteln. Zur Unterstützung der einheitlichen Durchführung und Überwachung dieser Verordnung sollten die Mitgliedstaaten dafür sorgen, dass die einschlägigen Informationen über ihre Tätigkeiten der Kommission rechtzeitig zur Verfügung stehen.

#### 2.2. Verwaltungs- und Kontrollsystem(e)

##### 2.2.1. Begründung der Haushaltsvollzugsart(en), des Durchführungsmechanismus/der Durchführungsmechanismen für die Finanzierung, der Zahlungsmodalitäten und der Kontrollstrategie, wie vorgeschlagen

    Mit der Verordnung wird ein neuer politischer Rahmen für harmonisierte Vorschriften für die Beschaffung von Cloud-Computing-Diensten im Binnenmarkt und die Einrichtung von Rechenzentren in der gesamten EU geschaffen, und gleichzeitig wird die Verwirklichung der politischen Ziele der Union in den Bereichen Verbrauchervertrauen, industrielle Wettbewerbsfähigkeit, Sicherheit und Resilienz sowie Nachhaltigkeit unterstützt. Die Verordnung zur Cloud- und KI-Entwicklung zielt darauf ab, die Koordinierung des Rechtsrahmens für die Entwicklung von Rechenzentren und die Beschaffung von Cloud-Computing-Diensten zu vereinfachen und zu verbessern. Diese Ziele machen eine verstärkte Koordinierung und operative Kapazitäten auf EU-Ebene erforderlich, wofür wiederum gezielte und verhältnismäßige Haushaltsmittel benötigt werden. Mit dem Vorschlag werden verhältnismäßige Änderungen eingeführt, indem ein Governance-System mit neuen Aufgaben auf EU-Ebene mit einer Binnenmarktdimension geschaffen und gleichzeitig sichergestellt wird, dass die Entscheidungsfindung weiterhin auf der effizientesten Ebene stattfindet. Das gewählte Governance-Modell soll auf bestehenden Strukturen und Mandaten aufbauen, wodurch der Bedarf an neuen Einrichtungen begrenzt und die Ausführung des Haushaltsplans mittels wohl etablierter administrativer und finanzieller Regelungen ermöglicht wird, was wiederum die Kosteneffizienz und Vorhersehbarkeit der Ausgaben gewährleistet.

    Zur Erfüllung dieser neuen Aufgaben ist zusätzliches Personal erforderlich. Für die Durchführung und Durchsetzung der Verordnung werden schätzungsweise 6 zusätzliche VZÄ für die GD CNECT und 4 VZÄ für die GD DIGIT benötigt. Die vorgeschlagene Personalausstattung steht in einem angemessenen Verhältnis mit dem Umfang und der Komplexität der neuen Zuständigkeiten und spiegelt die kosteneffizienteste Option wider, bei der Doppelarbeit auf nationaler Ebene vermieden wird.

    Die Zahlungen erfolgen nach den üblichen EU-Haushaltsverfahren, einschließlich der jährlicher Mittelbindungen und Zahlungen, im Einklang mit der Haushaltsordnung und innerhalb der Obergrenzen des geltenden mehrjährigen Finanzrahmens. Dies wird durch die jährlichen Beiträge aus den Gebühren zur Deckung der Kosten für zusätzliche Aufgaben und langfristige Kosten unterstützt. Die Ausgaben unterliegen dem internen Kontrollrahmen der Kommission, einschließlich Ex-ante-Kontrollen, Ex-post-Prüfungen, Leistungsüberwachung und Berichterstattung. Dies dient dazu, die Wirtschaftlichkeit der Haushaltsführung, die Rechtmäßigkeit und Ordnungsmäßigkeit der Ausgaben und die wirksame Verwendung der Unionsmittel sicherzustellen, und ermöglicht gleichzeitig die rechtzeitige Durchführung der Verordnung.

##### 2.2.2. Angaben zu den ermittelten Risiken und dem/den zu deren Eindämmung eingerichteten System(en) der internen Kontrolle

    Die in der Verordnung vorgeschlagenen Tätigkeiten betreffen verschiedene Einrichtungen der Union und einige Ausführungsrisiken, die Überwachungs-, Aufsichts-, Koordinierungs- und Orientierungsmaßnahmen zu ihrer Minderung erfordern. Die Kommission wird Personal unter anderem für die Ausarbeitung von Leitlinien, delegierten Rechtsakten, Abhängigkeitsbewertungen, das Ausschusssekretariat und die Überwachung der Umsetzung der Initiative, einschließlich der Überwachung ihrer Fortschritte anhand festgelegter zentraler Leistungsindikatoren und Etappenziele, einsetzen. Dies würde es ermöglichen, potenzielle Probleme und Risiken bei der Durchführung von Tätigkeiten rasch zu erkennen.

    Insbesondere für die gemeinsamen Auftragsvergabetätigkeiten wird ein Lenkungsausschuss eingesetzt, der sich aus der Kommission und Vertretern der Mitgliedstaaten zusammensetzt und für die strategische Aufsicht über die Auftragsvergabetätigkeiten zuständig ist, einschließlich der strategischen Ausrichtung der Planung für die Vergabe öffentlicher Aufträge und der einzelnen Vergabeverfahren, wobei die Einhaltung dieser Verordnung sowie transparente und diskriminierungsfreie Bedingungen für den Beitritt öffentlicher Auftraggeber sichergestellt werden. Im Falle des europäischen Cloud-Verbunds des öffentlichen Sektors ist es wichtig, eine breite Beteiligung von Einrichtungen der Union sicherzustellen und gleichzeitig im Einklang mit dem Unionsrecht für eine optimale Sicherheit bei der Erbringung von Dienstleistungen zu sorgen, um Durchführbarkeit, Wirksamkeit und Kontinuität zu gewährleisten. Daher sollte er für die freiwillige Beteiligung von öffentlichen Stellen und Organen, Einrichtungen und sonstigen Stellen der Union als öffentliche Stellen der Mitgliedstaaten offen stehen, die bereit sind, ihre Cloud-Computing-Infrastrukturen zu vernetzen und interoperable Cloud-Computing-Dienste in der gesamten Union einzuführen. Die Kommission würde eine Plattform einrichten, um die gemeinsame Nutzung von Rechenzentrums- und Cloud-Computing-Kapazitäten zu erleichtern, die ihren Mitgliedern zugänglich sind. Aufgrund der wahrscheinlichen Kritikalität und Sensibilität der Daten und Anwendungen, die in dieser gemeinsamen Kapazität gehostet werden, würde die Plattform Dienste und Mechanismen für einen sicheren Zugang und eine sichere Behandlung von Sicherheitsvorfällen umfassen, einschließlich des gemeinsamen Identitätsmanagements, Werkzeuge für die gegenseitige Authentifizierung und Werkzeuge für die Meldung von Sicherheitsvorfällen sowie Fähigkeiten zur Unterstützung des Betriebs der bereitgestellten Dienste, einschließlich der Überwachung der Bereitstellung der Dienste, der Ressourcenzuweisung, der Dienstaktivierung und der Leistung.

##### 2.2.3. Schätzung und Begründung der Kosteneffizienz der Kontrollen (Verhältnis zwischen den Kontrollkosten und dem Wert der betreffenden verwalteten Mittel) sowie Bewertung des erwarteten Ausmaßes des Fehlerrisikos (bei Zahlung und beim Abschluss)

    Die Kontrollkosten für diese Initiative wurden auf Kommissionsebene geschätzt. Diese Informationen stammen aus dem internen Verwaltungs- und Kontrollsystem der Kommission. Die Kosten wurden auf der Grundlage des Personals und der Ressourcen geschätzt, die für die im Rahmen dieser Initiative geplanten Tätigkeiten bereitgestellt wurden. Die erwarteten Gesamtkosten für solche Kontrollen können aufgrund der Komplexität der vorgeschlagenen Tätigkeiten und des Bedarfs an zweckgebundenen Ressourcen zur Minderung der Ausführungsrisiken relativ hoch sein. Die Kontrollintensität wird an die Art der Ausgaben, die Art der vorgesehenen Begünstigten oder Auftragnehmer, die Höhe der betreffenden Finanzmittel und die Höhe des Risikos angepasst. Spezifische Maßnahmen wie gemeinsame Vergabeverfahren, der EuroCloud-Verbund, das Finanzierungsmanagement und das Verzeichnis souveräner Dienste erfordern zielgerichtete Ressourcen und Kontrollen, einschließlich der strategischen Aufsicht, der Überwachung und der Behandlung von Sicherheitsvorfällen. Die Kosten solcher Kontrollen wurden geschätzt, um sicherzustellen, dass sie in einem angemessenen Verhältnis zum Wert der verwalteten Mittel, zur Komplexität der einzelnen Tätigkeiten und zu den ermittelten Risiken stehen.

    Ziel ist es, dass die erwartete Fehlerquote unter dem Schwellenwert von 2 % bleibt. Dies wird durch die oben genannten standardisierten Ex-ante- und Ex-post-Kontrollen, einschließlich z. B. der Überprüfung der Förderfähigkeit und Rechtmäßigkeit der Ausgaben, Kontrollen der Auftragsvergabe und der Vertragsverwaltung, die Überwachung der zu erbringenden Leistungen, risikobasierte Kontrollen, Prüfungen und gegebenenfalls Einziehungsverfahren erreicht. Jede Abweichung davon würde ein koordiniertes Vorgehen erfordern und würde im Einzelfall erörtert.

#### 2.3. Prävention von Betrug und Unregelmäßigkeiten

    Die für die Kommission geltenden Betrugsbekämpfungsmaßnahmen gelten auch für die zusätzlichen Mittel, die für diese Verordnung erforderlich werden.

### 3. GESCHÄTZTE FINANZIELLE AUSWIRKUNGEN DES VORSCHLAGS/DER INITIATIVE

#### 3.1. Betroffene Rubrik(en) des Mehrjährigen Finanzrahmens und Ausgabenlinie(n) im Haushaltsplan

  - · Bestehende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM^(40) | von EFTA-Ländern^(41) | von Kandidatenländern und potenziellen Kandidaten^(42) | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | MFR-Rubriken und noch festzulegende Haushaltslinien^(43) | GM/NGM | JA | NEIN | NEIN | NEIN |
|  | Gebühreneinnahmen (KOM wird die Gebühren erheben) | GM/NGM | JA | NEIN | NEIN | JA |

  - · Neu zu schaffende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM | von EFTA-Ländern | von Kandidatenländern und potenziellen Kandidaten | von anderen Drittländern | andere zweckgebundene Einnahmen |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |
|  | [XX.YY.YY.YY] | GM/NGM | JA/NEIN | JA/NEIN | JA/NEIN | JA/NEIN |

#### 3.2. Geschätzte finanzielle Auswirkungen des Vorschlags auf die Mittel

##### 3.2.1. Übersicht über die geschätzten Auswirkungen auf die operativen Mittel

  - –  Für den Vorschlag/die Initiative werden keine operativen Mittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden operativen Mittel benötigt:

    Die nachstehend angegebenen Beträge sind vorläufig und hängen vom endgültigen Ergebnis der Verhandlungen über den MFR 2028-2034 ab. Diese Initiative wird durch Umschichtungen innerhalb der operationellen Programme des nächsten MFR und teilweise durch Verwaltungsausgaben für Personal finanziert. Zum gegenwärtigen Zeitpunkt ist es nicht möglich, den Beitrag aus jeder einzelnen MFR-Rubrik und jedem Programm anzugeben; allerdings dürfte ein erheblicher Beitrag aus Programmen unter Rubrik 2 des MFR 2028-2034 (z. B. dem Europäischen Fonds für Wettbewerbsfähigkeit, insbesondere dem Bereich „Digitale Führungsrolle“) stammen. Diese Schätzungen wurden auf der Grundlage der derzeit verfügbaren Informationen erstellt und sollen realistische Haushaltsvoranschläge liefern.

##### 3.2.1.1. Mittel aus dem verabschiedeten Haushaltsplan

in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |
| --- | --- | --- |

| GD CNECT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) | 2,386 | 0,727 | 2,118 | 0,427 | 0,427 | 0,427 | 0,427 | 6,941 |  | 6,941 |
|  | Zahlungen | (2a) | 1,193 | 1,557 | 1,422 | 1,272 | 0,427 | 0,427 | 0,427 | 6,727 | 0,214 | 6,941 |
| Mittel INSGESAMT für die GD CNECT | Verpflichtungen | =1a | 2,386 | 0,727 | 2,118 | 0,427 | 0,427 | 0,427 | 0,427 | 6,941 | 0,000 | 6,941 |
|  | Zahlungen | =2a | 1,193 | 1,557 | 1,422 | 1,272 | 0,427 | 0,427 | 0,427 | 6,727 | 0,214 | 6,941 |

| GD DIGIT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) | 2,382 |  |  |  |  |  |  | 2,382 |  | 2,382 |
|  | Zahlungen | (2a) | 1,191 | 1,191 |  |  |  |  |  | 2,382 |  | 2,382 |
| Mittel INSGESAMT für die GD DIGIT | Verpflichtungen | =1a | 2,382 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 2,382 | 0,000 | 2,382 |
|  | Zahlungen | =2a | 1,191 | 1,191 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 2,382 | 0,000 | 2,382 |

Ab 2029 ist der VOBU-Antrag der Nettobetrag, von dem die vorgesehenen Gebühren für den Cloud-Verbund und gemeinsame Vergabeverfahren abgezogen wurden.

| INSGESAMT (DIGIT + CNECT) | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 4,768 | 0,727 | 2,118 | 0,427 | 0,427 | 0,427 | 0,427 | 9,323 | 0,000 | 9,323 |
|  | Zahlungen | (5) | 2,384 | 2,748 | 1,422 | 1,272 | 0,427 | 0,427 | 0,427 | 9,109 | 0,214 | 9,323 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Mittel INSGESAMT unter der RUBRIK 2 | Verpflichtungen | = 4+6 | 4,768 | 0,727 | 2,118 | 0,427 | 0,427 | 0,427 | 0,427 | 9,323 | 0,000 | 9,323 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 2,384 | 2,748 | 1,422 | 1,272 | 0,427 | 0,427 | 0,427 | 9,109 | 0,214 | 9,323 |

| Rubrik des Mehrjährigen Finanzrahmens | 4 | „Verwaltungsausgaben“ |
| --- | --- | --- |

in Mio. EUR (3 Dezimalstellen)

| GD CNECT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
|  Personalausgaben | 1,810 | 1,810 | 1,810 | 1,810 | 1,810 | 1,810 | 1,810 | 12,670 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD CNECT INSGESAMT | Mittel | 1,810 | 1,810 | 1,810 | 1,810 | 1,810 | 1,810 | 1,810 | 12,670 |
| GD DIGIT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
|  Personalausgaben | 1,794 | 1,794 | 1,794 | 1,794 | 1,794 | 1,794 | 1,794 | 12,558 |  |
|  Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |  |
| GD DIGIT INSGESAMT | Mittel | 1,794 | 1,794 | 1,794 | 1,794 | 1,794 | 1,794 | 1,794 | 12,558 |
| Mittel INSGESAMT unter der RUBRIK 4 des Mehrjährigen Finanzrahmens | (Verpflichtungen insges. = Zahlungen insges.) | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 25,228 |

in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 4 des Mehrjährigen Finanzrahmens | Verpflichtungen | 8,372 | 4,331 | 5,722 | 4,031 | 4,031 | 4,031 | 4,031 | 34,551 | 0,000 | 34,551 |
|  | Zahlungen | 5,988 | 6,352 | 5,026 | 4,876 | 4,031 | 4,031 | 4,031 | 34,337 | 0,214 | 34,551 |

##### 3.2.1.2. Durch Gebühren gedeckte Mittel (EuroCloud und gemeinsame Cloud-Vergabeverfahren)

in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Nummer |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GD CNECT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |  |
| Durch Gebühren finanzierte operative Mittel |  |  |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) | 0,000 | 2,940 | 4,410 | 5,880 | 2,570 | 2,570 | 2,570 | 20,939 |  | 20,939 |
|  | Zahlungen | (2a) | 0,000 | 2,940 | 4,410 | 5,880 | 2,570 | 2,570 | 2,570 | 20,939 |  | 20,939 |
| Durch Gebühren finanzierte Verwaltungsmittel |  |  |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  |  |  |  |  |  |  |
| Mittel INSGESAMT | Verpflichtungen | =1a+3 | 0,000 | 2,940 | 4,410 | 5,880 | 2,570 | 2,570 | 2,570 | 20,939 | 0,000 | 20,939 |
| für die GD CNECT | Zahlungen | =2a+3 | 0,000 | 2,940 | 4,410 | 5,880 | 2,570 | 2,570 | 2,570 | 20,939 |  | 20,939 |

| GD DIGIT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |  |
| Durch Gebühren finanzierte operative Mittel |  |  |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie | Verpflichtungen | (1a) | 0,000 | 3,027 | 4,317 | 6,037 | 6,342 | 6,663 | 7,001 | 33,387 |  | 33,387 |
|  | Zahlungen | (2a) | 0,000 | 3,027 | 4,317 | 6,037 | 6,342 | 6,663 | 7,001 | 33,387 |  | 33,387 |
| Durch Gebühren finanzierte Verwaltungsmittel |  |  |  |  |  |  |  |  |  |  |  |  |
| Haushaltslinie |  | (3) |  |  |  |  |  |  |  | 0 |  | 0 |
| Mittel INSGESAMT | Verpflichtungen | =1a+3 | 0,000 | 3,027 | 4,317 | 6,037 | 6,342 | 6,663 | 7,001 | 33,387 | 0,000 | 33,387 |
| für die GD DIGIT | Zahlungen | =2a+3 | 0,000 | 3,027 | 4,317 | 6,037 | 6,342 | 6,663 | 7,001 | 33,387 |  | 33,387 |
|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT | NACH 2034 | INSGESAMT |  |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |  |
| Operative Mittel INSGESAMT | Verpflichtungen | (4) | 0,000 | 5,967 | 8,727 | 11,917 | 8,912 | 9,233 | 9,570 | 54,326 | 0,000 | 54,326 |
|  | Zahlungen | (5) | 0,000 | 5,967 | 8,727 | 11,917 | 8,912 | 9,233 | 9,570 | 54,326 |  | 54,326 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) |  |  |  |  |  |  |  |  |  |  |  |
| Mittel INSGESAMT unter der RUBRIK 2 | Verpflichtungen | = 4+6 | 0,000 | 5,967 | 8,727 | 11,917 | 8,912 | 9,233 | 9,570 | 54,326 | 0,000 | 54,326 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 0,000 | 5,967 | 8,727 | 11,917 | 8,912 | 9,233 | 9,570 | 54,326 | 0,000 | 54,326 |

##### 3.2.2. Geschätzter Output, der mit operativen Mitteln finanziert wird (nicht auszufüllen im Fall dezentraler Agenturen)

Mittel für Verpflichtungen, in Mio. EUR (3 Dezimalstellen)

| Ziele und Outputs angeben  |  |  | Jahr 2024 | Jahr 2025 | Jahr 2026 | Jahr 2027 | Bei länger andauernden Auswirkungen bitte weitere Spalten einfügen (siehe 1.6) | INSGESAMT |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art^(44) | Durchschnittskosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Gesamtzahl | Gesamtkosten |
| EINZELZIEL Nr. 1^(45)… |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EINZELZIEL Nr. 2... |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Output |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Zwischensumme für Einzelziel Nr. 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| INSGESAMT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

##### 3.2.3. Übersicht über die geschätzten Auswirkungen auf die Verwaltungsmittel

  - –  Für den Vorschlag/die Initiative werden keine Verwaltungsmittel benötigt.

  - –  Für den Vorschlag/die Initiative werden die folgenden Verwaltungsmittel benötigt:

#####  3.2.3.1. Mittel aus dem verabschiedeten Haushaltsplan

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| RUBRIK 4 |  |  |  |  |  |  |  |  |
| Personalausgaben | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 25.22Ff8 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme RUBRIK 4 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 25,228 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |
| Personalausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |
| INSGESAMT | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 3,604 | 25,228 |

    Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus dienen lediglich der Veranschaulichung und greifen dem nächsten Mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034 ab und werden danach durch das jährliche Haushaltsverfahren bestimmt. Alle Mittel- und Personalzuweisungen ab 2028 sind vorläufig.

##### 3.2.3.2. Mittel aus externen zweckgebundenen Einnahmen

    Entfällt.

##### 3.2.3.3. Mittel insgesamt

    Siehe Tabelle oben.

##### 3.2.4. Geschätzter Personalbedarf

  - –  Für den Vorschlag/die Initiative wird kein Personal benötigt.

  - –  Für den Vorschlag/die Initiative wird das folgende Personal benötigt:

##### 3.2.4.1. Finanziert aus dem verabschiedeten Haushalt

Schätzung in Vollzeitäquivalenten (VZÄ)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
|  Planstellen (Beamte und Zeitbedienstete) |  |  |  |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 11 | 11 | 11 | 11 | 11 | 11 | 11 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| • Externes Personal (in VZÄ) |  |  |  |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 14 | 14 | 14 | 14 | 14 | 14 | 14 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Haushaltslinie administr. Unterstützung [XX.01.YY.YY] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 7 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – außerhalb der Rubrik 7 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| INSGESAMT | 25 | 25 | 25 | 25 | 25 | 25 | 25 |  |

    Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus dienen lediglich der Veranschaulichung und greifen dem nächsten Mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034 ab und werden danach durch das jährliche Haushaltsverfahren bestimmt. Alle Mittel- und Personalzuweisungen ab 2028 sind vorläufig.

##### 3.2.4.2. Finanziert aus externen zweckgebundenen Einnahmen

    Entfällt.

##### 3.2.4.3. Geschätzter Personalbedarf insgesamt

    Für die Durchführung des Vorschlags benötigtes Personal (in VZÄ):

|  | Personal aus den Dienststellen der Kommission | Zusatzpersonal (ausnahmsweise)* |  |  |
| --- | --- | --- | --- | --- |
|  |  | Zu finanzieren aus Rubrik 7 oder Forschung | Zu finanzieren aus einer Haushaltslinie für administrative Unterstützung | Zu finanzieren aus Gebühren |
| Planstellen | 5 | 6 | Nicht zutreffend |  |
| Externes Personal (VB, ANS, LAK) | 10 | 4 |  |  |

    * Die geschätzten Auswirkungen auf die Ausgaben und die Personalausstattung für 2028 und darüber hinaus sind vorläufig und greifen dem nächsten mehrjährigen Finanzrahmen nicht vor. Die Finanzierungsquelle und der Umfang der finanziellen Verpflichtung der Union in der Zeit nach 2027 hängen weiterhin vom Ergebnis der interinstitutionellen Verhandlungen über den MFR 2028-2034, dem jährlichen Haushaltsverfahren und dem Lenkungsmechanismus ab.

    Insgesamt sind 15 VZÄ, die für die Initiative beantragt wurden, bereits vorhanden und werden mit folgender Aufteilung umgeschichtet:

  - – GD CNECT: 2 VZÄ für Planstellen und 5 VZÄ für externes Personal

  - – GD DIGIT: 3 VZÄ für Planstellen und 5 VZÄ für externes Personal

    Zusätzlich zu diesen vorhandenen Ressourcen werden für die Initiative 10 VZÄ als außerordentliches zusätzliches Personal benötigt. Diese setzen sich aus sechs Beamten und vier Vertragsbediensteten zusammen und verteilen sich wie folgt auf die GD CNECT und die GD DIGIT:

  - – GD CNECT: 3 VZÄ für Planstellen und 3 VZÄ für externes Personal

  - – GD DIGIT: 3 VZÄ für Planstellen und 1 VZÄ für externes Personal

    Diese werden zusätzlich zum derzeitigen Personalbestand beantragt, um die vollständige und wirksame Umsetzung der Initiative zu gewährleisten. Die neuen Aufgaben, die mit dem Vorschlag eingeführt werden, können nicht durch die vorhandenen personellen Ressourcen der jeweiligen Generaldirektionen bewältigt werden. Die für diesen Vorschlag erforderlichen zusätzlichen personellen Ressourcen können in vollem Umfang durch Umschichtungen innerhalb der GD/Dienststelle oder in Ausnahmefällen durch Umschichtungen aus dem begrenzten Umschichtungspool der Kommission nach entsprechender Anwendung des internen Verfahrens gedeckt werden.

    Beschreibung der neuen Aufgaben der GD CNECT und der GD DIGIT:

| Beamte und Zeitbedienstete | Beamten und Zeitbediensteten werden folgende Aufgaben übertragen: 1.Festlegung und Verwaltung der Arbeitsprogramme im Rahmen der Säule 1 der Initiative, einschließlich der Entwicklung detaillierter Projektpläne, Haushaltsmittel, Mittelzuweisungen, KPIs und Überwachungsmechanismen; 2.Erstellung von Leitlinien, delegierten Rechtsakten, Abhängigkeitsbewertungen, Ausschusssekretariat und Überwachung der Umsetzung der Initiative, einschließlich a.Entwicklung umfassender Leitlinien, Empfehlungen, Muster und Werkzeuge zur Unterstützung der Mitgliedstaaten bei ihren Umsetzungsbemühungen in Bezug auf Säule 2 und Säule 3 der Initiative, b.erforderlichenfalls Ausarbeitung von Durchführungsrechtsakten, z. B. über die Anforderungen an die Mitglieder des EuroCloud-Verbunds und das Verfahren zur Bewertung ihrer Anträge, c.Erstellung von Marktüberwachungsberichten zur Ermittlung von Cloud-Computing-Diensten, bei denen die Union in Bezug auf solche Dienste in hohem Maße von einer einzigen oder einer begrenzten Zahl von Rechtsträgern aus Drittländern abhängig ist, d.Bereitstellung von Sekretariatsdiensten, einschließlich der Erstellung von Dokumenten und Berichten, Koordinierung mit Interessenträgern, e.Überwachung der Fortschritte der Initiative anhand der festgelegten KPIs und Etappenziele, Ermittlung möglicher Probleme und Risiken und erforderlichenfalls Bereitstellung technischer Hilfe und Unterstützung für die Mitgliedstaaten, f.Einrichtung eines Wissensmanagementsystems, um bewährte Verfahren, gewonnene Erkenntnisse und Sachkenntnis im Rahmen der Initiative zu erfassen und auszutauschen; 3.Entwurf der Spezifikationen der Ausschreibung für einen externen Anbieter für den Aufbau, die Entwicklung und die Pflege des Verzeichnisses souveräner Dienste sowie Bewertung und Festlegung der anschließenden Governance-Verfahren. Nach der Einrichtung regelmäßige Prüfung/Bewertung zertifizierter Dienste, die Teil des Verzeichnisses sind, einschließlich der Entwicklung von Prüfprotokollen und Bewertungsmethoden und/oder Qualitätskontrollverfahren, um die Zuverlässigkeit der bereitgestellten Informationen zu gewährleisten; 4.Beschaffung der EuroCloud-Verbundplattform und Unterstützung von deren Einrichtung. Verwaltung der Governance-Mechanismen des Verbunds, z. B. Zertifizierung der Voraussetzungen für die Verbundsmitgliedschaft, Bewertung der Anträge der Mitgliedstaaten und anderer öffentlicher Stellen auf Beitritt zum Verbund, Entwicklung und Durchsetzung gemeinsamer Regeln und Strategien für die Beteiligung am Verbund; 5.Einrichtung von Systemen, die derzeit noch nicht vorhanden sind, als Teil des Rahmens für gemeinsame Vergabeverfahren, einschließlich Verwaltung komplexer KI-Vergabeverfahren und der Beziehungen zu den Mitgliedstaaten und den öffentlichen Auftraggebern sowie Gewährleistung der Wirksamkeit und Effizienz des Rahmens. Dazu gehören Aufgaben wie die Einrichtung und Verwaltung der Vergabeverfahren für Cloud-Dienste, Software- und KI-Systeme, die Koordinierung mit den teilnehmenden Organisationen und Diensteanbietern, die Verwaltung der Verträge und Vereinbarungen mit Diensteanbietern und die Gewährleistung der Einhaltung der Vorschriften und Strategien der EU; 6.Aufbau und Pflege von Beziehungen zu Interessenträgern, einschließlich Mitgliedstaaten, Vertreter der Industrie und anderer einschlägiger Parteien, um sicherzustellen, dass die Initiative gut koordiniert und wirksam ist und den Bedürfnissen ihrer Interessenträger entspricht, einschließlich der Organisation regelmäßiger Sitzungen, Workshops und Konferenzen zur Erleichterung der Kommunikation und Zusammenarbeit. Dies würde auch eine enge Zusammenarbeit mit den zuständigen Behörden bei Ermittlungs- und Durchsetzungsmaßnahmen umfassen, um die Einhaltung von Titel IV der Verordnung sicherzustellen. |
| --- | --- |
| Externes Personal | Externem Personal werden folgende Aufgaben übertragen: 1.Regelmäßige Verwaltung der im Rahmen der Arbeitsprogramme der Säule 1 geförderten Projekte, einschließlich der Überwachung ihrer Fortschritte, der Koordinierung mit den Begünstigten und der Überprüfung der zu erbringenden Leistungen und Etappenziele des Projekts, um sicherzustellen, dass sie fristgerecht, im Rahmen der verfügbaren Haushaltsmittel und im Einklang mit den vorgegebenen Qualitätsstandards durchgeführt werden. Die Initiative wird im nächsten MFR umgesetzt und wird auf den Ergebnissen bestehender Projekte aufbauen, die bereits im Rahmen des Programms Horizont Europa und des Programms Digitales Europa genehmigt wurden, z. B. Simpl und das Gemeinsame Unternehmen für intelligente Netze und Dienste, auch in Abstimmung mit anderen Referaten; 2.Einrichtung und Betrieb von Unterstützungsmechanismen, um den Mitgliedstaaten Leitlinien für die Einrichtung von Beschleunigungsgebieten für Rechenzentren an die Hand zu geben, insbesondere in den ersten beiden Jahren der Initiative. Dazu gehört die Bereitstellung von Ad-hoc-Unterstützung für die Mitgliedstaaten bei der Entwicklung und Umsetzung ihrer nationalen Strategien und Pläne. Nach der Anfangsphase wird dies eher zu einer Ad-hoc-Koordinierungsrolle führen, wobei der Schwerpunkt auf der gezielten Unterstützung entsprechend dem Bedarf der Mitgliedstaaten liegt, und wird sichergestellt, dass die Initiative weiterhin auf die Bedürfnisse und Prioritäten ihrer Interessenträger abgestimmt ist; 3.Einrichtung und Verwaltung einer jährlichen Studie zur Überwachung der Rechenkapazitäten in ganz Europa, einschließlich der Festlegung des Umfangs und der Methodik der Studie, der Überprüfung der erhobenen Daten und der Überprüfung der zu erbringenden Leistungen; 4.Verwaltung der gemeinsamen Auftragsvergabetätigkeiten, insbesondere in Bezug auf die strategische Auftragsvergabe und die Marktgestaltung, d. h. Büro für das Anbietermanagement und Ausarbeitung von Spezifikationen und technischen Anforderungen für Cloud-, KI- und Softwaredienste; 5.Verwaltung des Verzeichnisses souveräner Dienste auf jährlicher Basis, unter anderem durch Überwachung der Tätigkeiten des Auftragnehmers im Zusammenhang mit dem Betrieb des Verzeichnisses, einschließlich des technischen Projektmanagements, d. h. Sicherstellung, dass der Auftragnehmer das Verzeichnis gemäß den vereinbarten technischen Spezifikationen, Fristen und Mitteln bereitstellt, sowie Überwachung der Prozesse des Auftragnehmers, um sicherzustellen, dass das Verzeichnis die erforderlichen Standards erfüllt; 6.Verwaltung des externen Auftragnehmers, der jährlichen administrativen, technischen und operativen Tätigkeiten der EuroCloud-Verbundplattform sowie der technischen Aspekte der EuroCloud-Verbundplattform, einschließlich der Aufsicht über die technische Architektur und Infrastruktur. |

##### 3.2.5. Einschätzung der Auswirkungen auf die Investitionen im Zusammenhang mit digitalen Technologien

    Obligatorisch: In die Tabelle unten ist die bestmögliche Einschätzung der für den Vorschlag/die Initiative erforderlichen Investitionen in digitale Technologien einzutragen.

    Wenn dies für die Durchführung des Vorschlags/der Initiative erforderlich ist, sollten die Mittel unter Rubrik 7 ausnahmsweise in der dafür vorgesehenen Haushaltslinie ausgewiesen werden.

    Die Mittel unter den Rubriken 1-6 sollten als „IT-Ausgaben zur Politikunterstützung für operationelle Programme“ ausgewiesen sein. Diese Ausgaben beziehen sich auf die operativen Mittel, die für die Wiederverwendung/den Erwerb/die Entwicklung von IT-Plattformen/Instrumenten verwendet werden, welche in direktem Zusammenhang mit der Durchführung der Initiative und den damit verbundenen Investitionen stehen (z. B. Lizenzen, Studien, Datenspeicherung usw.). Die in dieser Tabelle dargelegten Informationen sollten mit den Angaben in Abschnitt 4 „Digitale Aspekte“ vereinbar sein.

| Mittel INSGESAMT für Digitales und IT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| RUBRIK 4 |  |  |  |  |  |  |  |  |
| IT-Ausgaben (intern) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Zwischensumme RUBRIK 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |
| IT-Ausgaben zur Politikunterstützung für operationelle Programme | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Zwischensumme außerhalb der RUBRIK 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| INSGESAMT | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

##### 3.2.6. Vereinbarkeit mit dem derzeitigen Mehrjährigen Finanzrahmen

    Der Vorschlag/Die Initiative

  - –  kann durch Umschichtungen innerhalb der entsprechenden Rubrik des Mehrjährigen Finanzrahmens (MFR) in voller Höhe finanziert werden.

    Unbeschadet der Verhandlungen über den nächsten MFR werden die den Tätigkeiten im Zusammenhang mit der Verordnung zur Cloud- und KI-Entwicklung ab 2028 zugewiesenen Mittel durch Umschichtungen aus dem ECF im Rahmen des MFR 2028-2034 abgedeckt.

  - –  erfordert die Inanspruchnahme des verbleibenden Spielraums unter der einschlägigen Rubrik des MFR und/oder den Einsatz der besonderen Instrumente im Sinne der MFR-Verordnung.

  - –  erfordert eine Änderung des MFR.

##### 3.2.7. Beiträge Dritter

    Der Vorschlag/Die Initiative

  - –  sieht keine Kofinanzierung durch Dritte vor.

  - –  sieht folgende Kofinanzierung durch Dritte vor:

Mittel in Mio. EUR (3 Dezimalstellen)

|  | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Jahr 2032 | Jahr 2033 | Jahr 2034 | Insgesamt |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kofinanzierende Einrichtung |  |  |  |  |  |  |  |  |
| Kofinanzierung INSGESAMT |  |  |  |  |  |  |  |  |

3.3. Geschätzte Auswirkungen auf die Einnahmen

  - –  Der Vorschlag/Die Initiative wirkt sich nicht auf die Einnahmen aus.

  - –  Der Vorschlag/Die Initiative wirkt sich auf die Einnahmen aus, und zwar

- –  auf die Eigenmittel

- –  auf die übrigen Einnahmen

- –  Bitte geben Sie an, ob die Einnahmen bestimmten Ausgabenlinien zugeordnet sind.

in Mio. EUR (3 Dezimalstellen)

| Einnahmenlinie: | Für das laufende Haushaltsjahr zur Verfügung stehende Mittel | Auswirkungen des Vorschlags/der Initiative^(46) |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Jahr 2032 | Jahr 2033 | Jahr 2034 |
| Dienstgebühr für gemeinsame Cloud-Vergabeverfahren (GD DIGIT) |  | 0,000 | 3,027 | 4,317 | 6,037 | 6,342 | 6,663 | 7,001 |
| Gebühr Cloud-Verbund (GD CNECT) |  | 0,000 | 2,940 | 4,410 | 5,880 | 2,570 | 2,570 | 2,570 |

    Bitte geben Sie für die sonstigen zweckgebundenen Einnahmen die betreffende(n) Ausgabenlinie(n) im Haushaltsplan an.

    Dienstgebühr für gemeinsame Cloud-Vergabeverfahren:

    Die zweckgebundenen Einnahmen werden zur Deckung der Haushaltsausgaben im Zusammenhang mit dem für gemeinsame Vergabeverfahren eingerichteten Vermittlungssystem verwendet. Die Einnahmen werden zur Deckung der Betriebskosten des Systems, einschließlich der Kosten für externes Personal, Werkzeuge und Systeme, verwendet.

    Die zweckgebundenen Einnahmen verteilen sich im Durchschnitt wie folgt: Rund 50 % werden zur Deckung der Betriebs- und Verwaltungskosten bereitgestellt, z. B. für Studien und Forschungsarbeiten als Grundlage für Auftragsvergabeentscheidungen, Werkzeuge für das Gemeinschafts-Management und Systeme zur Unterstützung der Kommunikation und Zusammenarbeit zwischen den teilnehmenden Organisationen, technische Voraussetzungen und die Integration der Plattformen; etwa 30 % werden zur Deckung der Kosten der Entwicklung und Wartung der erforderlichen Werkzeuge und Systeme bereitgestellt, z. B. für Auftragsvergabeplattformen und -märkte, Systeme für das Lebenszyklusmanagement von Verträgen, Werkzeuge für das Portfoliomanagement und die Nachfragesteuerung; rund 20 % werden zur Deckung der Kosten für zusätzliches spezialisiertes externes Personal bereitgestellt, z. B. für Softwarebeschaffung, Datenschutztätigkeiten, Backoffice, FinOps und ContractOps für die Verwaltung vertraglicher Aspekte, Portfoliomanagement und Nachfragesteuerung.

    Mit dieser Zuweisung soll sichergestellt werden, dass die zweckgebundenen Einnahmen ausschließlich zur Deckung der Betriebskosten des Systems und der Haushaltsausgaben im Zusammenhang mit dem Vermittlungssystem verwendet werden. Diese Kosten werden auf der Grundlage des tatsächlichen Bedarfs zugewiesen, um sicherzustellen, dass die Ressourcen effizient zur Unterstützung gemeinsamer Vergabeverfahren eingesetzt werden.

    Gebühr Cloud-Verbund:

    Die zweckgebundenen Einnahmen werden zur Deckung der Haushaltsausgaben im Zusammenhang mit den Diensten und der Plattform verwendet, die für den EuroCloud-Verbund eingerichtet werden. Die Einnahmen werden zur Deckung der Betriebskosten des Systems, einschließlich der Kosten für externes Personal, Werkzeuge und Systeme, verwendet.

    Die zur Finanzierung des Verbunds erforderlichen Ausgaben setzen sich aus Betriebs- und Entwicklungskosten zusammen. Ein erheblicher Teil entfällt auf die Entwicklung und Pflege der Plattform. Die Entwicklungskosten dürften in den ersten Jahren am höchsten sein, was der Ersteinführungsphase entspricht. Ab dem vierten Jahr würden die Kosten laufende Maßnahmen, technische Unterstützung und regelmäßige Modernisierungen abdecken. Der Plattformpflegevertrag würde die Qualitätssicherung und Leistungsbewertung umfassen, die von einem externen Auftragnehmer auf der Grundlage ähnlicher Aufträge durchgeführt werden und auf etwa 10 % des Gesamtauftragswerts geschätzt werden. Die Betriebskosten umfassen die Kosten für externe technische Sachverständige (10 Profile) zusätzlich zu den internen VZÄ, die für die Koordinierung und das Projektmanagement zuständig wären (siehe die Beschreibung der neuen Aufgaben der GD CNECT). Ihre Beteiligung würde schrittweise zunehmen, mit etwa 40 % der Kapazität in Jahr 1, 80 % in Jahr 2 und voller Kapazität ab Jahr 3 entsprechend dem zunehmenden operativen Bedarf des Verbunds. Weitere Ausgaben umfassen IT-Infrastrukturkosten wie Hostingdienste und sicherheitsbezogene Werkzeuge, die erforderlich sind, um die Zuverlässigkeit, Skalierbarkeit und den Schutz der Plattform zu gewährleisten.

    Mit dieser Zuweisung soll sichergestellt werden, dass die zweckgebundenen Einnahmen zur Deckung der Betriebskosten des Systems und der Haushaltsausgaben im Zusammenhang mit den bereitgestellten Diensten verwendet werden. Diese Kosten werden auf der Grundlage des tatsächlichen Bedarfs zugewiesen, um sicherzustellen, dass die Ressourcen effizient zur Unterstützung des EuroCloud-Verbunds eingesetzt werden. Die anfänglichen Einrichtungskosten können aus dem Gesamthaushalt der Union bestritten und von den teilnehmenden Behörden über einen bestimmten Zeitraum durch die Gebühren erstattet werden.

    Sonstige Anmerkungen (bei der Ermittlung der Auswirkungen auf die Einnahmen verwendete Methode/Formel oder weitere Informationen).

    Dienstgebühr für gemeinsame Cloud-Vergabeverfahren:

    Die Gebühr soll die Betriebskosten für die Auftragsvergabetätigkeiten (interinstitutionelle Vergabeverfahren, gemeinsame Vergabeverfahren und zentrale Auftragsvergabetätigkeiten) und die möglichen Beschaffungsnebentätigkeiten decken.

    Die Gebühren würden von den teilnehmenden öffentlichen Auftraggeber getragen. Die Gebühr würde den Preis für die öffentlichen Auftraggeber erhöhen. Dies wird jedoch so festgelegt, dass ausschließlich die notwendigen Kosten für die Verwaltung der Auftragsvergabetätigkeiten gedeckt werden, da das Ziel dieser gemeinsamen Vergabeverfahren darin bestehen würde, bessere Bedingungen und niedrigere Preise für alle öffentlichen Auftraggeber auszuhandeln und die Einführung von Technologien, die sich ständig weiterentwickeln, in großem Maßstab zu erleichtern.

    Die Gebühren werden anteilig pro Transaktion oder über eine Pauschalgebühr pro anschließend vergebenem Auftrag berechnet, wie in den Auftragsunterlagen angegeben. Die Gebühren werden auf der Grundlage einer jährlichen Prognose des Verbrauchs der Begünstigten berechnet und jährlich vor der Ausführung der Verträge erhoben. Die den teilnehmenden öffentlichen Auftraggebern in Rechnung gestellten Gebühren dürfen die nachprüfbaren Kosten der Kommission nicht übersteigen. Sie werden jährlich proportional zum Umfang der vorgesehenen Arbeiten und den entstandenen Kosten neu berechnet. Die Gebühr würde ab 2029 erhoben, um einen ersten Aufbauprozess zu ermöglichen. Die Gebühr wird über bestehende Online-Dienste für die Rechnungsstellung und die Einziehung von Zahlungen von den teilnehmenden öffentlichen Auftraggebern erhoben.

    Die voraussichtlichen jährlichen Einnahmen hängen sowohl von der Zahl der teilnehmenden Behörden (Begünstigten) als auch von ihren durchschnittlichen erwarteten Vergabeverfahren ab. Die Gebühreneinnahmen müssen sich auf rund 6 Mio. EUR pro Jahr belaufen, um die voraussichtlichen durchschnittlichen jährlichen Kosten zu decken. Auf der Grundlage von Schätzungen der Beteiligung sollte dies mit einem durchschnittlichen jährlichen Gebührensatz von 2 % der Ausgaben pro Behörde erreichbar sein. Überschreiten die Gesamtausgaben dieses Niveau, z. B. weil mehr Behörden teilnehmen, sind die durchschnittlichen Ausgaben pro Behörde höher, oder beides, würde der Gebührensatz proportional sinken. Die Einnahmen aus der Gebühr werden zur Finanzierung der Gesamtbetriebskosten des Auftragsvergabemechanismus verwendet, wie oben erläutert.

    Die Kommission erstattet dem Europäischen Parlament und dem Rat Bericht über den Gesamtbetrag der Kosten, die für die Auftragsvergabetätigkeiten entstanden sind, und über den Gesamtbetrag der erhobenen Gebühren.

    Gebühr Cloud-Verbund:

    Die Gebühr soll die Betriebskosten für die Einrichtung und Verwaltung des EuroCloud-Verbunds decken, einschließlich der Bewertung von Mitgliedschaftsanträgen und der Erleichterung der gemeinsamen Nutzung von Rechenzentrums- und Cloud-Computing-Diensten durch die Entwicklung der EuroCloud-Verbundplattform.

    Die Gebühren würden von den Verbundsmitgliedern getragen. Die Gebühr würde die Gesamtkosten für die Teilnehmer leicht erhöhen. Sie ist jedoch so streng abzustimmen, dass sie die wesentlichen Verwaltungs- und Betriebskosten des Verbunds deckt. Dies dürfte zu Effizienzgewinnen und Kosteneinsparungen führen. Indem es den Mitgliedern ermöglicht wird, Kapazitäten zu teilen und ansonsten ungenutzte Ressourcen zu nutzen, können die Teilnehmer Dienste zu günstigeren Preisen in Anspruch nehmen, als sie auf dem freien Markt verfügbar sind. Dieses Modell der gemeinsamen Nutzung kann den Bedarf an externer Auftragsvergabe verringern und die Ressourcennutzung insgesamt verbessern, insbesondere kurz- bis mittelfristig. Die Gebühr führt zwar zu Grenzkosten, wird aber durch die wirtschaftlichen Vorteile ausgeglichen, die sich aus der Zusammenarbeit, einer verbesserten Kapazitätsnutzung und einer wettbewerbsfähigeren Preisgestaltung innerhalb des Verbunds ergeben.

    Die Kommission erlässt Durchführungsrechtsakte mit Durchführungsbestimmungen für die Festsetzung der von der Kommission zu erhebenden Gebühren, in denen die geschätzten Kosten für jede der Tätigkeiten, für die Gebühren zu entrichten sind, und die einzelnen zu entrichtenden Gebührenbeträge sowie die Modalitäten und Bedingungen, unter denen die Gebühren zu entrichten sind, präzisiert werden.

    Der Mitgliedsbeitrag würde als Kostendeckungsmechanismus gestaltet, der in einem angemessenen Verhältnis zur Zahl der am Verbund teilnehmenden Einrichtungen stünde. Ziel ist es, die Kosten zu decken und gleichzeitig die finanzielle Belastung der einzelnen Mitglieder mit steigender Beteiligung schrittweise zu verringern.

    Es wird davon ausgegangen, dass die Inanspruchnahme im Laufe der Zeit zunimmt, wobei etwa 20 % der möglichen Einrichtungen im ersten Jahr, 40 % im zweiten Jahr, 60 % im dritten Jahr und rund 80 % im vierten Jahr beitreten würden, bevor im fünften Jahr eine vollständige Beteiligung erreicht wird. Das erste Jahr wäre der Gründung des Verbunds gewidmet, sodass kein voller Mitgliedsbeitrag erhoben würde. Ausgehend von den Schätzungen könnte der Mitgliedsbeitrag ab Jahr 2 auf rund 75 000 EUR pro Mitglied festgesetzt werden, was die relativ geringe Teilnehmerzahl widerspiegelt. Sobald mehr Einrichtungen beitreten und die Kostenbasis auf eine größere Gruppe aufgeteilt wird, könnte die Gebühr schrittweise gesenkt werden und rund 30 000 EUR pro Mitglied erreichen, wenn die volle Kapazität erreicht ist. Es wird erwartet, dass die Regelung etwa in Jahr 4 die Gewinnschwelle erreicht. Zu diesem Zeitpunkt würde sich die Gebührenstruktur im Einklang mit dem Kostendeckungsprinzip auf einem Niveau stabilisieren, das ausreicht, um den Betrieb aufrechtzuerhalten, ohne einen erheblichen Überschuss zu generieren.

    Die Gebühr würde ab 2029 erhoben, um einen ersten Aufbauprozess zu ermöglichen. Die Gebühr wird über Online-Dienste für die Rechnungsstellung und die Einziehung von Zahlungen von den teilnehmenden Behörden erhoben.

    Die geschätzten jährlichen Einnahmen würden von der Zahl der teilnehmenden Mitglieder und dem anzuwendenden Mitgliedsbeitrag abhängen. Bei einem durchschnittlichen Mitgliedsbeitrag von rund 75 000 EUR pro Mitglied würden die jährlichen Einnahmen bei rund 4,4 Mio. EUR pro Jahr liegen, die die prognostizierten durchschnittlichen jährlichen Betriebskosten des Verbunds, einschließlich der anfänglichen Fixkosten, decken. Mit steigender Beteiligung würden die Kosten für die Verwaltung des Verbunds auf eine größere Zahl von Mitgliedern verteilt. Folglich würde die Gebühr pro Mitglied proportional sinken, wobei sich die jährlichen Einnahmen auf einem niedrigeren Niveau stabilisieren würden, z. B. bei rund 2,6 Mio. EUR pro Jahr.

    Die Kommission erstattet dem Europäischen Parlament und dem Rat Bericht über den Gesamtbetrag der Kosten, die für die Verbundstätigkeiten entstanden sind, und über den Gesamtbetrag der erhobenen Gebühren. Der Berichterstattungszeitraum ist noch festzulegen.

    Die Verwendung zweckgebundener Einnahmen für gemeinsame Vergabeverfahren und den EuroCloud-Verbund bietet eine haushaltspolitische Gelegenheit, einen gesonderten stabilen Finanzierungsstrom für diese Initiativen sicherzustellen. Durch die Bindung der Einnahmen aus der Gebühr für bestimmte Zwecke kann die Kommission gewährleisten, dass die Mittel effizient und wirksam eingesetzt werden, um die Entwicklung eines europäischen Cloud-Ökosystems zu unterstützen. Dieser Ansatz ist durch die Notwendigkeit gerechtfertigt, einen klaren und vorhersehbaren Finanzrahmen für beide Initiativen im Rahmen der CADA bereitzustellen, der es ermöglicht, sie strategisch und langfristig zu planen und umzusetzen.

    Im Hinblick auf die Einhaltung der Haushaltsgrundsätze der Universalität und Einheit ist die Verwendung zweckgebundener Einnahmen dadurch gerechtfertigt, dass diese Initiativen bestimmte und klar definierte politische Ziele unterstützen sollen, d. h. die Entwicklung eines europäischen Cloud-Ökosystems für die gemeinsame Nutzung ungenutzter Kapazitäten durch die Mitgliedstaaten und die gemeinsame Beschaffung von Cloud-Diensten, um Effizienzgewinne und Größenvorteile zu erzielen. Die Einnahmen aus den Gebühren werden zur Finanzierung spezifischer Ausgaben verwendet, die in direktem Zusammenhang mit der Verwirklichung dieser Ziele stehen, wie oben in den jeweiligen Abschnitten über beide Tätigkeiten dargelegt. Durch die Verwendung zweckgebundener Einnahmen kann die Kommission sicherstellen, dass die Mittel zielgerichtet und effizient verwendet werden, ohne sich auf den Gesamtsaldo des Unionshaushalts auszuwirken. Darüber hinaus steht die Verwendung zweckgebundener Einnahmen im Einklang mit dem Grundsatz der Einheit, da sie es der Kommission ermöglichen wird, diese Initiativen kohärent und koordiniert umzusetzen, Doppelarbeit zu vermeiden und sicherzustellen, dass die Mittel zur Unterstützung eines gemeinsamen europäischen Ziels verwendet werden. Die Kommission wird auch dafür sorgen, dass die Verwendung der zweckgebundenen Einnahmen transparent und nachvollziehbar ist, wobei regelmäßig über die Fortschritte und Wirkung der Initiative Bericht erstattet wird und diese bewertet werden.

    Darüber hinaus wird die Kommission der Notwendigkeit Rechnung tragen, mögliche Verzerrungen oder Ungleichheiten bei der Behandlung verschiedener Cloud- Diensteanbieter zu vermeiden, und sicherstellen, dass zweckgebundene Einnahmen fair, verhältnismäßig und diskriminierungsfrei verwendet werden. Die Kommission wird auch die einschlägigen Interessenträger konsultieren, um dafür zu sorgen, dass die Initiative so konzipiert und umgesetzt wird, dass ihren Bedürfnissen und Anliegen Rechnung getragen wird.

    Es sei darauf hingewiesen, dass nur die Betriebskosten der beiden Initiativen, wie oben dargelegt, aus den zweckgebundenen gebührenbasierten Einnahmen finanziert werden. Die Verwaltungskosten werden dagegen nicht durch die zweckgebundenen Einnahmen gedeckt.

    Für den Fall, dass Gebühren nicht in der angenommenen Höhe und dem angenommenen Zeitrahmen eingenommen werden, hat die Kommission einen vorsichtigen Ansatz verfolgt, um die Risiken zu mindern. Im Zusammenhang mit gemeinsamen Vergabeverfahren würde dies bei Nichteinnahme von Gebühren bedeuten, dass kein System eingerichtet und die Initiative keine erheblichen Kosten verursachen würde. Andererseits baut der EuroCloud-Verbund auf bereits vorliegenden Studien und aktuellen Belegen für das Interesse der Mitgliedstaaten an dieser Initiative auf. Darüber hinaus werden die erheblichen Kosten im Zusammenhang mit den Initiative bereits durch den derzeitigen mehrjährigen Finanzrahmen im Rahmen der der Kommission bereits zugewiesenen Haushaltsmittel gedeckt, wodurch dieses finanzielle Risiko insgesamt verringert wird. Insgesamt wird es dieser Ansatz der Kommission ermöglichen, ihre Pläne anzupassen, ohne erhebliche finanzielle Risiken einzugehen, und sie wird flexibler sein, ihre Mittelzuweisung erforderlichenfalls anzupassen, um den Erfolg dieser Initiativen sicherzustellen.

### 4. Digitale Aspekte

#### 4.1. Anforderungen von digitaler Relevanz

    Allgemeine Beschreibung der Anforderungen von digitaler Relevanz und der damit verbundenen Kategorien (Daten, Digitalisierung und Automatisierung von Prozessen, digitale Lösungen und/oder digitale öffentliche Dienste)

| Anforderung | Beschreibung der Anforderung | Von der Anforderung betroffene oder sie betreffende Akteure | Verfahren auf übergeordneter Ebene | Kategorien |
| --- | --- | --- | --- | --- |
| TITEL II FORSCHUNGS-, ENTWICKLUNGS- UND EINFÜHRUNGSTÄTIGKEITEN FÜR DAS CLOUD- UND KI-ÖKOSYSTEM Artikel 7 Nationale Cloud- und KI-Strategien | Die Mitgliedstaaten notifizieren der Kommission ihre nationalen Strategien. | Europäische Kommission Zuständige nationale Behörden | Notifizierung | Daten |
| TITEL III RECHENZENTRUMSKAPAZITÄTEN Artikel 14 Benennung strategischer Rechenzentrumsprojekte | Anträge auf Benennung strategischer Rechenzentrumsprojekte enthalten alle erforderlichen und sachdienlichen Informationen, um nachzuweisen, dass das Projekt die einschlägigen Kriterien erfüllt. | Projektträger Europäische Kommission | Überwachung der Erkenntnisse aus Anträgen | Daten |
| TITEL III RECHENZENTRUMSKAPAZITÄTEN Artikel 15 Überwachung der Kapazitätslücke | Die Kommission überwacht die in der Union verfügbaren Rechenkapazitäten, einschließlich Edge-Computing-Kapazitäten, das Volumen der Nachfrage nach Rechenzentrumskapazitäten, das Ausmaß der Kapazitätslücke. | Europäische Kommission Zuständige nationale Behörden | Datenerhebung | Daten |
| TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Ein Anbieter von Cloud-Computing-Diensten, der anerkennen lassen will, dass er eine Unionsvertrauenswürdigkeitsstufe anbietet, stellt bei der zuständigen nationalen Behörde am Niederlassungsort einen Antrag auf Anerkennung. | Anbieter von Cloud-Computing-Diensten Zuständige nationale Behörden | Aufsichtsmechanismus | Daten |
| TITEL IV AUTONOMIE Artikel 19 Selbstbewertung der Konformität | Der Anbieter von Cloud-Computing-Diensten kann eine Selbstbewertung der Konformität ausstellen, um die Einhaltung der Unionsvertrauenswürdigkeitsstufe 1 nachzuweisen. Diese ist öffentlich zugänglich zu machen. | Anbieter von Cloud-Computing-Diensten Zuständige nationale Behörden Europäische Kommission | Aufsichtsmechanismus | Daten |
| TITEL IV AUTONOMIE Artikel 20 Unabhängige Prüfung | Einführung der Möglichkeit unabhängiger Prüfungen für die Unionsvertrauenswürdigkeitsstufen 2, 3 und 4. Bestimmungen über Datenaspekte im Zusammenhang mit solchen Prüfungen. | Anbieter von Cloud-Computing-Diensten Prüfstellen Europäische Kommission | Aufsichtsmechanismus | Daten |
| TITEL IV AUTONOMIE Artikel 21 Inhalt und Qualität der Prüfbelege | Prüfungen auf der Grundlage der Anhänge II (Kriterien für die Unionsvertrauenswürdigkeitsstufen) und III (Prüfbelege für das Prüfverfahren). Müssen hinreichend vollständig und zuverlässig sein. | Anbieter von Cloud-Computing-Diensten Prüfstellen Europäische Kommission | Datenqualität | Daten |
| TITEL IV AUTONOMIE Artikel 22 Zentralverzeichnis für Cloud-Computing-Dienste | Die Kommission richtet ein spezielles Verzeichnis von Cloud-Computing-Diensten ein, die anhand einer Unionsvertrauenwürdigkeitsstufe anerkannt wurden, und führt dieses. Die verifizierende zuständige nationale Behörde am Niederlassungsort registriert die geprüften Dienste im zentralen Verzeichnis. Jeder Widerruf einer Anerkennung wird im zentralen Verzeichnis veröffentlicht und bleibt fünf Jahre lang öffentlich zugänglich. Das Zentralverzeichnis wird von der Kommission öffentlich zugänglich gemacht und von der Kommission und den zuständigen nationalen Behörden am Niederlassungsort auf einer eigens dafür eingerichteten und leicht zugänglichen Website regelmäßig aktualisiert. | Europäische Kommission Zuständige nationale Behörden | Verzeichnis | Digitale Lösung Daten Digitaler öffentlicher Dienst |
| TITEL IV AUTONOMIE Artikel 23 Transparenzpflichten | Erhält der Diensteanbieter Kenntnis von Informationen oder wesentlichen Änderungen der Umstände in Bezug auf Cloud-Computing-Dienste, die sich auf den Prüfbericht/die Stellungnahme auswirken könnten, so meldet er dies der Prüfstelle und der zuständigen nationalen Behörde am Niederlassungsort unverzüglich. Müssen die Ergebnisse des Prüfberichts und der Stellungnahme geändert oder aufgehoben werden, so teilt die Prüfstelle dies der zuständigen nationalen Behörde und der Kommission unverzüglich mit. Müssen die Ergebnisse der Anerkennung geändert oder aufgehoben werden, so teilt die zuständige nationale Behörde am Niederlassungsort dies den zuständigen nationalen Behörden der anderen Mitgliedstaaten und der Kommission unverzüglich mit. | Anbieter von Cloud-Computing-Diensten Prüfstellen Zuständige nationale Behörden Europäische Kommission | Notifizierung | Daten |
| TITEL IV AUTONOMIE Artikel 24 Sanktionen und Schadenersatz | Die Mitgliedstaaten notifizieren der Kommission so bald wie möglich die Vorschriften für Sanktionen und Schadenersatz sowie alle nachfolgenden Änderungen, die sich darauf auswirken. | Zuständige nationale Behörden Europäische Kommission | Notifizierung | Daten |
| TITEL IV AUTONOMIE Artikel 25 Zuständige nationale Behörden | Jeder Mitgliedstaat benennt eine oder mehrere zuständige nationale Behörden. Die Mitgliedstaaten notifizieren der Kommission die Liste der Behörden. Die Kommission führt ein öffentliches Behördenregister. | Europäische Kommission Zuständige nationale Behörden | Benennung zuständiger Behörden | Daten |
| TITEL IV AUTONOMIE Artikel 27 Amtshilfe | Datenströme im Rahmen der Zusammenarbeit zwischen zuständigen nationalen Behörden. | Zuständige nationale Behörden Europäische Kommission | Datenaustausch | Daten |
| TITEL IV AUTONOMIE Artikel 89 Grenzüberschreitende Zusammenarbeit | Datenströme im Rahmen der grenzüberschreitenden Zusammenarbeit. | Zuständige nationale Behörden Europäische Kommission | Datenaustausch | Daten |
| TITEL IV AUTONOMIE Artikel 29 Risikobewertungen | Die Mitgliedstaaten müssen eine oder mehrere Risikobewertungen durchführen und dabei die von der Kommission herausgegebenen Leitlinien weitestgehend berücksichtigen. Die Mitgliedstaaten teilen der Kommission die Ergebnisse der Risikobewertung mit. Für die Zwecke der Leitlinien ist die Kommission berechtigt, Informationen von Cloud-Diensteanbietern anzufordern. | Mitgliedstaaten Europäische Kommission Cloud-Diensteanbieter | Risikobewertung | Daten |
| TITEL IV AUTONOMIE Artikel 33 Überwachung der innovationsfördernden Auftragsvergabe in den Bereichen Cloud und KI | Die Mitgliedstaaten übermitteln der Kommission jährlich bestimmte Informationen in Bezug auf die Überwachung der Beschaffung innovativer Cloud-Computing-Dienste und KI-Systeme. | Mitgliedstaaten Europäische Kommission | Berichterstattung | Daten |
| TITEL IV AUTONOMIE Artikel 34 Einrichtung des Cloud-Verbunds des europäischen öffentlichen Sektors | Die Kommission richtet eine Plattform für den EuroCloud-Verbund ein. | Europäische Kommission Einrichtungen der Union Öffentliche Stellen | Anforderungen an eine digitale Lösung | Digitaler öffentlicher Dienst Digitale Lösung |
| TITEL IV AUTONOMIE Artikel 37 Auftragsvergabetätigkeiten der Kommission | Die Kommission kann eine Plattform für die gemeinsame Auftragsvergabe einrichten und verwalten, die Dienste umfasst, die zur Erleichterung der Auftragsvergabetätigkeiten im Rahmen dieses Kapitels genutzt werden können. | Europäische Kommission | Anforderungen an eine digitale Lösung | Digitale Lösung |
| TITEL IV AUTONOMIE Artikel 42 Weitergabe und Weiterverwendung von Software | Bei der Bereitstellung von Software, an der sie Rechte des geistigen Eigentums innehaben, zur Weiterverwendung im Rahmen einer quelloffenen Lizenz, macht eine Einrichtung der Union oder eine öffentliche Stelle die Software in einem Katalog oder einem Verzeichnis zur Weiterverwendung verfügbar, der/das mit dem EU-OSS-Katalog verbunden ist. | Einrichtungen der Union Öffentliche Stellen Europäische Kommission | Katalog | Digitale Lösung |
| TITEL IV AUTONOMIE Artikel 43 EU-Katalog quelloffener Lösungen | Die Kommission stellt einen EU-Katalog quelloffener Lösungen als zentralisierten Katalog für den Zugang zu Software, die von Einrichtungen der Union und öffentlichen Stellen zur Weiterverwendung zur Verfügung gestellt wird, bereit und führt diesen. Der EU-OSS-Katalog wird im Portal für ein interoperables Europa veröffentlicht. Die Kommission entscheidet auf Ersuchen von Einrichtungen der Union oder öffentlichen Stellen, die Eigentümer eines Katalogs oder Verzeichnisses sind oder diesen bzw. dieses führen, darüber, diesen Katalog oder dieses Verzeichnis mit dem EU-OSS-Katalog zu verbinden und über diesen zugänglich zu machen. | Europäische Kommission | Katalog | Digitale Lösung |

#### 4.2. Daten

Allgemeine Beschreibung der erfassten Daten

| Art der Daten | Anforderung(en) | Standard bzw. Norm und/oder Spezifikation (falls zutreffend) |
| --- | --- | --- |
| Nationale Strategien der Mitgliedstaaten | TITEL II FORSCHUNGS-, ENTWICKLUNGS- UND EINFÜHRUNGSTÄTIGKEITEN FÜR DAS CLOUD- UND KI-ÖKOSYSTEM Artikel 7 Nationale Cloud- und KI-Strategien | Mindestanforderungen an den Inhalt nationaler Strategien. |
| Daten in Verbindung mit Anträgen auf Anerkennung als strategisches Projekt | TITEL III RECHENZENTRUMSKAPAZITÄTEN Artikel 14 Benennung strategischer Rechenzentrumsprojekte | Vorlage aller erforderlichen und sachdienlichen Informationen, um nachzuweisen, dass das Projekt die einschlägigen Kriterien erfüllt. |
| Statistiken und Daten, die erforderlich sind, um die Kapazitätslücke zu überwachen | TITEL III RECHENZENTRUMSKAPAZITÄTEN Artikel 15 Überwachung der Kapazitätslücke | Entfällt |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Diensteanbieter, die als Anbieter einer Unionsvertrauenswürdigkeitsstufe anerkannt werden wollen | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Entfällt |
| EU-Konformitätserklärung | TITEL IV AUTONOMIE Artikel 19 Selbstbewertung der Konformität | Entfällt |
| Zur Anerkennung vorgelegter Prüfbericht und damit verbundene Austausche | TITEL IV AUTONOMIE Artikel 20 Unabhängige Prüfung Artikel 21 Inhalt und Qualität der Prüfbelege | Datenqualität: hinreichend vollständig und zuverlässig; Mindestanforderungen für Prüfungen. |
| Daten zu Diensten, die eine Anerkennung erhalten | TITEL IV AUTONOMIE Artikel 22 Zentralverzeichnis für Cloud-Computing-Dienste | Das Zentralverzeichnis enthält Informationen über Cloud-Computing-Dienste, die auf einer bestimmten Unionsvertrauenswürdigkeitsstufe anerkannt wurden. |
| Notifizierung der Kenntniserlangung von Informationen oder wesentlichen Änderungen der Umstände in Bezug auf Cloud-Computing-Dienste, die sich auf den Prüfbericht/die Stellungnahme/die Anerkennung und die damit verbundenen Datenströme auswirken können | TITEL IV AUTONOMIE Artikel 23 Transparenzpflichten | Entfällt |
| Notifizierung der Vorschriften und Maßnahmen in Verbindung mit Sanktionen | TITEL IV AUTONOMIE Artikel 24 Sanktionen und Schadenersatz | Entfällt |
| Daten zu den benannten zuständigen nationalen Behörden | TITEL IV AUTONOMIE Artikel 25 Zuständige nationale Behörden | Entfällt |
| Im Rahmen der Zusammenarbeit zwischen zuständigen nationalen Behörden verwendete Daten | TITEL IV AUTONOMIE Artikel 27 Amtshilfe | Entfällt |
| Im Rahmen der grenzüberschreitenden Zusammenarbeit verwendete Daten | TITEL IV AUTONOMIE Artikel 28 Grenzüberschreitende Zusammenarbeit | Entfällt |
| Von den Mitgliedstaaten durchgeführte Risikobewertungen | TITEL IV AUTONOMIE Artikel 29 Risikobewertungen | Entfällt |
| Der Kommission durch Anbieter zur Orientierung bereitgestellte Informationen | TITEL IV AUTONOMIE Artikel 29 Risikobewertungen | Entfällt |
| Daten in Bezug auf die Überwachung der Beschaffung innovativer Cloud- und KI-Systeme | TITEL IV AUTONOMIE Artikel 33 Innovationsfördernde Auftragsvergabe | Entfällt |

    Vereinbarkeit mit der europäischen Datenstrategie

    Erläuterung, inwiefern die Anforderung(en) mit der Europäischen Datenstrategie vereinbar ist/sind.

| Der Vorschlag steht im Einklang mit den Vorschriften über den Anbieterwechsel zwischen Datenverarbeitungsdiensten, die mit der Datenverordnung eingeführt wurden. Durch die Ermöglichung des Anbieterwechsels und die Beseitigung wichtiger Ursachen der Anbieterbindung soll die Datenverordnung sicherstellen, dass Cloud-Diensteanbieter in der EU in Bezug auf Qualität, Innovation und Preise miteinander im Wettbewerb stehen. Sie soll es Cloud-Nutzern ermöglichen, den ihren Bedürfnissen am besten entsprechenden Anbieter frei zu wählen und Angebote verschiedener Anbieter im Rahmen eines Multi-Cloud-Ansatzes miteinander zu kombinieren. Die Datenverordnung enthält jedoch keine Elemente zur Gestaltung eines wettbewerbsfähigeren Angebots an EU-Cloud-Computing-Diensten oder zur Förderung des Markteintritts vielfältigerer Cloud-Diensteanbieter. Die Datenverordnung ebnet zwar den Weg für eine mögliche Verringerung der Abhängigkeiten von außereuropäischen Anbietern, sie eröffnet aber keinen Entwicklungspfad hin zu einem souveräneren und vertrauenswürdigeren EU-Cloud-Computing-Sektor. Die Bestimmungen über den Cloud-Wechsel und die Interoperabilität ermöglichen es den Nutzern jedoch, verstärkt europäische Cloud-Computing-Dienste zu verwenden. Die Datenverordnung ist daher eine Voraussetzung für den Vorschlag. |
| --- |

    Vereinbarkeit mit dem Grundsatz der einmaligen Erfassung

    Erläuterung, inwiefern der Grundsatz der einmaligen Erfassung berücksichtigt und inwiefern die Möglichkeit der Weiterverwendung vorhandener Daten geprüft wurde

| Der Grundsatz der einmaligen Erfassung wurde gebührend berücksichtigt und wird systematisch durchgesetzt, wo immer dies relevant ist. Dies gilt insbesondere für a)die Statistiken und Daten, die erforderlich sind, um die Kapazitätslücke zu überwachen, b)die Daten zu Diensten, die eine Anerkennung erhalten, c)die der Kommission für die Marktanalyse bereitgestellten Informationen. |
| --- |

    Erläuterung, inwiefern neu geschaffene Daten auffindbar, zugänglich, interoperabel und weiterverwendbar sind und hohen Standards entsprechen.

| Es werden digitale Lösungen bereitgestellt, um die Auffindbarkeit, Zugänglichkeit, Interoperabilität und Wiederverwendbarkeit neu erzeugter Daten zu gewährleisten. Mindestanforderungen an den Inhalt werden hohe Datenqualitätsstandards fördern. |
| --- |

    Datenströme

| Art der Daten | Anforderung(en) | Akteure, die die Daten bereitstellen | Akteure, die die Daten empfangen | Auslöser für den Datenaustausch | Häufigkeit (falls zutreffend) |
| --- | --- | --- | --- | --- | --- |
| Nationale Strategien der Mitgliedstaaten | TITEL II FORSCHUNGS-, ENTWICKLUNGS- UND EINFÜHRUNGSTÄTIGKEITEN FÜR DAS CLOUD- UND KI-ÖKOSYSTEM Artikel 7 Nationale Cloud- und KI-Strategien | Mitgliedstaaten | Europäische Kommission | Innerhalb von drei Monaten nach Annahme einer nationalen Strategie | Je Annahme/Überarbeitung |
| Daten in Verbindung mit Anträgen auf Anerkennung als strategisches Projekt | TITEL III RECHENZENTRUMSKAPAZITÄTEN Artikel 14 Benennung strategischer Rechenzentrumsprojekte | Antragsteller für die Benennung eines strategischen Projekts | Europäische Kommission | Beantragung bei offenen Aufforderungen zur Interessenbekundung | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Antragstellender Anbieter von Cloud-Computing-Diensten | Zuständige nationale Behörde am Niederlassungsort | Antrag auf Bereitstellung von Diensten für Einrichtungen der Union und öffentliche Stellen | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Ergebnis des Antrags (Ablehnung, Anforderung zusätzlicher Belege, Anerkennung des Dienstes des Anbieters) | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Zuständige nationale Behörde | Antragstellender Anbieter von Cloud-Computing-Diensten | Schlussfolgerungen bei der Erstanerkennung | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Verbreitung der Schlussfolgerungen zur Überprüfung | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Zuständige nationale Behörde | Alle zuständigen nationalen Behörden | Anbieter von Cloud-Computing-Diensten, dem eine Anerkennung mitgeteilt wurde | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Einsprüche | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Alle zuständigen nationalen Behörden | Zuständige nationale Behörde | Die zuständige nationale Behörde hat Einsprüche gegen die Schlussfolgerung einer zuständigen nationalen Behörde am Niederlassungsort | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Der Kommission übertragene Fälle | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Zuständige nationale Behörden | Europäische Kommission | Zuständige nationale Behörden konnten keine Einigung erzielen | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Entscheidung der Kommission im übertragenen Fall | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Europäische Kommission | Zuständige nationale Behörden | Kommission kommt zu einer Entscheidung in einem Fall, in dem sich die zuständigen nationalen Behörden uneinig waren | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Auskunftsersuchen | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Zuständige nationale Behörden | Europäische Kommission | Zuständige nationale Behörden beschließen, von ihrem Recht auf ein Auskunftsersuchen Gebrauch zu machen | // |
| Daten im Zusammenhang mit der Einreichung von Anträgen durch Cloud-Computing-Dienste, die Dienstleistungen für Einrichtungen der Union und öffentliche Stellen erbringen wollen: Antwort auf ein Auskunftsersuchen | TITEL IV AUTONOMIE Artikel 17 Anerkennung von Anbietern von Cloud-Computing-Diensten | Europäische Kommission | Zuständige nationale Behörden | Auskunftsersuchen von zuständigen nationalen Behörden eingegangen | // |
| EU-Konformitätserklärung | TITEL IV AUTONOMIE Artikel 19 Selbstbewertung der Konformität | Anbieter von Cloud-Computing-Diensten | Öffentlichkeit | Selbstbewertung angewandt | // |
| Zur Anerkennung vorgelegter Prüfbericht und damit verbundene Austausche: Für die Prüfung erforderliche Informationen | TITEL IV AUTONOMIE Artikel 20 Unabhängige Prüfung Artikel 21 Inhalt und Qualität der Prüfbelege | Anbieter von Cloud-Computing-Diensten | Prüfstelle | Prüfung wird durchgeführt | // |
| Zur Anerkennung vorgelegter Prüfbericht und damit verbundene Austausche: Prüfberichte | TITEL IV AUTONOMIE Artikel 20 Unabhängige Prüfung Artikel 21 Inhalt und Qualität der Prüfbelege | Anbieter von Cloud-Computing-Diensten | Prüfstelle und zuständige nationale Behörden | Prüfung abgeschlossen | // |
| Daten zu Diensten, die eine Anerkennung erhalten: Zentralverzeichnis für Cloud-Computing-Dienste | TITEL IV AUTONOMIE Artikel 22 Zentralverzeichnis für Cloud-Computing-Dienste | Verifizierende zuständige nationale Behörde | Zentralverzeichnis für Cloud-Computing-Dienste (Europäische Kommission) | Anerkennung gewährt | // |
| Daten zu Diensten, die eine Anerkennung erhalten: Öffentlich zugängliche, von der Europäischen Kommission betriebene Website | TITEL IV AUTONOMIE Artikel 22 Zentralverzeichnis für Cloud-Computing-Dienste | Europäische Kommission Zuständige nationale Behörde am Niederlassungsort | Öffentlichkeit | Anerkennung gewährt | // |
| Notifizierung der Kenntniserlangung von Informationen oder wesentlichen Änderungen der Umstände in Bezug auf Cloud-Computing-Dienste, die sich auf den Prüfbericht/die Stellungnahme und die damit verbundenen Datenströme auswirken können: Erstnotifizierung | TITEL IV AUTONOMIE Artikel 23 Transparenzpflichten | Anbieter von Cloud-Computing-Diensten | Prüfstelle und zuständige nationale Behörden Europäische Kommission | Änderung wesentlicher Bedingungen aufseiten des Anbieters | // |
| Notifizierung der Kenntniserlangung von Informationen oder wesentlichen Änderungen der Umstände in Bezug auf Cloud-Computing-Dienste, die sich auf den Prüfbericht/die Stellungnahme und die damit verbundenen Datenströme auswirken können: Notifizierung eines veränderten Prüfergebnisses | TITEL IV AUTONOMIE Artikel 23 Transparenzpflichten | Prüfstelle | Zuständige nationale Behörden (am Niederlassungsort und anderer Mitgliedstaaten) Europäische Kommission | Veränderung des Prüfergebnisses | // |
| Notifizierung der Vorschriften und Maßnahmen in Verbindung mit Sanktionen | TITEL IV AUTONOMIE Artikel 24 Sanktionen und Schadenersatz | Mitgliedstaaten | Europäische Kommission | Mitgliedstaaten legen den Rahmen für die Auferlegung von Sanktionen fest/ändern diesen | // |
| Daten zu den benannten zuständigen nationalen Behörden Notifizierung durch die Mitgliedstaaten | TITEL IV AUTONOMIE Artikel 25 Zuständige nationale Behörden | Mitgliedstaaten | Europäische Kommission | Benannte zuständige nationale Behörden (innerhalb eines Jahres nach Inkrafttreten) | // |
| Daten zu den benannten zuständigen nationalen Behörden Daten im öffentlichen Behördenregister | TITEL IV AUTONOMIE Artikel 25 Zuständige nationale Behörden | Europäische Kommission | Öffentlichkeit | Benennung der zuständigen nationalen Behörden und Notifizierung der Kommission | // |
| Im Rahmen der Zusammenarbeit zwischen zuständigen nationalen Behörden verwendete Daten Informationsaustausch | TITEL IV AUTONOMIE Artikel 27 Amtshilfe | Zuständige nationale Behörden | Zuständige nationale Behörden | Zusammenarbeit (Informationsaustausch) zwischen zuständigen nationalen Behörden erforderlich | // |
| Im Rahmen der Zusammenarbeit zwischen zuständigen nationalen Behörden verwendete Daten Amtshilfeersuchen (und Antworten darauf) | TITEL IV AUTONOMIE Artikel 27 Amtshilfe | Zuständige nationale Behörden | Zuständige nationale Behörden | Amtshilfe wird als erforderlich erachtet | // |
| Im Rahmen der grenzüberschreitenden Zusammenarbeit verwendete Daten Ersuchen um Bewertung – Verdacht auf Nichtkonformität | TITEL IV AUTONOMIE Artikel 28 Grenzüberschreitende Zusammenarbeit | Zuständige nationale Behörden am Bestimmungsort des Dienstes | Zuständige nationale Behörden am Ausgangsort des Dienstes | Verdacht auf Nichtkonformität, der ein Amtshilfeersuchen nach sich zieht | // |
| Im Rahmen der grenzüberschreitenden Zusammenarbeit verwendete Daten Kommission über Verdacht auf Nichtkonformität unterrichtet | TITEL IV AUTONOMIE Artikel 28 Grenzüberschreitende Zusammenarbeit | Zuständige nationale Behörden am Bestimmungsort des Dienstes | Europäische Kommission | Eine zuständige Behörde beschließt, die zuständige Behörde am Niederlassungsort um Informationen zu ersuchen, um den Verdacht auf Nichtkonformität zu bewerten. | // |
| Im Rahmen der grenzüberschreitenden Zusammenarbeit verwendete Daten Ersuchen um Bewertung – Verdacht auf Nichtkonformität (Kommission) | TITEL IV AUTONOMIE Artikel 28 Grenzüberschreitende Zusammenarbeit | Zuständige nationale Behörden am Ausgangsort des Dienstes | Europäische Kommission Zuständige nationale Behörden | Verdacht auf Nichtkonformität vonseiten anderer zuständiger Behörden oder der Kommission | // |
| Im Rahmen der grenzüberschreitenden Zusammenarbeit verwendete Daten Ergebnis eines Ersuchens um Bewertung – Verdacht auf Nichtkonformität | TITEL IV AUTONOMIE Artikel 28 Grenzüberschreitende Zusammenarbeit | Zuständige Behörden am Ausgangsort | Ersuchende Europäische Kommission | Innerhalb von zwei Monaten nach Stellung eines Ersuchens | // |
| Von den Mitgliedstaaten durchgeführte Risikobewertungen | TITEL IV AUTONOMIE Artikel 29 Risikobewertungen | Mitgliedstaaten | Europäische Kommission | Risikobewertung erfolgt innerhalb eines Jahres nach Inkrafttreten | Zweimal jährlich |
| Der Kommission zur Orientierung bereitgestellte Informationen | TITEL IV AUTONOMIE Artikel 29 Risikobewertungen | Cloud-Diensteanbieter | Europäische Kommission | // | // |
| Daten in Bezug auf die Überwachung der Beschaffung innovativer Cloud- und KI-Systeme | TITEL IV AUTONOMIE Artikel 33 Überwachung der innovationsfördernden Auftragsvergabe in den Bereichen Cloud und KI | Mitgliedstaaten | Europäische Kommission | // | Jährlich |

#### 4.3. Digitale Lösungen

    Verzeichnis für anerkannte Cloud-Computing-Dienste

| Digitale und/oder sektorspezifische Strategien (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Nicht anwendbar |
| EU-Rahmen für Cybersicherheit | Das Verzeichnis wird sich an bewährten Verfahren der Kommission im Bereich der Cybersicherheit orientieren. |
| eIDAS-Verordnung | Das Verzeichnis wird, soweit relevant, den eIDAS-Rahmen weiterverwenden. |
| Einheitliches digitales Zugangstor und IMI | Nicht anwendbar |
| Sonstige (z. B. Verordnung für ein interoperables Europa) | Die Notwendigkeit einer weiteren Interoperabilitätsbewertung im Rahmen der Verordnung für ein interoperables Europa (Verordnung (EU) 2024/903) wird bewertet, sobald die operativen Einzelheiten für das Verzeichnis anerkannter Cloud-Computing-Dienste verfügbar sind. |

    EuroCloud-Plattform

| Digitale und/oder sektorspezifische Strategien (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Nicht anwendbar |
| EU-Rahmen für Cybersicherheit | Die Plattform sollte Mechanismen für einen sicheren Zugang und eine sichere Behandlung von Sicherheitsvorfällen umfassen, wie z. B. ein gemeinsames Identitätsmanagement, Instrumente für die gegenseitige Authentifizierung und Instrumente für die Meldung von Sicherheitsvorfällen. Die Plattform wird sich an bewährten Verfahren der Kommission im Bereich der Cybersicherheit orientieren. |
| eIDAS-Verordnung | Dies wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. |
| Einheitliches digitales Zugangstor und IMI | Nicht anwendbar |
| Sonstige (z. B. Verordnung für ein interoperables Europa) | Die Notwendigkeit einer weiteren Interoperabilitätsbewertung im Rahmen der Verordnung für ein interoperables Europa (Verordnung (EU) 2024/903) wird bewertet, sobald die operativen Einzelheiten für die EuroCloud-Plattform verfügbar sind. |

    Plattform für die gemeinsame Auftragsvergabe

| Digitale und/oder sektorspezifische Strategien (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Nicht anwendbar |
| EU-Rahmen für Cybersicherheit | Die Plattform wird sich an bewährten Verfahren der Kommission im Bereich der Cybersicherheit orientieren. |
| eIDAS-Verordnung | Dies wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. |
| Einheitliches digitales Zugangstor und IMI | Nicht anwendbar |
| Sonstige (z. B. Verordnung für ein interoperables Europa) | Nicht anwendbar |

    Katalog oder Verzeichnis weiterverwendbarer Software, der/das mit dem EU-OSS-Katalog verbunden ist

| Digitale und/oder sektorspezifische Strategien (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Nicht anwendbar |
| EU-Rahmen für Cybersicherheit | Die Plattform wird sich an bewährten Verfahren der Kommission im Bereich der Cybersicherheit orientieren. |
| eIDAS-Verordnung | Das Verzeichnis wird, soweit relevant, den eIDAS-Rahmen weiterverwenden. |
| Einheitliches digitales Zugangstor und IMI | Nicht anwendbar |
| Sonstige (z. B. Verordnung für ein interoperables Europa) | Nicht anwendbar |

    EU-Katalog quelloffener Lösungen

| Digitale und/oder sektorspezifische Strategien (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Nicht anwendbar |
| EU-Rahmen für Cybersicherheit | Die Plattform wird sich an bewährten Verfahren der Kommission im Bereich der Cybersicherheit orientieren. |
| eIDAS-Verordnung | Der Katalog wird, soweit relevant, den eIDAS-Rahmen weiterverwenden. |
| Einheitliches digitales Zugangstor und IMI | Nicht anwendbar |
| Sonstige (z. B. Verordnung für ein interoperables Europa) | Artikel 4 der Verordnung für ein interoperables Europa (Verordnung (EU) 2024/903) schreibt die Weitergabe und Weiterverwendung von Interoperabilitätslösungen zwischen Einrichtungen der Union und öffentlichen Stellen vor. Der EU-Katalog quelloffener Lösungen entspricht dieser Anforderung. |

#### 4.4. Interoperabilitätsbewertung

| Digitaler öffentlicher Dienst oder Kategorie digitaler öffentlicher Dienste | Beschreibung | Anforderung(en) | Lösung(en) für ein interoperables Europa | Andere Interoperabilitätslösung(en) |
| --- | --- | --- | --- | --- |
| Unionsverzeichnis anerkanntes souveräner Dienste | Ein spezielles Unionsverzeichnis für anerkannte Cloud-Computing-Dienste. Von der Kommission einzurichten und zu führen Zuständige nationale Behörden registrieren die einschlägigen Dienste in diesem Verzeichnis. | TITEL IV AUTONOMIE Artikel 22 Zentralverzeichnis für Cloud-Computing-Dienste | // | Nicht zutreffend |
| EuroCloud-Verbund | Mit Artikel 34 wird der Cloud-Verbund des europäischen öffentlichen Sektors (EuroCloud-Verbund) eingerichtet. Der EuroCloud-Verbund sollte nationale Cloud-Initiativen zusammenführen, die hochgradig vertrauenswürdige und sichere Cloud-Kapazitäten für den öffentlichen Sektors bieten, und die gemeinsame Nutzung solcher Kapazitäten zwischen Einrichtungen der Union und öffentlichen Stellen erleichtern. Dies sollte über eine Plattform erfolgen, die allen Mitgliedern des Verbunds zugänglich ist – die EuroCloud-Plattform. | TITEL IV AUTONOMIE Artikel 34 Einrichtung des Cloud-Verbunds des europäischen öffentlichen Sektors | Nicht zutreffend | Nicht zutreffend |

Auswirkungen der Anforderung(en) auf die grenzübergreifende Interoperabilität nach digitalem öffentlichen Dienst

Unionsverzeichnis anerkanntes souveräner Dienste

| Bewertung | Maßnahme(n) | Mögliche verbleibende Hindernisse (falls zutreffend) |
| --- | --- | --- |
| Vereinbarkeit mit bestehenden digitalen und sektorspezifischen Strategien Bitte führen Sie die ermittelten anwendbaren digitalen und sektorspezifischen Strategien auf. | Bei der Umsetzung des Unionsverzeichnisses anerkannter souveräner Dienste werden die bestehenden Strategien und die sich daraus ergebenden Bausteine weitestgehend berücksichtigt. |  |
| Organisatorische Maßnahmen für eine reibungslose grenzüberschreitende Erbringung digitaler öffentlicher Dienste Bitte führen Sie die geplanten Governance-Maßnahmen auf. | Die Europäische Kommission erhält die Aufgabe, das Verzeichnis einzurichten und zu führen. Die verifizierende nationale Behörde ist für das Hochladen der einschlägigen Daten in das Verzeichnis zuständig. | Die organisatorischen Maßnahmen wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. |
| Maßnahmen, die ergriffen wurden, um ein gemeinsames Verständnis der Daten zu gewährleisten Bitte führen Sie solche Maßnahmen auf. | Semantische Maßnahmen wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. |  |
| Verwendung gemeinsam vereinbarter offener technischer Spezifikationen und Standards Bitte führen Sie solche Maßnahmen auf. | Technische Maßnahmen wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. |  |

EuroCloud-Verbund

| Bewertung | Maßnahme(n) | Mögliche verbleibende Hindernisse (falls zutreffend) |
| --- | --- | --- |
| Vereinbarkeit mit bestehenden digitalen und sektorspezifischen Strategien Bitte führen Sie die ermittelten anwendbaren digitalen und sektorspezifischen Strategien auf. | Bei der Umsetzung des EuroCloud-Verbunds werden die bestehenden Strategien und die sich daraus ergebenden Bausteine weitestgehend berücksichtigt. Insbesondere NIS-2 für Cybersicherheit, Simpl, Datenräume. | Nicht zutreffend |
| Organisatorische Maßnahmen für eine reibungslose grenzüberschreitende Erbringung digitaler öffentlicher Dienste Bitte führen Sie die geplanten Governance-Maßnahmen auf. | Die genaue Governance der EuroCloud-Plattform wird durch sekundärrechtliche Vorschriften geregelt. | Nicht zutreffend |
| Maßnahmen, die ergriffen wurden, um ein gemeinsames Verständnis der Daten zu gewährleisten Bitte führen Sie solche Maßnahmen auf. | Semantische Maßnahmen wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. | Nicht zutreffend |
| Verwendung gemeinsam vereinbarter offener technischer Spezifikationen und Standards Bitte führen Sie solche Maßnahmen auf. | Technische Maßnahmen wird die Kommission zu einem späteren Zeitpunkt genauer ausführen. | Nicht zutreffend |

#### 4.5. Unterstützungsmaßnahmen für die digitale Umsetzung

| Beschreibung der Maßnahme | Anforderung(en) | Rolle der Kommission | Zu beteiligende Akteure | Voraussichtlicher Zeitplan |
| --- | --- | --- | --- | --- |
| Der Kommission wird die Befugnis übertragen, Durchführungsrechtsakte zu erlassen, in denen i) die technischen, operativen und organisatorischen Maßnahmen und ii) das Verfahren für die Beteiligung am EuroCloud-Verbund gemäß Artikel 40 Absatz 2 festgelegt werden. | Artikel 40, Artikel 41 | Ausarbeitung eines oder mehrerer Durchführungsrechtsakte | Europäische Kommission Teilnehmende Mitgliedstaaten | Noch festzulegen |

^(1) ABl. C , , S. .

^(2) ABl. C , , S. .

^(3) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen, Aktionsplan für den KI-Kontinent, 9.4.2025, COM(2025) 165 final .

^(4) Mitteilung der Kommission an das Europäische Parlament und den Rat, Strategie „KI anwenden“, 8.10.2025, COM(2025) 723 final .

^(5) Verordnung (EU) 2023/2854 des Rates und des Europäischen Parlaments vom 13. Dezember 2023 über harmonisierte Vorschriften für einen fairen Datenzugang und eine faire Datennutzung sowie zur Änderung der Verordnung (EU) 2017/2394 und der Richtlinie (EU) 2020/1828 (Datenverordnung) (ABl. L, 2023/2854, 22.12.2023, ELI: http://data.europa.eu/eli/reg/2023/2854/oj ).

^(6) Mitteilung der Kommission an das Europäische Parlament und den Rat, Strategie für eine Datenunion, 19.11.2025, COM(2025) 835 final .

^(7) Wie definiert in Titel I Artikel 2 des Anhangs der Empfehlung 2003/361/EG der Kommission vom 6. Mai 2003 betreffend die Definition der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen (ABl. L 124 vom 20.5.2003, S. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj ).

^(8) Wie definiert in Nummer 2 des Anhangs der Empfehlung (EU) 2025/1099 der Kommission vom 21. Mai 2025 zur Definition kleiner Midcap-Unternehmen (ABl. L, 2025/1099, 28.5.2025, ELI: http://data.europa.eu/eli/reco/2025/1099/oj ).

^(9) Die Zukunft der europäischen Wettbewerbsfähigkeit. Teil A, Eine Wettbewerbsstrategie für Europa (im Folgenden „Draghi-Bericht“), September 2024, https://data.europa.eu/doi/10.2872/9356120 .

^(10) Gemeinsame Mitteilung der Kommission an das Europäische Parlament und den Rat, Stärkung der wirtschaftlichen Sicherheit der EU, JOIN(2025) 977 final .

^(11) Schlussfolgerungen des Rates zur Wettbewerbsfähigkeit Europas in der digitalen Dekade, 5.12.2025, https://data.consilium.europa.eu/doc/document/ST-16430-2025-INIT/de/pdf .

^(12) Richtlinie (EU) 2022/2555 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über Maßnahmen für ein hohes gemeinsames Cybersicherheitsniveau in der Union, zur Änderung der Verordnung (EU) Nr. 910/2014 und der Richtlinie (EU) 2018/1972 sowie zur Aufhebung der Richtlinie (EU) 2016/1148 (NIS‑2-Richtlinie) (ABl. L 333 vom 27.12.2022, S. 80, ELI: http://data.europa.eu/eli/dir/2022/2555/oj ).

^(13) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj ).

^(14) Verweise auf die Chip-Verordnung 2.0 sind nach deren Erlass einzufügen. Siehe Kommissionsvorschlag [Verweis nach dessen Veröffentlichung einzufügen].

^(15) Verordnung (EU) 2021/696 des Europäischen Parlaments und des Rates vom 28. April 2021 zur Einrichtung des Weltraumprogramms der Union und der Agentur der Europäischen Union für das Weltraumprogramm und zur Aufhebung der Verordnungen (EU) Nr. 912/2010, (EU) Nr. 1285/2013 und (EU) Nr. 377/2014 sowie des Beschlusses Nr. 541/2014/EU (ABl. L 170 vom 12.5.2021, S. 69, ELI: http://data.europa.eu/eli/reg/2021/696/oj ).

^(16) Beschluss (EU) 2022/2481 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über die Aufstellung des Politikprogramms 2030 für die digitale Dekade (ABl. L 323 vom 19.12.2022, S. 4, ELI: http://data.europa.eu/eli/dec/2022/2481/oj ).

^(17) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen, Die Union der Kompetenzen, 5.3.2025, COM(2025) 90 final .

^(18) Verordnung (EU) 2021/2085 des Rates vom 19. November 2021 zur Gründung der gemeinsamen Unternehmen im Rahmen von „Horizont Europa“ und zur Aufhebung der Verordnungen (EG) Nr. 219/2007, (EU) Nr. 557/2014, (EU) Nr. 558/2014, (EU) Nr. 559/2014, (EU) Nr. 560/2014, (EU) Nr. 561/2014 und (EU) Nr. 642/2014 (ABl. L 427 vom 30.11.2021, S. 17, ELI: http://data.europa.eu/eli/reg/2021/2085/oj ).

^(19) Verordnung (EU) 2021/1173 des Rates vom 13. Juli 2021 zur Gründung des Gemeinsamen Unternehmens für europäisches Hochleistungsrechnen und zur Aufhebung der Verordnung (EU) 2018/1488 (ABl. L 256 vom 19.7.2021, S. 3, ELI: http://data.europa.eu/eli/reg/2021/1173/oj ).

^(20) Verordnung (EU) 2021/694 des Europäischen Parlaments und des Rates vom 29. April 2021 zur Aufstellung des Programms „Digitales Europa“ und zur Aufhebung des Beschlusses (EU) 2015/2240 (ABl. L 166 vom 11.5.2021, S. 1, ELI: http://data.europa.eu/eli/reg/2021/694/oj ).

^(21) Verordnung (EU) 2021/695 des Europäischen Parlaments und des Rates vom 28. April 2021 zur Einrichtung von „Horizont Europa“, dem Rahmenprogramm für Forschung und Innovation, sowie über dessen Regeln für die Beteiligung und die Verbreitung der Ergebnisse und zur Aufhebung der Verordnungen (EU) Nr. 1290/2013 und (EU) Nr. 1291/2013 (ABl. L 170 vom 12.5.2021, S. 1, ELI: http://data.europa.eu/eli/reg/2021/695/oj ).

^(22) Verordnung (EU) 2021/523 des Europäischen Parlaments und des Rates vom 24. März 2021 zur Einrichtung des Programms „InvestEU“ und zur Änderung der Verordnung (EU) 2015/1017 (ABl. L 107 vom 26.3.2021, S. 30, ELI: http://data.europa.eu/eli/reg/2021/523/oj ).

^(23) Beschluss (EU) 2022/2481 des Europäischen Parlaments und des Rates vom 14. Dezember 2022 über die Aufstellung des Politikprogramms 2030 für die digitale Dekade (ABl. L 323 vom 19.12.2022, S. 4, ELI: http://data.europa.eu/eli/dec/2022/2481/oj ).

^(24) Delegierte Verordnung (EU) 2024/1364 der Kommission vom 14. März 2024 über die erste Phase der Einrichtung eines gemeinsamen Bewertungssystems der Union für Rechenzentren (ABl. L, 2024/1364, 17.5.2024, ELI: http://data.europa.eu/eli/reg_del/2024/1364/oj ).

^(25) Richtlinie (EU) 2023/1791 des Europäischen Parlaments und des Rates vom 13. September 2023 zur Energieeffizienz und zur Änderung der Verordnung (EU) 2023/955 (Neufassung) (ABl. L 231 vom 20.9.2023, S. 1, ELI: http://data.europa.eu/eli/dir/2023/1791/oj ).

^(26) Verordnung (EU) 2024/1309 des Europäischen Parlaments und des Rates vom 29. April 2024 über Maßnahmen zur Reduzierung der Kosten des Aufbaus von Gigabit-Netzen für die elektronische Kommunikation, zur Änderung der Verordnung (EU) 2015/2120 und zur Aufhebung der Richtlinie 2014/61/EU (Gigabit-Infrastrukturverordnung) (ABl. L, 2024/1309, 8.5.2024, ELI: http://data.europa.eu/eli/reg/2024/1309/oj ).

^(27) Verweis auf die Verordnung zur Beschleunigung von Umweltprüfungen einfügen, sobald diese erlassen worden ist. Siehe Kommissionsvorschlag COM(2025) 984 final, https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52025PC0984 .

^(28) Verweis auf die Verordnung zur Einrichtung des Europäischen Fonds für Wettbewerbsfähigkeit einfügen, sobald diese erlassen worden ist. Siehe Kommissionsvorschlag COM(2025) 555 final/2, https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52025PC0555R(01) .

^(29) Verordnung (EU, Euratom) 2024/2509 des Europäischen Parlaments und des Rates vom 23. September 2024 über die Haushaltsordnung für den Gesamthaushaltsplan der Union (Neufassung) (ABl. L, 2024/2509, 26.9.2024, ELI: http://data.europa.eu/eli/reg/2024/2509/oj ).

^(30) Gemeinsame Erklärung der Mitgliedstaaten zum Aufbau der nächsten Cloud-Generation in Europa für Unternehmen und den öffentlichen Sektor, 15.10.2020, https://digital-strategy.ec.europa.eu/en/news/towards-next-generation-cloud-europe .

^(31) Berliner Erklärung zur digitalen Gesellschaft und wertebasierten digitalen Verwaltung, 8.12.2020, https://digital-strategy.ec.europa.eu/en/news/berlin-declaration-digital-society-and-value-based-digital-government .

^(32) Schlussfolgerungen des Rates zur Zukunft der Digitalpolitik der EU, 21.5.2024, https://data.consilium.europa.eu/doc/document/ST-9957-2024-INIT/de/pdf .

^(33) Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates vom 23. Oktober 2024 über horizontale Cybersicherheitsanforderungen für Produkte mit digitalen Elementen und zur Änderung der Verordnungen (EU) Nr. 168/2013 und (EU) 2019/1020 und der Richtlinie (EU) 2020/1828 (Cyberresilienz-Verordnung) (ABl. L, 2024/2847, 20.11.2024, ELI: http://data.europa.eu/eli/reg/2024/2847/oj ).

^(34) Richtlinie 2014/24/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 über die öffentliche Auftragsvergabe und zur Aufhebung der Richtlinie 2004/18/EG (ABl. L 94 vom 28.3.2014, S. 65, ELI: http://data.europa.eu/eli/dir/2014/24/oj ).

^(35) Verordnung (EU) 2024/903 des Europäischen Parlaments und des Rates vom 13. März 2024 über Maßnahmen für ein hohes Maß an Interoperabilität des öffentlichen Sektors in der Union (Verordnung für ein interoperables Europa) (ABl. L, 2024/903, 22.3.2024, ELI: http://data.europa.eu/eli/reg/2024/903/oj ).

^(36) Interinstitutionelle Vereinbarung zwischen dem Europäischen Parlament, dem Rat der Europäischen Union und der Europäischen Kommission über bessere Rechtsetzung (ABl. L 123 vom 12.5.2016, S. 1, ELI: http://data.europa.eu/eli/agree_interinstit/2016/512/oj ).

^(37) Verordnung (EU) Nr. 182/2011 des Europäischen Parlaments und des Rates vom 16. Februar 2011 zur Festlegung der allgemeinen Regeln und Grundsätze, nach denen die Mitgliedstaaten die Wahrnehmung der Durchführungsbefugnisse durch die Kommission kontrollieren (ABl. L 55 vom 28.2.2011, S. 13, ELI: http://data.europa.eu/eli/reg/2011/182/oj ).

^(38) Verordnung (EU) 2018/1725 des Europäischen Parlaments und des Rates vom 23. Oktober 2018 zum Schutz natürlicher Personen bei der Verarbeitung personenbezogener Daten durch die Organe, Einrichtungen und sonstigen Stellen der Union, zum freien Datenverkehr und zur Aufhebung der Verordnung (EG) Nr. 45/2001 und des Beschlusses Nr. 1247/2002/EG (ABl. L 295 vom 21.11.2018, S. 39, ELI: http://data.europa.eu/eli/reg/2018/1725/oj ).

^(39) Im Sinne des Artikels 58 Absatz 2 Buchstabe a oder b der Haushaltsordnung.

^(40) GM = Getrennte Mittel/NGM = Nichtgetrennte Mittel.

^(41) EFTA: Europäische Freihandelsassoziation.

^(42) Kandidatenländer und gegebenenfalls potenzielle Kandidaten des Westbalkans.

^(43) Die Haushaltslinien für den neuen MFR sind noch nicht bekannt.

^(44) Outputs sind Produkte, die geliefert, und Dienstleistungen, die erbracht werden (z. B. Zahl der Austauschstudenten, gebaute Straßenkilometer usw.).

^(45) Wie in Abschnitt 1.3.2 „Einzelziel(e)“

^(46) Bei den traditionellen Eigenmitteln (Zölle, Zuckerabgaben) sind die Beträge netto, d. h. abzüglich 20 % für Erhebungskosten, anzugeben.

<a id="annex-i"></a>
## Anhang I

Große Herausforderungen

####  1. Große Herausforderung 1: Ökologische Nachhaltigkeit, Leistung und Sicherheit der Rechenzentren der Union

Unionsweite Tests und Einführung von Technologien für Rechenzentren, die neue Maßstäbe bei der Energie- und Ressourceneffizienz setzen sollen.

Dazu zählt, eine niedrigere Kennzahl zur eingesetzten Energie (PUE) zu erreichen und eine deutlich höhere Serverauslastung zu ermöglichen. Beispiele hierfür sind:

- (1) Senkung der durchschnittlichen Kennzahl zur eingesetzten Energie: Verbesserung der ökologischen Nachhaltigkeit und Umweltleistung der Cloud- und Edge-Rechenzentren der Union durch die Senkung der durchschnittlichen Kennzahl zur eingesetzten Energie (PUE) auf 1,15 in der gesamten Union. Im Vordergrund steht dabei die Ermöglichung folgender Entwicklungen:

  - (a) fortgeschrittene Energieeffizienztechnologien für Rechenzentren beispielsweise in den Bereichen Kühlung und Abwärmerückgewinnung;

  - (b) Quanteninformatiktechnologien für den Betrieb von Cloud- und Recheninfrastrukturen;

  - (c) Netzintegration und fortgeschrittene Energiemanagementsysteme;

  - (d) Pilotanlagen zur Validierung energieeffizienter Technologien der nächsten Generation unter Betriebsbedingungen.

- (2) Erhöhung der durchschnittlichen Serverauslastung von Rechenzentren: Erhöhung der durchschnittlichen Serverauslastung in den Rechenzentren der Union auf rund 50 %, z. B. durch Integration KI-gestützter Technologien für die dynamische Steuerung der Serverauslastung, die Steuerung und Planung der Arbeitslasten im laufenden Betrieb oder das Ausgleichen der Auslastung, der Energiekosten, der thermischen Randbedingungen und der Latenzanforderungen.

- (3) Verbesserung der Sicherheit und Resilienz von Rechenzentren: Verbesserung der Sicherheit und Resilienz der Wertschöpfungskette der Rechenzentren und ihrer Versorgung durch die Integration von in der Union entworfener und hergestellter Halbleitertechnik und Quantentechnik sowie durch die Verbesserung ihrer Widerstandsfähigkeit gegenüber physischen Bedrohungen und Cybersicherheitsbedrohungen, einschließlich gezielter Angriffe.

####  2. Große Herausforderung 2: Cloud-Stacks

Aufbau durchgängiger Hardware- und Software-Cloud-Stacks, einschließlich KI-Werkzeugen, Infrastrukturen, Diensten und Verwaltungsebenen, um die kritischen Kapazitätslücken der Union zu schließen.

Dazu gehört der Aufbau von KI-Servern, die mit in der Union entworfener und hergestellter Halbleitertechnik und Quantentechnik betrieben werden, für verteilte und dezentrale Cloud- und Edge-Computing-Infrastrukturen für KI.

Pilotprogramme könnten dazu beitragen, die Fähigkeiten der europäischen offenen Cloud-Stacks in strategisch wichtigen Sektoren zu demonstrieren.

####  3. Große Herausforderung 3: Grenz-KI

Entwicklung der nächsten Generation multimodaler Grenz-KI-Modelle und -Systeme und wegweisender neuartiger Fähigkeiten.

Der Schwerpunkt wird auf dem Architekturentwurf und der Entwicklung multimodaler Modelle und Systeme der nächsten Generation liegen, die die Grenzen der derzeitigen algorithmischen Fähigkeiten verschieben, um eine bessere Leistung beim fortgeschrittenen logischen Schlussfolgern, beim modalitätsübergreifenden Verständnis und bei Agentenfähigkeiten zu erreichen, sowie auf der Untersuchung neuartiger Ansätze für die Modelleffizienz, die kognitive Modellierung, alternative Rechenstrukturen usw.

Mögliche Anwendungsbereiche wären die Grundlagenforschung (wie etwa wissenschaftliche Entdeckungen und komplexe Datenauswertung) sowie die Entwicklung von Weltmodellen für verbessertes Schlussfolgern, automatisierte Managementsimulationen und deren Planung.

####  4. Große Herausforderung 4: Physische KI

Entwicklung fortgeschrittener Modelle und Systeme für physische KI, die autonom und sicher arbeiten und eine robuste Manipulation und Navigation in unstrukturierten Umgebungen ermöglichen.

Der Schwerpunkt wird auf der gemeinsamen Konzeption von Software und den ihr zugrunde liegenden Hardware-Architekturen und auf der Kombination von Grenz-KI-Techniken mit Weltmodellen liegen, die das Schlussfolgern über physikalische Zusammenhänge (physical reasoning) unterstützen, um robuste Manipulations-, Navigations- und Interaktionsfähigkeiten bei minimaler menschlicher Aufsicht zu ermöglichen.

Mögliche Anwendungsbereiche wären autonome Roboter, industrielle Systeme und Drohnen, die in dynamischen realen Umgebungen betrieben werden.

####  5. Große Herausforderung 5: Industrielle KI

Beschleunigung der Entwicklung und Verbreitung europäischer industrieller KI in allen strategischen Sektoren der Union.

Der Schwerpunkt wird auf der Entwicklung europäischer Modelle und Systeme für industrielle KI liegen, die für hochwertige industrielle Anwendungen geeignet sind. Diese Modelle und Systeme sollten an sektorspezifische Anwendungsfälle angepasst werden können und eine sichere Einführung ermöglichen.

Die im Rahmen dieser Großen Herausforderung eingeleiteten Initiativen sollten sich auf spezialisierte Rechenressourcen und Testanlagen stützen, die erforderlich sind, um KI-Systeme in realen Umgebungen zu validieren, bevor ihre groß angelegte Einführung und Nutzung auch auf regionaler und lokaler Ebene unterstützt werden kann.

In der Automobilindustrie können diese Initiativen die Entwicklung und Einführung innovativer Softwareplattformen und KI-Modelle für das automatisierte Fahren erleichtern, während sie im verarbeitenden Gewerbe die Entwicklung spezialisierter Modelle zur Optimierung der Produktionsprozesse ermöglichen können. Weitere strategische Sektoren, die von industrieller KI profitieren könnten, sind beispielsweise Gesundheitswesen, Energie, Agrar- und Ernährungswirtschaft und Verteidigung.

####  6. Große Herausforderung 6: Kooperative europäische Industriemodelle

Entwicklung kooperativer europäischer Modelle und Systeme für industrielle KI in strategischen Sektoren, indem eine Zusammenarbeit im industriellen Maßstab in Europa ermöglicht wird, ohne dass sensible Geschäftsdaten zwischen den Beteiligten offengelegt werden.

Der Schwerpunkt wird auf fortgeschrittenen Technologien, die die Wahrung der Vertraulichkeit gewährleisten, liegen. Hierzu zählen föderierte und verteilte Trainingsansätze, bei denen Algorithmen zu den Daten gebracht werden, anstatt Daten zentral zusammenzuführen, sichere Ausführungsumgebungen, auf Verschlüsselung basierende Verarbeitung, Anonymisierungs- und Pseudonymisierungstechniken, Segmentierung von Zugriffsrechten und Schutz vor der Extraktion wirtschaftlich sensibler Informationen aus trainierten Modellen.

Zu den strategischen Sektoren, die von kooperativen europäischen industriellen KI-Modellen und -Systemen profitieren könnten, zählen etwa Luft- und Raumfahrt, Pharmazie, Cybersicherheit, Mobilität, autonome Fahrzeuge und Drohnen, Energie und Verteidigung.

####  7. Große Herausforderung 7: Plattform für KI-Agenten

Entwicklung eines europäischen Rahmens für die Orchestrierung von KI-Agenten, der die wesentliche Middleware für den resilienten und sicheren Einsatz autonomer Agenten in großem Maßstab bereitstellt.

Der Schwerpunkt liegt auf i) der Erforschung innovativer technologischer Paradigmen, die eine wirksame Zusammenarbeit vieler KI-Agenten ermöglichen, sodass deren gemeinsame Leistung die von Einzelsystemen übertrifft, während zugleich hohe Sicherheitsstandards gewährleistet werden, sowie auf ii) der Entwicklung resilienter cloudgestützter offener Plattformen für die Steuerung von KI-Agenten in großem Maßstab.

Mögliche Anwendungsbereiche wären Gesundheitswesen (z. B. zur Unterstützung klinischer Entscheidungen und zur Koordinierung der Forschung), Cybersicherheit (z. B. zur Erkennung und Abwehr von Bedrohungen) sowie Grundlagenforschung.

####  8. Große Herausforderung 8: KI im öffentlichen Sektor

Entwicklung von KI-Modellen und -Systemen auf der Grundlage hochwertiger Daten des öffentlichen Sektors für kritische Bereiche (wie Gesundheitswesen, öffentliche Verwaltung, Rechtswesen und Krisenmanagement sowie öffentliche Dienste).

Der Schwerpunkt liegt auf Lösungen für öffentliche Dienste, von denen erhebliche positive Auswirkungen auf die besonders kritischen öffentlichen Dienste zu erwarten sind und die von öffentlichen Einrichtungen auf verschiedenen Verwaltungsebenen gemeinsam genutzt werden können.

Ein Ziel besteht darin, die Datenweitergabe und die Entwicklung von Grenz-KI-Modellen zwischen nationalen öffentlichen Diensten zu ermöglichen, um die Auswirkungen auf den öffentlichen Sektor in der Union insgesamt zu erhöhen, auch in Bereichen, in denen sensible Daten verarbeitet werden. Rahmenbedingungen zur Wahrung der Privatsphäre (z. B. föderiertes Lernen und Erzeugung äußerst realitätsnaher synthetischer Daten), die das Trainieren von Modellen ermöglichen, ohne die Vertraulichkeit der zugrunde liegenden Datensätze zu beeinträchtigen, und Maßnahmen zur Beschleunigung der breiten Einführung solcher Modelle, auch auf regionaler und lokaler Ebene, werden ebenfalls zur Verwirklichung dieses Ziels beitragen.

<a id="annex-ii"></a>
## Anhang II

Kriterien für die Unionsvertrauenswürdigkeitsstufen

In diesem Anhang sind die Kriterien festgelegt, die Anbieter von Cloud-Computing-Diensten und deren Cloud-Computing-Dienste erfüllen müssen, um als Anbieter von Diensten der Unionsvertrauenswürdigkeitsstufen 1, 2, 3 und 4 anerkannt zu werden. Für die Zwecke der Kriterien für die Unionsvertrauenswürdigkeitsstufen 1, 2, 3 und 4 fällt „Software“ im Sinne des Artikels 3 Nummer 4 der Verordnung (EU) 2024/2847 in den Anwendungsbereich dieses Anhangs und des Anhangs III der vorliegenden Verordnung. „Hardware“ im Sinne des Artikels 3 Nummer 5 der Verordnung (EU) 2024/2847 fällt nicht in den Anwendungsbereich.

1. Unionsvertrauenswürdigkeitsstufe 1

1.1. Für die Unionsvertrauenswürdigkeitsstufe 1 müssen Anbieter von Cloud-Computing-Diensten die folgenden kumulativen Kriterien erfüllen:

- (a) Der Anbieter von Cloud-Computing-Diensten ist in der Union niedergelassen.

- (b) Infrastruktur und Anlagen des Anbieters von Cloud-Computing-Diensten, einschließlich derjenigen seiner Unterauftragnehmer, die an der Erbringung des Dienstes beteiligt sind, befinden sich in der Union, es sei denn, die öffentliche Stelle schreibt ausdrücklich etwas anderes vor.

- (c) Die Kundendaten, einschließlich Metadaten und Telemetriedaten, die vom Anbieter von Cloud-Computing-Diensten und von den an der Erbringung des Dienstes beteiligten Unterauftragnehmern verarbeitet, gespeichert und übertragen werden, verbleiben ausschließlich in der Union – es sei denn, die öffentliche Stelle schreibt ausdrücklich etwas anderes vor – und zwar jederzeit, auch vor, während oder nach der Konfiguration oder Nutzung des Dienstes.

- (d) Lagert der Anbieter von Cloud-Computing-Diensten die technische und operative Unterstützung oder Hilfe, einschließlich etwaiger nachträglicher Vereinbarungen über weitere Auslagerungen, an Drittanbieter außerhalb der Union aus, so werden die erforderlichen rechtlichen, technischen und organisatorischen Maßnahmen ergriffen, um die Rückverfolgbarkeit, Sicherheit und Governance dieser Tätigkeiten sicherzustellen, und diese Tätigkeiten dürfen in keiner Weise die Betriebsautonomie des Anbieters von Cloud-Computing-Diensten beeinträchtigen.

- (e) Der Anbieter von Cloud-Computing-Diensten weist nach, dass der Dienst den neuesten Cybersicherheitsstandards entspricht.

- (f) Der Anbieter von Cloud-Computing-Diensten gewährleistet vollständige Transparenz hinsichtlich der Beauftragung von Unterauftragnehmern. Der Anbieter von Cloud-Computing-Diensten stellt durch eine sorgfältige Prüfung seiner Unterauftragnehmer, vertragliche Verpflichtungen und eine kontinuierliche Beaufsichtigung sicher, dass diese ihren unionsrechtlichen Verpflichtungen nachkommen;

- (g) Unterliegt der Anbieter von Cloud-Computing-Diensten der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers, so stellt der Anbieter von Cloud-Computing-Diensten anhand unabhängiger Quellen sicher, dass in diesem Drittland keine Rechtsvorschriften oder Gepflogenheiten bestehen, nach denen der Anbieter von Cloud-Computing-Diensten verpflichtet wäre, den Behörden dieses Drittlands Informationen über Softwareschwachstellen zu melden, bevor bekannt wird, dass diese Schwachstellen ausgenutzt wurden.

1.2. Für die Unionsvertrauenswürdigkeitsstufe 1 gelten als Unterauftragnehmer im Sinne des Absatzes 1 ausschließlich Unterauftragnehmer, bei denen es sich um Dritte handelt, die in einer direkten Vertragsbeziehung mit dem Anbieter von Cloud-Computing-Diensten stehen und zur Erbringung der Cloud-Computing-Dienste beitragen.

2. Unionsvertrauenswürdigkeitsstufe 2

2.1. Für die Unionsvertrauenswürdigkeitsstufe 2 müssen Anbieter von Cloud-Computing-Diensten die folgenden kumulativen Kriterien erfüllen:

- (a) Der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer sind in der Union niedergelassen.

- (b) Infrastruktur, Anlagen und Personal des geprüften Anbieters, einschließlich derjenigen seiner Unterauftragnehmer, die an der Erbringung des Dienstes beteiligt sind, befinden sich in der Union.

- (c) Die Kundendaten, einschließlich Metadaten und Telemetriedaten, die vom geprüften Anbieter und von den an der Erbringung des Dienstes beteiligten Unterauftragnehmern verarbeitet, gespeichert und übertragen werden, verbleiben ausschließlich in der Union – es sei denn, die öffentliche Stelle schreibt ausdrücklich etwas anderes vor – und zwar jederzeit, auch vor, während oder nach der Konfiguration oder Nutzung des Dienstes.

- (d) Stellt die öffentliche Stelle fest, dass zusätzliche Anforderungen an die Personalüberprüfung und die Unionsbürgerschaft erforderlich sind, sollte der geprüfte Anbieter sicherstellen, dass Personal zur Verfügung steht, das diese Anforderungen erfüllt.

- (e) Der geprüfte Dienst erlangt ein europäisches Cybersicherheitszertifikat mindestens der Vertrauenswürdigkeitsstufe „mittel“ im Rahmen eines nach der Verordnung (EU) 2019/881 einzurichtenden europäischen Systems für die Cybersicherheitszertifizierung von Cloud-Computing-Diensten, sofern ein solches System im Rahmen der genannten Verordnung eingerichtet wurde und den Anbietern von Cloud-Computing-Diensten zur Verfügung steht. Wurde ein solches System noch nicht eingerichtet, gelten nationale Systeme für die Cybersicherheitszertifizierung, sofern diese vorhanden sind. Gibt es weder ein System für die Cybersicherheitszertifizierung auf nationaler Ebene noch auf EU-Ebene, muss der geprüfte Anbieter nachweisen, dass der Dienst die höchsten Cybersicherheitsstandards nach geltendem Unionsrecht erfüllt.

- (f) Die bei der Nutzung des geprüften Dienstes erzeugten Daten werden nicht zum Trainieren oder zur Optimierung von KI-Systemen verwendet, die von einem Drittland oder einem Rechtsträger mit Sitz in einem Drittland betrieben werden, und verlassen keinesfalls die Union.

- (g) Unterliegen der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers, so weisen sie nach, dass die erforderlichen rechtlichen, technischen und organisatorischen Maßnahmen getroffen wurden, um sicherzustellen, dass

  - i) die Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers über den geprüften Anbieter nicht in einer Weise ausgeübt wird, die dessen Fähigkeit zur Erbringung des Dienstes einschränkt oder beeinträchtigt, die Beschränkungen hinsichtlich der für die Erbringung des Dienstes erforderlichen Infrastrukturen und Anlagen und des erforderlichen Personals vorsieht oder die für die Erbringung des geprüften Dienstes erforderlichen Fähigkeiten und Standards untergräbt;

  - ii) Drittländer oder in einem Drittland niedergelassene Rechtsträger keinen Zugang zu Kundendaten haben;

  - iii) jedweder Möglichkeit einer Störung der Kontinuität des Dienstes und/oder einer Verschlechterung der Dienstqualität durch ein Drittland oder einen in einem Drittland niedergelassenen Rechtsträger vorgebeugt wird;

  - iv) die Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers über den geprüften Anbieter nicht in einer Weise ausgeübt wird, die den geprüften Anbieter dazu verpflichtet, restriktive Maßnahmen wie Sanktionsregelungen, Embargos oder gleichwertige rechtliche oder administrative Maßnahmen eines Drittlands umzusetzen, durchzusetzen, anzuwenden oder einzuhalten, es sei denn, diese Maßnahmen sind nach dem nationalen Recht der Mitgliedstaaten oder dem Unionsrecht rechtmäßig;

- (h) Die technische und operative Unterstützung oder Hilfe im Zusammenhang mit dem geprüften Dienst, einschließlich nachträglicher Vereinbarungen über weitere Auslagerungen, wird ausschließlich innerhalb der Union veranlasst und durchgeführt.

- (i) Der geprüfte Anbieter weist nach, dass die folgenden Maßnahmen in Bezug auf die Software-Lieferkette getroffen wurden:

  - i) eine vollständige und aktuelle Software-Stückliste (SBOM) im Sinne des Artikels 3 Nummer 39 der Verordnung (EU) 2024/2847 und eine Liste der ermittelten Abhängigkeiten, die für die Erbringung des Dienstes relevant sind, wurden dokumentiert und der Prüfstelle zur Verfügung gestellt;

  - ii) ist der Anbieter, Eigentümer und Lizenzgeber von Softwarekomponenten im Sinne des Artikels 3 Nummer 6 der Verordnung (EU) 2024/2847 oder Produkten ein in einem Drittland niedergelassener Rechtsträger, so werden Kontrollen durchgeführt und dokumentiert, um Fernzugriffsfunktionen zu unterbinden, die ein Gerät, ein System oder eine Software (auch durch Aktualisierungen) wesentlich manipulieren oder stören könnten, und um sicherzustellen, dass die sicherheitsrelevanten Komponenten von Softwareherstellern aus Drittländern im Sinne des Artikels 3 Nummer 13 der Verordnung (EU) 2024/2847 Quellcode-Prüfungen unterzogen werden und ein dokumentierter Migrationsplan vorliegt, falls der Software-Anbieter seinen Dienst nicht erbringen kann oder ein Drittland Beschränkungen auferlegt;

  - iii) unterliegt der Anbieter von Cloud-Computing-Diensten der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers, so stellt der Anbieter von Cloud-Computing-Diensten anhand unabhängiger Quellen sicher, dass in diesem Drittland keine Rechtsvorschriften oder Gepflogenheiten bestehen, nach denen der Anbieter von Cloud-Computing-Diensten verpflichtet ist, den Behörden dieses Drittlands Informationen über Softwareschwachstellen zu melden, bevor bekannt wird, dass diese Schwachstellen ausgenutzt wurden.

- (j) Wird für die Erbringung des Dienstes Software verwendet, die mit einer quelloffenen Lizenz freigegeben wurde, so weist der geprüfte Anbieter nach, dass er geeignete Kontrollen eingeführt und dokumentiert hat, um Fernzugriffsfunktionen oder -mechanismen zu unterbinden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören.

- (k) Soweit der geprüfte Anbieter seine Dienste weltweit erbringt und ein Tochterunternehmen in einem Drittland hat, trifft der geprüfte Anbieter die erforderlichen Maßnahmen, um eine wirksame rechtliche, technische und organisatorische Trennung zwischen dem Mutterunternehmen in der Union und einem solchen Tochterunternehmen in einem Drittland zu gewährleisten und durchzusetzen.

2.2. Für die Unionsvertrauenswürdigkeitsstufe 2 gelten als Unterauftragnehmer im Sinne des Absatzes 1 ausschließlich Unterauftragnehmer, bei denen es sich um Dritte handelt, die in einer direkten Vertragsbeziehung mit dem Anbieter von Cloud-Computing-Diensten stehen und zur Erbringung des Cloud-Computing-Dienstes beitragen.

3. Unionsvertrauenswürdigkeitsstufe 3

3.1. Für die Unionsvertrauenswürdigkeitsstufe 3 müssen Anbieter von Cloud-Computing-Diensten die folgenden kumulativen Kriterien erfüllen:

- (a) Der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer sind in der Union niedergelassen.

- (b) Infrastruktur, Anlagen und Personal des geprüften Anbieters, einschließlich derjenigen seiner Unterauftragnehmer, die an der Erbringung des Dienstes beteiligt sind, befinden sich in der Union.

- (c) Die Kundendaten, einschließlich Metadaten und Telemetriedaten, die vom geprüften Anbieter und von den an der Erbringung des Dienstes beteiligten Unterauftragnehmern verarbeitet, gespeichert und übertragen werden, verbleiben ausschließlich in der Union – es sei denn, die öffentliche Stelle schreibt ausdrücklich etwas anderes vor – und zwar jederzeit, auch vor, während oder nach der Konfiguration oder Nutzung des Dienstes.

- (d) Bei dem Personal, einschließlich des Personals der Unterauftragnehmer, das an der Erbringung des geprüften Dienstes beteiligt ist, handelt es sich um Unionsbürger und das Personal muss sich erforderlichenfalls auch einer nationalen Sicherheitsüberprüfung unterziehen, deren Bescheinigung von einem Mitgliedstaat für den Umgang mit Verschlusssachen im Sinne des Artikels 2 Nummer 21 der Verordnung (EU) 2021/697 ausgestellt wird.

- (e) Der geprüfte Dienst erlangt ein europäisches Cybersicherheitszertifikat mindestens der Vertrauenswürdigkeitsstufe „mittel“ im Rahmen eines nach der Verordnung (EU) 2019/881 einzurichtenden europäischen Systems für die Cybersicherheitszertifizierung von Cloud-Computing-Diensten, sofern ein solches System im Rahmen der genannten Verordnung eingerichtet wurde und den Anbietern von Cloud-Computing-Diensten zur Verfügung steht. Wurde ein solches System noch nicht eingerichtet, gelten nationale Systeme für die Cybersicherheitszertifizierung, sofern diese vorhanden sind. Gibt es weder ein System für die Cybersicherheitszertifizierung auf nationaler Ebene noch auf EU-Ebene, muss der geprüfte Anbieter nachweisen, dass der Dienst die höchsten Cybersicherheitsstandards nach geltendem Unionsrecht erfüllt.

- (f) Die bei der Nutzung des geprüften Dienstes erzeugten Daten werden nicht zum Trainieren oder zur Optimierung von KI-Systemen verwendet, die von einem Drittland oder einem Rechtsträger mit Sitz in einem Drittland betrieben werden, und verlassen keinesfalls die Union.

- (g) Der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer unterliegen nicht der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers. Abweichend von diesem Kriterium können ein Anbieter von Cloud-Computing-Diensten und dessen Unterauftragnehmer, die an der Erbringung des geprüften Dienstes beteiligt sind und der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers unterliegen, für die Unionsvertrauenswürdigkeitsstufe 3 geprüft werden, wenn die Kommission hierzu einen Durchführungsrechtsakt gemäß Artikel 19 erlassen hat. Hat die Kommission einen Durchführungsrechtsakt nach Artikel 19 erlassen, müssen der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer auch nachweisen, dass die erforderlichen rechtlichen, technischen und organisatorischen Maßnahmen getroffen wurden, um sicherzustellen, dass

  - i) die Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers über den geprüften Anbieter nicht in einer Weise ausgeübt wird, die dessen Fähigkeit zur Erbringung des Dienstes einschränkt oder beeinträchtigt, die Beschränkungen hinsichtlich der für die Erbringung des Dienstes erforderlichen Infrastrukturen und Anlagen und des erforderlichen Personals vorsieht oder die für die Erbringung des geprüften Dienstes erforderlichen Fähigkeiten und Standards untergräbt. Der geprüfte Anbieter sollte einen angemessenen Zugang zum Quellcode ermöglichen;

  - ii) Drittländer oder in einem Drittland niedergelassene Rechtsträger keinen Zugang zu Kundendaten haben;

  - iii) jedweder Möglichkeit einer Störung der Kontinuität des Dienstes und/oder einer Verschlechterung der Dienstqualität durch ein Drittland oder einen in einem Drittland niedergelassenen Rechtsträger vorgebeugt wird;

  - iv) die Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers über den geprüften Anbieter nicht in einer Weise ausgeübt wird, die den geprüften Anbieter dazu verpflichtet, restriktive Maßnahmen wie Sanktionsregelungen, Embargos oder gleichwertige rechtliche oder administrative Maßnahmen eines Drittlands umzusetzen, durchzusetzen, anzuwenden oder einzuhalten, es sei denn, diese Maßnahmen sind nach dem nationalen Recht der Mitgliedstaaten oder dem Unionsrecht rechtmäßig.

- (h) Die technische und operative Unterstützung oder Hilfe im Zusammenhang mit dem geprüften Dienst, einschließlich nachträglicher Vereinbarungen über weitere Auslagerungen, wird ausschließlich innerhalb der Union von in der Union ansässigem Personal und von Dritten, die nicht der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers unterliegen, veranlasst und durchgeführt.

- (i) Der geprüfte Anbieter weist nach, dass die folgenden Maßnahmen in Bezug auf die Software-Lieferkette getroffen wurden:

  - i) eine vollständige und aktuelle Software-Stückliste und eine Liste der ermittelten Abhängigkeiten, die für die Erbringung des Dienstes relevant sind, wurden dokumentiert und der Prüfstelle zur Verfügung gestellt;

  - ii) ist der Anbieter, Eigentümer und Lizenzgeber von Softwarekomponenten oder Produkten ein in einem Drittland niedergelassener Rechtsträger, so werden Kontrollen durchgeführt und dokumentiert, um Fernzugriffsfunktionen zu unterbinden, die ein Gerät, System oder eine Software (auch durch Aktualisierungen) wesentlich manipulieren oder stören könnten, und um sicherzustellen, dass die sicherheitsrelevanten Komponenten von Herstellern aus Drittländern Quellcode-Prüfungen unterzogen werden und ein dokumentierter Migrationsplan vorliegt, falls der Software-Anbieter seinen Dienst nicht erbringen kann oder ein Drittland Beschränkungen auferlegt;

  - iii) unterliegt der Anbieter von Cloud-Computing-Diensten der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers, so stellt der Anbieter von Cloud-Computing-Diensten anhand unabhängiger Quellen sicher, dass in diesem Drittland keine Rechtsvorschriften oder Gepflogenheiten bestehen, nach denen der Anbieter von Cloud-Computing-Diensten verpflichtet ist, den Behörden dieses Drittlands Informationen über Softwareschwachstellen zu melden, bevor bekannt wird, dass diese Schwachstellen ausgenutzt wurden.

- (j) Wird für die Erbringung des Dienstes Software verwendet, die mit einer quelloffenen Lizenz freigegeben wurde, so weist der geprüfte Anbieter nach, dass er geeignete Kontrollen eingeführt und dokumentiert hat, um Fernzugriffsfunktionen oder -mechanismen zu unterbinden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören.

- (k) Soweit der geprüfte Anbieter seine Dienste außerhalb der Union erbringt und ein Tochterunternehmen in einem Drittland hat, weist der geprüfte Anbieter nach, dass er die erforderlichen Maßnahmen getroffen hat, um eine wirksame rechtliche, technische und organisatorische Trennung zwischen dem Mutterunternehmen in der Union und einem solchen Tochterunternehmen in einem Drittland zu gewährleisten und durchzusetzen.

3.2. Für die Unionsvertrauenswürdigkeitsstufe 3 müssen die Unterauftragnehmer im Sinne des Absatzes 1 Unterauftragnehmer sein, bei denen es sich um Dritte handelt, die in einer direkten Vertragsbeziehung mit dem Anbieter von Cloud-Computing-Diensten stehen, zur Erbringung des Cloud-Computing-Dienstes beitragen und möglicherweise Zugang zu Verschlusssachen oder sensiblen Informationen im Sinne des Artikels 2 Nummer 22 der Verordnung (EU) 2021/697 benötigen.

4. Unionsvertrauenswürdigkeitsstufe 4

4.1. Für die Unionsvertrauenswürdigkeitsstufe 4 müssen Anbieter von Cloud-Computing-Diensten die folgenden kumulativen Kriterien erfüllen:

- (a) Der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer sind in der Union niedergelassen.

- (b) Infrastruktur, Anlagen und Personal des geprüften Anbieters, einschließlich derjenigen seiner Unterauftragnehmer, die an der Erbringung des Dienstes beteiligt sind, befinden sich in der Union.

- (c) Die Kundendaten, einschließlich Metadaten und Telemetriedaten, die nach einer Risikobewertung als sensibel eingestuft wurden und die vom geprüften Anbieter und von den an der Erbringung des Dienstes beteiligten Unterauftragnehmern verarbeitet, gespeichert und übertragen werden, verbleiben ausschließlich in der Union und zwar jederzeit, auch vor, während oder nach der Konfiguration oder Nutzung des Dienstes.

- (d) Bei dem Personal, einschließlich des Personals der Unterauftragnehmer, die an der Erbringung des geprüften Dienstes beteiligt sind, handelt es sich um Unionsbürger und das Personal muss sich erforderlichenfalls auch einer nationalen Sicherheitsüberprüfung unterziehen, deren Bescheinigung von einem Mitgliedstaat für den Umgang mit Verschlusssachen ausgestellt wird.

- (e) Der geprüfte Dienst erlangt ein europäisches Cybersicherheitszertifikat mindestens der Vertrauenswürdigkeitsstufe „hoch“ im Rahmen eines nach der Verordnung (EU) 2019/881 einzurichtenden europäischen Systems für die Cybersicherheitszertifizierung von Cloud-Computing-Diensten, sofern ein solches System im Rahmen der genannten Verordnung eingerichtet wurde und den Anbietern von Cloud-Computing-Diensten zur Verfügung steht. Wurde ein solches System noch nicht eingerichtet, gelten nationale Systeme für die Cybersicherheitszertifizierung, sofern diese vorhanden sind. Gibt es weder ein System für die Cybersicherheitszertifizierung auf nationaler Ebene noch auf EU-Ebene, muss der geprüfte Anbieter nachweisen, dass der Dienst die höchsten Cybersicherheitsstandards nach geltendem Unionsrecht erfüllt.

- (f) Die bei der Nutzung des geprüften Dienstes erzeugten Daten werden nicht zum Trainieren oder zur Optimierung von KI-Systemen verwendet, die von einem Drittland oder einem Rechtsträger mit Sitz in einem Drittland betrieben werden, und verlassen keinesfalls die Union.

- (g) Der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer unterliegen nicht der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers.

- (h) Die technische und operative Unterstützung oder Hilfe im Zusammenhang mit dem geprüften Dienst, einschließlich nachträglicher Vereinbarungen über weitere Auslagerungen, wird ausschließlich innerhalb der Union von in der Union ansässigem Personal und von Dritten, die nicht der Kontrolle eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers unterliegen, veranlasst und durchgeführt.

- (i) Der geprüfte Anbieter weist nach, dass die folgenden Maßnahmen in Bezug auf die Software-Lieferkette getroffen wurden:

  - i) eine vollständige und aktuelle Software-Stückliste und eine Liste der ermittelten Abhängigkeiten, die für die Erbringung des Dienstes relevant sind, wurden dokumentiert und der Prüfstelle zur Verfügung gestellt;

  - ii) es wurden Maßnahmen getroffen, um die wirksame Kontrolle über die Softwarekomponenten oder Produkte aufrechtzuerhalten und es wird nachgewiesen, dass ein Drittland oder ein in einem Drittland niedergelassener Rechtsträger keine wirksame Kontrolle über die Konzeption, Entwicklung, Wartung und Weiterentwicklung dieser Komponenten oder Produkte besitzt oder ausübt. Eine wirksame Kontrolle umfasst die Fähigkeit, die technische Entwicklung, die Wartungsprioritäten, die Behebung von Sicherheitsproblemen und die langfristige Kontinuität der Komponente wesentlich zu beeinflussen.

- (j) Wird Software verwendet, die mit einer quelloffenen Lizenz freigegeben wurde, so weist der geprüfte Anbieter nach, dass er geeignete Kontrollen eingeführt und dokumentiert hat, um Fernzugriffsfunktionen oder -mechanismen zu unterbinden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören.

- (k) Soweit der geprüfte Anbieter seine Dienste außerhalb der Union erbringt und ein Tochterunternehmen in einem Drittland hat, weist der geprüfte Anbieter nach, dass er die erforderlichen Maßnahmen getroffen hat, um eine wirksame rechtliche, technische und organisatorische Trennung zwischen dem Mutterunternehmen in der Union und einem solchen Tochterunternehmen in einem Drittland zu gewährleisten und durchzusetzen.

4.2. Für die Unionsvertrauenswürdigkeitsstufe 4 gelten als Unterauftragnehmer im Sinne des Absatzes 1 ausschließlich Unterauftragnehmer, bei denen es sich um Dritte handelt, die in einer direkten Vertragsbeziehung mit dem Anbieter von Cloud-Computing-Diensten stehen, zur Erbringung des Cloud-Computing-Dienstes beitragen und möglicherweise Zugang zu Verschlusssachen oder sensiblen Informationen für die Erbringung des Dienstes benötigen.

<a id="annex-iii"></a>
## Anhang III

Prüfbelege für das Prüfverfahren

Die Prüfstellen sollten die in diesem Anhang aufgeführten Prüfbelege von dem geprüften Anbieter anfordern, wenn sie die Konformität des geprüften Dienstes anhand der geltenden Prüfkriterien gemäß Anhang II bewerten.

Dieser Anhang enthält keine vollständige Auflistung; die Prüfstellen können auch andere als die in diesem Anhang aufgeführten Prüfbelege anfordern oder berücksichtigen. Die Prüfer können zusätzliche Informationen anfordern, die im Rahmen von Prüfungen für eine umfassende und genaue Konformitätsbewertung erforderlich sind. Die angeforderten Belege können zwar identisch sein, die zu analysierenden Aspekte unterscheiden sich jedoch je nach den Kriterien für die Vertrauenswürdigkeitsstufen und deren Anforderungsniveau.

1. Prüfkriterium A – Niederlassung in der Union

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe a aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Jegliche Belege, aus denen hervorgeht, dass der geprüfte Anbieter nach dem Recht eines Mitgliedstaats in der Union niedergelassen oder nach dem Gesellschaftsrecht eines Mitgliedstaats in der Union gegründet wurde.

- (2) Jegliche Belege dafür, dass sich der eingetragene Sitz, die Hauptverwaltung und die Hauptniederlassung des geprüften Anbieters in der Union befinden.

- (3) Die Prüfstelle sollte den geltenden Unionsrechtsrahmen des geprüften Anbieters überprüfen und prüfen, ob es sich um eine echte und dauerhafte Niederlassung handelt oder ob der geprüfte Anbieter stattdessen lediglich als außereuropäischer Anbieter einzustufen ist, der Dienste in der Union anbietet.

- (4) Die Prüfstelle sollte prüfen, ob der Anbieter in einem Mitgliedstaat der Union rechtmäßig eingetragen ist. Als Beleg hierfür könnten unter anderem Unternehmensregisterauszüge, Bescheinigungen über die steuerliche Ansässigkeit, Gewerbescheine, die Umsatzsteuer-Identifikationsnummer, und die Überprüfung, ob der Anbieter im System zur Verknüpfung von Unternehmensregistern (BRIS) und im Mehrwertsteuer-Informationsaustauschsystem (MIAS) registriert ist, dienen.

- (5) Die Prüfstelle sollte überprüfen, ob der geprüfte Anbieter dauerhaft und tatsächlich in der Union ansässig ist. Die Prüfstelle sollte daher überprüfen, ob

  - (a) sich physische Büros oder Betriebsstätten in der EU befinden (etwa anhand von Mietverträgen, Rechnungen von Versorgungsunternehmen oder Eigentumsurkunden);

  - (b) sich ständiges Personal in der Union befindet und ob die Kundenbetreuung in der Union durchgeführt wird (etwa anhand von Arbeitsverträgen, Gehaltsabrechnungen, Arbeitszeitnachweisen);

  - (c) die Vertragsabwicklung in der Union erfolgt (etwa anhand von Aufzeichnungen über das Tätigkeitsmanagement oder über die Meldung von Vorfällen);

  - (d) Bankgeschäfts- und Buchhaltungstätigkeiten ausschließlich in der Union durchgeführt werden (etwa anhand von Jahresabschlüssen und gesetzlich vorgeschriebenen Prüfberichten).

- (6) Die Prüfstelle sollte überprüfen, ob sich Niederlassungen oder Zweigniederlassungen in den Mitgliedstaaten der Union befinden (etwa anhand von Mietverträgen, Rechnungen von Versorgungsbetrieben, Eigentumsurkunden, Arbeitsverträgen, Arbeitszeitnachweisen, Gehaltsabrechnungen oder Bestellungen).

2. Prüfkriterium B – Standort der Infrastruktur, der Anlagen und des Personals

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe b aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Standort der Infrastruktur

  - (a) Eine Liste mit relevanten Angaben zum Standort der Infrastruktur und der Datenspeicherstandorte, die für die Erbringung des geprüften Dienstes genutzt werden. Diese Liste sollte den genauen Standort (Nummer, Straße, Stadt, Postleitzahl und Land) der Infrastruktur enthalten und belegen, dass alle Elemente für die Erbringung des geprüften Dienstes innerhalb der Union verbleiben. Dies umfasst die Standorte der Primär-, Sicherungskopie-, Notfallwiederherstellungs- und Protokollspeicher.

  - (b) Sonstige Belege dafür, dass sich die IT-Infrastruktur in der Union befindet, z. B. Mietverträge, Eigentumsurkunden, Wartungsverträge, Dienstleistungsverträge, Protokolle über den Zugang zu den Anlagen.

  - (c) Netzwerkdiagramme und Architekturunterlagen, aus denen hervorgeht, dass für die Datenspeicherung und -verarbeitung ausschließlich Infrastrukturen innerhalb der Union genutzt werden, auch für die Datensicherung und Datenreplizierung.

- (2) Standort der Anlagen

  - (a) Eine Liste mit relevanten Angaben zu den Anlagen, die für die Erbringung des geprüften Dienstes verwendet werden, z. B. ein Anlagenverzeichnis.

  - (b) Belege dafür, dass sich Server, Ausrüstung und betriebliche Anlagen in der Union befinden, wie etwa Unterlagen mit Angaben zum Server und seinem Standort, Einkaufsbelege, Lieferscheine, Lizenzvereinbarungen, Abonnementverträge oder Rechnungen für Softwarekäufe oder -abonnements, Rechnungen für Hardware mit Liefernachweisen.

  - (c) Belege dafür, dass sich die Kapazitäten für die Erbringung von Diensten in der Union befinden, z. B. Bereitstellungsnachweise, Installationsnachweise, Berichte zum Dienststatus, Konfigurationsberichte, Überwachungsergebnisse, Administratorprotokolle, aus denen die Nutzung des Dienstes hervorgeht.

- (3) Standort des Personals

  - (a) Eine Liste mit relevanten Angaben zum Personal, das für die Erbringung des geprüften Dienstes eingesetzt wird.

  - (b) Belege dafür, dass das an der Erbringung des geprüften Dienstes beteiligte Personal in der Union ansässig ist, wie etwa Arbeitsverträge, Gehaltsabrechnungen, Arbeitszeitnachweise, Tätigkeitsnachweise und Organisationspläne, aus denen das in der Union ansässige Personal und die entsprechenden betrieblichen Zuständigkeiten hervorgehen.

- (4) Erwägungen in Bezug auf Infrastruktur, Anlagen und Personal

  - (a) Die Prüfstelle sollte auch bewerten, wo Infrastruktur, Anlagen oder Personal

    - i) Kundendaten speichern, übermitteln, abrufen, verarbeiten oder anderweitig handhaben;

    - ii) den administrativen Zugang zu, die Kontrolle über, die Konfiguration von oder die Einsichtnahme in Kundendaten bereitstellen, ermöglichen oder ermöglichen könnten;

    - iii) im Falle einer Beeinträchtigung, Fehlkonfiguration, Nichtverfügbarkeit oder Störung voraussichtlich eine Störung oder Nichtverfügbarkeit des geprüften Dienstes verursacht würde.

Anmerkung: „Infrastruktur“ bezeichnet physische Infrastrukturen, wie beispielsweise Rechenzentrumsinfrastrukturen oder Kolokationsinfrastrukturen, Netzwerke, Kühlsysteme und IT-Systeme, die die Verwaltung des Rechenzentrums ermöglichen.

„Anlagen“ bezeichnet Hardware und Software, wie beispielsweise Bibliotheken, das für die Kommunikation zwischen Softwarekomponenten erforderliche interne Netz und kryptografisches Material, das die Erbringung von Cloud-Computing-Diensten ermöglicht.

„Personal“, einschließlich des von Unterauftragnehmern verwalteten Personals, bezeichnet Personen, die die Erbringung, Verwaltung, Sicherheit, Verfügbarkeit oder den Betrieb des geprüften Dienstes unterstützen.

3. Prüfkriterium C – Datenlokalisierung in der Union

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe c aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Belege dafür, dass Kundendaten ausschließlich in der Union gespeichert und verarbeitet werden und dass Dritte oder Unterauftragnehmer, die die Bedingungen dieses Anhangs nicht erfüllen, unter keinen Umständen technisch oder operativ in der Lage sind, ohne vorherige Genehmigung auf Kundendaten zuzugreifen, sie zu erlangen, unzugänglich zu machen, zu vernichten oder ganz allgemein zu verarbeiten. Beispiele hierfür sind Zugriffsprotokolle, Zugriffsregelungen für Unterstützungstätigkeiten, Aufzeichnungen über privilegierte Zugriffe, Regelungen zur Aufbewahrung von Sicherheitskopien und Datenflussdiagramme, aus denen hervorgeht, wo die Kundendaten gespeichert, verarbeitet, repliziert und Sicherheitskopien von ihnen gemacht werden. Werden personenbezogene Daten verarbeitet, sind Verträge mit den Unterauftragnehmern vorzuweisen, die die Einhaltung der Verordnung (EU) 2016/679 nachweisen.

- (2) Protokolle und Überwachungsaufzeichnungen, aus denen hervorgeht, dass alle Daten ausschließlich in der Union gespeichert und verarbeitet werden. Beispiele hierfür sind Dienstleistungsrahmenverträge, Datenverarbeitungsvereinbarungen, vertragliche Datenresidenzvereinbarungen oder eine EU-Datengrenze.

- (3) Belege (wie etwa vertragliche Vereinbarungen, Protokolle und Verfahren, die öffentlichen Stellen angeboten werden), aus denen hervorgeht, dass der geprüfte Anbieter und die an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer die erforderlichen Maßnahmen ergriffen haben, um sicherzustellen, dass

  - (a) ohne Zustimmung der öffentlichen Stelle keine Kundendaten, auch keine verschlüsselten Daten, die Union verlassen;

  - (b) keine Daten an andere Dritte übermittelt werden, bei denen es sich nicht um an der Erbringung des Dienstes beteiligte Unterauftragnehmer oder um von der öffentlichen Stelle ausdrücklich berechtigte Empfänger handelt.

- (4) Ein Datenflussdiagramm, das die Datenflüsse zwischen dem Anbieter von Cloud-Computing-Diensten und den Kunden sowie mit Diensten Dritter und Unterauftragnehmern zeigt. Aus dem Diagramm müssen Ursprung und Bestimmungsort der Daten eindeutig hervorgehen wie auch ein Nachweis, dass die Daten die Union nicht verlassen.

Anmerkung: Für die Zwecke dieses Anhangs bezeichnet „Kunde“ eine öffentliche Stelle, die mit dem Anbieter von Cloud-Computing-Diensten eine vertragliche oder sonstige rechtsverbindliche Vereinbarung über den Zugang zum Cloud-Computing-Dienst oder dessen Nutzung geschlossen hat.

„Kundendaten“ können alle Daten umfassen, die unter der rechtlichen, vertraglichen oder anderweitigen Kontrolle des Kunden des Cloud-Computing-Dienstes stehen und die

  - (a) vom Kunden oder in dessen Namen in den Cloud-Computing-Dienst eingegeben werden, einschließlich Authentifizierungsdaten,

  - (b) erzeugt werden, indem der Nutzer den Cloud-Computing-Dienst nutzt.

Kundendaten können auch Daten umfassen, die unter der Kontrolle des geprüften Anbieters stehen und die infolge der Interaktion des Kunden des Cloud-Dienstes mit dem geprüften Dienst erlangt werden. Hierzu gehören auch Kundendaten und alle Daten, die sich aus der Nutzung der Cloud-Computing-Dienste ergeben (d. h. Telemetrie- oder Metadaten).

„Von Cloud-Computing-Diensten abgeleitete Daten“ umfassen den Teil der Protokolldaten, der Aufzeichnungen darüber enthält, wer den Dienst zu welcher Zeit und welche Funktionen genutzt hat, betroffene Arten von Daten usw. Hierzu können zudem Informationen über die Anzahl der autorisierten Nutzer und deren Identität zählen wie auch alle Konfigurations- oder Anpassungsdaten, wenn der Cloud-Computing-Dienst über solche Konfigurations- und Anpassungsfunktionen verfügt.

4. Prüfkriterium D – Unionsbürgerschaft

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe d aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Der geprüfte Anbieter sollte der Prüfstelle gegenüber nachweisen, dass er die Maßnahmen umgesetzt hat, mit denen sichergestellt wird, dass es sich bei dem an der Erbringung des geprüften Dienstes beteiligten Personal um Unionsbürger handelt, falls eine öffentliche Stelle die Unionsbürgerschaft als Voraussetzung vorschreibt. Dies kann durch gültige amtliche Dokumente (wie einen gültigen Reisepass oder Personalausweis) nachgewiesen werden.

- (2) Der geprüfte Anbieter sollte Organisationspläne und Stellenbeschreibungen vorlegen, aus denen hervorgeht, dass er auf Anfrage sicherstellen kann, dass ausschließlich Personal mit Unionsbürgerschaft mit dem Betrieb, der Verwaltung, der Wartung und der Betreuung der geprüften Dienstes betraut wird.

- (3) Der geprüfte Anbieter sollte Unterlagen vorlegen, aus denen die Konzepte für die Zugriffskontrolle sowie Prüfpfade hervorgehen, um nachzuweisen, dass nur befugte Mitarbeiter, die Unionsbürger sind, Zugang zu den Systemen und Daten des Dienstes haben.

- (4) Der geprüfte Anbieter sollte nachweisen, dass er Verfahren eingeführt hat, die regeln, wie die Staatsbürgerschaft vor einer Aufgabenzuweisung überprüft wird und wie die Einhaltung dieses Prüfkriteriums während der gesamten Beschäftigung aufrechterhalten wird.

Anmerkung: Das an der Erbringung des geprüften Dienstes beteiligte Personal könnte Personal umfassen, das logischen oder physischen Zugang zu Infrastruktur und Anlagen hat, die für den Betrieb des Cloud-Computing-Dienstes genutzt werden, sowie Personal, das für die Kundenbetreuung zuständig ist, und das gesamte Personal, das die Managementkontrolle über den Anbieter von Cloud-Computing-Diensten ausübt.

5. Prüfkriterium E – Europäisches System für die Cybersicherheitszertifizierung, gemäß der Verordnung (EU) 2019/881

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe e aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Ein gültiges europäisches Cybersicherheitszertifikat, das von einer zuständigen Konformitätsbewertungsstelle ausgestellt wurde und aus dem hervorgeht, dass der geprüfte Dienst im Rahmen eines gemäß der Verordnung (EU) 2019/881 angenommenen europäischen Systems für die Cybersicherheitszertifizierung bewertet wurde und die Anforderungen der Vertrauenswürdigkeitsstufen „niedrig“, „mittel“ oder „hoch“ erfüllt, sofern ein solches System eingerichtet wurde.

- (2) Einen Zertifizierungsbericht mit einer Beschreibung der wichtigsten Komponenten, die für die Entwicklung und den Betrieb des Cloud-Computing-Dienstes verwendet werden, der Gegenstand der Prüfbescheinigung ist.

- (3) Bis zur Einrichtung des europäischen Systems für die Cybersicherheitszertifizierung von Cloud-Computing-Diensten kann der geprüfte Anbieter die Konformität durch gültige Cybersicherheitszertifizierungen nachweisen. Hierzu zählen unter anderem:

  - (a) ein gültiges, von einer zuständigen Konformitätsbewertungsstelle ausgestelltes Zertifikat (gemäß CEN/CLC/TS 18072:2025), aus dem hervorgeht, dass der Cloud-Computing-Dienst bewertet wurde und die Anforderungen der in CEN/TS 18026:2024 festgelegten Vertrauenswürdigkeitsstufen „niedrig“, „mittel“ oder „hoch“ erfüllt;

  - (b) ein von der jeweils zuständigen nationalen Behörde ausgestelltes gültiges Zertifikat, aus dem hervorgeht, dass der Cloud-Computing-Dienst bewertet wurde und die Anforderungen des derzeit in dem Mitgliedstaat geltenden nationalen Cybersicherheitssystems erfüllt;

  - (c) falls es ein solches nationales System nicht gibt: Belege dafür, dass die höchsten auf dem Markt verfügbaren Cybersicherheitsstandards eingehalten werden.

6. Prüfkriterium F – Von einem Drittland oder einem Rechtsträger eines Drittlands betriebene KI-Systeme

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe f aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Vertragsklauseln, in denen festgelegt ist, dass Daten, die unter Nutzung des geprüften Dienstes verarbeitet oder erzeugt werden, einschließlich von Kunden abgeleiteter Daten, Protokolle und Telemetrie, nicht zum Trainieren oder zur Optimierung von KI-Modellen oder -Systemen, die von einem Drittland oder einem Rechtsträger aus einem Drittland betrieben werden, verwendet werden dürfen und keinesfalls die Union verlassen dürfen.

- (2) Vertragsklauseln, in denen festgelegt ist, dass Daten ausschließlich für die Erbringung des geprüften Dienstes und nicht für Dienstverbesserungen, Modell- oder Systemverbesserungen oder andere sekundäre Zwecke verarbeitet werden dürfen.

- (3) Datenflussdiagramme, mit denen der durchgehende Datenfluss, einschließlich Datenaufnahme, -speicherung, -verarbeitung und -löschung, dokumentiert wird. Aus den Diagrammen sollte auch hervorgehen, wo die KI-Pipelines oder die Vorgänge des maschinellen Lernens (MLOps) mit Kundendaten verknüpft werden.

- (4) MLOps- oder Bereitstellungsprotokolle, aus denen hervorgeht, dass sich die Standorte für Erstellung, Tests und Freigabe in der Union befinden.

- (5) Modell- oder Systemkarten, die die Modell- oder Systembezeichnung, Version, Angaben zum Training und zur Validierung enthalten, einschließlich Erklärungen, dass die bei der Nutzung des geprüften Dienstes erzeugten Daten die Union nicht verlassen.

- (6) Datenherkunftsregelungen und zugehörige Umsetzungsunterlagen, aus denen hervorgeht, dass der Anbieter Datenherkunfts- und Datenursprungstools betreibt, und aus denen (pro Protokoll) hervorgeht, wofür die Daten verwendet wurden.

- (7) Eine Liste der Unterauftragnehmer (unter Angabe des Landes ihrer Niederlassung), die auf die durch die Nutzung des geprüften Dienstes erzeugten Daten zugreifen.

7. Prüfkriterium G – Fehlende Kontrolle durch ein Drittland oder durch einen Rechtsträger aus einem Drittland

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe g aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Die Prüfstelle sollte Folgendes ermitteln und analysieren:

  - (a) alle direkten und indirekten Anteilseigner, bis hin zu den Endeigentümern;

  - (b) die Beteiligungsübersicht, aus der die Eigentumsstruktur des Unternehmens hervorgeht;

  - (c) das Organ, das befugt ist (bzw. die Organe, die befugt sind), strategische Entscheidungen zu treffen (z. B. Hauptversammlung, Aufsichtsrat, Vorstände usw.);

  - (d) die Vorschriften für die Ernennung/Wahl/Abberufung von Leitungsorganen und die tatsächliche Zusammensetzung der Leitungsorgane (z. B. um festzustellen, ob ein Anteilseigner berechtigt ist, einen Vertreter des Vorstands zu nominieren, oder über die Mehrheit der Sitze im Vorstand verfügt);

  - (e) die für die Annahme strategischer Entscheidungen erforderlichen Beschlussfähigkeiten und Mehrheiten, um festzustellen, ob ein Anteilseigner eine strategische Entscheidung treffen kann (entweder weil er über die dafür erforderliche Mehrheit verfügt oder weil er eine solche Entscheidung durch ein Veto oder andere besondere Rechte blockieren kann, selbst wenn er eine solche Entscheidung nicht allein durchsetzen kann usw.);

  - (f) den möglichen Einfluss auf strategische Entscheidungen durch Geschäftsbeziehungen, finanzielle Verbindungen oder andere Mittel usw.

- (2) Der geprüfte Anbieter sollte alle oben genannten Informationen auch von seinen Unterauftragnehmern anfordern und sie der Prüfstelle zur Verfügung stellen.

7.1. Bewertung der Eigentums- und Kontrollverhältnisse:

- (1) Der geprüfte Anbieter sollte der Prüfstelle folgende Belege in Bezug auf seinen Hauptsitz vorlegen:

  - (a) Standort und vollständige Anschrift des weltweiten Hauptsitzes und/oder der Unternehmenszentrale;

  - (b) die Standorte der Leitungs- und Verwaltungsstrukturen.

- (2) Der geprüfte Anbieter sollte der Prüfstelle folgende Belege in Bezug auf die Eigentumsstruktur und besondere Rechte vorlegen:

  - (a) Eine detaillierte Liste, in der alle Eigentümer aufgeführt sind, die

    - i) direkt oder indirekt mindestens 5 % des Kapitals oder mindestens 5 % der Stimmrechte halten, auch durch jegliche Inhalte, Einvernehmen, Beziehungen oder Vermittler. Dies umfasst Stimmrechtsvereinbarungen zwischen Anteilseignern, die zusammen mehr als 5 % der Stimmrechte oder 5 % des Kapitals halten würden;

    - ii) über eines oder mehrere der folgenden besonderen Eigentumsrechte verfügen: a) Vetorecht bei der Übertragung von Anteilen; b) Vorkaufsrechte der Anteilseigner c) das Recht, zusätzliche Anteile zu erwerben sowie an Bedingungen geknüpfte Investitionen.

  - (b) Zur Bewertung der in Absatz 2 Buchstabe a genannten Elemente sollte die Prüfstelle die folgenden zusätzlichen Unterlagen anfordern:

    - i) Handelsregisterauszüge und Aktienbuch/Gesellschafterliste der Organisation sowie andere einschlägige Dokumente, aus denen die Anteilseigner und ihre Stimmrechte oder ihre prozentualen Anteile eindeutig hervorgehen;

    - ii) Aktionärs-/Gesellschaftervereinbarungen, Absichtserklärungen zwischen den Anteilseignern, Satzungen, Gesellschaftsverträge oder andere relevante Dokumente zu den Entscheidungsverfahren innerhalb des Rechtsträgers, Investitionsvereinbarungen zwischen den Anteilseignern usw.;

    - iii) Anteilseigner, die juristische Personen sind und mindestens 5 % des Kapitals oder mindestens 5 % der Stimmrechte halten:

      - (1) eine Grafik, in der die verschiedenen Eigentumsebenen/Kontrollketten bis hin zu den Endeigentümern dargestellt werden;

      - (2) die Gesellschaftsverträge, Satzungen oder gleichwertige Gründungsurkunden;

      - (3) ein Verzeichnis der Direktoren, Geschäftsführer und Unterzeichner.

- (3) Der geprüfte Anbieter sollte der Prüfstelle folgende Belege in Bezug auf die Unternehmensführung vorlegen:

  - (a) Der geprüfte Anbieter sollte der Prüfstelle eine Beschreibung folgender Aspekte vorlegen:

    - i) Entscheidungsgremien, ihre Zusammensetzung sowie Staatsangehörigkeit oder Niederlassungsort (falls zutreffend);

    - ii) Vorschriften über die Wahl, Ernennung, Nominierung oder Amtszeit der Mitglieder der Entscheidungsgremien oder anderer Führungspositionen;

    - iii) Entscheidungsverfahren, einschließlich Informationen über die erforderliche Mehrheiten und/oder die Beschlussfähigkeit;

    - iv) interne Führungsregelungen, in denen beschrieben wird, wie Entscheidungen in Bezug auf Eigentum und Kontrolle dokumentiert und genehmigt werden;

    - Entscheidungen des Vorstands und der Geschäftsleitung, die die angegebene Kontrollstruktur widerspiegeln;

    - Sitzungsprotokolle und Beschlüsse des Vorstands über Änderungen der Kontrollstruktur.

  - (b) Der geprüfte Anbieter sollte der Prüfstelle zusätzliche Unterlagen vorlegen, in denen Folgendes festgelegt oder beschrieben wird: die Entscheidungsgremien und die Vorschriften über deren Wahl, Ernennung, Nominierung oder Amtszeit, die Entscheidungsverfahren, Stimmrechte, Vetorechte, Ernennungsrechte und Genehmigungsrechte innerhalb des Rechtsträgers (z. B. Gesellschaftsverträge, Satzungen, Berichte über die Unternehmensführung usw.). Die zusätzlichen Unterlagen und Informationen sollten für jeden zwischengeschalteten Rechtsträger, der direkt oder indirekt mindestens 5 % des Kapitals oder der Stimmrechte hält, bis hin zu den Endeigentümern sämtlicher Ebenen vorgelegt werden.

- (4) Der geprüfte Anbieter sollte der Prüfstelle folgende Belege in Bezug auf die Kontrolle vorlegen:

  - (a) Der geprüfte Anbieter sollte der Prüfstelle Belege für Geschäftsbeziehungen vorlegen, durch die Kontrolle ausgeübt wird. Hierzu gehören unter anderem eine Liste der natürlichen oder juristischen Personen, mit denen die geprüften Anbieter (oder die Eigentümer des geprüften Anbieters, einschließlich zwischengeschalteter Ebenen bis hin zu den Endeigentümern) eine Geschäftsbeziehung unterhalten, die a) zu einem ähnlichen Maß an Kontrolle über Geschäftsleitung und Ressourcen führt wie das Eigentum an Anteilen oder Vermögenswerten und b) von sehr langer Dauer sind (z. B. besonders wichtige langfristige Liefervereinbarungen oder von Softwareherstellern oder Kunden bereitgestellte Kredite, die mit strukturellen Verbindungen einhergehen).

  - (b) Zu den zusätzlichen Unterlagen sollten auch Kooperationsabkommen mit der öffentlichen Stelle oder mit Softwareherstellern usw. gehören.

- (5) Der geprüfte Anbieter sollte der Prüfstelle Belege für finanzielle Verbindungen vorlegen, durch die Kontrolle ausgeübt wird:

  - (a) Der geprüfte Anbieter sollte die natürlichen oder juristischen Personen (einschließlich kontrollierender Anteilseigner oder Eigentümer) auflisten, von denen der geprüfte Anbieter (oder die Eigentümer) in einer Weise finanziell abhängig ist (bzw. sind), die es ihm (bzw. ihnen) ermöglichen könnte, in strategisch wichtigen Geschäftsbereichen Zugeständnisse zu erlangen.

  - (b) Zu den zusätzlichen Unterlagen sollten auch Darlehensunterlagen, Satzungen und Urkunden, aus denen die finanziellen Verbindungen hervorgeht, usw.

- (6) Der geprüfte Anbieter sollte der Prüfstelle Belege zu sonstigen Kontrollmöglichkeiten vorlegen:

  - (a) Die geprüften Anbieter sollten der Prüfstelle mitteilen, ob andere Mittel, Verfahren oder Verbindungen bestehen, durch die letztlich einem anderen Drittland oder einem in einem Drittland niedergelassenen Rechtsträger die Kontrolle übertragen wird (mit einem dem Eigentum an Anteilen oder Vermögenswerten vergleichbaren Maß an Kontrolle über Geschäftsleitung und Ressourcen und von langer Dauer).

  - (b) Aus den zusätzliche Unterlagen sollte hervorgehen, dass eine solche Kontrolle besteht, oder es sollte eine Erklärung enthalten sein, dass keine solche Kontrolle besteht (diese Erklärung kann vom Vorstand des Diensteanbieters vorgelegt werden).

Anmerkung: Bei der Bewertung der Kontrolle sollten die Eigentumsstrukturen und besonderen Rechte, die Unternehmensführung, kontrollbegründende Geschäftsbeziehungen, kontrollbegründende finanzielle Verbindungen sowie sonstige Kontrollmöglichkeiten berücksichtigt werden.

7.2. Weitere Schritte ausgehend von den Ergebnissen der Beurteilung von Eigentum und Kontrolle

Stellt die Prüfstelle fest, dass der geprüfte Anbieter der Kontrolle eines Drittlands oder eines Rechtsträgers aus einem Drittland unterliegt, sollte sie folgende zusätzliche Belege anfordern:

  - (c) den Nachweis dafür, dass die Kommission einen Beschluss gemäß Artikel 19 in Bezug auf das Drittland erlassen hat, dessen Kontrolle der Anbieter von Cloud-Computing-Diensten unterliegt;

  - (d) sämtliche Belege dafür, dass der geprüfte Anbieter und alle an der Erbringung des geprüften Dienstes beteiligten Unterauftragnehmer die erforderlichen Maßnahmen getroffen haben, um eine wirksame rechtliche, technische und organisatorische Trennung zwischen dem Anbieter von Cloud-Computing-Diensten und einem Drittland oder einem in einem Drittland niedergelassenen Rechtsträger durchzusetzen und um sicherzustellen, dass der Anbieter von Cloud-Computing-Diensten rechtlich, technisch und operativ nicht in der Lage ist, einem Verlangen nach Zugang zu Kundendaten, einschließlich verschlüsselter Daten, nachzukommen, die Kontinuität des Dienstes zu stören oder die Dienstqualität zu verschlechtern;

  - (e) sämtliche Belege dafür, dass die öffentliche Stelle über ein solches Verlangen unterrichtet wird, und eine Bestätigung, dass das Verlangen abgelehnt wurde;

  - (f) sämtliche Belege dafür, dass ein aktuelles Verzeichnis sämtlicher Verlangen eines Drittlands oder eines in einem Drittland niedergelassenen Rechtsträgers nach Zugang zu Kundendaten, Störung der Kontinuität des Dienstes oder Verschlechterung der Dienstqualität geführt wird, das mindestens das Verlangen und die Antwort darauf enthält.

8. Prüfkriterium H – Keine technische und operative Unterstützung außerhalb der Union

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe h aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Belege dafür, dass der geprüfte Anbieter verbindliche Vertragsklauseln umgesetzt hat, nach denen sämtliche Tätigkeiten in Bezug auf Unterstützung, Verwaltung, Wartung, Überwachung, Sicherheitsvorfälle sowie operative Tätigkeiten ausschließlich in der Union veranlasst und durchgeführt werden müssen. Hierzu können Vertragsklauseln gehören, nach denen alle Unterauftragnehmer und Standorte, an denen Unterstützungsdienste erbracht werden, vorab mitgeteilt werden müssen, vor der Beauftragung neuer Unterauftragnehmer eine vorherige schriftliche Genehmigung einzuholen ist und das Recht besteht, außerhalb der Union niedergelassene Unterauftragnehmer abzulehnen;

- (2) Belege dafür, dass der geprüfte Anbieter ein stets aktuelles Verzeichnis der Unterauftragnehmer führt;

- (3) Belege dafür, dass der geprüfte Anbieter solche Tätigkeiten nicht an Unterauftragnehmer außerhalb der Union vergibt oder überträgt;

- (4) Belege dafür, dass der geprüfte Anbieter die erforderlichen rechtlichen, technischen und organisatorischen Maßnahmen getroffen hat, um sicherzustellen, dass bei dem geprüften Dienst kein Fernzugriff für technische und operative Unterstützung von außerhalb der Union möglich ist.

- (5) Belege dafür, dass Helpdesk- und Unterstützungsdienste des geprüften Anbieters sowie seine Infrastrukturverwaltung, der Betrieb seines Sicherheitseinsatzzentrums (SOC) oder seiner Netzbetriebszentrale (NOC), die privilegierten Zugriffe, die Handhabung von Sicherungskopien und die Notfallwiederherstellungsvorgänge des geprüften Dienstes ausschließlich in der Union geleistet bzw. durchgeführt werden, einschließlich des Zugangswegs für den Betrieb des Dienstes;

- (6) Belege dafür, dass der geprüfte Anbieter sicherstellt, dass das Personal nach dem Verlassen des Unternehmens keinen weiteren Zugang zu dem geprüften Dienst mehr hat, und sämtliche Zugriffsberechtigungen widerrufen werden;

- (7) Belege dafür, dass der geprüfte Anbieter die erforderlichen technischen und organisatorischen Maßnahmen getroffen hat, um sicherzustellen, dass der administrative Zugang zu den Systemen, die für den Betrieb des geprüften Dienstes verwendet werden, über Zugangswege innerhalb der Union gewährt wird. Dies kann durch die Umsetzung einer geografisch begrenzten Netzsteuerung, eine in der Union angesiedelte Verwaltungsinfrastruktur, Kontrollen der Verwaltung des privilegierten Zugangs wie auch Überwachungsmechanismen nachgewiesen werden;

- (8) Belege dafür, dass der geprüfte Anbieter über Verfahren verfügt, mit denen sichergestellt wird, dass keine wirksame Kontrolle durch ein Drittland oder einem in einem Drittland niedergelassenen Rechtsträger besteht, auch im Falle einer nachträglichen weiteren Auslagerung.

9. Prüfkriterium I – Gewährleistung der Transparenz der Software-Lieferkette

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe i aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Der geprüfte Anbieter sollte der Prüfstelle eine vollständige und aktuelle Software-Stückliste für alle Softwarekomponenten, einschließlich quelloffener Software, zur Verfügung stellen.

- (2) Der geprüfte Anbieter sollte der Prüfstelle eine Liste der Abhängigkeiten zur Verfügung stellen. Diese sollte Folgendes umfassen:

  - (a) alle verwendeten Softwaremodule, Bibliotheken oder Anwendungsprogrammierschnittstellen (API) sowie alle Entwicklungswerkzeuge;

  - (b) Herkunft der Software: wo (Herkunftsland) und von wem die Software konzipiert, entwickelt und gewartet wird, der Vertriebsstandort, für den Vertrieb der Software maßgebliche Rechtsordnung und Aktualisierungen;

  - (c) Grad der Abhängigkeit von außereuropäischen Anbietern oder Einrichtungen oder von proprietären Technologien; für Stufe 3: Belege dafür, dass keine ungerechtfertigten Lizenzbeschränkungen bestehen, wenn der Software-Stack von einem Rechtsträger aus einem Drittland bereitgestellt wird;

  - (d) Grad der Abhängigkeit von quelloffener Software;

  - (e) Nachvollziehbarkeit der gesamten Kette der Softwarehersteller und -unterhersteller, einschließlich der Prüfrechte.

Anmerkung: Die vorstehend genannten Anforderungen bedeuten, dass Gemeinschaftsunternehmen, die sich z. B. aus einem Rechtsträger der Union und einem in einem Drittland niedergelassenen Rechtsträger zusammensetzen, für diese Stufe infrage kommen können.

- (3) Der geprüfte Anbieter sollte Folgendes vorlegen:

  - (a) Belege für ein risikobasiertes Verfahren zur Ermittlung und Minderung von Abhängigkeiten von externen Softwareherstellern, die für den Betrieb des Cloud-Computing-Dienstes relevant sind;

  - (b) Belege dafür, dass er eine oder mehrere alternative Softwarelösungen, einschließlich quelloffener Software, ermittelt hat. Kann keine gleichwertige Softwarelösung ermittelt werden, muss eine Lösung gefunden werden, die ein Mindestmaß an verfügbaren Funktionen gewährleistet. Es müssen Tests durchgeführt und es muss ein Umstellungsplan aufgestellt werden, der die Migration zu solchen alternativen Lösungen ermöglicht;

  - (c) Belege dafür, dass der geprüfte Anbieter im Falle eines Mangels oder Ausfalls des Software-Anbieters oder von Beschränkungen durch ein Drittland oder einen in einem Drittland niedergelassener Rechtsträger zu einer alternativen Lösung migrieren kann;

  - (d) eine Liste offener Standards, die als Teil der Regelungen der geprüften Anbieter in Bezug auf den geprüften Dienst befolgt werden;

- (4) Der geprüfte Anbieter sollte durch Fernzugriff und Nachprüfbarkeit des Quellcodes für Transparenz sorgen, indem er

  - (a) der Prüfstelle eine Liste von Belegen zur Verfügung stellt, aus denen hervorgeht, dass keine Fernzugriffsfunktionen oder -mechanismen verwendet werden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören. Diese sollte Folgendes umfassen:

    - i) Belege für die Tests von Softwarekomponenten, wodurch verhindert werden soll, dass Fernzugriffsfunktionen oder -mechanismen verwendet werden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören (Testverfahren, Testberichte, Testplan usw.);

    - ii) Belege dafür, dass die Änderungsmanagementverfahren der Organisation alle Firmware- und BIOS-Änderungen, Softwareaktualisierungen sowie die Integration neuer Komponenten umfassen, um den Einsatz von Fernzugriffsfunktionen oder -mechanismen zu unterbinden;

    - iii) Belege dafür, dass das Wartungsverfahren aktualisiert wird, um den Einsatz von Fernzugriffsfunktionen oder -mechanismen zu unterbinden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören.

  - (b) Der geprüfte Anbieter muss sicherstellen, dass dem unabhängigen externen Prüfer das Recht eingeräumt wird, auf den Quellcode einer solchen Software zuzugreifen und diesen zu prüfen. Der geprüfte Anbieter muss sicherstellen, dass der Prüfstelle sämtliche für die Bewertung und Prüfung des Quellcodes erforderlichen Unterlagen, technischen Materialien und Informationen vollständig, richtig und in einem zugänglichen Format zur Verfügung gestellt werden.

10. Prüfkriterium J – Quelloffene Software

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe j aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Der geprüfte Anbieter sollte durch Fernzugriff und Nachprüfbarkeit des Quellcodes für Transparenz sorgen, indem er

  - (a) der Prüfstelle eine Liste von Belegen zur Verfügung stellt, aus denen hervorgeht, dass keine Fernzugriffsfunktionen oder -mechanismen verwendet werden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören. Diese sollte Folgendes umfassen:

    - i) Belege für die Tests von Softwarekomponenten, wodurch verhindert werden soll, dass Fernzugriffsfunktionen oder -mechanismen verwendet werden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören (Testverfahren, Testberichte, Testplan usw.);

    - ii) Belege dafür, dass die Änderungsmanagementverfahren der Organisation alle Firmware- und BIOS-Änderungen, Softwareaktualisierungen sowie die Integration neuer Komponenten umfassen, um die Einsatz von Fernzugriffsfunktionen oder -mechanismen zu unterbinden;

    - iii) Belege dafür, dass das Wartungsverfahren aktualisiert wird, um den Einsatz von Fernzugriffsfunktionen oder -mechanismen zu unterbinden, die dazu eingesetzt werden könnten, ein Gerät, ein System oder eine Software wesentlich zu manipulieren oder zu stören.

- (2) Der geprüfte Anbieter sollte Folgendes vorlegen:

  - (a) Nachweis eines risikobasierten Prozesses zur Ermittlung und Minderung folgender Risiken: i) schwaches Ökosystems und schwache Gemeinschaftsunterstützung für quelloffene Software, ii) keine kontinuierliche Überwachung der veröffentlichten Aktualisierungen, iii) Verwendung quelloffener Software, die als veraltet gilt oder nicht mehr gepflegt wird;

  - (b) Belege dafür, dass der geprüfte Anbieter aktuelle Versionen der quelloffenen Software ohne unangemessene Verzögerung einsetzt;

  - (c) Belege dafür, dass der geprüfte Anbieter eine oder mehrere alternative quelloffene Lösungen ermittelt hat. Kann der geprüfte Anbieter keine gleichwertige Software ermitteln, muss er eine Lösung finden, die ein Mindestmaß an verfügbaren Funktionen gewährleistet. Der geprüfte Anbieter muss Tests durchführen und einen Umstellungsplan aufstellen, der die Migration zu alternativen Lösungen ermöglicht.

- (3) Verwendet der geprüfte Anbieter Software, die im Rahmen einer quelloffenen Lizenz freigegeben wurde, sollte er Mechanismen einrichten, um festzustellen, ob die Software von einem Drittland oder einem in einem Drittland niedergelassenen Rechtsträger (oder einer Stiftung) übernommen wird oder unter deren Kontrolle gerät, und die öffentliche Stelle hierüber rechtzeitig zu unterrichten.

11. Prüfkriterium K – Weltweite Dienste und Tochterunternehmen in Drittländern

Die Prüfstelle sollte das in Anhang II unter den Unionsvertrauenswürdigkeitsstufen 2, 3 und 4 jeweils in Buchstabe k aufgeführte Prüfkriterium anhand folgender Belege bewerten:

- (1) Die Prüfstelle sollte prüfen, dass das Tochterunternehmen rechtlich und operativ unabhängig vom geprüften Anbieter ist.

- (2) Der geprüfte Anbieter muss nachweisen, dass das Tochterunternehmen keinen Zugang zu Systemen hat, in denen Kundendaten verarbeitet oder gespeichert werden.

- (3) Der geprüfte Anbieter muss nachweisen, dass das Tochterunternehmen über keine privilegierten Konten in den Produktionsumgebungen der Union verfügt, einschließlich in den Bereichen Cloud-Verwaltung, Identitäts- und Zugriffsmanagement (IAM), Verwaltung privilegierter Zugänge (PAM), Überwachungs- oder Datenbankverwaltungsrechte.

- (4) Die Prüfstelle sollte prüfen, dass das Personal des Tochterunternehmens keinen Zugang zu Kundendaten in der Union erlangen kann.

- (5) Die Prüfstelle sollte prüfen, dass das Tochterunternehmen nicht befugt ist, das in der Union tätige Personal anzuweisen, Kundendaten offenzulegen oder Sicherheitsverfahren zu umgehen.

- (6) Die Prüfstelle sollte prüfen, dass alle bei dem Tochterunternehmen eingehenden Verlangen ausländischer Behörden förmlich an die zuständige Stelle in der Union zur rechtlichen Bewertung nach dem Unionsrecht und dem Recht der Mitgliedstaaten weitergeleitet werden.
