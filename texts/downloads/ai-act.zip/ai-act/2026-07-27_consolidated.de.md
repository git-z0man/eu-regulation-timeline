---
act: ai-act
version: 2026-07-27_consolidated
stage: consolidated
language: de
celex: 02024R1689-20260727
title: VERORDNUNG (EU) 2024/1689 DES EUROPÄISCHEN PARLAMENTS UND DES RATES vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz)
retrieved: '2026-11-09'
converter: tools/eurlex2md.py
counts:
  recitals: 0
  articles: 119
  annexes: 14
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:02024R1689-20260727
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# VERORDNUNG (EU) 2024/1689 DES EUROPÄISCHEN PARLAMENTS UND DES RATES vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz)

02024R1689 — DE — 27.07.2026 — 001.002

Dieser Text dient lediglich zu Informationszwecken und hat keine Rechtswirkung. Die EU-Organe übernehmen keine Haftung für seinen Inhalt. Verbindliche Fassungen der betreffenden Rechtsakte einschließlich ihrer Präambeln sind nur die im Amtsblatt der Europäischen Union veröffentlichten und auf EUR-Lex verfügbaren Texte. Diese amtlichen Texte sind über die Links in diesem Dokument unmittelbar zugänglich

Geändert durch:

- ►M1 VERORDNUNG (EU) 2026/1744 DES EUROPÄISCHEN PARLAMENTS UND DES RATES vom 8. Juli 2026 (ABl. L 1744, S. 1, 24.7.2026)

Berichtigt durch:

▼B

<a id="chapter-i"></a>
## Kapitel I – ALLGEMEINE BESTIMMUNGEN

<a id="art-1"></a>
### Artikel 1 – Gegenstand

(1) Zweck dieser Verordnung ist es, das Funktionieren des Binnenmarkts zu verbessern und die Einführung einer auf den Menschen ausgerichteten und vertrauenswürdigen künstlichen Intelligenz (KI) zu fördern und gleichzeitig ein hohes Schutzniveau in Bezug auf Gesundheit, Sicherheit und die in der Charta verankerten Grundrechte, einschließlich Demokratie, Rechtsstaatlichkeit und Umweltschutz, vor schädlichen Auswirkungen von KI-Systemen in der Union zu gewährleisten und die Innovation zu unterstützen.

(2) In dieser Verordnung wird Folgendes festgelegt:

- a) harmonisierte Vorschriften für das Inverkehrbringen, die Inbetriebnahme und die Verwendung von KI-Systemen in der Union;

- b) Verbote bestimmter Praktiken im KI-Bereich;

- c) besondere Anforderungen an Hochrisiko-KI-Systeme und Pflichten für Akteure in Bezug auf solche Systeme;

- d) harmonisierte Transparenzvorschriften für bestimmte KI-Systeme;

- e) harmonisierte Vorschriften für das Inverkehrbringen von KI-Modellen mit allgemeinem Verwendungszweck;

- f) Vorschriften für die Marktbeobachtung sowie die Governance und Durchsetzung der Marktüberwachung;

▼M1

- g) Maßnahmen zur Innovationsförderung mit besonderem Augenmerk auf kleinen Midcap-Unternehmen und kleinen und mittleren Unternehmen (KMU), einschließlich Start-up-Unternehmen.

▼B

<a id="art-2"></a>
### Artikel 2 – Anwendungsbereich

(1) Diese Verordnung gilt für

- a) Anbieter, die in der Union KI-Systeme in Verkehr bringen oder in Betrieb nehmen oder KI-Modelle mit allgemeinem Verwendungszweck in Verkehr bringen, unabhängig davon, ob diese Anbieter in der Union oder in einem Drittland niedergelassen sind;

- b) Betreiber von KI-Systemen, die ihren Sitz in der Union haben oder in der Union befinden;

- c) Anbieter und Betreiber von KI-Systemen, die ihren Sitz in einem Drittland haben oder sich in einem Drittland befinden, wenn die vom KI-System hervorgebrachte Ausgabe in der Union verwendet wird;

- d) Einführer und Händler von KI-Systemen;

- e) Produkthersteller, die KI-Systeme zusammen mit ihrem Produkt unter ihrem eigenen Namen oder ihrer Handelsmarke in Verkehr bringen oder in Betrieb nehmen;

- f) Bevollmächtigte von Anbietern, die nicht in der Union niedergelassen sind;

- g) betroffene Personen, die sich in der Union befinden.

▼M1

(2) Für KI-Systeme, die als Hochrisiko-KI-Systeme gemäß Artikel 6 Absatz 1 eingestuft sind und im Zusammenhang mit Produkten stehen, die unter die in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, gelten nur Artikel 6 Absatz 1, Artikel 60a und Artikel 102 bis 112. Die Artikel 57, 58 und 59 gelten nur, soweit die Anforderungen an Hochrisiko-KI-Systeme gemäß dieser Verordnung im Rahmen der genannten Harmonisierungsrechtsvorschriften der Union übernommen wurden.

▼B

(3) Diese Verordnung gilt nur in den unter das Unionsrecht fallenden Bereichen und berührt keinesfalls die Zuständigkeiten der Mitgliedstaaten in Bezug auf die nationale Sicherheit, unabhängig von der Art der Einrichtung, die von den Mitgliedstaaten mit der Wahrnehmung von Aufgaben im Zusammenhang mit diesen Zuständigkeiten betraut wurde.

Diese Verordnung gilt nicht für KI-Systeme, wenn und soweit sie ausschließlich für militärische Zwecke, Verteidigungszwecke oder Zwecke der nationalen Sicherheit in Verkehr gebracht, in Betrieb genommen oder, mit oder ohne Änderungen, verwendet werden, unabhängig von der Art der Einrichtung, die diese Tätigkeiten ausübt.

Diese Verordnung gilt nicht für KI-Systeme, die nicht in der Union in Verkehr gebracht oder in Betrieb genommen werden, wenn die Ausgaben in der Union ausschließlich für militärische Zwecke, Verteidigungszwecke oder Zwecke der nationalen Sicherheit verwendet werden, unabhängig von der Art der Einrichtung, die diese Tätigkeiten ausübt.

(4) Diese Verordnung gilt weder für Behörden in Drittländern noch für internationale Organisationen, die gemäß Absatz 1 in den Anwendungsbereich dieser Verordnung fallen, soweit diese Behörden oder Organisationen KI-Systeme im Rahmen der internationalen Zusammenarbeit oder internationaler Übereinkünfte im Bereich der Strafverfolgung und justiziellen Zusammenarbeit mit der Union oder mit einem oder mehreren Mitgliedstaaten verwenden und sofern ein solches Drittland oder eine solche internationale Organisation angemessene Garantien hinsichtlich des Schutz der Privatsphäre, der Grundrechte und der Grundfreiheiten von Personen bietet.

(5) Die Anwendung der Bestimmungen über die Haftung der Anbieter von Vermittlungsdiensten in Kapitel II der Verordnung 2022/2065 bleibt von dieser Verordnung unberührt.

(6) Diese Verordnung gilt nicht für KI-Systeme oder KI-Modelle, einschließlich ihrer Ausgabe, die eigens für den alleinigen Zweck der wissenschaftlichen Forschung und Entwicklung entwickelt und in Betrieb genommen werden.

▼M1

(7) Die Rechtsvorschriften der Union zum Schutz personenbezogener Daten, der Privatsphäre und der Vertraulichkeit der Kommunikation gelten für die Verarbeitung personenbezogener Daten im Zusammenhang mit den in dieser Verordnung festgelegten Rechten und Pflichten. Unbeschadet der Artikel 4a und 59 der vorliegenden Verordnung, berührt diese Verordnung nicht die Verordnung (EU) 2016/679 bzw. (EU) 2018/1725 oder die Richtlinie 2002/58/EG bzw. (EU) 2016/680.

▼B

(8) Diese Verordnung gilt nicht für Forschungs-, Test- und Entwicklungstätigkeiten zu KI-Systemen oder KI-Modellen, bevor diese in Verkehr gebracht oder in Betrieb genommen werden. Solche Tätigkeiten werden im Einklang mit dem geltenden Unionsrecht durchgeführt. Tests unter Realbedingungen fallen nicht unter diesen Ausschluss.

(9) Diese Verordnung berührt nicht die Vorschriften anderer Rechtsakte der Union zum Verbraucherschutz und zur Produktsicherheit.

(10) Diese Verordnung gilt nicht für die Pflichten von Betreibern, die natürliche Personen sind und KI-Systeme im Rahmen einer ausschließlich persönlichen und nicht beruflichen Tätigkeit verwenden.

(11) Diese Verordnung hindert die Union oder die Mitgliedstaaten nicht daran, Rechts- oder Verwaltungsvorschriften beizubehalten oder einzuführen, die für die Arbeitnehmer im Hinblick auf den Schutz ihrer Rechte bei der Verwendung von KI-Systemen durch die Arbeitgeber vorteilhafter sind, oder die Anwendung von Kollektivvereinbarungen zu fördern oder zuzulassen, die für die Arbeitnehmer vorteilhafter sind.

(12) Diese Verordnung gilt nicht für KI-Systeme, die unter freien und quelloffenen Lizenzen bereitgestellt werden, es sei denn, sie werden als Hochrisiko-KI-Systeme oder als ein KI-System, das unter Artikel 5 oder 50 fällt, in Verkehr gebracht oder in Betrieb genommen.

▼M1

(13) Für die in Artikel 6 Absatz 1 genannten Hochrisiko-KI-Systeme kann die Anwendung der in den Artikeln 9 bis 15 sowie 17 bis 25 festgelegten spezifischen Anforderungen oder Pflichten beschränkt werden, sofern und soweit

- a) in den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union Anforderungen oder bzw. Pflichten vorgesehen sind, die in Bezug auf Gesundheit, Sicherheit oder Grundrechte ein gleichwertiges oder höheres Schutzniveau bieten als die betreffende Anforderung bzw. Pflicht, und

- (b) eine solche Beschränkung nicht zu einer Verringerung des in dieser Verordnung vorgesehenen allgemeinen Schutzniveaus führt.

Die Kommission erlässt bis zum 2. August 2027 delegierte Rechtsakte gemäß Artikel 97 zur Ergänzung dieser Verordnung zu erlassen, um die betreffenden Hochrisiko-KI-Systeme, die Anforderungen oder Pflichten, die beschränkt werden können, die Bedingungen, unter denen eine solche Beschränkung gilt, und den Umfang der Beschränkung festzulegen.

▼B

<a id="art-3"></a>
### Artikel 3 – Begriffsbestimmungen

Für die Zwecke dieser Verordnung bezeichnet der Ausdruck

- 1. „KI-System“ ein maschinengestütztes System, das für einen in unterschiedlichem Grade autonomen Betrieb ausgelegt ist und das nach seiner Betriebsaufnahme anpassungsfähig sein kann und das aus den erhaltenen Eingaben für explizite oder implizite Ziele ableitet, wie Ausgaben wie etwa Vorhersagen, Inhalte, Empfehlungen oder Entscheidungen erstellt werden, die physische oder virtuelle Umgebungen beeinflussen können;

- 2. „Risiko“ die Kombination aus der Wahrscheinlichkeit des Auftretens eines Schadens und der Schwere dieses Schadens;

- 3. „Anbieter“ eine natürliche oder juristische Person, Behörde, Einrichtung oder sonstige Stelle, die ein KI-System oder ein KI-Modell mit allgemeinem Verwendungszweck entwickelt oder entwickeln lässt und es unter ihrem eigenen Namen oder ihrer Handelsmarke in Verkehr bringt oder das KI-System unter ihrem eigenen Namen oder ihrer Handelsmarke in Betrieb nimmt, sei es entgeltlich oder unentgeltlich;

- 4. „Betreiber“ eine natürliche oder juristische Person, Behörde, Einrichtung oder sonstige Stelle, die ein KI-System in eigener Verantwortung verwendet, es sei denn, das KI-System wird im Rahmen einer persönlichen und nicht beruflichen Tätigkeit verwendet;

- 5. „Bevollmächtigter“ eine in der Union ansässige oder niedergelassene natürliche oder juristische Person, die vom Anbieter eines KI-Systems oder eines KI-Modells mit allgemeinem Verwendungszweck schriftlich dazu bevollmächtigt wurde und sich damit einverstanden erklärt hat, in seinem Namen die in dieser Verordnung festgelegten Pflichten zu erfüllen bzw. Verfahren durchzuführen;

- 6. „Einführer“ eine in der Union ansässige oder niedergelassene natürliche oder juristische Person, die ein KI-System, das den Namen oder die Handelsmarke einer in einem Drittland niedergelassenen natürlichen oder juristischen Person trägt, in Verkehr bringt;

- 7. „Händler“ eine natürliche oder juristische Person in der Lieferkette, die ein KI-System auf dem Unionsmarkt bereitstellt, mit Ausnahme des Anbieters oder des Einführers;

- 8. „Akteur“ einen Anbieter, Produkthersteller, Betreiber, Bevollmächtigten, Einführer oder Händler;

- 9. „Inverkehrbringen“ die erstmalige Bereitstellung eines KI-Systems oder eines KI-Modells mit allgemeinem Verwendungszweck auf dem Unionsmarkt;

- 10. „Bereitstellung auf dem Markt“ die entgeltliche oder unentgeltliche Abgabe eines KI-Systems oder eines KI-Modells mit allgemeinem Verwendungszweck zum Vertrieb oder zur Verwendung auf dem Unionsmarkt im Rahmen einer Geschäftstätigkeit;

- 11. „Inbetriebnahme“ die Bereitstellung eines KI-Systems in der Union zum Erstgebrauch direkt an den Betreiber oder zum Eigengebrauch entsprechend seiner Zweckbestimmung;

- 12. „Zweckbestimmung“ die Verwendung, für die ein KI-System laut Anbieter bestimmt ist, einschließlich der besonderen Umstände und Bedingungen für die Verwendung, entsprechend den vom Anbieter bereitgestellten Informationen in den Betriebsanleitungen, im Werbe- oder Verkaufsmaterial und in diesbezüglichen Erklärungen sowie in der technischen Dokumentation;

- 13. „vernünftigerweise vorhersehbare Fehlanwendung“ die Verwendung eines KI-Systems in einer Weise, die nicht seiner Zweckbestimmung entspricht, die sich aber aus einem vernünftigerweise vorhersehbaren menschlichen Verhalten oder einer vernünftigerweise vorhersehbaren Interaktion mit anderen Systemen, auch anderen KI-Systemen, ergeben kann;

▼M1

- 14. „Sicherheitsbauteil“ einen Bestandteil eines Produkts oder KI-Systems, der eine Sicherheitsfunktion für dieses Produkt oder KI-System erfüllt oder dessen Ausfall oder Störung die Gesundheit und Sicherheit von Personen oder Eigentum gefährdet; für die Zwecke dieser Begriffsbestimmung erfüllt ein Bauteil dann eine Sicherheitsfunktion, wenn seine Zweckbestimmung darin besteht, Risiken für die Gesundheit und Sicherheit von Personen oder Eigentum abzuwenden oder zu mindern;

▼M1

- 14a. „Kleinst-, kleines oder mittleres Unternehmen“ oder „KMU“ ein Kleinstunternehmen, kleines oder mittleres Unternehmen im Sinne von Artikel 2 des Anhangs der Empfehlung 2003/361/EG;

- 14b. „kleines Midcap-Unternehmen“ ein kleines Unternehmen mit mittlerer Kapitalisierung im Sinne von Nummer 2 des Anhangs der Empfehlung (EU) 2025/1099;

▼B

- 15. „Betriebsanleitungen“ die Informationen, die der Anbieter bereitstellt, um den Betreiber insbesondere über die Zweckbestimmung und die ordnungsgemäße Verwendung eines KI-Systems zu informieren;

- 16. „Rückruf eines KI-Systems“ jede Maßnahme, die auf die Rückgabe an den Anbieter oder auf die Außerbetriebsetzung oder Abschaltung eines den Betreibern bereits zur Verfügung gestellten KI-Systems abzielt;

- 17. „Rücknahme eines KI-Systems“ jede Maßnahme, mit der die Bereitstellung eines in der Lieferkette befindlichen KI-Systems auf dem Markt verhindert werden soll;

- 18. „Leistung eines KI-Systems“ die Fähigkeit eines KI-Systems, seine Zweckbestimmung zu erfüllen;

- 19. „notifizierende Behörde“ die nationale Behörde, die für die Einrichtung und Durchführung der erforderlichen Verfahren für die Bewertung, Benennung und Notifizierung von Konformitätsbewertungsstellen und für deren Überwachung zuständig ist;

- 20. „Konformitätsbewertung“ ein Verfahren mit dem bewertet wird, ob die in Titel III Abschnitt 2 festgelegten Anforderungen an ein Hochrisiko-KI-System erfüllt wurden;

- 21. „Konformitätsbewertungsstelle“ eine Stelle, die Konformitätsbewertungstätigkeiten einschließlich Prüfungen, Zertifizierungen und Inspektionen durchführt und dabei als Dritte auftritt;

- 22. „notifizierte Stelle“ eine Konformitätsbewertungsstelle, die gemäß dieser Verordnung und den anderen einschlägigen Harmonisierungsrechtsvorschriften der Union notifiziert wurde;

- 23. „wesentliche Veränderung“ eine Veränderung eines KI-Systems nach dessen Inverkehrbringen oder Inbetriebnahme, die in der vom Anbieter durchgeführten ursprünglichen Konformitätsbewertung nicht vorgesehen oder geplant war und durch die die Konformität des KI-Systems mit den Anforderungen in Kapitel III Abschnitt 2 beeinträchtigt wird oder die zu einer Änderung der Zweckbestimmung führt, für die das KI-System bewertet wurde;

- 24. „CE-Kennzeichnung“ eine Kennzeichnung, durch die ein Anbieter erklärt, dass ein KI-System die Anforderungen erfüllt, die in Kapitel III Abschnitt 2 und in anderen anwendbaren Harmonisierungsrechtsvorschriften, die die Anbringung dieser Kennzeichnung vorsehen, festgelegt sind;

- 25. „System zur Beobachtung nach dem Inverkehrbringen“ alle Tätigkeiten, die Anbieter von KI-Systemen zur Sammlung und Überprüfung von Erfahrungen mit der Verwendung der von ihnen in Verkehr gebrachten oder in Betrieb genommenen KI-Systeme durchführen, um festzustellen, ob unverzüglich nötige Korrektur- oder Präventivmaßnahmen zu ergreifen sind;

- 26. „Marktüberwachungsbehörde“ die nationale Behörde, die die Tätigkeiten durchführt und die Maßnahmen ergreift, die in der Verordnung (EU) 2019/1020 vorgesehen sind;

- 27. „harmonisierte Norm“ bezeichnet eine harmonisierte Norm im Sinne des Artikels 2 Absatz 1 Buchstabe c der Verordnung (EU) Nr. 1025/2012;

- 28. „gemeinsame Spezifikation“ eine Reihe technischer Spezifikationen im Sinne des Artikels 2 Nummer 4 der Verordnung (EU) Nr. 1025/2012, deren Befolgung es ermöglicht, bestimmte Anforderungen der vorliegenden Verordnung zu erfüllen;

- 29. „Trainingsdaten“ Daten, die zum Trainieren eines KI-Systems verwendet werden, wobei dessen lernbare Parameter angepasst werden;

- 30. „Validierungsdaten“ Daten, die zur Evaluation des trainierten KI-Systems und zur Einstellung seiner nicht erlernbaren Parameter und seines Lernprozesses verwendet werden, um unter anderem eine Unter- oder Überanpassung zu vermeiden;

- 31. „Validierungsdatensatz“ einen separaten Datensatz oder einen Teil des Trainingsdatensatzes mit fester oder variabler Aufteilung;

- 32. „Testdaten“ Daten, die für eine unabhängige Bewertung des KI-Systems verwendet werden, um die erwartete Leistung dieses Systems vor dessen Inverkehrbringen oder Inbetriebnahme zu bestätigen;

- 33. „Eingabedaten“ die in ein KI-System eingespeisten oder von diesem direkt erfassten Daten, auf deren Grundlage das System eine Ausgabe hervorbringt;

- 34. „biometrische Daten“ mit speziellen technischen Verfahren gewonnene personenbezogene Daten zu den physischen, physiologischen oder verhaltenstypischen Merkmalen einer natürlichen Person, wie etwa Gesichtsbilder oder daktyloskopische Daten;

- 35. „biometrische Identifizierung“ die automatisierte Erkennung physischer, physiologischer, verhaltensbezogener oder psychologischer menschlicher Merkmale zum Zwecke der Feststellung der Identität einer natürlichen Person durch den Vergleich biometrischer Daten dieser Person mit biometrischen Daten von Personen, die in einer Datenbank gespeichert sind;

- 36. „biometrische Verifizierung“ die automatisierte Eins-zu-eins-Verifizierung, einschließlich Authentifizierung, der Identität natürlicher Personen durch den Vergleich ihrer biometrischen Daten mit zuvor bereitgestellten biometrischen Daten;

- 37. „besondere Kategorien personenbezogener Daten“ die in Artikel 9 Absatz 1der Verordnung (EU) 2016/679, Artikel 10 der Richtlinie (EU) 2016/680 und Artikel 10 Absatz 1 der Verordnung (EU) 2018/1725 aufgeführten Kategorien personenbezogener Daten;

- 38. „sensible operative Daten“ operative Daten im Zusammenhang mit Tätigkeiten zur Verhütung, Aufdeckung, Untersuchung oder Verfolgung von Straftaten, deren Offenlegung die Integrität von Strafverfahren gefährden könnte;

- 39. „Emotionserkennungssystem“ ein KI-System, das dem Zweck dient, Emotionen oder Absichten natürlicher Personen auf der Grundlage ihrer biometrischen Daten festzustellen oder daraus abzuleiten;

▼C1

- 40. „System zur biometrischen Kategorisierung“ ein KI-System, das dem Zweck dient, natürliche Personen auf der Grundlage ihrer biometrischen Daten bestimmten Kategorien zuzuordnen, sofern es sich nicht um eine Nebenfunktion eines anderen kommerziellen Dienstes handelt und aus objektiven technischen Gründen unbedingt erforderlich ist;

▼B

- 41. „biometrisches Fernidentifizierungssystem“ ein KI-System, das dem Zweck dient, natürliche Personen ohne ihre aktive Einbeziehung und in der Regel aus der Ferne durch Abgleich der biometrischen Daten einer Person mit den in einer Referenzdatenbank gespeicherten biometrischen Daten zu identifizieren;

- 42. „biometrisches Echtzeit-Fernidentifizierungssystem“ ein biometrisches Fernidentifizierungssystem, bei dem die Erfassung biometrischer Daten, der Abgleich und die Identifizierung ohne erhebliche Verzögerung erfolgen, und das zur Vermeidung einer Umgehung der Vorschriften nicht nur die sofortige Identifizierung, sondern auch eine Identifizierung mit begrenzten kurzen Verzögerungen umfasst;

- 43. „System zur nachträglichen biometrischen Fernidentifizierung“ ein biometrisches Fernidentifizierungssystem, das kein biometrisches Echtzeit-Fernidentifizierungssystem ist;

- 44. „öffentlich zugänglicher Raum“ einen einer unbestimmten Anzahl natürlicher Personen zugänglichen physischen Ort in privatem oder öffentlichem Eigentum, unabhängig davon, ob bestimmte Bedingungen für den Zugang gelten, und unabhängig von möglichen Kapazitätsbeschränkungen;

- 45. „Strafverfolgungsbehörde“

  - a) eine Behörde, die für die Verhütung, Ermittlung, Aufdeckung oder Verfolgung von Straftaten oder die Strafvollstreckung, einschließlich des Schutzes vor und der Abwehr von Gefahren für die öffentliche Sicherheit, zuständig ist, oder

  - b) eine andere Stelle oder Einrichtung, der durch nationales Recht die Ausübung öffentlicher Gewalt und hoheitlicher Befugnisse zur Verhütung, Ermittlung, Aufdeckung oder Verfolgung von Straftaten oder zur Strafvollstreckung, einschließlich des Schutzes vor und der Abwehr von Gefahren für die öffentliche Sicherheit, übertragen wurde;

- 46. „Strafverfolgung“ Tätigkeiten der Strafverfolgungsbehörden oder in deren Auftrag zur Verhütung, Ermittlung, Aufdeckung oder Verfolgung von Straftaten oder zur Strafvollstreckung, einschließlich des Schutzes vor und der Abwehr von Gefahren für die öffentliche Sicherheit;

- 47. „Büro für Künstliche Intelligenz“ die Aufgabe der Kommission, zur Umsetzung, Beobachtung und Überwachung von KI-Systemen und KI-Modellen mit allgemeinem Verwendungszweck und zu der im Beschluss der Kommission vom 24. Januar 2024 vorgesehenen KI-Governance beizutragen; Bezugnahmen in dieser Verordnung auf das Büro für Künstliche Intelligenz gelten als Bezugnahmen auf die Kommission;

- 48. „zuständige nationale Behörde“ eine notifizierende Behörde oder eine Marktüberwachungsbehörde; in Bezug auf KI-Systeme, die von Organen, Einrichtungen und sonstigen Stellen der Union in Betrieb genommen oder verwendet werden, sind Bezugnahmen auf die zuständigen nationalen Behörden oder Marktüberwachungsbehörden in dieser Verordnung als Bezugnahmen auf den Europäischen Datenschutzbeauftragten auszulegen;

- 49. „schwerwiegender Vorfall“ einen Vorfall oder eine Fehlfunktion bezüglich eines KI-Systems, das bzw. die direkt oder indirekt eine der nachstehenden Folgen hat:

  - a) den Tod oder die schwere gesundheitliche Schädigung einer Person;

  - b) eine schwere und unumkehrbare Störung der Verwaltung oder des Betriebs kritischer Infrastrukturen;

  - c) die Verletzung von Pflichten aus den Unionsrechtsvorschriften zum Schutz der Grundrechte;

  - d) schwere Sach- oder Umweltschäden;

- 50. „personenbezogene Daten“ personenbezogene Daten im Sinne von Artikel 4 Nummer 1 der Verordnung (EU) 2016/679;

- 51. „nicht personenbezogene Daten“ Daten, die keine personenbezogenen Daten im Sinne von Artikel 4 Nummer 1 der Verordnung (EU) 2016/679 sind;

- 52. „Profiling“ das Profiling im Sinne von Artikel 4 Nummer 4 der Verordnung (EU) 2016/679;

- 53. „Plan für einen Test unter Realbedingungen“ ein Dokument, in dem die Ziele, die Methodik, der geografische, bevölkerungsbezogene und zeitliche Umfang, die Überwachung, die Organisation und die Durchführung eines Tests unter Realbedingungen beschrieben werden;

- 54. „Plan für das Reallabor“ ein zwischen dem teilnehmenden Anbieter und der zuständigen Behörde vereinbartes Dokument, in dem die Ziele, die Bedingungen, der Zeitrahmen, die Methodik und die Anforderungen für die im Reallabor durchgeführten Tätigkeiten beschrieben werden;

- 55. „KI-Reallabor“ einen kontrollierten Rahmen, der von einer zuständigen Behörde geschaffen wird und den Anbieter oder zukünftige Anbieter von KI-Systemen nach einem Plan für das Reallabor einen begrenzten Zeitraum und unter regulatorischer Aufsicht nutzen können, um ein innovatives KI-System zu entwickeln, zu trainieren, zu validieren und — gegebenenfalls unter Realbedingungen — zu testen.

- 56. „KI-Kompetenz“ die Fähigkeiten, die Kenntnisse und das Verständnis, die es Anbietern, Betreibern und Betroffenen unter Berücksichtigung ihrer jeweiligen Rechte und Pflichten im Rahmen dieser Verordnung ermöglichen, KI-Systeme sachkundig einzusetzen sowie sich der Chancen und Risiken von KI und möglicher Schäden, die sie verursachen kann, bewusst zu werden.

- 57. „Test unter Realbedingungen“ den befristeten Test eines KI-Systems auf seine Zweckbestimmung, der unter Realbedingungen außerhalb eines Labors oder einer anderweitig simulierten Umgebung erfolgt, um zuverlässige und belastbare Daten zu erheben und die Konformität des KI-Systems mit den Anforderungen der vorliegenden Verordnung zu bewerten und zu überprüfen, wobei dieser Test nicht als Inverkehrbringen oder Inbetriebnahme des KI-Systems im Sinne dieser Verordnung gilt, sofern alle Bedingungen nach Artikel 57 oder Artikel 60 erfüllt sind;

- 58. „Testteilnehmer“ für die Zwecke eines Tests unter Realbedingungen eine natürliche Person, die an dem Test unter Realbedingungen teilnimmt;

- 59. „informierte Einwilligung“ eine aus freien Stücken erfolgende, spezifische, eindeutige und freiwillige Erklärung der Bereitschaft, an einem bestimmten Test unter Realbedingungen teilzunehmen, durch einen Testteilnehmer, nachdem dieser über alle Aspekte des Tests, die für die Entscheidungsfindung des Testteilnehmers bezüglich der Teilnahme relevant sind, aufgeklärt wurde;

- 60. „Deepfake“ einen durch KI erzeugten oder manipulierten Bild-, Ton- oder Videoinhalt, der wirklichen Personen, Gegenständen, Orten, Einrichtungen oder Ereignissen ähnelt und einer Person fälschlicherweise als echt oder wahrheitsgemäß erscheinen würde;

- 61. „weitverbreiteter Verstoß“ jede Handlung oder Unterlassung, die gegen das Unionsrecht verstößt, das die Interessen von Einzelpersonen schützt, und die

  - a) die kollektiven Interessen von Einzelpersonen in mindestens zwei anderen Mitgliedstaaten als dem Mitgliedstaat schädigt oder zu schädigen droht, in dem

    - i) die Handlung oder die Unterlassung ihren Ursprung hatte oder stattfand,

    - ii) der betreffende Anbieter oder gegebenenfalls sein Bevollmächtigter sich befindet oder niedergelassen ist oder

    - iii) der Betreiber niedergelassen ist, sofern der Verstoß vom Betreiber begangen wird,

  - b) die kollektiven Interessen von Einzelpersonen geschädigt hat, schädigt oder schädigen könnte und allgemeine Merkmale aufweist, einschließlich derselben rechtswidrigen Praxis oder desselben verletzten Interesses, und gleichzeitig auftritt und von demselben Akteur in mindestens drei Mitgliedstaaten begangen wird;

- 62. „kritische Infrastrukturen“ kritische Infrastrukturen im Sinne von Artikel 2 Nummer 4 der Richtlinie (EU) 2022/2557;

- 63. „KI-Modell mit allgemeinem Verwendungszweck“ ein KI-Modell — einschließlich der Fälle, in denen ein solches KI-Modell mit einer großen Datenmenge unter umfassender Selbstüberwachung trainiert wird —, das eine erhebliche allgemeine Verwendbarkeit aufweist und in der Lage ist, unabhängig von der Art und Weise seines Inverkehrbringens ein breites Spektrum unterschiedlicher Aufgaben kompetent zu erfüllen, und das in eine Vielzahl nachgelagerter Systeme oder Anwendungen integriert werden kann, ausgenommen KI-Modelle, die vor ihrem Inverkehrbringen für Forschungs- und Entwicklungstätigkeiten oder die Konzipierung von Prototypen eingesetzt werden;

- 64. „Fähigkeiten mit hoher Wirkkraft“ bezeichnet Fähigkeiten, die den bei den fortschrittlichsten KI-Modellen mit allgemeinem Verwendungszweck festgestellten Fähigkeiten entsprechen oder diese übersteigen;

- 65. „systemisches Risiko“ ein Risiko, das für die Fähigkeiten mit hoher Wirkkraft von KI-Modellen mit allgemeinem Verwendungszweck spezifisch ist und aufgrund deren Reichweite oder aufgrund tatsächlicher oder vernünftigerweise vorhersehbarer negativer Folgen für die öffentliche Gesundheit, die Sicherheit, die öffentliche Sicherheit, die Grundrechte oder die Gesellschaft insgesamt erhebliche Auswirkungen auf den Unionsmarkt hat, die sich in großem Umfang über die gesamte Wertschöpfungskette hinweg verbreiten können;

- 66. „KI-System mit allgemeinem Verwendungszweck“ ein KI-System, das auf einem KI-Modell mit allgemeinem Verwendungszweck beruht und in der Lage ist, einer Vielzahl von Zwecken sowohl für die direkte Verwendung als auch für die Integration in andere KI-Systeme zu dienen;

- 67. „Gleitkommaoperation“ jede Rechenoperation oder jede Zuweisung mit Gleitkommazahlen, bei denen es sich um eine Teilmenge der reellen Zahlen handelt, die auf Computern typischerweise durch das Produkt aus einer ganzen Zahl mit fester Genauigkeit und einer festen Basis mit ganzzahligem Exponenten dargestellt wird;

- 68. „nachgelagerter Anbieter“ einen Anbieter eines KI-Systems, einschließlich eines KI-Systems mit allgemeinem Verwendungszweck, das ein KI-Modell integriert, unabhängig davon, ob das KI-Modell von ihm selbst bereitgestellt und vertikal integriert wird oder von einer anderen Einrichtung auf der Grundlage vertraglicher Beziehungen bereitgestellt wird.

▼M1

<a id="art-4"></a>
### Artikel 4 – KI-Kompetenz

(1) Die Anbieter und Betreiber von KI-Systemen ergreifen Maßnahmen, um die Entwicklung der KI-Kompetenz ihres Personals und anderer Personen zu unterstützen, die in ihrem Auftrag mit dem Betrieb und der Nutzung von KI-Systemen befasst sind, wobei ihre technischen Kenntnisse, ihre Erfahrung, ihre Aus- und Fortbildung und der Kontext, in dem die KI-Systeme eingesetzt werden sollen, sowie die Personen oder Personengruppen, bei denen die KI-Systeme eingesetzt werden sollen, zu berücksichtigen sind. Diese Verpflichtung verpflichtet Anbieter oder Betreiber nicht, für irgendeine Person ein bestimmtes Niveau an KI-Kompetenz zu garantieren.

(2) Die Kommission und die Mitgliedstaaten unterstützen und fördern die Bemühungen der Anbieter und Betreiber von KI-Systemen und insbesondere von KMU, ihre Verpflichtung nach Absatz 1 dieses Artikels zu erfüllen. Zu diesem Zweck veröffentlicht die Kommission praktische Beispiele dafür, wie diese Verpflichtung erfüllt wird auf der in Artikel 62 Absatz 3 Buchstabe b genannten zentralen Informationsplattform.

(3) Das KI-Gremium nimmt unter Berücksichtigung der europäischen Kompetenzrahmen Empfehlungen an, um die Kommission und die Mitgliedstaaten unter anderem durch die Festlegung gemeinsamer Ziele bei der Förderung der KI-Kompetenz gemäß Absatz 1 zu unterstützen.

▼M1

<a id="art-4a"></a>
### Artikel 4a – Verarbeitung besonderer Kategorien personenbezogener Daten zur Erkennung und Korrektur von Verzerrungen

(1) Soweit dies zur Erkennung und Korrektur von Verzerrungen im Zusammenhang mit Hochrisiko-KI-Systemen im Einklang mit Artikel 10 Absatz 2 Buchstaben f und g dieser Verordnung unbedingt erforderlich ist, dürfen die Anbieter solcher Systeme ausnahmsweise besondere Kategorien personenbezogener Daten verarbeiten, wobei sie angemessene Vorkehrungen zum Schutz der Grundrechte und Grundfreiheiten natürlicher Personen treffen müssen. Zusätzlich zu den Bestimmungen der Verordnungen (EU) 2016/679 und (EU) 2018/1725 und der Richtlinie (EU) 2016/680, soweit zutreffend, müssen sämtliche der folgenden Bedingungen erfüllt sein, damit eine solche Verarbeitung stattfinden darf:

- a) Die Erkennung und Korrektur von Verzerrungen kann durch die Verarbeitung anderer Daten, einschließlich synthetischer oder anonymisierter Daten, nicht effektiv durchgeführt werden,

- b) die besonderen Kategorien personenbezogener Daten unterliegen technischen Beschränkungen bezüglich einer Weiterverwendung der personenbezogenen Daten und modernsten Sicherheits- und Datenschutzmaßnahmen, einschließlich Pseudonymisierung,

- c) die besonderen Kategorien personenbezogener Daten unterliegen Maßnahmen, mit denen sichergestellt wird, dass die verarbeiteten personenbezogenen Daten gesichert und geschützt und Gegenstand angemessener Sicherheitsvorkehrungen sind, wozu auch strenge Kontrollen des Zugriffs und seine Dokumentation gehören, um Missbrauch zu verhindern und sicherzustellen, dass nur befugte Personen, die zur Einhaltung entsprechender Vertraulichkeitspflichten verpflichtet sind, Zugang zu diesen personenbezogenen Daten haben,

- d) die besonderen Kategorien personenbezogener Daten werden nicht an Dritte übermittelt oder übertragen, noch haben diese Dritten anderweitigen Zugang zu diesen Daten,

- e) die besonderen Kategorien personenbezogener Daten werden gelöscht, sobald die Verzerrung korrigiert wurde oder das Ende der Speicherfrist für die personenbezogenen Daten erreicht ist, je nachdem, was zuerst eintritt, und

- f) die Aufzeichnungen über Verarbeitungstätigkeiten gemäß den Verordnungen (EU) 2016/679 und (EU) 2018/1725 und der Richtlinie (EU) 2016/680 enthalten die Gründe, warum die Verarbeitung besonderer Kategorien personenbezogener Daten für die Erkennung und Korrektur von Verzerrungen unbedingt erforderlich war und warum dieses Ziel mit der Verarbeitung anderer Daten nicht erreicht werden konnte.

(2) Anbieter und Betreiber anderer KI-Systeme und KI-Modelle und Betreiber von Hochrisiko-KI-Systemen dürfen ausnahmsweise besondere Kategorien personenbezogener Daten verarbeiten, sofern

- a) eine solche Verarbeitung zur Erkennung und Korrektur von Verzerrungen im Hinblick auf mögliche Verzerrungen unbedingt erforderlich ist, die die Gesundheit und Sicherheit von Personen beeinträchtigen, negative Auswirkungen hinsichtlich der Grundrechte haben oder zu einer gemäß den Rechtsvorschriften der Union verbotenen Diskriminierung führen, insbesondere wenn die Datenausgaben die Eingaben für künftige Operationen beeinflussen, und

- b) alle in Absatz 1 genannten Bedingungen und Vorkehrungen Anwendung finden.

Dieser Absatz begründet keine Verpflichtung, eine solche Erkennung und Korrektur von Verzerrungen vorzunehmen.

▼B

<a id="chapter-ii"></a>
## Kapitel II – VERBOTENE PRAKTIKEN IM KI-BEREICH

<a id="art-5"></a>
### Artikel 5 – Verbotene Praktiken im KI-Bereich

(1) Folgende Praktiken im KI-Bereich sind verboten:

- a) das Inverkehrbringen, die Inbetriebnahme oder die Verwendung eines KI-Systems, das Techniken der unterschwelligen Beeinflussung außerhalb des Bewusstseins einer Person oder absichtlich manipulative oder täuschende Techniken mit dem Ziel oder der Wirkung einsetzt, das Verhalten einer Person oder einer Gruppe von Personen wesentlich zu verändern, indem ihre Fähigkeit, eine fundierte Entscheidung zu treffen, deutlich beeinträchtigt wird, wodurch sie veranlasst wird, eine Entscheidung zu treffen, die sie andernfalls nicht getroffen hätte, und zwar in einer Weise, die dieser Person, einer anderen Person oder einer Gruppe von Personen erheblichen Schaden zufügt oder mit hinreichender Wahrscheinlichkeit zufügen wird.

- b) das Inverkehrbringen, die Inbetriebnahme oder die Verwendung eines KI-Systems, das eine Vulnerabilität oder Schutzbedürftigkeit einer natürlichen Person oder einer bestimmten Gruppe von Personen aufgrund ihres Alters, einer Behinderung oder einer bestimmten sozialen oder wirtschaftlichen Situation mit dem Ziel oder der Wirkung ausnutzt, das Verhalten dieser Person oder einer dieser Gruppe angehörenden Person in einer Weise wesentlich zu verändern, die dieser Person oder einer anderen Person erheblichen Schaden zufügt oder mit hinreichender Wahrscheinlichkeit zufügen wird;

▼M1

- ba) das Inverkehrbringen, die Inbetriebnahme oder die Verwendung eines KI-Systems, das realistische Bild-, Video-, Ton- oder ähnliche Inhalte erzeugt oder manipuliert, in denen intime Körperteile einer bestimmbaren natürlichen Person dargestellt werden oder eine an eindeutig sexuellen Handlungen beteiligte bestimmbare Person dargestellt wird, ohne dass die betreffende Person eine aus freien Stücken erfolgende, spezifische, aufgeklärte, eindeutige und ausdrückliche Zustimmung zu dieser Erzeugung oder Manipulation erteilt hat;

- bb) das Inverkehrbringen, die Inbetriebnahme oder die Verwendung eines KI-Systems, das Material oder Darbietungen im Sinne von Artikel 2 Buchstaben c und e der Richtlinie 2011/93/EU erzeugt oder manipuliert, es sei denn, nach nationalem Recht gilt das „unrechtmäßige“ Verhalten als gerechtfertigt;

▼B

- c) das Inverkehrbringen, die Inbetriebnahme oder die Verwendung von KI-Systemen zur Bewertung oder Einstufung von natürlichen Personen oder Gruppen von Personen über einen bestimmten Zeitraum auf der Grundlage ihres sozialen Verhaltens oder bekannter, abgeleiteter oder vorhergesagter persönlicher Eigenschaften oder Persönlichkeitsmerkmale, wobei die soziale Bewertung zu einem oder beiden der folgenden Ergebnisse führt:

  - i) Schlechterstellung oder Benachteiligung bestimmter natürlicher Personen oder Gruppen von Personen in sozialen Zusammenhängen, die in keinem Zusammenhang zu den Umständen stehen, unter denen die Daten ursprünglich erzeugt oder erhoben wurden;

  - ii) Schlechterstellung oder Benachteiligung bestimmter natürlicher Personen oder Gruppen von Personen in einer Weise, die im Hinblick auf ihr soziales Verhalten oder dessen Tragweite ungerechtfertigt oder unverhältnismäßig ist;

- d) das Inverkehrbringen, die Inbetriebnahme für diesen spezifischen Zweck oder die Verwendung eines KI-Systems zur Durchführung von Risikobewertungen in Bezug auf natürliche Personen, um das Risiko, dass eine natürliche Person eine Straftat begeht, ausschließlich auf der Grundlage des Profiling einer natürlichen Person oder der Bewertung ihrer persönlichen Merkmale und Eigenschaften zu bewerten oder vorherzusagen; dieses Verbot gilt nicht für KI-Systeme, die dazu verwendet werden, die durch Menschen durchgeführte Bewertung der Beteiligung einer Person an einer kriminellen Aktivität, die sich bereits auf objektive und überprüfbare Tatsachen stützt, die in unmittelbarem Zusammenhang mit einer kriminellen Aktivität stehen, zu unterstützen;

- e) das Inverkehrbringen, die Inbetriebnahme für diesen spezifischen Zweck oder die Verwendung von KI-Systemen, die Datenbanken zur Gesichtserkennung durch das ungezielte Auslesen von Gesichtsbildern aus dem Internet oder von Überwachungsaufnahmen erstellen oder erweitern;

- f) das Inverkehrbringen, die Inbetriebnahme für diesen spezifischen Zweck oder die Verwendung von KI-Systemen zur Ableitung von Emotionen einer natürlichen Person am Arbeitsplatz und in Bildungseinrichtungen, es sei denn, die Verwendung des KI-Systems soll aus medizinischen Gründen oder Sicherheitsgründen eingeführt oder auf den Markt gebracht werden;

- g) das Inverkehrbringen, die Inbetriebnahme für diesen spezifischen Zweck oder die Verwendung von Systemen zur biometrischen Kategorisierung, mit denen natürliche Personen individuell auf der Grundlage ihrer biometrischen Daten kategorisiert werden, um ihre Rasse, ihre politischen Einstellungen, ihre Gewerkschaftszugehörigkeit, ihre religiösen oder weltanschaulichen Überzeugungen, ihr Sexualleben oder ihre sexuelle Ausrichtung zu erschließen oder abzuleiten; dieses Verbot gilt nicht für die Kennzeichnung oder Filterung rechtmäßig erworbener biometrischer Datensätze, wie z. B. Bilder auf der Grundlage biometrischer Daten oder die Kategorisierung biometrischer Daten im Bereich der Strafverfolgung;

- h) die Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken, außer wenn und insoweit dies im Hinblick auf eines der folgenden Ziele unbedingt erforderlich ist:

  - i) gezielte Suche nach bestimmten Opfern von Entführung, Menschenhandel oder sexueller Ausbeutung sowie die Suche nach vermissten Personen;

  - ii) Abwenden einer konkreten, erheblichen und unmittelbaren Gefahr für das Leben oder die körperliche Unversehrtheit natürlicher Personen oder einer tatsächlichen und bestehenden oder tatsächlichen und vorhersehbaren Gefahr eines Terroranschlags;

  - iii) Aufspüren oder Identifizieren einer Person, die der Begehung einer Straftat verdächtigt wird, zum Zwecke der Durchführung von strafrechtlichen Ermittlungen oder von Strafverfahren oder der Vollstreckung einer Strafe für die in Anhang II aufgeführten Straftaten, die in dem betreffenden Mitgliedstaat nach dessen Recht mit einer Freiheitsstrafe oder einer freiheitsentziehenden Maßregel der Sicherung im Höchstmaß von mindestens vier Jahren bedroht ist.

Unterabsatz 1 Buchstabe h gilt unbeschadet des Artikels 9 der Verordnung (EU) 2016/679 für die Verarbeitung biometrischer Daten zu anderen Zwecken als der Strafverfolgung.

▼M1

(1a) Für die Zwecke von Absatz 1 Unterabsatz 1 Buchstaben ba und bb:

- a) Das Inverkehrbringen oder die Inbetriebnahme eines KI-Systems, das Material oder Darbietungen im Sinne von Absatz 1 Unterabsatz 1 Buchstaben ba oder bb generiert oder manipuliert, ist nur verboten, wenn

  - i) die Erzeugung oder Manipulation die Zweckbestimmung des KI-Systems sind oder

  - ii) aufgrund der Gestaltung, des Trainings, der Architektur, der Fähigkeiten oder der nutzerseitigen Funktionen des Systems diese Erzeugung oder Manipulation ein nach vernünftigem Ermessen absehbares und reproduzierbares Ergebnis ist, ohne dass erhebliche technische Änderungen erforderlich sind, und das System nicht über zumutbare und angemessene technische Sicherheitsmaßnahmen und andere Schutzvorkehrungen verfügt, um diese Erzeugung oder Manipulation unter Berücksichtigung einer nach vernünftigem Ermessen absehbaren missbräuchlichen Nutzung zuverlässig zu verhindern und eine beobachtete oder gemeldete missbräuchliche Nutzung zu korrigieren.

- b) Die Verwendung eines KI-Systems, mit dem Material oder Darbietungen im Sinne von Absatz 1 Unterabsatz 1 Buchstaben ba und bb erzeugt oder manipuliert werden, ist nur verboten, wenn der Betreiber das System zum Zwecke der Erzeugung oder der Manipulation solchen Materials oder solcher Darbietungen verwendet.

1b. Für die Zwecke von Absatz 1 Unterabsatz 1 Buchstabe ba gilt ein KI-System, mit dem das Material in einer Weise manipuliert wird, die die Sichtbarkeit der dargestellten intimen Körperteile weder erhöht noch die Art der dargestellten eindeutig sexuellen Handlungen verändert, nicht als manipulativ.

▼B

(2) Die Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken im Hinblick auf die in Absatz 1 Unterabsatz 1 Buchstabe h genannten Ziele darf für die in jenem Buchstaben genannten Zwecke nur zur Bestätigung der Identität der speziell betroffenen Person erfolgen, wobei folgende Elemente berücksichtigt werden:

- a) die Art der Situation, die der möglichen Verwendung zugrunde liegt, insbesondere die Schwere, die Wahrscheinlichkeit und das Ausmaß des Schadens, der entstehen würde, wenn das System nicht eingesetzt würde;

- b) die Folgen der Verwendung des Systems für die Rechte und Freiheiten aller betroffenen Personen, insbesondere die Schwere, die Wahrscheinlichkeit und das Ausmaß solcher Folgen.

Darüber hinaus sind bei der Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken im Hinblick auf die in Absatz 1 Unterabsatz 1 Buchstabe h des vorliegenden Artikels genannten Ziele notwendige und verhältnismäßige Schutzvorkehrungen und Bedingungen für die Verwendung im Einklang mit nationalem Recht über die Ermächtigung ihrer Verwendung einzuhalten, insbesondere in Bezug auf die zeitlichen, geografischen und personenbezogenen Beschränkungen. Die Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen ist nur dann zu gestatten, wenn die Strafverfolgungsbehörde eine Folgenabschätzung im Hinblick auf die Grundrechte gemäß Artikel 27 abgeschlossen und das System gemäß Artikel 49 in der EU-Datenbank registriert hat. In hinreichend begründeten dringenden Fällen kann jedoch mit der Verwendung solcher Systeme zunächst ohne Registrierung in der EU-Datenbank begonnen werden, sofern diese Registrierung unverzüglich erfolgt.

(3) Für die Zwecke des Absatz 1 Unterabsatz 1 Buchstabe h und des Absatzes 2 ist für jede Verwendung eines biometrischen Echtzeit-Fernidentifizierungssystems in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken eine vorherige Genehmigung erforderlich, die von einer Justizbehörde oder einer unabhängigen Verwaltungsbehörde des Mitgliedstaats, in dem die Verwendung erfolgen soll, auf begründeten Antrag und gemäß den in Absatz 5 genannten detaillierten nationalen Rechtsvorschriften erteilt wird, wobei deren Entscheidung bindend ist. In hinreichend begründeten dringenden Fällen kann jedoch mit der Verwendung eines solchen Systems zunächst ohne Genehmigung begonnen werden, sofern eine solche Genehmigung unverzüglich, spätestens jedoch innerhalb von 24 Stunden beantragt wird. Wird eine solche Genehmigung abgelehnt, so wird die Verwendung mit sofortiger Wirkung eingestellt und werden alle Daten sowie die Ergebnisse und Ausgaben dieser Verwendung unverzüglich verworfen und gelöscht.

Die zuständige Justizbehörde oder eine unabhängige Verwaltungsbehörde, deren Entscheidung bindend ist, erteilt die Genehmigung nur dann, wenn sie auf der Grundlage objektiver Nachweise oder eindeutiger Hinweise, die ihr vorgelegt werden, davon überzeugt ist, dass die Verwendung des betreffenden biometrischen Echtzeit-Fernidentifizierungssystems für das Erreichen eines der in Absatz 1 Unterabsatz 1 Buchstabe h genannten Ziele — wie im Antrag angegeben — notwendig und verhältnismäßig ist und insbesondere auf das in Bezug auf den Zeitraum sowie den geografischen und persönlichen Anwendungsbereich unbedingt erforderliche Maß beschränkt bleibt. Bei ihrer Entscheidung über den Antrag berücksichtigt diese Behörde die in Absatz 2 genannten Elemente. Eine Entscheidung, aus der sich eine nachteilige Rechtsfolge für eine Person ergibt, darf nicht ausschließlich auf der Grundlage der Ausgabe des biometrischen Echtzeit-Fernidentifizierungssystems getroffen werden.

(4) Unbeschadet des Absatzes 3 wird jede Verwendung eines biometrischen Echtzeit-Fernidentifizierungssystems in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken der zuständigen Marktüberwachungsbehörde und der nationalen Datenschutzbehörde gemäß den in Absatz 5 genannten nationalen Vorschriften mitgeteilt. Die Mitteilung muss mindestens die in Absatz 6 genannten Angaben enthalten und darf keine sensiblen operativen Daten enthalten.

(5) Ein Mitgliedstaat kann die Möglichkeit einer vollständigen oder teilweisen Ermächtigung zur Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken innerhalb der in Absatz 1 Unterabsatz 1 Buchstabe h sowie Absätze 2 und 3 aufgeführten Grenzen und unter den dort genannten Bedingungen vorsehen. Die betreffenden Mitgliedstaaten legen in ihrem nationalen Recht die erforderlichen detaillierten Vorschriften für die Beantragung, Erteilung und Ausübung der in Absatz 3 genannten Genehmigungen sowie für die entsprechende Beaufsichtigung und Berichterstattung fest. In diesen Vorschriften wird auch festgelegt, im Hinblick auf welche der in Absatz 1 Unterabsatz 1 Buchstabe h aufgeführten Ziele und welche der unter Buchstabe h Ziffer iii genannten Straftaten die zuständigen Behörden ermächtigt werden können, diese Systeme zu Strafverfolgungszwecken zu verwenden. Die Mitgliedstaaten teilen der Kommission diese Vorschriften spätestens 30 Tage nach ihrem Erlass mit. Die Mitgliedstaaten können im Einklang mit dem Unionsrecht strengere Rechtsvorschriften für die Verwendung biometrischer Fernidentifizierungssysteme erlassen.

(6) Die nationalen Marktüberwachungsbehörden und die nationalen Datenschutzbehörden der Mitgliedstaaten, denen gemäß Absatz 4 die Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken mitgeteilt wurden, legen der Kommission Jahresberichte über diese Verwendung vor. Zu diesem Zweck stellt die Kommission den Mitgliedstaaten und den nationalen Marktüberwachungs- und Datenschutzbehörden ein Muster zur Verfügung, das Angaben über die Anzahl der Entscheidungen der zuständigen Justizbehörden oder einer unabhängigen Verwaltungsbehörde, deren Entscheidung über Genehmigungsanträge gemäß Absatz 3 bindend ist, und deren Ergebnis enthält.

(7) Die Kommission veröffentlicht Jahresberichte über die Verwendung biometrischer Echtzeit-Fernidentifizierungssysteme in öffentlich zugänglichen Räumen zu Strafverfolgungszwecken, die auf aggregierten Daten aus den Mitgliedstaaten auf der Grundlage der in Absatz 6 genannten Jahresberichte beruhen. Diese Jahresberichte dürfen keine sensiblen operativen Daten im Zusammenhang mit den damit verbundenen Strafverfolgungsmaßnahmen enthalten.

(8) Dieser Artikel berührt nicht die Verbote, die gelten, wenn KI-Praktiken gegen andere Rechtsvorschriften der Union verstoßen.

<a id="chapter-iii"></a>
## Kapitel III – HOCHRISIKO-KI-SYSTEME

<a id="chapter-iii-section-1"></a>
## Abschnitt 1 – Einstufung von KI-Systemen als Hochrisiko-KI-Systeme

<a id="art-6"></a>
### Artikel 6 – Einstufungsvorschriften für Hochrisiko-KI-Systeme

(1) Ungeachtet dessen, ob ein KI-System unabhängig von den unter den Buchstaben a und b genannten Produkten in Verkehr gebracht oder in Betrieb genommen wird, gilt es als Hochrisiko-KI-System, wenn die beiden folgenden Bedingungen erfüllt sind:

- a) das KI-System soll als Sicherheitsbauteil eines unter die in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union fallenden Produkts verwendet werden oder das KI-System ist selbst ein solches Produkt;

- b) das Produkt, dessen Sicherheitsbauteil gemäß Buchstabe a das KI-System ist, oder das KI-System selbst als Produkt muss einer Konformitätsbewertung durch Dritte im Hinblick auf das Inverkehrbringen oder die Inbetriebnahme dieses Produkts gemäß den in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union unterzogen werden.

▼M1

(1a) Für die Zwecke dieser Verordnung, einschließlich des Absatzes 1 dieses Artikels, gelten KI-Systeme, die ausschließlich für nicht sicherheitsrelevante Aspekte der Nutzerunterstützung, Leistungsoptimierung, Leistungseffizienz, Automatisierung oder Benutzerfreundlichkeit oder Qualitätskontrolle verwendet werden, nicht als Sicherheitsbauteile.

▼C2

(1b) Ungeachtet des Absatzes 1a gelten KI-Systeme, deren Ausfall oder Fehlfunktion Gesundheit und Sicherheit gefährden würde, als Sicherheitsbauteile.

▼M1

(1c) Ein Produkt, das ausschließlich aufgrund anderer Risiken als Risiken für Gesundheit und Sicherheit einer Konformitätsbewertung durch Dritte unterzogen werden muss, insbesondere aufgrund von Risiken im Zusammenhang mit der Verbreitung von Funkfrequenzen oder elektromagnetischen Interferenzen, die Gesundheit und Sicherheit nicht beeinträchtigen, gilt nicht als Produkt, das die Bedingung in Absatz 1 Buchstabe b erfüllt.

▼B

(2) Zusätzlich zu den in Absatz 1 genannten Hochrisiko-KI-Systemen gelten die in Anhang III genannten KI-Systeme als hochriskant.

(3) Abweichend von Absatz 2 gilt ein in Anhang III genanntes KI-System nicht als hochriskant, wenn es kein erhebliches Risiko der Beeinträchtigung in Bezug auf die Gesundheit, Sicherheit oder Grundrechte natürlicher Personen birgt, indem es unter anderem nicht das Ergebnis der Entscheidungsfindung wesentlich beeinflusst.

Unterabsatz 1 gilt, wenn eine der folgenden Bedingungen erfüllt ist:

- a) das KI-System ist dazu bestimmt, eine eng gefasste Verfahrensaufgabe durchzuführen;

- b) das KI-System ist dazu bestimmt, das Ergebnis einer zuvor abgeschlossenen menschlichen Tätigkeit zu verbessern;

- c) das KI-System ist dazu bestimmt, Entscheidungsmuster oder Abweichungen von früheren Entscheidungsmustern zu erkennen, und ist nicht dazu gedacht, die zuvor abgeschlossene menschliche Bewertung ohne eine angemessene menschliche Überprüfung zu ersetzen oder zu beeinflussen; oder

- d) das KI-System ist dazu bestimmt, eine vorbereitende Aufgabe für eine Bewertung durchzuführen, die für die Zwecke der in Anhang III aufgeführten Anwendungsfälle relevant ist.

Ungeachtet des Unterabsatzes 1 gilt ein in Anhang III aufgeführtes KI-System immer dann als hochriskant, wenn es ein Profiling natürlicher Personen vornimmt.

(4) Ein Anbieter, der der Auffassung ist, dass ein in Anhang III aufgeführtes KI-System nicht hochriskant ist, dokumentiert seine Bewertung, bevor dieses System in Verkehr gebracht oder in Betrieb genommen wird. Dieser Anbieter unterliegt der Registrierungspflicht gemäß Artikel 49 Absatz 2. Auf Verlangen der zuständigen nationalen Behörden legt der Anbieter die Dokumentation der Bewertung vor.

(5) Die Kommission stellt nach Konsultation des Europäischen Gremiums für Künstliche Intelligenz (im Folgenden „KI-Gremium“) spätestens bis zum 2. Februar 2026 Leitlinien zur praktischen Umsetzung dieses Artikels gemäß Artikel 96 und eine umfassende Liste praktischer Beispiele für Anwendungsfälle für KI-Systeme, die hochriskant oder nicht hochriskant sind, bereit.

(6) Die Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zu erlassen, um Absatz 3 Unterabsatz 2 des vorliegenden Artikels zu ändern, indem neue Bedingungen zu den darin genannten Bedingungen hinzugefügt oder diese geändert werden, wenn konkrete und zuverlässige Beweise für das Vorhandensein von KI-Systemen vorliegen, die in den Anwendungsbereich von Anhang III fallen, jedoch kein erhebliches Risiko der Beeinträchtigung in Bezug auf die Gesundheit, Sicherheit oder Grundrechte natürlicher Personen bergen.

(7) Die Kommission erlässt gemäß Artikel 97 delegierte Rechtsakte, um Absatz 3 Unterabsatz 2 des vorliegenden Artikels zu ändern, indem eine der darin festgelegten Bedingungen gestrichen wird, wenn konkrete und zuverlässige Beweise dafür vorliegen, dass dies für die Aufrechterhaltung des Schutzniveaus in Bezug auf Gesundheit, Sicherheit und die in dieser Verordnung vorgesehenen Grundrechte erforderlich ist.

(8) Eine Änderung der in Absatz 3 Unterabsatz 2 festgelegten Bedingungen, die gemäß den Absätzen 6 und 7 des vorliegenden Artikels erlassen wurde, darf das allgemeine Schutzniveau in Bezug auf Gesundheit, Sicherheit und die in dieser Verordnung vorgesehenen Grundrechte nicht senken; dabei ist die Kohärenz mit den gemäß Artikel 7 Absatz 1 erlassenen delegierten Rechtsakten sicherzustellen und die Marktentwicklungen und die technologischen Entwicklungen sind zu berücksichtigen.

<a id="art-7"></a>
### Artikel 7 – Änderungen des Anhangs III

(1) Die Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zur Änderung von Anhang III durch Hinzufügung oder Änderung von Anwendungsfällen für Hochrisiko-KI-Systeme zu erlassen, die beide der folgenden Bedingungen erfüllen:

- a) Die KI-Systeme sollen in einem der in Anhang III aufgeführten Bereiche eingesetzt werden;

- b) die KI-Systeme bergen ein Risiko der Schädigung in Bezug auf die Gesundheit und Sicherheit oder haben nachteilige Auswirkungen auf die Grundrechte und dieses Risiko gleicht dem Risiko der Schädigung oder den nachteiligen Auswirkungen, das bzw. die von den in Anhang III bereits genannten Hochrisiko-KI-Systemen ausgeht bzw. ausgehen, oder übersteigt diese.

(2) Bei der Bewertung der Bedingung gemäß Absatz 1 Buchstabe b berücksichtigt die Kommission folgende Kriterien:

- a) die Zweckbestimmung des KI-Systems;

- b) das Ausmaß, in dem ein KI-System verwendet wird oder voraussichtlich verwendet werden wird;

- c) die Art und den Umfang der vom KI-System verarbeiteten und verwendeten Daten, insbesondere die Frage, ob besondere Kategorien personenbezogener Daten verarbeitet werden;

- d) das Ausmaß, in dem das KI-System autonom handelt, und die Möglichkeit, dass ein Mensch eine Entscheidung oder Empfehlungen, die zu einem potenziellen Schaden führen können, außer Kraft setzt;

- e) das Ausmaß, in dem durch die Verwendung eines KI-Systems schon die Gesundheit und Sicherheit geschädigt wurden, es nachteilige Auswirkungen auf die Grundrechte gab oder z. B. nach Berichten oder dokumentierten Behauptungen, die den zuständigen nationalen Behörden übermittelt werden, oder gegebenenfalls anderen Berichten Anlass zu erheblichen Bedenken hinsichtlich der Wahrscheinlichkeit eines solchen Schadens oder solcher nachteiligen Auswirkungen besteht;

- f) das potenzielle Ausmaß solcher Schäden oder nachteiligen Auswirkungen, insbesondere hinsichtlich ihrer Intensität und ihrer Eignung, mehrere Personen zu beeinträchtigen oder eine bestimmte Gruppe von Personen unverhältnismäßig stark zu beeinträchtigen;

- g) das Ausmaß, in dem Personen, die potenziell geschädigt oder negative Auswirkungen erleiden werden, von dem von einem KI-System hervorgebrachten Ergebnis abhängen, weil es insbesondere aus praktischen oder rechtlichen Gründen nach vernünftigem Ermessen unmöglich ist, sich diesem Ergebnis zu entziehen;

- h) das Ausmaß, in dem ein Machtungleichgewicht besteht oder in dem Personen, die potenziell geschädigt oder negative Auswirkungen erleiden werden, gegenüber dem Betreiber eines KI-Systems schutzbedürftig sind, insbesondere aufgrund von Status, Autorität, Wissen, wirtschaftlichen oder sozialen Umständen oder Alter;

- i) das Ausmaß, in dem das mithilfe eines KI-Systems hervorgebrachte Ergebnis unter Berücksichtigung der verfügbaren technischen Lösungen für seine Korrektur oder Rückgängigmachung leicht zu korrigieren oder rückgängig zu machen ist, wobei Ergebnisse, die sich auf die Gesundheit, Sicherheit oder Grundrechte von Personen negativ auswirken, nicht als leicht korrigierbar oder rückgängig zu machen gelten;

- j) das Ausmaß und die Wahrscheinlichkeit, dass der Einsatz des KI-Systems für Einzelpersonen, Gruppen oder die Gesellschaft im Allgemeinen, einschließlich möglicher Verbesserungen der Produktsicherheit, nützlich ist;

- k) das Ausmaß, in dem bestehendes Unionsrecht Folgendes vorsieht:

  - i) wirksame Abhilfemaßnahmen in Bezug auf die Risiken, die von einem KI-System ausgehen, mit Ausnahme von Schadenersatzansprüchen;

  - ii) wirksame Maßnahmen zur Vermeidung oder wesentlichen Verringerung dieser Risiken.

(3) Die Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zur Änderung der Liste in Anhang III zu erlassen, um Hochrisiko-KI-Systeme zu streichen, die beide der folgenden Bedingungen erfüllen:

- a) Das betreffende Hochrisiko-KI-System weist unter Berücksichtigung der in Absatz 2 aufgeführten Kriterien keine erheblichen Risiken mehr für die Grundrechte, Gesundheit oder Sicherheit auf;

- b) durch die Streichung wird das allgemeine Schutzniveau in Bezug auf Gesundheit, Sicherheit und Grundrechte im Rahmen des Unionsrechts nicht gesenkt.

<a id="chapter-iii-section-2"></a>
## Abschnitt 2 – Anforderungen an Hochrisiko-KI-Systeme

<a id="art-8"></a>
### Artikel 8 – Einhaltung der Anforderungen

(1) Hochrisiko-KI-Systeme müssen die in diesem Abschnitt festgelegten Anforderungen erfüllen, wobei ihrer Zweckbestimmung sowie dem allgemein anerkannten Stand der Technik in Bezug auf KI und KI-bezogene Technologien Rechnung zu tragen ist. Bei der Gewährleistung der Einhaltung dieser Anforderungen wird dem in Artikel 9 genannten Risikomanagementsystem Rechnung getragen.

(2) Enthält ein Produkt ein KI-System, für das die Anforderungen dieser Verordnung und die Anforderungen der in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union gelten, so sind die Anbieter dafür verantwortlich, sicherzustellen, dass ihr Produkt alle geltenden Anforderungen der geltenden Harmonisierungsrechtsvorschriften der Union vollständig erfüllt. Bei der Gewährleistung der Erfüllung der in diesem Abschnitt festgelegten Anforderungen durch die in Absatz 1 genannten Hochrisiko-KI-Systeme und im Hinblick auf die Gewährleistung der Kohärenz, der Vermeidung von Doppelarbeit und der Minimierung zusätzlicher Belastungen haben die Anbieter die Wahl, die erforderlichen Test- und Berichterstattungsverfahren, Informationen und Dokumentationen, die sie im Zusammenhang mit ihrem Produkt bereitstellen, gegebenenfalls in Dokumentationen und Verfahren zu integrieren, die bereits bestehen und gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union vorgeschrieben sind.

<a id="art-9"></a>
### Artikel 9 – Risikomanagementsystem

(1) Für Hochrisiko-KI-Systeme wird ein Risikomanagementsystem eingerichtet, angewandt, dokumentiert und aufrechterhalten.

(2) Das Risikomanagementsystem versteht sich als ein kontinuierlicher iterativer Prozess, der während des gesamten Lebenszyklus eines Hochrisiko-KI-Systems geplant und durchgeführt wird und eine regelmäßige systematische Überprüfung und Aktualisierung erfordert. Es umfasst folgende Schritte:

- a) die Ermittlung und Analyse der bekannten und vernünftigerweise vorhersehbaren Risiken, die vom Hochrisiko-KI-System für die Gesundheit, Sicherheit oder Grundrechte ausgehen können, wenn es entsprechend seiner Zweckbestimmung verwendet wird;

- b) die Abschätzung und Bewertung der Risiken, die entstehen können, wenn das Hochrisiko-KI-System entsprechend seiner Zweckbestimmung oder im Rahmen einer vernünftigerweise vorhersehbaren Fehlanwendung verwendet wird;

- c) die Bewertung anderer möglicherweise auftretender Risiken auf der Grundlage der Auswertung der Daten aus dem in Artikel 72 genannten System zur Beobachtung nach dem Inverkehrbringen;

- d) die Ergreifung geeigneter und gezielter Risikomanagementmaßnahmen zur Bewältigung der gemäß Buchstabe a ermittelten Risiken.

(3) Die in diesem Artikel genannten Risiken betreffen nur solche Risiken, die durch die Entwicklung oder Konzeption des Hochrisiko-KI-Systems oder durch die Bereitstellung ausreichender technischer Informationen angemessen gemindert oder behoben werden können.

(4) Bei den in Absatz 2 Buchstabe d genannten Risikomanagementmaßnahmen werden die Auswirkungen und möglichen Wechselwirkungen, die sich aus der kombinierten Anwendung der Anforderungen dieses Abschnitts ergeben, gebührend berücksichtigt, um die Risiken wirksamer zu minimieren und gleichzeitig ein angemessenes Gleichgewicht bei der Durchführung der Maßnahmen zur Erfüllung dieser Anforderungen sicherzustellen.

(5) Die in Absatz 2 Buchstabe d genannten Risikomanagementmaßnahmen werden so gestaltet, dass jedes mit einer bestimmten Gefahr verbundene relevante Restrisiko sowie das Gesamtrestrisiko der Hochrisiko-KI-Systeme als vertretbar beurteilt wird.

Bei der Festlegung der am besten geeigneten Risikomanagementmaßnahmen ist Folgendes sicherzustellen:

- a) soweit technisch möglich, Beseitigung oder Verringerung der gemäß Absatz 2 ermittelten und bewerteten Risiken durch eine geeignete Konzeption und Entwicklung des Hochrisiko-KI-Systems;

- b) gegebenenfalls Anwendung angemessener Minderungs- und Kontrollmaßnahmen zur Bewältigung nicht auszuschließender Risiken;

- c) Bereitstellung der gemäß Artikel 13 erforderlichen Informationen und gegebenenfalls entsprechende Schulung der Betreiber.

Zur Beseitigung oder Verringerung der Risiken im Zusammenhang mit der Verwendung des Hochrisiko-KI-Systems werden die technischen Kenntnisse, die Erfahrungen und der Bildungsstand, die vom Betreiber erwartet werden können, sowie der voraussichtliche Kontext, in dem das System eingesetzt werden soll, gebührend berücksichtigt.

(6) Hochrisiko-KI-Systeme müssen getestet werden, um die am besten geeigneten gezielten Risikomanagementmaßnahmen zu ermitteln. Durch das Testen wird sichergestellt, dass Hochrisiko-KI-Systeme stets im Einklang mit ihrer Zweckbestimmung funktionieren und die Anforderungen dieses Abschnitts erfüllen.

(7) Die Testverfahren können einen Test unter Realbedingungen gemäß Artikel 60 umfassen.

(8) Das Testen von Hochrisiko-KI-Systemen erfolgt zu jedem geeigneten Zeitpunkt während des gesamten Entwicklungsprozesses und in jedem Fall vor ihrem Inverkehrbringen oder ihrer Inbetriebnahme. Das Testen erfolgt anhand vorab festgelegter Metriken und Wahrscheinlichkeitsschwellenwerte, die für die Zweckbestimmung des Hochrisiko-KI-Systems geeignet sind.

(9) Bei der Umsetzung des in den Absätzen 1 bis 7 vorgesehenen Risikomanagementsystems berücksichtigen die Anbieter, ob angesichts seiner Zweckbestimmung das Hochrisiko-KI-System wahrscheinlich nachteilige Auswirkungen auf Personen unter 18 Jahren oder gegebenenfalls andere schutzbedürftige Gruppen haben wird.

(10) Bei Anbietern von Hochrisiko-KI-Systemen, die den Anforderungen an interne Risikomanagementprozesse gemäß anderen einschlägigen Bestimmungen des Unionsrechts unterliegen, können die in den Absätzen 1 bis 9 enthaltenen Aspekte Bestandteil der nach diesem Recht festgelegten Risikomanagementverfahren sein oder mit diesen Verfahren kombiniert werden.

<a id="art-10"></a>
### Artikel 10 – Daten und Daten-Governance

▼M1

(1) Hochrisiko-KI-Systeme, in denen Techniken eingesetzt werden, bei denen KI-Modelle mit Daten trainiert werden, müssen mit Trainings-, Validierungs- und Testdatensätzen entwickelt werden, die den in den Absätzen 2, 3 und 4 dieses Artikels und in Artikel 4a Absatz 1 genannten Qualitätskriterien entsprechen, wenn solche Datensätze verwendet werden.

▼B

(2) Für Trainings-, Validierungs- und Testdatensätze gelten Daten-Governance- und Datenverwaltungsverfahren, die für die Zweckbestimmung des Hochrisiko-KI-Systems geeignet sind. Diese Verfahren betreffen insbesondere

- a) die einschlägigen konzeptionellen Entscheidungen,

- b) die Datenerhebungsverfahren und die Herkunft der Daten und im Falle personenbezogener Daten den ursprünglichen Zweck der Datenerhebung,

- c) relevante Datenaufbereitungsvorgänge wie Annotation, Kennzeichnung, Bereinigung, Aktualisierung, Anreicherung und Aggregierung,

- d) die Aufstellung von Annahmen, insbesondere in Bezug auf die Informationen, die mit den Daten erfasst und dargestellt werden sollen,

- e) eine Bewertung der Verfügbarkeit, Menge und Eignung der benötigten Datensätze,

- f) eine Untersuchung im Hinblick auf mögliche Verzerrungen (Bias), die die Gesundheit und Sicherheit von Personen beeinträchtigen, sich negativ auf die Grundrechte auswirken oder zu einer nach den Rechtsvorschriften der Union verbotenen Diskriminierung führen könnten, insbesondere wenn die Datenausgaben die Eingaben für künftige Operationen beeinflussen,

- g) geeignete Maßnahmen zur Erkennung, Verhinderung und Abschwächung möglicher gemäß Buchstabe f ermittelter Verzerrungen,

- h) die Ermittlung relevanter Datenlücken oder Mängel, die der Einhaltung dieser Verordnung entgegenstehen, und wie diese Lücken und Mängel behoben werden können.

(3) Die Trainings-, Validierungs- und Testdatensätze müssen im Hinblick auf die Zweckbestimmung relevant, hinreichend repräsentativ und so weit wie möglich fehlerfrei und vollständig sein. Sie müssen die geeigneten statistischen Merkmale, gegebenenfalls auch bezüglich der Personen oder Personengruppen, für die das Hochrisiko-KI-System bestimmungsgemäß verwendet werden soll, haben. Diese Merkmale der Datensätze können auf der Ebene einzelner Datensätze oder auf der Ebene einer Kombination davon erfüllt werden.

(4) Die Datensätze müssen, soweit dies für die Zweckbestimmung erforderlich ist, die entsprechenden Merkmale oder Elemente berücksichtigen, die für die besonderen geografischen, kontextuellen, verhaltensbezogenen oder funktionalen Rahmenbedingungen, unter denen das Hochrisiko-KI-System bestimmungsgemäß verwendet werden soll, typisch sind.

▼M1 —————

▼M1

(6) Bei der Entwicklung von Hochrisiko-KI-Systemen, in denen keine Techniken eingesetzt werden, bei denen KI-Modelle trainiert werden, gelten die Absätze 2, 3 und 4 dieses Artikels und Artikel 4a Absatz 1 nur für Testdatensätze.

▼B

<a id="art-11"></a>
### Artikel 11 – Technische Dokumentation

(1) Die technische Dokumentation eines Hochrisiko-KI-Systems wird erstellt, bevor dieses System in Verkehr gebracht oder in Betrieb genommen wird, und ist auf dem neuesten Stand zu halten.

▼M1

Diese technische Dokumentation wird so erstellt, dass aus ihr der Nachweis hervorgeht, wie das Hochrisiko-KI-System die Anforderungen dieses Abschnitts erfüllt, und dass den zuständigen nationalen Behörden und den notifizierten Stellen die Informationen in klarer und verständlicher Form zur Verfügung stehen, die erforderlich sind, um zu beurteilen, ob das KI-System diese Anforderungen erfüllt. Sie enthält zumindest die in Anhang IV genannten Angaben. KMU, einschließlich Start-up-Unternehmen, und kleine Midcap-Unternehmen, können die in Anhang IV aufgeführten Elemente der technischen Dokumentation in vereinfachter Weise bereitstellen. Zu diesem Zweck erstellt die Kommission ein vereinfachtes Formular für die technische Dokumentation, das auf die Bedürfnisse von KMU, einschließlich Start-up-Unternehmen, und von kleinen Midcap-Unternehmen zugeschnitten ist. Entscheidet sich ein KMU, einschließlich Start-up-Unternehmen, oder ein kleines Midcap-Unternehmen für eine vereinfachte Bereitstellung der in Anhang IV vorgeschriebenen Angaben, so verwendet es das in diesem Absatz genannte Formular. Die notifizierten Stellen akzeptieren das Formular für die Zwecke der Konformitätsbewertung.

▼B

(2) Wird ein Hochrisiko-KI-System, das mit einem Produkt verbunden ist, das unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fällt, in Verkehr gebracht oder in Betrieb genommen, so wird eine einzige technische Dokumentation erstellt, die alle in Absatz 1 genannten Informationen sowie die nach diesen Rechtsakten erforderlichen Informationen enthält.

(3) Die Kommission ist befugt, wenn dies nötig ist, gemäß Artikel 97 delegierte Rechtsakte zur Änderung des Anhangs IV zu erlassen, damit die technische Dokumentation in Anbetracht des technischen Fortschritts stets alle Informationen enthält, die erforderlich sind, um zu beurteilen, ob das System die Anforderungen dieses Abschnitts erfüllt.

<a id="art-12"></a>
### Artikel 12 – Aufzeichnungspflichten

(1) Die Technik der Hochrisiko-KI-Systeme muss die automatische Aufzeichnung von Ereignissen (im Folgenden „Protokollierung“) während des Lebenszyklus des Systems ermöglichen.

(2) Zur Gewährleistung, dass das Funktionieren des Hochrisiko-KI-Systems in einem der Zweckbestimmung des Systems angemessenen Maße rückverfolgbar ist, ermöglichen die Protokollierungsfunktionen die Aufzeichnung von Ereignissen, die für Folgendes relevant sind:

- a) die Ermittlung von Situationen, die dazu führen können, dass das Hochrisiko-KI-System ein Risiko im Sinne des Artikels 79 Absatz 1 birgt oder dass es zu einer wesentlichen Änderung kommt,

- b) die Erleichterung der Beobachtung nach dem Inverkehrbringen gemäß Artikel 72 und

- c) die Überwachung des Betriebs der Hochrisiko-KI-Systeme gemäß Artikel 26 Absatz 5.

(3) Die Protokollierungsfunktionen der in Anhang III Nummer 1 Buchstabe a genannten Hochrisiko-KI-Systeme müssen zumindest Folgendes umfassen:

- a) Aufzeichnung jedes Zeitraums der Verwendung des Systems (Datum und Uhrzeit des Beginns und des Endes jeder Verwendung);

- b) die Referenzdatenbank, mit der das System die Eingabedaten abgleicht;

- c) die Eingabedaten, mit denen die Abfrage zu einer Übereinstimmung geführt hat;

- d) die Identität der gemäß Artikel 14 Absatz 5 an der Überprüfung der Ergebnisse beteiligten natürlichen Personen.

<a id="art-13"></a>
### Artikel 13 – Transparenz und Bereitstellung von Informationen für die Betreiber

(1) Hochrisiko-KI-Systeme werden so konzipiert und entwickelt, dass ihr Betrieb hinreichend transparent ist, damit die Betreiber die Ausgaben eines Systems angemessen interpretieren und verwenden können. Die Transparenz wird auf eine geeignete Art und in einem angemessenen Maß gewährleistet, damit die Anbieter und Betreiber ihre in Abschnitt 3 festgelegten einschlägigen Pflichten erfüllen können.

(2) Hochrisiko-KI-Systeme werden mit Betriebsanleitungen in einem geeigneten digitalen Format bereitgestellt oder auf andere Weise mit Betriebsanleitungen versehen, die präzise, vollständige, korrekte und eindeutige Informationen in einer für die Betreiber relevanten, barrierefrei zugänglichen und verständlichen Form enthalten.

(3) Die Betriebsanleitungen enthalten mindestens folgende Informationen:

- a) den Namen und die Kontaktangaben des Anbieters sowie gegebenenfalls seines Bevollmächtigten;

- b) die Merkmale, Fähigkeiten und Leistungsgrenzen des Hochrisiko-KI-Systems, einschließlich

  - i) seiner Zweckbestimmung,

  - ii) des Maßes an Genauigkeit — einschließlich diesbezüglicher Metriken —, Robustheit und Cybersicherheit gemäß Artikel 15, für das das Hochrisiko-KI-System getestet und validiert wurde und das zu erwarten ist, sowie aller bekannten und vorhersehbaren Umstände, die sich auf das erwartete Maß an Genauigkeit, Robustheit und Cybersicherheit auswirken können;

  - iii) aller bekannten oder vorhersehbaren Umstände bezüglich der Verwendung des Hochrisiko-KI-Systems im Einklang mit seiner Zweckbestimmung oder einer vernünftigerweise vorhersehbaren Fehlanwendung, die zu den in Artikel 9 Absatz 2 genannten Risiken für die Gesundheit und Sicherheit oder die Grundrechte führen können,

  - iv) gegebenenfalls der technischen Fähigkeiten und Merkmale des Hochrisiko-KI-Systems, um Informationen bereitzustellen, die zur Erläuterung seiner Ausgaben relevant sind;

  - v) gegebenenfalls seiner Leistung in Bezug auf bestimmte Personen oder Personengruppen, auf die das System bestimmungsgemäß angewandt werden soll;

  - vi) gegebenenfalls der Spezifikationen für die Eingabedaten oder sonstiger relevanter Informationen über die verwendeten Trainings-, Validierungs- und Testdatensätze, unter Berücksichtigung der Zweckbestimmung des Hochrisiko-KI-Systems;

  - vii) gegebenenfalls Informationen, die es den Betreibern ermöglichen, die Ausgabe des Hochrisiko-KI-Systems zu interpretieren und es angemessen zu nutzen;

- c) etwaige Änderungen des Hochrisiko-KI-Systems und seiner Leistung, die der Anbieter zum Zeitpunkt der ersten Konformitätsbewertung vorab bestimmt hat;

- d) die in Artikel 14 genannten Maßnahmen zur Gewährleistung der menschlichen Aufsicht, einschließlich der technischen Maßnahmen, die getroffen wurden, um den Betreibern die Interpretation der Ausgaben von Hochrisiko-KI-Systemen zu erleichtern;

- e) die erforderlichen Rechen- und Hardware-Ressourcen, die erwartete Lebensdauer des Hochrisiko-KI-Systems und alle erforderlichen Wartungs- und Pflegemaßnahmen einschließlich deren Häufigkeit zur Gewährleistung des ordnungsgemäßen Funktionierens dieses KI-Systems, auch in Bezug auf Software-Updates;

- f) gegebenenfalls eine Beschreibung der in das Hochrisiko-KI-System integrierten Mechanismen, die es den Betreibern ermöglicht, die Protokolle im Einklang mit Artikel 12 ordnungsgemäß zu erfassen, zu speichern und auszuwerten.

<a id="art-14"></a>
### Artikel 14 – Menschliche Aufsicht

(1) Hochrisiko-KI-Systeme werden so konzipiert und entwickelt, dass sie während der Dauer ihrer Verwendung — auch mit geeigneten Instrumenten einer Mensch-Maschine-Schnittstelle — von natürlichen Personen wirksam beaufsichtigt werden können.

(2) Die menschliche Aufsicht dient der Verhinderung oder Minimierung der Risiken für Gesundheit, Sicherheit oder Grundrechte, die entstehen können, wenn ein Hochrisiko-KI-System im Einklang mit seiner Zweckbestimmung oder im Rahmen einer vernünftigerweise vorhersehbaren Fehlanwendung verwendet wird, insbesondere wenn solche Risiken trotz der Einhaltung anderer Anforderungen dieses Abschnitts fortbestehen.

(3) Die Aufsichtsmaßnahmen müssen den Risiken, dem Grad der Autonomie und dem Kontext der Nutzung des Hochrisiko-KI-Systems angemessen sein und werden durch eine oder beide der folgenden Arten von Vorkehrungen gewährleistet:

- a) Vorkehrungen, die vor dem Inverkehrbringen oder der Inbetriebnahme vom Anbieter bestimmt und, sofern technisch machbar, in das Hochrisiko-KI-System eingebaut werden;

- b) Vorkehrungen, die vor dem Inverkehrbringen oder der Inbetriebnahme des Hochrisiko-KI-Systems vom Anbieter bestimmt werden und dazu geeignet sind, vom Betreiber umgesetzt zu werden.

(4) Für die Zwecke der Durchführung der Absätze 1, 2 und 3 wird das Hochrisiko-KI-System dem Betreiber so zur Verfügung gestellt, dass die natürlichen Personen, denen die menschliche Aufsicht übertragen wurde, angemessen und verhältnismäßig in der Lage sind,

- a) die einschlägigen Fähigkeiten und Grenzen des Hochrisiko-KI-Systems angemessen zu verstehen und seinen Betrieb ordnungsgemäß zu überwachen, einschließlich in Bezug auf das Erkennen und Beheben von Anomalien, Fehlfunktionen und unerwarteter Leistung;

- b) sich einer möglichen Neigung zu einem automatischen oder übermäßigen Vertrauen in die von einem Hochrisiko-KI-System hervorgebrachte Ausgabe („Automatisierungsbias“) bewusst zu bleiben, insbesondere wenn Hochrisiko-KI-Systeme Informationen oder Empfehlungen ausgeben, auf deren Grundlage natürliche Personen Entscheidungen treffen;

- c) die Ausgabe des Hochrisiko-KI-Systems richtig zu interpretieren, wobei beispielsweise die vorhandenen Interpretationsinstrumente und -methoden zu berücksichtigen sind;

- d) in einer bestimmten Situation zu beschließen, das Hochrisiko-KI-System nicht zu verwenden oder die Ausgabe des Hochrisiko-KI-Systems außer Acht zu lassen, außer Kraft zu setzen oder rückgängig zu machen;

- e) in den Betrieb des Hochrisiko-KI-Systems einzugreifen oder den Systembetrieb mit einer „Stopptaste“ oder einem ähnlichen Verfahren zu unterbrechen, was dem System ermöglicht, in einem sicheren Zustand zum Stillstand zu kommen.

(5) Bei den in Anhang III Nummer 1 Buchstabe a genannten Hochrisiko-KI-Systemen müssen die in Absatz 3 des vorliegenden Artikels genannten Vorkehrungen so gestaltet sein, dass außerdem der Betreiber keine Maßnahmen oder Entscheidungen allein aufgrund des vom System hervorgebrachten Identifizierungsergebnisses trifft, solange diese Identifizierung nicht von mindestens zwei natürlichen Personen, die die notwendige Kompetenz, Ausbildung und Befugnis besitzen, getrennt überprüft und bestätigt wurde.

Die Anforderung einer getrennten Überprüfung durch mindestens zwei natürliche Personen gilt nicht für Hochrisiko-KI-Systeme, die für Zwecke in den Bereichen Strafverfolgung, Migration, Grenzkontrolle oder Asyl verwendet werden, wenn die Anwendung dieser Anforderung nach Unionsrecht oder nationalem Recht unverhältnismäßig wäre.

<a id="art-15"></a>
### Artikel 15 – Genauigkeit, Robustheit und Cybersicherheit

(1) Hochrisiko-KI-Systeme werden so konzipiert und entwickelt, dass sie ein angemessenes Maß an Genauigkeit, Robustheit und Cybersicherheit erreichen und in dieser Hinsicht während ihres gesamten Lebenszyklus beständig funktionieren.

(2) Um die technischen Aspekte der Art und Weise der Messung des angemessenen Maßes an Genauigkeit und Robustheit gemäß Absatz 1 und anderer einschlägiger Leistungsmetriken anzugehen, fördert die Kommission in Zusammenarbeit mit einschlägigen Interessenträgern und Organisationen wie Metrologie- und Benchmarking-Behörden gegebenenfalls die Entwicklung von Benchmarks und Messmethoden.

(3) Die Maße an Genauigkeit und die relevanten Genauigkeitsmetriken von Hochrisiko-KI-Systemen werden in den ihnen beigefügten Betriebsanleitungen angegeben.

(4) Hochrisiko-KI-Systeme müssen so widerstandsfähig wie möglich gegenüber Fehlern, Störungen oder Unstimmigkeiten sein, die innerhalb des Systems oder der Umgebung, in der das System betrieben wird, insbesondere wegen seiner Interaktion mit natürlichen Personen oder anderen Systemen, auftreten können. In diesem Zusammenhang sind technische und organisatorische Maßnahmen zu ergreifen.

Die Robustheit von Hochrisiko-KI-Systemen kann durch technische Redundanz erreicht werden, was auch Sicherungs- oder Störungssicherheitspläne umfassen kann.

Hochrisiko-KI-Systeme, die nach dem Inverkehrbringen oder der Inbetriebnahme weiterhin dazulernen, sind so zu entwickeln, dass das Risiko möglicherweise verzerrter Ausgaben, die künftige Vorgänge beeinflussen („Rückkopplungsschleifen“), beseitigt oder so gering wie möglich gehalten wird und sichergestellt wird, dass auf solche Rückkopplungsschleifen angemessen mit geeigneten Risikominderungsmaßnahmen eingegangen wird.

(5) Hochrisiko-KI-Systeme müssen widerstandsfähig gegen Versuche unbefugter Dritter sein, ihre Verwendung, Ausgaben oder Leistung durch Ausnutzung von Systemschwachstellen zu verändern.

Die technischen Lösungen zur Gewährleistung der Cybersicherheit von Hochrisiko-KI-Systemen müssen den jeweiligen Umständen und Risiken angemessen sein.

Die technischen Lösungen für den Umgang mit KI-spezifischen Schwachstellen umfassen gegebenenfalls Maßnahmen, um Angriffe, mit denen versucht wird, eine Manipulation des Trainingsdatensatzes („data poisoning“) oder vortrainierter Komponenten, die beim Training verwendet werden („model poisoning“), vorzunehmen, Eingabedaten, die das KI-Modell zu Fehlern verleiten sollen („adversarial examples“ oder „model evasions“), Angriffe auf vertrauliche Daten oder Modellmängel zu verhüten, zu erkennen, darauf zu reagieren, sie zu beseitigen und zu kontrollieren.

<a id="chapter-iii-section-3"></a>
## Abschnitt 3 – Pflichten der Anbieter und Betreiber von Hochrisiko-KI-Systemen und anderer Beteiligter

<a id="art-16"></a>
### Artikel 16 – Pflichten der Anbieter von Hochrisiko-KI-Systemen

Anbieter von Hochrisiko-KI-Systemen müssen

- a) sicherstellen, dass ihre Hochrisiko-KI-Systeme die in Abschnitt 2 festgelegten Anforderungen erfüllen;

- b) auf dem Hochrisiko-KI-System oder, falls dies nicht möglich ist, auf seiner Verpackung oder in der beigefügten Dokumentation ihren Namen, ihren eingetragenen Handelsnamen bzw. ihre eingetragene Handelsmarke und ihre Kontaktanschrift angeben;

- c) über ein Qualitätsmanagementsystem verfügen, das Artikel 17 entspricht;

- d) die in Artikel 18 genannte Dokumentation aufbewahren;

- e) die von ihren Hochrisiko-KI-Systemen automatisch erzeugten Protokolle gemäß Artikel 19 aufbewahren, wenn diese ihrer Kontrolle unterliegen;

- f) sicherstellen, dass das Hochrisiko-KI-System dem betreffenden Konformitätsbewertungsverfahren gemäß Artikel 43 unterzogen wird, bevor es in Verkehr gebracht oder in Betrieb genommen wird;

- g) eine EU-Konformitätserklärung gemäß Artikel 47 ausstellen;

- h) die CE-Kennzeichnung an das Hochrisiko-KI-System oder, falls dies nicht möglich ist, auf seiner Verpackung oder in der beigefügten Dokumentation anbringen, um Konformität mit dieser Verordnung gemäß Artikel 48 anzuzeigen;

- i) den in Artikel 49 Absatz 1 genannten Registrierungspflichten nachkommen;

- j) die erforderlichen Korrekturmaßnahmen ergreifen und die gemäß Artikel 20 erforderlichen Informationen bereitstellen;

- k) auf begründete Anfrage einer zuständigen nationalen Behörde nachweisen, dass das Hochrisiko-KI-System die Anforderungen in Abschnitt 2 erfüllt;

- l) sicherstellen, dass das Hochrisiko-KI-System die Barrierefreiheitsanforderungen gemäß den Richtlinien (EU) 2016/2102 und (EU) 2019/882 erfüllt.

<a id="art-17"></a>
### Artikel 17 – Qualitätsmanagementsystem

(1) Anbieter von Hochrisiko-KI-Systemen richten ein Qualitätsmanagementsystem ein, das die Einhaltung dieser Verordnung gewährleistet. Dieses System wird systematisch und ordnungsgemäß in Form schriftlicher Regeln, Verfahren und Anweisungen dokumentiert und umfasst mindestens folgende Aspekte:

- a) ein Konzept zur Einhaltung der Regulierungsvorschriften, was die Einhaltung der Konformitätsbewertungsverfahren und der Verfahren für das Management von Änderungen an dem Hochrisiko-KI-System miteinschließt;

- b) Techniken, Verfahren und systematische Maßnahmen für den Entwurf, die Entwurfskontrolle und die Entwurfsprüfung des Hochrisiko-KI-Systems;

- c) Techniken, Verfahren und systematische Maßnahmen für die Entwicklung, Qualitätskontrolle und Qualitätssicherung des Hochrisiko-KI-Systems;

- d) Untersuchungs-, Test- und Validierungsverfahren, die vor, während und nach der Entwicklung des Hochrisiko-KI-Systems durchzuführen sind, und die Häufigkeit der Durchführung;

- e) die technischen Spezifikationen und Normen, die anzuwenden sind und, falls die einschlägigen harmonisierten Normen nicht vollständig angewandt werden oder sie nicht alle relevanten Anforderungen gemäß Abschnitt 2 abdecken, die Mittel, mit denen gewährleistet werden soll, dass das Hochrisiko-KI-System diese Anforderungen erfüllt;

- f) Systeme und Verfahren für das Datenmanagement, einschließlich Datengewinnung, Datenerhebung, Datenanalyse, Datenkennzeichnung, Datenspeicherung, Datenfilterung, Datenauswertung, Datenaggregation, Vorratsdatenspeicherung und sonstiger Vorgänge in Bezug auf die Daten, die im Vorfeld und für die Zwecke des Inverkehrbringens oder der Inbetriebnahme von Hochrisiko-KI-Systemen durchgeführt werden;

- g) das in Artikel 9 genannte Risikomanagementsystem;

- h) die Einrichtung, Anwendung und Aufrechterhaltung eines Systems zur Beobachtung nach dem Inverkehrbringen gemäß Artikel 72;

- i) Verfahren zur Meldung eines schwerwiegenden Vorfalls gemäß Artikel 73;

- j) die Handhabung der Kommunikation mit zuständigen nationalen Behörden, anderen einschlägigen Behörden, auch Behörden, die den Zugang zu Daten gewähren oder erleichtern, notifizierten Stellen, anderen Akteuren, Kunden oder sonstigen interessierten Kreisen;

- k) Systeme und Verfahren für die Aufzeichnung sämtlicher einschlägigen Dokumentation und Informationen;

- l) Ressourcenmanagement, einschließlich Maßnahmen im Hinblick auf die Versorgungssicherheit;

- m) einen Rechenschaftsrahmen, der die Verantwortlichkeiten der Leitung und des sonstigen Personals in Bezug auf alle in diesem Absatz aufgeführten Aspekte regelt.

▼M1

(2) Die Umsetzung der in Absatz 1 genannten Aspekte erfolgt in einem angemessenen Verhältnis zur Größe der Organisation des Anbieters, insbesondere wenn es sich bei dem Anbieter um ein KMU, einschließlich Start-up-Unternehmen, oder ein kleines Midcap-Unternehmen handelt. Die Anbieter müssen in jedem Fall den Grad der Strenge und das Schutzniveau einhalten, die erforderlich sind, um die Übereinstimmung ihrer Hochrisiko-KI-Systeme mit dieser Verordnung sicherzustellen.

▼B

(3) Anbieter von Hochrisiko-KI-Systemen, die Pflichten in Bezug auf Qualitätsmanagementsysteme oder eine gleichwertige Funktion gemäß den sektorspezifischen Rechtsvorschriften der Union unterliegen, können die in Absatz 1 aufgeführten Aspekte als Bestandteil der nach den genannten Rechtsvorschriften festgelegten Qualitätsmanagementsysteme einbeziehen.

(4) Bei Anbietern, die Finanzinstitute sind und gemäß den Rechtsvorschriften der Union über Finanzdienstleistungen Anforderungen in Bezug auf ihre Regelungen oder Verfahren der internen Unternehmensführung unterliegen, gilt die Pflicht zur Einrichtung eines Qualitätsmanagementsystems — mit Ausnahme des Absatzes 1 Buchstaben g, h und i des vorliegenden Artikels — als erfüllt, wenn die Vorschriften über Regelungen oder Verfahren der internen Unternehmensführung gemäß dem einschlägigen Unionsrecht über Finanzdienstleistungen eingehalten werden. Zu diesem Zweck werden die in Artikel 40 genannten harmonisierten Normen berücksichtigt.

<a id="art-18"></a>
### Artikel 18 – Aufbewahrung der Dokumentation

(1) Der Anbieter hält für einen Zeitraum von zehn Jahren ab dem Inverkehrbringen oder der Inbetriebnahme des Hochrisiko-KI-Systems folgende Unterlagen für die zuständigen nationalen Behörden bereit:

- a) die in Artikel 11 genannte technische Dokumentation;

- b) die Dokumentation zu dem in Artikel 17 genannten Qualitätsmanagementsystem;

- c) die Dokumentation über etwaige von notifizierten Stellen genehmigte Änderungen;

- d) gegebenenfalls die von den notifizierten Stellen ausgestellten Entscheidungen und sonstigen Dokumente;

- e) die in Artikel 47 genannte EU-Konformitätserklärung.

(2) Jeder Mitgliedstaat legt die Bedingungen fest, unter denen die in Absatz 1 genannte Dokumentation für die zuständigen nationalen Behörden für den in dem genannten Absatz angegebenen Zeitraum bereitgehalten wird, für den Fall, dass ein Anbieter oder sein in demselben Hoheitsgebiet niedergelassener Bevollmächtigter vor Ende dieses Zeitraums in Konkurs geht oder seine Tätigkeit aufgibt.

(3) Anbieter, die Finanzinstitute sind und gemäß dem Unionsrecht über Finanzdienstleistungen Anforderungen in Bezug auf ihre Regelungen oder Verfahren der internen Unternehmensführung unterliegen, pflegen die technische Dokumentation als Teil der gemäß dem Unionsrecht über Finanzdienstleistungen aufzubewahrenden Dokumentation.

<a id="art-19"></a>
### Artikel 19 – Automatisch erzeugte Protokolle

(1) Anbieter von Hochrisiko-KI-Systemen bewahren die von ihren Hochrisiko-KI-Systemen automatisch erzeugten Protokolle gemäß Artikel 12 Absatz 1 auf, soweit diese Protokolle ihrer Kontrolle unterliegen. Unbeschadet des geltenden Unionsrechts oder nationalen Rechts werden die Protokolle für einen der Zweckbestimmung des Hochrisiko-KI-Systems angemessenen Zeitraum von mindestens sechs Monaten aufbewahrt, sofern in den geltenden Rechtsvorschriften der Union, insbesondere im Unionsrecht zum Schutz personenbezogener Daten, oder im geltenden nationalen Recht nichts anderes vorgesehen ist.

(2) Anbieter, die Finanzinstitute sind und gemäß den Rechtsvorschriften der Union über Finanzdienstleistungen Anforderungen in Bezug auf ihre Regelungen oder Verfahren der internen Unternehmensführung, unterliegen, bewahren die von ihren Hochrisiko-KI-Systemen automatisch erzeugten Protokolle als Teil der gemäß dem einschlägigen Unionsrecht über Finanzdienstleistungen aufzubewahrenden Dokumentation auf.

<a id="art-20"></a>
### Artikel 20 – Korrekturmaßnahmen und Informationspflicht

(1) Anbieter von Hochrisiko-KI-Systemen, die der Auffassung sind oder Grund zu der Annahme haben, dass ein von ihnen in Verkehr gebrachtes oder in Betrieb genommenes Hochrisiko-KI-System nicht dieser Verordnung entspricht, ergreifen unverzüglich die erforderlichen Korrekturmaßnahmen, um die Konformität dieses Systems herzustellen oder es gegebenenfalls zurückzunehmen, zu deaktivieren oder zurückzurufen. Sie informieren die Händler des betreffenden Hochrisiko-KI-Systems und gegebenenfalls die Betreiber, den Bevollmächtigten und die Einführer darüber.

(2) Birgt das Hochrisiko-KI-System ein Risiko im Sinne des Artikels 79 Absatz 1 und wird sich der Anbieter des Systems dieses Risikos bewusst, so führt er unverzüglich gegebenenfalls gemeinsam mit dem meldenden Betreiber eine Untersuchung der Ursachen durch und informiert er die Marktüberwachungsbehörden, in deren Zuständigkeit das betroffene Hochrisiko-KI-System fällt, und gegebenenfalls die notifizierte Stelle, die eine Bescheinigung für dieses Hochrisiko-KI-System gemäß Artikel 44 ausgestellt hat, insbesondere über die Art der Nichtkonformität und über bereits ergriffene relevante Korrekturmaßnahmen.

<a id="art-21"></a>
### Artikel 21 – Zusammenarbeit mit den zuständigen Behörden

(1) Anbieter von Hochrisiko-KI-Systemen übermitteln einer zuständigen Behörde auf deren begründete Anfrage sämtliche Informationen und Dokumentation, die erforderlich sind, um die Konformität des Hochrisiko-KI-Systems mit den in Abschnitt 2 festgelegten Anforderungen nachzuweisen, und zwar in einer Sprache, die für die Behörde leicht verständlich ist und bei der es sich um eine der von dem betreffenden Mitgliedstaat angegebenen Amtssprachen der Institutionen der Union handelt.

(2) Auf begründete Anfrage einer zuständigen Behörde gewähren die Anbieter der anfragenden zuständigen Behörde gegebenenfalls auch Zugang zu den automatisch erzeugten Protokollen des Hochrisiko-KI-Systems gemäß Artikel 12 Absatz 1, soweit diese Protokolle ihrer Kontrolle unterliegen.

(3) Alle Informationen, die eine zuständige Behörde aufgrund dieses Artikels erhält, werden im Einklang mit den in Artikel 78 festgelegten Vertraulichkeitspflichten behandelt.

<a id="art-22"></a>
### Artikel 22 – Bevollmächtigte der Anbieter von Hochrisiko-KI-Systemen

(1) Anbieter, die in Drittländern niedergelassen sind, benennen vor der Bereitstellung ihrer Hochrisiko-KI-Systeme auf dem Unionsmarkt schriftlich einen in der Union niedergelassenen Bevollmächtigten.

(2) Der Anbieter muss seinem Bevollmächtigten ermöglichen, die Aufgaben wahrzunehmen, die im vom Anbieter erhaltenen Auftrag festgelegt sind.

(3) Der Bevollmächtigte nimmt die Aufgaben wahr, die in seinem vom Anbieter erhaltenen Auftrag festgelegt sind. Er stellt den Marktüberwachungsbehörden auf Anfrage eine Kopie des Auftrags in einer von der zuständigen Behörde angegebenen Amtssprache der Institutionen der Union bereit. Für die Zwecke dieser Verordnung ermächtigt der Auftrag den Bevollmächtigten zumindest zur Wahrnehmung folgender Aufgaben:

- a) Überprüfung, ob die in Artikel 47 genannte EU-Konformitätserklärung und die technische Dokumentation gemäß Artikel 11 erstellt wurden und ob der Anbieter ein angemessenes Konformitätsbewertungsverfahren durchgeführt hat;

- b) Bereithaltung — für einen Zeitraum von zehn Jahren ab dem Inverkehrbringen oder der Inbetriebnahme des Hochrisiko-KI-Systems — der Kontaktdaten des Anbieters, der den Bevollmächtigten benannt hat, eines Exemplars der in Artikel 47 genannten EU-Konformitätserklärung, der technischen Dokumentation und gegebenenfalls der von der notifizierten Stelle ausgestellten Bescheinigung für die zuständigen Behörden und die in Artikel 74 Absatz 10 genannten nationalen Behörden oder Stellen;

- c) Übermittlung sämtlicher — auch der unter Buchstabe b dieses Unterabsatzes genannten — Informationen und Dokumentation, die erforderlich sind, um die Konformität eines Hochrisiko-KI-Systems mit den in Abschnitt 2 festgelegten Anforderungen nachzuweisen, an eine zuständige Behörde auf deren begründete Anfrage, einschließlich der Gewährung des Zugangs zu den vom Hochrisiko-KI-System automatisch erzeugten Protokollen gemäß Artikel 12 Absatz 1, soweit diese Protokolle der Kontrolle des Anbieters unterliegen;

- d) Zusammenarbeit mit den zuständigen Behörden auf deren begründete Anfrage bei allen Maßnahmen, die Letztere im Zusammenhang mit dem Hochrisiko-KI-System ergreifen, um insbesondere die von dem Hochrisiko-KI-System ausgehenden Risiken zu verringern und abzumildern;

- e) gegebenenfalls die Einhaltung der Registrierungspflichten gemäß Artikel 49 Absatz 1 oder, falls die Registrierung vom Anbieter selbst vorgenommen wird, Sicherstellung der Richtigkeit der in Anhang VIII Abschnitt A Nummer 3 aufgeführten Informationen.

Mit dem Auftrag wird der Bevollmächtigte ermächtigt, neben oder anstelle des Anbieters als Ansprechpartner für die zuständigen Behörden in allen Fragen zu dienen, die die Gewährleistung der Einhaltung dieser Verordnung betreffen.

(4) Der Bevollmächtigte beendet den Auftrag, wenn er der Auffassung ist oder Grund zu der Annahme hat, dass der Anbieter gegen seine Pflichten gemäß dieser Verordnung verstößt. In diesem Fall informiert er unverzüglich die betreffende Marktüberwachungsbehörde und gegebenenfalls die betreffende notifizierte Stelle über die Beendigung des Auftrags und deren Gründe.

<a id="art-23"></a>
### Artikel 23 – Pflichten der Einführer

(1) Bevor sie ein Hochrisiko-KI-System in Verkehr bringen, stellen die Einführer sicher, dass das System dieser Verordnung entspricht, indem sie überprüfen, ob

- a) der Anbieter des Hochrisiko-KI-Systems das entsprechende Konformitätsbewertungsverfahren gemäß Artikel 43 durchgeführt hat;

- b) der Anbieter die technische Dokumentation gemäß Artikel 11 und Anhang IV erstellt hat;

- c) das System mit der erforderlichen CE-Kennzeichnung versehen ist und ihm die in Artikel 47 genannte EU-Konformitätserklärung und Betriebsanleitungen beigefügt sind;

- d) der Anbieter einen Bevollmächtigten gemäß Artikel 22 Absatz 1 benannt hat.

(2) Hat ein Einführer hinreichenden Grund zu der Annahme, dass ein Hochrisiko-KI-System nicht dieser Verordnung entspricht oder gefälscht ist oder diesem eine gefälschte Dokumentation beigefügt ist, so bringt er das System erst in Verkehr, nachdem dessen Konformität hergestellt wurde. Birgt das Hochrisiko-KI-System ein Risiko im Sinne des Artikels 79 Absatz 1, so informiert der Einführer den Anbieter des Systems, die Bevollmächtigten und die Marktüberwachungsbehörden darüber.

(3) Die Einführer geben ihren Namen, ihren eingetragenen Handelsnamen oder ihre eingetragene Handelsmarke und die Anschrift, unter der sie in Bezug auf das Hochrisiko-KI-System kontaktiert werden können, auf der Verpackung oder gegebenenfalls in der beigefügten Dokumentation an.

(4) Solange sich ein Hochrisiko-KI-System in ihrer Verantwortung befindet, gewährleisten Einführer, dass — soweit zutreffend — die Lagerungs- oder Transportbedingungen seine Konformität mit den in Abschnitt 2 festgelegten Anforderungen nicht beeinträchtigen.

(5) Die Einführer halten für einen Zeitraum von zehn Jahren ab dem Inverkehrbringen oder der Inbetriebnahme des Hochrisiko-KI-Systems ein Exemplar der von der notifizierten Stelle ausgestellten Bescheinigung sowie gegebenenfalls die Betriebsanleitungen und die in Artikel 47 genannte EU-Konformitätserklärung bereit.

(6) Die Einführer übermitteln den betreffenden nationalen Behörden auf deren begründete Anfrage sämtliche — auch die in Absatz 5 genannten — Informationen und Dokumentation, die erforderlich sind, um die Konformität des Hochrisiko-KI-Systems mit den in Abschnitt 2 festgelegten Anforderungen nachzuweisen, und zwar in einer Sprache, die für jene leicht verständlich ist. Zu diesem Zweck stellen sie auch sicher, dass diesen Behörden die technische Dokumentation zur Verfügung gestellt werden kann.

(7) Die Einführer arbeiten mit den betreffenden nationalen Behörden bei allen Maßnahmen zusammen, die diese Behörden im Zusammenhang mit einem von den Einführern in Verkehr gebrachten Hochrisiko-KI-System ergreifen, um insbesondere die von diesem System ausgehenden Risiken zu verringern und abzumildern.

<a id="art-24"></a>
### Artikel 24 – Pflichten der Händler

(1) Bevor Händler ein Hochrisiko-KI-System auf dem Markt bereitstellen, überprüfen sie, ob es mit der erforderlichen CE-Kennzeichnung versehen ist, ob ihm eine Kopie der in Artikel 47 genannten EU-Konformitätserklärung und Betriebsanleitungen beigefügt sind und ob der Anbieter und gegebenenfalls der Einführer dieses Systems ihre in Artikel 16 Buchstaben b und c sowie Artikel 23 Absatz 3 festgelegten jeweiligen Pflichten erfüllt haben.

(2) Ist ein Händler der Auffassung oder hat er aufgrund von Informationen, die ihm zur Verfügung stehen, Grund zu der Annahme, dass ein Hochrisiko-KI-System nicht den Anforderungen in Abschnitt 2 entspricht, so stellt er das Hochrisiko-KI-System erst auf dem Markt bereit, nachdem die Konformität des Systems mit den Anforderungen hergestellt wurde. Birgt das Hochrisiko-IT-System zudem ein Risiko im Sinne des Artikels 79 Absatz 1, so informiert der Händler den Anbieter bzw. den Einführer des Systems darüber.

(3) Solange sich ein Hochrisiko-KI-System in ihrer Verantwortung befindet, gewährleisten Händler, dass — soweit zutreffend — die Lagerungs- oder Transportbedingungen die Konformität des Systems mit den in Abschnitt 2 festgelegten Anforderungen nicht beeinträchtigen.

(4) Ein Händler, der aufgrund von Informationen, die ihm zur Verfügung stehen, der Auffassung ist oder Grund zu der Annahme hat, dass ein von ihm auf dem Markt bereitgestelltes Hochrisiko-KI-System nicht den Anforderungen in Abschnitt 2 entspricht, ergreift die erforderlichen Korrekturmaßnahmen, um die Konformität dieses Systems mit diesen Anforderungen herzustellen, es zurückzunehmen oder zurückzurufen, oder er stellt sicher, dass der Anbieter, der Einführer oder gegebenenfalls jeder relevante Akteur diese Korrekturmaßnahmen ergreift. Birgt das Hochrisiko-KI-System ein Risiko im Sinne des Artikels 79 Absatz 1, so informiert der Händler unverzüglich den Anbieter bzw. den Einführer des Systems sowie die für das betroffene Hochrisiko-KI-System zuständigen Behörden und macht dabei ausführliche Angaben, insbesondere zur Nichtkonformität und zu bereits ergriffenen Korrekturmaßnahmen.

(5) Auf begründete Anfrage einer betreffenden zuständigen Behörde übermitteln die Händler eines Hochrisiko-KI-Systems dieser Behörde sämtliche Informationen und Dokumentation in Bezug auf ihre Maßnahmen gemäß den Absätzen 1 bis 4, die erforderlich sind, um die Konformität dieses Systems mit den in Abschnitt 2 festgelegten Anforderungen nachzuweisen.

(6) Die Händler arbeiten mit den betreffenden zuständigen Behörden bei allen Maßnahmen zusammen, die diese Behörden im Zusammenhang mit einem von den Händlern auf dem Markt bereitgestellten Hochrisiko-KI-System ergreifen, um insbesondere das von diesem System ausgehende Risiko zu verringern oder abzumildern.

<a id="art-25"></a>
### Artikel 25 – Verantwortlichkeiten entlang der KI-Wertschöpfungskette

(1) In den folgenden Fällen gelten Händler, Einführer, Betreiber oder sonstige Dritte als Anbieter eines Hochrisiko-KI-Systems für die Zwecke dieser Verordnung und unterliegen den Anbieterpflichten gemäß Artikel 16:

- a) wenn sie ein bereits in Verkehr gebrachtes oder in Betrieb genommenes Hochrisiko-KI-System mit ihrem Namen oder ihrer Handelsmarke versehen, unbeschadet vertraglicher Vereinbarungen, die eine andere Aufteilung der Pflichten vorsehen;

- b) wenn sie eine wesentliche Veränderung eines Hochrisiko-KI-Systems, das bereits in Verkehr gebracht oder in Betrieb genommen wurde, so vornehmen, dass es weiterhin ein Hochrisiko-KI-System gemäß Artikel 6 bleibt;

- c) wenn sie die Zweckbestimmung eines KI-Systems, einschließlich eines KI-Systems mit allgemeinem Verwendungszweck, das nicht als hochriskant eingestuft wurde und bereits in Verkehr gebracht oder in Betrieb genommen wurde, so verändern, dass das betreffende KI-System zu einem Hochrisiko-KI-System im Sinne von Artikel 6 wird.

▼M1

(2) Unter den in Absatz 1 genannten Umständen gilt der Anbieter, der das KI-System ursprünglich in Verkehr gebracht oder in Betrieb genommen hatte, nicht mehr als Anbieter dieses spezifischen KI-Systems für die Zwecke dieser Verordnung.

Dieser Erstanbieter arbeitet eng mit neuen Anbietern zusammen, stellt die erforderlichen Informationen zur Verfügung und sorgt für den nach vernünftigem Ermessen zu erwartenden technischen Zugang und sonstige Unterstützung, die für die Erfüllung der in dieser Verordnung festgelegten Pflichten, insbesondere in Bezug auf die Konformitätsbewertung von Hochrisiko-KI-Systemen, erforderlich sind.

Die in Unterabsatz 2 festgelegte Verpflichtung umfasst, sofern dies für die dort genannten Zwecke relevant ist, insbesondere Folgendes:

- a) Bereitstellung technischer Unterlagen, die ausreichen, um die Einhaltung der in Artikel 16 festgelegten Anforderungen zu bewerten;

- b) Unterrichtung der neuen Anbieter über bekannte Einschränkungen und Fehlerarten und

- c) Bereitstellung eines gezielten technischen Zugangs für die neuen Anbieter, auch zu Test- und Validierungszwecken.

Dieser Absatz gilt nicht in Fällen, in denen der Erstanbieter eindeutig festgelegt hat, dass sein KI-System nicht in ein Hochrisiko-KI-System umgewandelt werden darf und daher nicht der Pflicht zur Zusammenarbeit mit neuen Anbietern und zur Übergabe der Dokumentation unterliegt.

▼B

(3) Im Falle von Hochrisiko-KI-Systemen, bei denen es sich um Sicherheitsbauteile von Produkten handelt, die unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, gilt der Produkthersteller als Anbieter des Hochrisiko-KI-Systems und unterliegt in den beiden nachfolgenden Fällen den Pflichten nach Artikel 16:

- a) Das Hochrisiko-KI-System wird zusammen mit dem Produkt unter dem Namen oder der Handelsmarke des Produktherstellers in Verkehr gebracht;

- b) das Hochrisiko-KI-System wird unter dem Namen oder der Handelsmarke des Produktherstellers in Betrieb genommen, nachdem das Produkt in Verkehr gebracht wurde.

▼M1

(4) Der Anbieter eines Hochrisiko-KI-Systems und der Dritte, der ein KI-System, ein KI-Modell, Instrumente, Dienste, Komponenten oder Verfahren bereitstellt, die in einem Hochrisiko-KI-System verwendet oder integriert werden, legen in einer schriftlichen Vereinbarung die Informationen, die Fähigkeiten, den technischen Zugang und die sonstige Unterstützung nach dem allgemein anerkannten Stand der Technik fest, die erforderlich sind, damit der Anbieter des Hochrisiko-KI-Systems die in dieser Verordnung festgelegten Pflichten vollständig erfüllen kann. Dieser Absatz gilt nicht für Dritte, die Instrumente, Dienste, Verfahren oder Komponenten, bei denen es sich nicht um KI-Modelle mit allgemeinem Verwendungszweck handelt, im Rahmen einer freien und quelloffenen Lizenz öffentlich zugänglich machen.

▼B

Das Büro für Künstliche Intelligenz kann freiwillige Musterbedingungen für Verträge zwischen Anbietern von Hochrisiko-KI-Systemen und Dritten, die Instrumente, Dienste, Komponenten oder Verfahren bereitstellen, die für Hochrisiko-KI-Systeme verwendet oder in diese integriert werden, ausarbeiten und empfehlen. Bei der Ausarbeitung dieser freiwilligen Musterbedingungen berücksichtigt das Büro für Künstliche Intelligenz mögliche vertragliche Anforderungen, die in bestimmten Sektoren oder Geschäftsfällen gelten. Die freiwilligen Musterbedingungen werden veröffentlicht und sind kostenlos in einem leicht nutzbaren elektronischen Format verfügbar.

(5) Die Absätze 2 und 3 berühren nicht die Notwendigkeit, Rechte des geistigen Eigentums, vertrauliche Geschäftsinformationen und Geschäftsgeheimnisse im Einklang mit dem Unionsrecht und dem nationalen Recht zu achten und zu schützen.

<a id="art-26"></a>
### Artikel 26 – Pflichten der Betreiber von Hochrisiko-KI-Systemen

(1) Die Betreiber von Hochrisiko-KI-Systemen treffen geeignete technische und organisatorische Maßnahmen, um sicherzustellen, dass sie solche Systeme entsprechend der den Systemen beigefügten Betriebsanleitungen und gemäß den Absätzen 3 und 6 verwenden.

(2) Die Betreiber übertragen natürlichen Personen, die über die erforderliche Kompetenz, Ausbildung und Befugnis verfügen, die menschliche Aufsicht und lassen ihnen die erforderliche Unterstützung zukommen.

(3) Die Pflichten nach den Absätzen 1 und 2 lassen sonstige Pflichten der Betreiber nach Unionsrecht oder nationalem Recht sowie die Freiheit der Betreiber bei der Organisation ihrer eigenen Ressourcen und Tätigkeiten zur Wahrnehmung der vom Anbieter angegebenen Maßnahmen der menschlichen Aufsicht unberührt.

(4) Unbeschadet der Absätze 1 und 2 und soweit die Eingabedaten ihrer Kontrolle unterliegen, sorgen die Betreiber dafür, dass die Eingabedaten der Zweckbestimmung des Hochrisiko-KI-Systems entsprechen und ausreichend repräsentativ sind.

(5) Die Betreiber überwachen den Betrieb des Hochrisiko-KI-Systems anhand der Betriebsanleitung und informieren gegebenenfalls die Anbieter gemäß Artikel 72. Haben Betreiber Grund zu der Annahme, dass die Verwendung gemäß der Betriebsanleitung dazu führen kann, dass dieses Hochrisiko-KI-System ein Risiko im Sinne des Artikels 79 Absatz 1 birgt, so informieren sie unverzüglich den Anbieter oder Händler und die zuständige Marktüberwachungsbehörde und setzen die Verwendung dieses Systems aus. Haben die Betreiber einen schwerwiegenden Vorfall festgestellt, informieren sie auch unverzüglich zuerst den Anbieter und dann den Einführer oder Händler und die zuständigen Marktüberwachungsbehörden über diesen Vorfall. Kann der Betreiber den Anbieter nicht erreichen, so gilt Artikel 73 entsprechend. Diese Pflicht gilt nicht für sensible operative Daten von Betreibern von KI-Systemen, die Strafverfolgungsbehörden sind.

Bei Betreibern, die Finanzinstitute sind und gemäß den Rechtsvorschriften der Union über Finanzdienstleistungen Anforderungen in Bezug auf ihre Regelungen oder Verfahren der internen Unternehmensführung, unterliegen, gilt die in Unterabsatz 1 festgelegte Überwachungspflicht als erfüllt, wenn die Vorschriften über Regelungen, Verfahren oder Mechanismen der internen Unternehmensführung gemäß einschlägigem Recht über Finanzdienstleistungen eingehalten werden.

(6) Betreiber von Hochrisiko-KI-Systemen bewahren die von ihrem Hochrisiko-KI-System automatisch erzeugten Protokolle, soweit diese Protokolle ihrer Kontrolle unterliegen, für einen der Zweckbestimmung des Hochrisiko-KI-Systems angemessenen Zeitraum von mindestens sechs Monaten auf, sofern im geltenden Unionsrecht, insbesondere im Unionsrecht über den Schutz personenbezogener Daten, oder im geltenden nationalen Recht nichts anderes bestimmt ist.

Betreiber, die Finanzinstitute sind und gemäß den Rechtsvorschriften der Union über Finanzdienstleistungen Anforderungen in Bezug auf ihre Regelungen oder Verfahren der internen Unternehmensführung unterliegen, bewahren die Protokolle als Teil der gemäß einschlägigem Unionsecht über Finanzdienstleistungen aufzubewahrenden Dokumentation auf.

(7) Vor der Inbetriebnahme oder Verwendung eines Hochrisiko-KI-Systems am Arbeitsplatz informieren Betreiber, die Arbeitgeber sind, die Arbeitnehmervertreter und die betroffenen Arbeitnehmer darüber, dass sie der Verwendung des Hochrisiko-KI-Systems unterliegen werden. Diese Informationen werden gegebenenfalls im Einklang mit den Vorschriften und Gepflogenheiten auf Unionsebene und nationaler Ebene in Bezug auf die Unterrichtung der Arbeitnehmer und ihrer Vertreter bereitgestellt.

(8) Betreiber von Hochrisiko-KI-Systemen, bei denen es sich um Organe, Einrichtungen oder sonstige Stellen der Union handelt, müssen den Registrierungspflichten gemäß Artikel 49 nachkommen. Stellen diese Betreiber fest, dass das Hochrisiko-KI-System, dessen Verwendung sie planen, nicht in der in Artikel 71 genannten EU-Datenbank registriert wurde, sehen sie von der Verwendung dieses Systems ab und informieren den Anbieter oder den Händler.

(9) Die Betreiber von Hochrisiko-KI-Systemen verwenden gegebenenfalls die gemäß Artikel 13 der vorliegenden Verordnung bereitgestellten Informationen, um ihrer Pflicht zur Durchführung einer Datenschutz-Folgenabschätzung gemäß Artikel 35 der Verordnung (EU) 2016/679 oder Artikel 27 der Richtlinie (EU) 2016/680 nachzukommen.

(10) Unbeschadet der Richtlinie (EU) 2016/680 beantragt der Betreiber eines Hochrisiko-KI-Systems zur nachträglichen biometrischen Fernfernidentifizierung im Rahmen von Ermittlungen zur gezielten Suche einer Person, die der Begehung einer Straftat verdächtigt wird oder aufgrund einer solchen verurteilt wurde, vorab oder unverzüglich, spätestens jedoch binnen 48 Stunden bei einer Justizbehörde oder einer Verwaltungsbehörde, deren Entscheidung bindend ist und einer justiziellen Überprüfung unterliegt, die Genehmigung für die Nutzung dieses Systems, es sei denn, es wird zur erstmaligen Identifizierung eines potenziellen Verdächtigen auf der Grundlage objektiver und nachprüfbarer Tatsachen, die in unmittelbarem Zusammenhang mit der Straftat stehen, verwendet. Jede Verwendung ist auf das für die Ermittlung einer bestimmten Straftat unbedingt erforderliche Maß zu beschränken.

Wird die gemäß Unterabsatz 1 beantragte Genehmigung abgelehnt, so wird die Verwendung des mit dieser beantragten Genehmigung verbundenen Systems zur nachträglichen biometrischen Fernidentifizierung mit sofortiger Wirkung eingestellt und werden die personenbezogenen Daten, die im Zusammenhang mit der Verwendung des Hochrisiko-KI-Systems stehen, für die die Genehmigung beantragt wurde, gelöscht.

In keinem Fall darf ein solches Hochrisiko-KI-System zur nachträglichen biometrischen Fernidentifizierung zu Strafverfolgungszwecken in nicht zielgerichteter Weise und ohne jeglichen Zusammenhang mit einer Straftat, einem Strafverfahren, einer tatsächlichen und bestehenden oder tatsächlichen und vorhersehbaren Gefahr einer Straftat oder der Suche nach einer bestimmten vermissten Person verwendet werden. Es muss sichergestellt werden, dass die Strafverfolgungsbehörden keine ausschließlich auf der Grundlage der Ausgabe solcher Systeme zur nachträglichen biometrischen Fernidentifizierung beruhende Entscheidung, aus der sich eine nachteilige Rechtsfolge für eine Person ergibt, treffen.

Dieser Absatz gilt unbeschadet des Artikels 9 der Verordnung (EU) 2016/679 und des Artikels 10 der Richtlinie (EU) 2016/680 für die Verarbeitung biometrischer Daten.

Unabhängig vom Zweck oder Betreiber wird jede Verwendung solcher Hochrisiko-KI-Systeme in der einschlägigen Polizeiakte dokumentiert und der zuständigen Marktüberwachungsbehörde und der nationalen Datenschutzbehörde auf Anfrage zur Verfügung gestellt, wovon die Offenlegung sensibler operativer Daten im Zusammenhang mit der Strafverfolgung ausgenommen ist. Dieser Unterabsatz berührt nicht die den Aufsichtsbehörden durch die Richtlinie (EU) 2016/680 übertragenen Befugnisse.

Die Betreiber legen den zuständigen Marktüberwachungsbehörden und den nationalen Datenschutzbehörden Jahresberichte über ihre Verwendung von Systemen zur nachträglichen biometrischen Fernidentifizierung vor, wovon die Offenlegung sensibler operativer Daten im Zusammenhang mit der Strafverfolgung ausgenommen ist. Die Berichte können eine Zusammenfassung sein, damit sie mehr als einen Einsatz abdecken.

Die Mitgliedstaaten können im Einklang mit dem Unionsrecht strengere Rechtsvorschriften für die Verwendung von Systemen zur nachträglichen biometrischen Fernidentifizierung erlassen.

(11) Unbeschadet des Artikels 50 der vorliegenden Verordnung informieren die Betreiber der in Anhang III aufgeführten Hochrisiko-KI-Systeme, die natürliche Personen betreffende Entscheidungen treffen oder bei solchen Entscheidungen Unterstützung leisten, die natürlichen Personen darüber, dass sie der Verwendung des Hochrisiko-KI-Systems unterliegen. Für Hochrisiko-KI-Systeme, die zu Strafverfolgungszwecken verwendet werden, gilt Artikel 13 der Richtlinie (EU) 2016/680.

(12) Die Betreiber arbeiten mit den zuständigen Behörden bei allen Maßnahmen zusammen, die diese Behörden im Zusammenhang mit dem Hochrisiko-KI-System zur Umsetzung dieser Verordnung ergreifen.

<a id="art-27"></a>
### Artikel 27 – Grundrechte-Folgenabschätzung für Hochrisiko-KI-Systeme

(1) Vor der Inbetriebnahme eines Hochrisiko-KI-Systems gemäß Artikel 6 Absatz 2 — mit Ausnahme von Hochrisiko-KI-Systemen, die in dem in Anhang III Nummer 2 aufgeführten Bereich verwendet werden sollen — führen Betreiber, bei denen es sich um Einrichtungen des öffentlichen Rechts oder private Einrichtungen, die öffentliche Dienste erbringen, handelt, und Betreiber von Hochrisiko-KI-Systemen gemäß Anhang III Nummer 5 Buchstaben b und c eine Abschätzung der Auswirkungen, die die Verwendung eines solchen Systems auf die Grundrechte haben kann, durch. Zu diesem Zweck führen die Betreiber eine Abschätzung durch, die Folgendes umfasst:

- a) eine Beschreibung der Verfahren des Betreibers, bei denen das Hochrisiko-KI-System im Einklang mit seiner Zweckbestimmung verwendet wird;

- b) eine Beschreibung des Zeitraums und der Häufigkeit, innerhalb dessen bzw. mit der jedes Hochrisiko-KI-System verwendet werden soll;

- c) die Kategorien der natürlichen Personen und Personengruppen, die von seiner Verwendung im spezifischen Kontext betroffen sein könnten;

- d) die spezifischen Schadensrisiken, die sich auf die gemäß Buchstabe c dieses Absatzes ermittelten Kategorien natürlicher Personen oder Personengruppen auswirken könnten, unter Berücksichtigung der vom Anbieter gemäß Artikel 13 bereitgestellten Informationen;

- e) eine Beschreibung der Umsetzung von Maßnahmen der menschlichen Aufsicht entsprechend den Betriebsanleitungen;

- f) die Maßnahmen, die im Falle des Eintretens dieser Risiken zu ergreifen sind, einschließlich der Regelungen für die interne Unternehmensführung und Beschwerdemechanismen.

(2) Die in Absatz 1 festgelegte Pflicht gilt für die erste Verwendung eines Hochrisiko-KI-Systems. Der Betreiber kann sich in ähnlichen Fällen auf zuvor durchgeführte Grundrechte-Folgenabschätzungen oder bereits vorhandene Folgenabschätzungen, die vom Anbieter durchgeführt wurden, stützen. Gelangt der Betreiber während der Verwendung des Hochrisiko-KI-Systems zur Auffassung, dass sich eines der in Absatz 1 aufgeführten Elemente geändert hat oder nicht mehr auf dem neuesten Stand ist, so unternimmt der Betreiber die erforderlichen Schritte, um die Informationen zu aktualisieren.

(3) Sobald die Abschätzung gemäß Absatz 1 des vorliegenden Artikels durchgeführt wurde, teilt der Betreiber der Marktüberwachungsbehörde ihre Ergebnisse mit, indem er das ausgefüllte, in Absatz 5 des vorliegenden Artikels genannte Muster als Teil der Mitteilung übermittelt. In dem in Artikel 46 Absatz 1 genannten Fall können die Betreiber von der Mitteilungspflicht befreit werden.

▼M1

(4) Wird eine der in diesem Artikel festgelegten Pflichten bereits infolge einer gemäß Artikel 35 der Verordnung (EU) 2016/679 oder Artikel 27 der Richtlinie (EU) 2016/680 durchgeführten Datenschutz-Folgenabschätzung erfüllt, kann der Betreiber bei der Durchführung der Grundrechte-Folgenabschätzung gemäß Absatz 1 dieses Artikels entweder Verweise auf die einschlägigen Abschnitte dieser Datenschutz-Folgenabschätzung oder die einschlägigen Teile ebendieser in die Grundrechte-Folgenabschätzung aufnehmen.

(5) Das Büro für Künstliche Intelligenz erarbeitet ein Muster für einen Fragebogen — auch mithilfe eines automatisierten Instruments —, um die Betreiber in die Lage zu versetzen, ihren Pflichten gemäß diesem Artikel in vereinfachter Weise nachzukommen. In diesem Muster wird den Betreibern gegebenenfalls die Möglichkeit gegeben, gemäß Absatz 4 Verweise auf die einschlägigen Abschnitte der Datenschutz-Folgenabschätzung oder die einschlägigen Teile ebendieser in die Grundrechte-Folgenabschätzung aufzunehmen.

▼B

<a id="chapter-iii-section-4"></a>
## Abschnitt 4 – Notifizierende Behörden und notifizierte Stellen

<a id="art-28"></a>
### Artikel 28 – Notifizierende Behörden

(1) Jeder Mitgliedstaat sorgt für die Benennung oder Schaffung mindestens einer notifizierenden Behörde, die für die Einrichtung und Durchführung der erforderlichen Verfahren zur Bewertung, Benennung und Notifizierung von Konformitätsbewertungsstellen und für deren Überwachung zuständig ist. Diese Verfahren werden in Zusammenarbeit zwischen den notifizierenden Behörden aller Mitgliedstaaten entwickelt.

(2) Die Mitgliedstaaten können entscheiden, dass die Bewertung und Überwachung nach Absatz 1 von einer nationalen Akkreditierungsstelle im Sinne und gemäß der Verordnung (EG) Nr. 765/2008 durchzuführen ist.

(3) Notifizierende Behörden werden so eingerichtet, organisiert und geführt, dass jegliche Interessenkonflikte mit Konformitätsbewertungsstellen vermieden werden und die Objektivität und die Unparteilichkeit ihrer Tätigkeiten gewährleistet sind.

(4) Notifizierende Behörden werden so organisiert, dass Entscheidungen über die Notifizierung von Konformitätsbewertungsstellen von kompetenten Personen getroffen werden, die nicht mit den Personen identisch sind, die die Bewertung dieser Stellen durchgeführt haben.

(5) Notifizierende Behörden dürfen weder Tätigkeiten, die Konformitätsbewertungsstellen durchführen, noch Beratungsleistungen auf einer gewerblichen oder wettbewerblichen Basis anbieten oder erbringen.

(6) Notifizierende Behörden gewährleisten gemäß Artikel 78 die Vertraulichkeit der von ihnen erlangten Informationen.

(7) Notifizierende Behörden verfügen über eine angemessene Anzahl kompetenter Mitarbeiter, sodass sie ihre Aufgaben ordnungsgemäß wahrnehmen können. Die kompetenten Mitarbeiter verfügen — wo erforderlich — über das für ihre Funktion erforderliche Fachwissen in Bereichen wie Informationstechnologie sowie KI und Recht, einschließlich der Überwachung der Grundrechte.

▼M1

(8) Die gemäß dieser Verordnung benannten notifizierenden Behörden, die für KI-Systeme zuständig sind, die unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, stellen sicher, dass die Konformitätsbewertungsstelle, die ihre Benennung sowohl gemäß dieser Verordnung als auch gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union beantragt, die Möglichkeit erhält, einen einzigen Antrag zu stellen, und sich einem einheitlichen Bewertungsverfahren unterzieht, um gemäß dieser Verordnung und den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union benannt zu werden, sofern die einschlägigen Harmonisierungsrechtsvorschriften der Union einen solchen einzigen Antrag und ein solches einheitliches Bewertungsverfahren vorsehen. Zu diesem Zweck arbeiten die gemäß dieser Verordnung benannten notifizierenden Behörden und die gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union benannten Behörden bei ihren Bewertungen zusammen.

Der in diesem Absatz genannte einzige Antrag und das einheitliche Bewertungsverfahren steht auch notifizierten Stellen offen, die bereits gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union benannt wurden, wenn diese notifizierten Stellen ihre Benennung gemäß dieser Verordnung beantragen, sofern die einschlägigen Harmonisierungsrechtsvorschriften der Union ein solches Verfahren vorsehen.

Eine Konformitätsbewertungsstelle, die gemäß mehr als einer der in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union benannt wurde, muss nur einmal einen Antrag stellen, um gemäß dieser Verordnung benannt zu werden. Eine Benennung gemäß dieser Verordnung gilt für alle in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union, für die die Konformitätsbewertungsstelle benannt ist.

Durch den einzigen Antrag und das einheitliche Bewertungsverfahren wird unnötige Doppelarbeit vermieden, auf den bestehenden Benennungsverfahren gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union aufgebaut und die Einhaltung der Anforderungen an notifizierte Stellen sowohl gemäß dieser Verordnung als auch gemäß den einschlägigen Harmonisierungsrechtsvorschriften der Union gewährleistet.

(9) Eine notifizierende Behörde, die gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union benannt wurde, ist auch die notifizierende Behörde, die gemäß Absatz 8 den einzigen Antrag stellt und sich dem einheitlichen Bewertungsverfahren unterzieht, es sei denn, der Mitgliedstaat benennt für diese Verordnung eine andere notifizierende Behörde.

▼B

<a id="art-29"></a>
### Artikel 29 – Antrag einer Konformitätsbewertungsstelle auf Notifizierung

(1) Konformitätsbewertungsstellen beantragen ihre Notifizierung bei der notifizierenden Behörde des Mitgliedstaats, in dem sie niedergelassen sind.

(2) Dem Antrag auf Notifizierung legen sie eine Beschreibung der Konformitätsbewertungstätigkeiten, des bzw. der Konformitätsbewertungsmodule und der Art der KI-Systeme, für die diese Konformitätsbewertungsstelle Kompetenz beansprucht, sowie, falls vorhanden, eine Akkreditierungsurkunde bei, die von einer nationalen Akkreditierungsstelle ausgestellt wurde und in der bescheinigt wird, dass die Konformitätsbewertungsstelle die Anforderungen des Artikels 31 erfüllt.

Sonstige gültige Dokumente in Bezug auf bestehende Benennungen der antragstellenden notifizierten Stelle im Rahmen anderer Harmonisierungsrechtsvorschriften der Union sind ebenfalls beizufügen.

(3) Kann die betreffende Konformitätsbewertungsstelle keine Akkreditierungsurkunde vorweisen, so legt sie der notifizierenden Behörde als Nachweis alle Unterlagen vor, die erforderlich sind, um zu überprüfen, festzustellen und regelmäßig zu überwachen, ob sie die Anforderungen des Artikels 31 erfüllt.

▼M1

(4) Bei notifizierten Stellen, die gemäß anderen Harmonisierungsrechtsvorschriften der Union benannt wurden, können alle Unterlagen und Bescheinigungen im Zusammenhang mit solchen Benennungen zur Unterstützung und Beschleunigung ihres Benennungsverfahrens nach dieser Verordnung verwendet werden.

Notifizierte Stellen, die gemäß einer der in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union benannt wurden und sich dem einheitlichen Bewertungsverfahren gemäß Artikel 28 Absatz 8 unterziehen, stellen den einzigen Antrag auf Bewertung bei der notifizierenden Behörde, die gemäß diesen Harmonisierungsrechtsvorschriften der Union benannt wurde.

Die notifizierte Stelle aktualisiert die in den Absätzen 2 und 3 des vorliegenden Artikels genannte Dokumentation immer dann, wenn sich relevante Änderungen ergeben, damit die für notifizierte Stellen zuständige Behörde überwachen und überprüfen kann, ob die Anforderungen des Artikels 31 kontinuierlich erfüllt sind.

▼B

<a id="art-30"></a>
### Artikel 30 – Notifizierungsverfahren

(1) Die notifizierenden Behörden dürfen nur Konformitätsbewertungsstellen notifizieren, die die Anforderungen des Artikels 31 erfüllen.

▼M1

(2) Die notifizierenden Behörden unterrichten die Kommission und die übrigen Mitgliedstaaten anhand des in Anhang XIV genannten Verzeichnisses der Codes, Kategorien und entsprechenden Arten von KI-Systemen und mithilfe des elektronischen Notifizierungsinstruments, das von der Kommission entwickelt und verwaltet wird, über jede Konformitätsbewertungsstelle gemäß Absatz 1.

Der Kommission wird die Befugnis übertragen, gemäß Artikel 97 delegierte Rechtsakte zur Änderung des Anhangs XIV zu erlassen, um dem technischen Fortschritt, dem erweiterten Wissen oder neuen wissenschaftlichen Erkenntnissen Rechnung zu tragen und in das Verzeichnis der Codes, Kategorien und entsprechenden Arten von KI-Systemen neue Codes, Kategorien oder Arten von KI-Systemen aufzunehmen, bestehende Codes, Kategorien oder Arten von KI-Systemen daraus zu streichen oder Codes oder Arten von KI-Systemen von einer Kategorie in eine andere zu verschieben.

▼B

(3) Die Notifizierung gemäß Absatz 2 des vorliegenden Artikels enthält vollständige Angaben zu den Konformitätsbewertungstätigkeiten, dem betreffenden Konformitätsbewertungsmodul oder den betreffenden Konformitätsbewertungsmodulen, den betreffenden Arten der KI-Systeme und der einschlägigen Bestätigung der Kompetenz. Beruht eine Notifizierung nicht auf einer Akkreditierungsurkunde gemäß Artikel 29 Absatz 2, so legt die notifizierende Behörde der Kommission und den anderen Mitgliedstaaten die Unterlagen vor, die die Kompetenz der Konformitätsbewertungsstelle und die Vereinbarungen nachweisen, die getroffen wurden, um sicherzustellen, dass die Stelle regelmäßig überwacht wird und weiterhin die Anforderungen des Artikels 31 erfüllt.

(4) Die betreffende Konformitätsbewertungsstelle darf die Tätigkeiten einer notifizierten Stelle nur dann wahrnehmen, wenn weder die Kommission noch die anderen Mitgliedstaaten innerhalb von zwei Wochen nach einer Notifizierung durch eine notifizierende Behörde, falls eine Akkreditierungsurkunde gemäß Artikel 29 Absatz 2 vorgelegt wird, oder innerhalb von zwei Monaten nach einer Notifizierung durch eine notifizierende Behörde, falls als Nachweis Unterlagen gemäß Artikel 29 Absatz 3 vorgelegt werden, Einwände erhoben haben.

(5) Werden Einwände erhoben, konsultiert die Kommission unverzüglich die betreffenden Mitgliedstaaten und die Konformitätsbewertungsstelle. Im Hinblick darauf entscheidet die Kommission, ob die Genehmigung gerechtfertigt ist. Die Kommission richtet ihren Beschluss an die betroffenen Mitgliedstaaten und an die zuständige Konformitätsbewertungsstelle.

<a id="art-31"></a>
### Artikel 31 – Anforderungen an notifizierte Stellen

(1) Eine notifizierte Stelle wird nach dem nationalen Recht eines Mitgliedstaats gegründet und muss mit Rechtspersönlichkeit ausgestattet sein.

(2) Die notifizierten Stellen müssen die zur Wahrnehmung ihrer Aufgaben erforderlichen Anforderungen an die Organisation, das Qualitätsmanagement, die Ressourcenausstattung und die Verfahren sowie angemessene Cybersicherheitsanforderungen erfüllen.

(3) Die Organisationsstruktur, die Zuweisung der Zuständigkeiten, die Berichtslinien und die Funktionsweise der notifizierten Stellen müssen das Vertrauen in ihre Leistung und in die Ergebnisse der von ihnen durchgeführten Konformitätsbewertungstätigkeiten gewährleisten.

(4) Die notifizierten Stellen müssen von dem Anbieter eines Hochrisiko-KI-Systems, zu dem sie Konformitätsbewertungstätigkeiten durchführen, unabhängig sein. Außerdem müssen die notifizierten Stellen von allen anderen Akteuren, die ein wirtschaftliches Interesse an den bewerteten Hochrisiko-KI-Systemen haben, und von allen Wettbewerbern des Anbieters unabhängig sein. Dies schließt die Verwendung von bewerteten Hochrisiko-KI-Systemen, die für die Tätigkeit der Konformitätsbewertungsstelle nötig sind, oder die Verwendung solcher Hochrisiko-KI-Systeme zum persönlichen Gebrauch nicht aus.

(5) Weder die Konformitätsbewertungsstelle, ihre oberste Leitungsebene noch die für die Erfüllung ihrer Konformitätsbewertungsaufgaben zuständigen Mitarbeiter dürfen direkt an Entwurf, Entwicklung, Vermarktung oder Verwendung von Hochrisiko-KI-Systemen beteiligt sein oder die an diesen Tätigkeiten beteiligten Parteien vertreten. Sie dürfen sich nicht mit Tätigkeiten befassen, die ihre Unabhängigkeit bei der Beurteilung oder ihre Integrität im Zusammenhang mit den Konformitätsbewertungstätigkeiten, für die sie notifiziert sind, beeinträchtigen könnten. Dies gilt besonders für Beratungsdienstleistungen.

(6) Notifizierte Stellen werden so organisiert und geführt, dass bei der Ausübung ihrer Tätigkeit Unabhängigkeit, Objektivität und Unparteilichkeit gewahrt sind. Von den notifizierten Stellen werden eine Struktur und Verfahren dokumentiert und umgesetzt, die ihre Unparteilichkeit gewährleisten und sicherstellen, dass die Grundsätze der Unparteilichkeit in ihrer gesamten Organisation, von allen Mitarbeitern und bei allen Bewertungstätigkeiten gefördert und angewandt werden.

(7) Die notifizierten Stellen gewährleisten durch dokumentierte Verfahren, dass ihre Mitarbeiter, Ausschüsse, Zweigstellen, Unterauftragnehmer sowie alle zugeordneten Stellen oder Mitarbeiter externer Einrichtungen die Vertraulichkeit der Informationen, die bei der Durchführung der Konformitätsbewertungstätigkeiten in ihren Besitz gelangen, im Einklang mit Artikel 78 wahren, außer wenn ihre Offenlegung gesetzlich vorgeschrieben ist. Informationen, von denen Mitarbeiter der notifizierten Stellen bei der Durchführung ihrer Aufgaben gemäß dieser Verordnung Kenntnis erlangen, unterliegen der beruflichen Schweigepflicht, außer gegenüber den notifizierenden Behörden des Mitgliedstaats, in dem sie ihre Tätigkeiten ausüben.

(8) Die notifizierten Stellen verfügen über Verfahren zur Durchführung ihrer Tätigkeiten unter gebührender Berücksichtigung der Größe eines Betreibers, des Sektors, in dem er tätig ist, seiner Struktur sowie der Komplexität des betreffenden KI-Systems.

(9) Die notifizierten Stellen schließen eine angemessene Haftpflichtversicherung für ihre Konformitätsbewertungstätigkeiten ab, es sei denn, diese Haftpflicht wird aufgrund nationalen Rechts von dem Mitgliedstaat, in dem sie niedergelassen sind, gedeckt oder dieser Mitgliedstaat ist selbst unmittelbar für die Konformitätsbewertung zuständig.

(10) Die notifizierten Stellen müssen in der Lage sein, ihre Aufgaben gemäß dieser Verordnung mit höchster beruflicher Integrität und der erforderlichen Fachkompetenz in dem betreffenden Bereich auszuführen, gleichgültig, ob diese Aufgaben von den notifizierten Stellen selbst oder in ihrem Auftrag und in ihrer Verantwortung durchgeführt werden.

(11) Die notifizierten Stellen müssen über ausreichende interne Kompetenzen verfügen, um die von externen Stellen in ihrem Namen wahrgenommen Aufgaben wirksam beurteilen zu können. Die notifizierten Stellen müssen ständig über ausreichendes administratives, technisches, juristisches und wissenschaftliches Personal verfügen, das Erfahrungen und Kenntnisse in Bezug auf einschlägige Arten der KI-Systeme, Daten und Datenverarbeitung sowie die in Abschnitt 2 festgelegten Anforderungen besitzt.

(12) Die notifizierten Stellen wirken an den in Artikel 38 genannten Koordinierungstätigkeiten mit. Sie wirken außerdem unmittelbar oder mittelbar an der Arbeit der europäischen Normungsorganisationen mit oder stellen sicher, dass sie stets über den Stand der einschlägigen Normen unterrichtet sind.

<a id="art-32"></a>
### Artikel 32 – Vermutung der Konformität mit den Anforderungen an notifizierte Stellen

Weist eine Konformitätsbewertungsstelle nach, dass sie die Kriterien der einschlägigen harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, oder Teile dieser Normen erfüllt, so wird davon ausgegangen, dass sie die Anforderungen des Artikels 31, soweit diese von den geltenden harmonisierten Normen erfasst werden, erfüllt.

<a id="art-33"></a>
### Artikel 33 – Zweigstellen notifizierter Stellen und Vergabe von Unteraufträgen

(1) Vergibt eine notifizierte Stelle bestimmte mit der Konformitätsbewertung verbundene Aufgaben an Unterauftragnehmer oder überträgt sie diese einer Zweigstelle, so stellt sie sicher, dass der Unterauftragnehmer oder die Zweigstelle die Anforderungen des Artikels 31 erfüllt, und informiert die notifizierende Behörde darüber.

(2) Die notifizierten Stellen tragen die volle Verantwortung für Arbeiten, die von jedweden Unterauftragnehmern oder Zweigstellen ausgeführt werden.

(3) Tätigkeiten dürfen nur mit Zustimmung des Anbieters an einen Unterauftragnehmer vergeben oder einer Zweigstelle übertragen werden. Die notifizierten Stellen veröffentlichen ein Verzeichnis ihrer Zweigstellen.

(4) Die einschlägigen Unterlagen über die Bewertung der Qualifikation des Unterauftragnehmers oder der Zweigstelle und die von ihnen gemäß dieser Verordnung ausgeführten Arbeiten werden für einen Zeitraum von fünf Jahren ab dem Datum der Beendigung der Unterauftragsvergabe für die notifizierende Behörde bereitgehalten.

<a id="art-34"></a>
### Artikel 34 – Operative Pflichten der notifizierten Stellen

(1) Die notifizierten Stellen überprüfen die Konformität von Hochrisiko-KI-Systemen nach den in Artikel 43 festgelegten Konformitätsbewertungsverfahren.

(2) Die notifizierten Stellen vermeiden bei der Durchführung ihrer Tätigkeiten unnötige Belastungen für die Anbieter und berücksichtigen gebührend die Größe des Anbieters, den Sektor, in dem er tätig ist, seine Struktur sowie die Komplexität des betreffenden Hochrisiko-KI-Systems, um insbesondere den Verwaltungsaufwand und die Befolgungskosten für Kleinstunternehmen und kleine Unternehmen im Sinne der Empfehlung 2003/361/EG zu minimieren. Die notifizierte Stelle muss jedoch den Grad der Strenge und das Schutzniveau einhalten, die für die Konformität des Hochrisiko-KI-Systems mit den Anforderungen dieser Verordnung erforderlich sind.

(3) Die notifizierten Stellen machen der in Artikel 28 genannten notifizierenden Behörde sämtliche einschlägige Dokumentation, einschließlich der Dokumentation des Anbieters, zugänglich bzw. übermitteln diese auf Anfrage, damit diese Behörde ihre Bewertungs-, Benennungs-, Notifizierungs- und Überwachungstätigkeiten durchführen kann und die Bewertung gemäß diesem Abschnitt erleichtert wird.

<a id="art-35"></a>
### Artikel 35 – Identifizierungsnummern und Verzeichnisse notifizierter Stellen

(1) Die Kommission weist jeder notifizierten Stelle eine einzige Identifizierungsnummer zu, selbst wenn eine Stelle nach mehr als einem Rechtsakt der Union notifiziert wurde.

(2) Die Kommission veröffentlicht das Verzeichnis der nach dieser Verordnung notifizierten Stellen samt ihren Identifizierungsnummern und den Tätigkeiten, für die sie notifiziert wurden. Die Kommission stellt sicher, dass das Verzeichnis auf dem neuesten Stand gehalten wird.

<a id="art-36"></a>
### Artikel 36 – Änderungen der Notifizierungen

(1) Die notifizierende Behörde unterrichtet die Kommission und die anderen Mitgliedstaaten mithilfe des in Artikel 30 Absatz 2 genannten elektronischen Notifizierungsinstruments über alle relevanten Änderungen der Notifizierung einer notifizierten Stelle.

(2) Für Erweiterungen des Anwendungsbereichs der Notifizierung gelten die in den Artikeln 29 und 30 festgelegten Verfahren.

Für andere Änderungen der Notifizierung als Erweiterungen ihres Anwendungsbereichs gelten die in den Absätzen 3 bis 9 dargelegten Verfahren.

(3) Beschließt eine notifizierte Stelle die Einstellung ihrer Konformitätsbewertungstätigkeiten, so informiert sie die betreffende notifizierende Behörde und die betreffenden Anbieter so bald wie möglich und im Falle einer geplanten Einstellung ihrer Tätigkeiten mindestens ein Jahr vor deren Einstellung darüber. Die Bescheinigungen der notifizierten Stelle können für einen Zeitraum von neun Monaten nach Einstellung der Tätigkeiten der notifizierten Stelle gültig bleiben, sofern eine andere notifizierte Stelle schriftlich bestätigt hat, dass sie die Verantwortung für die von diesen Bescheinigungen abgedeckten Hochrisiko-KI-Systeme übernimmt. Die letztgenannte notifizierte Stelle führt vor Ablauf dieser Frist von neun Monaten eine vollständige Bewertung der betroffenen Hochrisiko-KI-Systeme durch, bevor sie für diese neue Bescheinigungen ausstellt. Stellt die notifizierte Stelle ihre Tätigkeit ein, so widerruft die notifizierende Behörde die Benennung.

(4) Hat eine notifizierende Behörde hinreichenden Grund zu der Annahme, dass eine notifizierte Stelle die in Artikel 31 festgelegten Anforderungen nicht mehr erfüllt oder dass sie ihren Pflichten nicht nachkommt, so untersucht die notifizierende Behörde den Sachverhalt unverzüglich und mit äußerster Sorgfalt. In diesem Zusammenhang teilt sie der betreffenden notifizierten Stelle die erhobenen Einwände mit und gibt ihr die Möglichkeit, dazu Stellung zu nehmen. Kommt die notifizierende Behörde zu dem Schluss, dass die notifizierte Stelle die in Artikel 31 festgelegten Anforderungen nicht mehr erfüllt oder dass sie ihren Pflichten nicht nachkommt, schränkt sie die Benennung gegebenenfalls ein, setzt sie aus oder widerruft sie, je nach Schwere der Nichterfüllung dieser Anforderungen oder Pflichtverletzung. Sie informiert die Kommission und die anderen Mitgliedstaaten unverzüglich darüber.

(5) Wird die Benennung einer notifizierten Stelle ausgesetzt, eingeschränkt oder vollständig oder teilweise widerrufen, so informiert die notifizierte Stelle die betreffenden Anbieter innerhalb von zehn Tagen darüber.

(6) Wird eine Benennung eingeschränkt, ausgesetzt oder widerrufen, so ergreift die notifizierende Behörde geeignete Maßnahmen, um sicherzustellen, dass die Akten der betreffenden notifizierten Stelle für die notifizierenden Behörden in anderen Mitgliedstaaten und die Marktüberwachungsbehörden bereitgehalten und ihnen auf deren Anfrage zur Verfügung gestellt werden.

(7) Wird eine Benennung eingeschränkt, ausgesetzt oder widerrufen, so geht die notifizierende Behörde wie folgt vor:

- a) Sie bewertet die Auswirkungen auf die von der notifizierten Stelle ausgestellten Bescheinigungen;

- b) sie legt der Kommission und den anderen Mitgliedstaaten innerhalb von drei Monaten nach Notifizierung der Änderungen der Benennung einen Bericht über ihre diesbezüglichen Ergebnisse vor;

- c) sie weist die notifizierte Stelle zur Gewährleistung der fortlaufenden Konformität der im Verkehr befindlichen Hochrisiko-KI-Systeme an, sämtliche nicht ordnungsgemäß ausgestellten Bescheinigungen innerhalb einer von der Behörde festgelegten angemessenen Frist auszusetzen oder zu widerrufen;

- d) sie informiert die Kommission und die Mitgliedstaaten über Bescheinigungen, deren Aussetzung oder Widerruf sie angewiesen hat;

- e) sie stellt den zuständigen nationalen Behörden des Mitgliedstaats, in dem der Anbieter seine eingetragene Niederlassung hat, alle relevanten Informationen über Bescheinigungen, deren Aussetzung oder Widerruf sie angewiesen hat, zur Verfügung; diese Behörde ergreift erforderlichenfalls geeignete Maßnahmen, um ein mögliches Risiko für Gesundheit, Sicherheit oder Grundrechte zu verhindern.

(8) Abgesehen von den Fällen, in denen Bescheinigungen nicht ordnungsgemäß ausgestellt wurden und in denen eine Benennung ausgesetzt oder eingeschränkt wurde, bleiben die Bescheinigungen unter einem der folgenden Umstände gültig:

- a) Die notifizierende Behörde hat innerhalb eines Monats nach der Aussetzung oder Einschränkung bestätigt, dass im Zusammenhang mit den von der Aussetzung oder Einschränkung betroffenen Bescheinigungen kein Risiko für Gesundheit, Sicherheit oder Grundrechte besteht, und die notifizierende Behörde hat einen Zeitplan für Maßnahmen zur Aufhebung der Aussetzung oder Einschränkung genannt oder

- b) die notifizierende Behörde hat bestätigt, dass keine von der Aussetzung betroffenen Bescheinigungen während der Dauer der Aussetzung oder Einschränkung ausgestellt, geändert oder erneut ausgestellt werden, und gibt an, ob die notifizierte Stelle in der Lage ist, bestehende ausgestellte Bescheinigungen während der Dauer der Aussetzung oder Einschränkung weiterhin zu überwachen und die Verantwortung dafür zu übernehmen; falls die notifizierende Behörde feststellt, dass die notifizierte Stelle nicht in der Lage ist, bestehende ausgestellte Bescheinigungen weiterzuführen, so bestätigt der Anbieter des von der Bescheinigung abgedeckten Systems den zuständigen nationalen Behörden des Mitgliedstaats, in dem er seine eingetragene Niederlassung hat, innerhalb von drei Monaten nach der Aussetzung oder Einschränkung schriftlich, dass eine andere qualifizierte notifizierte Stelle vorübergehend die Aufgaben der notifizierten Stelle zur Überwachung der Bescheinigung übernimmt und dass sie während der Dauer der Aussetzung oder Einschränkung für die Bescheinigung verantwortlich bleibt.

(9) Abgesehen von den Fällen, in denen Bescheinigungen nicht ordnungsgemäß ausgestellt wurden und in denen eine Benennung widerrufen wurde, bleiben die Bescheinigungen unter folgenden Umständen für eine Dauer von neun Monaten gültig:

- a) Die zuständige nationale Behörde des Mitgliedstaats, in dem der Anbieter des von der Bescheinigung abgedeckten Hochrisiko-KI-Systems seine eingetragene Niederlassung hat, hat bestätigt, dass im Zusammenhang mit den betreffenden Hochrisiko-KI-Systemen kein Risiko für Gesundheit, Sicherheit oder Grundrechte besteht, und

- b) eine andere notifizierte Stelle hat schriftlich bestätigt, dass sie die unmittelbare Verantwortung für diese KI-Systeme übernehmen und deren Bewertung innerhalb von 12 Monaten ab dem Widerruf der Benennung abgeschlossen haben wird.

Unter den in Unterabsatz 1 genannten Umständen kann die zuständige nationale Behörde des Mitgliedstaats, in dem der Anbieter des von der Bescheinigung abgedeckten Systems seine Niederlassung hat, die vorläufige Gültigkeit der Bescheinigungen um zusätzliche Zeiträume von je drei Monaten, jedoch nicht um insgesamt mehr als 12 Monate, verlängern.

Die zuständige nationale Behörde oder die notifizierte Stelle, die die Aufgaben der von der Benennungsänderung betroffenen notifizierten Stelle übernimmt, informiert unverzüglich die Kommission, die anderen Mitgliedstaaten und die anderen notifizierten Stellen darüber.

<a id="art-37"></a>
### Artikel 37 – Anfechtungen der Kompetenz notifizierter Stellen

(1) Die Kommission untersucht erforderlichenfalls alle Fälle, in denen begründete Zweifel an der Kompetenz einer notifizierten Stelle oder daran bestehen, dass eine notifizierte Stelle die in Artikel 31 festgelegten Anforderungen und ihre geltenden Pflichten weiterhin erfüllt.

(2) Die notifizierende Behörde stellt der Kommission auf Anfrage alle Informationen über die Notifizierung oder die Aufrechterhaltung der Kompetenz der betreffenden notifizierten Stelle zur Verfügung.

(3) Die Kommission stellt sicher, dass alle im Verlauf ihrer Untersuchungen gemäß diesem Artikel erlangten sensiblen Informationen gemäß Artikel 78 vertraulich behandelt werden.

(4) Stellt die Kommission fest, dass eine notifizierte Stelle die Anforderungen für ihre Notifizierung nicht oder nicht mehr erfüllt, so informiert sie den notifizierenden Mitgliedstaat entsprechend und fordert ihn auf, die erforderlichen Abhilfemaßnahmen zu treffen, einschließlich einer Aussetzung oder eines Widerrufs der Notifizierung, sofern dies nötig ist. Versäumt es ein Mitgliedstaat, die erforderlichen Abhilfemaßnahmen zu ergreifen, kann die Kommission die Benennung im Wege eines Durchführungsrechtsakts aussetzen, einschränken oder widerrufen. Dieser Durchführungsrechtsakt wird gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

<a id="art-38"></a>
### Artikel 38 – Koordinierung der notifizierten Stellen

(1) Die Kommission sorgt dafür, dass in Bezug auf Hochrisiko-KI-Systeme eine zweckmäßige Koordinierung und Zusammenarbeit zwischen den an den Konformitätsbewertungsverfahren im Rahmen dieser Verordnung beteiligten notifizierten Stellen in Form einer sektoralen Gruppe notifizierter Stellen eingerichtet und ordnungsgemäß weitergeführt wird.

(2) Jede notifizierende Behörde sorgt dafür, dass sich die von ihr notifizierten Stellen direkt oder über benannte Vertreter an der Arbeit der in Absatz 1 genannten Gruppe beteiligen.

(3) Die Kommission sorgt für den Austausch von Wissen und bewährten Verfahren zwischen den notifizierenden Behörden.

<a id="art-39"></a>
### Artikel 39 – Konformitätsbewertungsstellen in Drittländern

Konformitätsbewertungsstellen, die nach dem Recht eines Drittlands errichtet wurden, mit dem die Union ein Abkommen geschlossen hat, können ermächtigt werden, die Tätigkeiten notifizierter Stellen gemäß dieser Verordnung durchzuführen, sofern sie die Anforderungen gemäß Artikel 31 erfüllen oder das gleiche Maß an Konformität gewährleisten.

<a id="chapter-iii-section-5"></a>
## Abschnitt 5 – Normen, Konformitätsbewertung, Bescheinigungen, Registrierung

<a id="art-40"></a>
### Artikel 40 – Harmonisierte Normen und Normungsdokumente

(1) Bei Hochrisiko-KI-Systemen oder KI-Modellen mit allgemeinem Verwendungszweck, die mit harmonisierten Normen oder Teilen davon, deren Fundstellen gemäß der Verordnung (EU) Nr. 1025/2012 im Amtsblatt der Europäischen Union veröffentlicht wurden, übereinstimmen, wird eine Konformität mit den Anforderungen gemäß Abschnitt 2 des vorliegenden Kapitels oder gegebenenfalls mit den Pflichten gemäß Kapitel V Abschnitte 2 und 3 der vorliegenden Verordnung vermutet, soweit diese Anforderungen oder Verpflichtungen von den Normen abgedeckt sind.

(2) Gemäß Artikel 10 der Verordnung (EU) Nr. 1025/2012 erteilt die Kommission unverzüglich Normungsaufträge, die alle Anforderungen gemäß Abschnitt 2 des vorliegenden Kapitels abdecken und gegebenenfalls Normungsaufträge, die Pflichten gemäß Kapitel V Abschnitte 2 und 3 der vorliegenden Verordnung abdecken. In dem Normungsauftrag werden auch Dokumente zu den Berichterstattungs- und Dokumentationsverfahren im Hinblick auf die Verbesserung der Ressourcenleistung von KI-Systemen z. B. durch die Verringerung des Energie- und sonstigen Ressourcenverbrauchs des Hochrisiko-KI-Systems während seines gesamten Lebenszyklus und zu der energieeffizienten Entwicklung von KI-Modellen mit allgemeinem Verwendungszweck verlangt. Bei der Ausarbeitung des Normungsauftrags konsultiert die Kommission das KI-Gremium und die einschlägigen Interessenträger, darunter das Beratungsforum.

Bei der Erteilung eines Normungsauftrags an die europäischen Normungsorganisationen gibt die Kommission an, dass die Normen klar und — u. a. mit den Normen, die in den verschiedenen Sektoren für Produkte entwickelt wurden, die unter die in Anhang I aufgeführten geltenden Harmonisierungsrechtsvorschriften der Union fallen — konsistent sein müssen und sicherstellen sollen, dass die in der Union in Verkehr gebrachten oder in Betrieb genommenen Hochrisiko-KI-Systeme oder KI-Modelle mit allgemeinem Verwendungszweck die in dieser Verordnung festgelegten einschlägigen Anforderungen oder Pflichten erfüllen.

Die Kommission fordert die europäischen Normungsorganisationen auf, Nachweise dafür vorzulegen, dass sie sich nach besten Kräften bemühen, die in den Unterabsätzen 1 und 2 dieses Absatzes genannten Ziele im Einklang mit Artikel 24 der Verordnung (EU) Nr. 1025/2012 zu erreichen.

▼M1

Die Kommission beauftragt im Einklang mit der Verordnung (EU) Nr. 1025/2012 des Europäischen Parlaments und des Rates ^(1) unverzüglich die europäischen Normungsorganisationen, Normungsprodukte, gegebenenfalls einschließlich harmonisierter Normen, auszuarbeiten, um die gemeinsame Einhaltung und die Konformitätsvermutung mit den Anforderungen oder Verpflichtungen gemäß Kapitel III Abschnitte 2 und 3 dieser Verordnung und den einschlägigen Anforderungen und Verpflichtungen, die in den in Anhang I dieser Verordnung aufgeführten Harmonisierungsrechtsvorschriften der Union festgelegt sind, zu erleichtern.

▼B

(3) Die am Normungsprozess Beteiligten bemühen sich, Investitionen und Innovationen im Bereich der KI, u. a. durch Erhöhung der Rechtssicherheit, sowie der Wettbewerbsfähigkeit und des Wachstums des Unionsmarktes zu fördern und zur Stärkung der weltweiten Zusammenarbeit bei der Normung und zur Berücksichtigung bestehender internationaler Normen im Bereich der KI, die mit den Werten, Grundrechten und Interessen der Union im Einklang stehen, beizutragen und die Multi-Stakeholder-Governance zu verbessern, indem eine ausgewogene Vertretung der Interessen und eine wirksame Beteiligung aller relevanten Interessenträger gemäß den Artikeln 5, 6 und 7 der Verordnung (EU) Nr. 1025/2012 sichergestellt werden.

<a id="art-41"></a>
### Artikel 41 – Gemeinsame Spezifikationen

(1) Die Kommission kann Durchführungsrechtsakte zur Festlegung gemeinsamer Spezifikationen für die Anforderungen gemäß Abschnitt 2 dieses Kapitels oder gegebenenfalls die Pflichten gemäß Kapitel V Abschnitte 2 und 3 erlassen, wenn die folgenden Bedingungen erfüllt sind:

- a) Die Kommission hat gemäß Artikel 10 Absatz 1 der Verordnung (EU) Nr. 1025/2012 eine oder mehrere europäische Normungsorganisationen damit beauftragt, eine harmonisierte Norm für die in Abschnitt 2 dieses Kapitels festgelegten Anforderungen oder gegebenenfalls für die in Kapitel V Abschnitte 2 und 3 festgelegten Pflichten zu erarbeiten, und

  - i) der Auftrag wurde von keiner der europäischen Normungsorganisationen angenommen oder

  - ii) die harmonisierten Normen, die Gegenstand dieses Auftrags sind, werden nicht innerhalb der gemäß Artikel 10 Absatz 1 der Verordnung (EU) Nr. 1025/2012 festgelegten Frist erarbeitet oder

  - iii) die einschlägigen harmonisierten Normen tragen den Bedenken im Bereich der Grundrechte nicht ausreichend Rechnung oder

  - iv) die harmonisierten Normen entsprechen nicht dem Auftrag und

- b) im Amtsblatt der Europäischen Union sind keine Fundstellen zu harmonisierten Normen gemäß der Verordnung (EU) Nr. 1025/2012 veröffentlicht, die den in Abschnitt 2 dieses Kapitels aufgeführten Anforderungen oder gegebenenfalls den in Kapitel V Abschnitte 2 und 3 aufgeführten Pflichten genügen, und es ist nicht zu erwarten, dass eine solche Fundstelle innerhalb eines angemessenen Zeitraums veröffentlicht wird.

Bei der Verfassung der gemeinsamen Spezifikationen konsultiert die Kommission das in Artikel 67 genannte Beratungsforum.

Die in Unterabsatz 1 des vorliegenden Absatzes genannten Durchführungsrechtsakte werden gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

(2) Vor der Ausarbeitung eines Entwurfs eines Durchführungsrechtsakts informiert die Kommission den in Artikel 22 der Verordnung (EU) Nr. 1025/2012 genannten Ausschuss darüber, dass sie die in Absatz 1 des vorliegenden Artikels festgelegten Bedingungen als erfüllt erachtet.

(3) Bei Hochrisiko-KI-Systemen oder KI-Modellen mit allgemeinem Verwendungszweck, die mit den in Absatz 1 genannten gemeinsamen Spezifikationen oder Teilen dieser Spezifikationen übereinstimmen, wird eine Konformität mit den Anforderungen in Abschnitt 2 dieses Kapitels oder gegebenenfalls die Einhaltung der in Kapitel V Abschnitte 2 und 3 genannten Pflichten vermutet, soweit diese Anforderungen oder diese Pflichten von den gemeinsamen Spezifikationen abgedeckt sind.

(4) Wird eine harmonisierte Norm von einer europäischen Normungsorganisation angenommen und der Kommission zur Veröffentlichung ihrer Fundstelle im Amtsblatt der Europäischen Union vorgeschlagen, so bewertet die Kommission die harmonisierte Norm gemäß der Verordnung (EU) Nr. 1025/2012. Wird die Fundstelle zu einer harmonisierten Norm im Amtsblatt der Europäischen Union veröffentlicht, so werden die in Absatz 1 genannten Durchführungsrechtsakte, die dieselben Anforderungen gemäß Abschnitt 2 dieses Kapitels oder gegebenenfalls dieselben Pflichten gemäß Kapitel V Abschnitte 2 und 3 erfassen, von der Kommission ganz oder teilweise aufgehoben.

(5) Wenn Anbieter von Hochrisiko-KI-Systemen oder KI-Modellen mit allgemeinem Verwendungszweck die in Absatz 1 genannten gemeinsamen Spezifikationen nicht befolgen, müssen sie hinreichend nachweisen, dass sie technische Lösungen verwenden, die die in Abschnitt 2 dieses Kapitels aufgeführten Anforderungen oder gegebenenfalls die Pflichten gemäß Kapitel V Abschnitte 2 und 3 zumindest in gleichem Maße erfüllen;

(6) Ist ein Mitgliedstaat der Auffassung, dass eine gemeinsame Spezifikation den Anforderungen gemäß Abschnitt 2 nicht vollständig entspricht oder gegebenenfalls die Pflichten gemäß Kapitel V Abschnitte 2 und 3 nicht vollständig erfüllt, so setzt er die Kommission im Rahmen einer ausführlichen Erläuterung davon in Kenntnis. Die Kommission bewertet die betreffende Information und ändert gegebenenfalls den Durchführungsrechtsakt, durch den die betreffende gemeinsame Spezifikation festgelegt wurde.

<a id="art-42"></a>
### Artikel 42 – Vermutung der Konformität mit bestimmten Anforderungen

(1) Für Hochrisiko-KI-Systeme, die mit Daten, in denen sich die besonderen geografischen, verhaltensbezogenen, kontextuellen oder funktionalen Rahmenbedingungen niederschlagen, unter denen sie verwendet werden sollen, trainiert und getestet wurden, gilt die Vermutung, dass sie die in Artikel 10 Absatz 4 festgelegten einschlägigen Anforderungen erfüllen.

(2) Für Hochrisiko-KI-Systeme, die im Rahmen eines der Cybersicherheitszertifizierungssysteme gemäß der Verordnung (EU) 2019/881, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden, zertifiziert wurden oder für die eine solche Konformitätserklärung erstellt wurde, gilt die Vermutung, dass sie die in Artikel 15 der vorliegenden Verordnung festgelegten Cybersicherheitsanforderungen erfüllen, sofern diese Anforderungen von der Cybersicherheitszertifizierung oder der Konformitätserklärung oder Teilen davon abdeckt sind.

▼M1

(3) Fallen Hochrisiko-KI-Systeme in den Anwendungsbereich der Verordnung (EU) 2024/2847 und sind die in Artikel 12 Absatz 1 der genannten Verordnung festgelegten Bedingungen erfüllt, so gelten diese Systeme als mit den in Artikel 15 dieser Verordnung festgelegten Cybersicherheitsanforderungen konform.

▼B

<a id="art-43"></a>
### Artikel 43 – Konformitätsbewertung

(1) Hat ein Anbieter zum Nachweis, dass ein in Anhang III Nummer 1 aufgeführtes Hochrisiko-KI-System die in Abschnitt 2 festgelegten Anforderungen erfüllt, harmonisierte Normen gemäß Artikel 40 oder gegebenenfalls gemeinsame Spezifikationen gemäß Artikel 41 angewandt, so entscheidet er sich für eines der folgenden Konformitätsbewertungsverfahren auf der Grundlage

- a) der internen Kontrolle gemäß Anhang VI oder

- b) der Bewertung des Qualitätsmanagementsystems und der Bewertung der technischen Dokumentation unter Beteiligung einer notifizierten Stelle gemäß Anhang VII.

Zum Nachweis, dass sein Hochrisiko-KI-System die in Abschnitt 2 festgelegten Anforderungen erfüllt, befolgt der Anbieter das Konformitätsbewertungsverfahren gemäß Anhang VII, wenn

- a) es harmonisierte Normen gemäß Artikel 40 nicht gibt und keine gemeinsamen Spezifikationen gemäß Artikel 41 vorliegen,

- b) der Anbieter die harmonisierte Norm nicht oder nur teilweise angewandt hat;

- c) die unter Buchstabe a genannten gemeinsamen Spezifikationen zwar vorliegen, der Anbieter sie jedoch nicht angewandt hat;

- d) eine oder mehrere der unter Buchstabe a genannten harmonisierten Normen mit einer Einschränkung und nur für den eingeschränkten Teil der Norm veröffentlicht wurden.

Für die Zwecke des Konformitätsbewertungsverfahrens gemäß Anhang VII kann der Anbieter eine der notifizierten Stellen auswählen. Soll das Hochrisiko-KI-System jedoch von Strafverfolgungs-, Einwanderungs- oder Asylbehörden oder von Organen, Einrichtungen oder sonstigen Stellen der Union in Betrieb genommen werden, so übernimmt die in Artikel 74 Absatz 8 bzw. 9 genannte Marktüberwachungsbehörde die Funktion der notifizierten Stelle.

(2) Bei den in Anhang III Nummern 2 bis 8 aufgeführten Hochrisiko-KI-Systemen befolgen die Anbieter das Konformitätsbewertungsverfahren auf der Grundlage einer internen Kontrolle gemäß Anhang VI, das keine Beteiligung einer notifizierten Stelle vorsieht.

▼M1

(3) Bei den Hochrisiko-KI-Systemen, die unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, befolgt der Anbieter des Systems das einschlägige Konformitätsbewertungsverfahren, das gemäß den einschlägigen Harmonisierungsrechtsvorschriften der Union erforderlich ist. Die in Abschnitt 2 dieses Kapitels festgelegten Anforderungen gelten für diese Hochrisiko-KI-Systeme und werden in diese Bewertung einbezogen. Die Bewertung des Qualitätsmanagementsystems gemäß Artikel 17 wird ebenfalls durchgeführt, und Anhang VII Nummern 3, 4.3, 4.4. und 4.5 sowie Nummer 4.6 Absatz 5 und Nummer 5 finden Anwendung.

Für die Zwecke dieser Konformitätsbewertung sind die notifizierten Stellen, die gemäß den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union notifiziert wurden, dazu befugt, die Konformität der Hochrisiko-KI-Systeme mit den in Abschnitt 2 dieses Kapitels festgelegten Anforderungen zu bewerten, sofern im Rahmen des gemäß den einschlägigen Harmonisierungsrechtsvorschriften der Union durchgeführten Notifizierungsverfahrens geprüft wurde, dass diese notifizierten Stellen die in Artikel 31 Absätze 4, 5, 10 und 11 festgelegten Anforderungen erfüllen, was im Zuge der Bewertung als Teil der bestehenden Notifizierung belegt wird. Unbeschadet des Artikels 28 beantragen solche notifizierten Stellen, die nach den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union notifiziert wurden, ihre Benennung gemäß Abschnitt 4 dieses Kapitels bis 28. Januar 2028.

Wenn eine in Anhang I Abschnitt A aufgeführte Harmonisierungsrechtsvorschrift der Union dem Hersteller des Produkts die Möglichkeit einräumt, auf eine Konformitätsbewertung zurückzugreifen, an der keine Dritten beteiligt sind, sofern dieser Hersteller harmonisierte Normen angewandt hat, um die Konformität mit allen relevanten Anforderungen zu gewährleisten, so darf dieser Hersteller nur dann von dieser Möglichkeit Gebrauch machen, wenn er auch harmonisierte Normen oder gegebenenfalls gemeinsame Spezifikationen gemäß Artikel 41, die alle in Abschnitt 2 dieses Kapitels festgelegten Anforderungen abdecken, angewandt hat. Die Einstufung eines Produkts als Hochrisiko-KI-System gemäß Artikel 6 Absatz 1 berührt nicht die Wahl des Konformitätsbewertungsverfahrens, das den Herstellern von Produkten zur Verfügung gestellt wird, die unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, wobei dies gegebenenfalls eine Option, sich auf harmonisierte Normen zu stützen, umfassen kann. Die Hersteller solcher Produkte sind nicht verpflichtet, ein Konformitätsbewertungsverfahren mit einer Konformitätsbewertung durch Dritte zu wählen, nur weil das Produkt ein Hochrisiko-KI-System als Sicherheitsbauteil enthält, sofern dies nicht in den in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union vorgeschrieben ist.

Wenn ein Hochrisiko-KI-System sowohl unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union als auch unter eine der in Anhang III aufgeführten Kategorien fällt, befolgt der Anbieter dieses Systems das einschlägige Konformitätsbewertungsverfahren, das gemäß den in Anhang I Abschnitt A aufgeführten einschlägigen Harmonisierungsrechtsvorschriften der Union erforderlich ist.

▼B

(4) Hochrisiko-KI-Systeme, die bereits Gegenstand eines Konformitätsbewertungsverfahren gewesen sind, werden im Falle einer wesentlichen Änderung einem neuen Konformitätsbewertungsverfahren unterzogen, unabhängig davon, ob das geänderte System noch weiter in Verkehr gebracht oder vom derzeitigen Betreiber weitergenutzt werden soll.

Bei Hochrisiko-KI-Systemen, die nach dem Inverkehrbringen oder der Inbetriebnahme weiterhin dazulernen, gelten Änderungen des Hochrisiko-KI-Systems und seiner Leistung, die vom Anbieter zum Zeitpunkt der ursprünglichen Konformitätsbewertung vorab festgelegt wurden und in den Informationen der technischen Dokumentation gemäß Anhang IV Nummer 2 Buchstabe f enthalten sind, nicht als wesentliche Veränderung;

(5) Die Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zu erlassen, um die Anhänge VI und VII zu ändern, indem sie sie angesichts des technischen Fortschritts aktualisiert.

(6) Die Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zur Änderung der Absätze 1 und 2 des vorliegenden Artikels zu erlassen, um die in Anhang III Nummern 2 bis 8 genannten Hochrisiko-KI-Systeme dem Konformitätsbewertungsverfahren gemäß Anhang VII oder Teilen davon zu unterwerfen. Die Kommission erlässt solche delegierten Rechtsakte unter Berücksichtigung der Wirksamkeit des Konformitätsbewertungsverfahrens auf der Grundlage einer internen Kontrolle gemäß Anhang VI hinsichtlich der Vermeidung oder Minimierung der von solchen Systemen ausgehenden Risiken für die Gesundheit und Sicherheit und den Schutz der Grundrechte sowie hinsichtlich der Verfügbarkeit angemessener Kapazitäten und Ressourcen in den notifizierten Stellen.

<a id="art-44"></a>
### Artikel 44 – Bescheinigungen

(1) Die von notifizierten Stellen gemäß Anhang VII ausgestellten Bescheinigungen werden in einer Sprache ausgefertigt, die für die einschlägigen Behörden des Mitgliedstaats, in dem die notifizierte Stelle niedergelassen ist, leicht verständlich ist.

(2) Die Bescheinigungen sind für die darin genannte Dauer gültig, die maximal fünf Jahre für unter Anhang I fallende KI-Systeme und maximal vier Jahre für unter Anhang III fallende KI-Systeme beträgt. Auf Antrag des Anbieters kann die Gültigkeit einer Bescheinigung auf der Grundlage einer Neubewertung gemäß den geltenden Konformitätsbewertungsverfahren um weitere Zeiträume von jeweils höchstens fünf Jahren für unter Anhang I fallende KI-Systeme und höchstens vier Jahre für unter Anhang III fallende KI-Systeme verlängert werden. Eine Ergänzung zu einer Bescheinigung bleibt gültig, sofern die Bescheinigung, zu der sie gehört, gültig ist.

(3) Stellt eine notifizierte Stelle fest, dass ein KI-System die in Abschnitt 2 festgelegten Anforderungen nicht mehr erfüllt, so setzt sie die ausgestellte Bescheinigung aus, widerruft sie oder schränkt sie ein, jeweils unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit, sofern die Einhaltung der Anforderungen nicht durch geeignete Korrekturmaßnahmen des Anbieters des Systems innerhalb einer von der notifizierten Stelle gesetzten angemessenen Frist wiederhergestellt wird. Die notifizierte Stelle begründet ihre Entscheidung.

Es muss ein Einspruchsverfahren gegen die Entscheidungen der notifizierten Stellen, auch solche über ausgestellte Konformitätsbescheinigungen, vorgesehen sein.

<a id="art-45"></a>
### Artikel 45 – Informationspflichten der notifizierten Stellen

(1) Die notifizierten Stellen informieren die notifizierende Behörde über

- a) alle Unionsbescheinigungen über die Bewertung der technischen Dokumentation, etwaige Ergänzungen dieser Bescheinigungen und alle Genehmigungen von Qualitätsmanagementsystemen, die gemäß den Anforderungen des Anhangs VII erteilt wurden;

- b) alle Verweigerungen, Einschränkungen, Aussetzungen oder Rücknahmen von Unionsbescheinigungen über die Bewertung der technischen Dokumentation oder Genehmigungen von Qualitätsmanagementsystemen, die gemäß den Anforderungen des Anhangs VII erteilt wurden;

- c) alle Umstände, die Folgen für den Anwendungsbereich oder die Bedingungen der Notifizierung haben;

- d) alle Auskunftsersuchen über Konformitätsbewertungstätigkeiten, die sie von den Marktüberwachungsbehörden erhalten haben;

- e) auf Anfrage die Konformitätsbewertungstätigkeiten, denen sie im Anwendungsbereich ihrer Notifizierung nachgegangen sind, und sonstige Tätigkeiten, einschließlich grenzüberschreitender Tätigkeiten und Vergabe von Unteraufträgen, die sie durchgeführt haben.

(2) Jede notifizierte Stelle informiert die anderen notifizierten Stellen über

- a) die Genehmigungen von Qualitätsmanagementsystemen, die sie verweigert, ausgesetzt oder zurückgenommen hat, und auf Anfrage die Genehmigungen von Qualitätsmanagementsystemen, die sie erteilt hat;

- b) die Bescheinigungen der Union über die Bewertung der technischen Dokumentation und deren etwaige Ergänzungen, die sie verweigert, ausgesetzt oder zurückgenommen oder anderweitig eingeschränkt hat, und auf Anfrage die Bescheinigungen und/oder deren Ergänzungen, die sie ausgestellt hat.

(3) Jede notifizierte Stelle übermittelt den anderen notifizierten Stellen, die ähnlichen Konformitätsbewertungstätigkeiten für die gleichen Arten der KI-Systeme nachgehen, einschlägige Informationen über negative und auf Anfrage über positive Konformitätsbewertungsergebnisse.

(4) Notifizierende Behörden gewährleisten gemäß Artikel 78 die Vertraulichkeit der von ihnen erlangten Informationen.

<a id="art-46"></a>
### Artikel 46 – Ausnahme vom Konformitätsbewertungsverfahren

(1) Abweichend von Artikel 43 und auf ein hinreichend begründetes Ersuchen kann eine Marktüberwachungsbehörde das Inverkehrbringen oder die Inbetriebnahme bestimmter Hochrisiko-KI-Systeme im Hoheitsgebiet des betreffenden Mitgliedstaats aus außergewöhnlichen Gründen der öffentlichen Sicherheit, des Schutzes des Lebens und der Gesundheit von Personen, des Umweltschutzes oder des Schutzes wichtiger Industrie- und Infrastrukturanlagen genehmigen. Diese Genehmigung wird auf die Dauer der erforderlichen Konformitätsbewertungsverfahren befristet, wobei den außergewöhnlichen Gründen für die Ausnahme Rechnung getragen wird. Der Abschluss dieser Verfahren erfolgt unverzüglich.

(2) In hinreichend begründeten dringenden Fällen aus außergewöhnlichen Gründen der öffentlichen Sicherheit oder in Fällen einer konkreten, erheblichen und unmittelbaren Gefahr für das Leben oder die körperliche Unversehrtheit natürlicher Personen können Strafverfolgungsbehörden oder Katastrophenschutzbehörden ein bestimmtes Hochrisiko-KI-System ohne die in Absatz 1 genannte Genehmigung in Betrieb nehmen, sofern diese Genehmigung während der Verwendung oder im Anschluss daran unverzüglich beantragt wird. Falls die Genehmigung gemäß Absatz 1 abgelehnt wird, wird Verwendung des Hochrisiko-KI-Systems mit sofortiger Wirkung eingestellt und sämtliche Ergebnisse und Ausgaben dieser Verwendung werden unverzüglich verworfen.

(3) Die in Absatz 1 genannte Genehmigung wird nur erteilt, wenn die Marktüberwachungsbehörde zu dem Schluss gelangt, dass das Hochrisiko-KI-System die Anforderungen des Abschnitts 2 erfüllt. Die Marktüberwachungsbehörde informiert die Kommission und die anderen Mitgliedstaaten über alle von ihr gemäß den Absätzen 1 und 2 erteilten Genehmigungen. Diese Pflicht erstreckt sich nicht auf sensible operative Daten zu den Tätigkeiten von Strafverfolgungsbehörden.

(4) Erhebt weder ein Mitgliedstaat noch die Kommission innerhalb von 15 Kalendertagen nach Erhalt der in Absatz 3 genannten Mitteilung Einwände gegen die von einer Marktüberwachungsbehörde eines Mitgliedstaats gemäß Absatz 1 erteilte Genehmigung, so gilt diese Genehmigung als gerechtfertigt.

(5) Erhebt innerhalb von 15 Kalendertagen nach Erhalt der in Absatz 3 genannten Mitteilung ein Mitgliedstaat Einwände gegen eine von einer Marktüberwachungsbehörde eines anderen Mitgliedstaats erteilte Genehmigung oder ist die Kommission der Auffassung, dass die Genehmigung mit dem Unionsrecht unvereinbar ist oder dass die Schlussfolgerung der Mitgliedstaaten in Bezug auf die Konformität des in Absatz 3 genannten Systems unbegründet ist, so nimmt die Kommission unverzüglich Konsultationen mit dem betreffenden Mitgliedstaat auf. Die betroffenen Akteure werden konsultiert und erhalten Gelegenheit, dazu Stellung zu nehmen. In Anbetracht dessen entscheidet die Kommission, ob die Genehmigung gerechtfertigt ist. Die Kommission richtet ihren Beschluss an den betroffenen Mitgliedstaat und an die betroffenen Akteure.

(6) Wird die Genehmigung von der Kommission als ungerechtfertigt erachtet, so muss sie von der Marktüberwachungsbehörde des betreffenden Mitgliedstaats zurückgenommen werden.

(7) Für Hochrisiko-KI-Systeme im Zusammenhang mit Produkten, die unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, gelten nur die in diesen Harmonisierungsrechtsvorschriften der Union festgelegten Ausnahmen von den Konformitätsbewertungsverfahren.

<a id="art-47"></a>
### Artikel 47 – EU-Konformitätserklärung

(1) Der Anbieter stellt für jedes Hochrisiko-KI-System eine schriftliche maschinenlesbare, physische oder elektronisch unterzeichnete EU-Konformitätserklärung aus und hält sie für einen Zeitraum von 10 Jahren ab dem Inverkehrbringen oder der Inbetriebnahme des Hochrisiko-KI-Systems für die zuständigen nationalen Behörden bereit. Aus der EU-Konformitätserklärung geht hervor, für welches Hochrisiko-KI-System sie ausgestellt wurde. Eine Kopie der EU-Konformitätserklärung wird den zuständigen nationalen Behörden auf Anfrage übermittelt.

(2) Die EU-Konformitätserklärung muss feststellen, dass das betreffende Hochrisiko-KI-System die in Abschnitt 2 festgelegten Anforderungen erfüllt. Die EU-Konformitätserklärung enthält die in Anhang V festgelegten Informationen und wird in eine Sprache übersetzt, die für die zuständigen nationalen Behörden der Mitgliedstaaten, in denen das Hochrisiko-KI-System in Verkehr gebracht oder bereitgestellt wird, leicht verständlich ist.

(3) Unterliegen Hochrisiko-KI-Systeme anderen Harmonisierungsrechtsvorschriften der Union, die ebenfalls eine EU-Konformitätserklärung vorschreiben, so wird eine einzige EU-Konformitätserklärung ausgestellt, die sich auf alle für das Hochrisiko-KI-System geltenden Rechtsvorschriften der Union bezieht. Die Erklärung enthält alle erforderlichen Informationen zur Feststellung der Harmonisierungsrechtsvorschriften der Union, auf die sich die Erklärung bezieht.

(4) Mit der Ausstellung der EU-Konformitätserklärung übernimmt der Anbieter die Verantwortung für die Erfüllung der in Abschnitt 2 festgelegten Anforderungen. Der Anbieter hält die EU-Konformitätserklärung gegebenenfalls auf dem neuesten Stand.

(5) Der Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zur Aktualisierung des in Anhang V festgelegten Inhalts der EU-Konformitätserklärung zu erlassen, um den genannten Anhang durch die Einführung von Elementen zu ändern, die angesichts des technischen Fortschritts erforderlich werden.

<a id="art-48"></a>
### Artikel 48 – CE-Kennzeichnung

(1) Für die CE-Kennzeichnung gelten die in Artikel 30 der Verordnung (EG) Nr. 765/2008 festgelegten allgemeinen Grundsätze.

(2) Bei digital bereitgestellten Hochrisiko-KI-Systemen wird eine digitale CE-Kennzeichnung nur dann verwendet, wenn sie über die Schnittstelle, von der aus auf dieses System zugegriffen wird, oder über einen leicht zugänglichen maschinenlesbaren Code oder andere elektronische Mittel leicht zugänglich ist.

(3) Die CE-Kennzeichnung wird gut sichtbar, leserlich und dauerhaft an Hochrisiko-KI-Systemen angebracht. Falls die Art des Hochrisiko-KI-Systems dies nicht zulässt oder nicht rechtfertigt, wird sie auf der Verpackung bzw. der beigefügten Dokumentation angebracht.

(4) Gegebenenfalls wird der CE-Kennzeichnung die Identifizierungsnummer der für die in Artikel 43 festgelegten Konformitätsbewertungsverfahren zuständigen notifizierten Stelle hinzugefügt. Die Identifizierungsnummer der notifizierten Stelle ist entweder von der Stelle selbst oder nach ihren Anweisungen durch den Anbieter oder den Bevollmächtigten des Anbieters anzubringen. Diese Identifizierungsnummer wird auch auf jeglichem Werbematerial angegeben, in dem darauf hingewiesen wird, dass das Hochrisiko-KI-System die Anforderungen für die CE-Kennzeichnung erfüllt.

(5) Falls Hochrisiko-KI-Systeme ferner unter andere Rechtsvorschriften der Union fallen, in denen die CE-Kennzeichnung auch vorgesehen ist, bedeutet die CE-Kennzeichnung, dass das Hochrisiko-KI-System auch die Anforderungen dieser anderen Rechtsvorschriften erfüllt.

<a id="art-49"></a>
### Artikel 49 – Registrierung

(1) Vor dem Inverkehrbringen oder der Inbetriebnahme eines in Anhang III aufgeführten Hochrisiko-KI-Systems — mit Ausnahme der in Anhang III Nummer 2 genannten Hochrisiko-KI-Systeme — registriert der Anbieter oder gegebenenfalls sein Bevollmächtigter sich und sein System in der in Artikel 71 genannten EU-Datenbank.

(2) Vor dem Inverkehrbringen oder der Inbetriebnahme eines Hochrisiko-KI-Systems, bei dem der Anbieter zu dem Schluss gelangt ist, dass es nicht hochriskant gemäß Artikel 6 Absatz 3 ist, registriert dieser Anbieter oder gegebenenfalls sein Bevollmächtigter sich und dieses System in der in Artikel 71 genannten EU-Datenbank.

(3) Vor der Inbetriebnahme oder Verwendung eines in Anhang III aufgeführten Hochrisiko-KI-Systems — mit Ausnahme der in Anhang III Nummer 2 aufgeführten Hochrisiko-KI-Systeme — registrieren sich Betreiber, bei denen es sich um Behörden oder Organe, Einrichtungen oder sonstige Stellen der Union oder in ihrem Namen handelnde Personen handelt, in der in Artikel 71 genannten EU-Datenbank, wählen das System aus und registrieren es dort.

(4) Bei den in Anhang III Nummern 1, 6 und 7 genannten Hochrisiko-KI-Systemen erfolgt in den Bereichen Strafverfolgung, Migration, Asyl und Grenzkontrolle die Registrierung gemäß den Absätzen 1, 2 und 3 des vorliegenden Artikels in einem sicheren nicht öffentlichen Teil der in Artikel 71 genannten EU-Datenbank und enthält, soweit zutreffend, lediglich die Informationen gemäß

- a) Anhang VIII Abschnitt A Nummern 1 bis 10 mit Ausnahme der Nummern 6, 8 und 9,

- b) Anhang VIII Abschnitt B Nummern 1 bis 5 sowie Nummern 8 und 9,

- c) Anhang VIII Abschnitt C Nummern 1 bis 3,

- d) Anhang IX Nummern 1, 2, 3 und Nummer 5.

Nur die Kommission und die in Artikel 74 Absatz 8 genannten nationalen Behörden haben Zugang zu den jeweiligen beschränkten Teilen der EU-Datenbank gemäß Unterabsatz 1 dieses Absatzes.

(5) Die in Anhang III Nummer 2 genannten Hochrisiko-KI-Systeme werden auf nationaler Ebene registriert.

<a id="chapter-iv"></a>
## Kapitel IV – TRANSPARENZPFLICHTEN FÜR ANBIETER UND BETREIBER BESTIMMTER KI-SYSTEME

<a id="art-50"></a>
### Artikel 50 – Transparenzpflichten für Anbieter und Betreiber bestimmter KI-Systeme

(1) Die Anbieter stellen sicher, dass KI-Systeme, die für die direkte Interaktion mit natürlichen Personen bestimmt sind, so konzipiert und entwickelt werden, dass die betreffenden natürlichen Personen informiert werden, dass sie mit einem KI-System interagieren, es sei denn, dies ist aus Sicht einer angemessen informierten, aufmerksamen und verständigen natürlichen Person aufgrund der Umstände und des Kontexts der Nutzung offensichtlich. Diese Pflicht gilt nicht für gesetzlich zur Aufdeckung, Verhütung, Ermittlung oder Verfolgung von Straftaten zugelassene KI-Systeme, wenn geeignete Schutzvorkehrungen für die Rechte und Freiheiten Dritter bestehen, es sei denn, diese Systeme stehen der Öffentlichkeit zur Anzeige einer Straftat zur Verfügung.

(2) Anbieter von KI-Systemen, einschließlich KI-Systemen mit allgemeinem Verwendungszweck, die synthetische Audio-, Bild-, Video- oder Textinhalte erzeugen, stellen sicher, dass die Ausgaben des KI-Systems in einem maschinenlesbaren Format gekennzeichnet und als künstlich erzeugt oder manipuliert erkennbar sind. Die Anbieter sorgen dafür, dass — soweit technisch möglich — ihre technischen Lösungen wirksam, interoperabel, belastbar und zuverlässig sind und berücksichtigen dabei die Besonderheiten und Beschränkungen der verschiedenen Arten von Inhalten, die Umsetzungskosten und den allgemein anerkannten Stand der Technik, wie er in den einschlägigen technischen Normen zum Ausdruck kommen kann. Diese Pflicht gilt nicht, soweit die KI-Systeme eine unterstützende Funktion für die Standardbearbeitung ausführen oder die vom Betreiber bereitgestellten Eingabedaten oder deren Semantik nicht wesentlich verändern oder wenn sie zur Aufdeckung, Verhütung, Ermittlung oder Verfolgung von Straftaten gesetzlich zugelassen sind.

(3) Die Betreiber eines Emotionserkennungssystems oder eines Systems zur biometrischen Kategorisierung informieren die davon betroffenen natürlichen Personen über den Betrieb des Systems und verarbeiten personenbezogene Daten gemäß den Verordnungen (EU) 2016/679 und (EU) 2018/1725 und der Richtlinie (EU) 2016/680. Diese Pflicht gilt nicht für gesetzlich zur Aufdeckung, Verhütung oder Ermittlung von Straftaten zugelassene KI-Systeme, die zur biometrischen Kategorisierung und Emotionserkennung im Einklang mit dem Unionsrecht verwendet werden, sofern geeignete Schutzvorkehrungen für die Rechte und Freiheiten Dritter bestehen.

(4) Betreiber eines KI-Systems, das Bild-, Ton- oder Videoinhalte erzeugt oder manipuliert, die ein Deepfake sind, müssen offenlegen, dass die Inhalte künstlich erzeugt oder manipuliert wurden. Diese Pflicht gilt nicht, wenn die Verwendung zur Aufdeckung, Verhütung, Ermittlung oder Verfolgung von Straftaten gesetzlich zugelassen ist. Ist der Inhalt Teil eines offensichtlich künstlerischen, kreativen, satirischen, fiktionalen oder analogen Werks oder Programms, so beschränken sich die in diesem Absatz festgelegten Transparenzpflichten darauf, das Vorhandensein solcher erzeugten oder manipulierten Inhalte in geeigneter Weise offenzulegen, die die Darstellung oder den Genuss des Werks nicht beeinträchtigt.

Betreiber eines KI-Systems, das Text erzeugt oder manipuliert, der veröffentlicht wird, um die Öffentlichkeit über Angelegenheiten von öffentlichem Interesse zu informieren, müssen offenlegen, dass der Text künstlich erzeugt oder manipuliert wurde. Diese Pflicht gilt nicht, wenn die Verwendung zur Aufdeckung, Verhütung, Ermittlung oder Verfolgung von Straftaten gesetzlich zugelassen ist oder wenn die durch KI erzeugten Inhalte einem Verfahren der menschlichen Überprüfung oder redaktionellen Kontrolle unterzogen wurden und wenn eine natürliche oder juristische Person die redaktionelle Verantwortung für die Veröffentlichung der Inhalte trägt.

(5) Die in den Absätzen 1 bis 4 genannten Informationen werden den betreffenden natürlichen Personen spätestens zum Zeitpunkt der ersten Interaktion oder Aussetzung in klarer und eindeutiger Weise bereitgestellt. Die Informationen müssen den geltenden Barrierefreiheitsanforderungen entsprechen.

(6) Die Absätze 1 bis 4 lassen die in Kapitel III festgelegten Anforderungen und Pflichten unberührt und berühren nicht andere Transparenzpflichten, die im Unionsrecht oder dem nationalen Recht für Betreiber von KI-Systemen festgelegt sind.

▼M1

(7) Die Kommission fördert und erleichtert die Ausarbeitung von Praxisleitfäden auf Unionsebene, um die wirksame Umsetzung der Pflichten in Bezug auf die Feststellung, Markierung und Kennzeichnung künstlich erzeugter oder manipulierter Inhalte zu erleichtern. Die Kommission prüft unter weitestgehender Berücksichtigung der Stellungnahme des KI-Gremiums nach dem Verfahren des Artikels 56 Absatz 6 Unterabsatz 1, ob die Befolgung dieser Praxisleitfäden angemessen ist, um die Einhaltung der in den Absätzen 2 und 4 dieses Artikels festgelegten Pflichten zu gewährleisten. Hält sie den Praxisleitfaden für unangemessen, so kann die Kommission einen Durchführungsrechtsakt gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen, in dem gemeinsame Vorschriften für die Umsetzung dieser Pflichten festgelegt werden.

▼B

<a id="chapter-v"></a>
## Kapitel V – KI-MODELLE MIT ALLGEMEINEM VERWENDUNGSZWECK

<a id="chapter-v-section-1"></a>
## Abschnitt 1 – Einstufungsvorschriften

<a id="art-51"></a>
### Artikel 51 – Einstufung von KI-Modellen mit allgemeinem Verwendungszweck als KI-Modelle mit allgemeinem Verwendungszweck mit systemischem Risiko

(1) Ein KI-Modell mit allgemeinem Verwendungszweck wird als KI-Modell mit allgemeinem Verwendungszweck mit systemischem Risiko eingestuft, wenn eine der folgenden Bedingungen erfüllt ist:

- a) Es verfügt über Fähigkeiten mit hohem Wirkungsgrad, die mithilfe geeigneter technischer Instrumente und Methoden, einschließlich Indikatoren und Benchmarks, bewertet werden;

- b) einem unter Berücksichtigung der in Anhang XIII festgelegten Kriterien von der Kommission von Amts wegen oder aufgrund einer qualifizierten Warnung des wissenschaftlichen Gremiums getroffenen Entscheidung zufolge verfügt es über Fähigkeiten oder eine Wirkung, die denen gemäß Buchstabe a entsprechen.

(2) Bei einem KI-Modell mit allgemeinem Verwendungszweck wird angenommen, dass es über Fähigkeiten mit hohem Wirkungsgrad gemäß Absatz 1 Buchstabe a verfügt, wenn die kumulierte Menge der für sein Training verwendeten Berechnungen, gemessen in Gleitkommaoperationen, mehr als 1025 beträgt.

(3) Die Kommission erlässt gemäß Artikel 97 delegierte Rechtsakte zur Änderung der in den Absätzen 1 und 2 des vorliegenden Artikels aufgeführten Schwellenwerte sowie zur Ergänzung von Benchmarks und Indikatoren vor dem Hintergrund sich wandelnder technologischer Entwicklungen, wie z. B. algorithmische Verbesserungen oder erhöhte Hardwareeffizienz, wenn dies erforderlich ist, damit diese Schwellenwerte dem Stand der Technik entsprechen.

<a id="art-52"></a>
### Artikel 52 – Verfahren

(1) Erfüllt ein KI-Modell mit allgemeinem Verwendungszweck die Bedingung gemäß Artikel 51 Absatz 1 Buchstabe a, so teilt der betreffende Anbieter dies der Kommission unverzüglich, in jedem Fall jedoch innerhalb von zwei Wochen, nachdem diese Bedingung erfüllt ist oder bekannt wird, dass sie erfüllt wird, mit. Diese Mitteilung muss die Informationen enthalten, die erforderlich sind, um nachzuweisen, dass die betreffende Bedingung erfüllt ist. Erlangt die Kommission Kenntnis von einem KI-Modell mit allgemeinem Verwendungszweck, das systemische Risiken birgt, die ihr nicht mitgeteilt wurden, so kann sie entscheiden, es als Modell mit systemischen Risiken auszuweisen.

(2) Der Anbieter eines KI-Modells mit allgemeinem Verwendungszweck, das die in Artikel 51 Absatz 1 Buchstabe a genannte Bedingung erfüllt, kann in seiner Mitteilung hinreichend begründete Argumente vorbringen, um nachzuweisen, dass das KI-Modell mit allgemeinem Verwendungszweck, obwohl es diese Bedingung erfüllt, aufgrund seiner besonderen Merkmale außerordentlicherweise keine systemischen Risiken birgt und daher nicht als KI-Modell mit allgemeinem Verwendungszweck mit systemischem Risiko eingestuft werden sollte.

(3) Gelangt die Kommission zu dem Schluss, dass die gemäß Absatz 2 vorgebrachten Argumente nicht hinreichend begründet sind, und konnte der betreffende Anbieter nicht nachweisen, dass das KI-Modell mit allgemeinem Verwendungszweck aufgrund seiner besonderen Merkmale keine systemischen Risiken aufweist, weist sie diese Argumente zurück, und das KI-Modell mit allgemeinem Verwendungszweck gilt als KI-Modell mit allgemeiner Zweckbestimmung mit systemischem Risiko.

(4) Die Kommission kann ein KI-Modell mit allgemeinem Verwendungszweck von Amts wegen oder aufgrund einer qualifizierten Warnung des wissenschaftlichen Gremiums gemäß Artikel 90 Absatz 1 Buchstabe a auf der Grundlage der in Anhang XIII festgelegten Kriterien als KI-Modell mit systemischen Risiken ausweisen.

Die Kommission ist befugt, gemäß Artikel 97 delegierte Rechtsakte zu erlassen, um Anhang XIII zu ändern, indem die in dem genannten Anhang genannten Indikatoren präzisiert und aktualisiert werden.

(5) Stellt der Anbieter, dessen Modell gemäß Absatz 4 als KI-Modell mit allgemeinem Verwendungszweck mit systemischem Risiko ausgewiesen wurde, einen entsprechenden Antrag, berücksichtigt die Kommission den Antrag und kann entscheiden, erneut zu prüfen, ob beim KI-Modell mit allgemeinem Verwendungszweck auf der Grundlage der in Anhang XIII festgelegten Kriterien immer noch davon ausgegangen werden kann, dass es systemische Risiken aufweist. Dieser Antrag muss objektive, detaillierte und neue Gründe enthalten, die sich seit der Entscheidung zur Ausweisung ergeben haben. Die Anbieter können frühestens sechs Monate nach der Entscheidung zur Ausweisung eine Neubewertung beantragen. Entscheidet die Kommission nach ihrer Neubewertung, die Ausweisung als KI-Modell mit allgemeiner Zweckbestimmung mit systemischem Risiko beizubehalten, können die Anbieter frühestens sechs Monate nach dieser Entscheidung eine Neubewertung beantragen.

(6) Die Kommission stellt sicher, dass eine Liste von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko veröffentlicht wird, und hält diese Liste unbeschadet der Notwendigkeit, Rechte des geistigen Eigentums und vertrauliche Geschäftsinformationen oder Geschäftsgeheimnisse im Einklang mit dem Unionsrecht und dem nationalen Recht zu achten und zu schützen, auf dem neuesten Stand.

<a id="chapter-v-section-2"></a>
## Abschnitt 2 – Pflichten für Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

<a id="art-53"></a>
### Artikel 53 – Pflichten für Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

(1) Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

- a) erstellen und aktualisieren die technische Dokumentation des Modells, einschließlich seines Trainings- und Testverfahrens und der Ergebnisse seiner Bewertung, die mindestens die in Anhang XI aufgeführten Informationen enthält, damit sie dem Büro für Künstliche Intelligenz und den zuständigen nationalen Behörden auf Anfrage zur Verfügung gestellt werden kann;

- b) erstellen und aktualisieren Informationen und die Dokumentation und stellen sie Anbietern von KI-Systemen zur Verfügung, die beabsichtigen, das KI-Modell mit allgemeinem Verwendungszweck in ihre KI-Systeme zu integrieren. Unbeschadet der Notwendigkeit, die Rechte des geistigen Eigentums und vertrauliche Geschäftsinformationen oder Geschäftsgeheimnisse im Einklang mit dem Unionsrecht und dem nationalen Recht zu achten und zu schützen, müssen die Informationen und die Dokumentation

  - i) die Anbieter von KI-Systemen in die Lage versetzen, die Fähigkeiten und Grenzen des KI-Modells mit allgemeinem Verwendungszweck gut zu verstehen und ihren Pflichten gemäß dieser Verordnung nachzukommen, und

  - ii) zumindest die in Anhang XII genannten Elemente enthalten;

- c) bringen eine Strategie zur Einhaltung des Urheberrechts der Union und damit zusammenhängender Rechte und insbesondere zur Ermittlung und Einhaltung eines gemäß Artikel 4 Absatz 3 der Richtlinie (EU) 2019/790 geltend gemachten Rechtsvorbehalts, auch durch modernste Technologien, auf den Weg;

- d) erstellen und veröffentlichen eine hinreichend detaillierte Zusammenfassung der für das Training des KI-Modells mit allgemeinem Verwendungszweck verwendeten Inhalte nach einer vom Büro für Künstliche Intelligenz bereitgestellten Vorlage.

(2) Die Pflichten gemäß Absatz 1 Buchstaben a und b gelten nicht für Anbieter von KI-Modellen, die im Rahmen einer freien und quelloffenen Lizenz bereitgestellt werden, die den Zugang, die Nutzung, die Änderung und die Verbreitung des Modells ermöglicht und deren Parameter, einschließlich Gewichte, Informationen über die Modellarchitektur und Informationen über die Modellnutzung, öffentlich zugänglich gemacht werden. Diese Ausnahme gilt nicht für KI-Modellen mit allgemeinem Verwendungszweck mit systemischen Risiken.

(3) Anbieter von KI-Modellen mit allgemeinem Verwendungszweck arbeiten bei der Ausübung ihrer Zuständigkeiten und Befugnisse gemäß dieser Verordnung erforderlichenfalls mit der Kommission und den zuständigen nationalen Behörden zusammen.

(4) Anbieter von KI-Modellen mit allgemeinem Verwendungszweck können sich bis zur Veröffentlichung einer harmonisierten Norm auf Praxisleitfäden im Sinne des Artikels 56 stützen, um die Einhaltung der in Absatz 1 des vorliegenden Artikels genannten Pflichten nachzuweisen. Die Einhaltung der harmonisierten europäischen Norm begründet für die Anbieter die Vermutung der Konformität, insoweit diese Normen diese Verpflichtungen abdecken. Anbieter von KI-Modellen mit allgemeinem Verwendungszweck, die keinen genehmigten Praxisleitfaden befolgen oder eine harmonisierte europäische Norm nicht einhalten, müssen geeignete alternative Verfahren der Einhaltung aufzeigen, die von der Kommission zu bewerten sind.

(5) Um die Einhaltung von Anhang XI, insbesondere Nummer 2 Buchstaben d und e, zu erleichtern, ist die Kommission befugt, gemäß Artikel 97 delegierte Rechtsakte zu erlassen, um die Mess- und Berechnungsmethoden im Einzelnen festzulegen, damit eine vergleichbare und überprüfbare Dokumentation ermöglicht wird.

(6) Die Kommission ist befugt, gemäß Artikel 97 Absatz 2 delegierte Rechtsakte zu erlassen, um die Anhänge XI und XII vor dem Hintergrund sich wandelnder technologischer Entwicklungen zu ändern.

(7) Jegliche Informationen oder Dokumentation, die gemäß diesem Artikel erlangt werden, einschließlich Geschäftsgeheimnisse, werden im Einklang mit den in Artikel 78 festgelegten Vertraulichkeitspflichten behandelt.

<a id="art-54"></a>
### Artikel 54 – Bevollmächtigte der Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

(1) Anbieter, die in Drittländern niedergelassen sind, benennen vor dem Inverkehrbringen eines KI-Modells mit allgemeinem Verwendungszweck auf dem Unionsmarkt schriftlich einen in der Union niedergelassenen Bevollmächtigten.

(2) Der Anbieter muss seinem Bevollmächtigten ermöglichen, die Aufgaben wahrzunehmen, die im vom Anbieter erhaltenen Auftrag festgelegt sind.

(3) Der Bevollmächtigte nimmt die Aufgaben wahr, die in seinem vom Anbieter erhaltenen Auftrag festgelegt sind. Er stellt dem Büro für Künstliche Intelligenz auf Anfrage eine Kopie des Auftrags in einer der Amtssprachen der Institutionen der Union bereit. Für die Zwecke dieser Verordnung ermächtigt der Auftrag den Bevollmächtigten zumindest zur Wahrnehmung folgender Aufgaben:

- a) Überprüfung, ob die technische Dokumentation gemäß Anhang XI erstellt wurde und alle Pflichten gemäß Artikel 53 und gegebenenfalls gemäß Artikel 55 vom Anbieter erfüllt wurden;

- b) Bereithaltung einer Kopie der technischen Dokumentation gemäß Anhang XI für das Büro für Künstliche Intelligenz und die zuständigen nationalen Behörden für einen Zeitraum von zehn Jahren nach dem Inverkehrbringen des KI-Modells mit allgemeinem Verwendungszweck und der Kontaktdaten des Anbieters, der den Bevollmächtigten benannt hat;

- c) Bereitstellung sämtlicher zum Nachweis der Einhaltung der Pflichten gemäß diesem Kapitel erforderlichen Informationen und Dokumentation, einschließlich der unter Buchstabe b genannten Informationen und Dokumentation, an das Büro für Künstliche Intelligenz auf begründeten Antrag;

- d) Zusammenarbeit mit dem Büro für Künstliche Intelligenz und den zuständigen Behörden auf begründeten Antrag bei allen Maßnahmen, die sie im Zusammenhang mit einem KI-Modell mit allgemeinem Verwendungszweck ergreifen, auch wenn das Modell in KI-Systeme integriert ist, die in der Union in Verkehr gebracht oder in Betrieb genommen werden.

(4) Mit dem Auftrag wird der Bevollmächtigte ermächtigt, neben oder anstelle des Anbieters als Ansprechpartner für das Büro für Künstliche Intelligenz oder die zuständigen Behörden in allen Fragen zu dienen, die die Gewährleistung der Einhaltung dieser Verordnung betreffen.

(5) Der Bevollmächtigte beendet den Auftrag, wenn er der Auffassung ist oder Grund zu der Annahme hat, dass der Anbieter gegen seine Pflichten gemäß dieser Verordnung verstößt. In einem solchen Fall informiert er auch das Büro für Künstliche Intelligenz unverzüglich über die Beendigung des Auftrags und die Gründe dafür.

(6) Die Pflicht gemäß diesem Artikel gilt nicht für Anbieter von KI-Modellen, die im Rahmen einer freien und quelloffenen Lizenz bereitgestellt werden, die den Zugang, die Nutzung, die Änderung und die Verbreitung des Modells ermöglicht und deren Parameter, einschließlich Gewichte, Informationen über die Modellarchitektur und Informationen über die Modellnutzung, öffentlich zugänglich gemacht werden, es sei denn, die KI-Modelle mit allgemeinem Verwendungszweck bergen systemische Risiken.

<a id="chapter-v-section-3"></a>
## Abschnitt 3 – Pflichten der Anbieter von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko

<a id="art-55"></a>
### Artikel 55 – Pflichten der Anbieter von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko

(1) Zusätzlich zu den in den Artikeln 53 und 54 aufgeführten Pflichten müssen Anbieter von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko

- a) eine Modellbewertung mit standardisierten Protokollen und Instrumenten, die dem Stand der Technik entsprechen, durchführen, wozu auch die Durchführung und Dokumentation von Angriffstests beim Modell gehören, um systemische Risiken zu ermitteln und zu mindern,

- b) mögliche systemische Risiken auf Unionsebene — einschließlich ihrer Ursachen —, die sich aus der Entwicklung, dem Inverkehrbringen oder der Verwendung von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko ergeben können, bewerten und mindern,

- c) einschlägige Informationen über schwerwiegende Vorfälle und mögliche Abhilfemaßnahmen erfassen und dokumentieren und das Büro für Künstliche Intelligenz und gegebenenfalls die zuständigen nationalen Behörden unverzüglich darüber unterrichten,

- d) ein angemessenes Maß an Cybersicherheit für die KI-Modelle mit allgemeinem Verwendungszweck mit systemischem Risiko und die physische Infrastruktur des Modells gewährleisten.

(2) Anbieter von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko können sich bis zur Veröffentlichung einer harmonisierten Norm auf Praxisleitfäden im Sinne des Artikels 56 stützen, um die Einhaltung der in Absatz 1 des vorliegenden Artikels genannten Pflichten nachzuweisen. Die Einhaltung der harmonisierten europäischen Norm begründet für die Anbieter die Vermutung der Konformität, insoweit diese Normen diese Verpflichtungen abdecken. Anbieter von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko, die einen genehmigten Praxisleitfaden nicht befolgen oder eine harmonisierte europäische Norm nicht einhalten, müssen geeignete alternative Verfahren der Einhaltung aufzeigen, die von der Kommission zu bewerten sind.

(3) Jegliche Informationen oder Dokumentation, die gemäß diesem Artikel erlangt werden, werden im Einklang mit den in Artikel 78 festgelegten Vertraulichkeitspflichten behandelt.

<a id="chapter-v-section-4"></a>
## Abschnitt 4 – Praxisleitfäden

<a id="art-56"></a>
### Artikel 56 – Praxisleitfäden

(1) Das Büro für Künstliche Intelligenz fördert und erleichtert die Ausarbeitung von Praxisleitfäden auf Unionsebene, um unter Berücksichtigung internationaler Ansätze zur ordnungsgemäßen Anwendung dieser Verordnung beizutragen.

(2) Das Büro für Künstliche Intelligenz und das KI-Gremium streben an, sicherzustellen, dass die Praxisleitfäden mindestens die in den Artikeln 53 und 55 vorgesehenen Pflichten abdecken, einschließlich der folgenden Aspekte:

- a) Mittel, mit denen sichergestellt wird, dass die in Artikel 53 Absatz 1 Buchstaben a und b genannten Informationen vor dem Hintergrund der Marktentwicklungen und technologischen Entwicklungen auf dem neuesten Stand gehalten werden;

- b) die angemessene Detailgenauigkeit bei der Zusammenfassung der für das Training verwendeten Inhalte;

- c) die Ermittlung von Art und Wesen der systemischen Risiken auf Unionsebene, gegebenenfalls einschließlich ihrer Ursachen;

- d) die Maßnahmen, Verfahren und Modalitäten für die Bewertung und das Management der systemischen Risiken auf Unionsebene, einschließlich ihrer Dokumentation, die in einem angemessenen Verhältnis zu den Risiken stehen, ihrer Schwere und Wahrscheinlichkeit Rechnung tragen und die spezifischen Herausforderungen bei der Bewältigung dieser Risiken vor dem Hintergrund der möglichen Arten der Entstehung und des Eintretens solcher Risiken entlang der KI-Wertschöpfungskette berücksichtigen.

(3) Das Büro für Künstliche Intelligenz kann alle Anbieter von KI-Modellen mit allgemeinem Verwendungszweck sowie die einschlägigen zuständigen nationalen Behörden ersuchen, sich an der Ausarbeitung von Praxisleitfäden zu beteiligen. Organisationen der Zivilgesellschaft, die Industrie, die Wissenschaft und andere einschlägige Interessenträger wie nachgelagerte Anbieter und unabhängige Sachverständige können den Prozess unterstützen.

(4) Das Büro für Künstliche Intelligenz und das KI-Gremium streben an, sicherzustellen, dass in den Praxisleitfäden ihre spezifischen Ziele eindeutig festgelegt sind und Verpflichtungen oder Maßnahmen, gegebenenfalls einschließlich wesentlicher Leistungsindikatoren, enthalten, um die Verwirklichung dieser Ziele gewährleisten, und dass sie den Bedürfnissen und Interessen aller interessierten Kreise, einschließlich betroffener Personen, auf Unionsebene gebührend Rechnung tragen.

(5) Das Büro für Künstliche Intelligenz strebt an, sicherzustellen, dass die an Praxisleitfäden Beteiligten dem Büro für Künstliche Intelligenz regelmäßig über die Umsetzung der Verpflichtungen, die ergriffenen Maßnahmen und deren Ergebnisse, die gegebenenfalls auch anhand der wesentlichen Leistungsindikatoren gemessen werden, Bericht erstatten. Bei den wesentlichen Leistungsindikatoren und den Berichtspflichten wird den Größen- und Kapazitätsunterschieden zwischen den verschiedenen Beteiligten Rechnung getragen.

▼M1

(6) Die Kommission und das KI-Gremium überwachen und bewerten regelmäßig die Verwirklichung der Ziele der Praxisleitfäden durch die Beteiligten und deren Beitrag zur ordnungsgemäßen Anwendung dieser Verordnung. Die Kommission bewertet unter weitestgehender Berücksichtigung der Stellungnahme des KI-Gremiums, ob die Praxisleitfäden die in den Artikeln 53 und 55 vorgesehenen Pflichten abdecken, und überwacht und bewertet regelmäßig die Verwirklichung von deren Zielen. Die Kommission veröffentlicht ihre Bewertung der Angemessenheit der Praxisleitfäden.

▼B

(7) Das Büro für Künstliche Intelligenz kann alle Anbieter von KI-Modellen mit allgemeinem Verwendungszweck ersuchen, die Praxisleitfäden zu befolgen. Für Anbieter von KI-Modellen mit allgemeinem Verwendungszweck, die keine systemischen Risiken bergen, kann diese Befolgung auf die in Artikel 53 vorgesehenen Pflichten beschränkt werden, es sei denn, sie erklären ausdrücklich ihr Interesse, sich dem ganzen Kodex anzuschließen.

(8) Das Büro für Künstliche Intelligenz fördert und erleichtert gegebenenfalls auch die Überprüfung und Anpassung der Praxisleitfäden, insbesondere vor dem Hintergrund neuer Normen. Das Büro für Künstliche Intelligenz unterstützt bei der Bewertung der verfügbaren Normen.

(9) Praxisleitfäden müssen spätestens am 2. Mai 2025 vorliegen. Das Büro für Künstliche Intelligenz unternimmt die erforderlichen Schritte, einschließlich des Ersuchens von Anbietern gemäß Absatz 7.

Kann bis zum 2. August 2025 ein Verhaltenskodex nicht fertiggestellt werden oder erachtet das Büro für Künstliche Intelligenz dies nach seiner Bewertung gemäß Absatz 6 des vorliegenden Artikels für nicht angemessen, kann die Kommission im Wege von Durchführungsrechtsakten gemeinsame Vorschriften für die Umsetzung der in den Artikeln 53 und 55 vorgesehenen Pflichten, einschließlich der in Absatz 2 des vorliegenden Artikels genannten Aspekte, festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

<a id="chapter-vi"></a>
## Kapitel VI – MASSNAHMEN ZUR INNOVATIONSFÖRDERUNG

<a id="art-57"></a>
### Artikel 57 – KI-Reallabore

▼M1

(1) Die Mitgliedstaaten sorgen dafür, dass ihre zuständigen Behörden mindestens ein KI-Reallabor auf nationaler Ebene einrichten, das bis zum 2. August 2027 einsatzbereit sein muss. Dieses Reallabor kann auch gemeinsam mit den zuständigen Behörden anderer Mitgliedstaaten eingerichtet werden. Die Kommission kann technische Unterstützung, Beratung und Instrumente für die Einrichtung und den Betrieb von KI-Reallaboren bereitstellen.

▼B

Die Verpflichtung nach Unterabsatz 1 kann auch durch Beteiligung an einem bestehenden Reallabor erfüllt werden, sofern eine solche Beteiligung die nationale Abdeckung der teilnehmenden Mitgliedstaaten in gleichwertigem Maße gewährleistet.

(2) Es können auch zusätzliche KI-Reallabore auf regionaler oder lokaler Ebene oder gemeinsam mit den zuständigen Behörden anderer Mitgliedstaaten eingerichtet werden;

▼M1

(3) Der Europäische Datenschutzbeauftragte kann ein KI-Reallabor für die Organe, Einrichtungen und sonstigen Stellen der Union einrichten. Für diesen Zweck gelten Bezugnahmen auf die zuständigen nationalen Behörden in diesem Kapitel als Bezugnahmen auf den Europäischen Datenschutzbeauftragten.

▼M1

(3a) Das Büro für Künstliche Intelligenz kann auf Unionsebene ein KI-Reallabor für KI-Systeme einrichten, die unter Artikel 75 Absatz 1 fallen. Für diesen Zweck gelten Bezugnahmen auf die zuständigen nationalen Behörden in diesem Kapitel gegebenenfalls als Bezugnahmen auf das Büro für Künstliche Intelligenz. Diese KI-Reallabor wird in enger Zusammenarbeit mit den jeweils zuständigen Behörden umgesetzt, insbesondere wenn die Einhaltung anderer Rechtsvorschriften der Union als dieser Verordnung im KI-Reallabor beaufsichtigt wird, und gewährt KMU, einschließlich Start-up-Unternehmen, und kleinen Midcap-Unternehmen vorrangigen Zugang dazu.

Die Einrichtung eines KI-Reallabors auf Unionsebene durch das Büro für Künstliche Intelligenz lässt die Zuständigkeiten der Mitgliedstaaten für die Einrichtung und Beaufsichtigung von KI-Reallaboren für KI-Systeme, die ihrer Aufsicht unterliegen, unberührt.

▼B

(4) Die Mitgliedstaaten stellen sicher, dass die in den Absätzen 1 und 2 genannten zuständigen Behörden ausreichende Mittel bereitstellen, um diesem Artikel wirksam und zeitnah nachzukommen. Gegebenenfalls arbeiten die zuständigen nationalen Behörden mit anderen einschlägigen Behörden zusammen und können die Einbeziehung anderer Akteure des KI-Ökosystems gestatten. Andere Reallabore, die im Rahmen des Unionsrechts oder des nationalen Rechts eingerichtet wurden, bleiben von diesem Artikel unberührt. Die Mitgliedstaaten sorgen dafür, dass die diese anderen Reallabore beaufsichtigenden Behörden und die zuständigen nationalen Behörden angemessen zusammenarbeiten.

▼M1

(5) Die nach diesem Artikel eingerichteten KI-Reallabore bieten eine kontrollierte Umgebung, um Innovation zu fördern und die Entwicklung, das Training, das Testen und die Validierung innovativer KI-Systeme für einen begrenzten Zeitraum vor ihrem Inverkehrbringen oder ihrer Inbetriebnahme nach einem bestimmten zwischen den Anbietern oder zukünftigen Anbietern und den zuständigen Behörden vereinbarten Reallabor-Plan zu erleichtern, wobei sie dafür sorgen, dass angemessene Schutzvorkehrungen bestehen. In diesen Reallaboren können auch darin beaufsichtigte Tests unter Realbedingungen durchgeführt werden. Der Plan für das Reallabor enthält, soweit zutreffend, den Plan für einen Test unter Realbedingungen gemäß Artikel 60 und Artikel 60a.

▼B

(6) Die zuständigen Behörden stellen innerhalb der KI-Reallabore gegebenenfalls Anleitung, Aufsicht und Unterstützung bereit, um Risiken, insbesondere im Hinblick auf Grundrechte, Gesundheit und Sicherheit, Tests und Risikominderungsmaßnahmen sowie deren Wirksamkeit hinsichtlich der Pflichten und Anforderungen dieser Verordnung und gegebenenfalls anderem Unionsrecht und nationalem Recht, deren Einhaltung innerhalb des Reallabors beaufsichtigt wird, zu ermitteln.

(7) Die zuständigen Behörden stellen den Anbietern und zukünftigen Anbietern, die am KI-Reallabor teilnehmen, Leitfäden zu regulatorischen Erwartungen und zur Erfüllung der in dieser Verordnung festgelegten Anforderungen und Pflichten zur Verfügung.

Die zuständige Behörde legt dem Anbieter oder zukünftigen Anbieter des KI-Systems auf dessen Anfrage einen schriftlichen Nachweis für die im Reallabor erfolgreich durchgeführten Tätigkeiten vor. Außerdem legt die zuständige Behörde einen Abschlussbericht vor, in dem sie die im Reallabor durchgeführten Tätigkeiten, deren Ergebnisse und die gewonnenen Erkenntnisse im Einzelnen darlegt. Die Anbieter können diese Unterlagen nutzen, um im Rahmen des Konformitätsbewertungsverfahrens oder einschlägiger Marktüberwachungstätigkeiten nachzuweisen, dass sie dieser Verordnung nachkommen. In diesem Zusammenhang werden die Abschlussberichte und die von der zuständigen nationalen Behörde vorgelegten schriftlichen Nachweise von den Marktüberwachungsbehörden und den notifizierten Stellen im Hinblick auf eine Beschleunigung der Konformitätsbewertungsverfahren in angemessenem Maße positiv gewertet.

(8) Vorbehaltlich der in Artikel 78 enthaltenen Bestimmungen über die Vertraulichkeit und im Einvernehmen mit den Anbietern oder zukünftigen Anbietern, sind die Kommission und das KI-Gremium befugt, die Abschlussberichte einzusehen und tragen diesen gegebenenfalls bei der Wahrnehmung ihrer Aufgaben gemäß dieser Verordnung Rechnung. Wenn der Anbieter oder der zukünftige Anbieter und die zuständige nationale Behörde ihr ausdrückliches Einverständnis erklären, kann der Abschlussbericht über die in diesem Artikel genannte zentrale Informationsplattform veröffentlicht werden.

(9) Die Einrichtung von KI-Reallaboren soll zu den folgenden Zielen beitragen:

- a) Verbesserung der Rechtssicherheit, um für die Einhaltung der Regulierungsvorschriften dieser Verordnung oder, gegebenenfalls, anderem geltenden Unionsrecht und nationalem Recht zu sorgen;

- b) Förderung des Austauschs bewährter Verfahren durch Zusammenarbeit mit den am KI-Reallabor beteiligten Behörden;

- c) Förderung von Innovation und Wettbewerbsfähigkeit sowie Erleichterung der Entwicklung eines KI-Ökosystems;

- d) Leisten eines Beitrags zum evidenzbasierten regulatorischen Lernen;

▼M1

- e) Erleichterung und Beschleunigung des Zugangs von KI-Systemen zum Unionsmarkt, insbesondere wenn sie von KMU, einschließlich Start-up-Unternehmen, und von kleinen Midcap-Unternehmen angeboten werden.

(10) Soweit die innovativen KI-Systeme personenbezogene Daten verarbeiten oder anderweitig der Aufsicht anderer nationaler Behörden oder zuständiger Behörden unterstehen, die den Zugang zu personenbezogenen Daten gewähren oder unterstützen, sorgen die zuständigen nationalen Behörden dafür, dass die zuständigen Datenschutzbehörden oder diese anderen nationalen oder zuständigen Behörden in den Betrieb des KI-Reallabors sowie in die Überwachung dieser Aspekte im vollen Umfang ihrer entsprechenden Aufgaben und Befugnisse einbezogen werden.

▼B

(11) Die KI-Reallabore lassen die Aufsichts- oder Abhilfebefugnisse der die Reallabore beaufsichtigenden zuständigen Behörden, einschließlich auf regionaler oder lokaler Ebene, unberührt. Alle erheblichen Risiken für die Gesundheit und Sicherheit und die Grundrechte, die bei der Entwicklung und Erprobung solcher KI-Systeme festgestellt werden, führen zur sofortigen und angemessenen Risikominderung. Die zuständigen nationalen Behörden sind befugt, das Testverfahren oder die Beteiligung am Reallabor vorübergehend oder dauerhaft auszusetzen, wenn keine wirksame Risikominderung möglich ist, und unterrichten das Büro für Künstliche Intelligenz über diese Entscheidung. Um Innovationen im Bereich KI in der Union zu fördern, üben die zuständigen nationalen Behörden ihre Aufsichtsbefugnisse im Rahmen des geltenden Rechts aus, indem sie bei der Anwendung der Rechtsvorschriften auf ein bestimmtes KI-Reallabor ihren Ermessensspielraum nutzen.

(12) Die am KI-Reallabor beteiligten Anbieter und zukünftigen Anbieter bleiben nach geltendem Recht der Union und nationalem Haftungsrecht für Schäden haftbar, die Dritten infolge der Erprobung im Reallabor entstehen. Sofern die zukünftigen Anbieter den spezifischen Plan und die Bedingungen für ihre Beteiligung beachten und der Anleitung durch die zuständigen nationalen Behörden in gutem Glauben folgen, werden jedoch von den Behörden keine Geldbußen für Verstöße gegen diese Verordnung verhängt. In Fällen, in denen andere zuständige Behörden, die für anderes Unionsrecht und nationales Recht zuständig sind, aktiv an der Beaufsichtigung des KI-Systems im Reallabor beteiligt waren und Anleitung für die Einhaltung gegeben haben, werden im Hinblick auf dieses Recht keine Geldbußen verhängt.

(13) Die KI-Reallabore sind so konzipiert und werden so umgesetzt, dass sie gegebenenfalls die grenzüberschreitende Zusammenarbeit zwischen zuständigen nationalen Behörden erleichtern.

▼M1

(14) Die zuständigen nationalen Behörden, der Europäische Datenschutzbeauftragte und das Büro für Künstliche Intelligenz koordinieren gegebenenfalls im Einklang mit ihren jeweiligen Befugnissen ihre Tätigkeiten und arbeiten im Rahmen des KI-Gremiums dementsprechend zusammen. Sie können die gemeinsame Einrichtung und den gemeinsamen Betrieb von KI-Reallaboren unterstützen, auch in verschiedenen Sektoren, und sich über einschlägige bewährte Verfahren austauschen.

▼B

(15) Die zuständigen nationalen Behörden unterrichten das Büro für Künstliche Intelligenz und das KI-Gremium über die Einrichtung eines Reallabors und können sie um Unterstützung und Anleitung bitten. Das Büro für Künstliche Intelligenz veröffentlicht eine Liste der geplanten und bestehenden Reallabore und hält sie auf dem neuesten Stand, um eine stärkere Interaktion in den KI-Reallaboren und die grenzüberschreitende Zusammenarbeit zu fördern.

(16) Die zuständigen nationalen Behörden übermitteln dem Büro für Künstliche Intelligenz und dem KI-Gremium jährliche Berichte, und zwar ab einem Jahr nach der Einrichtung des Reallabors und dann jedes Jahr bis zu dessen Beendigung, sowie einen Abschlussbericht. Diese Berichte informieren über den Fortschritt und die Ergebnisse der Umsetzung dieser Reallabore, einschließlich bewährter Verfahren, Vorfällen, gewonnener Erkenntnisse und Empfehlungen zu deren Aufbau, sowie gegebenenfalls über die Anwendung und mögliche Überarbeitung dieser Verordnung, einschließlich ihrer delegierten Rechtsakte und Durchführungsrechtsakte, sowie über die Anwendung anderen Unionsrechts, deren Einhaltung von den zuständigen Behörden innerhalb des Reallabors beaufsichtigt wird. Die zuständigen nationalen Behörden stellen diese jährlichen Berichte oder Zusammenfassungen davon der Öffentlichkeit online zur Verfügung. Die Kommission trägt den jährlichen Berichten gegebenenfalls bei der Wahrnehmung ihrer Aufgaben gemäß dieser Verordnung Rechnung.

(17) Die Kommission richtet eine eigene Schnittstelle ein, die alle relevanten Informationen zu den KI-Reallaboren enthält, um es den Interessenträgern zu ermöglichen, mit den KI-Reallaboren zu interagieren und Anfragen an die zuständigen Behörden zu richten und unverbindliche Beratung zur Konformität von innovativen Produkten, Dienstleistungen und Geschäftsmodellen mit integrierter KI-Technologie im Einklang mit Artikel 62 Absatz 1 Buchstabe c einzuholen. Die Kommission stimmt sich gegebenenfalls proaktiv mit den zuständigen nationalen Behörden ab.

<a id="art-58"></a>
### Artikel 58 – Detaillierte Regelungen für KI-Reallabore und deren Funktionsweise

▼M1

(1) Um eine Zersplitterung in der Union zu vermeiden, erlässt die Kommission Durchführungsrechtsakte, in denen detaillierte Regelungen für die Einrichtung, Entwicklung, Umsetzung, den Betrieb, die Führung und die Beaufsichtigung der KI-Reallabore enthalten sind. In den Durchführungsrechtsakten werden gemeinsame Grundsätze zu den folgenden Aspekten festgelegt:

▼B

- a) Voraussetzungen und Auswahlkriterien für eine Beteiligung am KI-Reallabor;

- b) Verfahren für Antragstellung, Beteiligung, Überwachung, Ausstieg und Beendigung bezüglich des KI-Reallabors, einschließlich Plan und Abschlussbericht für das Reallabor;

- c) für Beteiligte geltende Anforderungen und Bedingungen;

▼M1

- d) detaillierte Vorschriften für die Führung von KI-Reallaboren gemäß Artikel 57, auch in Bezug auf die Einbeziehung der zuständigen Datenschutzbehörden und die Aufsicht durch ebendiese, soweit zutreffend, sowie die Wahrnehmung der Aufgaben der zuständigen Behörden und die Koordinierung und Zusammenarbeit auf nationaler und Unionsebene.

▼B

Diese Durchführungsrechtsakte werden gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

(2) Die in Absatz 1 genannten Durchführungsrechtsakte gewährleisten,

- a) dass KI-Reallabore allen Anbietern oder zukünftigen Anbietern eines KI-Systems, die einen Antrag stellen und die Voraussetzungen und Auswahlkriterien erfüllen, offen stehen; diese Voraussetzungen und Kriterien sind transparent und fair und die zuständigen nationalen Behörden informieren die Antragsteller innerhalb von drei Monaten nach Antragstellung über ihre Entscheidung;

- b) dass die KI-Reallabore einen breiten und gleichberechtigten Zugang ermöglichen und mit der Nachfrage nach Beteiligung Schritt halten; die Anbieter und zukünftigen Anbieter auch Anträge zusammen mit Betreibern oder einschlägigen Dritten, die ihre Partner sind, stellen können;

- c) dass die detaillierten Regelungen und Bedingungen für KI-Reallabore so gut wie möglich die Flexibilität der zuständigen nationalen Behörden bei der Einrichtung und dem Betrieb ihrer KI-Reallabore unterstützen;

- d) dass der Zugang zu KI-Reallaboren für KMU, einschließlich Start-up-Unternehmen, kostenlos ist, unbeschadet außergewöhnlicher Kosten, die die zuständigen nationalen Behörden in einer fairen und verhältnismäßigen Weise einfordern können;

- e) dass den Anbietern und zukünftigen Anbietern die Einhaltung der Verpflichtungen zur Konformitätsbewertung nach dieser Verordnung oder die freiwillige Anwendung der in Artikel 95 genannten Verhaltenskodizes mittels der gewonnenen Erkenntnisse der KI-Reallabore erleichtert wird;

- f) dass KI-Reallabore die Einbeziehung anderer einschlägiger Akteure innerhalb des KI-Ökosystems, wie etwa notifizierte Stellen und Normungsorganisationen, KMU, einschließlich Start-up-Unternehmen, Unternehmen, Innovatoren, Test- und Versuchseinrichtungen, Forschungs- und Versuchslabore, europäische digitale Innovationszentren, Kompetenzzentren und einzelne Forscher begünstigen, um die Zusammenarbeit mit dem öffentlichen und dem privaten Sektor zu ermöglichen und zu erleichtern;

- g) dass die Verfahren, Prozesse und administrativen Anforderungen für die Antragstellung, die Auswahl, die Beteiligung und den Ausstieg aus dem KI-Reallabor einfach, leicht verständlich und klar kommuniziert sind, um die Beteiligung von KMU, einschließlich Start-up-Unternehmen, mit begrenzten rechtlichen und administrativen Kapazitäten zu erleichtern, sowie unionsweit gestrafft sind, um eine Zersplitterung zu vermeiden, und dass die Beteiligung an einem von einem Mitgliedstaat oder dem Europäischen Datenschutzbeauftragten eingerichteten KI-Reallabor gegenseitig und einheitlich anerkannt wird und in der gesamten Union die gleiche Rechtswirkung hat;

- h) dass die Beteiligung an dem KI-Reallabor auf einen der Komplexität und dem Umfang des Projekts entsprechenden Zeitraum beschränkt ist, der von der zuständigen nationalen Behörde verlängert werden kann;

- i) dass die KI-Reallabore die Entwicklung von Instrumenten und Infrastruktur für das Testen, das Benchmarking, die Bewertung und die Erklärung der Dimensionen von KI-Systemen erleichtern, die für das regulatorische Lernen Bedeutung sind, wie etwa Genauigkeit, Robustheit und Cybersicherheit, sowie Maßnahmen zur Risikominderung im Hinblick auf die Grundrechte und die Gesellschaft als Ganzes fördern.

(3) Zukünftige Anbieter in den KI-Reallaboren, insbesondere KMU und Start-up-Unternehmen, werden gegebenenfalls vor der Einrichtung an Dienste verwiesen, die beispielsweise eine Anleitung zur Umsetzung dieser Verordnung oder andere Mehrwertdienste wie Hilfe bei Normungsdokumenten bereitstellen, sowie an Zertifizierungs-, Test- und Versuchseinrichtungen, europäische digitale Innovationszentren und Exzellenzzentren.

(4) Wenn zuständige nationale Behörden in Betracht ziehen, Tests unter Realbedingungen zu genehmigen, die im Rahmen eines KI-Reallabors beaufsichtigt werden, welches nach diesem Artikel einzurichten ist, vereinbaren sie mit den Beteiligten ausdrücklich die Anforderungen und Bedingungen für diese Tests und insbesondere geeignete Schutzvorkehrungen für Grundrechte, Gesundheit und Sicherheit. Gegebenenfalls arbeiten sie mit anderen zuständigen nationalen Behörden zusammen, um für unionsweit einheitliche Verfahren zu sorgen.

<a id="art-59"></a>
### Artikel 59 – Weiterverarbeitung personenbezogener Daten zur Entwicklung bestimmter KI-Systeme im öffentlichen Interesse im KI-Reallabor

(1) Rechtmäßig für andere Zwecke erhobene personenbezogene Daten dürfen im KI-Reallabor ausschließlich für die Zwecke der Entwicklung, des Trainings und des Testens bestimmter KI-Systeme im Reallabor verarbeitet werden, wenn alle der folgenden Bedingungen erfüllt sind:

- a) Die KI-Systeme werden zur Wahrung eines erheblichen öffentlichen Interesses durch eine Behörde oder eine andere natürliche oder juristische Person und in einem oder mehreren der folgenden Bereiche entwickelt:

  - i) öffentliche Sicherheit und öffentliche Gesundheit, einschließlich Erkennung, Diagnose, Verhütung, Bekämpfung und Behandlung von Krankheiten sowie Verbesserung von Gesundheitsversorgungssystemen;

  - ii) hohes Umweltschutzniveau und Verbesserung der Umweltqualität, Schutz der biologischen Vielfalt, Schutz gegen Umweltverschmutzung, Maßnahmen für den grünen Wandel sowie Klimaschutz und Anpassung an den Klimawandel;

  - iii) nachhaltige Energie;

  - iv) Sicherheit und Widerstandsfähigkeit von Verkehrssystemen und Mobilität, kritischen Infrastrukturen und Netzen;

  - v) Effizienz und Qualität der öffentlichen Verwaltung und öffentlicher Dienste;

- b) die verarbeiteten Daten sind für die Erfüllung einer oder mehrerer der in Kapitel III Abschnitt 2 genannten Anforderungen erforderlich, sofern diese Anforderungen durch die Verarbeitung anonymisierter, synthetischer oder sonstiger nicht personenbezogener Daten nicht wirksam erfüllt werden können;

- c) es bestehen wirksame Überwachungsmechanismen, mit deren Hilfe festgestellt wird, ob während der Reallaborversuche hohe Risiken für die Rechte und Freiheiten betroffener Personen gemäß Artikel 35 der Verordnung (EU) 2016/679 und gemäß Artikel 39 der Verordnung (EU) 2018/1725 auftreten können, sowie Reaktionsmechanismen, mit deren Hilfe diese Risiken umgehend eingedämmt werden können und die Verarbeitung bei Bedarf beendet werden kann;

- d) personenbezogene Daten, die im Rahmen des Reallabors verarbeitet werden sollen, befinden sich in einer funktional getrennten, isolierten und geschützten Datenverarbeitungsumgebung unter der Kontrolle des zukünftigen Anbieters, und nur befugte Personen haben Zugriff auf diese Daten;

- e) Anbieter dürfen die ursprünglich erhobenen Daten nur im Einklang mit dem Datenschutzrecht der Union weitergeben; personenbezogene Daten, die im Reallabor erstellt wurden, dürfen nicht außerhalb des Reallabors weitergegeben werden;

- f) eine Verarbeitung personenbezogener Daten im Rahmen des Reallabors führt zu keinen Maßnahmen oder Entscheidungen, die Auswirkungen auf die betroffenen Personen haben, und berührt nicht die Anwendung ihrer Rechte, die in den Rechtsvorschriften der Union über den Schutz personenbezogener Daten festgelegt sind;

- g) im Rahmen des Reallabors verarbeitete personenbezogene Daten sind durch geeignete technische und organisatorische Maßnahmen geschützt und werden gelöscht, sobald die Beteiligung an dem Reallabor endet oder das Ende der Speicherfrist für die personenbezogenen Daten erreicht ist;

- h) die Protokolle der Verarbeitung personenbezogener Daten im Rahmen des Reallabors werden für die Dauer der Beteiligung am Reallabor aufbewahrt, es sei denn, im Unionsrecht oder nationalen Recht ist etwas anderes bestimmt;

- i) eine vollständige und detaillierte Beschreibung des Prozesses und der Gründe für das Trainieren, Testen und Validieren des KI-Systems wird zusammen mit den Testergebnissen als Teil der technischen Dokumentation gemäß Anhang IV aufbewahrt;

- j) eine kurze Zusammenfassung des im Reallabor entwickelten KI-Projekts, seiner Ziele und der erwarteten Ergebnisse wird auf der Website der zuständigen Behörden veröffentlicht; diese Pflicht erstreckt sich nicht auf sensible operative Daten zu den Tätigkeiten von Strafverfolgungs-, Grenzschutz-, Einwanderungs- oder Asylbehörden.

(2) Für die Zwecke der Verhütung, Ermittlung, Aufdeckung oder Verfolgung von Straftaten oder der Strafvollstreckung — einschließlich des Schutzes vor und der Abwehr von Gefahren für die öffentliche Sicherheit — unter der Kontrolle und Verantwortung der Strafverfolgungsbehörden erfolgt die Verarbeitung personenbezogener Daten in KI-Reallaboren auf der Grundlage eines spezifischen Unionsrechts oder nationalen Rechts und unterliegt den kumulativen Bedingungen des Absatzes 1.

(3) Das Unionsrecht oder nationale Recht, das die Verarbeitung personenbezogener Daten für andere Zwecke als die ausdrücklich in jenem Recht genannten ausschließt, sowie Unionsrecht oder nationales Recht, in dem die Grundlagen für eine für die Zwecke der Entwicklung, des Testens oder des Trainings innovativer KI-Systeme notwendige Verarbeitung personenbezogener Daten festgelegt sind, oder jegliche anderen dem Unionsrecht zum Schutz personenbezogener Daten entsprechenden Rechtsgrundlagen bleiben von Absatz 1 unberührt.

<a id="art-60"></a>
### Artikel 60 – Tests von Hochrisiko-KI-Systemen unter Realbedingungen außerhalb von KI-Reallaboren

▼M1

(1) Tests von Hochrisiko-KI-Systemen unter Realbedingungen können von Anbietern oder zukünftigen Anbietern von Hochrisiko-KI-Systemen, die in Anhang III genannt sind oder unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, außerhalb von KI-Reallaboren gemäß diesem Artikel und — unbeschadet der Bestimmungen unter Artikel 5 — dem in diesem Artikel genannten Plan für einen Test unter Realbedingungen durchgeführt werden.

▼B

Die Kommission legt die einzelnen Elemente des Plans für einen Test unter Realbedingungen im Wege von Durchführungsrechtsakten fest. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

Das Unionsrecht oder nationale Recht für das Testen von Hochrisiko-KI-Systemen unter Realbedingungen im Zusammenhang mit Produkten, die unter die in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, bleibt von dieser Bestimmung unberührt.

▼M1

(2) Anbieter oder zukünftige Anbieter können Hochrisiko-KI-Systeme, die in Anhang III genannt sind oder unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, vor deren Inverkehrbringen oder Inbetriebnahme jederzeit selbst oder in Partnerschaft mit einem oder mehreren Betreibern oder zukünftigen Betreibern unter Realbedingungen testen.

▼B

(3) Tests von KI-Systemen unter Realbedingungen gemäß diesem Artikel lassen nach dem Unionsrecht oder dem nationalen Recht gegebenenfalls vorgeschriebene Ethikprüfungen unberührt.

(4) Tests unter Realbedingungen dürfen von Anbietern oder zukünftigen Anbietern nur durchgeführt werden, wenn alle der folgenden Bedingungen erfüllt sind:

- a) Der Anbieter oder der zukünftige Anbieter hat einen Plan für einen Test unter Realbedingungen erstellt und diesen bei der Marktüberwachungsbehörde in dem Mitgliedstaat eingereicht, in dem der Test unter Realbedingungen stattfinden soll;

- b) die Marktüberwachungsbehörde in dem Mitgliedstaat, in dem der Test unter Realbedingungen stattfinden soll, hat den Test unter Realbedingungen und den Plan für einen Test unter Realbedingungen genehmigt; hat die Marktüberwachungsbehörde innerhalb von 30 Tagen keine Antwort gegeben, so gelten der Test unter Realbedingungen und der Plan für einen Test unter Realbedingungen als genehmigt; ist im nationalen Recht keine stillschweigende Genehmigung vorgesehen, so bleibt der Test unter Realbedingungen genehmigungspflichtig;

- c) der Anbieter oder zukünftige Anbieter, mit Ausnahme der in Anhang III Nummern 1, 6 und 7 genannten Anbieter oder zukünftigen Anbieter von Hochrisiko-KI-Systemen in den Bereichen Strafverfolgung, Migration, Asyl und Grenzkontrolle und der in Anhang III Nummer 2 genannten Hochrisiko-KI-Systeme, hat den Test unter Realbedingungen unter Angabe einer unionsweit einmaligen Identifizierungsnummer und der in Anhang IX festgelegten Informationen gemäß Artikel 71 Absatz 4 registriert; der Anbieter oder zukünftige Anbieter von Hochrisiko-KI-Systemen gemäß Anhang III Nummern 1, 6 und 7 in den Bereichen Strafverfolgung, Migration, Asyl und Grenzkontrollmanagement hat die Tests unter Realbedingungen im sicheren nicht öffentlichen Teil der EU-Datenbank gemäß Artikel 49 Absatz 4 Buchstabe d mit einer unionsweit einmaligen Identifizierungsnummer und den darin festgelegten Informationen registriert; der Anbieter oder zukünftige Anbieter von Hochrisiko-KI-Systemen gemäß Anhang III Nummer 2 hat die Tests unter Realbedingungen gemäß Artikel 49 Absatz 5 registriert;

- d) der Anbieter oder der zukünftige Anbieter, der den Test unter Realbedingungen durchführt, ist in der Union niedergelassen oder hat einen in der Union niedergelassenen gesetzlichen Vertreter bestellt;

- e) die für die Zwecke des Tests unter Realbedingungen erhobenen und verarbeiteten Daten werden nur dann an Drittländer übermittelt, wenn gemäß Unionsrecht geeignete und anwendbare Schutzvorkehrungen greifen;

- f) der Test unter Realbedingungen dauert nicht länger als zur Erfüllung seiner Zielsetzungen nötig und in keinem Fall länger als sechs Monate; dieser Zeitraum kann um weitere sechs Monate verlängert werden, sofern der Anbieter oder der zukünftige Anbieter die Marktüberwachungsbehörde davon vorab in Kenntnis setzt und erläutert, warum eine solche Verlängerung erforderlich ist;

- g) Testteilnehmer im Rahmen von Tests unter Realbedingungen, die aufgrund ihres Alters oder einer Behinderung schutzbedürftigen Gruppen angehören, sind angemessen geschützt;

- h) wenn ein Anbieter oder zukünftiger Anbieter den Test unter Realbedingungen in Zusammenarbeit mit einem oder mehreren Betreibern oder zukünftigen Betreibern organisiert, werden Letztere vorab über alle für ihre Teilnahmeentscheidung relevanten Aspekte des Tests informiert und erhalten die einschlägigen in Artikel 13 genannten Betriebsanleitungen für das KI-System; der Anbieter oder zukünftige Anbieter und der Betreiber oder zukünftige Betreiber schließen eine Vereinbarung, in der ihre Aufgaben und Zuständigkeiten festgelegt sind, um für die Einhaltung der nach dieser Verordnung und anderem Unionsrecht und nationalem Recht für Tests unter Realbedingungen geltenden Bestimmungen zu sorgen;

- i) die Testteilnehmer im Rahmen von Tests unter Realbedingungen erteilen ihre informierte Einwilligung gemäß Artikel 61, oder, wenn im Fall der Strafverfolgung die Einholung einer informierten Einwilligung den Test des KI-Systems verhindern würde, dürfen sich der Test und die Ergebnisse des Tests unter Realbedingungen nicht negativ auf die Testteilnehmer auswirken und ihre personenbezogenen Daten werden nach Durchführung des Tests gelöscht;

- j) der Anbieter oder zukünftige Anbieter und die Betreiber und zukünftigen Betreiber lassen den Test unter Realbedingungen von Personen wirksam überwachen, die auf dem betreffenden Gebiet angemessen qualifiziert sind und über die Fähigkeit, Ausbildung und Befugnis verfügen, die für die Wahrnehmung ihrer Aufgaben erforderlich sind;

- k) die Vorhersagen, Empfehlungen oder Entscheidungen des KI-Systems können effektiv rückgängig gemacht und außer Acht gelassen werden.

(5) Jeder Testteilnehmer bezüglich des Tests unter Realbedingungen oder gegebenenfalls dessen gesetzlicher Vertreter kann seine Teilnahme an dem Test jederzeit durch Widerruf seiner informierten Einwilligung beenden und die unverzügliche und dauerhafte Löschung seiner personenbezogenen Daten verlangen, ohne dass ihm daraus Nachteile entstehen und er dies in irgendeiner Weise begründen müsste. Der Widerruf der informierten Einwilligung wirkt sich nicht auf bereits durchgeführte Tätigkeiten aus.

(6) Im Einklang mit Artikel 75 übertragen die Mitgliedstaaten ihren Marktüberwachungsbehörden die Befugnis, Anbieter und zukünftige Anbieter zur Bereitstellung von Informationen zu verpflichten, unangekündigte Ferninspektionen oder Vor-Ort-Inspektionen durchzuführen und die Durchführung der Tests unter Realbedingungen und damit zusammenhängende Hochrisiko-KI-Systeme zu prüfen. Die Marktüberwachungsbehörden nutzen diese Befugnisse, um für die sichere Entwicklung von Tests unter Realbedingungen zu sorgen.

(7) Jegliche schwerwiegenden Vorfälle im Verlauf des Tests unter Realbedingungen sind den nationalen Marktüberwachungsbehörden gemäß Artikel 73 zu melden. Der Anbieter oder zukünftige Anbieter trifft Sofortmaßnahmen zur Schadensbegrenzung; andernfalls setzt er den Test unter Realbedingungen so lange aus, bis eine Schadensbegrenzung stattgefunden hat, oder bricht ihn ab. Im Fall eines solchen Abbruchs des Tests unter Realbedingungen richtet der Anbieter oder zukünftige Anbieter ein Verfahren für den sofortigen Rückruf des KI-Systems ein.

(8) Anbieter oder zukünftige Anbieter setzen die nationalen Marktüberwachungsbehörde in dem Mitgliedstaat, in dem der Test unter Realbedingungen stattfindet, über die Aussetzung oder den Abbruch des Tests unter Realbedingungen und die Endergebnisse in Kenntnis.

(9) Anbieter oder zukünftige Anbieter sind nach geltendem Recht der Union und geltendem nationalen Recht für Schäden haftbar, die während ihrer Tests unter Realbedingungen entstehen.

▼M1

<a id="art-60a"></a>
### Artikel 60a – Tests von Hochrisiko-KI-Systemen, die unter die in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, unter Realbedingungen außerhalb von KI-Reallaboren

(1) Die Mitgliedstaaten können Tests von Hochrisiko-KI-Systemen unter Realbedingungen durch Anbieter oder zukünftige Anbieter von KI-gestützten Produkten, die unter die in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, außerhalb von KI-Reallaboren gemäß diesem Artikel zulassen, um die Konformität dieser Systeme mit den in den Artikeln 8 bis 15 festgelegten Anforderungen zu bewerten und zu überprüfen.

(2) Mitgliedstaaten, die sich dafür entscheiden, Tests gemäß Absatz 1 zuzulassen, legen einzeln oder gemeinsam Rahmen für einen Test unter Realbedingungen fest.

(3) Jeder Mitgliedstaat teilt der Kommission jeden von ihm angenommenen Rahmen für einen Test unter Realbedingungen vor dessen Umsetzung mit. Dies berührt nicht die Zuständigkeiten der Kommission gemäß den in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union.

(4) Die Mitgliedstaaten, die Rahmen für einen Test unter Realbedingungen angenommen haben, stellen sicher, dass die einschlägigen zuständigen nationalen Behörden, die zuständigen Behörden und die Behörden, die für Verwaltung und Betrieb der unter die in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union fallenden Infrastrukturen und Produkte zuständig sind, eng und nach Treu und Glauben zusammenarbeiten und — soweit erforderlich — alle praktischen Hindernisse beseitigen, auch in Bezug auf Verfahrensvorschriften für den Zugang zu physischen öffentlichen Infrastrukturen, um diese Rahmen für einen Test unter Realbedingungen erfolgreich umzusetzen und KI-gestützte Produkte, die unter die in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, zu testen.

(5) In den Rahmen für einen Test unter Realbedingungen werden die Anforderungen festgelegt, unter denen Tests unter Realbedingungen stattfinden müssen. Diese Rahmen

- a) umfassen die Vorlage eines verbindlichen Plans für einen Test unter Realbedingungen, der zwischen dem Anbieter oder zukünftigen Anbieter und der zuständigen nationalen Behörde oder der im Einklang mit den in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union zuständigen Behörde zu vereinbaren ist;

- b) stellen die Einhaltung der in Artikel 60 Absätze 2 und 3, Absatz 4 Buchstaben d bis j und Absätze 5 bis 9 festgelegten Anforderungen sicher, wobei jede Bezugnahme auf Marktüberwachungsbehörden in diesen Bestimmungen als Bezugnahme auf die zuständige nationale Behörde oder gegebenenfalls die im Einklang mit den in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften zuständige Behörde der Union zu verstehen ist;

- c) umfassen wirksame Vorkehrungen für Führung und Rechenschaftspflicht;

- d) stellen ein hohes Schutzniveau in Bezug auf Gesundheit, Sicherheit und Grundrechte sicher.

(6) Im Rahmen der Tests unter Realbedingungen wird den einschlägigen Bestimmungen der in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union Rechnung getragen. Die in diesen Bestimmungen festgelegten Anforderungen berühren nicht die Anwendung dieses Artikels, soweit dies erforderlich ist, um die in Absatz 1 genannten Tests zu ermöglichen.

▼B

<a id="art-61"></a>
### Artikel 61 – Informierte Einwilligung zur Teilnahme an einem Test unter Realbedingungen außerhalb von KI-Reallaboren

(1) Für die Zwecke von Tests unter Realbedingungen gemäß Artikel 60 ist von den Testteilnehmern eine freiwillig erteilte informierte Einwilligung einzuholen, bevor sie an dem Test teilnehmen und nachdem sie mit präzisen, klaren, relevanten und verständlichen Informationen über Folgendes ordnungsgemäß informiert wurden:

- a) die Art und die Zielsetzungen des Tests unter Realbedingungen und etwaige mit ihrer Teilnahme verbundene Unannehmlichkeiten;

- b) die Bedingungen, unter denen der Test unter Realbedingungen erfolgen soll, einschließlich der voraussichtlichen Dauer der Teilnahme des Testteilnehmers oder der Testteilnehmer;

- c) ihre Rechte und Garantien, die ihnen bezüglich ihrer Teilnahme zustehen, insbesondere ihr Recht, die Teilnahme an dem Test unter Realbedingungen zu verweigern oder diese Teilnahme jederzeit zu beenden, ohne dass ihnen daraus Nachteile entstehen und sie dies in irgendeiner Weise begründen müssten;

- d) die Regelungen, unter denen die Rückgängigmachung oder Außerachtlassung der Vorhersagen, Empfehlungen oder Entscheidungen des KI-Systems beantragt werden kann;

- e) die unionsweit einmalige Identifizierungsnummer des Tests unter Realbedingungen gemäß Artikel 60 Absatz 4 Buchstabe c und die Kontaktdaten des Anbieters oder seines gesetzlichen Vertreters, bei dem weitere Informationen eingeholt werden können.

(2) Die informierte Einwilligung ist zu datieren und zu dokumentieren, und eine Kopie wird den Testteilnehmern oder ihren gesetzlichen Vertretern ausgehändigt.

<a id="art-62"></a>
### Artikel 62 – Maßnahmen für Anbieter und Betreiber, insbesondere KMU, einschließlich Start-up-Unternehmen

(1) Die Mitgliedstaaten ergreifen die folgenden Maßnahmen:

- a) Sie gewähren KMU — einschließlich Start-up-Unternehmen —, die ihren Sitz oder eine Zweigniederlassung in der Union haben, soweit sie die Voraussetzungen und Auswahlkriterien erfüllen, vorrangigen Zugang zu den KI-Reallaboren; der vorrangige Zugang schließt nicht aus, dass andere als die in diesem Absatz genannten KMU, einschließlich Start-up-Unternehmen, Zugang zum KI-Reallabor erhalten, sofern sie ebenfalls die Zulassungsvoraussetzungen und Auswahlkriterien erfüllen;

- b) sie führen besondere Sensibilisierungs- und Schulungsmaßnahmen für die Anwendung dieser Verordnung durch, die auf die Bedürfnisse von KMU, einschließlich Start-up-Unternehmen, Betreibern sowie gegebenenfalls lokalen Behörden ausgerichtet sind;

- c) sie nutzen entsprechende bestehende Kanäle und richten gegebenenfalls neue Kanäle für die Kommunikation mit KMU, einschließlich Start-up-Unternehmen, Betreibern, anderen Innovatoren sowie gegebenenfalls lokalen Behörden ein, um Ratschläge zu geben und Fragen zur Durchführung dieser Verordnung, auch bezüglich der Beteiligung an KI-Reallaboren, zu beantworten;

- d) sie fördern die Beteiligung von KMU und anderen einschlägigen Interessenträgern an der Entwicklung von Normen.

(2) Bei der Festsetzung der Gebühren für die Konformitätsbewertung gemäß Artikel 43 werden die besonderen Interessen und Bedürfnisse von KMU, einschließlich Start-up-Unternehmen, berücksichtigt, indem diese Gebühren proportional zur Größe der Unternehmen, der Größe ihres Marktes und anderen einschlägigen Kennzahlen gesenkt werden.

(3) Das Büro für Künstliche Intelligenz ergreift die folgenden Maßnahmen:

- a) es stellt standardisierte Muster für die unter diese Verordnung fallenden Bereiche bereit, wie vom KI-Gremium in seinem Antrag festgelegt;

- b) es entwickelt und führt eine zentrale Informationsplattform, über die allen Akteuren in der Union leicht nutzbare Informationen zu dieser Verordnung bereitgestellt werden;

- c) es führt geeignete Informationskampagnen durch, um für die aus dieser Verordnung erwachsenden Pflichten zu sensibilisieren;

- d) es bewertet und fördert die Zusammenführung bewährter Verfahren im Bereich der mit KI-Systemen verbundenen Vergabeverfahren.

<a id="art-63"></a>
### Artikel 63 – Ausnahmen für bestimmte Akteure

▼M1

(1) KMU, einschließlich Start-up-Unternehmen können bestimmte Elemente des in Artikel 17 vorgeschriebenen Qualitätsmanagementsystems in vereinfachter Weise einhalten, sofern sie keine Partnerunternehmen oder verbundenen Unternehmen im Sinne der Empfehlung 2003/361/EG haben. Zu diesem Zweck arbeitet die Kommission Leitlinien zu den Elementen des Qualitätsmanagementsystems aus, die unter Berücksichtigung der Bedürfnisse von KMU in vereinfachter Weise eingehalten werden können, ohne das Schutzniveau oder die Notwendigkeit zur Einhaltung der Anforderungen in Bezug auf Hochrisiko-KI-Systeme zu beeinträchtigen.

▼B

(2) Absatz 1 dieses Artikels ist nicht dahin gehend auszulegen, dass diese Akteure auch von anderen in dieser Verordnung festgelegten Anforderungen oder Pflichten, einschließlich der nach den Artikeln 9, 10, 11, 12, 13, 14, 15, 72 und 73 geltenden, befreit sind.

<a id="chapter-vii"></a>
## Kapitel VII – GOVERNANCE

<a id="chapter-vii-section-1"></a>
## Abschnitt 1 – Governance auf Unionsebene

<a id="art-64"></a>
### Artikel 64 – Büro für Künstliche Intelligenz

(1) Die Kommission entwickelt über das Büro für Künstliche Intelligenz die Sachkenntnis und Fähigkeiten der Union auf dem Gebiet der KI.

(2) Die Mitgliedstaaten erleichtern dem Büro für Künstliche Intelligenz die ihm gemäß dieser Verordnung übertragenen Aufgaben.

▼M1

(3) Unbeschadet des Haushaltsverfahrens werden dem Büro für Künstliche Intelligenz angemessene Ressourcen zugewiesen, damit es seine Aufgaben und Befugnisse im Zusammenhang mit der Durchsetzung dieser Verordnung wirksam wahrnehmen kann.

▼B

<a id="art-65"></a>
### Artikel 65 – Einrichtung und Struktur des Europäischen Gremiums für Künstliche Intelligenz

(1) Ein Europäisches Gremium für Künstliche Intelligenz (im Folgenden „KI-Gremium“) wird hiermit eingerichtet.

(2) Das KI-Gremium setzt sich aus einem Vertreter je Mitgliedstaat zusammen. Der Europäische Datenschutzbeauftragte nimmt als Beobachter teil. Das Büro für Künstliche Intelligenz nimmt ebenfalls an den Sitzungen des KI-Gremiums teil, ohne sich jedoch an den Abstimmungen zu beteiligen. Andere Behörden oder Stellen der Mitgliedstaaten und der Union oder Sachverständige können im Einzelfall zu den Sitzungen des KI-Gremiums eingeladen werden, wenn die erörterten Fragen für sie von Belang sind.

(3) Die Vertreter werden von ihren Mitgliedstaaten für einen Zeitraum von drei Jahren benannt, der einmal verlängert werden kann.

(4) Die Mitgliedstaaten sorgen dafür, dass ihre Vertreter im KI-Gremium

- a) in ihrem Mitgliedstaat über die einschlägigen Kompetenzen und Befugnisse verfügen, sodass sie aktiv zur Bewältigung der in Artikel 66 genannten Aufgaben des KI-Gremiums beitragen können;

- b) gegenüber dem KI-Gremium sowie gegebenenfalls, unter Berücksichtigung der Erfordernisse der Mitgliedstaaten, gegenüber Interessenträgern als zentrale Ansprechpartner fungieren;

- c) ermächtigt sind, auf die Kohärenz und die Abstimmung zwischen den zuständigen nationalen Behörden in ihrem Mitgliedstaat bei der Durchführung dieser Verordnung hinzuwirken, auch durch Erhebung einschlägiger Daten und Informationen für die Zwecke der Erfüllung ihrer Aufgaben im KI-Gremium.

(5) Die benannten Vertreter der Mitgliedstaaten nehmen die Geschäftsordnung des KI-Gremiums mit einer Zweidrittelmehrheit an. In der Geschäftsordnung sind insbesondere die Vorgehensweise für das Auswahlverfahren, die Dauer des Mandats und die genauen Aufgaben des Vorsitzes, die Abstimmungsregelungen und die Organisation der Tätigkeiten des KI-Gremiums und seiner Untergruppen festgelegt.

(6) Das KI-Gremium richtet zwei ständige Untergruppen ein, um Marktüberwachungsbehörden eine Plattform für die Zusammenarbeit und den Austausch zu bieten und Behörden über Angelegenheiten, die jeweils die Marktüberwachung und notifizierte Stellen betreffen, zu unterrichten.

Die ständige Untergruppe für Marktüberwachung sollte für diese Verordnung als Gruppe für die Verwaltungszusammenarbeit (ADCO-Gruppe) im Sinne des Artikels 30 der Verordnung (EU) 2019/1020 fungieren.

Das KI-Gremium kann weitere ständige oder nichtständige Untergruppen einrichten, falls das für die Prüfung bestimmter Fragen zweckmäßig sein sollte. Gegebenenfalls können Vertreter des in Artikel 67 genannten Beratungsforums als Beobachter zu diesen Untergruppen oder zu bestimmten Sitzungen dieser Untergruppen eingeladen werden.

(7) Das KI-Gremium wird so organisiert und geführt, dass bei seinen Tätigkeiten Objektivität und Unparteilichkeit gewahrt sind.

(8) Den Vorsitz im KI-Gremium führt einer der Vertreter der Mitgliedstaaten. Die Sekretariatsgeschäfte des KI-Gremiums werden vom Büro für Künstliche Intelligenz geführt; dieses beruft auf Anfrage des Vorsitzes die Sitzungen ein und erstellt die Tagesordnung im Einklang mit den Aufgaben des KI-Gremiums gemäß dieser Verordnung und seiner Geschäftsordnung.

<a id="art-66"></a>
### Artikel 66 – Aufgaben des KI-Gremiums

Das KI-Gremium berät und unterstützt die Kommission und die Mitgliedstaaten, um die einheitliche und wirksame Anwendung dieser Verordnung zu erleichtern. Für diese Zwecke kann das KI-Gremium insbesondere

- a) zur Koordinierung zwischen den für die Anwendung dieser Verordnung zuständigen nationalen Behörden beitragen und in Zusammenarbeit mit den betreffenden Marktüberwachungsbehörden und vorbehaltlich ihrer Zustimmung gemeinsame Tätigkeiten der Marktüberwachungsbehörden gemäß Artikel 74 Absatz 11 unterstützen;

- b) technisches und regulatorisches Fachwissen und bewährte Verfahren zusammentragen und unter den Mitgliedstaaten verbreiten;

- c) zur Durchführung dieser Verordnung Beratung anbieten, insbesondere im Hinblick auf die Durchsetzung der Vorschriften zu KI-Modellen mit allgemeinem Verwendungszweck;

- d) zur Harmonisierung der Verwaltungspraxis in den Mitgliedstaaten beitragen, auch bezüglich der Ausnahme vom Konformitätsbewertungsverfahren gemäß Artikel 46 und der Funktionsweise von KI-Reallaboren und Tests unter Realbedingungen gemäß den Artikeln 57, 59 und 60;

- e) auf Anfrage der Kommission oder in Eigeninitiative Empfehlungen und schriftliche Stellungnahmen zu einschlägigen Fragen der Durchführung dieser Verordnung und ihrer einheitlichen und wirksamen Anwendung abgeben, einschließlich

  - i) zur Entwicklung und Anwendung von Verhaltenskodizes und Praxisleitfäden gemäß dieser Verordnung sowie der Leitlinien der Kommission;

  - ii) zur Bewertung und Überprüfung dieser Verordnung gemäß Artikel 112, auch in Bezug auf die Meldung schwerwiegender Vorfälle gemäß Artikel 73 und das Funktionieren der EU-Datenbank gemäß Artikel 71, die Ausarbeitung der delegierten Rechtsakte oder Durchführungsrechtsakte sowie im Hinblick auf mögliche Anpassungen dieser Verordnung an die in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union;

  - iii) zu technischen Spezifikationen oder geltenden Normen in Bezug auf die in Kapitel III Abschnitt 2 festgelegten Anforderungen;

  - iv) zur Anwendung der in den Artikeln 40 und 41 genannten harmonisierten Normen oder gemeinsamen Spezifikationen;

  - v) zu Tendenzen, etwa im Bereich der globalen Wettbewerbsfähigkeit Europas auf dem Gebiet der KI, bei der Verbreitung von KI in der Union und bei der Entwicklung digitaler Fähigkeiten;

  - vi) zu Tendenzen im Bereich der sich ständig weiterentwickelnden Typologie der KI-Wertschöpfungsketten insbesondere hinsichtlich der sich daraus ergebenden Auswirkungen auf die Rechenschaftspflicht;

  - vii) zur möglicherweise notwendigen Änderung des Anhangs III im Einklang mit Artikel 7 und zur möglicherweise notwendigen Überarbeitung des Artikels 5 gemäß Artikel 112 unter Berücksichtigung der einschlägigen verfügbaren Erkenntnisse und der neuesten technologischen Entwicklungen;

- f) die Kommission bei der Förderung der KI-Kompetenz, der Sensibilisierung und Aufklärung der Öffentlichkeit in Bezug auf die Vorteile, Risiken, Schutzmaßnahmen, Rechte und Pflichten im Zusammenhang mit der Nutzung von KI-Systemen unterstützen;

- g) die Entwicklung gemeinsamer Kriterien und eines gemeinsamen Verständnisses der Marktteilnehmer und der zuständigen Behörden in Bezug auf die in dieser Verordnung vorgesehenen einschlägigen Konzepte erleichtern, auch durch einen Beitrag zur Entwicklung von Benchmarks;

- h) gegebenenfalls mit anderen Organen, Einrichtungen und sonstigen Stellen der EU, einschlägigen Sachverständigengruppen und Netzwerken der EU insbesondere in den Bereichen Produktsicherheit, Cybersicherheit, Wettbewerb, digitale und Mediendienste, Finanzdienstleistungen, Verbraucherschutz, Datenschutz und Schutz der Grundrechte zusammenarbeiten;

- i) zur wirksamen Zusammenarbeit mit den zuständigen Behörden von Drittstaaten und mit internationalen Organisationen beitragen;

- j) die zuständigen nationalen Behörden und die Kommission beim Aufbau des für die Durchführung dieser Verordnung erforderlichen organisatorischen und technischen Fachwissens beraten, unter anderem durch einen Beitrag zur Einschätzung des Schulungsbedarfs des Personals der Mitgliedstaaten, das an der Durchführung dieser Verordnung beteiligt ist;

- k) dem Büro für Künstliche Intelligenz helfen, die zuständigen nationalen Behörden bei der Einrichtung und Entwicklung von KI-Reallaboren zu unterstützen, und die Zusammenarbeit und den Informationsaustausch zwischen KI-Reallaboren erleichtern;

- l) zur Entwicklung von Leitfäden beitragen und diesbezüglich entsprechend beraten;

- m) die Kommission zu internationalen Angelegenheiten im Bereich der KI beraten;

- n) der Kommission Stellungnahmen zu qualifizierten Warnungen in Bezug auf KI-Modelle mit allgemeinem Verwendungszweck vorlegen;

- o) Stellungnahmen der Mitgliedstaaten zu qualifizierten Warnungen in Bezug auf KI-Modelle mit allgemeinem Verwendungszweck entgegennehmen sowie zu nationalen Erfahrungen und Praktiken bei der Überwachung und Durchsetzung von KI-Systemen, insbesondere von Systemen, die KI-Modelle mit allgemeinem Verwendungszweck integrieren.

<a id="art-67"></a>
### Artikel 67 – Beratungsforum

(1) Es wird ein Beratungsforum eingerichtet, das technisches Fachwissen bereitstellt, das KI-Gremium und die Kommission berät und zu deren Aufgaben im Rahmen dieser Verordnung beiträgt.

(2) Die Mitglieder des Beratungsforums vertreten eine ausgewogene Auswahl von Interessenträgern, darunter die Industrie, Start-up-Unternehmen, KMU, die Zivilgesellschaft und die Wissenschaft. Bei der Zusammensetzung des Beratungsforums wird auf ein ausgewogenes Verhältnis zwischen wirtschaftlichen und nicht-wirtschaftlichen Interessen und innerhalb der Kategorie der wirtschaftlichen Interessen zwischen KMU und anderen Unternehmen geachtet.

(3) Die Kommission ernennt die Mitglieder des Beratungsforums gemäß den in Absatz 2 genannten Kriterien aus dem Kreis der Interessenträger mit anerkanntem Fachwissen auf dem Gebiet der KI.

(4) Die Amtszeit der Mitglieder des Beratungsforums beträgt zwei Jahre; sie kann bis zu höchstens vier Jahre verlängert werden.

(5) Die Agentur der Europäischen Union für Grundrechte, ENISA, das Europäische Komitee für Normung (CEN), das Europäische Komitee für elektrotechnische Normung (CENELEC) und das Europäische Institut für Telekommunikationsnormen (ETSI) sind ständige Mitglieder des Beratungsforums.

(6) Das Beratungsforum gibt sich eine Geschäftsordnung. Es wählt gemäß den in Absatz 2 festgelegten Kriterien zwei Ko-Vorsitzende unter seinen Mitgliedern. Die Amtszeit der Ko-Vorsitzenden beträgt zwei Jahre und kann einmal verlängert werden.

(7) Das Beratungsforum hält mindestens zweimal pro Jahr Sitzungen ab. Das Beratungsforum kann Sachverständige und andere Interessenträger zu seinen Sitzungen einladen.

(8) Das Beratungsforum kann auf Ersuchen des KI-Gremiums oder der Kommission Stellungnahmen, Empfehlungen und schriftliche Beiträge ausarbeiten.

(9) Das Beratungsforum kann gegebenenfalls ständige oder zeitweilige Untergruppen einsetzen, um spezifische Fragen im Zusammenhang mit den Zielen dieser Verordnung zu prüfen.

(10) Das Beratungsforum erstellt jährlich einen Bericht über seine Tätigkeit. Dieser Bericht wird veröffentlicht.

<a id="art-68"></a>
### Artikel 68 – Wissenschaftliches Gremium unabhängiger Sachverständiger

(1) Die Kommission erlässt im Wege eines Durchführungsrechtsakts Bestimmungen über die Einrichtung eines wissenschaftlichen Gremiums unabhängiger Sachverständiger („wissenschaftliches Gremium“), das die Durchsetzungstätigkeiten im Rahmen dieser Verordnung unterstützen soll. Dieser Durchführungsrechtsakt wird gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

(2) Das wissenschaftliche Gremium setzt sich aus Sachverständigen zusammen, die von der Kommission auf der Grundlage aktueller wissenschaftlicher oder technischer Fachkenntnisse auf dem Gebiet der KI, die zur Erfüllung der in Absatz 3 genannten Aufgaben erforderlich sind, ausgewählt werden, und muss nachweisen können, dass es alle folgenden Bedingungen erfüllt:

- a) es verfügt über besondere Fachkenntnisse und Kompetenzen sowie über wissenschaftliches oder technisches Fachwissen auf dem Gebiet der KI;

- b) es ist von Anbietern von KI-Systemen oder KI-Modellen mit allgemeinem Verwendungszweck unabhängig;

- c) es ist in der Lage, Tätigkeiten sorgfältig, präzise und objektiv auszuführen.

Die Kommission legt in Absprache mit dem KI-Gremium die Anzahl der Sachverständigen des Gremiums nach Maßgabe der jeweiligen Erfordernisse fest und sorgt für eine ausgewogene Vertretung der Geschlechter und eine gerechte geografische Verteilung.

(3) Das wissenschaftliche Gremium berät und unterstützt das Büro für Künstliche Intelligenz, insbesondere in Bezug auf folgende Aufgaben:

- a) Unterstützung bei der Durchführung und Durchsetzung dieser Verordnung in Bezug auf KI-Modelle und -Systeme mit allgemeinem Verwendungszweck, insbesondere indem es

  - i) das Büro für Künstliche Intelligenz im Einklang mit Artikel 90 vor möglichen systemischen Risiken von KI-Modellen mit allgemeinem Verwendungszweck auf Unionsebene warnt;

  - ii) einen Beitrag zur Entwicklung von Instrumenten und Methoden für die Bewertung der Fähigkeiten von KI-Modellen und -Systemen mit allgemeinem Verwendungszweck, auch durch Benchmarks, leistet;

  - iii) Beratung über die Einstufung von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko anbietet;

  - iv) Beratung über die Einstufung verschiedener KI-Modelle und -Systeme mit allgemeinem Verwendungszweck anbietet;

  - v) einen Beitrag zur Entwicklung von Instrumenten und Mustern leistet;

- b) Unterstützung der Arbeit der Marktüberwachungsbehörden auf deren Ersuchen;

- c) Unterstützung grenzüberschreitender Marktüberwachungstätigkeiten gemäß Artikel 74 Absatz 11, ohne dass die Befugnisse der Marktüberwachungsbehörden berührt werden;

- d) Unterstützung des Büros für Künstliche Intelligenz bei der Wahrnehmung seiner Aufgaben im Rahmen des Schutzklauselverfahrens der Union gemäß Artikel 81.

(4) Die Sachverständigen des wissenschaftlichen Gremiums führen ihre Aufgaben nach den Grundsätzen der Unparteilichkeit und der Objektivität aus und gewährleisten die Vertraulichkeit der Informationen und Daten, in deren Besitz sie bei der Ausführung ihrer Aufgaben und Tätigkeiten gelangen. Sie dürfen bei der Wahrnehmung ihrer Aufgaben nach Absatz 3 weder Weisungen anfordern noch entgegennehmen. Jeder Sachverständige gibt eine Interessenerklärung ab, die öffentlich zugänglich gemacht wird. Das Büro für Künstliche Intelligenz richtet Systeme und Verfahren ein, mit denen mögliche Interessenkonflikte aktiv bewältigt und verhindert werden können.

(5) Der in Absatz 1 genannte Durchführungsrechtsakt enthält Bestimmungen über die Bedingungen, Verfahren und detaillierten Regelungen nach denen das wissenschaftliche Gremium und seine Mitglieder Warnungen ausgeben und das Büro für Künstliche Intelligenz um Unterstützung bei der Wahrnehmung der Aufgaben des wissenschaftlichen Gremiums ersuchen können.

<a id="art-69"></a>
### Artikel 69 – Zugang zum Pool von Sachverständigen durch die Mitgliedstaaten

(1) Die Mitgliedstaaten können Sachverständige des wissenschaftlichen Gremiums hinzuziehen, um ihre Durchsetzungstätigkeiten im Rahmen dieser Verordnung zu unterstützen.

▼M1

(2) Die Mitgliedstaaten können verpflichtet werden, für die Beratung und Unterstützung durch die Sachverständigen Gebühren in Höhe der Vergütungsgebühren zu entrichten, die für die Kommission gemäß dem in Artikel 68 Absatz 1 genannten Durchführungsrechtsakt gelten.

▼B

(3) Die Kommission ermöglicht den Mitgliedstaaten bei Bedarf einen rechtzeitigen Zugang zu den Sachverständigen und sorgt dafür, dass die Kombination aus unterstützenden Tätigkeiten durch die Union zur Prüfung von KI gemäß Artikel 84 und durch die Sachverständigen gemäß dem vorliegenden Artikel effizient organisiert ist und den bestmöglichen zusätzlichen Nutzen bringt.

<a id="chapter-vii-section-2"></a>
## Abschnitt 2 – Zuständige nationale Behörden

<a id="art-70"></a>
### Artikel 70 – Benennung von zuständigen nationalen Behörden und zentrale Anlaufstelle

(1) Jeder Mitgliedstaat muss für die Zwecke dieser Verordnung mindestens eine notifizierende Behörde und mindestens eine Marktüberwachungsbehörde als zuständige nationale Behörden einrichten oder benennen. Diese zuständigen nationalen Behörden üben ihre Befugnisse unabhängig, unparteiisch und unvoreingenommen aus, um die Objektivität ihrer Tätigkeiten und Aufgaben zu gewährleisten und die Anwendung und Durchführung dieser Verordnung sicherzustellen. Die Mitglieder dieser Behörden haben jede Handlung zu unterlassen, die mit ihren Aufgaben unvereinbar ist. Sofern diese Grundsätze gewahrt werden, können die betreffenden Tätigkeiten und Aufgaben gemäß den organisatorischen Erfordernissen des Mitgliedstaats von einer oder mehreren benannten Behörden wahrgenommen werden.

(2) Die Mitgliedstaaten teilen der Kommission die Namen der notifizierenden Behörden und der Marktüberwachungsbehörden und die Aufgaben dieser Behörden sowie alle späteren Änderungen mit. Die Mitgliedstaaten machen Informationen darüber, wie die zuständigen Behörden und zentralen Anlaufstellen bis zum 2. August 2025 auf elektronischem Wege kontaktiert werden können, öffentlich zugänglich. Die Mitgliedstaaten benennen eine Marktüberwachungsbehörde, die als zentrale Anlaufstelle für diese Verordnung fungiert, und teilen der Kommission den Namen der zentralen Anlaufstelle mit. Die Kommission erstellt eine öffentlich verfügbare Liste der zentralen Anlaufstellen.

(3) Die Mitgliedstaaten sorgen dafür, dass ihre zuständigen nationalen Behörden mit angemessenen technischen und finanziellen Mitteln sowie geeignetem Personal und Infrastrukturen ausgestattet werden, damit sie ihre Aufgaben im Rahmen dieser Verordnung wirksam erfüllen können. Insbesondere müssen die zuständigen nationalen Behörden zu jeder Zeit über eine ausreichende Zahl von Mitarbeitern verfügen, zu deren Kompetenzen und Fachwissen ein tiefes Verständnis der KI-Technologien, der Daten und Datenverarbeitung, des Schutzes personenbezogener Daten, der Cybersicherheit, der Grundrechte, der Gesundheits- und Sicherheitsrisiken sowie Kenntnis der bestehenden Normen und rechtlichen Anforderungen gehört. Die Mitgliedstaaten bewerten und aktualisieren, falls erforderlich, jährlich die in diesem Absatz genannten Erfordernisse bezüglich Kompetenzen und Ressourcen.

(4) Die zuständigen nationalen Behörden ergreifen geeignete Maßnahmen zur Sicherstellung eines angemessenen Maßes an Cybersicherheit.

(5) Bei der Erfüllung ihrer Aufgaben halten sich die zuständigen nationalen Behörden an die in Artikel 78 festgelegten Vertraulichkeitspflichten.

(6) Bis zum 2. August 2025 und anschließend alle zwei Jahre erstatten die Mitgliedstaaten der Kommission Bericht über den Sachstand bezüglich der finanziellen Mittel und des Personals der zuständigen nationalen Behörden und geben eine Einschätzung über deren Angemessenheit ab. Die Kommission leitet diese Informationen zur Erörterung und etwaigen Abgabe von Empfehlungen an das KI-Gremium weiter.

(7) Die Kommission fördert den Erfahrungsaustausch zwischen den zuständigen nationalen Behörden.

▼M1

(8) Die zuständigen nationalen Behörden können gegebenenfalls insbesondere KMU, einschließlich Start-up-Unternehmen, und kleinen Midcap-Unternehmen unter Berücksichtigung der Anleitung und Beratung durch das KI-Gremium oder die Kommission mit Anleitung und Beratung bei der Durchführung dieser Verordnung zur Seite stehen. Wenn zuständige nationale Behörden beabsichtigen, Anleitung und Beratung in Bezug auf ein KI-System in Bereichen anzubieten, die unter das Unionsrecht fallen, so sind gegebenenfalls die nach jenem Unionsrecht zuständigen nationalen Behörden zu konsultieren.

▼B

(9) Soweit Organe, Einrichtungen und sonstige Stellen der Union in den Anwendungsbereich dieser Verordnung fallen, übernimmt der Europäische Datenschutzbeauftragte die Funktion der für ihre Beaufsichtigung zuständigen Behörde.

<a id="chapter-viii"></a>
## Kapitel VIII – EU-DATENBANK FÜR HOCHRISIKO-KI-SYSTEME

<a id="art-71"></a>
### Artikel 71 – EU-Datenbank für die in Anhang III aufgeführten Hochrisiko-KI-Systeme

(1) Die Kommission errichtet und führt in Zusammenarbeit mit den Mitgliedstaaten eine EU-Datenbank mit den in den Absätzen 2 und 3 dieses Artikels genannten Informationen über Hochrisiko-KI-Systeme nach Artikel 6 Absatz 2, die gemäß den Artikeln 49 und 60 registriert werden und über KI-Systeme, die nicht als Hochrisiko-KI-Systeme gemäß Artikel 6 Absatz 3 gelten und gemäß Artikel 6 Absatz 4 und Artikel 49 registriert werden. Bei der Festlegung der Funktionsspezifikationen dieser Datenbank konsultiert die Kommission die einschlägigen Sachverständigen und bei der Aktualisierung der Funktionsspezifikationen dieser Datenbank konsultiert sie das KI-Gremium.

(2) Die in Anhang VIII Abschnitte A und B aufgeführten Daten werden vom Anbieter oder gegebenenfalls vom Bevollmächtigten in die EU-Datenbank eingegeben.

(3) Die in Anhang VIII Abschnitt C aufgeführten Daten werden vom Betreiber, der eine Behörde, Einrichtung oder sonstige Stelle ist oder in deren Namen handelt, gemäß Artikel 49 Absätze 3 und 4 in die EU-Datenbank eingegeben.

(4) Mit Ausnahme des in Artikel 49 Absatz 4 und Artikel 60 Absatz 4 Buchstabe c genannten Abschnitts müssen die gemäß Artikel 49 in der Datenbank registrierten und dort enthaltenen Informationen auf benutzerfreundliche Weise zugänglich und öffentlich verfügbar sein. Die Informationen sollten leicht handhabbar und maschinenlesbar sein. Auf die gemäß Artikel 60 registrierten Informationen können nur Marktüberwachungsbehörden und die Kommission zugreifen, es sei denn, der zukünftige Anbieter oder der Anbieter hat seine Zustimmung dafür erteilt, dass die Informationen auch öffentlich zugänglich sind.

(5) Die EU-Datenbank enthält personenbezogene Daten nur, soweit dies für die Erfassung und Verarbeitung von Informationen gemäß dieser Verordnung erforderlich ist. Zu diesen Informationen gehören die Namen und Kontaktdaten der natürlichen Personen, die für die Registrierung des Systems verantwortlich sind und die rechtlich befugt sind, den Anbieter oder gegebenenfalls den Betreiber zu vertreten.

(6) Die Kommission gilt als für die EU-Datenbank Verantwortlicher. Sie stellt Anbietern, zukünftigen Anbietern und Betreibern angemessene technische und administrative Unterstützung bereit. Die EU-Datenbank muss den geltenden Barrierefreiheitsanforderungen entsprechen.

<a id="chapter-ix"></a>
## Kapitel IX – BEOBACHTUNG NACH DEM INVERKEHRBRINGEN, INFORMATIONSAUSTAUSCH UND MARKTÜBERWACHUNG

<a id="chapter-ix-section-1"></a>
## Abschnitt 1 – Beobachtung nach dem Inverkehrbringen

<a id="art-72"></a>
### Artikel 72 – Beobachtung nach dem Inverkehrbringen durch die Anbieter und Plan für die Beobachtung nach dem Inverkehrbringen für Hochrisiko-KI-Systeme

(1) Anbieter müssen ein System zur Beobachtung nach dem Inverkehrbringen, das im Verhältnis zur Art der KI-Technik und zu den Risiken des Hochrisiko-KI-Systems steht, einrichten und dokumentieren.

(2) Mit dem System zur Beobachtung nach dem Inverkehrbringen müssen sich die einschlägigen Daten zur Leistung der Hochrisiko-KI-Systeme, die von den Anbietern oder den Betreibern bereitgestellt oder aus anderen Quellen erhoben werden können, über ihre gesamte Lebensdauer hinweg aktiv und systematisch erheben, dokumentieren und analysieren lassen, und der Anbieter muss damit die fortdauernde Einhaltung der in Kapitel III Abschnitt 2 genannten Anforderungen an die KI-Systeme bewerten können. Gegebenenfalls umfasst die Beobachtung nach dem Inverkehrbringen eine Analyse der Interaktion mit anderen KI-Systemen. Diese Pflicht gilt nicht für sensible operative Daten von Betreibern, die Strafverfolgungsbehörden sind.

▼M1

(3) Das System zur Beobachtung nach dem Inverkehrbringen muss auf einem Plan für die Beobachtung nach dem Inverkehrbringen beruhen. Der Plan für die Beobachtung nach dem Inverkehrbringen ist Teil der in Anhang IV genannten technischen Dokumentation. Die Kommission nimmt unter weitestgehender Berücksichtigung der Stellungnahme des KI-Gremiums bis zum 2. September 2027 Leitlinien, einschließlich eines Musters, für den Plan zur Beobachtung nach dem Inverkehrbringen an.

▼B

(4) Bei Hochrisiko-KI-Systemen, die unter die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union fallen, und für die auf der Grundlage dieser Rechtvorschriften bereits ein System zur Beobachtung nach dem Inverkehrbringen sowie ein entsprechender Plan festgelegt wurden, haben die Anbieter zur Gewährleistung der Kohärenz, zur Vermeidung von Doppelarbeit und zur Minimierung zusätzlicher Belastungen die Möglichkeit, unter Verwendung des Musters nach Absatz 3, gegebenenfalls die in den Absätzen 1, 2 und 3 genannten erforderlichen Elemente in die im Rahmen dieser Vorschriften bereits vorhandenen Systeme und Pläne zu integrieren, sofern ein gleichwertiges Schutzniveau erreicht wird.

Unterabsatz 1 dieses Absatzes gilt auch für in Anhang III Nummer 5 genannte Hochrisiko-KI-Systeme, die von Finanzinstituten in Verkehr gebracht oder in Betrieb genommen wurden, die bezüglich ihrer internen Unternehmensführung, Regelungen oder Verfahren Anforderungen gemäß den Rechtsvorschriften der Union über Finanzdienstleistungen unterliegen.

<a id="chapter-ix-section-2"></a>
## Abschnitt 2 – Austausch von Informationen über schwerwiegende Vorfälle

<a id="art-73"></a>
### Artikel 73 – Meldung schwerwiegender Vorfälle

(1) Anbieter von in der Union in Verkehr gebrachten Hochrisiko-KI-Systemen melden schwerwiegende Vorfälle den Marktüberwachungsbehörden der Mitgliedstaaten, in denen der Vorfall stattgefunden hat.

(2) Die Meldung nach Absatz 1 erfolgt unmittelbar, nachdem der Anbieter den kausalen Zusammenhang zwischen dem KI-System und dem schwerwiegenden Vorfall oder die naheliegende Wahrscheinlichkeit eines solchen Zusammenhangs festgestellt hat und in jedem Fall spätestens 15 Tage, nachdem der Anbieter oder gegebenenfalls der Betreiber Kenntnis von diesem schwerwiegenden Vorfall erlangt hat.

Bezüglich des in Unterabsatz 1 genannten Meldezeitraums wird der Schwere des schwerwiegenden Vorfalls Rechnung getragen.

(3) Ungeachtet des Absatzes 2 dieses Artikels erfolgt die in Absatz 1 dieses Artikels genannte Meldung im Falle eines weitverbreiteten Verstoßes oder eines schwerwiegenden Vorfalls im Sinne des Artikels 3 Nummer 49 Buchstabe b unverzüglich, spätestens jedoch zwei Tage nachdem der Anbieter oder gegebenenfalls der Betreiber von diesem Vorfall Kenntnis erlangt hat.

(4) Ungeachtet des Absatzes 2 erfolgt die Meldung im Falle des Todes einer Person unverzüglich nachdem der Anbieter oder der Betreiber einen kausalen Zusammenhang zwischen dem Hochrisiko-KI-System und dem schwerwiegenden Vorfall festgestellt hat, oder einen solchen vermutet, spätestens jedoch zehn Tage nach dem Datum, an dem der Anbieter oder gegebenenfalls der Betreiber von dem schwerwiegenden Vorfall Kenntnis erlangt hat.

(5) Wenn es zur Gewährleistung der rechtzeitigen Meldung erforderlich ist, kann der Anbieter oder gegebenenfalls der Betreiber einen unvollständigen Erstbericht vorlegen, dem ein vollständiger Bericht folgt.

(6) Im Anschluss an die Meldung eines schwerwiegenden Vorfalls gemäß Absatz 1 führt der Anbieter unverzüglich die erforderlichen Untersuchungen im Zusammenhang mit dem schwerwiegenden Vorfall und dem betroffenen KI-System durch. Dies umfasst eine Risikobewertung des Vorfalls sowie Korrekturmaßnahmen.

Der Anbieter arbeitet bei den Untersuchungen gemäß Unterabsatz 1 mit den zuständigen Behörden und gegebenenfalls mit der betroffenen notifizierten Stelle zusammen und nimmt keine Untersuchung vor, die zu einer Veränderung des betroffenen KI-Systems in einer Weise führt, die möglicherweise Auswirkungen auf eine spätere Bewertung der Ursachen des Vorfalls hat, bevor er die zuständigen Behörden über eine solche Maßnahme nicht unterrichtet hat.

(7) Sobald die zuständige Marktüberwachungsbehörde eine Meldung über einen in Artikel 3 Nummer 49 Buchstabe c genannten schwerwiegenden Vorfall erhält, informiert sie die in Artikel 77 Absatz 1 genannten nationalen Behörden oder öffentlichen Stellen. Zur leichteren Einhaltung der Pflichten nach Absatz 1 dieses Artikels arbeitet die Kommission entsprechende Leitlinien aus. Diese Leitlinien werden bis zum 2. August 2025 veröffentlicht und regelmäßig bewertet.

(8) Die Marktüberwachungsbehörde ergreift innerhalb von sieben Tagen nach Eingang der in Absatz 1 dieses Artikels genannten Meldung geeignete Maßnahmen gemäß Artikel 19 der Verordnung (EU) 2019/1020 und befolgt die in der genannten Verordnung vorgesehenen Meldeverfahren.

(9) Bei Hochrisiko-KI-Systemen nach Anhang III, die von Anbietern in Verkehr gebracht oder in Betrieb genommen wurden, die Rechtsinstrumenten der Union mit gleichwertigen Meldepflichten wie jenen in dieser Verordnung festgesetzten unterliegen, müssen nur jene schwerwiegenden Vorfälle gemeldet werden, die in Artikel 3 Nummer 49 Buchstabe c genannt werden.

(10) Bei Hochrisiko-KI-Systemen, bei denen es sich um Sicherheitsbauteile von Produkten handelt, die unter die Verordnungen (EU) 2017/745 und (EU) 2017/746 fallen, oder die selbst solche Produkte sind, müssen nur die in Artikel 3 Nummer 49 Buchstabe c dieser Verordnung genannten schwerwiegenden Vorfälle gemeldet werden, und zwar der zuständigen nationalen Behörde, die für diesen Zweck von den Mitgliedstaaten, in denen der Vorfall stattgefunden hat, ausgewählt wurde.

(11) Die zuständigen nationalen Behörden melden der Kommission unverzüglich jeden schwerwiegenden Vorfall gemäß Artikel 20 der Verordnung (EU) 2019/1020, unabhängig davon, ob sie diesbezüglich Maßnahmen ergriffen haben.

<a id="chapter-ix-section-3"></a>
## Abschnitt 3 – Durchsetzung

<a id="art-74"></a>
### Artikel 74 – Marktüberwachung und Kontrolle von KI-Systemen auf dem Unionsmarkt

(1) Die Verordnung (EU) 2019/1020 gilt für KI-Systeme, die unter die vorliegende Verordnung fallen. Für die Zwecke einer wirksamen Durchsetzung der vorliegenden Verordnung gilt Folgendes:

- a) Jede Bezugnahme auf einen Wirtschaftsakteur nach der Verordnung (EU) 2019/1020 gilt auch als Bezugnahme auf alle Akteure, die in Artikel 2 Absatz 1 der vorliegenden Verordnung genannt werden;

- b) jede Bezugnahme auf ein Produkt nach der Verordnung (EU) 2019/1020 gilt auch als Bezugnahme auf alle KI-Systeme, die in den Anwendungsbereich der vorliegenden Verordnung fallen.

(2) Im Rahmen ihrer Berichtspflichten gemäß Artikel 34 Absatz 4 der Verordnung (EU) 2019/1020 melden die Marktüberwachungsbehörden der Kommission und den einschlägigen nationalen Wettbewerbsbehörden jährlich alle Informationen, die sie im Verlauf ihrer Marktüberwachungstätigkeiten erlangt haben und die für die Anwendung von Unionsrecht im Bereich der Wettbewerbsregeln von Interesse sein könnten. Ferner erstatten sie der Kommission jährlich Bericht über die Anwendung verbotener Praktiken in dem betreffenden Jahr und über die ergriffenen Maßnahmen.

(3) Bei Hochrisiko-KI-Systemen und damit in Zusammenhang stehenden Produkten, auf die die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union Anwendung finden, gilt als Marktüberwachungsbehörde für die Zwecke dieser Verordnung die in jenen Rechtsakten für die Marktüberwachung benannte Behörde.

Abweichend von Unterabsatz 1 und unter geeigneten Umständen können die Mitgliedstaaten eine andere einschlägige Behörde benennen, die die Funktion der Marktüberwachungsbehörde übernimmt, sofern sie die Koordinierung mit den einschlägigen sektorspezifischen Marktüberwachungsbehörden, die für die Durchsetzung der in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union zuständig sind, sicherstellen.

(4) Die Verfahren gemäß den Artikeln 79 bis 83 der vorliegenden Verordnung gelten nicht für KI-Systeme, die im Zusammenhang mit Produkten stehen, auf die die in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union Anwendung finden, wenn in diesen Rechtsakten bereits Verfahren, die ein gleichwertiges Schutzniveau sicherstellen und dasselbe Ziel haben, vorgesehen sind. In diesen Fällen kommen stattdessen die einschlägigen sektorspezifischen Verfahren zur Anwendung.

(5) Unbeschadet der Befugnisse der Marktüberwachungsbehörden gemäß Artikel 14 der Verordnung (EU) 2019/1020 können die Marktüberwachungsbehörden für die Zwecke der Sicherstellung der wirksamen Durchsetzung der vorliegenden Verordnung die in Artikel 14 Absatz 4 Buchstaben d und j der genannten Verordnung genannten Befugnisse gegebenenfalls aus der Ferne ausüben.

(6) Bei Hochrisiko-KI-Systemen, die von auf der Grundlage des Unionsrechts im Bereich der Finanzdienstleistungen regulierten Finanzinstituten in Verkehr gebracht, in Betrieb genommen oder verwendet werden, gilt die in jenen Rechtsvorschriften für die Finanzaufsicht über diese Institute benannte nationale Behörde als Marktüberwachungsbehörde für die Zwecke dieser Verordnung, sofern das Inverkehrbringen, die Inbetriebnahme oder die Verwendung des KI-Systems mit der Erbringung dieser Finanzdienstleistungen in direktem Zusammenhang steht.

(7) Abweichend von Absatz 6 kann der Mitgliedstaat — unter geeigneten Umständen und wenn für Abstimmung gesorgt ist — eine andere einschlägige Behörde als Marktüberwachungsbehörde für die Zwecke dieser Verordnung benennen.

Nationale Marktüberwachungsbehörden, die unter die Richtlinie 2013/36/EU fallende Kreditinstitute, welche an dem mit der Verordnung (EU) Nr. 1024/2013 eingerichteten einheitlichen Aufsichtsmechanismus teilnehmen, beaufsichtigen, sollten der Europäischen Zentralbank unverzüglich alle im Zuge ihrer Marktüberwachungstätigkeiten ermittelten Informationen übermitteln, die für die in der genannten Verordnung festgelegten Aufsichtsaufgaben der Europäischen Zentralbank von Belang sein könnten.

(8) Für die in Anhang III Nummer 1 der vorliegenden Verordnung genannten Hochrisiko-KI-Systeme, sofern diese Systeme für Strafverfolgungszwecke, Grenzmanagement und Justiz und Demokratie eingesetzt werden, und für die in Anhang III Nummern 6, 7 und 8 genannten Hochrisiko-KI-Systeme benennen die Mitgliedstaaten für die Zwecke dieser Verordnung als Marktüberwachungsbehörden entweder die nach der Verordnung (EU) 2016/679 oder der Richtlinie (EU) 2016/680 für den Datenschutz zuständigen Aufsichtsbehörden oder jede andere gemäß denselben Bedingungen wie den in den Artikeln 41 bis 44 der Richtlinie (EU) 2016/680 festgelegten benannte Behörde. Marktüberwachungstätigkeiten dürfen in keiner Weise die Unabhängigkeit von Justizbehörden beeinträchtigen oder deren Handlungen im Rahmen ihrer justiziellen Tätigkeit anderweitig beeinflussen.

(9) Soweit Organe, Einrichtungen und sonstige Stellen der Union in den Anwendungsbereich dieser Verordnung fallen, übernimmt der Europäische Datenschutzbeauftragte die Funktion der für sie zuständigen Marktüberwachungsbehörde — ausgenommen für den Gerichtshof der Europäischen Union im Rahmen seiner Rechtsprechungstätigkeit.

(10) Die Mitgliedstaaten erleichtern die Koordinierung zwischen den auf der Grundlage dieser Verordnung benannten Marktüberwachungsbehörden und anderen einschlägigen nationalen Behörden oder Stellen, die die Anwendung der in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union oder sonstigen Unionsrechts überwachen, das für die in Anhang III genannten Hochrisiko-KI-Systeme relevant sein könnte.

(11) Die Marktüberwachungsbehörden und die Kommission können gemeinsame Tätigkeiten, einschließlich gemeinsamer Untersuchungen, vorschlagen, die von den Marktüberwachungsbehörden oder von den Marktüberwachungsbehörden gemeinsam mit der Kommission durchgeführt werden, um Konformität zu fördern, Nichtkonformität festzustellen, zu sensibilisieren oder Orientierung zu dieser Verordnung und bestimmten Kategorien von Hochrisiko-KI-Systemen, bei denen festgestellt wird, dass sie in zwei oder mehr Mitgliedstaaten gemäß Artikel 9 der Verordnung (EU) 2019/1020 ein ernstes Risiko darstellen, zu geben. Das Büro für Künstliche Intelligenz unterstützt die Koordinierung der gemeinsamen Untersuchungen.

(12) Die Anbieter gewähren den Marktüberwachungsbehörden unbeschadet der Befugnisübertragung gemäß der Verordnung (EU) 2019/1020 — sofern dies relevant ist und beschränkt auf das zur Wahrnehmung der Aufgaben dieser Behörden erforderliche Maß — uneingeschränkten Zugang zur Dokumentation sowie zu den für die Entwicklung von Hochrisiko-KI-Systemen verwendeten Trainings-, Validierungs- und Testdatensätzen, gegebenenfalls und unter Einhaltung von Sicherheitsvorkehrungen auch über die Anwendungsprogrammierschnittstellen (im Folgenden „API“) oder andere einschlägige technische Mittel und Instrumente, die den Fernzugriff ermöglichen.

(13) Zum Quellcode des Hochrisiko-KI-Systems erhalten Marktüberwachungsbehörden auf begründete Anfrage und nur dann Zugang, wenn die beiden folgenden Bedingungen erfüllt sind:

- a) Der Zugang zum Quellcode ist zur Bewertung der Konformität eines Hochrisiko-KI-Systems mit den in Kapitel III Abschnitt 2 festgelegten Anforderungen notwendig und

- b) die Test- oder Prüfverfahren und Überprüfungen aufgrund der vom Anbieter bereitgestellten Daten und Dokumentation wurden ausgeschöpft oder haben sich als unzureichend erwiesen.

(14) Jegliche Informationen oder Dokumentation, in deren Besitz die Marktüberwachungsbehörden gelangen, werden im Einklang mit den in Artikel 78 festgelegten Vertraulichkeitspflichten behandelt.

<a id="art-75"></a>
### Artikel 75 – Marktüberwachung und Kontrolle von KI-Systemen sowie Amtshilfe

▼M1

(1) Das Büro für Künstliche Intelligenz ist ausschließlich für die Beaufsichtigung und Durchsetzung der Pflichten aus dieser Verordnung in Bezug auf die folgenden KI-Systeme zuständig:

- a) KI-Systeme auf der Grundlage von KI-Modellen mit allgemeinem Verwendungszweck, bei denen das Modell und das System von demselben Anbieter oder von Anbietern entwickelt werden, die Teil desselben Unternehmens wie dieser Anbieter sind, mit Ausnahme von:

  - i) KI-Systemen im Zusammenhang mit Produkten, die unter die in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union fallen;

  - ii) KI-Systemen gemäß Anhang III Nummer 2;

  - iii) KI-Systemen, die von Strafverfolgungsbehörden, Grenzverwaltungsbehörden und Finanzinstituten bereitgestellt werden, sofern diese KI-Systeme unter Artikel 74 Absatz 6 fallen, und

  - iv) KI-Systemen gemäß Anhang III Nummer 8 in Bezug auf die Rechtspflege;

- b) KI-Systemen, die eine gemäß der Verordnung (EU) 2022/2065 benannte sehr große Online-Plattform oder sehr große Online-Suchmaschine bilden oder die darin integriert sind.

Die in Unterabsatz 1 genannte ausschließliche Zuständigkeit gilt für die Anbieter dieser Systeme. Sie gilt für die Betreiber dieser Systeme nur dann, wenn sie auch Anbieter dieser Systeme sind oder Teil desselben Unternehmens wie der Anbieter sind.

▼M1

(1a) Abweichend von Artikel 73 melden Anbieter von Hochrisiko-KI-Systemen, die der Zuständigkeit des Büros für Künstliche Intelligenz gemäß Absatz 1 dieses Artikels unterliegen, dem Büro für Künstliche Intelligenz alle schwerwiegenden Vorfälle. Die Absätze 2 bis 9 des Artikels 73 gelten sinngemäß. Das Büro für Künstliche Intelligenz übermittelt die einschlägigen Informationen unverzüglich der Marktüberwachungsbehörde des Mitgliedstaats, in dessen Hoheitsgebiet sich der Anbieter oder sein gesetzlicher Vertreter befindet.

(1b) Die an der Anwendung dieser Verordnung beteiligten Behörden arbeiten aktiv mit dem Büro für Künstliche Intelligenz zusammen und leistet ihm die erforderliche Unterstützung für die Ausübung seiner Befugnisse, unter anderem erforderlichenfalls im Zusammenhang mit Inspektionen oder anderen Durchsetzungsmaßnahmen im Hoheitsgebiet eines Mitgliedstaats. Zu diesem Zweck verfügen diese Behörden über die in dieser Verordnung und der Verordnung (EU) 2019/1020 niedergelegten Befugnisse und soweit zutreffend und auf das zur Erfüllung ihrer Aufgaben nach diesem Absatz erforderliche Maß beschränkt, im Einklang mit den geltenden nationalen Verfahren.

(1c) Werden im Hoheitsgebiet eines Mitgliedstaats Ermittlungs- oder Durchsetzungsmaßnahmen ergriffen, die den Zugang zu Daten oder KI-Systemen einer Behörde umfassen, so wird das Büro für Künstliche Intelligenz von der einschlägigen Marktüberwachungsbehörde unterstützt.

(1d) Bevor das Büro für Künstliche Intelligenz eine Entscheidung trifft, die ein Verbot oder eine Beschränkung der Bereitstellung oder Inbetriebnahme des KI-Systems auf einem nationalen Markt zur Folge hätte, oder bevor es eine Entscheidung dahin gehend trifft, das KI-System von einem solchen Markt zu nehmen oder zurückzurufen, unterrichtet es die für diesen Markt zuständige Marktüberwachungsbehörde unverzüglich über seine Absicht, eine solche Entscheidung zu treffen. Das Büro für Künstliche Intelligenz konsultiert gegebenenfalls die an der Anwendung dieser Verordnung beteiligten Behörden zu allen Fragen im Zusammenhang mit der Anwendung und Durchsetzung dieser Verordnung.

(1e) Das Büro für Künstliche Intelligenz ist für Konformitätsbewertungen und Tests der in Absatz 1 dieses Artikels genannten KI-Systeme zuständig, die als hochriskant eingestuft sind und einer Konformitätsbewertung durch Dritte gemäß Artikel 43 unterliegen, wobei diese Konformitätsbewertung durchzuführen ist, bevor solche KI-Systeme in Verkehr gebracht oder in Betrieb genommen werden. Bei diesen Tests und Bewertungen wird überprüft, ob die Systeme den einschlägigen Anforderungen dieser Verordnung entsprechen und gemäß dieser Verordnung in der Union in Verkehr gebracht bzw. in Betrieb genommen werden dürfen. Die Kommission betraut die gemäß dieser Verordnung benannten notifizierten Stellen mit der Durchführung dieser Tests oder Bewertungen; in diesem Fall handeln diese notifizierten Stellen im Namen der Kommission. Kommt eine notifizierte Stelle, der die Kommission Aufgaben gemäß diesem Absatz übertragen hat, diesen Aufgaben nicht angemessen nach, so kann die Kommission die Übertragung mit sofortiger Wirkung widerrufen.

Die Gebühren für Test- und Bewertungstätigkeiten werden von dem Anbieter eines Hochrisiko-KI-Systems erhoben, der bei der Kommission eine Konformitätsbewertung durch Dritte beantragt hat. Der Anbieter zahlt die Kosten der Dienstleistungen, mit denen die Kommission die notifizierten Stellen gemäß diesem Artikel betraut hat, direkt an die notifizierte Stelle.

▼B

(2) Haben die zuständigen Marktüberwachungsbehörden hinreichenden Grund für die Auffassung, dass KI-Systeme mit allgemeinem Verwendungszweck, die von Betreibern direkt für mindestens einen Zweck, der gemäß dieser Verordnung als hochriskant eingestuft ist, verwendet werden können, nicht mit den in dieser Verordnung festgelegten Anforderungen konform sind, so arbeiten sie bei der Durchführung von Konformitätsbewertungen mit dem Büro für Künstliche Intelligenz zusammen und unterrichten das KI-Gremium und andere Marktüberwachungsbehörden entsprechend.

▼M1

(2a) Hat eine Marktüberwachungsbehörde fundierte und hinreichende Gründe für den Verdacht, dass ein Anbieter oder Betreiber eines in Absatz 1 dieses Artikels genannten KI-Systems gegen diese Verordnung verstoßen hat, so kann sie das Büro für Künstliche Intelligenz über die gemäß Artikel 70 Absatz 2 benannte zuständige zentrale Anlaufstelle ersuchen, die Angelegenheit zu prüfen, damit die erforderlichen Aufsichts- und Durchsetzungsmaßnahmen ergriffen werden können, um die unverzügliche Einhaltung dieser Verordnung sicherzustellen. Entsprechende Ersuchen sind hinreichend zu begründen und umfassen mindestens Folgendes:

- a) den Namen des betreffenden Anbieters oder Betreibers;

- b) eine Beschreibung des relevanten Sachverhalts, der Bestimmungen dieser Verordnung, gegen die mutmaßlich verstoßen wurde, und aller fundierten und hinreichenden Gründe für den Verdacht eines Verstoßes, gegebenenfalls einschließlich einer Beschreibung der negativen Auswirkungen des mutmaßlichen Verstoßes;

- c) die ersuchende Marktüberwachungsbehörde.

Das Büro für Künstliche Intelligenz trägt dem Ersuchen mit größter Sorgfalt Rechnung, und die Marktüberwachungsbehörde kooperiert aktiv und leistet dem Büro für Künstliche Intelligenz die erforderliche Unterstützung für die Ausübung seiner Befugnisse gemäß Absatz 1a.

Das Büro für Künstliche Intelligenz unterrichtet die zentrale Anlaufstelle unverzüglich, spätestens jedoch vier Monate nach Eingang des Ersuchens, über seine Absicht, seine Befugnisse gemäß Artikel 75a auszuüben, oder über die Gründe dafür, dass es seine Befugnisse nicht ausübt. Beschließt das Büro für Künstliche Intelligenz, seine Befugnisse gemäß Artikel 75a auszuüben, so unterrichtet es die zentrale Anlaufstelle regelmäßig über wichtige Entwicklungen in dem Verfahren und das Ergebnis dieses Verfahrens, ohne vertrauliche Informationen offenzulegen.

▼B

(3) Ist eine Marktüberwachungsbehörde wegen der Unzugänglichkeit bestimmter Informationen im Zusammenhang mit dem KI-Modell mit allgemeinem Verwendungszweck nicht in der Lage, ihre Ermittlungen zu dem Hochrisiko-KI-System abzuschließen, obwohl sie alle angemessenen Anstrengungen unternommen hat, diese Informationen zu erhalten, kann sie ein begründetes Ersuchen an das Büro für Künstliche Intelligenz richten, durch das der Zugang zu den Informationen durchgesetzt werden kann. In diesem Fall übermittelt das Büro für Künstliche Intelligenz der ersuchenden Behörde unverzüglich, spätestens aber innerhalb von 30 Tagen, alle Informationen, die das Büro für Künstliche Intelligenz für die Feststellung, ob ein Hochrisiko-KI-System nicht konform ist, für erforderlich erachtet. Die Marktüberwachungsbehörden gewährleisten gemäß Artikel 78 der vorliegenden Verordnung die Vertraulichkeit der von ihnen erlangten Informationen. Das Verfahren nach Kapitel VI der Verordnung (EU) 2019/1020 gilt entsprechend.

▼M1

<a id="art-75a"></a>
### Artikel 75a – Aufsichts- und Durchsetzungsbefugnisse des Büros für Künstliche Intelligenz

(1) Zur Wahrnehmung seiner in Artikel 75 Absatz 1 der vorliegenden Verordnung niedergelegten Aufgaben in Bezug auf Aufsicht und Durchsetzung hat das Büro für Künstliche Intelligenz alle in diesem Abschnitt und in Artikel 14 Absatz 4 und Artikel 16 Absatz 3 der Verordnung (EU) 2019/1020 vorgesehenen Befugnisse einer Marktüberwachungsbehörde. Das Büro für Künstliche Intelligenz ist befugt, gemäß Artikel 15 der Verordnung (EU) 2019/1020 die gesamten Kosten seiner Aufsichts- und Durchsetzungstätigkeiten in Bezug auf Fälle von Nichtkonformität, einschließlich der Kosten für personelle und technische Ressourcen, von dem betreffenden Akteur vollständig zurückzufordern. Artikel 17 der Verordnung (EU) 2019/1020 gilt sinngemäß.

(2) Hat das Büro für Künstliche Intelligenz berechtigten Grund zu der Annahme, dass ein Anbieter oder Betreiber eines in Artikel 75 Absatz 1 der vorliegenden Verordnung genannten KI-Systems gegen die vorliegende Verordnung verstößt, so kann es gemäß Artikel 14 Absatz 4 Buchstabe f der Verordnung (EU) 2019/1020 beschließen, in Bezug auf diese Nichtkonformität eine Ermittlung einzuleiten. Im Zuge der Einleitung einer solchen Ermittlung unterrichtet das Büro für Künstliche Intelligenz den Akteur des betreffenden KI-Systems. Das Büro für Künstliche Intelligenz kann die in Absatz 1 dieses Artikels genannten Befugnisse von Amts wegen oder aufgrund einer gemäß Artikel 85 dieser Verordnung eingegangenen Beschwerde ausüben, noch bevor es eine Ermittlung gemäß Artikel 14 Absatz 4 Buchstabe f der Verordnung (EU) 2019/1020 einleitet.

Hat eine Marktüberwachungsbehörde Grund zu der Annahme, dass ein Anbieter oder Betreiber eines in Artikel 75 Absatz 1 genannten KI-Systems gegen die vorliegende Verordnung verstößt, kann sie das Büro für Künstliche Intelligenz ersuchen, die Angelegenheit zu prüfen.

(3) Das Büro für Künstliche Intelligenz kann die in Artikel 14 Absatz 4 Buchstaben a, b und c der Verordnung (EU) 2019/1020 und in Artikel 74 Absätze 12 und 13 der vorliegenden Verordnung aufgeführten Befugnisse durch einfaches Ersuchen oder im Wege eines Beschlusses ausüben.

Bei einem Informationsersuchen gibt das Büro für Künstliche Intelligenz die Rechtsgrundlage und den Zweck des Ersuchens an, gibt an, welche Informationen erforderlich sind, und legt die Frist fest, innerhalb deren die Informationen bereitzustellen sind. Handelt es sich bei dem Ersuchen um ein einfaches Ersuchen, weist das Büro für Künstliche Intelligenz zusätzlich darauf hin, dass zwar keine Verpflichtung zur Bereitstellung der angeforderten Informationen besteht, im Falle einer freiwilligen Antwort die Informationen jedoch richtig sein müssen und nicht irreführend sein dürfen, und es weist auf die möglichen Geldbußen gemäß Artikel 99 Absatz 5 für die Bereitstellung von Informationen hin, die unrichtig oder irreführend sind. Beruht das Ersuchen auf einem Beschluss, gibt das Büro für Künstliche Intelligenz zusätzlich die in Artikel 99 Absatz 5 vorgesehenen Geldbußen für die Bereitstellung unrichtiger, unvollständiger oder irreführender Informationen an und weist auf das Recht hin, den Beschluss durch den Gerichtshof der Europäischen Union überprüfen zu lassen. Das Büro für Künstliche Intelligenz übermittelt der Marktüberwachungsbehörde des Mitgliedstaats, in dessen Hoheitsgebiet sich der Akteur oder sein gesetzlicher Vertreter befindet, eine Kopie des Ersuchens.

(4) Zur Wahrnehmung der ihm gemäß diesem Abschnitt übertragenen Aufgaben kann das Büro für Künstliche Intelligenz im Rahmen der Befugnisse nach Artikel 14 Absatz 4 Buchstaben d und e der Verordnung (EU) 2019/1020 und Artikel 74 Absatz 5 der vorliegenden Verordnung alle erforderlichen Ferninspektionen oder Vor-Ort-Inspektionen durchführen. Bei der Durchführung einer Inspektion informiert das Büro für Künstliche Intelligenz den betreffenden Anbieter über den Gegenstand und Zweck der Untersuchung, die einschlägigen Geldbußen gemäß Artikel 99 Absatz 5 der vorliegenden Verordnung sowie das Recht, den Beschluss durch den Gerichtshof der Europäischen Union überprüfen zu lassen. Im Vorfeld der Durchführung einer Inspektion unterrichtet das Büro für Künstliche Intelligenz die Marktüberwachungsbehörde des Mitgliedstaats, in dessen Hoheitsgebiet sich der Akteur oder sein gesetzlicher Vertreter befindet.

Die Bediensteten des Büros für Künstliche Intelligenz sind im Zuge von Inspektionen befugt,

- a) alle in der Union gelegenen Geschäftsräume, Grundstücke oder Immobilien des betreffenden Betreibers zu betreten,

- b) die Bücher, Daten und sonstiges für die Erfüllung ihrer Aufgaben relevantes Material, unabhängig davon, in welcher Form es gespeichert ist, zu prüfen,

- c) Kopien oder Auszüge gleich in welcher Form aus Büchern, von Daten und aus sonstigen Aufzeichnungen anzufertigen oder zu verlangen,

- d) jede von der Inspektion betroffene Person oder ihre Vertreter oder jeden Beschäftigten zur Abgabe mündlicher oder schriftlicher Erklärungen zu Sachverhalten oder Unterlagen aufzufordern, die mit dem Gegenstand und Zweck der Inspektion in Zusammenhang stehen, und die Antworten aufzuzeichnen,

- e) betriebliche Räumlichkeiten und Bücher oder Unterlagen jeder Art für die Dauer der Inspektion in dem hierfür erforderlichen Ausmaß zu versiegeln.

Stellt das Büro für Künstliche Intelligenz fest, dass sich eine natürliche oder juristische Person einer Inspektion widersetzt oder diese behindert, so gewährt die zuständige nationale Behörde des betreffenden Mitgliedstaats gegebenenfalls unter Einsatz von Polizeikräften oder einer entsprechenden vollziehenden Behörde die erforderliche Unterstützung, damit die Vor-Ort-Inspektion durchgeführt werden kann.

Ist für eine Vor-Ort-Inspektion von Geschäftsräumen, Grundstücken oder Immobilien eine gerichtliche Genehmigung nach nationalem Recht erforderlich, so ersucht das Büro für Künstliche Intelligenz um eine solche Genehmigung. Das Büro für Künstliche Intelligenz kann die Genehmigung auch vorsorglich beantragen. Wird eine solche Genehmigung beantragt, so verifiziert die nationale Justizbehörde unverzüglich, dass die geplanten Zwangsmaßnahmen im Hinblick auf den Gegenstand der Untersuchung oder Inspektion und die vom Büro für Künstliche Intelligenz mit dem Beschluss vorgelegten Unterlagen weder willkürlich noch unverhältnismäßig sind. Bei der Prüfung der Verhältnismäßigkeit von Zwangsmaßnahmen kann die nationale Justizbehörde das Büro für Künstliche Intelligenz um detaillierte Erläuterungen bitten, insbesondere in Bezug auf die Gründe, die dem Büro für Künstliche Intelligenz Anlass zu der Vermutung geben, dass ein Verstoß gegen diese Verordnung vorliegt, sowie auf die Schwere des mutmaßlichen Verstoßes und die Art der Beteiligung der Person, gegen die sich die Zwangsmaßnahmen richten. Die nationale Justizbehörde darf weder die Notwendigkeit der Untersuchung oder Inspektion prüfen noch Auskünfte aus der Verfahrensakte des Büros für Künstliche Intelligenz verlangen. Gemäß den Verträgen unterliegt die Rechtmäßigkeit des Beschlusses des Büros für Künstliche Intelligenz ausschließlich der Kontrolle durch den Gerichtshof der Europäischen Union.

(5) Auf Ersuchen des Büros für Künstliche Intelligenz kann die zuständige Marktüberwachungsbehörde eines Mitgliedstaats in ihrem eigenen Hoheitsgebiet im Namen und für Rechnung des Büros für Künstliche Intelligenz Untersuchungen, Inspektionen oder andere Maßnahmen zur Sachverhaltsaufklärung durchführen, um festzustellen, ob ein Verstoß gegen diese Verordnung vorliegt. Die Bediensteten der zuständigen Behörden der Mitgliedstaaten, die für die Durchführung solcher Untersuchungen, Inspektionen oder Maßnahmen zur Sachverhaltsaufklärung zuständig sind, sowie die von ihnen ermächtigten oder bestellten Personen üben ihre Befugnisse nach Maßgabe ihres nationalen Rechts aus.

(6) Zusätzlich zu den in Absatz 1 dieses Artikels genannten Befugnissen kann das Büro für Künstliche Intelligenz in Ausübung seiner in Artikel 75 Absatz 1 genannten Zuständigkeiten

- a) Akteure anweisen, Zugang zu ihren KI-Systemen zu gewähren und einschlägige Erläuterungen bereitzustellen,

- b) einem Akteur die Verpflichtung auferlegen, alle Daten und Unterlagen aufzubewahren, die als erforderlich erachtet werden, damit die Umsetzung und Einhaltung der aus dieser Verordnung erwachsenden Verpflichtungen bewertet werden kann.

(7) Das Büro für Künstliche Intelligenz kann mit Zustimmung der betreffenden Behörde unabhängige externe Sachverständige und Prüfer sowie Sachverständige, Untersuchungsteams und Prüfer aus den zuständigen Behörden des Mitgliedstaats bestellen, um es bei der Überwachung der wirksamen Durchführung und Einhaltung der einschlägigen Bestimmungen dieser Verordnung zu unterstützen und dem Büro für Künstliche Intelligenz spezifisches Fachwissen oder spezifische Kenntnisse bei der Ausübung seiner Befugnisse gemäß Artikel 75 Absatz 1 zur Verfügung zu stellen. Die im Rahmen dieser Überwachungsmaßnahmen erlangten Informationen werden an die einschlägigen zuständigen Behörden der Mitgliedstaaten weitergegeben.

(8) Die nach diesem Artikel erhobenen Informationen dürfen ausschließlich für den Zweck dieser Verordnung verwendet werden.

<a id="art-75b"></a>
### Artikel 75b – Verpflichtungszusagen

Bietet der betreffende Akteur während des Verfahrens nach Artikel 75a Absatz 2 Verpflichtungszusagen an, mit denen die Einhaltung der einschlägigen Bestimmungen dieser Verordnung sichergestellt wird, so kann das Büro für Künstliche Intelligenz diese Verpflichtungszusagen durch einen Beschluss für den Akteur für bindend erklären und feststellen, dass es keinen weiteren Anlass zum Handeln gibt. Das Büro für Künstliche Intelligenz kann das Verfahren auf Antrag oder von Amts wegen wieder aufnehmen, wenn

- a) sich der Sachverhalt, auf den sich der Beschluss stützte, in einem wesentlichen Punkt geändert hat,

- b) der Akteur seinen Verpflichtungszusagen zuwiderhandelt oder

- c) der Beschluss auf unvollständigen, unrichtigen oder irreführenden Angaben des betreffenden Akteurs beruhte.

Ist das Büro für Künstliche Intelligenz der Auffassung, dass die von dem betreffenden Akteur angebotenen Verpflichtungszusagen die wirksame Einhaltung der einschlägigen Bestimmungen dieser Verordnung nicht sicherstellen können, so lehnt sie diese Verpflichtungszusagen bei Abschluss des Verfahrens in einem mit Gründen versehenen Beschluss ab.

<a id="art-75c"></a>
### Artikel 75c – Verstöße, Geldbußen und Zwangsgelder

(1) Stellt das Büro für Künstliche Intelligenz fest, dass ein Akteur, der in den Anwendungsbereich von Artikel 75 Absatz 1 fällt, die einschlägigen Bestimmungen dieser Verordnung oder die gemäß Artikel 75b für bindend erklärten Verpflichtungszusagen nicht einhält, so erlässt es einen Beschluss, mit dem ein solcher Verstoß festgestellt wird.

(2) Vor Erlass des Beschlusses nach Absatz 1 teilt das Büro für Künstliche Intelligenz dem betreffenden Akteur seine vorläufige Beurteilung mit. In dieser vorläufigen Beurteilung erläutert das Büro für Künstliche Intelligenz, welche Maßnahmen es zu ergreifen beabsichtigt bzw. der betreffende Akteur ergreifen sollte, um der vorläufigen Beurteilung wirksam Rechnung zu tragen.

(3) In dem Beschluss gemäß Absatz 1 dieses Artikels ordnet das Büro für Künstliche Intelligenz gegebenenfalls an, dass der betreffende Akteur die erforderlichen Maßnahmen ergreift, um die Einhaltung der einschlägigen Bestimmungen dieser Verordnung innerhalb einer angemessenen, darin genannten Frist sicherzustellen, und dass der Akteur Informationen über die Maßnahmen übermittelt, die er zu ergreifen beabsichtigt, um dem Beschluss nachzukommen. Der betreffende Akteur legt dem Büro für Künstliche Intelligenz eine Beschreibung der Maßnahmen vor, die er ergriffen hat, um die Einhaltung des Beschlusses durch ihre Umsetzung sicherzustellen. Bevor das Büro für Künstliche Intelligenz eine Maßnahme fordert, kann es einen strukturierten Dialog mit dem Akteur des betreffenden KI-Systems aufnehmen. Während dieses Dialogs kann der Akteur Verpflichtungszusagen gemäß Artikel 75b vorschlagen.

(4) Ein nach Absatz 1 dieses Artikels erlassener Beschluss kann mit der Verhängung von Sanktionen gemäß Artikel 99 Absätze 3 bis 7 einhergehen, deren Bestimmungen sinngemäß für das Büro für Künstliche Intelligenz bei der Wahrnehmung seiner Aufsichts- und Durchsetzungsaufgaben gemäß Artikel 75 Absatz 1 gelten.

Mit Geldbußen nach Artikel 99 Absatz 4 werden insbesondere belegt:

- a) Verstöße gegen anwendbare Bestimmungen dieser Verordnung, einschließlich der nicht in Artikel 99 Absatz 4 aufgeführten Bestimmungen;

- b) die Nichteinhaltung von Beschlüssen oder Maßnahmen, die gemäß den in Artikel 14 Absatz 4 oder Artikel 16 Absatz 3 der Verordnung (EU) 2019/1020 aufgeführten Befugnissen sowie den in Artikel 75a dieser Verordnung aufgeführten Befugnissen erlassen wurden;

- c) die Nichteinhaltung einer Verpflichtungszusage, die durch einen Beschluss gemäß Artikel 75b für bindend erklärt wurde.

Die Übermittlung unrichtiger, unvollständiger oder irreführender Informationen an das Büro für Künstliche Intelligenz als Antwort auf ein Ersuchen wird mit Geldbußen gemäß Artikel 99 Absatz 5 belegt.

(5) Das Büro für Künstliche Intelligenz kann einen Beschluss zur Verhängung von Zwangsgeldern erlassen, um die seiner Zuständigkeit unterliegenden Akteure gemäß Artikel 75 Absatz 1 zu zwingen,

- a) eine Untersuchung zu dulden,

- b) einem durch einen Beschluss gemäß Artikel 75a Absatz 3 angeordneten Informationsersuchen nachzukommen,

- c) sich einer durch einen Beschluss gemäß Artikel 75a Absatz 4 angeordneten Inspektion zu unterziehen,

- d) im Rahmen einer durch einen Beschluss gemäß Artikel 75a Absatz 4 angeordneten Inspektion richtige oder vollständige Antworten oder Erläuterungen zu geben,

- e) den gemäß der Befugnis nach Artikel 16 der Verordnung (EU) 2019/1020 angeordneten Korrekturmaßnahmen nachzukommen,

- f) durch Beschluss nach Artikel 75b für bindend erklärte Verpflichtungszusagen einzuhalten oder

- g) einem Beschluss nach Absatz 1 dieses Artikels nachzukommen.

Diese Zwangsgelder müssen wirksam und verhältnismäßig sein und dürfen gegebenenfalls 5 % der durchschnittlichen Tageseinnahmen oder des durchschnittlichen weltweiten Jahresumsatzes im vorangegangenen Geschäftsjahr pro Tag, berechnet ab dem durch den Beschluss bestimmten Tag, nicht übersteigen.

(6) Der Gerichtshof der Europäischen Union besitzt die unbeschränkte Befugnis zur Überprüfung von Beschlüssen, mit denen das Büro für Künstliche Intelligenz eine Geldbuße oder ein Zwangsgeld gemäß diesem Artikel verhängt hat. Er kann die verhängten Geldbußen oder Zwangsgelder aufheben, herabsetzen oder erhöhen.

(7) Das Aufkommen aus den nach diesem Artikel verhängten Geldbußen oder Zwangsgeldern trägt zum Gesamthaushalt der Union bei.

(8) Die Befugnisse, die dem Büro für Künstliche Intelligenz mit diesem Artikel übertragen wurden, verjähren nach einer Frist von fünf Jahren. Die Verjährungsfrist beginnt mit dem Tag, an dem der Verstoß begangen wird. Im Fall andauernder oder wiederholter Verstöße läuft die Verjährungsfrist jedoch ab dem Tag, an dem der Verstoß beendet wird.

Die Befugnis des Büros für Künstliche Intelligenz zur Vollstreckung von Beschlüssen nach diesem Artikel verjährt nach Ablauf von fünf Jahren. Die Verjährungsfrist beginnt mit dem Tag, an dem der Beschluss rechtskräftig wird.

In dem in Artikel 75d Absatz 3 genannten Durchführungsrechtsakt werden die Unterabsätze 1 und 2 dieses Absatzes näher festgelegt, einschließlich der Umstände, unter denen die Verjährungsfristen ausgesetzt werden.

(9) Stellt das Büro für Künstliche Intelligenz fest, dass keine Gründe für den Erlass eines Beschlusses wegen Nichteinhaltung vorliegen, so schließt es das Verfahren mit einem Beschluss ab. Dieser Beschluss ist sofort anwendbar.

<a id="art-75d"></a>
### Artikel 75d – Schutzvorkehrungen und weitere Spezifizierung

(1) Unbeschadet der in dieser Verordnung enthaltenen spezifischeren Verfahrensrechte gilt Artikel 18 der Verordnung (EU) 2019/1020 sinngemäß für Akteure, die gemäß Artikel 75 Absatz 1 dieser Verordnung in die Zuständigkeit des Büros für Künstliche Intelligenz fallen.

(2) Die Verteidigungsrechte und das Recht auf Einsicht in die Akten von Akteuren, die in den Anwendungsbereich von Artikel 75 Absatz 1 fallen, werden in den Verfahren in vollem Umfang gewahrt. Im Hinblick auf den möglichen Erlass von Beschlüssen auf der Grundlage von Artikel 75c Absatz 1 haben diese Akteure das Recht auf Einsicht in die Akten des Büros für Künstliche Intelligenz im Rahmen einer einvernehmlichen Einsichtnahme, vorbehaltlich des berechtigten Interesses des Akteurs oder einer anderen betroffenen Person an der Wahrung ihrer Geschäftsgeheimnisse. Das Büro für Künstliche Intelligenz ist befugt, im Falle von Meinungsverschiedenheiten zwischen den Parteien Beschlüsse über die Bedingungen dieser Einsichtnahme zu fassen. Von der Einsicht in die Akten ausgenommen sind vertrauliche Informationen sowie interne Schriftstücke des Büros für Künstliche Intelligenz, anderer zuständiger Marktüberwachungsbehörden oder anderer öffentlicher Stellen der Mitgliedstaaten. Insbesondere ist die Korrespondenz zwischen dem Büro für Künstliche Intelligenz und diesen Behörden und Stellen von der Akteneinsicht ausgenommen. Die Regelung dieses Absatzes steht der Offenlegung und Nutzung der für den Nachweis einer Zuwiderhandlung notwendigen Informationen durch das Büro für Künstliche Intelligenz in keiner Weise entgegen.

(3) Die Kommission kann Durchführungsrechtsakte zu den praktischen Modalitäten für die Akteneinsicht und die einvernehmliche Offenlegung von Informationen gemäß Absatz 2 erlassen.

(4) Das Büro für Künstliche Intelligenz veröffentlicht die Beschlüsse, die es nach den Artikeln 75b und 75c erlässt. In diesen Veröffentlichungen sind die Namen der beteiligten Unternehmen und der wesentliche Inhalt des Beschlusses, einschließlich der gegebenenfalls verhängten Sanktionen, anzugeben. Bei der Veröffentlichung ist den Rechten und dem berechtigten Interesse aller Personen am Schutz ihrer vertraulichen Informationen Rechnung zu tragen.

▼B

<a id="art-76"></a>
### Artikel 76 – Beaufsichtigung von Tests unter Realbedingungen durch Marktüberwachungsbehörden

(1) Marktüberwachungsbehörden müssen über die Kompetenzen und Befugnisse verfügen, um sicherzustellen, dass Tests unter Realbedingungen gemäß dieser Verordnung erfolgen.

▼M1

Beruht der Test unter Realbedingungen auf Artikel 60a, so gilt jede Bezugnahme auf eine Marktüberwachungsbehörde in diesem Artikel als Bezugnahme auf die zuständige nationale Behörde oder die gemäß den in Anhang I Abschnitt B aufgeführten Harmonisierungsrechtsvorschriften der Union zuständige Behörde, und Bezugnahmen auf Artikel 60 gelten entsprechend als Bezugnahmen auf Artikel 60a.

▼B

(2) Wenn ein Test unter Realbedingungen für KI-Systeme durchgeführt wird, die in einem KI-Reallabor gemäß Artikel 58 beaufsichtigt werden, überprüfen die Marktüberwachungsbehörden im Rahmen ihrer Aufsichtsaufgaben für das KI-Reallabor die Einhaltung des Artikels 60. Die Behörden können gegebenenfalls gestatten, dass der Anbieter oder zukünftige Anbieter den Test unter Realbedingungen in Abweichung von den in Artikel 60 Absatz 4 Buchstaben f und g festgelegten Bedingungen durchführt.

(3) Wenn eine Marktüberwachungsbehörde vom zukünftigen Anbieter, vom Anbieter oder von einem Dritten über einen schwerwiegenden Vorfall informiert wurde oder Grund zu der Annahme hat, dass die in den Artikeln 60 und 61 festgelegten Bedingungen nicht erfüllt sind, kann sie — je nachdem, was angemessen ist — in ihrem Hoheitsgebiet gegebenenfalls entscheiden, entweder

- a) den Test unter Realbedingungen auszusetzen oder abzubrechen oder

- b) den Anbieter oder zukünftigen Anbieter und die Betreiber oder zukünftigen Betreiber zur Änderung eines beliebigen Aspekts des Tests unter Realbedingungen zu verpflichten.

(4) Wenn eine Marktüberwachungsbehörde eine Entscheidung nach Absatz 3 des vorliegenden Artikels getroffen oder Einwände im Sinne des Artikels 60 Absatz 4 Buchstabe b erhoben hat, sind im Rahmen der Entscheidung oder der Einwände die Gründe dafür zu nennen sowie anzugeben, wie der Anbieter oder zukünftige Anbieter die Entscheidung oder die Einwände anfechten kann.

(5) Wenn eine Marktüberwachungsbehörde eine Entscheidung nach Absatz 3 getroffen hat, teilt sie ihre Gründe dafür gegebenenfalls den Marktüberwachungsbehörden anderer Mitgliedstaaten mit, in denen das KI-System gemäß dem Plan für den Test getestet wurde.

<a id="art-77"></a>
### Artikel 77 – Befugnisse der für den Schutz der Grundrechte zuständigen Behörden und Zusammenarbeit mit den Marktüberwachungsbehörden

▼M1

(1) Nationale Behörden oder öffentliche Stellen, die die Einhaltung des Unionsrechts zum Schutz der Grundrechte, einschließlich des Rechts auf Nichtdiskriminierung, beaufsichtigen oder durchsetzen, sind befugt, von der betreffenden Marktüberwachungsbehörde sämtliche auf der Grundlage dieser Verordnung erstellten oder geführten Informationen oder Dokumentationen in zugänglicher Sprache und maschinenlesbarer Form auf elektronischem Weg anzufordern und einzusehen, sofern der Zugang zu diesen Informationen oder Dokumentationen für die wirksame Ausübung ihrer Aufträge im Rahmen ihrer Befugnisse innerhalb der Grenzen ihrer Hoheitsgewalt notwendig ist. Dieser Artikel gilt unbeschadet der Zuständigkeiten, Aufgaben, Befugnisse und Unabhängigkeit der zuständigen nationalen Behörden oder öffentlichen Stellen im Rahmen ihres Auftrags.

▼M1

(1a) Unter den in diesem Artikel genannten Bedingungen gewährt die Marktüberwachungsbehörde der in Absatz 1 genannten zuständigen Behörde oder öffentlichen Stelle Zugang zu diesen Informationen oder Dokumentationen, wozu sie diese Informationen oder Dokumentationen erforderlichenfalls und unverzüglich auch erst vom Anbieter oder Betreiber anfordert.

(1b) Die Marktüberwachungsbehörden und die in Absatz 1 genannten Behörden oder öffentlichen Stellen arbeiten eng zusammen und leisten einander die für die Wahrnehmung ihrer jeweiligen Aufgaben erforderliche Amtshilfe, um die kohärente Anwendung dieser Verordnung und des Unionsrechts zum Schutz der Grundrechte zu gewährleisten und die Verfahren zu straffen und gleichzeitig ihre jeweiligen Zuständigkeiten, Aufgaben, Befugnisse und ihre Unabhängigkeit zu achten. Dies umfasst insbesondere den Austausch von Informationen, soweit dieser für die wirksame Beaufsichtigung oder Durchsetzung im Rahmen dieser Verordnung und der anderen einschlägigen Rechtsvorschriften der Union erforderlich ist.

▼B

(2) Bis 2. November 2024 muss jeder Mitgliedstaat die in Absatz 1 genannten Behörden oder öffentlichen Stellen benennen und in einer öffentlichen Liste verfügbar machen. Die Mitgliedstaaten übermitteln die Liste der Kommission und den anderen Mitgliedstaaten und halten die Liste auf dem neuesten Stand.

(3) Sollte die in Absatz 1 genannte Dokumentation nicht ausreichen, um feststellen zu können, ob ein Verstoß gegen das Unionsrecht zum Schutz der Grundrechte vorliegt, so kann die in Absatz 1 genannte Behörde oder öffentliche Stelle bei der Marktüberwachungsbehörde einen begründeten Antrag auf Durchführung eines technischen Tests des Hochrisiko-KI-Systems stellen. Die Marktüberwachungsbehörde führt den Test unter enger Einbeziehung der beantragenden Behörde oder öffentlichen Stelle innerhalb eines angemessenen Zeitraums nach Eingang des Antrags durch.

(4) Jegliche Informationen oder Dokumentation, in deren Besitz die in Absatz 1 des vorliegenden Artikels genannten nationalen Behörden oder öffentlichen Stellen auf der Grundlage des vorliegenden Artikels gelangen, werden im Einklang mit den in Artikel 78 festgelegten Vertraulichkeitspflichten behandelt.

<a id="art-78"></a>
### Artikel 78 – Vertraulichkeit

(1) Die Kommission, die Marktüberwachungsbehörden und die notifizierten Stellen sowie alle anderen natürlichen oder juristischen Personen, die an der Anwendung dieser Verordnung beteiligt sind, wahren gemäß dem Unionsrecht oder dem nationalen Recht die Vertraulichkeit der Informationen und Daten, in deren Besitz sie bei der Ausführung ihrer Aufgaben und Tätigkeiten gelangen, sodass insbesondere Folgendes geschützt ist:

- a) die Rechte des geistigen Eigentums sowie vertrauliche Geschäftsinformationen oder Geschäftsgeheimnisse natürlicher oder juristischer Personen, einschließlich Quellcodes, mit Ausnahme der in Artikel 5 der Richtlinie (EU) 2016/943 des Europäischen Parlaments und des Rates ^(2);

- b) die wirksame Durchführung dieser Verordnung, insbesondere für die Zwecke von Inspektionen, Untersuchungen oder Audits;

- c) öffentliche und nationale Sicherheitsinteressen;

- d) die Durchführung von Straf- oder Verwaltungsverfahren;

- e) gemäß dem Unionsrecht oder dem nationalen Recht als Verschlusssache eingestufte Informationen.

(2) Die gemäß Absatz 1 an der Anwendung dieser Verordnung beteiligten Behörden fragen nur Daten an, die für die Bewertung des von KI-Systemen ausgehenden Risikos und für die Ausübung ihrer Befugnisse in Übereinstimmung mit dieser Verordnung und mit der Verordnung (EU) 2019/1020 unbedingt erforderlich sind. Sie ergreifen angemessene und wirksame Cybersicherheitsmaßnahmen zum Schutz der Sicherheit und Vertraulichkeit der erlangten Informationen und Daten und löschen im Einklang mit dem geltenden Unionsrecht oder nationalen Recht die erhobenen Daten, sobald sie für den Zweck, für den sie erlangt wurden, nicht mehr benötigt werden.

(3) Unbeschadet der Absätze 1 und 2 darf der Austausch vertraulicher Informationen zwischen den zuständigen nationalen Behörden untereinander oder zwischen den zuständigen nationalen Behörden und der Kommission nicht ohne vorherige Rücksprache mit der zuständigen nationalen Behörde, von der die Informationen stammen, und dem Betreiber offengelegt werden, sofern die in Anhang III Nummer 1, 6 oder 7 genannten Hochrisiko-KI-Systeme von Strafverfolgungs-, Grenzschutz-, Einwanderungs- oder Asylbehörden verwendet werden und eine solche Offenlegung die öffentlichen und nationalen Sicherheitsinteressen gefährden könnte. Dieser Informationsaustausch erstreckt sich nicht auf sensible operative Daten zu den Tätigkeiten von Strafverfolgungs-, Grenzschutz-, Einwanderungs- oder Asylbehörden.

Handeln Strafverfolgungs-, Einwanderungs- oder Asylbehörden als Anbieter von in Anhang III Nummer 1, 6 oder 7 genannten Hochrisiko-KI-Systemen, so verbleibt die technische Dokumentation nach Anhang IV in den Räumlichkeiten dieser Behörden. Diese Behörden sorgen dafür, dass die in Artikel 74 Absätze 8 und 9 genannten Marktüberwachungsbehörden auf Anfrage unverzüglich Zugang zu dieser Dokumentation oder eine Kopie davon erhalten. Zugang zu dieser Dokumentation oder zu einer Kopie davon darf nur das Personal der Marktüberwachungsbehörde erhalten, das über eine entsprechende Sicherheitsfreigabe verfügt.

(4) Die Absätze 1, 2 und 3 dürfen sich weder auf die Rechte oder Pflichten der Kommission, der Mitgliedstaaten und ihrer einschlägigen Behörden sowie der notifizierten Stellen in Bezug auf den Informationsaustausch und die Weitergabe von Warnungen, einschließlich im Rahmen der grenzüberschreitenden Zusammenarbeit, noch auf die Pflichten der betreffenden Parteien auswirken, Informationen auf der Grundlage des Strafrechts der Mitgliedstaaten bereitzustellen.

(5) Die Kommission und die Mitgliedstaaten können erforderlichenfalls und im Einklang mit den einschlägigen Bestimmungen internationaler Übereinkommen und Handelsabkommen mit Regulierungsbehörden von Drittstaaten, mit denen sie bilaterale oder multilaterale Vertraulichkeitsvereinbarungen getroffen haben und die ein angemessenes Niveau an Vertraulichkeit gewährleisten, vertrauliche Informationen austauschen.

<a id="art-79"></a>
### Artikel 79 – Verfahren auf nationaler Ebene für den Umgang mit KI-Systemen, die ein Risiko bergen

(1) Als KI-Systeme, die ein Risiko bergen, gelten „Produkte, mit denen ein Risiko verbunden ist“ im Sinne des Artikels 3 Nummer 19 der Verordnung (EU) 2019/1020, sofern sie Risiken für die Gesundheit oder Sicherheit oder Grundrechte von Personen bergen.

(2) Hat die Marktüberwachungsbehörde eines Mitgliedstaats hinreichend Grund zu der Annahme, dass ein KI-System ein Risiko nach Absatz 1 des vorliegenden Artikels birgt, so prüft sie das betreffende KI-System im Hinblick auf die Erfüllung aller in der vorliegenden Verordnung festgelegten Anforderungen und Pflichten. Besondere Aufmerksamkeit gilt KI-Systemen, die für schutzbedürftige Gruppen ein Risiko bergen. Wenn Risiken für die Grundrechte festgestellt werden, informiert die Marktüberwachungsbehörde auch die in Artikel 77 Absatz 1 genannten einschlägigen nationalen Behörden oder öffentlichen Stellen und arbeitet uneingeschränkt mit ihnen zusammen. Die betreffenden Akteure arbeiten erforderlichenfalls mit der Marktüberwachungsbehörde und den in Artikel 77 Absatz 1 genannten anderen Behörden oder öffentlichen Stellen zusammen.

Stellt die Marktüberwachungsbehörde oder gegebenenfalls die Marktüberwachungsbehörde in Zusammenarbeit mit der in Artikel 77 Absatz 1 genannten nationalen Behörde im Verlauf dieser Prüfung fest, dass das KI-System die in dieser Verordnung festgelegten Anforderungen und Pflichten nicht erfüllt, fordert sie den jeweiligen Akteur unverzüglich auf, alle Korrekturmaßnahmen zu ergreifen, die geeignet sind, die Konformität des KI-Systems herzustellen, das KI-System vom Markt zu nehmen oder es innerhalb einer Frist, die die Marktüberwachungsbehörde vorgeben kann, in jedem Fall innerhalb von weniger als 15 Arbeitstagen, oder gemäß den einschlägigen Harmonisierungsrechtsvorschriften der Union zurückzurufen.

Die Marktüberwachungsbehörde informiert die betreffende notifizierte Stelle entsprechend. Artikel 18 der Verordnung (EU) 2019/1020 gilt für die in Unterabsatz 2 des vorliegenden Absatzes genannten Maßnahmen.

(3) Gelangt die Marktüberwachungsbehörde zu der Auffassung, dass die Nichtkonformität nicht auf ihr nationales Hoheitsgebiet beschränkt ist, so informiert sie die Kommission und die anderen Mitgliedstaaten unverzüglich über die Ergebnisse der Prüfung und über die Maßnahmen, zu denen sie den Akteur aufgefordert hat.

(4) Der Akteur sorgt dafür, dass alle geeigneten Korrekturmaßnahmen in Bezug auf alle betreffenden KI-Systeme, die er auf dem Unionsmarkt bereitgestellt hat, getroffen werden.

(5) Ergreift der Akteur in Bezug auf sein KI-System keine geeigneten Korrekturmaßnahmen innerhalb der in Absatz 2 genannten Frist, trifft die Marktüberwachungsbehörde alle geeigneten vorläufigen Maßnahmen, um die Bereitstellung oder Inbetriebnahme des KI-Systems auf ihrem nationalen Markt zu verbieten oder einzuschränken, das Produkt oder das eigenständige KI-System von diesem Markt zu nehmen oder es zurückzurufen. Diese Behörde notifiziert unverzüglich die Kommission und die anderen Mitgliedstaaten über diese Maßnahmen.

(6) Die Notifizierung nach Absatz 5 enthält alle vorliegenden Angaben, insbesondere die für die Identifizierung des nicht konformen Systems notwendigen Informationen, den Ursprung des KI-Systems und die Lieferkette, die Art der vermuteten Nichtkonformität und das sich daraus ergebende Risiko, die Art und Dauer der ergriffenen nationalen Maßnahmen und die von dem betreffenden Akteur vorgebrachten Argumente. Die Marktüberwachungsbehörden geben insbesondere an, ob die Nichtkonformität eine oder mehrere der folgenden Ursachen hat:

- a) Missachtung des Verbots der in Artikel 5 genannten KI-Praktiken;

- b) Nichterfüllung der in Kapitel III Abschnitt 2 festgelegten Anforderungen durch ein Hochrisiko-KI-System;

- c) Mängel in den in den Artikeln 40 und 41 genannten harmonisierten Normen oder gemeinsamen Spezifikationen, die eine Konformitätsvermutung begründen;

- d) Nichteinhaltung des Artikels 50.

(7) Die anderen Marktüberwachungsbehörden — mit Ausnahme der Marktüberwachungsbehörde des Mitgliedstaats, der das Verfahren eingeleitet hat — informieren unverzüglich die Kommission und die anderen Mitgliedstaaten über jegliche Maßnahmen und ihnen vorliegende zusätzlichen Informationen zur Nichtkonformität des betreffenden KI-Systems sowie — falls sie die ihnen mitgeteilte nationale Maßnahme ablehnen — über ihre Einwände.

(8) Erhebt weder eine Marktüberwachungsbehörde eines Mitgliedstaats noch die Kommission innerhalb von drei Monaten nach Eingang der in Absatz 5 des vorliegenden Artikels genannten Notifizierung Einwände gegen eine von einer Marktüberwachungsbehörde eines anderen Mitgliedstaats erlassene vorläufige Maßnahme, so gilt diese Maßnahme als gerechtfertigt. Die Verfahrensrechte des betreffenden Akteurs nach Artikel 18 der Verordnung (EU) 2019/1020 bleiben hiervon unberührt. Die Frist von drei Monaten gemäß dem vorliegenden Absatz wird bei Nichteinhaltung des Verbots der in Artikel 5 der vorliegenden Verordnung genannten KI-Praktiken auf 30 Tage verkürzt.

(9) Die Marktüberwachungsbehörden tragen dafür Sorge, dass geeignete einschränkende Maßnahmen in Bezug auf das betreffende Produkt oder KI-System ergriffen werden, beispielsweise die unverzügliche Rücknahme des Produkts oder KI-Systems von ihrem Markt.

<a id="art-80"></a>
### Artikel 80 – Verfahren für den Umgang mit KI-Systemen, die vom Anbieter gemäß Anhang III als nicht hochriskant eingestuft werden

(1) Hat eine Marktüberwachungsbehörde hinreichend Grund zu der Annahme, dass ein vom Anbieter als nicht hochriskant gemäß Artikel 6 Absatz 3 eingestuftes KI-System tatsächlich hochriskant ist, so prüft die Marktüberwachungsbehörde das betreffende KI-System im Hinblick auf seine Einstufung als Hochrisiko-KI-System auf der Grundlage der in Artikel 6 Absatz 3 festgelegten Bedingungen und den Leitlinien der Kommission.

(2) Stellt die Marktüberwachungsbehörde im Verlauf dieser Prüfung fest, dass das betreffende KI-System hochriskant ist, fordert sie den jeweiligen Anbieter unverzüglich auf, alle erforderlichen Maßnahmen zu ergreifen, um die Konformität des KI-Systems mit den in dieser Verordnung festgelegten Anforderungen und Pflichten herzustellen, sowie innerhalb einer Frist, die die Marktüberwachungsbehörde vorgeben kann, geeignete Korrekturmaßnahmen zu ergreifen.

(3) Gelangt die Marktüberwachungsbehörde zu der Auffassung, dass die Verwendung des betreffenden KI-Systems nicht auf ihr nationales Hoheitsgebiet beschränkt ist, so informiert sie die Kommission und die anderen Mitgliedstaaten unverzüglich über die Ergebnisse der Prüfung und über die Maßnahmen, zu denen sie den Anbieter aufgefordert hat.

(4) Der Anbieter sorgt dafür, dass alle erforderlichen Maßnahmen ergriffen werden, um die Konformität des KI-Systems mit den in dieser Verordnung festgelegten Anforderungen und Pflichten herzustellen. Stellt der Anbieter eines betroffenen KI-Systems die Konformität des KI-Systems mit diesen Anforderungen und Pflichten nicht innerhalb der in Absatz 2 des vorliegenden Artikels genannten Frist her, so werden gegen den Anbieter Geldbußen gemäß Artikel 99 verhängt.

(5) Der Anbieter sorgt dafür, dass alle geeigneten Korrekturmaßnahmen in Bezug auf alle betreffenden KI-Systeme, die er auf dem Unionsmarkt bereitgestellt hat, getroffen werden.

(6) Ergreift der Anbieter des betreffenden KI-Systems innerhalb der in Absatz 2 des vorliegenden Artikels genannten Frist keine angemessenen Korrekturmaßnahmen, so findet Artikel 79 Absätze 5 bis 9 Anwendung.

(7) Stellt die Marktüberwachungsbehörde im Verlauf der Prüfung gemäß Absatz 1 des vorliegenden Artikels fest, dass das KI-System vom Anbieter fälschlich als nicht hochriskant eingestuft wurde, um die Geltung der Anforderungen von Kapitel III Abschnitt 2 zu umgehen, so werden gegen den Anbieter Geldbußen gemäß Artikel 99 verhängt.

(8) Bei der Ausübung ihrer Befugnis zur Überwachung der Anwendung dieses Artikels können die Marktüberwachungsbehörden im Einklang mit Artikel 11 der Verordnung (EU) 2019/1020 geeignete Überprüfungen durchführen, wobei sie insbesondere Informationen berücksichtigen, die in der EU-Datenbank gemäß Artikel 71 der vorliegenden Verordnung gespeichert sind.

<a id="art-81"></a>
### Artikel 81 – Schutzklauselverfahren der Union

(1) Erhebt eine Marktüberwachungsbehörde eines Mitgliedstaats innerhalb von drei Monaten nach Eingang der in Artikel 79 Absatz 5 genannten Notifizierung — oder bei Nichteinhaltung des Verbots der in Artikel 5 genannten KI-Praktiken innerhalb von 30 Tagen — Einwände gegen eine von der Marktüberwachungsbehörde eines anderen Mitgliedstaats getroffene Maßnahme oder ist die Kommission der Ansicht, dass die Maßnahme mit dem Unionsrecht unvereinbar ist, so nimmt die Kommission unverzüglich Konsultationen mit der Marktüberwachungsbehörde des betreffenden Mitgliedstaats und dem Akteur bzw. den Akteuren auf und prüft die nationale Maßnahme. Anhand der Ergebnisse dieser Prüfung entscheidet die Kommission innerhalb von sechs Monaten — oder bei Nichteinhaltung des Verbots der in Artikel 5 genannten KI-Praktiken innerhalb von 60 Tagen — ab dem Eingang der in Artikel 79 Absatz 5 genannten Notifizierung, ob die nationale Maßnahme gerechtfertigt ist, und teilt der Marktüberwachungsbehörde des betreffenden Mitgliedstaats ihre Entscheidung mit. Die Kommission unterrichtet auch alle übrigen Marktüberwachungsbehörden über ihre Entscheidung.

(2) Ist die Kommission der Ansicht, dass die von dem betreffenden Mitgliedstaat ergriffene Maßnahme gerechtfertigt ist, so tragen alle Mitgliedstaaten dafür Sorge, dass sie geeignete einschränkende Maßnahmen in Bezug auf das betreffende KI-System ergreifen, etwa die Anordnung der unverzüglichen Rücknahme des KI-Systems von ihrem Markt, und informiert die Kommission darüber. Erachtet die Kommission die nationale Maßnahme als nicht gerechtfertigt, nimmt der betreffende Mitgliedstaat die Maßnahme zurück und informiert die Kommission darüber.

(3) Gilt die nationale Maßnahme als gerechtfertigt und wird die Nichtkonformität des KI-Systems auf Mängel in den in den Artikeln 40 und 41 dieser Verordnung genannten harmonisierten Normen oder gemeinsamen Spezifikationen zurückgeführt, so leitet die Kommission das in Artikel 11 der Verordnung (EU) Nr. 1025/2012 festgelegte Verfahren ein.

<a id="art-82"></a>
### Artikel 82 – Konforme KI-Systeme, die ein Risiko bergen

(1) Stellt die Marktüberwachungsbehörde eines Mitgliedstaats — nach einer Konsultation der in Artikel 77 Absatz 1 genannten betreffenden nationalen Behörde — nach der gemäß Artikel 79 durchgeführten Prüfung fest, dass ein Hochrisiko-KI-System zwar dieser Verordnung entspricht, aber dennoch ein Risiko für die Gesundheit oder Sicherheit von Personen, für die Grundrechte oder für andere Aspekte des Schutzes öffentlicher Interessen darstellt, so fordert sie unverzüglich den betreffenden Akteur auf, alle geeigneten Maßnahmen zu treffen, damit das betreffende KI-System zum Zeitpunkt des Inverkehrbringens oder der Inbetriebnahme dieses Risiko nicht mehr birgt, und zwar innerhalb einer Frist, die sie vorgeben kann.

(2) Der Anbieter oder der andere einschlägige Akteur sorgt dafür, dass in Bezug auf alle betroffenen KI-Systeme, die er auf dem Unionsmarkt bereitgestellt hat, innerhalb der Frist, die von der in Absatz 1 genannten Marktüberwachungsbehörde des Mitgliedstaats vorgegeben wurde, Korrekturmaßnahmen ergriffen werden.

(3) Die Mitgliedstaaten unterrichten unverzüglich die Kommission und die anderen Mitgliedstaaten über Feststellungen gemäß Absatz 1. Diese Unterrichtung enthält alle vorliegenden Angaben, insbesondere die für die Identifizierung des betreffenden KI-Systems notwendigen Daten, den Ursprung und die Lieferkette des KI-Systems, die Art des sich daraus ergebenden Risikos sowie die Art und Dauer der ergriffenen nationalen Maßnahmen.

(4) Die Kommission nimmt unverzüglich mit den betreffenden Mitgliedstaaten und den jeweiligen Akteuren Konsultationen auf und prüft die ergriffenen nationalen Maßnahmen. Anhand der Ergebnisse dieser Prüfung entscheidet die Kommission, ob die Maßnahme gerechtfertigt ist, und schlägt, falls erforderlich, weitere geeignete Maßnahmen vor.

(5) Die Kommission teilt ihren Beschluss unverzüglich den betroffenen Mitgliedstaaten und den jeweiligen Akteuren mit. Sie unterrichtet auch die übrigen Mitgliedstaaten.

<a id="art-83"></a>
### Artikel 83 – Formale Nichtkonformität

(1) Wenn die Marktüberwachungsbehörde eines Mitgliedstaats eine der folgenden Nichtkonformitäten feststellt, fordert sie den jeweiligen Anbieter auf, diese binnen einer Frist, die sie vorgeben kann, zu beheben:

- a) die CE-Kennzeichnung wurde unter Verstoß gegen Artikel 48 angebracht;

- b) es wurde keine CE-Kennzeichnung angebracht;

- c) es wurde keine EU-Konformitätserklärung gemäß Artikel 47 ausgestellt;

- d) es wurde keine EU-Konformitätserklärung gemäß Artikel 47 ordnungsgemäß ausgestellt;

- e) es wurde keine Registrierung in der EU-Datenbank gemäß Artikel 71 vorgenommen;

- f) es wurde kein Bevollmächtigter — sofern erforderlich — ernannt;

- g) es ist keine technische Dokumentation verfügbar.

(2) Besteht die Nichtkonformität nach Absatz 1 weiter, so ergreift die Marktüberwachungsbehörde des betreffenden Mitgliedstaats geeignete und verhältnismäßige Maßnahmen, um die Bereitstellung des Hochrisiko-KI-Systems auf dem Markt zu beschränken oder zu verbieten oder um dafür zu sorgen, dass es unverzüglich zurückgerufen oder vom Markt genommen wird.

<a id="art-84"></a>
### Artikel 84 – Unionsstrukturen zur Unterstützung der Prüfung von KI

(1) Die Kommission benennt eine oder mehrere Unionsstrukturen zur Unterstützung der Prüfung von KI, die die Aufgaben gemäß Artikel 21 Absatz 6 der Verordnung (EU) 2019/1020 im KI-Bereich wahrnehmen.

(2) Unbeschadet der in Absatz 1 genannten Aufgaben leisten die Unionsstrukturen zur Unterstützung der Prüfung von KI auf Anfrage des KI-Gremiums, der Kommission oder der Marktüberwachungsbehörden auch unabhängige technische oder wissenschaftliche Beratung.

<a id="chapter-ix-section-4"></a>
## Abschnitt 4 – Rechtsbehelfe

<a id="art-85"></a>
### Artikel 85 – Recht auf Beschwerde bei einer Marktüberwachungsbehörde

Unbeschadet anderer verwaltungsrechtlicher oder gerichtlicher Rechtsbehelfe kann jede natürliche oder juristische Person, die Grund zu der Annahme hat, dass gegen die Bestimmungen dieser Verordnung verstoßen wurde, bei der betreffenden Marktüberwachungsbehörde Beschwerden einreichen.

Gemäß der Verordnung (EU) 2019/1020 werden solche Beschwerden für die Zwecke der Durchführung von Marktüberwachungstätigkeiten berücksichtigt und nach den einschlägigen von den Marktüberwachungsbehörden dafür eingerichteten Verfahren behandelt.

<a id="art-86"></a>
### Artikel 86 – Recht auf Erläuterung der Entscheidungsfindung im Einzelfall

(1) Personen, die von einer Entscheidung betroffen sind, die der Betreiber auf der Grundlage der Ausgaben eines in Anhang III aufgeführten Hochrisiko-KI-Systems, mit Ausnahme der in Nummer 2 des genannten Anhangs aufgeführten Systeme, getroffen hat und die rechtliche Auswirkungen hat oder sie in ähnlicher Art erheblich auf eine Weise beeinträchtigt, die ihrer Ansicht nach ihre Gesundheit, ihre Sicherheit oder ihre Grundrechte beeinträchtigt, haben das Recht, vom Betreiber eine klare und aussagekräftige Erläuterung zur Rolle des KI-Systems im Entscheidungsprozess und zu den wichtigsten Elementen der getroffenen Entscheidung zu erhalten.

(2) Absatz 1 gilt nicht für die Verwendung von KI-Systemen, bei denen sich Ausnahmen von oder Beschränkungen der Pflicht nach dem genannten Absatz aus dem Unionsrecht oder dem nationalen Recht im Einklang mit dem Unionsrecht ergeben.

(3) Dieser Artikel gilt nur insoweit, als das Recht gemäß Absatz 1 nicht anderweitig im Unionsrecht festgelegt ist.

<a id="art-87"></a>
### Artikel 87 – Meldung von Verstößen und Schutz von Hinweisgebern

Für die Meldung von Verstößen gegen diese Verordnung und den Schutz von Personen, die solche Verstöße melden, gilt die Richtlinie (EU) 2019/1937.

<a id="chapter-ix-section-5"></a>
## Abschnitt 5 – Aufsicht, Ermittlung, Durchsetzung und Überwachung in Bezug auf Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

<a id="art-88"></a>
### Artikel 88 – Durchsetzung der Pflichten der Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

(1) Die Kommission verfügt unter Berücksichtigung der Verfahrensgarantien nach Artikel 94 über ausschließliche Befugnisse zur Beaufsichtigung und Durchsetzung von Kapitel V. Unbeschadet der Organisationsbefugnisse der Kommission und der Aufteilung der Zuständigkeiten zwischen den Mitgliedstaaten und der Union auf der Grundlage der Verträge überträgt die Kommission dem Büro für Künstliche Intelligenz die Durchführung dieser Aufgaben.

(2) Unbeschadet des Artikels 75 Absatz 3 können die Marktüberwachungsbehörden die Kommission ersuchen, die in diesem Abschnitt festgelegten Befugnisse auszuüben, wenn es erforderlich und verhältnismäßig ist, um die Wahrnehmung ihrer Aufgaben gemäß dieser Verordnung zu unterstützen.

<a id="art-89"></a>
### Artikel 89 – Überwachungsmaßnahmen

(1) Zur Wahrnehmung der ihr in diesem Abschnitt übertragenen Aufgaben kann das Büro für Künstliche Intelligenz die erforderlichen Maßnahmen ergreifen, um die wirksame Umsetzung und Einhaltung dieser Verordnung durch Anbieter von KI-Modellen mit allgemeinem Verwendungszweck, einschließlich der Einhaltung genehmigter Praxisleitfäden, zu überwachen.

(2) Nachgelagerte Anbieter haben das Recht, eine Beschwerde wegen eines Verstoßes gegen diese Verordnung einzureichen. Eine Beschwerde ist hinreichend zu begründen und enthält mindestens Folgendes:

- a) die Kontaktstelle des Anbieters des betreffenden KI-Modells mit allgemeinem Verwendungszweck;

- b) eine Beschreibung der einschlägigen Fakten, die betreffenden Bestimmungen dieser Verordnung und die Begründung, warum der nachgelagerte Anbieter der Auffassung ist, dass der Anbieter des KI-Modells mit allgemeinem Verwendungszweck gegen diese Verordnung verstoßen hat;

- c) alle sonstigen Informationen, die der nachgelagerte Anbieter, der die Anfrage übermittelt hat, für relevant hält, gegebenenfalls einschließlich Informationen, die er auf eigene Initiative hin zusammengetragen hat.

<a id="art-90"></a>
### Artikel 90 – Warnungen des wissenschaftlichen Gremiums vor systemischen Risiken

(1) Das wissenschaftliche Gremium kann dem Büro für Künstliche Intelligenz eine qualifizierte Warnung übermitteln, wenn es Grund zu der Annahme hat, dass

- a) ein KI-Modell mit allgemeinem Verwendungszweck ein konkretes, identifizierbares Risiko auf Unionsebene birgt oder

- b) ein KI-Modell mit allgemeinem Verwendungszweck die Bedingungen gemäß Artikel 51 erfüllt.

(2) Aufgrund einer solchen qualifizierten Warnung kann die Kommission über das Büro für Künstliche Intelligenz und nach Unterrichtung des KI-Gremiums die in diesem Abschnitt festgelegten Befugnisse zur Beurteilung der Angelegenheit ausüben. Das Büro für Künstliche Intelligenz unterrichtet das KI-Gremium über jede Maßnahme gemäß den Artikeln 91 bis 94.

(3) Eine qualifizierte Warnung ist hinreichend zu begründen und enthält mindestens Folgendes:

- a) die Kontaktstelle des Anbieters des betreffenden KI-Modells mit allgemeinem Verwendungszweck mit systemischem Risiko;

- b) eine Beschreibung der einschlägigen Fakten und der Gründe für die Warnung durch das wissenschaftliche Gremium;

- c) alle sonstigen Informationen, die das wissenschaftliche Gremium für relevant hält, gegebenenfalls einschließlich Informationen, die es auf eigene Initiative hin zusammengetragen hat.

<a id="art-91"></a>
### Artikel 91 – Befugnis zur Anforderung von Dokumentation und Informationen

(1) Die Kommission kann den Anbieter des betreffenden KI-Modells mit allgemeinem Verwendungszweck auffordern, die vom Anbieter gemäß den Artikeln 53 und 55 erstellte Dokumentation oder alle zusätzlichen Informationen vorzulegen, die erforderlich sind, um die Einhaltung dieser Verordnung durch den Anbieter zu beurteilen.

(2) Vor der Übermittlung des Informationsersuchens kann das Büro für Künstliche Intelligenz einen strukturierten Dialog mit dem Anbieter des KI-Modells mit allgemeinem Verwendungszweck einleiten.

(3) Auf hinreichend begründeten Antrag des wissenschaftlichen Gremiums kann die Kommission ein Informationsersuchen an einen Anbieter eines KI-Modells mit allgemeinem Verwendungszweck richten, wenn der Zugang zu Informationen für die Wahrnehmung der Aufgaben des wissenschaftlichen Gremiums gemäß Artikel 68 Absatz 2 erforderlich und verhältnismäßig ist.

(4) In dem Auskunftsersuchen sind die Rechtsgrundlage und der Zweck des Ersuchens zu nennen, anzugeben, welche Informationen benötigt werden, eine Frist für die Übermittlung der Informationen zu setzen, und die Geldbußen für die Erteilung unrichtiger, unvollständiger oder irreführender Informationen gemäß Artikel 101 anzugeben.

(5) Der Anbieter des betreffenden KI-Modells mit allgemeinem Verwendungszweck oder sein Vertreter stellt die angeforderten Informationen bereit. Im Falle juristischer Personen, Gesellschaften oder — wenn der Anbieter keine Rechtspersönlichkeit besitzt — die Personen, die nach Gesetz oder Satzung zur Vertretung dieser Personen befugt sind, stellen die angeforderten Informationen im Namen des Anbieters des betreffenden KI-Modells mit allgemeinem Verwendungszweck zur Verfügung. Ordnungsgemäß bevollmächtigte Rechtsanwälte können Informationen im Namen ihrer Mandanten erteilen. Die Mandanten bleiben jedoch in vollem Umfang dafür verantwortlich, dass die erteilten Auskünfte vollständig, sachlich richtig oder nicht irreführend sind.

<a id="art-92"></a>
### Artikel 92 – Befugnis zur Durchführung von Bewertungen

(1) Das Büro für Künstliche Intelligenz kann nach Konsultation des KI-Gremiums Bewertungen des betreffenden KI-Modells mit allgemeinem Verwendungszweck durchführen, um

- a) die Einhaltung der Pflichten aus dieser Verordnung durch den Anbieter zu beurteilen, wenn die gemäß Artikel 91 eingeholten Informationen unzureichend sind, oder

- b) systemische Risiken auf Unionsebene von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko zu ermitteln, insbesondere im Anschluss an eine qualifizierte Warnung des wissenschaftlichen Gremiums gemäß Artikel 90 Absatz 1 Buchstabe a.

(2) Die Kommission kann beschließen, unabhängige Sachverständige zu benennen, die in ihrem Namen Bewertungen durchführen, einschließlich aus dem gemäß Artikel 68 eingesetzten wissenschaftlichen Gremium. Die für diese Aufgabe benannten unabhängigen Sachverständigen erfüllen die in Artikel 68 Absatz 2 umrissenen Kriterien.

(3) Für die Zwecke des Absatzes 1 kann die Kommission über API oder weitere geeignete technische Mittel und Instrumente, einschließlich Quellcode, Zugang zu dem betreffenden KI-Modell mit allgemeinem Verwendungszweck anfordern.

(4) In der Anforderung des Zugangs sind die Rechtsgrundlage, der Zweck und die Gründe für die Anforderung zu nennen und die Frist für die Bereitstellung des Zugangs zu setzen und die Geldbußen gemäß Artikel 101 für den Fall, dass der Zugang nicht bereitgestellt wird, anzugeben.

(5) Die Anbieter des betreffenden KI-Modells mit allgemeinem Verwendungszweck oder seine Vertreter stellen die angeforderten Informationen zur Verfügung. Im Falle juristischer Personen, Gesellschaften oder — wenn der Anbieter keine Rechtspersönlichkeit besitzt — die Personen, die nach Gesetz oder ihrer Satzung zur Vertretung dieser Personen befugt sind, stellen den angeforderten Zugang im Namen des Anbieters des betreffenden KI-Modells mit allgemeinem Verwendungszweck zur Verfügung.

(6) Die Kommission erlässt Durchführungsrechtsakte, in denen die detaillierten Regelungen und Voraussetzungen für die Bewertungen, einschließlich der detaillierten Regelungen für die Einbeziehung unabhängiger Sachverständiger, und das Verfahren für deren Auswahl festgelegt werden. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

(7) Bevor es den Zugang zu dem betreffenden KI-Modell mit allgemeinem Verwendungszweck anfordert, kann das Büro für Künstliche Intelligenz einen strukturierten Dialog mit dem Anbieter des KI-Modells mit allgemeinem Verwendungszweck einleiten, um mehr Informationen über die interne Erprobung des Modells, interne Vorkehrungen zur Vermeidung systemischer Risiken und andere interne Verfahren und Maßnahmen, die der Anbieter zur Minderung dieser Risiken ergriffen hat, einzuholen.

<a id="art-93"></a>
### Artikel 93 – Befugnis zur Aufforderung zu Maßnahmen

(1) Soweit erforderlich und angemessen, kann die Kommission die Anbieter auffordern,

- a) geeignete Maßnahmen zu ergreifen, um die Verpflichtungen gemäß den Artikeln 53 und 54 einzuhalten;

- b) Risikominderungsmaßnahmen durchzuführen, wenn die gemäß Artikel 92 durchgeführte Bewertung zu ernsthaften und begründeten Bedenken hinsichtlich eines systemischen Risikos auf Unionsebene geführt hat;

- c) die Bereitstellung des Modells auf dem Markt einzuschränken, es zurückzunehmen oder zurückzurufen.

(2) Vor der Aufforderung zu einer Maßnahme kann das Büro für Künstliche Intelligenz einen strukturierten Dialog mit dem Anbieter des KI-Modells mit allgemeinem Verwendungszweck einleiten.

(3) Wenn der Anbieter des KI-Modells mit allgemeinem Verwendungszweck im Rahmen des strukturierten Dialogs gemäß Absatz 2 Verpflichtungszusagen zur Durchführung von Risikominderungsmaßnahmen, um einem systemischen Risiko auf Unionsebene zu begegnen, anbietet, kann die Kommission diese Verpflichtungszusagen durch einen Beschluss für bindend erklären und feststellen, dass es keinen weiteren Anlass zum Handeln gibt.

<a id="art-94"></a>
### Artikel 94 – Verfahrensrechte der Wirtschaftsakteure des KI-Modells mit allgemeinem Verwendungszweck

Unbeschadet der in dieser Verordnung enthaltenen spezifischeren Verfahrensrechte gilt für die Anbieter des KI-Modells mit allgemeinem Verwendungszweck Artikel 18 der Verordnung (EU) 2019/1020 sinngemäß.

<a id="chapter-x"></a>
## Kapitel X – VERHALTENSKODIZES UND LEITLINIEN

<a id="art-95"></a>
### Artikel 95 – Verhaltenskodizes für die freiwillige Anwendung bestimmter Anforderungen

(1) Das Büro für Künstliche Intelligenz und die Mitgliedstaaten fördern und erleichtern die Aufstellung von Verhaltenskodizes, einschließlich damit zusammenhängender Governance-Mechanismen, mit denen die freiwillige Anwendung einiger oder aller der in Kapitel III Abschnitt 2 genannten Anforderungen auf KI-Systeme, die kein hohes Risiko bergen, gefördert werden soll, wobei den verfügbaren technischen Lösungen und bewährten Verfahren der Branche, die die Anwendung dieser Anforderungen ermöglichen, Rechnung zu tragen ist.

(2) Das Büro für Künstliche Intelligenz und die Mitgliedstaaten erleichtern die Aufstellung von Verhaltenskodizes in Bezug auf die freiwillige Anwendung spezifischer Anforderungen auf alle KI-Systeme, einschließlich durch Betreiber, auf der Grundlage klarer Zielsetzungen sowie wesentlicher Leistungsindikatoren zur Messung der Erfüllung dieser Zielsetzungen, einschließlich unter anderem folgender Elemente:

- a) in den Ethik-Leitlinien der Union für eine vertrauenswürdige KI enthaltene anwendbare Elemente;

- b) Beurteilung und Minimierung der Auswirkungen von KI-Systemen auf die ökologische Nachhaltigkeit, einschließlich im Hinblick auf energieeffizientes Programmieren, und Techniken, um KI effizient zu gestalten, zu trainieren und zu nutzen;

- c) Förderung der KI-Kompetenz, insbesondere der von Personen, die mit der Entwicklung, dem Betrieb und der Nutzung von KI befasst sind;

- d) Erleichterung einer inklusiven und vielfältigen Gestaltung von KI-Systemen, unter anderem durch die Einsetzung inklusiver und vielfältiger Entwicklungsteams und die Förderung der Beteiligung der Interessenträger an diesem Prozess;

- e) Bewertung und Verhinderung der negativen Auswirkungen von KI-Systemen auf schutzbedürftige Personen oder Gruppen schutzbedürftiger Personen, einschließlich im Hinblick auf die Barrierefreiheit für Personen mit Behinderungen, sowie auf die Gleichstellung der Geschlechter.

(3) Verhaltenskodizes können von einzelnen KI-System-Anbietern oder -Betreibern oder von Interessenvertretungen dieser Anbieter oder Betreiber oder von beiden aufgestellt werden, auch unter Einbeziehung von Interessenträgern sowie deren Interessenvertretungen einschließlich Organisationen der Zivilgesellschaft und Hochschulen. Verhaltenskodizes können sich auf ein oder mehrere KI-Systeme erstrecken, um ähnlichen Zweckbestimmungen der jeweiligen Systeme Rechnung zu tragen.

▼M1

(4) Das Büro für Künstliche Intelligenz und die Mitgliedstaaten berücksichtigen die besonderen Interessen und Bedürfnisse von KMU, einschließlich Startups, und von kleinen Midcap-Unternehmen bei der Förderung und Erleichterung der Aufstellung von Verhaltenskodizes.

▼B

<a id="art-96"></a>
### Artikel 96 – Leitlinien der Kommission zur Durchführung dieser Verordnung

(1) Die Kommission erarbeitet Leitlinien für die praktische Umsetzung dieser Verordnung, die sich insbesondere auf Folgendes beziehen:

▼M1

- a) die Anwendung der in den Artikeln 8 bis 15 und in den Artikeln 25 und 26 genannten Anforderungen und Pflichten;

▼B

- b) die in Artikel 5 genannten verbotenen Praktiken;

- c) die praktische Durchführung der Bestimmungen über wesentliche Veränderungen;

- d) die praktische Umsetzung der Transparenzpflichten gemäß Artikel 50;

- e) detaillierte Informationen über das Verhältnis dieser Verordnung zu den in Anhang I aufgeführten Harmonisierungsrechtsvorschriften der Union sowie zu anderen einschlägigen Rechtsvorschriften der Union, auch in Bezug auf deren kohärente Durchsetzung;

- f) die Anwendung der Definition eines KI-Systems gemäß Artikel 3 Nummer 1;

▼M1

- g) die praktische Umsetzung von Artikel 8 Absatz 2, Artikel 9 Absatz 10 und Artikel 17 Absatz 3 im Einklang mit dem Grundsatz der Komplementarität und Verhältnismäßigkeit mit Blick darauf, Kohärenz zu gewährleisten, Doppelarbeit zu vermeiden und den zusätzlichen Aufwand bei der Erfüllung der Anforderungen dieser Verordnung und der Anforderungen der in Anhang I Abschnitt A aufgeführten Harmonisierungsrechtsvorschriften der Union so gering wie möglich zu halten; diese Leitlinien werden bis zum 1. August 2027 veröffentlicht.

▼M1

Wenn die Kommission solche Leitlinien herausgibt, bezieht sie das KI-Gremium ein und widmet den Bedürfnissen von KMU, einschließlich Start-up-Unternehmen, und von kleinen Midcap-Unternehmen, von lokalen Behörden und von den am wahrscheinlichsten von dieser Verordnung betroffenen Sektoren besondere Aufmerksamkeit.

▼B

Die Leitlinien gemäß Unterabsatz 1 dieses Absatzes tragen dem allgemein anerkannten Stand der Technik im Bereich KI sowie den einschlägigen harmonisierten Normen und gemeinsamen Spezifikationen, auf die in den Artikeln 40 und 41 Bezug genommen wird, oder den harmonisierten Normen oder technischen Spezifikationen, die gemäß den Harmonisierungsrechtsvorschriften der Union festgelegt wurden, gebührend Rechnung.

(2) Auf Ersuchen der Mitgliedstaaten oder des Büros für Künstliche Intelligenz oder von sich aus aktualisiert die Kommission früher verabschiedete Leitlinien, wenn es als notwendig erachtet wird.

<a id="chapter-xi"></a>
## Kapitel XI – BEFUGNISÜBERTRAGUNG UND AUSSCHUSSVERFAHREN

<a id="art-97"></a>
### Artikel 97 – Ausübung der Befugnisübertragung

(1) Die Befugnis zum Erlass delegierter Rechtsakte wird der Kommission unter den in diesem Artikel festgelegten Bedingungen übertragen.

▼M1

(2) Die in Artikel 6 Absätze 6 und 7, Artikel 7 Absätze 1 und 3, Artikel 11 Absatz 3, Artikel 43 Absätze 5 und 6, Artikel 47 Absatz 5, Artikel 51 Absatz 3, Artikel 52 Absatz 4 sowie Artikel 53 Absätze 5 und 6 genannte Befugnis zum Erlass delegierter Rechtsakte wird der Kommission für einen Zeitraum von fünf Jahren ab 1. August 2024 übertragen. Die in Artikel 2 Absatz 13 und Artikel 30 Absatz 2 genannte Befugnis zum Erlass delegierter Rechtsakte wird der Kommission für einen Zeitraum von fünf Jahren ab 27. Juli 2026 übertragen. Die Kommission erstellt spätestens neun Monate vor Ablauf des Zeitraums von fünf Jahren einen Bericht über die Befugnisübertragung. Die Befugnisübertragung verlängert sich stillschweigend um Zeiträume gleicher Länge, es sei denn, das Europäische Parlament oder der Rat widersprechen einer solchen Verlängerung spätestens drei Monate vor Ablauf des jeweiligen Zeitraums.

(3) Die Befugnisübertragung gemäß Artikel 2 Absatz 13, Artikel 6 Absätze 6 und 7, Artikel 7 Absätze 1 und 3, Artikel 11 Absatz 3, Artikel 30 Absatz 2, Artikel 43 Absätze 5 und 6, Artikel 47 Absatz 5, Artikel 51 Absatz 3, Artikel 52 Absatz 4 sowie Artikel 53 Absätze 5 und 6 kann vom Europäischen Parlament oder vom Rat jederzeit widerrufen werden. Der Beschluss über den Widerruf beendet die Übertragung der in jenem Beschluss angegebenen Befugnis. Er wird am Tag nach seiner Veröffentlichung im Amtsblatt der Europäischen Union oder zu einem darin angegebenen späteren Zeitpunkt wirksam. Die Gültigkeit von delegierten Rechtsakten, die bereits in Kraft sind, wird von dem Beschluss über den Widerruf nicht berührt.

▼B

(4) Vor dem Erlass eines delegierten Rechtsakts konsultiert die Kommission die von den einzelnen Mitgliedstaaten benannten Sachverständigen im Einklang mit den in der Interinstitutionellen Vereinbarung vom 13. April 2016 über bessere Rechtsetzung niedergelegten Grundsätzen.

(5) Sobald die Kommission einen delegierten Rechtsakt erlässt, übermittelt sie ihn gleichzeitig dem Europäischen Parlament und dem Rat.

▼M1

(6) Ein delegierter Rechtsakt, der nach Artikel 2 Absatz 13, Artikel 6 Absatz 6 oder 7, Artikel 7 Absatz 1 oder 3, Artikel 11 Absatz 3, Artikel 30 Absatz 2, Artikel 43 Absatz 5 oder 6, Artikel 47 Absatz 5, Artikel 51 Absatz 3, Artikel 52 Absatz 4 sowie Artikel 53 Absatz 5 oder 6 erlassen wurde, tritt nur in Kraft, wenn weder das Europäische Parlament noch der Rat innerhalb einer Frist von drei Monaten nach Übermittlung jenes Rechtsakts an das Europäische Parlament und den Rat Einwände erhoben haben oder wenn vor Ablauf dieser Frist das Europäische Parlament und der Rat beide der Kommission mitgeteilt haben, dass sie keine Einwände erheben werden. Auf Initiative des Europäischen Parlaments oder des Rates wird diese Frist um drei Monate verlängert.

▼B

<a id="art-98"></a>
### Artikel 98 – Ausschussverfahren

(1) Die Kommission wird von einem Ausschuss unterstützt. Dieser Ausschuss ist ein Ausschuss im Sinne der Verordnung (EU) Nr. 182/2011.

(2) Wird auf diesen Absatz Bezug genommen, so gilt Artikel 5 der Verordnung (EU) Nr. 182/2011.

<a id="chapter-xii"></a>
## Kapitel XII – SANKTIONEN

<a id="art-99"></a>
### Artikel 99 – Sanktionen

▼M1

(1) Entsprechend den Vorgaben dieser Verordnung erlassen die Mitgliedstaaten Vorschriften für Sanktionen und andere Durchsetzungsmaßnahmen, zu denen auch Geldbußen, Verwarnungen und nichtmonetäre Maßnahmen gehören können, die bei jeglichem Verstoß gegen diese Verordnung durch Akteure Anwendung finden, und ergreifen alle Maßnahmen, die für deren ordnungsgemäße und wirksame Durchsetzung notwendig sind, wobei die von der Kommission gemäß Artikel 96 erteilten Leitlinien zu berücksichtigen sind. Die vorgesehenen Sanktionen müssen wirksam, verhältnismäßig und abschreckend sein. Die Mitgliedstaaten berücksichtigen bei der Verhängung von Sanktionen die Interessen von KMU, einschließlich Start-up-Unternehmen, und von kleinen Midcap-Unternehmen sowie deren wirtschaftliches Überleben.

▼B

(2) Die Mitgliedstaaten teilen der Kommission die Vorschriften für Sanktionen und andere Durchsetzungsmaßnahmen gemäß Absatz 1 unverzüglich und spätestens zum Zeitpunkt ihres Inkrafttretens mit und melden ihr unverzüglich etwaige spätere Änderungen.

(3) Bei Missachtung des Verbots der in Artikel 5 genannten KI-Praktiken werden Geldbußen von bis zu 35 000 000 EUR oder — im Falle von Unternehmen — von bis zu 7 % des gesamten weltweiten Jahresumsatzes des vorangegangenen Geschäftsjahres verhängt, je nachdem, welcher Betrag höher ist.

(4) Für Verstöße gegen folgende für Akteure oder notifizierte Stellen geltende Bestimmungen, mit Ausnahme der in Artikel 5 genannten, werden Geldbußen von bis zu 15 000 000 EUR oder — im Falle von Unternehmen — von bis zu 3 % des gesamten weltweiten Jahresumsatzes des vorangegangenen Geschäftsjahres verhängt, je nachdem, welcher Betrag höher ist:

- a) Pflichten der Anbieter gemäß Artikel 16;

- b) Pflichten der Bevollmächtigten gemäß Artikel 22;

- c) Pflichten der Einführer gemäß Artikel 23;

- d) Pflichten der Händler gemäß Artikel 24;

▼M1

- da) Pflichten der Anbieter und Akteure gemäß Artikel 25 Absätze 2 und 4;

▼B

- e) Pflichten der Betreiber gemäß Artikel 26;

- f) für notifizierte Stellen geltende Anforderungen und Pflichten gemäß Artikel 31, Artikel 33 Absätze 1, 3 und 4 bzw. Artikel 34;

- g) Transparenzpflichten für Anbieter und Betreiber gemäß Artikel 50.

(5) Werden notifizierten Stellen oder zuständigen nationalen Behörden auf deren Auskunftsersuchen hin falsche, unvollständige oder irreführende Informationen bereitgestellt, so werden Geldbußen von bis zu 7 500 000 EUR oder — im Falle von Unternehmen — von bis zu 1 % des gesamten weltweiten Jahresumsatzes des vorangegangenen Geschäftsjahres verhängt, je nachdem, welcher Betrag höher ist.

(6) Im Falle von KMU, einschließlich Start-up-Unternehmen, gilt für jede in diesem Artikel genannte Geldbuße der jeweils niedrigere Betrag aus den in den Absätzen 3, 4 und 5 genannten Prozentsätzen oder Summen.

▼M1

(6a) Im Falle von kleinen Midcap-Unternehmen gilt für jede in den Absätzen 4 und 5 genannte Geldbuße der jeweils niedrigere Betrag aus den darin genannten Prozentsätzen oder Summen.

▼B

(7) Bei der Entscheidung, ob eine Geldbuße verhängt wird, und bei der Festsetzung der Höhe der Geldbuße werden in jedem Einzelfall alle relevanten Umstände der konkreten Situation sowie gegebenenfalls Folgendes berücksichtigt:

- a) Art, Schwere und Dauer des Verstoßes und seiner Folgen, unter Berücksichtigung des Zwecks des KI-Systems sowie gegebenenfalls der Zahl der betroffenen Personen und des Ausmaßes des von ihnen erlittenen Schadens;

- b) ob demselben Akteur bereits von anderen Marktüberwachungsbehörden für denselben Verstoß Geldbußen auferlegt wurden;

- c) ob demselben Akteur bereits von anderen Behörden für Verstöße gegen das Unionsrecht oder das nationale Recht Geldbußen auferlegt wurden, wenn diese Verstöße auf dieselbe Handlung oder Unterlassung zurückzuführen sind, die einen einschlägigen Verstoß gegen diese Verordnung darstellt;

- d) Größe, Jahresumsatz und Marktanteil des Akteurs, der den Verstoß begangen hat;

- e) jegliche anderen erschwerenden oder mildernden Umstände im jeweiligen Fall, wie etwa unmittelbar oder mittelbar durch den Verstoß erlangte finanzielle Vorteile oder vermiedene Verluste;

- f) Grad der Zusammenarbeit mit den zuständigen nationalen Behörden, um den Verstoß abzustellen und die möglichen nachteiligen Auswirkungen des Verstoßes abzumildern;

- g) Grad an Verantwortung des Akteurs unter Berücksichtigung der von ihm ergriffenen technischen und organisatorischen Maßnahmen;

- h) Art und Weise, wie der Verstoß den zuständigen nationalen Behörden bekannt wurde, insbesondere ob und gegebenenfalls in welchem Umfang der Akteur den Verstoß gemeldet hat;

- i) Vorsätzlichkeit oder Fahrlässigkeit des Verstoßes;

- j) alle Maßnahmen, die der Akteur ergriffen hat, um den Schaden, der den betroffenen Personen zugefügt wird, zu mindern.

(8) Jeder Mitgliedstaat erlässt Vorschriften darüber, in welchem Umfang gegen Behörden und öffentliche Stellen, die in dem betreffenden Mitgliedstaat niedergelassen sind, Geldbußen verhängt werden können.

(9) In Abhängigkeit vom Rechtssystem der Mitgliedstaaten können die Vorschriften über Geldbußen je nach den dort geltenden Regeln so angewandt werden, dass die Geldbußen von den zuständigen nationalen Gerichten oder von sonstigen Stellen verhängt werden. Die Anwendung dieser Vorschriften in diesen Mitgliedstaaten muss eine gleichwertige Wirkung haben.

(10) Die Ausübung der Befugnisse gemäß diesem Artikel muss angemessenen Verfahrensgarantien gemäß dem Unionsrecht und dem nationalen Recht, einschließlich wirksamer gerichtlicher Rechtsbehelfe und ordnungsgemäßer Verfahren, unterliegen.

(11) Die Mitgliedstaaten erstatten der Kommission jährlich Bericht über die Geldbußen, die sie in dem betreffenden Jahr gemäß diesem Artikel verhängt haben, und über damit zusammenhängende Rechtsstreitigkeiten oder Gerichtsverfahren.

<a id="art-100"></a>
### Artikel 100 – Verhängung von Geldbußen gegen Organe, Einrichtungen und sonstige Stellen der Union

(1) Der Europäische Datenschutzbeauftragte kann gegen Organe, Einrichtungen und sonstige Stellen der Union, die in den Anwendungsbereich dieser Verordnung fallen, Geldbußen verhängen. Bei der Entscheidung, ob eine Geldbuße verhängt wird, und bei der Festsetzung der Höhe der Geldbuße werden in jedem Einzelfall alle relevanten Umstände der konkreten Situation sowie Folgendes gebührend berücksichtigt:

- a) Art, Schwere und Dauer des Verstoßes und dessen Folgen, unter Berücksichtigung des Zwecks des betreffenden KI-Systems sowie gegebenenfalls der Zahl der betroffenen Personen und des Ausmaßes des von ihnen erlittenen Schadens;

- b) Grad der Verantwortung des Organs, der Einrichtung oder der sonstigen Stelle der Union unter Berücksichtigung der von diesem bzw. dieser ergriffenen technischen und organisatorischen Maßnahmen;

- c) alle Maßnahmen, die das Organ, die Einrichtung oder die sonstige Stelle der Union zur Minderung des von den betroffenen Personen erlittenen Schadens ergriffen hat;

- d) das Maß der Zusammenarbeit mit dem Europäischen Datenschutzbeauftragten bei der Behebung des Verstoßes und der Minderung seiner möglichen nachteiligen Auswirkungen, einschließlich der Befolgung von Maßnahmen, die der Europäische Datenschutzbeauftragte dem Organ, der Einrichtung oder der sonstigen Stelle der Union im Hinblick auf denselben Gegenstand zuvor bereits auferlegt hatte;

- e) ähnliche frühere Verstöße des Organs, der Einrichtung oder der sonstigen Stelle der Union;

- f) Art und Weise, wie der Verstoß dem Europäischen Datenschutzbeauftragten bekannt wurde, insbesondere ob und gegebenenfalls in welchem Umfang das Organ, die Einrichtung oder die sonstige Stelle der Union den Verstoß gemeldet hat;

- g) der Jahreshaushalt des Organs, der Einrichtung oder der sonstigen Stelle der Union.

(2) Bei Missachtung des Verbots der in Artikel 5 genannten KI-Praktiken werden Geldbußen von bis zu 1 500 000 EUR verhängt.

(3) Bei Nichtkonformität des KI-Systems mit in dieser Verordnung festgelegten Anforderungen oder Pflichten, mit Ausnahme der in Artikel 5 festgelegten, werden Geldbußen von bis zu 750 000 EUR verhängt.

(4) Bevor der Europäische Datenschutzbeauftragte Entscheidungen nach dem vorliegenden Artikel trifft, gibt er dem Organ, der Einrichtung oder der sonstigen Stelle der Union, gegen das bzw. die sich das von ihm geführte Verfahren richtet, Gelegenheit, sich zum Vorwurf des Verstoßes zu äußern. Der Europäische Datenschutzbeauftragte stützt seine Entscheidungen nur auf die Elemente und Umstände, zu denen sich die betreffenden Parteien äußern können. Beschwerdeführer, soweit vorhanden, müssen in das Verfahren eng einbezogen werden.

(5) Die Verteidigungsrechte der betroffenen Parteien werden während des Verfahrens in vollem Umfang gewahrt. Vorbehaltlich der legitimen Interessen von Einzelpersonen oder Unternehmen im Hinblick auf den Schutz ihrer personenbezogenen Daten oder Geschäftsgeheimnisse haben die betroffenen Parteien Anspruch auf Einsicht in die Unterlagen des Europäischen Datenschutzbeauftragten.

(6) Das Aufkommen aus den nach diesem Artikel verhängten Geldbußen trägt zum Gesamthaushalt der Union bei. Die Geldbußen dürfen nicht den wirksamen Betrieb des Organs, der Einrichtung oder der sonstigen Stelle der Union beeinträchtigen, dem bzw. der die Geldbuße auferlegt wurde.

(7) Der Europäische Datenschutzbeauftragte macht der Kommission jährlich Mitteilung über die Geldbußen, die er nach Maßgabe dieses Artikels verhängt hat, und über die von ihm eingeleiteten Rechtsstreitigkeiten oder Gerichtsverfahren.

<a id="art-101"></a>
### Artikel 101 – Geldbußen für Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

(1) Die Kommission kann gegen Anbieter von KI-Modellen mit allgemeinem Verwendungszweck Geldbußen von bis zu 3 % ihres gesamten weltweiten Jahresumsatzes im vorangegangenen Geschäftsjahr oder 15 000 000 EUR verhängen, je nachdem, welcher Betrag höher ist, wenn sie feststellt, dass der Anbieter vorsätzlich oder fahrlässig

- a) gegen die einschlägigen Bestimmungen dieser Verordnung verstoßen hat;

- b) der Anforderung eines Dokuments oder von Informationen gemäß Artikel 91 nicht nachgekommen ist oder falsche, unvollständige oder irreführende Informationen bereitgestellt hat;

- c) einer gemäß Artikel 93 geforderten Maßnahme nicht nachgekommen ist;

- d) der Kommission keinen Zugang zu dem KI-Modell mit allgemeinem Verwendungszweck oder dem KI-Modell mit allgemeinem Verwendungszweck mit systemischem Risiko gewährt hat, um eine Bewertung gemäß Artikel 92 durchzuführen.

Bei der Festsetzung der Höhe der Geldbuße oder des Zwangsgelds wird der Art, der Schwere und der Dauer des Verstoßes sowie den Grundsätzen der Verhältnismäßigkeit und der Angemessenheit gebührend Rechnung getragen. Die Kommission berücksichtigt außerdem Verpflichtungen, die gemäß Artikel 93 Absatz 3 oder in den einschlägigen Praxisleitfäden nach Artikel 56 gemacht wurden.

(2) Vor der Annahme einer Entscheidung nach Absatz 1 teilt die Kommission dem Anbieter des KI-Modells mit allgemeinem Verwendungszweck ihre vorläufige Beurteilung mit und gibt ihm Gelegenheit, Stellung zu nehmen.

(3) Die gemäß diesem Artikel verhängten Geldbußen müssen wirksam, verhältnismäßig und abschreckend sein.

(4) Informationen über gemäß diesem Artikel verhängte Geldbußen werden gegebenenfalls dem KI-Gremium mitgeteilt.

(5) Der Gerichtshof der Europäischen Union hat die unbeschränkte Befugnis zur Überprüfung der Entscheidungen der Kommission über die Festsetzung einer Geldbuße gemäß diesem Artikel. Er kann die verhängte Geldbuße aufheben, herabsetzen oder erhöhen.

(6) Die Kommission erlässt Durchführungsrechtsakte mit detaillierten Regelungen und Verfahrensgarantien für die Verfahren im Hinblick auf den möglichen Erlass von Beschlüssen gemäß Absatz 1 dieses Artikels. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 98 Absatz 2 genannten Prüfverfahren erlassen.

<a id="chapter-xiii"></a>
## Kapitel XIII – SCHLUSSBESTIMMUNGEN

<a id="art-102"></a>
### Artikel 102 – Änderung der Verordnung (EG) Nr. 300/2008

In Artikel 4 Absatz 3 der Verordnung (EG) Nr. 300/2008 wird folgender Unterabsatz angefügt:

„Beim Erlass detaillierter Maßnahmen, die technische Spezifikationen und Verfahren für die Genehmigung und den Einsatz von Sicherheitsausrüstung betreffen, bei der auch Systeme der künstlichen Intelligenz im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(3) zum Einsatz kommen, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

<a id="art-103"></a>
### Artikel 103 – Änderung der Verordnung (EU) Nr. 167/2013

In Artikel 17 Absatz 5 der Verordnung (EU) Nr. 167/2013 wird folgender Unterabsatz angefügt:

„Beim Erlass delegierter Rechtsakte nach Unterabsatz 1, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(4) handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

<a id="art-104"></a>
### Artikel 104 – Änderung der Verordnung (EU) Nr. 168/2013

In Artikel 22 Absatz 5 der Verordnung (EU) Nr. 168/2013 wird folgender Unterabsatz angefügt:

„Beim Erlass delegierter Rechtsakte nach Unterabsatz 1, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(5) handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

<a id="art-105"></a>
### Artikel 105 – Änderung der Richtlinie 2014/90/EU

In Artikel 8 der Richtlinie 2014/90/EU wird folgender Absatz angefügt:

„(5) Bei Systemen der künstlichen Intelligenz, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(6) handelt, berücksichtigt die Kommission bei der Ausübung ihrer Tätigkeiten nach Absatz 1 und bei Erlass technischer Spezifikationen und Prüfnormen nach den Absätzen 2 und 3 die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen.

<a id="art-106"></a>
### Artikel 106 – Änderung der Richtlinie (EU) 2016/797

In Artikel 5 der Richtlinie (EU) 2016/797 wird folgender Absatz angefügt:

„(12) Beim Erlass von delegierten Rechtsakten nach Absatz 1 und von Durchführungsrechtsakten nach Absatz 11, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(7) handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

<a id="art-107"></a>
### Artikel 107 – Änderung der Verordnung (EU) 2018/858

In Artikel 5 der Verordnung (EU) 2018/858 wird folgender Absatz angefügt:

„(4) Beim Erlass delegierter Rechtsakte nach Absatz 3, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(8) handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

<a id="art-108"></a>
### Artikel 108 – Änderungen der Verordnung (EU) 2018/1139

Die Verordnung (EU) 2018/1139 wird wie folgt geändert:

- 1. In Artikel 17 wird folgender Absatz angefügt:

  „(3) Unbeschadet des Absatzes 2 werden beim Erlass von Durchführungsrechtsakten nach Absatz 1, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(9) handelt, die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

- 2. In Artikel 19 wird folgender Absatz angefügt:

  „(4) Beim Erlass delegierter Rechtsakte nach den Absätzen 1 und 2, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.“

- 3. In Artikel 43 wird folgender Absatz angefügt:

  „(4) Beim Erlass von Durchführungsrechtsakten nach Absatz 1, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.“

- 4. In Artikel 47 wird folgender Absatz angefügt:

  „(3) Beim Erlass delegierter Rechtsakte nach den Absätzen 1 und 2, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.“

- 5. In Artikel 57 wird folgender Unterabsatz angefügt:

  „Beim Erlass solcher Durchführungsrechtsakte, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.“

- 6. In Artikel 58 wird folgender Absatz angefügt:

  „(3) Beim Erlass delegierter Rechtsakte nach den Absätzen 1 und 2, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.“

<a id="art-109"></a>
### Artikel 109 – Änderung der Verordnung (EU) 2019/2144

In Artikel 11 der Verordnung (EU) 2019/2144 wird folgender Absatz angefügt:

„(3) Beim Erlass von Durchführungsrechtsakten nach Absatz 2, die sich auf Systeme der künstlichen Intelligenz beziehen, bei denen es sich um Sicherheitsbauteile im Sinne der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates ^(10) handelt, werden die in Kapitel III Abschnitt 2 jener Verordnung festgelegten Anforderungen berücksichtigt.

<a id="art-110"></a>
### Artikel 110 – Änderung der Richtlinie (EU) 2020/1828

In Anhang I der Richtlinie (EU) 2020/1828 des Europäischen Parlaments und des Rates ^(11) wird die folgende Nummer angefügt:

- „68. Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

<a id="art-111"></a>
### Artikel 111 – Bereits in Verkehr gebrachte oder in Betrieb genommene KI-Systeme und bereits in Verkehr gebrachte KI-Modelle mit allgemeinem Verwendungszweck

(1) Unbeschadet der Anwendung des Artikels 5 gemäß Artikel 113 Absatz 3 Buchstabe a werden KI-Systeme, bei denen es sich um Komponenten von IT-Großsystemen handelt, die mit den in Anhang X aufgeführten Rechtsakten eingerichtet wurden und vor dem 2. August 2027 in Verkehr gebracht oder in Betrieb genommen wurden, bis zum 31. Dezember 2030 mit dieser Verordnung in Einklang gebracht.

Die in dieser Verordnung festgelegten Anforderungen werden bei der Bewertung jedes IT-Großsystems, das mit den in Anhang X aufgeführten Rechtsakten eingerichtet wurde, berücksichtigt, wobei die Bewertung entsprechend den Vorgaben der jeweiligen Rechtsakte und bei Ersetzung oder Änderung dieser Rechtsakte erfolgt.

▼M1

(2) Unbeschadet der Anwendung des Artikels 5 gemäß Artikel 113 Absatz 3 Buchstabe a gilt diese Verordnung für Akteure von Hochrisiko-KI-Systemen — mit Ausnahme der in Absatz 1 des vorliegenden Artikels genannten Systeme —, die vor dem Beginn der Anwendung des Kapitels III gemäß Artikel 113 in Verkehr gebracht oder in Betrieb genommen wurden, nur dann, wenn diese Systeme danach in ihrer Konzeption erheblich verändert wurden. In jedem Fall treffen die Anbieter und Betreiber von Hochrisiko-KI-Systemen, die bestimmungsgemäß von Behörden verwendet werden sollen, die erforderlichen Maßnahmen zur Erfüllung der in dieser Verordnung festgelegten Anforderungen und Pflichten bis zum 2. August 2030.

▼B

(3) Anbieter von KI-Modellen mit allgemeinem Verwendungszweck, die vor dem 2. August 2025 in Verkehr gebracht wurden, treffen die erforderlichen Maßnahmen für die Erfüllung der in dieser Verordnung festgelegten Pflichten bis zum 2. August 2027.

▼M1

(4) Anbieter von KI-Systemen, einschließlich KI-Systemen mit allgemeinem Verwendungszweck, die synthetische Audio-, Bild-, Video- oder Textinhalte erzeugen, die vor dem 2. August 2026 in Verkehr gebracht wurden, treffen die erforderlichen Maßnahmen, um Artikel 50 Absatz 2 bis zum 2. Dezember 2026 nachzukommen.

▼B

<a id="art-112"></a>
### Artikel 112 – Bewertung und Überprüfung

(1) Die Kommission prüft nach Inkrafttreten dieser Verordnung und bis zum Ende der Befugnisübertragung gemäß Artikel 97 einmal jährlich, ob eine Änderung der Liste in Anhang III und der Liste der verbotenen Praktiken im KI-Bereich gemäß Artikel 5 erforderlich ist. Die Kommission übermittelt die Ergebnisse dieser Bewertung dem Europäischen Parlament und dem Rat.

(2) Bis zum 2. August 2028 und danach alle vier Jahre bewertet die Kommission Folgendes und erstattet dem Europäischen Parlament und dem Rat Bericht darüber:

- a) Notwendigkeit von Änderungen zur Erweiterung bestehender Bereiche oder zur Aufnahme neuer Bereiche in Anhang III:

- b) Änderungen der Liste der KI-Systeme, die zusätzliche Transparenzmaßnahmen erfordern, in Artikel 50;

- c) Änderungen zur Verbesserung der Wirksamkeit des Überwachungs- und Governance-Systems.

(3) Bis zum 2. August 2029 und danach alle vier Jahre legt die Kommission dem Europäischen Parlament und dem Rat einen Bericht über die Bewertung und Überprüfung dieser Verordnung vor. Der Bericht enthält eine Beurteilung hinsichtlich der Durchsetzungsstruktur und der etwaigen Notwendigkeit einer Agentur der Union zur Lösung der festgestellten Mängel. Auf der Grundlage der Ergebnisse wird diesem Bericht gegebenenfalls ein Vorschlag zur Änderung dieser Verordnung beigefügt. Die Berichte werden veröffentlicht.

(4) In den in Absatz 2 genannten Berichten wird insbesondere auf folgende Aspekte eingegangen:

- a) Sachstand bezüglich der finanziellen, technischen und personellen Ressourcen der zuständigen nationalen Behörden im Hinblick auf deren Fähigkeit, die ihnen auf der Grundlage dieser Verordnung übertragenen Aufgaben wirksam zu erfüllen;

- b) Stand der Sanktionen, insbesondere der Bußgelder nach Artikel 99 Absatz 1, die Mitgliedstaaten bei Verstößen gegen diese Verordnung verhängt haben;

- c) angenommene harmonisierte Normen und gemeinsame Spezifikationen, die zur Unterstützung dieser Verordnung erarbeitet wurden;

- d) Zahl der Unternehmen, die nach Inkrafttreten dieser Verordnung in den Markt eintreten, und wie viele davon KMU sind.

(5) Bis zum 2. August 2028 bewertet die Kommission die Arbeitsweise des Büros für Künstliche Intelligenz und prüft, ob das Büro für Künstliche Intelligenz mit ausreichenden Befugnissen und Zuständigkeiten zur Erfüllung seiner Aufgaben ausgestattet wurde, und ob es für die ordnungsgemäße Durchführung und Durchsetzung dieser Verordnung zweckmäßig und erforderlich wäre, das Büro für Künstliche Intelligenz und seine Durchsetzungskompetenzen zu erweitern und seine Ressourcen aufzustocken. Die Kommission übermittelt dem Europäischen Parlament und dem Rat einen Bericht über ihre Bewertung.

(6) Bis zum 2. August 2028 und danach alle vier Jahre legt die Kommission einen Bericht über die Überprüfung der Fortschritte bei der Entwicklung von Normungsdokumenten zur energieeffizienten Entwicklung von KI-Modellen mit allgemeinem Verwendungszweck vor und beurteilt die Notwendigkeit weiterer Maßnahmen oder Handlungen, einschließlich verbindlicher Maßnahmen oder Handlungen. Dieser Bericht wird dem Europäischen Parlament und dem Rat vorgelegt und veröffentlicht.

(7) Bis zum 2. August 2028 und danach alle drei Jahre führt die Kommission eine Bewertung der Folgen und der Wirksamkeit der freiwilligen Verhaltenskodizes durch, mit denen die Anwendung der in Kapitel III Abschnitt 2 festgelegten Anforderungen an andere KI-Systeme als Hochrisiko-KI-Systeme und möglicherweise auch zusätzlicher Anforderungen an andere KI-Systeme als Hochrisiko-KI-Systeme, auch in Bezug auf deren ökologische Nachhaltigkeit, gefördert werden soll.

(8) Für die Zwecke der Absätze 1 bis 7 übermitteln das KI-Gremium, die Mitgliedstaaten und die zuständigen nationalen Behörden der Kommission auf Anfrage unverzüglich die gewünschten Informationen.

(9) Bei den in den Absätzen 1 bis 7 genannten Bewertungen und Überprüfungen berücksichtigt die Kommission die Standpunkte und Feststellungen des KI-Gremiums, des Europäischen Parlaments, des Rates und anderer einschlägiger Stellen oder Quellen.

(10) Die Kommission legt erforderlichenfalls geeignete Vorschläge zur Änderung dieser Verordnung vor und berücksichtigt dabei insbesondere technologische Entwicklungen, die Auswirkungen von KI-Systemen auf die Gesundheit und Sicherheit und auf die Grundrechte und die Fortschritte in der Informationsgesellschaft.

(11) Als Orientierung für die in den Absätzen 1 bis 7 genannten Bewertungen und Überprüfungen entwickelt das Büro für Künstliche Intelligenz ein Ziel und eine partizipative Methode für die Bewertung der Risikoniveaus anhand der in den jeweiligen Artikeln genannten Kriterien und für die Einbeziehung neuer Systeme in

- a) die Liste gemäß Anhang III, einschließlich der Erweiterung bestehender Bereiche oder der Aufnahme neuer Bereiche in diesen Anhang;

- b) die Liste der verbotenen Praktiken gemäß Artikel 5; und

- c) die Liste der KI-Systeme, die zusätzliche Transparenzmaßnahmen erfordern, in Artikel 50.

(12) Eine Änderung dieser Verordnung im Sinne des Absatzes 10 oder entsprechende delegierte Rechtsakte oder Durchführungsrechtsakte, die sektorspezifische Rechtsvorschriften für eine unionsweite Harmonisierung gemäß Anhang I Abschnitt B betreffen, berücksichtigen die regulatorischen Besonderheiten des jeweiligen Sektors und die in der Verordnung festgelegten bestehenden Governance-, Konformitätsbewertungs- und Durchsetzungsmechanismen und -behörden.

(13) Bis zum 2. August 2031 nimmt die Kommission unter Berücksichtigung der ersten Jahre der Anwendung der Verordnung eine Bewertung der Durchsetzung dieser Verordnung vor und erstattet dem Europäischen Parlament, dem Rat und dem Europäischen Wirtschafts- und Sozialausschuss darüber Bericht. Auf Grundlage der Ergebnisse wird dem Bericht gegebenenfalls ein Vorschlag zur Änderung dieser Verordnung beigefügt, der die Struktur der Durchsetzung und die Notwendigkeit einer Agentur der Union für die Lösung festgestellter Mängel betrifft.

<a id="art-113"></a>
### Artikel 113 – Inkrafttreten und Geltungsbeginn

Diese Verordnung tritt am zwanzigsten Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

Sie gilt ab dem 2. August 2026.

Jedoch:

▼M1

- a) Die Kapitel I und II gelten ab dem 2. Februar 2025, mit Ausnahme von Artikel 5 Absatz 1 Unterabsatz 1 Buchstaben ba und bb und Artikel 5 Absätze 1a und 1b, die ab dem 2. Dezember 2026 gelten;

▼B

- b) Kapitel III Abschnitt 4, Kapitel V, Kapitel VII und Kapitel XII sowie Artikel 78 gelten ab dem 2. August 2025, mit Ausnahme des Artikels 101;

▼M1

- c) Kapitel III Abschnitte 1, 2 und 3, mit Ausnahme von Artikel 6 Absatz 5, gelten ab dem:

  - i) 2. Dezember 2027 in Bezug auf KI-Systeme, die gemäß Artikel 6 Absatz 2 und Anhang III als hochriskant eingestuft sind, und

  - ii) 2. August 2028 in Bezug auf KI-Systeme, die gemäß Artikel 6 Absatz 1 und Anhang I als hochriskant eingestuft sind;

▼M1

- d) Die Artikel 102 bis 110 gelten ab dem 27. Juli 2026.

▼B

Diese Verordnung ist in allen ihren Teilen verbindlich und gilt unmittelbar in jedem Mitgliedstaat.

<a id="annex-i"></a>
## Anhang I – Liste der Harmonisierungsrechtsvorschriften der Union

### Abschnitt A — Liste der Harmonisierungsrechtsvorschriften der Union auf der Grundlage des neuen Rechtsrahmens

▼M1 —————

▼B

2. Richtlinie 2009/48/EG des Europäischen Parlaments und des Rates vom 18. Juni 2009 über die Sicherheit von Spielzeug (ABl. L 170 vom 30.6.2009, S. 1)

3. Richtlinie 2013/53/EU des Europäischen Parlaments und des Rates vom 20. November 2013 über Sportboote und Wassermotorräder und zur Aufhebung der Richtlinie 94/25/EG (ABl. L 354 vom 28.12.2013, S. 90)

4. Richtlinie 2014/33/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Angleichung der Rechtsvorschriften der Mitgliedstaaten über Aufzüge und Sicherheitsbauteile für Aufzüge (ABl. L 96 vom 29.3.2014, S. 251)

5. Richtlinie 2014/34/EU des Europäischen Parlaments und des Rates vom 26. Februar 2014 zur Harmonisierung der Rechtsvorschriften der Mitgliedstaaten für Geräte und Schutzsysteme zur bestimmungsgemäßen Verwendung in explosionsgefährdeten Bereichen (ABl. L 96 vom 29.3.2014, S. 309)

6. Richtlinie 2014/53/EU des Europäischen Parlaments und des Rates vom 16. April 2014 über die Harmonisierung der Rechtsvorschriften der Mitgliedstaaten über die Bereitstellung von Funkanlagen auf dem Markt und zur Aufhebung der Richtlinie 1999/5/EG (ABl. L 153 vom 22.5.2014, S. 62)

7. Richtlinie 2014/68/EU des Europäischen Parlaments und des Rates vom 15. Mai 2014 zur Harmonisierung der Rechtsvorschriften der Mitgliedstaaten über die Bereitstellung von Druckgeräten auf dem Markt (ABl. L 189 vom 27.6.2014, S. 164)

8. Verordnung (EU) 2016/424 des Europäischen Parlaments und des Rates vom 9. März 2016 über Seilbahnen und zur Aufhebung der Richtlinie 2000/9/EG (ABl. L 81 vom 31.3.2016, S. 1)

9. Verordnung (EU) 2016/425 des Europäischen Parlaments und des Rates vom 9. März 2016 über persönliche Schutzausrüstungen und zur Aufhebung der Richtlinie 89/686/EWG des Rates (ABl. L 81 vom 31.3.2016, S. 51)

10. Verordnung (EU) 2016/426 des Europäischen Parlaments und des Rates vom 9. März 2016 über Geräte zur Verbrennung gasförmiger Brennstoffe und zur Aufhebung der Richtlinie 2009/142/EG (ABl. L 81 vom 31.3.2016, S. 99)

11. Verordnung (EU) 2017/745 des Europäischen Parlaments und des Rates vom 5. April 2017 über Medizinprodukte, zur Änderung der Richtlinie 2001/83/EG, der Verordnung (EG) Nr. 178/2002 und der Verordnung (EG) Nr. 1223/2009 und zur Aufhebung der Richtlinien 90/385/EWG und 93/42/EWG des Rates (ABl. L 117 vom 5.5.2017, S. 1)

12. Verordnung (EU) 2017/746 des Europäischen Parlaments und des Rates vom 5. April 2017 über In-vitro-Diagnostika und zur Aufhebung der Richtlinie 98/79/EG und des Beschlusses 2010/227/EU der Kommission (ABl. L 117 vom 5.5.2017, S. 176)

### Abschnitt B — Liste anderer Harmonisierungsrechtsvorschriften der Union

13. Verordnung (EG) Nr. 300/2008 des Europäischen Parlaments und des Rates vom 11. März 2008 über gemeinsame Vorschriften für die Sicherheit in der Zivilluftfahrt und zur Aufhebung der Verordnung (EG) Nr. 2320/2002 (ABl. L 97 vom 9.4.2008, S. 72)

14. Verordnung (EU) Nr. 168/2013 des Europäischen Parlaments und des Rates vom 15. Januar 2013 über die Genehmigung und Marktüberwachung von zwei- oder dreirädrigen und vierrädrigen Fahrzeugen (ABl. L 60 vom 2.3.2013, S. 52)

15. Verordnung (EU) Nr. 167/2013 des Europäischen Parlaments und des Rates vom 5. Februar 2013 über die Genehmigung und Marktüberwachung von land- und forstwirtschaftlichen Fahrzeugen (ABl. L 60 vom 2.3.2013, S. 1)

16. Richtlinie 2014/90/EU des Europäischen Parlaments und des Rates vom 23. Juli 2014 über Schiffsausrüstung und zur Aufhebung der Richtlinie 96/98/EG des Rates (ABl. L 257 vom 28.8.2014, S. 146)

17. Richtlinie (EU) 2016/797 des Europäischen Parlaments und des Rates vom 11. Mai 2016 über die Interoperabilität des Eisenbahnsystems in der Europäischen Union (ABl. L 138 vom 26.5.2016, S. 44)

18. Verordnung (EU) 2018/858 des Europäischen Parlaments und des Rates vom 30. Mai 2018 über die Genehmigung und die Marktüberwachung von Kraftfahrzeugen und Kraftfahrzeuganhängern sowie von Systemen, Bauteilen und selbstständigen technischen Einheiten für diese Fahrzeuge, zur Änderung der Verordnungen (EG) Nr. 715/2007 und (EG) Nr. 595/2009 und zur Aufhebung der Richtlinie 2007/46/EG (ABl. L 151 vom 14.6.2018, S. 1)

19. Verordnung (EU) 2019/2144 des Europäischen Parlaments und des Rates vom 27. November 2019 über die Typgenehmigung von Kraftfahrzeugen und Kraftfahrzeuganhängern sowie von Systemen, Bauteilen und selbstständigen technischen Einheiten für diese Fahrzeuge im Hinblick auf ihre allgemeine Sicherheit und den Schutz der Fahrzeuginsassen und von ungeschützten Verkehrsteilnehmern, zur Änderung der Verordnung (EU) 2018/858 des Europäischen Parlaments und des Rates und zur Aufhebung der Verordnungen (EG) Nr. 78/2009, (EG) Nr. 79/2009 und (EG) Nr. 661/2009 des Europäischen Parlaments und des Rates sowie der Verordnungen (EG) Nr. 631/2009, (EU) Nr. 406/2010, (EU) Nr. 672/2010, (EU) Nr. 1003/2010, (EU) Nr. 1005/2010, (EU) Nr. 1008/2010, (EU) Nr. 1009/2010, (EU) Nr. 19/2011, (EU) Nr. 109/2011, (EU) Nr. 458/2011, (EU) Nr. 65/2012, (EU) Nr. 130/2012, (EU) Nr. 347/2012, (EU) Nr. 351/2012, (EU) Nr. 1230/2012 und (EU) 2015/166 der Kommission (ABl. L 325 vom 16.12.2019, S. 1)

20. Verordnung (EU) 2018/1139 des Europäischen Parlaments und des Rates vom 4. Juli 2018 zur Festlegung gemeinsamer Vorschriften für die Zivilluftfahrt und zur Errichtung einer Agentur der Europäischen Union für Flugsicherheit sowie zur Änderung der Verordnungen (EG) Nr. 2111/2005, (EG) Nr. 1008/2008, (EU) Nr. 996/2010, (EU) Nr. 376/2014 und der Richtlinien 2014/30/EU und 2014/53/EU des Europäischen Parlaments und des Rates, und zur Aufhebung der Verordnungen (EG) Nr. 552/2004 und (EG) Nr. 216/2008 des Europäischen Parlaments und des Rates und der Verordnung (EWG) Nr. 3922/91 des Rates (ABl. L 212 vom 22.8.2018, S. 1), insoweit die Konstruktion, Herstellung und Vermarktung von Luftfahrzeugen gemäß Artikel 2 Absatz 1 Buchstaben a und b in Bezug auf unbemannte Luftfahrzeuge sowie deren Motoren, Propeller, Teile und Ausrüstung zur Fernsteuerung betroffen sind

▼M1

21. Verordnung (EU) 2023/1230 des Europäischen Parlaments und des Rates vom 14. Juni 2023 über Maschinen und zur Aufhebung der Richtlinie 2006/42/EG des Europäischen Parlaments und des Rates und der Richtlinie 73/361/EWG des Rates (ABl. L 165 vom 29.6.2023, S. 1, ELI: http://data.europa.eu/eli/reg/2023/1230/oj).

▼B

<a id="annex-ii"></a>
## Anhang II – Liste der Straftaten gemäß Artikel 5 Absatz 1 Unterabsatz 1 Buchstabe h Ziffer iii

Straftaten gemäß Artikel 5 Absatz 1 Unterabsatz 1 Buchstabe h Ziffer iii:

- — Terrorismus,

- — Menschenhandel,

- — sexuelle Ausbeutung von Kindern und Kinderpornografie,

- — illegaler Handel mit Drogen oder psychotropen Stoffen,

- — illegaler Handel mit Waffen, Munition oder Sprengstoffen,

- — Mord, schwere Körperverletzung,

- — illegaler Handel mit menschlichen Organen oder menschlichem Gewebe,

- — illegaler Handel mit nuklearen oder radioaktiven Substanzen,

- — Entführung, Freiheitsberaubung oder Geiselnahme,

- — Verbrechen, die in die Zuständigkeit des Internationalen Strafgerichtshofs fallen,

- — Flugzeug- oder Schiffsentführung,

- — Vergewaltigung,

- — Umweltkriminalität,

- — organisierter oder bewaffneter Raub,

- — Sabotage,

- — Beteiligung an einer kriminellen Vereinigung, die an einer oder mehreren der oben genannten Straftaten beteiligt ist.

<a id="annex-iii"></a>
## Anhang III – Hochrisiko-KI-Systeme gemäß Artikel 6 Absatz 2

Als Hochrisiko-KI-Systeme gemäß Artikel 6 Absatz 2 gelten die in folgenden Bereichen aufgeführten KI-Systeme:

- 1. Biometrie, soweit ihr Einsatz nach einschlägigem Unionsrecht oder nationalem Recht zugelassen ist:

  - a) biometrische Fernidentifizierungssysteme.

    Dazu gehören nicht KI-Systeme, die bestimmungsgemäß für die biometrische Verifizierung, deren einziger Zweck darin besteht, zu bestätigen, dass eine bestimmte natürliche Person die Person ist, für die sie sich ausgibt, verwendet werden sollen;

  - b) KI-Systeme, die bestimmungsgemäß für die biometrische Kategorisierung nach sensiblen oder geschützten Attributen oder Merkmalen auf der Grundlage von Rückschlüssen auf diese Attribute oder Merkmale verwendet werden sollen;

  - c) KI-Systeme, die bestimmungsgemäß zur Emotionserkennung verwendet werden sollen.

- 2. Kritische Infrastruktur: KI-Systeme, die bestimmungsgemäß als Sicherheitsbauteile im Rahmen der Verwaltung und des Betriebs kritischer digitaler Infrastruktur, des Straßenverkehrs oder der Wasser-, Gas-, Wärme- oder Stromversorgung verwendet werden sollen

- 3. Allgemeine und berufliche Bildung

  - a) KI-Systeme, die bestimmungsgemäß zur Feststellung des Zugangs oder der Zulassung oder zur Zuweisung natürlicher Personen zu Einrichtungen aller Ebenen der allgemeinen und beruflichen Bildung verwendet werden sollen;

  - b) KI-Systeme, die bestimmungsgemäß für die Bewertung von Lernergebnissen verwendet werden sollen, einschließlich des Falles, dass diese Ergebnisse dazu dienen, den Lernprozess natürlicher Personen in Einrichtungen oder Programmen aller Ebenen der allgemeinen und beruflichen Bildung zu steuern;

  - c) KI-Systeme, die bestimmungsgemäß zum Zweck der Bewertung des angemessenen Bildungsniveaus, das eine Person im Rahmen von oder innerhalb von Einrichtungen aller Ebenen der allgemeinen und beruflichen Bildung erhalten wird oder zu denen sie Zugang erhalten wird, verwendet werden sollen;

  - d) KI-Systeme, die bestimmungsgemäß zur Überwachung und Erkennung von verbotenem Verhalten von Schülern bei Prüfungen im Rahmen von oder innerhalb von Einrichtungen aller Ebenen der allgemeinen und beruflichen Bildung verwendet werden sollen.

- 4. Beschäftigung, Personalmanagement und Zugang zur Selbstständigkeit

  - a) KI-Systeme, die bestimmungsgemäß für die Einstellung oder Auswahl natürlicher Personen verwendet werden sollen, insbesondere um gezielte Stellenanzeigen zu schalten, Bewerbungen zu sichten oder zu filtern und Bewerber zu bewerten;

  - b) KI-Systeme, die bestimmungsgemäß für Entscheidungen, die die Bedingungen von Arbeitsverhältnissen, Beförderungen und Kündigungen von Arbeitsvertragsverhältnissen beeinflussen, für die Zuweisung von Aufgaben aufgrund des individuellen Verhaltens oder persönlicher Merkmale oder Eigenschaften oder für die Beobachtung und Bewertung der Leistung und des Verhaltens von Personen in solchen Beschäftigungsverhältnissen verwendet werden soll.

- 5. Zugänglichkeit und Inanspruchnahme grundlegender privater und grundlegender öffentlicher Dienste und Leistungen:

  - a) KI-Systeme, die bestimmungsgemäß von Behörden oder im Namen von Behörden verwendet werden sollen, um zu beurteilen, ob natürliche Personen Anspruch auf grundlegende öffentliche Unterstützungsleistungen und -dienste, einschließlich Gesundheitsdiensten, haben und ob solche Leistungen und Dienste zu gewähren, einzuschränken, zu widerrufen oder zurückzufordern sind;

  - b) KI-Systeme, die bestimmungsgemäß für die Kreditwürdigkeitsprüfung und Bonitätsbewertung natürlicher Personen verwendet werden sollen, mit Ausnahme von KI-Systemen, die zur Aufdeckung von Finanzbetrug verwendet werden;

  - c) KI-Systeme, die bestimmungsgemäß für die Risikobewertung und Preisbildung in Bezug auf natürliche Personen im Fall von Lebens- und Krankenversicherungen verwendet werden sollen;

  - d) KI-Systeme, die bestimmungsgemäß zur Bewertung und Klassifizierung von Notrufen von natürlichen Personen oder für die Entsendung oder Priorisierung des Einsatzes von Not- und Rettungsdiensten, einschließlich Polizei, Feuerwehr und medizinischer Nothilfe, sowie für Systeme für die Triage von Patienten bei der Notfallversorgung verwendet werden sollen.

- 6. Strafverfolgung, soweit ihr Einsatz nach einschlägigem Unionsrecht oder nationalem Recht zugelassen ist:

  - a) KI-Systeme, die bestimmungsgemäß von Strafverfolgungsbehörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union zur Unterstützung von Strafverfolgungsbehörden oder in deren Namen zur Bewertung des Risikos einer natürlichen Person, zum Opfer von Straftaten zu werden, verwendet werden sollen;

  - b) KI-Systeme, die bestimmungsgemäß von Strafverfolgungsbehörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union zur Unterstützung von Strafverfolgungsbehörden als Lügendetektoren oder ähnliche Instrumente verwendet werden sollen;

  - c) KI-Systeme, die bestimmungsgemäß von Strafverfolgungsbehörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union zur Unterstützung von Strafverfolgungsbehörden zur Bewertung der Verlässlichkeit von Beweismitteln im Zuge der Ermittlung oder Verfolgung von Straftaten verwendet werden sollen;

  - d) KI-Systeme, die bestimmungsgemäß von Strafverfolgungsbehörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union zur Unterstützung von Strafverfolgungsbehörden zur Bewertung des Risikos, dass eine natürliche Person eine Straftat begeht oder erneut begeht, nicht nur auf der Grundlage der Erstellung von Profilen natürlicher Personen gemäß Artikel 3 Absatz 4 der Richtlinie (EU) 2016/680 oder zur Bewertung persönlicher Merkmale und Eigenschaften oder vergangenen kriminellen Verhaltens von natürlichen Personen oder Gruppen verwendet werden sollen;

  - e) KI-Systeme, die bestimmungsgemäß von Strafverfolgungsbehörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union zur Unterstützung von Strafverfolgungsbehörden zur Erstellung von Profilen natürlicher Personen gemäß Artikel 3 Absatz 4 der Richtlinie (EU) 2016/680 im Zuge der Aufdeckung, Ermittlung oder Verfolgung von Straftaten verwendet werden sollen.

- 7. Migration, Asyl und Grenzkontrolle, soweit ihr Einsatz nach einschlägigem Unionsrecht oder nationalem Recht zugelassen ist:

  - a) KI-Systeme, die bestimmungsgemäß von zuständigen Behörden oder in deren Namen oder Organen, Einrichtungen und sonstigen Stellen der Union als Lügendetektoren verwendet werden sollen oder ähnliche Instrumente;

  - b) KI-Systeme, die bestimmungsgemäß von zuständigen Behörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union zur Bewertung eines Risikos verwendet werden sollen, einschließlich eines Sicherheitsrisikos, eines Risikos der irregulären Einwanderung oder eines Gesundheitsrisikos, das von einer natürlichen Person ausgeht, die in das Hoheitsgebiet eines Mitgliedstaats einzureisen beabsichtigt oder eingereist ist;

  - c) KI-Systeme, die bestimmungsgemäß von zuständigen Behörden oder in deren Namen oder von Organen, Einrichtungen und sonstigen Stellen der Union verwendet werden sollen, um zuständige Behörden bei der Prüfung von Asyl- und Visumanträgen sowie Aufenthaltstiteln und damit verbundenen Beschwerden im Hinblick auf die Feststellung der Berechtigung der den Antrag stellenden natürlichen Personen, einschließlich damit zusammenhängender Bewertungen der Verlässlichkeit von Beweismitteln, zu unterstützen;

  - d) KI-Systeme, die bestimmungsgemäß von oder im Namen der zuständigen Behörden oder Organen, Einrichtungen und sonstigen Stellen der Union, im Zusammenhang mit Migration, Asyl oder Grenzkontrolle zum Zwecke der Aufdeckung, Anerkennung oder Identifizierung natürlicher Personen verwendet werden sollen, mit Ausnahme der Überprüfung von Reisedokumenten.

- 8. Rechtspflege und demokratische Prozesse

  - a) KI-Systeme, die bestimmungsgemäß von einer oder im Namen einer Justizbehörde verwendet werden sollen, um eine Justizbehörde bei der Ermittlung und Auslegung von Sachverhalten und Rechtsvorschriften und bei der Anwendung des Rechts auf konkrete Sachverhalte zu unterstützen, oder die auf ähnliche Weise für die alternative Streitbeilegung genutzt werden sollen;

  - b) KI-Systeme, die bestimmungsgemäß verwendet werden sollen, um das Ergebnis einer Wahl oder eines Referendums oder das Wahlverhalten natürlicher Personen bei der Ausübung ihres Wahlrechts bei einer Wahl oder einem Referendum zu beeinflussen. Dazu gehören nicht KI-Systeme, deren Ausgaben natürliche Personen nicht direkt ausgesetzt sind, wie Instrumente zur Organisation, Optimierung oder Strukturierung politischer Kampagnen in administrativer oder logistischer Hinsicht.

<a id="annex-iv"></a>
## Anhang IV – Technische Dokumentation gemäß Artikel 11 Absatz 1

Die in Artikel 11 Absatz 1 genannte technische Dokumentation muss mindestens die folgenden Informationen enthalten, soweit sie für das betreffende KI-System von Belang sind:

- 1. Allgemeine Beschreibung des KI-Systems, darunter

  - a) Zweckbestimmung, Name des Anbieters und Version des Systems mit Angaben dazu, in welcher Beziehung sie zu vorherigen Versionen steht;

  - b) gegebenenfalls Interaktion oder Verwendung des KI-Systems mit Hardware oder Software, einschließlich anderer KI-Systeme, die nicht Teil des KI-Systems selbst sind;

  - c) Versionen der betreffenden Software oder Firmware und etwaige Anforderungen in Bezug auf Aktualisierungen der Versionen;

  - d) Beschreibung aller Formen, in denen das KI-System in Verkehr gebracht oder in Betrieb genommen wird, zum Beispiel in Hardware eingebettete Softwarepakete, Herunterladen oder API;

  - e) Beschreibung der Hardware, auf der das KI-System betrieben werden soll;

  - f) falls das KI-System Bestandteil von Produkten ist: Fotografien oder Abbildungen, die äußere Merkmale, die Kennzeichnungen und den inneren Aufbau dieser Produkte zeigen;

  - g) eine grundlegende Beschreibung der Benutzerschnittstelle, die dem Betreiber zur Verfügung gestellt wird;

  - h) Betriebsanleitungen für den Betreiber und gegebenenfalls eine grundlegende Beschreibung der dem Betreiber zur Verfügung gestellten Benutzerschnittstelle;

- 2. Detaillierte Beschreibung der Bestandteile des KI-Systems und seines Entwicklungsprozesses, darunter

  - a) Methoden und Schritte zur Entwicklung des KI-Systems, gegebenenfalls einschließlich des Einsatzes von durch Dritte bereitgestellten vortrainierten Systemen oder Instrumenten, und wie diese vom Anbieter verwendet, integriert oder verändert wurden;

  - b) Entwurfsspezifikationen des Systems, insbesondere die allgemeine Logik des KI-Systems und der Algorithmen; die wichtigsten Entwurfsentscheidungen mit den Gründen und getroffenen Annahmen, einschließlich in Bezug auf Personen oder Personengruppen, bezüglich deren das System angewandt werden soll; hauptsächliche Einstufungsentscheidungen; was das System optimieren soll und welche Bedeutung den verschiedenen Parametern dabei zukommt; Beschreibung der erwarteten Ausgabe des Systems und der erwarteten Qualität dieser Ausgabe; die über mögliche Kompromisse in Bezug auf die technischen Lösungen, mit denen die in Kapitel III Abschnitt 2 festgelegten Anforderungen erfüllt werden sollen, getroffenen Entscheidungen;

  - c) Beschreibung der Systemarchitektur, aus der hervorgeht, wie Softwarekomponenten aufeinander aufbauen oder einander zuarbeiten und in die Gesamtverarbeitung integriert sind; zum Entwickeln, Trainieren, Testen und Validieren des KI-Systems verwendete Rechenressourcen;

  - d) gegebenenfalls Datenanforderungen in Form von Datenblättern, in denen die Trainingsmethoden und -techniken und die verwendeten Trainingsdatensätze beschrieben werden, einschließlich einer allgemeinen Beschreibung dieser Datensätze sowie Informationen zu deren Herkunft, Umfang und Hauptmerkmalen; Angaben zur Beschaffung und Auswahl der Daten; Kennzeichnungsverfahren (zum Beispiel für überwachtes Lernen) und Datenbereinigungsmethoden (zum Beispiel Erkennung von Ausreißern);

  - e) Bewertung der nach Artikel 14 erforderlichen Maßnahmen der menschlichen Aufsicht, mit einer Bewertung der technischen Maßnahmen, die erforderlich sind, um den Betreibern gemäß Artikel 13 Absatz 3 Buchstabe d die Interpretation der Ausgaben von KI-Systemen zu erleichtern;

  - f) gegebenenfalls detaillierte Beschreibung der vorab bestimmten Änderungen an dem KI-System und seiner Leistung mit allen einschlägigen Informationen zu den technischen Lösungen, mit denen sichergestellt wird, dass das KI-System die einschlägigen in Kapitel III Abschnitt 2 festgelegten Anforderungen weiterhin dauerhaft erfüllt;

  - g) verwendete Validierungs- und Testverfahren, mit Informationen zu den verwendeten Validierungs- und Testdaten und deren Hauptmerkmalen; Parameter, die zur Messung der Genauigkeit, Robustheit und der Erfüllung anderer einschlägiger Anforderungen nach Kapitel III Abschnitt 2 sowie potenziell diskriminierender Auswirkungen verwendet werden; Testprotokolle und alle von den verantwortlichen Personen datierten und unterzeichneten Testberichte, auch in Bezug auf die unter Buchstabe f genannten vorab bestimmten Änderungen;

  - h) ergriffene Cybersicherheitsmaßnahmen;

- 3. Detaillierte Informationen über die Überwachung, Funktionsweise und Kontrolle des KI-Systems, insbesondere in Bezug auf Folgendes: die Fähigkeiten und Leistungsgrenzen des Systems, einschließlich der Genauigkeitsgrade bei bestimmten Personen oder Personengruppen, auf die es bestimmungsgemäß angewandt werden soll, sowie des in Bezug auf seine Zweckbestimmung insgesamt erwarteten Maßes an Genauigkeit; angesichts der Zweckbestimmung des KI-Systems vorhersehbare unbeabsichtigte Ergebnisse und Quellen von Risiken in Bezug auf Gesundheit und Sicherheit sowie Grundrechte und Diskriminierung; die nach Artikel 14 erforderlichen Maßnahmen der menschlichen Aufsicht, einschließlich der technischen Maßnahmen, die getroffen wurden, um den Betreibern die Interpretation der Ausgaben von KI-Systemen zu erleichtern; gegebenenfalls Spezifikationen zu Eingabedaten;

- 4. Darlegungen zur Eignung der Leistungskennzahlen für das spezifische KI-System;

- 5. Detaillierte Beschreibung des Risikomanagementsystems gemäß Artikel 9;

- 6. Beschreibung einschlägiger Änderungen, die der Anbieter während des Lebenszyklus an dem System vorgenommen hat;

- 7. Aufstellung der vollständig oder teilweise angewandten harmonisierten Normen, deren Fundstellen im Amtsblatt der Europäischen Union veröffentlicht wurden; falls keine solchen harmonisierten Normen angewandt wurden, eine detaillierte Beschreibung der Lösungen, mit denen die in Kapitel III Abschnitt 2 festgelegten Anforderungen erfüllt werden sollen, mit einer Aufstellung anderer angewandter einschlägiger Normen und technischer Spezifikationen;

- 8. Kopie der EU-Konformitätserklärung gemäß Artikel 47;

- 9. Detaillierte Beschreibung des Systems zur Bewertung der Leistung des KI-Systems in der Phase nach dem Inverkehrbringen gemäß Artikel 72, einschließlich des in Artikel 72 Absatz 3 genannten Plans für die Beobachtung nach dem Inverkehrbringen

<a id="annex-v"></a>
## Anhang V – EU-Konformitätserklärung

Die EU-Konformitätserklärung gemäß Artikel 47 enthält alle folgenden Angaben:

- 1. Name und Art des KI-Systems und etwaige zusätzliche eindeutige Angaben, die die Identifizierung und Rückverfolgbarkeit des KI-Systems ermöglichen;

- 2. Name und Anschrift des Anbieters und gegebenenfalls seines Bevollmächtigten;

- 3. Erklärung darüber, dass der Anbieter die alleinige Verantwortung für die Ausstellung der EU-Konformitätserklärung gemäß Artikel 47 trägt;

- 4. Versicherung, dass das betreffende KI-System der vorliegenden Verordnung sowie gegebenenfalls weiteren einschlägigen Rechtsvorschriften der Union, in denen die Ausstellung der EU-Konformitätserklärung gemäß Artikel 47 vorgesehen ist, entspricht;

- 5. wenn ein KI-System die Verarbeitung personenbezogener Daten erfordert, eine Erklärung darüber, dass das KI-System den Verordnungen (EU) 2016/679 und (EU) 2018/1725 sowie der Richtlinie (EU) 2016/680 entspricht;

- 6. Verweise auf die verwendeten einschlägigen harmonisierten Normen oder sonstigen gemeinsamen Spezifikationen, für die die Konformität erklärt wird;

- 7. gegebenenfalls Name und Identifizierungsnummer der notifizierten Stelle, Beschreibung des durchgeführten Konformitätsbewertungsverfahrens und Identifizierungsnummer der ausgestellten Bescheinigung;

- 8. Ort und Datum der Ausstellung der Erklärung, den Namen und die Funktion des Unterzeichners sowie Angabe, für wen oder in wessen Namen diese Person unterzeichnet hat, eine Unterschrift.

<a id="annex-vi"></a>
## Anhang VI – Konformitätsbewertungsverfahren auf der Grundlage einer internen Kontrolle

1. Das Konformitätsbewertungsverfahren auf der Grundlage einer internen Kontrolle ist das Konformitätsbewertungsverfahren gemäß den Nummern 2, 3 und 4.

2. Der Anbieter überprüft, ob das bestehende Qualitätsmanagementsystem den Anforderungen des Artikels 17 entspricht.

3. Der Anbieter prüft die in der technischen Dokumentation enthaltenen Informationen, um zu beurteilen. ob das KI-System den einschlägigen grundlegenden Anforderungen in Kapitel III Abschnitt 2 entspricht.

4. Der Anbieter überprüft ferner, ob der Entwurfs- und Entwicklungsprozess des KI-Systems und seine Beobachtung nach dem Inverkehrbringen gemäß Artikel 72 mit der technischen Dokumentation im Einklang stehen.

<a id="annex-vii"></a>
## Anhang VII – Konformität auf der Grundlage einer Bewertung des Qualitätsmanagementsystems und einer Bewertung der technischen Dokumentation

### 1. Einleitung

Die Konformität auf der Grundlage einer Bewertung des Qualitätsmanagementsystems und einer Bewertung der technischen Dokumentation entspricht dem Konformitätsbewertungsverfahren gemäß den Nummern 2 bis 5.

### 2. Überblick

Das genehmigte Qualitätsmanagementsystem für die Konzeption, die Entwicklung und das Testen von KI-Systemen nach Artikel 17 wird gemäß Nummer 3 geprüft und unterliegt der Überwachung gemäß Nummer 5. Die technische Dokumentation des KI-Systems wird gemäß Nummer 4 geprüft.

### 3. Qualitätsmanagementsystem

3.1. Der Antrag des Anbieters muss Folgendes enthalten:

- a) Name und Anschrift des Anbieters sowie, wenn der Antrag von einem Bevollmächtigten eingereicht wird, auch dessen Namen und Anschrift;

- b) die Liste der unter dasselbe Qualitätsmanagementsystem fallenden KI-Systeme;

- c) die technische Dokumentation für jedes unter dasselbe Qualitätsmanagementsystem fallende KI-System;

- d) die Dokumentation über das Qualitätsmanagementsystem mit allen in Artikel 17 aufgeführten Aspekten;

- e) eine Beschreibung der bestehenden Verfahren, mit denen sichergestellt wird, dass das Qualitätsmanagementsystem angemessen und wirksam bleibt;

- f) eine schriftliche Erklärung, dass derselbe Antrag bei keiner anderen notifizierten Stelle eingereicht wurde.

3.2. Das Qualitätssicherungssystem wird von der notifizierten Stelle bewertet, um festzustellen, ob es die in Artikel 17 genannten Anforderungen erfüllt.

Die Entscheidung wird dem Anbieter oder dessen Bevollmächtigten mitgeteilt.

Die Mitteilung enthält die Ergebnisse der Bewertung des Qualitätsmanagementsystems und die begründete Bewertungsentscheidung.

3.3. Das genehmigte Qualitätsmanagementsystem wird vom Anbieter weiter angewandt und gepflegt, damit es stets angemessen und effizient funktioniert.

3.4. Der Anbieter unterrichtet die notifizierte Stelle über jede beabsichtigte Änderung des genehmigten Qualitätsmanagementsystems oder der Liste der unter dieses System fallenden KI-Systeme.

Die notifizierte Stelle prüft die vorgeschlagenen Änderungen und entscheidet, ob das geänderte Qualitätsmanagementsystem die unter Nummer 3.2 genannten Anforderungen weiterhin erfüllt oder ob eine erneute Bewertung erforderlich ist.

Die notifizierte Stelle teilt dem Anbieter ihre Entscheidung mit. Die Mitteilung enthält die Ergebnisse der Prüfung der Änderungen und die begründete Bewertungsentscheidung.

### 4. Kontrolle der technischen Dokumentation

4.1. Zusätzlich zu dem unter Nummer 3 genannten Antrag stellt der Anbieter bei der notifizierten Stelle seiner Wahl einen Antrag auf Bewertung der technischen Dokumentation für das KI-System, das er in Verkehr zu bringen oder in Betrieb zu nehmen beabsichtigt und das unter das unter Nummer 3 genannte Qualitätsmanagementsystem fällt.

4.2. Der Antrag enthält Folgendes:

- a) den Namen und die Anschrift des Anbieters;

- b) eine schriftliche Erklärung, dass derselbe Antrag bei keiner anderen notifizierten Stelle eingereicht wurde;

- c) die in Anhang IV genannte technische Dokumentation.

4.3. Die technische Dokumentation wird von der notifizierten Stelle geprüft. Sofern es relevant ist und beschränkt auf das zur Wahrnehmung ihrer Aufgaben erforderliche Maß erhält die notifizierte Stelle uneingeschränkten Zugang zu den verwendeten Trainings-, Validierungs- und Testdatensätzen, gegebenenfalls und unter Einhaltung von Sicherheitsvorkehrungen auch über API oder sonstige einschlägige technische Mittel und Instrumente, die den Fernzugriff ermöglichen.

4.4. Bei der Prüfung der technischen Dokumentation kann die notifizierte Stelle vom Anbieter weitere Nachweise oder die Durchführung weiterer Tests verlangen, um eine ordnungsgemäße Bewertung der Konformität des KI-Systems mit den in Kapitel III Abschnitt 2 festgelegten Anforderungen zu ermöglichen. Ist die notifizierte Stelle mit den vom Anbieter durchgeführten Tests nicht zufrieden, so führt sie gegebenenfalls unmittelbar selbst angemessene Tests durch.

4.5. Sofern es für die Bewertung der Konformität des Hochrisiko-KI-Systems mit den in Kapitel III Abschnitt 2 festgelegten Anforderungen notwendig ist, und nachdem alle anderen sinnvollen Möglichkeiten zur Überprüfung der Konformität ausgeschöpft sind oder sich als unzureichend erwiesen haben, wird der notifizierten Stelle auf begründeten Antrag Zugang zu den Trainingsmodellen und trainierten Modellen des KI-Systems, einschließlich seiner relevanten Parameter, gewährt. Ein solcher Zugang unterliegt dem bestehenden EU-Recht zum Schutz von geistigem Eigentum und Geschäftsgeheimnissen.

4.6. Die Entscheidung der notifizierten Stelle wird dem Anbieter oder dessen Bevollmächtigten mitgeteilt. Die Mitteilung enthält die Ergebnisse der Bewertung der technischen Dokumentation und die begründete Bewertungsentscheidung.

Erfüllt das KI-System die Anforderungen in Kapitel III Abschnitt 2, so stellt die notifizierte Stelle eine Unionsbescheinigung über die Bewertung der technischen Dokumentation aus. Diese Bescheinigung enthält den Namen und die Anschrift des Anbieters, die Ergebnisse der Prüfung, etwaige Bedingungen für ihre Gültigkeit und die für die Identifizierung des KI-Systems notwendigen Daten.

Die Bescheinigung und ihre Anhänge enthalten alle zweckdienlichen Informationen für die Beurteilung der Konformität des KI-Systems und gegebenenfalls für die Kontrolle des KI-Systems während seiner Verwendung.

Erfüllt das KI-System die in Kapitel III Abschnitt 2 festgelegten Anforderungen nicht, so verweigert die notifizierte Stelle die Ausstellung einer Unionsbescheinigung über die Bewertung der technischen Dokumentation und informiert den Antragsteller darüber, wobei sie ihre Verweigerung ausführlich begründet.

Erfüllt das KI-System nicht die Anforderung in Bezug auf die verwendeten Trainingsdaten, so muss das KI-System vor der Beantragung einer neuen Konformitätsbewertung erneut trainiert werden. In diesem Fall enthält die begründete Bewertungsentscheidung der notifizierten Stelle, mit der die Ausstellung der Unionsbescheinigung über die Bewertung der technischen Dokumentation verweigert wird, besondere Erläuterungen zu den zum Trainieren des KI-Systems verwendeten Qualitätsdaten und insbesondere zu den Gründen für die Nichtkonformität.

4.7. Jede Änderung des KI-Systems, die sich auf die Konformität des KI-Systems mit den Anforderungen oder auf seine Zweckbestimmung auswirken könnte, bedarf der Bewertung durch die notifizierte Stelle, die die Unionsbescheinigung über die Bewertung der technischen Dokumentation ausgestellt hat. Der Anbieter informiert die notifizierte Stelle über seine Absicht, eine der oben genannten Änderungen vorzunehmen, oder wenn er auf andere Weise Kenntnis vom Eintreten solcher Änderungen erhält. Die notifizierte Stelle bewertet die beabsichtigten Änderungen und entscheidet, ob diese Änderungen eine neue Konformitätsbewertung gemäß Artikel 43 Absatz 4 erforderlich machen oder ob ein Nachtrag zu der Unionsbescheinigung über die Bewertung der technischen Dokumentation ausgestellt werden könnte. In letzterem Fall bewertet die notifizierte Stelle die Änderungen, teilt dem Anbieter ihre Entscheidung mit und stellt ihm, sofern die Änderungen genehmigt wurden, einen Nachtrag zu der Unionsbescheinigung über die Bewertung der technischen Dokumentation aus.

### 5. Überwachung des genehmigten Qualitätsmanagementsystems

5.1. Mit der unter Nummer 3 genannten Überwachung durch die notifizierte Stelle soll sichergestellt werden, dass der Anbieter sich ordnungsgemäß an die Anforderungen und Bedingungen des genehmigten Qualitätsmanagementsystems hält.

5.2. Zu Bewertungszwecken gewährt der Anbieter der notifizierten Stelle Zugang zu den Räumlichkeiten, in denen die Konzeption, die Entwicklung und das Testen der KI-Systeme stattfindet. Außerdem übermittelt der Anbieter der notifizierten Stelle alle erforderlichen Informationen.

5.3. Die notifizierte Stelle führt regelmäßig Audits durch, um sicherzustellen, dass der Anbieter das Qualitätsmanagementsystem pflegt und anwendet, und übermittelt ihm einen Prüfbericht. Im Rahmen dieser Audits kann die notifizierte Stelle die KI-Systeme, für die eine Unionsbescheinigung über die Bewertung der technischen Dokumentation ausgestellt wurde, zusätzlichen Tests unterziehen.

<a id="annex-viii"></a>
## Anhang VIII – Bei der Registrierung des Hochrisiko-KI-Systems gemäß Artikel 49 bereitzustellende Informationen

### Abschnitt A — Von Anbietern von Hochrisiko-KI-Systemen gemäß Artikel 49 Absatz 1 bereitzustellende Informationen

Für Hochrisiko-KI-Systeme, die gemäß Artikel 49 Absatz 1 zu registrieren sind, werden folgende Informationen bereitgestellt und danach auf dem neuesten Stand gehalten:

- 1. der Name, die Anschrift und die Kontaktdaten des Anbieters;

- 2. bei Vorlage von Informationen durch eine andere Person im Namen des Anbieters: der Name, die Anschrift und die Kontaktdaten dieser Person;

- 3. gegebenenfalls der Name, die Anschrift und die Kontaktdaten des Bevollmächtigten;

- 4. der Handelsname des KI-Systems und etwaige zusätzliche eindeutige Angaben, die die Identifizierung und Rückverfolgbarkeit des KI-Systems ermöglichen;

- 5. eine Beschreibung der Zweckbestimmung des KI-Systems und der durch dieses KI-System unterstützten Komponenten und Funktionen;

- 6. eine grundlegende und knappe Beschreibung der vom System verwendeten Informationen (Daten, Eingaben) und seiner Betriebslogik;

- 7. der Status des KI-Systems (in Verkehr/in Betrieb; nicht mehr in Verkehr/in Betrieb, zurückgerufen);

- 8. die Art, die Nummer und das Ablaufdatum der von der notifizierten Stelle ausgestellten Bescheinigung und gegebenenfalls Name oder Identifizierungsnummer dieser notifizierten Stelle;

- 9. gegebenenfalls eine gescannte Kopie der in Nummer 8 genannten Bescheinigung;

- 10. alle Mitgliedstaaten, in denen das KI-System in Verkehr gebracht, in Betrieb genommen oder in der Union bereitgestellt wurde;

- 11. eine Kopie der in Artikel 47 genannten EU-Konformitätserklärung;

- 12. elektronische Betriebsanleitungen; dies gilt nicht für Hochrisiko-KI-Systeme in den Bereichen Strafverfolgung oder Migration, Asyl und Grenzkontrolle gemäß Anhang III Nummern 1, 6 und 7;

- 13. Eine URL-Adresse für zusätzliche Informationen (fakultativ).

### Abschnitt B — Von Anbietern von Hochrisiko-KI-Systemen gemäß Artikel 49 Absatz 2 bereitzustellende Informationen

Für KI-Systeme, die gemäß Artikel 49 Absatz 2 zu registrieren sind, werden folgende Informationen bereitgestellt und danach auf dem neuesten Stand gehalten:

- 1. der Name, die Anschrift und die Kontaktdaten des Anbieters;

- 2. bei Vorlage von Informationen durch eine andere Person im Namen des Anbieters: Name, Anschrift und Kontaktdaten dieser Person;

- 3. gegebenenfalls der Name, die Anschrift und die Kontaktdaten des Bevollmächtigten;

- 4. der Handelsname des KI-Systems und etwaige zusätzliche eindeutige Angaben, die die Identifizierung und Rückverfolgbarkeit des KI-Systems ermöglichen;

- 5. eine Beschreibung der Zweckbestimmung des KI-Systems;

- 6. die Bedingung oder Bedingungen gemäß Artikel 6 Absatz 3, aufgrund derer das KI-System nicht als Hoch-Risiko-System eingestuft wird;

▼M1 —————

▼B

- 8. der Status des KI-Systems (in Verkehr/in Betrieb; nicht mehr in Verkehr/in Betrieb, zurückgerufen).

▼M1 —————

▼B

### Abschnitt C — Von Betreibern von Hochrisiko-KI-Systemen gemäß Artikel 49 Absatz 3 bereitzustellende Informationen

Für Hochrisiko-KI-Systeme, die gemäß Artikel 49 Absatz 3 zu registrieren sind, werden folgende Informationen bereitgestellt und danach auf dem neuesten Stand gehalten:

- 1. der Name, die Anschrift und die Kontaktdaten des Betreibers;

- 2. der Name, die Anschrift und die Kontaktdaten der Person, die im Namen des Betreibers Informationen übermittelt;

- 3. die URL des Eintrags des KI-Systems in der EU-Datenbank durch seinen Anbieter;

- 4. eine Zusammenfassung der Ergebnisse der gemäß Artikel 27 durchgeführten Grundrechte-Folgenabschätzung;

- 5. gegebenenfalls eine Zusammenfassung der im Einklang mit Artikel 35 der Verordnung (EU) 2016/679 oder Artikel 27 der Richtlinie (EU) 2016/680 gemäß Artikel 26 Absatz 8 der vorliegenden Verordnung durchgeführten Datenschutz-Folgenabschätzung.

<a id="annex-ix"></a>
## Anhang IX – Bezüglich Tests unter Realbedingungen gemäß Artikel 60 bei der Registrierung von in Anhang III aufgeführten Hochrisiko-KI-Systemen bereitzustellende Informationen

Bezüglich Tests unter Realbedingungen, die gemäß Artikel 60 zu registrieren sind, werden folgende Informationen bereitgestellt und danach auf dem aktuellen Stand gehalten:

- 1. eine unionsweit einmalige Identifizierungsnummer des Tests unter Realbedingungen;

- 2. der Name und die Kontaktdaten des Anbieters oder zukünftigen Anbieters und der Betreiber, die an dem Test unter Realbedingungen teilgenommen haben;

- 3. eine kurze Beschreibung des KI-Systems, seine Zweckbestimmung und sonstige zu seiner Identifizierung erforderliche Informationen;

- 4. eine Übersicht über die Hauptmerkmale des Plans für den Test unter Realbedingungen;

- 5. Informationen über die Aussetzung oder den Abbruch des Tests unter Realbedingungen.

<a id="annex-x"></a>
## Anhang X – Rechtsvorschriften der Union über IT-Großsysteme im Raum der Freiheit, der Sicherheit und des Rechts

### 1. Schengener Informationssystem

- a) Verordnung (EU) 2018/1860 des Europäischen Parlaments und des Rates vom 28. November 2018 über die Nutzung des Schengener Informationssystems für die Rückkehr illegal aufhältiger Drittstaatsangehöriger (ABl. L 312 vom 7.12.2018, S. 1)

- b) Verordnung (EU) 2018/1861 des Europäischen Parlaments und des Rates vom 28. November 2018 über die Einrichtung, den Betrieb und die Nutzung des Schengener Informationssystems (SIS) im Bereich der Grenzkontrollen, zur Änderung des Übereinkommens zur Durchführung des Übereinkommens von Schengen und zur Änderung und Aufhebung der Verordnung (EG) Nr. 1987/2006 (ABl. L 312 vom 7.12.2018, S. 14)

- c) Verordnung (EU) 2018/1862 des Europäischen Parlaments und des Rates vom 28. November 2018 über die Einrichtung, den Betrieb und die Nutzung des Schengener Informationssystems (SIS) im Bereich der polizeilichen Zusammenarbeit und der justiziellen Zusammenarbeit in Strafsachen, zur Änderung und Aufhebung des Beschlusses 2007/533/JI des Rates und zur Aufhebung der Verordnung (EG) Nr. 1986/2006 des Europäischen Parlaments und des Rates und des Beschlusses 2010/261/EU der Kommission (ABl. L 312 vom 7.12.2018, S. 56)

### 2. Visa-Informationssystem

- a) Verordnung (EU) 2021/1133 des Europäischen Parlaments und des Rates vom 7. Juli 2021 zur Änderung der Verordnungen (EU) Nr. 603/2013, (EU) 2016/794, (EU) 2018/1862, (EU) 2019/816 und (EU) 2019/818 hinsichtlich der Festlegung der Voraussetzungen für den Zugang zu anderen Informationssystemen der EU für Zwecke des Visa-Informationssystems (ABl. L 248 vom 13.7.2021, S. 1)

- b) Verordnung (EU) 2021/1134 des Europäischen Parlaments und des Rates vom 7. Juli 2021 zur Änderung der Verordnungen (EG) Nr. 767/2008, (EG) Nr. 810/2009, (EU) 2016/399, (EU) 2017/2226, (EU) 2018/1240, (EU) 2018/1860, (EU) 2018/1861, (EU) 2019/817 und (EU) 2019/1896 des Europäischen Parlaments und des Rates und zur Aufhebung der Entscheidung 2004/512/EG und des Beschlusses 2008/633/JI des Rates zum Zwecke der Reform des Visa-Informationssystems (ABl. L 248 vom 13.7.2021, S. 11)

### 3. Eurodac

Verordnung (EU) 2024/1358 des Europäischen Parlaments und des Rates vom 14. Mai 2024 über die Einrichtung von Eurodac für den Abgleich biometrischer Daten zum Zwecke der effektiven Anwendung der Verordnungen (EU) 2024/1315 und (EU) 2024/1350 des Europäischen Parlaments und des Rates und der Richtlinie 2001/55/EG des Rates und zur Feststellung der Identität illegal aufhältiger Drittstaatsangehöriger und Staatenloser und über der Gefahrenabwehr und Strafverfolgung dienende Anträge der Gefahrenabwehr- und Strafverfolgungsbehörden der Mitgliedstaaten und Europols auf den Abgleich mit Eurodac-Daten sowie zur Änderung der Verordnungen (EU) 2018/1240 und (EU) 2019/818 des Europäischen Parlaments und des Rates und zur Aufhebung der Verordnung (EU) Nr. 603/2013 des Europäischen Parlaments und des Rates (ABl. L, 2024/1358, 22.5.2024, ELI: http://data.europa.eu/eli/reg/2024/1358/oj)

### 4. Einreise-/Ausreisesystem

Verordnung (EU) 2017/2226 des Europäischen Parlaments und des Rates vom 30. November 2017 über ein Einreise-/Ausreisesystem (EES) zur Erfassung der Ein- und Ausreisedaten sowie der Einreiseverweigerungsdaten von Drittstaatsangehörigen an den Außengrenzen der Mitgliedstaaten und zur Festlegung der Bedingungen für den Zugang zum EES zu Gefahrenabwehr- und Strafverfolgungszwecken und zur Änderung des Übereinkommens von Schengen sowie der Verordnungen (EG) Nr. 767/2008 und (EU) Nr. 1077/2011 (ABl. L 327 vom 9.12.2017, S. 20)

### 5. Europäisches Reiseinformations- und -genehmigungssystem

- a) Verordnung (EU) 2018/1240 des Europäischen Parlaments und des Rates vom 12. September 2018 über die Einrichtung eines Europäischen Reiseinformations- und -genehmigungssystems (ETIAS) und zur Änderung der Verordnungen (EU) Nr. 1077/2011, (EU) Nr. 515/2014, (EU) 2016/399, (EU) 2016/1624 und (EU) 2017/2226 (ABl. L 236 vom 19.9.2018, S. 1)

- b) Verordnung (EU) 2018/1241 des Europäischen Parlaments und des Rates vom 12. September 2018 zur Änderung der Verordnung (EU) 2016/794 für die Zwecke der Einrichtung eines Europäischen Reiseinformations- und -genehmigungssystems (ETIAS) (ABl. L 236 vom 19.9.2018, S. 72)

### 6. Europäisches Strafregisterinformationssystem über Drittstaatsangehörige und Staatenlose

Verordnung (EU) 2019/816 des Europäischen Parlaments und des Rates vom 17. April 2019 zur Einrichtung eines zentralisierten Systems für die Ermittlung der Mitgliedstaaten, in denen Informationen zu Verurteilungen von Drittstaatsangehörigen und Staatenlosen (ECRIS-TCN) vorliegen, zur Ergänzung des Europäischen Strafregisterinformationssystems und zur Änderung der Verordnung (EU) 2018/1726 (ABl. L 135 vom 22.5.2019, S. 1)

### 7. Interoperabilität

- a) Verordnung (EU) 2019/817 des Europäischen Parlaments und des Rates vom 20. Mai 2019 zur Errichtung eines Rahmens für die Interoperabilität zwischen EU-Informationssystemen in den Bereichen Grenzen und Visa und zur Änderung der Verordnungen (EG) Nr. 767/2008, (EU) 2016/399, (EU) 2017/2226, (EU) 2018/1240, (EU) 2018/1726 und (EU) 2018/1861 des Europäischen Parlaments und des Rates, der Entscheidung 2004/512/EG des Rates und des Beschlusses 2008/633/JI des Rates (ABl. L 135 vom 22.5.2019, S. 27)

- b) Verordnung (EU) 2019/818 des Europäischen Parlaments und des Rates vom 20. Mai 2019 zur Errichtung eines Rahmens für die Interoperabilität zwischen EU-Informationssystemen (polizeiliche und justizielle Zusammenarbeit, Asyl und Migration) und zur Änderung der Verordnungen (EU) 2018/1726, (EU) 2018/1862 und (EU) 2019/816 (ABl. L 135 vom 22.5.2019, S. 85).

<a id="annex-xi"></a>
## Anhang XI – Technische Dokumentation gemäß Artikel 53 Absatz 1 Buchstabe a — technische Dokumentation für Anbieter von KI-Modellen mit allgemeinem Verwendungszweck

### Abschnitt 1

### Von allen Anbietern von KI-Modellen mit allgemeinem Verwendungszweck bereitzustellende Informationen

Die in Artikel 53 Absatz 1 Buchstabe a genannte technische Dokumentation muss mindestens die folgenden Informationen enthalten, soweit es anhand der Größe und des Risikoprofils des betreffenden Modells angemessen ist:

- 1. Eine allgemeine Beschreibung des KI-Modells einschließlich

  - a) der Aufgaben, die das Modell erfüllen soll, sowie der Art und des Wesens der KI-Systeme, in die es integriert werden kann;

  - b) die anwendbaren Regelungen der akzeptablen Nutzung;

  - c) das Datum der Freigabe und die Vertriebsmethoden;

  - d) die Architektur und die Anzahl der Parameter;

  - e) die Modalität (zum Beispiel Text, Bild) und das Format der Ein- und Ausgaben;

  - f) die Lizenz.

- 2. Eine ausführliche Beschreibung der Elemente des Modells gemäß Nummer 1 und relevante Informationen zum Entwicklungsverfahren, einschließlich der folgenden Elemente:

  - a) die technischen Mittel (zum Beispiel Betriebsanleitungen, Infrastruktur, Instrumente), die für die Integration des KI-Modells mit allgemeinem Verwendungszweck in KI-Systeme erforderlich sind;

  - b) die Entwurfsspezifikationen des Modells und des Trainingsverfahrens einschließlich Trainingsmethoden und -techniken, die wichtigsten Entwurfsentscheidungen mit den Gründen und getroffenen Annahmen; gegebenenfalls, was das Modell optimieren soll und welche Bedeutung den verschiedenen Parametern dabei zukommt;

  - c) gegebenenfalls Informationen über die für das Trainieren, Testen und Validieren verwendeten Daten, einschließlich der Art und Herkunft der Daten und der Aufbereitungsmethoden (zum Beispiel Bereinigung, Filterung usw.), der Zahl der Datenpunkte, ihres Umfangs und ihrer Hauptmerkmale; gegebenenfalls die Art und Weise, wie die Daten erlangt und ausgewählt wurden, sowie alle anderen Maßnahmen zur Feststellung, ob Datenquellen ungeeignet sind, und Methoden zur Erkennung ermittelbarer Verzerrungen;

  - d) die für das Trainieren des Modells verwendeten Rechenressourcen (zum Beispiel Anzahl der Gleitkommaoperationen), die Trainingszeit und andere relevante Einzelheiten im Zusammenhang mit dem Trainieren;

  - e) bekannter oder geschätzter Energieverbrauch des Modells.

  Wenn der Energieverbrauch des Modells nicht bekannt ist, kann für Buchstabe e der Energieverbrauch auf Informationen über die eingesetzten Rechenressourcen gestützt werden.

### Abschnitt 2

### Zusätzliche von Anbietern von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko bereitzustellende Informationen

1. Eine ausführliche Beschreibung der Prüfstrategien, einschließlich der Prüfungsergebnisse, auf der Grundlage öffentlich verfügbarer Prüfprotokolle und -instrumente oder anderer Prüfmethoden. Die Prüfstrategien umfassen Prüfkriterien und -metrik sowie die Methodik zur Ermittlung von Einschränkungen.

2. Gegebenenfalls eine ausführliche Beschreibung der Maßnahmen, die ergriffen wurden, um interne und/oder externe Angriffstests durchzuführen (zum Beispiel Red Teaming), Modellanpassungen, einschließlich Ausrichtung und Feinabstimmung.

3. Gegebenenfalls eine ausführliche Beschreibung der Systemarchitektur, aus der hervorgeht, wie Softwarekomponenten aufeinander aufbauen oder einander zuarbeiten und in die Gesamtverarbeitung integriert sind.

<a id="annex-xii"></a>
## Anhang XII – Transparenzinformationen gemäß Artikel 53 Absatz 1 Buchstabe b — technische Dokumentation für Anbieter von KI-Modellen mit allgemeinem Verwendungszweck für nachgelagerte Anbieter, die das Modell in ihr KI-System integrieren

Die in Artikel 53 Absatz 1 Buchstabe b genannten Informationen enthalten mindestens Folgendes:

- 1. eine allgemeine Beschreibung des KI-Modells einschließlich

  - a) der Aufgaben, die das Modell erfüllen soll, sowie der Art und des Wesens der KI-Systeme, in die es integriert werden kann;

  - b) die anwendbaren Regelungen der akzeptablen Nutzung;

  - c) das Datum der Freigabe und die Vertriebsmethoden;

  - d) gegebenenfalls wie das Modell mit Hardware oder Software interagiert, die nicht Teil des Modells selbst ist, oder wie es zu einer solchen Interaktion verwendet werden kann;

  - e) gegebenenfalls die Versionen der einschlägigen Software im Zusammenhang mit der Verwendung des KI-Modells mit allgemeinem Verwendungszweck;

  - f) die Architektur und die Anzahl der Parameter;

  - g) die Modalität (zum Beispiel Text, Bild) und das Format der Ein- und Ausgaben;

  - h) die Lizenz für das Modell.

- 2. Eine Beschreibung der Bestandteile des Modells und seines Entwicklungsprozesses, einschließlich

  - a) die technischen Mittel (zum Beispiel Betriebsanleitungen, Infrastruktur, Instrumente), die für die Integration des KI-Modells mit allgemeinem Verwendungszweck in KI-Systeme erforderlich sind;

  - b) Modalität (zum Beispiel Text, Bild usw.) und Format der Ein- und Ausgaben und deren maximale Größe (zum Beispiel Länge des Kontextfensters usw.);

  - c) gegebenenfalls Informationen über die für das Trainieren, Testen und Validieren verwendeten Daten, einschließlich der Art und Herkunft der Daten und der Aufbereitungsmethoden.

<a id="annex-xiii"></a>
## Anhang XIII – Kriterien für die Benennung von KI-Modellen mit allgemeinem Verwendungszweck mit systemischem Risiko gemäß Artikel 51

Um festzustellen, ob ein KI-Modell mit allgemeinem Verwendungszweck über Fähigkeiten oder eine Wirkung verfügt, die den in Artikel 51 Absatz 1 Buchstabe a genannten gleichwertig sind, berücksichtigt die Kommission folgende Kriterien:

- a) die Anzahl der Parameter des Modells;

- b) die Qualität oder Größe des Datensatzes, zum Beispiel durch Tokens gemessen;

- c) die Menge der für das Trainieren des Modells verwendeten Berechnungen, gemessen in Gleitkommaoperationen oder anhand einer Kombination anderer Variablen, wie geschätzte Trainingskosten, geschätzter Zeitaufwand für das Trainieren oder geschätzter Energieverbrauch für das Trainieren;

- d) die Ein- und Ausgabemodalitäten des Modells, wie Text-Text (Große Sprachmodelle), Text-Bild, Multimodalität, Schwellenwerte auf dem Stand der Technik für die Bestimmung der Fähigkeiten mit hoher Wirkkraft für jede Modalität und die spezifische Art der Ein- und Ausgaben (zum Beispiel biologische Sequenzen);

- e) die Benchmarks und Beurteilungen der Fähigkeiten des Modells, einschließlich unter Berücksichtigung der Zahl der Aufgaben ohne zusätzliches Training, der Anpassungsfähigkeit zum Erlernen neuer, unterschiedlicher Aufgaben, des Grades an Autonomie und Skalierbarkeit sowie der Instrumente, zu denen es Zugang hat;

- f) ob es aufgrund seiner Reichweite große Auswirkungen auf den Binnenmarkt hat — davon wird ausgegangen, wenn es mindestens 10 000 in der Union niedergelassenen registrierten gewerblichen Nutzern zur Verfügung gestellt wurde;

- g) die Zahl der registrierten Endnutzer.

▼M1

<a id="annex-xiv"></a>
## Anhang XIV

Verzeichnis der Codes, Kategorien und entsprechenden Arten von KI-Systemen für die Zwecke des Notifizierungsverfahrens gemäß Artikel 30 mit Angabe des Geltungsbereichs der Benennung als notifizierte Stellen

### 1. Einleitung

Die Konformitätsbewertung von Hochrisiko-KI-Systemen gemäß dieser Verordnung kann die Einbeziehung von Konformitätsbewertungsstellen erfordern. Nur Konformitätsbewertungsstellen, die gemäß dieser Verordnung benannt wurden, dürfen Konformitätsbewertungen durchführen, und dies nur für die Tätigkeiten in Bezug auf die betreffenden Arten von KI-Systemen. In dem Verzeichnis der Codes, Kategorien und entsprechenden Arten von KI-Systemen wird der Geltungsbereich der Benennung der gemäß Artikel 30 notifizierten Konformitätsbewertungsstellen festgelegt.

### 2. Liste der Codes, Kategorien und entsprechenden Arten von KI-Systemen

#### a) KI-Systeme, die unter Anhang I fallen

| AIA-Code |  |
| --- | --- |
| AIP 0102 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 2 fallen |
| AIP 0103 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 3 fallen |
| AIP 0104 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 4 fallen |
| AIP 0105 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 5 fallen |
| AIP 0106 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 6 fallen |
| AIP 0107 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 7 fallen |
| AIP 0108 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 8 fallen |
| AIP 0109 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 9 fallen |
| AIP 0110 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 10 fallen |
| AIP 0111 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 11 fallen |
| AIP 0112 | KI-Systeme, die unter Anhang I Abschnitt A Nummer 12 fallen |

#### b) KI-Systeme, die unter Anhang III Nummer 1 fallen

| AIA-Code |  |
| --- | --- |
| AIB 0201 | Biometrische Fernidentifizierungssysteme |
| AIB 0202 | KI-Systeme zur biometrischen Kategorisierung |
| AIB 0203 | KI-Systeme zur Emotionserkennung |

### 3. KI-technologiespezifische Codes

#### a) Symbolische KI und Expertensysteme

| AIA-Code |  |
| --- | --- |
| AIH 0101 | KI-Systeme, die auf symbolischer KI, Experten- und wissensgestützten Systemen beruhen, und KI-Systeme, die auf Suche und Optimierung beruhen |

#### b) Maschinelles Lernen, mit Ausnahme von generativer KI und von KI mit allgemeinem Verwendungszweck

| AIA-Code |  |
| --- | --- |
| AIH 0201 | KI-Systeme, die strukturierte Daten verarbeiten |
| AIH 0202 | KI-Systeme, die Signal- und Audiodaten verarbeiten |
| AIH 0203 | KI-Systeme, die Textdaten verarbeiten |
| AIH 0204 | KI-Systeme, die Bild- und Videodaten verarbeiten |
| AIH 0205 | KI-Systeme, die von ihrer Umgebung lernen, mit Ausnahme von KI-Systemen, die unter AIH 0401 fallen |

#### c) KI- Systeme, die auf KI-Modellen mit allgemeinem Verwendungszweck oder generativer KI beruhen

| AIA-Code |  |
| --- | --- |
| AIH 0301 | generative KI-Systeme, einschließlich KI-Systemen, die auf KI-Modellen mit allgemeinem Verwendungszweck beruhen |

#### d) Neue KI-Technologien

| AIA-Code |  |
| --- | --- |
| AIH 0401 | KI-Systeme, die auf anderen neuen KI-Technologien beruhen, die nicht unter andere Codes fallen, einschließlich agentischer KI |

### 4. Antrag auf Benennung

Konformitätsbewertungsstellen verwenden das Verzeichnis der Codes, Kategorien und entsprechenden Arten von KI-Systemen aus diesem Anhang, wenn sie die Arten von KI-Systemen in dem in Artikel 29 genannten Antrag auf Benennung angeben.

<a id="notes"></a>
## Fußnoten

(1) Verordnung (EU) Nr. 1025/2012 des Europäischen Parlaments und des Rates vom 25. Oktober 2012 zur europäischen Normung, zur Änderung der Richtlinien 89/686/EWG und 93/15/EWG des Rates sowie der Richtlinien 94/9/EG, 94/25/EG, 95/16/EG, 97/23/EG, 98/34/EG, 2004/22/EG, 2007/23/EG, 2009/23/EG und 2009/105/EG des Europäischen Parlaments und des Rates und zur Aufhebung des Beschlusses 87/95/EWG des Rates und des Beschlusses Nr. 1673/2006/EG des Europäischen Parlaments und des Rates (ABl. L 316 vom 14.11.2012, S. 12, ELI: http://data.europa.eu/eli/reg/2012/1025/oj).

(2) Richtlinie (EU) 2016/943 des Europäischen Parlaments und des Rates vom 8. Juni 2016 über den Schutz vertraulichen Know-hows und vertraulicher Geschäftsinformationen (Geschäftsgeheimnisse) vor rechtswidrigem Erwerb sowie rechtswidriger Nutzung und Offenlegung (ABl. L 157 vom 15.6.2016, S. 1).

(3) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(4) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(5) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(6) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(7) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(8) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(9) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(10) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj).“

(11) Richtlinie (EU) 2020/1828 des Europäischen Parlaments und des Rates vom 25. November 2020 über Verbandsklagen zum Schutz der Kollektivinteressen der Verbraucher und zur Aufhebung der Richtlinie 2009/22/EG (ABl. L 409 vom 4.12.2020, S. 1).
