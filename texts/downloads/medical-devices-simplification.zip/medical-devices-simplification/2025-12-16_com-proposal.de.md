---
act: medical-devices-simplification
version: 2025-12-16_com-proposal
stage: com-proposal
language: de
celex: 52025PC1023
title: Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Änderung der Verordnungen (EU) 2017/745 und (EU) 2017/746 zwecks Vereinfachung der Vorschriften über Medizinprodukte und In-vitro-Diagnostika und Reduzierung des mit ihnen verbundenen Aufwands sowie zur Änderung der Verordnung (EU) 2022/123 hinsichtlich der Unterstützung der Expertengremien für Medizinprodukte durch die Europäische Arzneimittel-Agentur und zur Änderung der Verordnung (EU) 2024/1689 hinsichtlich der in ihrem Anhang I enthaltenen Liste der Harmonisierungsrechtsvorschriften der Union
retrieved: '2026-09-24'
converter: tools/eurlex2md.py
counts:
  recitals: 59
  articles: 9
  annexes: 2
official_source: https://eur-lex.europa.eu/legal-content/DE/TXT/?uri=CELEX:52025PC1023
reuse: '© European Union, EUR-Lex. Reuse: Commission Decision 2011/833/EU, Article 6.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
---


# Vorschlag für eine VERORDNUNG DES EUROPÄISCHEN PARLAMENTS UND DES RATES zur Änderung der Verordnungen (EU) 2017/745 und (EU) 2017/746 zwecks Vereinfachung der Vorschriften über Medizinprodukte und In-vitro-Diagnostika und Reduzierung des mit ihnen verbundenen Aufwands sowie zur Änderung der Verordnung (EU) 2022/123 hinsichtlich der Unterstützung der Expertengremien für Medizinprodukte durch die Europäische Arzneimittel-Agentur und zur Änderung der Verordnung (EU) 2024/1689 hinsichtlich der in ihrem Anhang I enthaltenen Liste der Harmonisierungsrechtsvorschriften der Union

<a id="begr-ndung"></a>
## BEGRÜNDUNG

### 1. KONTEXT DES VORSCHLAGS

#### • Gründe und Ziele des Vorschlags

Der Medizinproduktesektor ist in Europa ein äußerst vielfältiger und innovativer Motor für wirtschaftliches Wachstum. Der Sektor spielt eine Schlüsselrolle bei der Stärkung der Wettbewerbsfähigkeit der Europäischen Union sowie bei der Sicherstellung der Funktionsfähigkeit der Gesundheitssysteme der Mitgliedstaaten und letztlich bei der Gewährleistung eines hohen Maß an Schutz der öffentlichen Gesundheit. Ein Medizinprodukt kann jedes Instrument, jeder Apparat, jedes Gerät, jede Software, jedes Implantat, jedes Reagenz zur In-vitro-Verwendung oder jedes andere Material oder jeder andere Gegenstand sein, der vom Hersteller dazu bestimmt ist, allein oder in Kombination mit anderen Materialien oder Gegenständen bei Menschen zu medizinischen Zwecken verwendet zu werden, z. B. zur Diagnose, Behandlung, Linderung, Verhütung, Überwachung, Vorhersage oder Prognose einer Krankheit, einer Verletzung oder eines sonstigen Zustands.

Medizinprodukte umfassen eine breite Palette von Erzeugnissen, wie etwa Heftpflaster, Spritzen, chirurgische Masken, Brillen, Rollstühle, medizinische Apps, Körperscanner sowie implantierbare Produkte wie Herzklappen, Herzschrittmacher oder Knie- und Hüftgelenkersatz. Beispiele für In-vitro-Diagnostika (IVD) sind Influenza- oder COVID-19-Tests, HIV-Tests, Genmutationstests oder Blutgruppentests. Nach Angaben der Weltgesundheitsorganisation gibt es auf dem Weltmarkt schätzungsweise 2 000 000 verschiedene Arten von Medizinprodukten, die zu mehr als 7 000 generischen Produktgruppen^(1) gehören. In Europa gibt es mehr als 38 000 Medizintechnikunternehmen. Kleine und mittlere Unternehmen (KMU) machen rund 90 % der Branche aus; bei den meisten handelt es sich um kleine und Kleinstunternehmen, die weniger als 50 Personen beschäftigen. Insgesamt sind in der Medizintechnikbranche in Europa mehr als 930 000 Menschen beschäftigt. Der europäische Markt für Medizintechnik wurde im Jahr 2024 auf rund 170 Mrd. EUR geschätzt^(2).

Die Verordnung (EU) 2017/745 über Medizinprodukte (im Folgenden „Verordnung über Medizinprodukte“ oder „MP-VO“)^(3) und die Verordnung (EU) 2017/746 über In-vitro-Diagnostika (im Folgenden „Verordnung über In-vitro-Diagnostika“ oder „IVD-VO“)^(4) des Europäischen Parlaments und des Rates (im Folgenden zusammen „Verordnungen“) schaffen einen verstärkten Rechtsrahmen für Medizinprodukte und In-vitro-Diagnostika („IVD“). Wie in ihren ersten beiden Erwägungsgründen dargelegt, zielen die MP-VO und die IVD-VO darauf ab, einen robusten, transparenten, vorhersehbaren und nachhaltigen Rechtsrahmen für Medizinprodukte und In-vitro-Diagnostika zu schaffen, der ein hohes Maß an Sicherheit und Gesundheit gewährleistet und zugleich Innovationen unterstützt. Diese Verordnungen zielen darauf ab, das reibungslose Funktionieren des Binnenmarkts zu gewährleisten, wobei ein hohes Schutzniveau für die Gesundheit von Patienten und Anwendern zugrunde gelegt wird und die in diesem Sektor tätigen KMU berücksichtigt werden.

Um diese Ziele zu erreichen und Probleme im Zusammenhang mit den zuvor geltenden Rechtsvorschriften anzugehen, sind in den Verordnungen unter anderem strengere Anforderungen an den Umfang der klinischen Nachweise festgelegt, die von den Herstellern zu erheben sind, um die Konformität ihrer Produkte mit den einschlägigen Vorschriften nachzuweisen. Die Verordnungen sehen auch ein robusteres System der Konformitätsbewertung vor, um die Qualität, Sicherheit und Leistung der in der EU in Verkehr gebrachten Produkte zu überprüfen. Nach der MP-VO und der IVD-VO werden Produkte je nach ihrer Zweckbestimmung und den ihnen innewohnenden Risiken in vier Risikoklassen^(5) eingeteilt. Abhängig von der Risikoklasse des Produkts muss der Hersteller vor dem Anbringen der CE-Kennzeichnung und dem Inverkehrbringen des Produkts eine unabhängige Konformitätsbewertungsstelle (im Folgenden „Benannte Stelle“) in das Konformitätsbewertungsverfahren einbeziehen. Als die MP-VO und die IVD-VO in Kraft traten, war die Zahl der Benannten Stellen sehr gering, was zu Engpässen im vorgeschriebenen Zertifizierungsverfahren vor dem Inverkehrbringen führte. Bislang wurden 51 Benannte Stellen gemäß MP-VO und 19 Benannte Stellen gemäß IVD-VO benannt.

Die Verordnung über Medizinprodukte trat am 26. Mai 2021^(6) und die Verordnung über In-vitro-Diagnostika am 26. Mai 2022 in Kraft. Die durch die Verordnungen eingeführten deutlich strengeren Anforderungen, die auch für bestehende Produkte gelten, die begrenzten Zertifizierungskapazitäten der Benannten Stellen sowie die unzureichende Vorbereitung der Hersteller bargen das Risiko von Versorgungsengpässen und des Verschwindens kritischer Produkte vom Markt. Daher wurde der in Artikel 120 der MP-VO festgelegte Übergangszeitraum durch die Verordnung (EU) 2023/607^(7) verlängert und endet, abhängig von der Risikoklasse des Produkts und vorbehaltlich bestimmter Bedingungen, entweder am 31. Dezember 2027 oder am 31. Dezember 2028. Die in Artikel 110 der IVD-VO festgelegten Übergangszeiträume wurden durch die Verordnung (EU) 2022/112^(8) sowie durch die Verordnung (EU) 2024/1860^(9) verlängert; sie enden, abhängig von der Risikoklasse des In-vitro-Diagnostikums und vorbehaltlich bestimmter Bedingungen, die denen der MP-VO ähneln, entweder am 31. Dezember 2027, am 31. Dezember 2028 oder am 31. Dezember 2029.

Die wiederholte Verlängerung der Übergangsfristen war nur eine kurzfristige Lösung, um das Risiko von Engpässen zu mindern. Die zugrunde liegenden strukturellen Probleme bei der Umsetzung der MP-VO und der IVD-VO konnten dadurch nicht behoben werden. Angesichts der zahlreichen Herausforderungen bei der Umsetzung der beiden Verordnungen leitete die Europäische Kommission im Jahr 2024 eine gezielte Bewertung der MP-VO und der IVD-VO ein. Trotz der erheblichen Fortschritte, die bei der praktischen Umsetzung der MP-VO und der IVD-VO erzielt wurden, hat die gezielte Bewertung (die zeitgleich mit diesem Vorschlag abgeschlossen wird) Mängel im Rechtsrahmen aufgezeigt. Diese Schwächen beeinträchtigen die Verfügbarkeit von Produkten und die Wettbewerbsfähigkeit der EU-Hersteller (insbesondere der zahlreichen Kleinstunternehmen sowie kleinen und mittleren Unternehmen) und behindern Innovationen in der Medizintechnik. Dies wiederum wirkt sich negativ auf die Qualität der Gesundheitsversorgung und die Patientensicherheit aus. Die Ergebnisse der gezielten Bewertung werden in Abschnitt 3 dieser Begründung dargelegt.

Der vorliegende Vorschlag zielt darauf ab, den Rechtsrahmen zu straffen und zukunftssicher zu gestalten. Sein Hauptziel besteht darin, die geltenden Vorschriften zu vereinfachen, den Verwaltungsaufwand für die Hersteller zu verringern und die Vorhersehbarkeit sowie die Kosteneffizienz des Zertifizierungsverfahrens durch Benannte Stellen zu verbessern, wobei ein hohes Schutzniveau der öffentlichen Gesundheit und der Patientensicherheit gewahrt bleibt, und so zur Verwirklichung der ursprünglichen Ziele der Verordnungen beiträgt. Die Ziele der MP-VO und der IVD-VO werden weiterhin von allen einschlägigen Akteuren verfolgt. Die nicht ausreichende Vorhersehbarkeit der Dauer des Zertifizierungsverfahrens sowie die unterschiedlichen Praktiken in der gesamten EU beeinträchtigen jedoch weiterhin die Effizienz des Verfahrens zur Erlangung der CE-Kennzeichnung. Zudem sind mehrere Anforderungen der Verordnungen nicht verhältnismäßig im Hinblick auf die tatsächlichen von den Produkten ausgehenden Risiken, was zu unnötig hohen Kosten und Belastungen führt. Übermäßig hohe Anforderungen können Hersteller, insbesondere KMU, dazu veranlassen, die Bereitstellung von Produkten einzustellen oder deren Markteinführung zu verzögern, mit potenziell negativen Folgen für die Patientenversorgung und die öffentliche Gesundheit. Zudem können sie sich nachteilig auf die Wettbewerbsfähigkeit des EU-Marktes für Medizinprodukte im Vergleich zu anderen Rechtsräumen in aller Welt auswirken.

Dieser Vorschlag ist eine Reaktion auf Forderungen des Europäischen Parlaments^(10), mehrerer Mitgliedstaaten^(11) und zahlreicher Interessenträger nach einer Vereinfachung des Rechtsrahmens für Medizinprodukte sowie nach Maßnahmen zur Sicherstellung der Verfügbarkeit von Produkten. Zur Behebung der festgestellten Probleme ist eine neue Verordnung erforderlich, da diese andernfalls erhebliche Auswirkungen auf den Markt für Medizinprodukte und folglich auf die Qualität der Gesundheitsversorgung der Patienten in der EU hätten.

Der Vorschlag zielt darauf ab, das Funktionieren des derzeitigen Rechtsrahmens zu verbessern, insbesondere im Hinblick auf das reibungslose Funktionieren des Binnenmarkts, wobei zugleich ein hohes Maß an Schutz für die Gesundheit der Patienten gewährleistet werden soll. Er baut auf den wesentlichen Merkmalen des bestehenden Rahmens auf, insbesondere auf dem dezentralen Ansatz (bei dem die Zuständigkeiten den Mitgliedstaaten zugewiesen sind) sowie auf der Einbeziehung der Benannten Stellen in das Konformitätsbewertungsverfahren, wie dies auch in anderen auf dem Neuen Rechtsrahmen beruhenden EU-Rechtsvorschriften vorgesehen ist. Ziel ist es jedoch, einen schlankeren und kosteneffizienteren Rechtsrahmen zu schaffen und eine weitere Harmonisierung zu fördern, sodass ein wettbewerbsfähigerer und innovativerer EU-Markt entsteht.

Die Koordinierungsgruppe Medizinprodukte wurde gemäß Artikel 103 der MP-VO eingerichtet, setzt sich aus Vertretern der nationalen zuständigen Behörden zusammen und wird von der Kommission geleitet. In dem Vorschlag wird die Koordinierungsgruppe Medizinprodukte als zentrales Steuerungsgremium beibehalten.

Der Vorschlag stärkt die Koordinierung zwischen den Benannten Stellen durch die Koordinierungsgruppe der Benannten Stellen (im Folgenden „NBCG-Med“), die gemäß Artikel 49 der MP-VO eingerichtet wurde, und schafft eine direkte Berichtspflicht der NBCG-Med gegenüber der Koordinierungsgruppe Medizinprodukte. Während die Benannten Stellen weiterhin in der Zuständigkeit der Mitgliedstaaten verbleiben, zielt der Vorschlag darauf ab, die Aufsicht und die regelmäßige Überwachung der Benannten Stellen durch die Einbeziehung von Sachverständigen der Kommission und anderer Mitgliedstaaten zu verbessern.

Mit der MP-VO wurden Expertengremien^(12) eingeführt, um wissenschaftliche und klinische Beratung zu Medizinprodukten und In-vitro-Diagnostika bereitzustellen sowie Stellungnahmen zu den von den Benannten Stellen erstellten Begutachtungsberichten der klinischen Bewertung bestimmter Hochrisiko-Medizinprodukte und zu den Leistungsbewertungsberichten bestimmter Hochrisiko-In-vitro-Diagnostika abzugeben. Seit 2022 stellt die Europäische Arzneimittel-Agentur (EMA) das Sekretariat für die Expertengremien^(13). Der Vorschlag zielt darauf ab, den Umfang der in den Expertengremien verfügbaren Fachkompetenz zu erweitern und deren beratende Funktion bei regulatorischen Entscheidungsprozessen auszubauen. Darüber hinaus sieht der Vorschlag der Kommission auch eine Unterstützung der zuständigen Behörden durch die EMA vor, um die Koordinierung zwischen ihnen zu verbessern, insbesondere im Hinblick auf Grenzfälle und Klassifizierungsfragen, Abweichungen von den geltenden Konformitätsbewertungsverfahren und gegebenenfalls von weiteren Anforderungen, klinische Bewertungen und Prüfungen sowie die Vigilanz und die Marktüberwachung.

#### • Kohärenz mit den bestehenden Vorschriften in diesem Bereich

Angesichts des dringenden Handlungsbedarfs wird der Vorschlag als unmittelbare Folgemaßnahme zur gezielten Bewertung der MP-VO und der IVD-VO vorgelegt. Er verfolgt ähnliche Ziele wie die im April 2023 angenommenen Vorschläge der Kommission zur Reform der EU-Arzneimittelvorschriften^(14). Die Kohärenz mit den vorgeschlagenen Verordnungen zur Aufhebung und Ersetzung der Richtlinie 2001/83/EG und der Verordnung (EU) Nr. 726/2004 ist gewährleistet. Der vorliegende Vorschlag steht zudem im Einklang mit dem Vorschlag der Kommission für einen Biotech-Rechtsakt^(15), dessen Annahme zeitgleich mit diesem Vorschlag vorgesehen ist und der unter anderem vorgeschlagene Änderungen der Verordnung über klinische Prüfungen^(16) enthält, etwa ein koordiniertes Bewertungsverfahren für kombinierte Studien mit Arzneimitteln, In-vitro-Diagnostika und/oder Medizinprodukten. Mit diesem Vorschlag werden außerdem die einschlägigen Bestimmungen der MP-VO an die neue Verordnung über Substanzen menschlichen Ursprungs (SoHO)^(17) angeglichen.

#### • Kohärenz mit der Politik der Union in anderen Bereichen

Der Vorschlag trägt zur Verwirklichung des Ziels der Kommission bei, die Wettbewerbsfähigkeit der EU zu verbessern, indem die Rahmenbedingungen für Unternehmen erleichtert sowie Forschung und Innovation unterstützt werden. Der Kompass für Wettbewerbsfähigkeit^(18) bekräftigt die Notwendigkeit, das regulatorische Umfeld zu vereinfachen, den Verwaltungsaufwand zu verringern und Innovationen zu fördern, insbesondere in technologiegestützten Sektoren.

Die Mitteilung mit dem Titel „Ein einfacheres und schnelleres Europa“^(19) hat neue Zielvorgaben für den Abbau des Verwaltungsaufwands festgelegt und Prioritäten für neue Vereinfachungsmaßnahmen gesetzt.

Der vorliegende Vorschlag steht auch im Einklang mit der Strategie der Kommission für die europäischen Biowissenschaften^(20), in der darauf hingewiesen wurde, dass die Risiken eines Verlusts an Wettbewerbsfähigkeit gegenüber anderen Regionen insbesondere in Bereichen wie Medizinprodukten besonders hoch sind, da die Rechtsvorschriften nicht ausreichend innovationsfreundlich und zukunftssicher sind und klare Zugangswege zu den Märkten fehlen. Die Kommission hat sich daher verpflichtet, eine Gesetzgebungsinitiative vorzulegen, die ein ausgewogenes Verhältnis zwischen der Vereinfachung der EU-Vorschriften für Medizinprodukte und In-vitro-Diagnostika und dem wirksamen Schutz der Patientensicherheit und der öffentlichen Gesundheit herstellt und dabei auch gesundheitliche Notlagen berücksichtigt.

Der Vorschlag steht im Einklang mit der EU-Politik in den Bereichen Sicherheit, Gesundheit und Umwelt, da er ein hohes Maß an Patientensicherheit und an Schutz der öffentlichen Gesundheit gewährleistet und zugleich übermäßig belastende Anforderungen verringert sowie Verfahren strafft. Der Vorschlag ergänzt die EU-Politik in den Bereichen Binnenmarkt und künstliche Intelligenz, da er regulatorische Instrumente festlegt, die dieselben Ziele verfolgen wie die bestehenden Bestimmungen in diesen Bereichen.

### 2. RECHTSGRUNDLAGE, SUBSIDIARITÄT UND VERHÄLTNISMÄẞIGKEIT

#### • Rechtsgrundlage

Da der Vorschlag zwei bestehende Verordnungen ändert, entspricht seine Rechtsgrundlage derjenigen der zu ändernden Verordnungen, nämlich Artikel 114 und Artikel 168 Absatz 4 Buchstabe c des Vertrags über die Arbeitsweise der Europäischen Union (AEUV). Die für diese Änderungsverordnung vorgeschlagenen Maßnahmen verfolgen das Ziel, das reibungslose Funktionieren des Binnenmarkts im Bereich der Medizinprodukte und der In-vitro-Diagnostika zu erhalten und zu verbessern und zugleich die Leistungsfähigkeit und Sicherheit der Produkte für Patienten und Anwender zu wahren.

#### • Subsidiarität (bei nicht ausschließlicher Zuständigkeit)

Mit der MP-VO und der IVD-VO wurde ein gemeinsamer Rechtsrahmen auf EU-Ebene eingeführt, da die Ziele dieser Verordnungen nicht in ausreichendem Maße durch Maßnahmen auf nationaler Ebene erreicht werden konnten. Diese Ziele bestehen insbesondere darin, ein hohes Schutzniveau für die Gesundheit der Patienten und Anwender sowie das reibungslose Funktionieren des Binnenmarkts zu gewährleisten und potenzielle Marktstörungen zu vermeiden. Zur Bewältigung der festgestellten Probleme wird ein Tätigwerden auf EU-Ebene als weniger kostspielig und effizienter angesehen als nationale Maßnahmen in allen Mitgliedstaaten. Aus diesem Grund müssen die vorgeschlagenen Änderungen der MP-VO und der IVD-VO auf EU-Ebene vorgenommen werden.

#### • Verhältnismäßigkeit

Die vorgeschlagenen Änderungen gehen nicht über das hinaus, was zur Erreichung der Ziele der Vereinfachung und des Abbaus von Belastungen erforderlich ist, um sicherzustellen, dass die Zweckbestimmung beider Verordnungen erreicht werden kann. Diese Zweckbestimmung besteht darin, einen robusten, transparenten, vorhersehbaren und nachhaltigen Rechtsrahmen für Medizinprodukte und In-vitro-Diagnostika zu schaffen, der ein hohes Schutzniveau der öffentlichen Gesundheit und der Patientensicherheit sowie das reibungslose Funktionieren des Binnenmarkts für diese Produkte gewährleistet.

#### • Wahl des Instruments

Die Kommission schlägt eine Verordnung des Europäischen Parlaments und des Rates vor. Dies ist das am besten geeignete Rechtsinstrument, da nur eine Verordnung mit ihrer einheitlichen Anwendung, ihrer Verbindlichkeit und ihrer unmittelbaren Anwendbarkeit den erforderlichen Grad an Einheitlichkeit gewährleisten kann, der zur Verbesserung des Funktionierens des Binnenmarkts im Bereich der Medizinprodukte und der In-vitro-Diagnostika erforderlich ist.

### 3. ERGEBNISSE DER EX-POST-BEWERTUNG, DER KONSULTATION DER INTERESSENTRÄGER UND DER FOLGENABSCHÄTZUNG

#### • Ex-post-Bewertung / Eignungsprüfungen bestehender Rechtsvorschriften

Die Kommission hat kürzlich eine gezielte Bewertung der Verordnungen abgeschlossen^(21). Dieser Vorschlag stützt sich auf die Ergebnisse der Bewertung.

Insgesamt ergab die Bewertung, dass der Nutzen der Verordnungen für Patienten und Gesundheitssysteme darin besteht, dass sie die Sicherheit und Leistungsfähigkeit der Produkte stärken und die Transparenz erhöhen. Diese Erfolge gehen jedoch mit hohen und häufig nicht verhältnismäßigen Kosten für die Einhaltung der Vorschriften einher, die auch durch die hohe regulatorische Komplexität verursacht werden.

Die Bewertung ergab, dass die Verordnungen den Rechtsrahmen durch strengere Anforderungen an die Benennung und Beaufsichtigung der Benannten Stellen, die Durchführung von Konformitätsbewertungsverfahren sowie die Gewinnung klinischer Nachweise gestärkt haben. Die drei Dimensionen sind jedoch eng miteinander verknüpft, und Schwächen in einem Bereich wirken sich auf das gesamte System aus. Ein fragmentierter und langwieriger Benennungsprozess verringert die verfügbare Kapazität und führt zu Inkonsistenzen bei der Aufsicht, was wiederum zu divergierenden Konformitätsbewertungspraktiken beiträgt. Gleichzeitig verlängern unvollständige oder uneinheitlich bewertete klinische Nachweise die Bewertungsverfahren und untergraben die Vorhersehbarkeit, während sie zugleich die Möglichkeit einschränken, nachzuweisen, dass die Sicherheitsziele der Verordnungen erreicht werden. Obwohl Fortschritte erkennbar sind, führt die kombinierte Wirkung von Kapazitätsengpässen, fragmentierter Aufsicht und uneinheitlichen Anforderungen an die Nachweise dazu, dass Effizienz, Harmonisierung und Wirksamkeit weiterhin hinter den Erwartungen zurückbleiben. Dies hat zu einer wahrgenommenen Unvorhersehbarkeit und Unverhältnismäßigkeit des Rechtsrahmens geführt und untergräbt das Vertrauen der Interessenträger in das System. Genauer gesagt zeigt die Bewertung, dass dies zu einem Rückgang der Verfügbarkeit bestimmter Produkte (z. B. innovativer und Nischenprodukte) führt, was sich negativ auf den Schutz der Patienten und die Wettbewerbsfähigkeit des Industriezweigs auswirkt.

Die Bewertung hebt mehrere Mängel und Ineffizienzen im derzeitigen Rechtsrahmen hervor, insbesondere im Hinblick auf die Vereinfachung und die Straffung der Verfahren. Ein fragmentierter und nicht harmonisierter Rechtsrahmen hat zu mehreren Ineffizienzen und unnötigen Belastungen für die Interessenträger geführt, die eine stärker zentralisierte Leitungsstruktur fordern. Ein unerwarteter Anstieg des Verwaltungsaufwands scheint aus redundanten Berichtspflichten und unnötigen Arbeitsdoppelungen zu resultieren und stellt für die Interessenträger erhebliche Herausforderungen dar. Die Unvorhersehbarkeit und Unverhältnismäßigkeit des Systems verschärfen diese Bedenken zusätzlich, insbesondere für Wirtschaftsakteure, die Klarheit und Kohärenz der Anforderungen anstreben, um Innovationen zu fördern, ohne die Sicherheit zu beeinträchtigen. Darüber hinaus werden digitale Lösungen häufig als potenzielle Ansatzpunkte genannt, um einen Teil dieser Belastungen zu mindern, die Effizienz zu steigern und Ressourcenengpässe zu verringern. Die festgestellte Fragmentierung der Leitungsstrukturen, sich überschneidende Berichtspflichten und die begrenzte Digitalisierung tragen zu erhöhten Verwaltungs- und Anpassungskosten sowohl für die Behörden als auch für die Wirtschaftsakteure bei.

Zusammenfassend zeigt die gezielte Bewertung, dass

- • bestimmte Anforderungen, insbesondere im Zusammenhang mit Konformitätsbewertungsverfahren, übermäßig komplex, belastend, langwierig und kostspielig sind,

- • die Anwendung der rechtlichen Anforderungen durch die nationalen Behörden und die Benannten Stellen nicht ausreichend aufeinander abgestimmt ist,

- • die bestehenden Koordinierungsmechanismen nicht hinreichend effizient und wirksam sind,

- • auf EU-Ebene keine ausreichende technisch-regulatorische Beratung verfügbar ist,

- • keine adaptiven Pfade für bahnbrechende Innovationen sowie für Produkte für seltene Erkrankungen oder „Nischen“-Produkte bestehen,

- • die Verordnungen unbeabsichtigte negative Auswirkungen auf Innovation, Wettbewerbsfähigkeit und die Patientenversorgung haben,

- • ein Bedarf an verbesserter Kohärenz mit anderem EU-Recht besteht, etwa mit der Verordnung über klinische Prüfungen.

Die Bewertung hat gezeigt, dass Potenzial besteht, die Umsetzung beider Verordnungen zu vereinfachen und Belastungen zu verringern, ohne deren Hauptziele zu beeinträchtigen.

#### • Konsultationen der Interessenträger

Neben den fortlaufenden Konsultationen mit den Mitgliedstaaten und den Interessenträgern im Rahmen der Koordinierungsgruppe Medizinprodukte sowie den öffentlichen und gezielten Konsultationstätigkeiten, die in die gezielte Bewertung eingeflossen sind, hat die Kommission eine Aufforderung zur Stellungnahme zur gezielten Überarbeitung der MP-VO und der IVD-VO eingeleitet.

Rückmeldungen konnten vom 8. September bis zum 6. Oktober 2025 eingereicht werden^(22). Insgesamt wurden 427 Einzelbeiträge^(23) und 166 Anhänge^(24) als gültig anerkannt (die abschließende Analyse stützte sich auf 165 dieser Anhänge)^(25).

In Bezug auf die Interessenträgergruppen stellten Unternehmen und Betriebe die größte Gruppe der Teilnehmenden (199 Beiträge, 46,6 %), gefolgt von Wirtschaftsverbänden (61 Beiträge, 14,29 %). Die übrigen Teilnehmenden waren Nichtregierungsorganisationen (36 Beiträge, 8,43 %), akademische und Forschungseinrichtungen (31 Beiträge, 7,26 %), öffentliche Behörden (13 Beiträge, 3,04 %) sowie Gewerkschaften (6 Beiträge, 1,41 %). Rückmeldungen wurden außerdem von Benannten Stellen (5 Beiträge, 1,17 %) und Verbraucherorganisationen (1 Beitrag) sowie von Einzelpersonen übermittelt (37 Stellungnahmen von Unionsbürgerinnen und -bürgern (8,67 %) und 8 von Nicht-EU-Bürgerinnen und -bürgern (1,87 %)). Einige Interessenträger wählten die Option „Sonstige“ (30 Beiträge, 7,03 %). Eine große Mehrheit der teilnehmenden Unternehmen waren KMU (129 Beiträge, 64,8 %), darunter 34 mittlere, 54 kleine und 41 Kleinstunternehmen.

Hinsichtlich der geografischen Herkunft stammten die Rückmeldungen überwiegend aus Deutschland (100 Stellungnahmen, 23,42 %), Belgien (48 Stellungnahmen, 11,24 %) und Frankreich (39 Stellungnahmen, 9,13 %).

Die Rückmeldungen zur Aufforderung zur Stellungnahme zeigten, dass die Befragten den ermittelten, aus den Verordnungen resultierenden Hürden zustimmten. Sie verwiesen auf unverhältnismäßige Kosten, einen hohen Verwaltungsaufwand und die insgesamt hohe regulatorische Komplexität und bestätigten damit zugleich die Ergebnisse der gezielten Bewertung. Die Interessenträger bekundeten insgesamt breite Unterstützung für Maßnahmen, die darauf abzielen, den Rechtsrahmen zu vereinfachen und verhältnismäßiger sowie effizienter zu gestalten, den Verwaltungsaufwand zu verringern und mehr Flexibilität zu ermöglichen, um das Inverkehrbringen innovativer Medizinprodukte zu unterstützen.

Die Befragten aus allen Interessenträgergruppen erkannten insgesamt die Ziele der Verordnungen an und betonten, dass die Aufrechterhaltung der Sicherheitsstandards und eines hohen Niveaus der öffentlichen Gesundheit der Bevölkerung – unter anderem durch die Sicherstellung der Verfügbarkeit von Medizinprodukten oder durch die Unterstützung von Innovationen für kleine Bevölkerungsgruppen – weiterhin im Mittelpunkt der Überarbeitung stehen sollte.

Insgesamt unterstrichen die Interessenträger die Notwendigkeit eines risikobasierten Ansatzes bei den Anforderungen, befürworteten eine stärkere Digitalisierung sowie eine effizientere Steuerung. Die Rückmeldungen umfassten vorgeschlagene Änderungen in mehreren Bereichen, darunter die Anforderungen an klinische Daten und Daten nach dem Inverkehrbringen, die Vereinfachung und größere Vorhersehbarkeit des Konformitätsbewertungsverfahrens sowie Änderungen im Zusammenhang mit Audits und der Überwachung nach dem Inverkehrbringen.

In den Rückmeldungen wurde außerdem insbesondere auf die Auswirkungen der Verordnungen auf KMU hingewiesen, da die Kosten für die Erfüllung der Anforderungen für KMU als besonders unverhältnismäßig angesehen werden; viele Interessenträger fordern, dass die Bedürfnisse der KMU berücksichtigt werden.

Einige Interessenträger sprachen sich darüber hinaus für eine stärkere Nutzung digitaler Instrumente aus. Es wurden außerdem Forderungen nach einer vereinfachten und verbesserten Steuerung erhoben, unter anderem zur Verbesserung der Vorhersehbarkeit und zur Gewährleistung einer harmonisierten Auslegung des Rechtsrahmens.

Schließlich unterstützten die Interessenträger Maßnahmen zur Stärkung der Kohärenz mit anderen EU-Rechtsrahmen, wie etwa den EU-Rechtsvorschriften über klinische Prüfungen und über KI.

Die Kommission leitete außerdem eine Reihe gezielter Umfragen ein, darunter eine Umfrage speziell für kleine und mittlere Hersteller von Medizinprodukten, und organisierte mehrere Workshops.

#### • Einholung und Nutzung von Expertenwissen

Der Vorschlag stützt sich auf die Ergebnisse der gezielten Bewertung und der oben beschriebenen Konsultationen der Interessenträger.

#### • Folgenabschätzung

Der Vorschlag greift die im Rahmen der gezielten Bewertung festgestellten Probleme auf. Die vorgeschlagene Überarbeitung der MP-VO und der IVD-VO besteht aus gezielten Vereinfachungsmaßnahmen (für die es keine praktikablen Alternativen gibt), mit denen Belastungen verringert und eine größere Vorhersehbarkeit des Rechtsrahmens sichergestellt werden sollen. Die vorgeschlagenen Änderungen zielen nicht darauf ab, die Ziele der Rechtsvorschriften zu ändern; vielmehr wird damit die fortdauernde Verfügbarkeit sicherer und innovativer Medizinprodukte gewährleistet und ein hohes Niveau der Patientensicherheit, der öffentlichen Gesundheit der Bevölkerung und der Gesundheitsversorgung gesichert. In diesem Zusammenhang wurde eine Folgenabschätzung im Hinblick auf Zeitpunkt und Effizienz weder als erforderlich noch als zweckmäßig erachtet.

Stattdessen wird der Vorschlag von einer Arbeitsunterlage der Kommissionsdienststellen begleitet, in der die vorgeschlagenen Maßnahmen erläutert werden und die Nachweise und deren Analyse sowie die Standpunkte der Interessenträger dargelegt sind. Diese Arbeitsunterlage der Kommissionsdienststellen enthält eine Schätzung der Kosteneinsparungen^(26). Insgesamt wird der kombinierte quantifizierbare Effekt der in diesem Dokument beschriebenen Vereinfachungsmaßnahmen, unter Berücksichtigung der darin dargelegten Einschränkungen und Annahmen, auf mehr als 3 Mrd. EUR pro Jahr geschätzt. Neben der finanziellen Entlastung zielen die Maßnahmen darauf ab, einen verhältnismäßigen, effizienten und flexiblen Rahmen zu schaffen, die Rechtssicherheit zu erhöhen, eine kohärentere Umsetzung in der gesamten Union zu unterstützen und das in der MP-VO und der IVD-VO festgelegte hohe Schutzniveau für die Gesundheit aufrechtzuerhalten. Durch die Unterstützung eines effizienteren und innovationsfreundlichen Systems tragen die vorgeschlagenen Maßnahmen letztlich dazu bei, sicherzustellen, dass Patienten weiterhin Zugang zu den von ihnen benötigten Medizinprodukten haben.

#### • Effizienz der Rechtsetzung und Vereinfachung

Mit diesem Vorschlag kommt die Kommission ihrem Versprechen nach, die EU-Rechtsvorschriften zu vereinfachen und den regulatorischen Aufwand für Bürgerinnen und Bürger, Unternehmen und Verwaltungen in der Union zu verringern, und verbessert damit deren Wettbewerbsfähigkeit und Resilienz.

Der Vorschlag zur Straffung der Verfahren und zur Verringerung der Belastungen für Hersteller, Händler und Benannte Stellen dürfte die Kosten der Einhaltung der Vorschriften für KMU, große Unternehmen und andere Interessenträger in den betreffenden Sektoren senken. Die Vereinfachung der Verwaltungsverfahren wird die Unsicherheit erheblich verringern, eine größere Vorhersehbarkeit für Unternehmen gewährleisten und es ihnen ermöglichen, ihre Forschungs- und Entwicklungstätigkeiten effizienter zu planen. Die stärker gestrafften Verfahren für die Zertifizierung und für die Aufsicht über Benannte Stellen werden die Wettbewerbsfähigkeit der betroffenen EU-Sektoren steigern, insbesondere für KMU, die dadurch schneller auf sich verändernde Marktbedingungen und Kundenbedürfnisse reagieren können. Effizientere und vorhersehbarere Verfahren werden die betreffenden EU-Unternehmen für inländische wie ausländische Investoren attraktiver machen, was zu höheren Investitionen und Wachstum im Sektor führen könnte.

#### • Grundrechte

Der Vorschlag steht im Einklang mit den Grundrechten sowie den in der Charta der Grundrechte der Europäischen Union^(27) festgelegten Prinzipien. Insbesondere wahrt er das Recht jeder Person auf Achtung ihrer körperlichen und geistigen Unversehrtheit (Artikel 3), den Schutz personenbezogener Daten (Artikel 8), die unternehmerische Freiheit (Artikel 16) sowie das Recht auf Eigentum (Artikel 17). Darüber hinaus unterstützen die vorgeschlagenen Vereinfachungsmaßnahmen, die erwartete Verringerung des Verwaltungsaufwands sowie die Maßnahmen zur Förderung patientenorientierter Innovation und der Verfügbarkeit von Medizinprodukten, einschließlich solcher für kleine Patientengruppen, das Recht auf Zugang zur Gesundheitsvorsorge und das Recht auf medizinische Behandlung. Sie gewährleisten zudem ein hohes Schutzniveau für die menschliche Gesundheit, wie es in Artikel 35 der Charta festgelegt ist.

### 4. AUSWIRKUNGEN AUF DEN HAUSHALT

Der Vorschlag hat haushaltsrelevante Auswirkungen für die Union, insbesondere im Hinblick auf die zusätzlichen Ressourcen, die erforderlich sind, um Folgendes sicherzustellen: 1. eine verstärkte Aufsicht über Benannte Stellen sowie eine einheitliche Anwendung des Rechtsrahmens; 2. den Zugang zu zusätzlicher externer wissenschaftlicher, technischer und regulatorischer Fachkompetenz zur Unterstützung evidenzbasierter Entscheidungsfindung; 3. die Unterstützung durch die Europäische Arzneimittel-Agentur (EMA) zur besseren Koordinierung der von den nationalen Behörden im Zusammenhang mit der Umsetzung der MP-VO und der IVD-VO durchgeführten Tätigkeiten, insbesondere in den Bereichen Vigilanz und Marktüberwachung, Grenzfall- und Klassifizierungsentscheidungen, klinische Prüfungen und Leistungsstudien sowie Ausnahmen in außergewöhnlichen Fällen im Zusammenhang mit der Gesundheit und Sicherheit der Patienten. Der Finanzbogen enthält detaillierte Informationen zu den haushaltsrelevanten Auswirkungen sowie zu den erforderlichen personellen und administrativen Ressourcen. Dieser Ansatz nutzt die etablierte Rolle der Expertengremien und der Europäischen Arzneimittel-Agentur (EMA), um die Bedürfnisse des Sektors innerhalb des bestehenden Systemrahmens effizient zu adressieren, und greift dabei auf die Stärken der bestehenden EU-Rechtsvorschriften zurück.

Der Vorschlag ermächtigt die Kommission, für bestimmte Tätigkeiten, die nach der geltenden MP-VO und IVD-VO sowie den vorgeschlagenen Änderungen erforderlich sind, Gebühren festzulegen, etwa für die Bewertung und Überwachung Benannter Stellen sowie für die Bereitstellung wissenschaftlicher und regulatorischer Beratung. Diese Tätigkeiten können daher zumindest teilweise über Gebühren finanziert werden, wobei die Möglichkeit der Einführung ermäßigter Gebührensätze für KMU besteht. Andere Tätigkeiten, insbesondere solche im Zusammenhang mit der Verbesserung der Koordinierung zwischen den nationalen Behörden, um das Funktionieren des Binnenmarkts zu verbessern und die Einhaltung der Vorschriften für Wirtschaftsakteure zu vereinfachen, können zu diesem Zeitpunkt jedoch nicht aus den finanziellen Beiträgen der dem Rechtsrahmen unterliegenden Einrichtungen finanziert werden. Eine spezifische Regelung für Nutzergebühren ist erforderlich, da entsprechende Regelungen in anderen Sektoren in der Union und in anderen Rechtsordnungen bestehen.

Die Auswirkungen der Kosten der verstärkten Koordinierung auf den EU-Haushalt werden letztlich zu Kostensenkungen für Wirtschaftsakteure führen, dank der Vorteile, die sich aus einheitlichen Praktiken im Binnenmarkt, gestrafften Verfahren sowie einer robusteren und vorhersehbareren regulatorischen Infrastruktur ergeben, die die Wettbewerbsfähigkeit stärkt und Innovation fördert. Darüber hinaus stärkt die vorgeschlagene Änderung die Fähigkeit der Union, Bedrohungen der öffentlichen Gesundheit wirksam zu verhindern und darauf zu reagieren, wie etwa Versorgungsengpässe bei Medizinprodukten und Sicherheitsbedenken, und minimiert dadurch die mit etwaigen Ineffizienzen des Rechtsrahmens verbundenen Kosten. Entscheidend ist zudem, dass diese Initiative darauf abzielt, die bestehenden Rechtsvorschriften zu vereinfachen, den Verwaltungsaufwand zu verringern und die Zertifizierungsverfahren für Benannte Stellen zu präzisieren, was zu einer erheblichen Senkung der Gesamtkosten für Hersteller führt, während zugleich der Schutz der öffentlichen Gesundheit und der Patientensicherheit gewahrt bleibt.

### 5. WEITERE ANGABEN

#### • Durchführungspläne sowie Monitoring-, Bewertungs- und Berichterstattungsmodalitäten

Die Auswirkungen des Vorschlags werden im Rahmen der regelmäßigen Folgemaßnahmen der Verordnungen durch bestehende Berichts- und Aufsichtsmechanismen überwacht. Darüber hinaus schlägt die Kommission vor, fünf Jahre nach Inkrafttreten der vorgeschlagenen Änderungen eine weitere gezielte Bewertung der Anwendung der MP-VO und der IVD-VO durchzuführen.

#### • Ausführliche Erläuterung einzelner Bestimmungen des Vorschlags

Der Vorschlag ist wie folgt gegliedert:

Artikel 1: Änderungen der Verordnung (EU) 2017/745

Artikel 2: Änderungen der Verordnung (EU) 2017/746

Artikel 3: Änderungen der Verordnung (EU) 2022/123

Artikel 4: Änderungen der Verordnung (EU) 2024/1689

Artikel 5: Inkrafttreten

Die Änderungen lassen sich nach Hauptthemen, den betroffenen Artikeln und den besonderen Bestimmungen des Vorschlags wie folgt zusammenfassen:

| Änderungen der Verordnung (EU) 2017/745 über Medizinprodukte (MP-VO) und der Verordnung (EU) 2017/746 über In-vitro-Diagnostika (IVD-VO) |  |
| --- | --- |
| THEMA 1: VEREINFACHUNG UND VERHÄLTNISMÄSSIGKEIT |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Verantwortliche Person für die Einhaltung der Regulierungsvorschriften (im Folgenden „verantwortliche Person“) (MP-VO: Artikel 15, IVD-VO: Artikel 15) | Streichung der detaillierten Qualifikationsanforderungen für die verantwortliche Personen sowie Aufhebung der Verpflichtung, dass KMU, die auf eine externe verantwortliche Person zurückgreifen, diese „ständig und kontinuierlich“ verfügbar halten müssen; erforderlich ist lediglich, dass die verantwortliche Person verfügbar ist. |
| Gültigkeit von Bescheinigungen und Erneuerung von Bescheinigungen (MP-VO: Artikel 56, IVD-VO: Artikel 51) | Die maximale Gültigkeitsdauer von Bescheinigungen (derzeit 5 Jahre) wird aufgehoben. Anstatt Medizinprodukte erneut zu zertifizieren, führen Benannte Stellen während der Gültigkeitsdauer der Bescheinigung regelmäßige, dem Risiko des Medizinprodukts angemessene Überprüfungen durch. |
| Klinische Nachweise, nichtklinische Daten und klinische Daten (MP-VO: Artikel 2 Nummer 48, Artikel 61, Anhang II, Anhang XIV, IVD-VO: Anhang XIII) | Ein breiteres Spektrum an Daten kann als klinische Daten gelten. Die Bedingungen für die Heranziehung klinischer Daten eines gleichwertigen Medizinprodukts werden flexibler gestaltet. In Artikel 61 MP-VO wird die Möglichkeit erweitert, die Sicherheit und Leistung eines Medizinprodukts allein auf der Grundlage nichtklinischer Daten nachzuweisen. Die Anwendung von auf neuen Ansätzen beruhenden Methoden (New Approach Methodologies) wie etwa In-silico-Tests wird gefördert. |
| Bewährte Technologien (MP-VO: Artikel 2 Nummer 72, Artikel 18, Artikel 32, Artikel 52, Artikel 61, Artikel 86) | Für Medizinprodukte mit bewährter Technologie, für die verhältnismäßigere Anforderungen gelten, wird eine Definition eingeführt; damit werden die Listen von Medizinprodukten in den geltenden Artikeln 18 Absatz 3, 52 Absatz 4 und 61 Absatz 6 Buchstabe b MP-VO ersetzt. |
| Umpacken und die Neukennzeichnung (MP-VO: Artikel 16, IVD-VO: Artikel 16) | Die Anforderungen an eine Bescheinigung einer Benannten Stelle für Neukennzeichnungs- und Umpacktätigkeiten sowie die Pflicht zur vorherigen Unterrichtung werden aufgehoben. |
| Klassifizierungsregeln (MP-VO: Anhang VIII) | Einige Klassifizierungsregeln werden angepasst, was für bestimmte Medizinprodukte zu niedrigeren Risikoklassen führt, etwa für wiederverwendbare chirurgische Instrumente, Zubehör zu aktiven implantierbaren Produkten und Software. |
| THEMA 2: VERRINGERUNG DES VERWALTUNGSAUFWANDS |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Kurzbericht über Sicherheit und (klinische) Leistung (MP-VO: Artikel 32, IVD-VO: Artikel 29) | Der Anwendungsbereich der Produkte, für die der Hersteller einen Kurzbericht über Sicherheit und (klinische) Leistung vorlegen muss, wird auf die Produkte beschränkt, für die die Benannte Stelle eine Bewertung der technischen Dokumentation durchführen muss. Da der Entwurf des Kurzberichts über Sicherheit und (klinische) Leistung Teil der von der Benannten Stelle vorzulegenden Dokumentation ist, ist eine gesonderte Validierung durch die Benannte Stelle nicht länger erforderlich. |
| Regelmäßig aktualisierter Bericht über die Sicherheit (MP-VO: Artikel 86, IVD-VO: Artikel 81) | Die Häufigkeit, mit der Hersteller verpflichtet sind, regelmäßig aktualisierte Berichte über die Sicherheit (im Folgenden „Sicherheitsbericht“) zu aktualisieren, wird verringert. Die Überprüfung des regelmäßig aktualisierten Sicherheitsberichts durch die Benannte Stelle wird Teil ihrer Überwachungstätigkeiten sein. |
| Meldezeitraum bestimmter schwerwiegender Vorkommnisse im Rahmen der Vigilanz (MP-VO: Artikel 87, IVD-VO Artikel 82) | Hersteller erhalten 30 Tage (statt 15 Tage) für die Meldung schwerwiegender Vorkommnisse, die nicht im Zusammenhang mit Bedrohungen der öffentlichen Gesundheit, Todesfällen oder einer schwerwiegenden Verschlechterung des Gesundheitszustands stehen. |
| Änderungen nach der Zertifizierung (MP-VO: Anhang VII, IVD-VO: Anhang VII) | Die Benannte Stelle muss unterscheiden zwischen Änderungen am Qualitätsmanagementsystem oder am zugelassenen Medizinprodukt, die Hersteller ohne vorherige Unterrichtung, ohne vorherige Genehmigung oder erst nach Genehmigung durch die Benannte Stelle umsetzen dürfen. Gegebenenfalls vereinbaren Benannte Stelle und Hersteller einen vorab festgelegten Änderungssteuerungsplan. |
| Genehmigung oder Anzeige bestimmter Leistungsstudien (IVD-VO: Artikel 58) | Leistungsstudien, die ausschließlich routinemäßige Blutentnahmen beinhalten, unterliegen keiner vorherigen Genehmigung. Die Anzeigepflicht für Leistungsstudien zu therapiebegleitenden Diagnostika, bei denen Restproben verwendet werden, wird aufgehoben. |
| THEMA 3: INNOVATION UND VERFÜGBARKEIT VON MEDIZINPRODUKTEN FÜR BESONDERE PATIENTENGRUPPEN ODER SITUATIONEN |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Hausinterne Produkte (MP-VO: Artikel 5 Absatz 5, IVD-VO: Artikel 5 Absatz 5) | Die Bedingungen für die Herstellung und Verwendung innerhalb von Gesundheitseinrichtungen werden flexibler gestaltet, etwa indem die Weitergabe von hausinternen Medizinprodukten zugelassen wird, wenn dies im Interesse der Patientensicherheit oder der öffentlichen Gesundheit liegt. Nach der IVD-VO wird die Voraussetzung, dass kein gleichwertiges Medizinprodukt auf dem Markt verfügbar ist, gestrichen. Zentrale Laboratorien, die Tests ausschließlich für klinische Prüfungen herstellen und verwenden, werden in den Anwendungsbereich der Ausnahmeregelung für hausinterne Medizinprodukte einbezogen. |
| Unterbrechung oder Einstellung der Versorgung mit bestimmten Medizinprodukten (MP-VO: Artikel 10a, IVD-VO: Artikel 10a) | Ein zentrales IT-Instrument für die Meldung und den Informationsaustausch wird in der Europäischen Datenbank für Medizinprodukte (Eudamed) bereitgestellt oder mit Eudamed interoperabel sein. Die EMA wird eine Methodik zur Identifizierung von Medizinprodukten, die in den Anwendungsbereich der Meldepflicht fallen, entwickeln und eine Liste dieser Medizinprodukte erstellen. |
| Konformitätsbewertungsverfahren für bahnbrechende Produkte oder Produkte für seltene Erkrankungen (MP-VO: neuer Artikel 52a, IVD-VO: neuer Artikel 48a) | Es werden Kriterien für bahnbrechende Produkte und Produkte für seltene Erkrankungen eingeführt. Nach der Einstufung durch ein Expertengremium unterliegen bahnbrechende Medizinprodukte und Produkte für seltene Erkrankungen einer prioritären und fortlaufenden Prüfung. Hersteller haben Zugang zur Beratung durch die Expertengremien. |
| Ausnahmeregelungen für Notlagen der öffentlichen Gesundheit, Katastrophen oder Krisen (MP-VO: Artikel 59, neuer Artikel 59a, IVD-VO: Artikel 54, neuer Artikel 54a) | Die Kommission kann von sich aus das Inverkehrbringen von Medizinprodukten im Falle einer Notlage der öffentlichen Gesundheit genehmigen. Die zuständigen Behörden können während schwerwiegender grenzüberschreitender Gesundheitsgefahren, Katastrophen oder Krisen Ausnahmen von den Herstellungs-, Auslegungs- oder Zweckbestimmungsanforderungen für CE-gekennzeichnete Medizinprodukte genehmigen. |
| Reallabore (MP-VO: neue Artikel 59b und 59c, IVD-VO: neue Artikel 54b und 54c) | Die Mitgliedstaaten und die Kommission können Reallabore einrichten, um dem Bedarf im Zusammenhang mit neuen Technologien gerecht zu werden. |
| Aufbereitung von Einmalprodukten (MP-VO: Artikel 17) | Hersteller werden verpflichtet, eine Begründung für die Einstufung als „Einmalprodukt“ vorzulegen. Alle Produkte, die nicht für den einmaligen Gebrauch bestimmt sind, können gemäß den vom Hersteller bereitgestellten Anweisungen aufbereitet werden. Eine Person, die ein Einmalprodukt als neu aufbereitet, gilt als Hersteller des als neu aufbereiteten Medizinprodukts. Die Bestimmung wird fünf Jahre nach ihrem Inkrafttreten anwendbar. |
| Kits (IVD-VO: neuer Artikel 19a) | Klarstellung hinsichtlich der Zusammensetzung von Kits im Sinne von Artikel 2 Absatz 11 IVD-VO. |
| Bestandsschutz für Altprodukte für seltene Erkrankungen (MP-VO: Artikel 120, IVD-VO: Artikel 110) | Produkte für seltene Erkrankungen, die nach den früheren Richtlinien CE-gekennzeichnet wurden und für die ein Expertengremium bestätigt hat, dass sie die Kriterien eines Produkts für seltene Erkrankungen erfüllen, dürfen vorbehaltlich bestimmter Bedingungen auch über die Übergangszeiträume hinaus weiterhin in Verkehr gebracht werden. |
| Nanomaterial (MP-VO: Anhang I, Anhang VIII) | Die veraltete Definition von Nanomaterial in Artikel 2 MP-VO wird aufgehoben und durch einen Verweis auf die Empfehlung der Kommission vom 10. Juni 2022 zur Definition von Nanomaterial in den Bestimmungen des Anhangs I und des Anhangs VIII in Bezug auf Nanomaterial ersetzt. |
| THEMA 4: VORHERSEHBARKEIT UND KOSTENEFFIZIENZ DER ZERTIFIZIERUNG |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Strukturierter Dialog (MP-VO: Anhang VII, IVD-VO: Anhang VII) | Es wird eine Rechtsgrundlage für Benannte Stellen und Hersteller eingeführt, um vor und nach der Einreichung einen strukturierten Dialog auf der Grundlage dokumentierter Verfahren zu führen. |
| Konformitätsbewertungsverfahren (MP-VO: Artikel 52, Anhänge IX, X, XI, IVD-VO: Artikel 48, Anhänge IX, X, XI) | Die Einbindung der Benannten Stellen in die Konformitätsbewertung von Medizinprodukten mit niedrigem und mittlerem Risiko (Klasse IIa und IIb sowie Klasse B und C) wird reduziert (Bewertung der technischen Dokumentation eines repräsentativen Medizinprodukts für eine generische Medizinproduktgruppe, für eine Kategorie oder für das gesamte Portfolio). Im Rahmen der Überwachungstätigkeiten ist keine systematische Bewertung der technischen Dokumentation repräsentativer Medizinprodukte erforderlich. Sterile IVD der Klasse A erfordern keine Einbindung einer Benannten Stelle. Benannte Stellen erhalten die Möglichkeit, Vor-Ort-Audits durch Fernaudits zu ersetzen. Sofern dies mangels Sicherheitsproblemen gerechtfertigt ist, sollten Überwachungsaudits nur alle zwei Jahre durchgeführt werden. Unangekündigte Audits sollten nur aus konkretem Anlass durchgeführt werden. Verkürzte Fristen für die Konsultation der Arzneimittel- und SoHO-Behörden. |
| Konsultationsverfahren zur klinischen Bewertung (MP-VO: Artikel 54), Konsultationsverfahren zur Leistungsbewertung und frühzeitige Beratung (IVD-VO: Artikel 48, neuer Artikel 56a) | Der Anwendungsbereich des CECP wird auf implantierbare Medizinprodukte der Klasse III beschränkt; zugleich wird die Kommission ermächtigt, weitere Arten von Medizinprodukten durch einen delegierten Rechtsakt hinzuzufügen. Der PECP wird aufgehoben. Stattdessen wird die Möglichkeit einer frühzeitigen Beratung durch Expertengremien für IVD der Klassen C und D eingeführt. |
| Gebühren der Benannten Stellen (MP-VO: Artikel 50) | Gebührenermäßigungen für Klein- und Kleinsthersteller sowie für Produkte für seltene Erkrankungen. Die Kommission wird ermächtigt, die Höhe und Struktur der Gebühren der Benannten Stellen festzulegen. |
| THEMA 5: KOORDINIERUNG INNERHALB DES DEZENTRALEN SYSTEMS |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Rechtlicher Status von Produkten und Klassifizierung von Medizinprodukten (MP-VO: Artikel 4, neuer Artikel 4a, neuer Artikel 51a, neuer Artikel 51b, IVD-VO: Artikel 3, neuer Artikel 3a, neuer Artikel 47a, neuer Artikel 47b) | Die Koordinierung zwischen den zuständigen Behörden in Bezug auf die Qualifizierung eines Produkts und die Klassifizierung eines Medizinprodukts („Helsinki-Verfahren“) wird kodifiziert, mit der Möglichkeit, Stellungnahmen von Expertengremien einzuholen. |
| Benennung und Überwachung der Benannten Stellen (MP-VO: Artikel 36-44, IVD-VO: Artikel 31 mit Bezugnahme auf die Bestimmungen der MP-VO) | Die Bewertung von Anträgen von Konformitätsbewertungsstellen sowie die Benennung/Notifizierung von Benannten Stellen wird durch die Einbindung gemeinsamer Bewertungsteams gestrafft, die sich aus der für Benannte Stellen zuständigen nationalen Behörde, von der Kommission benannten Sachverständigen und von aus anderen Mitgliedstaaten benannten Sachverständigen zusammensetzen. Gemeinsame Bewertungsteams werden in die Überwachung der Benannten Stellen nach deren Benennung einbezogen, mindestens alle zwei Jahre. Die vollständige Neubewertung der Benannten Stellen alle fünf Jahre wird abgeschafft. Die Kommission wird ermächtigt, die Höhe und Struktur der Gebühren sowie der erstattungsfähigen Kosten für die Benennung und Überwachung der Benannten Stellen festzulegen. |
| Streitbeilegungsmechanismus zwischen Herstellern und Benannten Stellen (MP-VO: Artikel 35, IVD-VO: Artikel 31 mit Bezugnahme auf die Bestimmungen der MP-VO) | Die für Benannte Stellen zuständige Behörde übernimmt im Falle von Streitigkeiten zwischen Herstellern und Benannten Stellen die Rolle einer Ombudsstelle. |
| Koordinierung der Benannten Stellen (MP-VO: Artikel 49, Artikel 31 mit Bezugnahme auf die Bestimmungen der MP-VO) | Die Verpflichtung der Benannten Stellen zur Teilnahme an der Koordinierungsgruppe Benannter Stellen (NBCG-Med) wird verstärkt. Die NBCG-Med berichtet der Koordinierungsgruppe Medizinprodukte. |
| Gestärkte Rolle der dem Regulierungssystem zur Verfügung stehenden externen Fachkompetenz (MP-VO: Artikel 106, neuer Artikel 106a, IVD-VO: Artikel 100) | Die Rolle der Expertengremien sowie deren Zusammensetzung wird erweitert, unter anderem durch ihre Einbeziehung in die Feststellung des rechtlichen Status von Produkten und die Klassifizierung von Medizinprodukten. Expertengremien sollten in der Lage sein, der Kommission, den Mitgliedstaaten, der Koordinierungsgruppe Medizinprodukte, den Benannten Stellen und in bestimmten Fällen auch den Herstellern wissenschaftliche, technische, klinische und rechtliche Beratung zu leisten. Die EMA wird weiterhin das Sekretariat der Expertengremien bereitstellen. Die Aufgaben der Expertengremien und der Fachlaboratorien, die derzeit gemeinsam in Artikel 106 MP-VO geregelt sind, werden durch eine gesonderte Bestimmung zu Fachlaboratorien klargestellt. |
| Unterstützung durch die EMA für die Koordinierung der zuständigen Behörden (MP-VO: neuer Artikel 106b) | Die EMA stellt wissenschaftliche, technische und administrative Unterstützung für die Koordinierung zwischen den nationalen zuständigen Behörden in mehreren Bereichen bereit, etwa bei Abgrenzungsfragen und der Klassifizierung, multinationalen klinischen Prüfungen, Ausnahmeregelungen, der Vigilanz und der Marktüberwachung. Die EMA unterstützt außerdem KMU. |
| THEMA 6: WEITERE DIGITALISIERUNG |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Digitalisierung von Instrumenten zur Einhaltung der Vorschriften (MP-VO: Artikel 19, neuer Artikel 110a, Anhang I, Anhang VI, IVD-VO: Artikel 17, neuer Artikel 103a, Anhang I, Anhang VI) | Die EU-Konformitätserklärung kann in digitaler Form vorgelegt werden. Vorbehaltlich künftiger Durchführungsbestimmungen können bestimmte Angaben auf der Kennzeichnung in digitaler Form bereitgestellt werden. Hersteller von patientennahen Tests werden in der Lage sein, elektronische Gebrauchsanweisungen bereitzustellen. Die Übermittlung von Informationen gemäß MP-VO/IVD-VO erfolgt elektronisch. Wirtschaftsakteure müssen ihren digitalen Kontakt in Eudamed angeben. |
| Digitalisierung der Konformitätsbewertung (MP-VO: neuer Artikel 52b, IVD-VO: neuer Artikel 48b) | Die Hersteller können die technische Dokumentation, Berichte und andere Unterlagen in digitaler Form erstellen. |
| Online-Verkäufe (MP-VO: Artikel 6, IVD-VO: Artikel 6) | Bei Online-Verkäufen sind bestimmte wesentliche Informationen, die zur Identifizierung des Medizinprodukts erforderlich sind, sowie die Gebrauchsanweisung bereitzustellen. |
| UDI und Eudamed (MP-VO: Artikel 27-33, Anhang VII, IVD-VO: Artikel 24-30, Anhang VII) | Die Bestimmungen zur Zuteilung der UDI und zur Registrierung in Eudamed wurden klargestellt. Es wird ermöglicht, dass bestimmte elektronische Systeme außerhalb von Eudamed eingerichtet werden. |
| THEMA 7: INTERNATIONALE ZUSAMMENARBEIT |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Internationale Zusammenarbeit und Anerkennungsmechanismen (MP-VO: neuer Artikel 108a und neuer Artikel 108b) | Ein neuer Abschnitt zur internationalen Zusammenarbeit wird eingeführt, der Tätigkeiten zur Förderung der globalen regulatorischen Konvergenz und der internationalen Zusammenarbeit unterstützt, etwa im Rahmen des Internationalen Forums der Aufsichtsbehörden für Medizinprodukte (im Folgenden „IMP-VOF“) und des Programms zur Durchführung eines einheitlichen Audits für Medizinprodukte (MDSAP). |
| THEMA 8: ZUSAMMENSPIEL MIT ANDEREN RECHTSVORSCHRIFTEN DER UNION |  |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Kombinierte Studien mit Arzneimitteln, Medizinprodukten und/oder In-vitro-Diagnostika (MP-VO: neuer Artikel 79a, IVD-VO: neuer Artikel 75a) | Bei kombinierten Studien kann der Sponsor einen einzigen Antrag einreichen, der eine koordinierte Bewertung auslöst, gemäß der Verordnung (EU) Nr. 536/2014 über klinische Prüfungen, die durch den Biotech-Rechtsakt^(28) entsprechend geändert wird. |
| Cybersicherheit (MP-VO: neuer Artikel 87a, Anhang I, IVD-VO: neuer Artikel 82a, Anhang I) | Schwerwiegende Vorkommnisse, die gemäß dem nach der MP-VO oder der IVD-VO eingerichteten Vigilanzsystem gemeldet werden und die zugleich als aktiv ausgenutzte Schwachstellen und schwerwiegende Sicherheitsvorfälle im Sinne der Verordnung (EU) 2024/2847 über die Cyberresilienz gelten, werden den zuständigen nationalen Computer-Notfallteams (im Folgenden „CSIRTs“) sowie der Agentur der Europäischen Union für Cybersicherheit (im Folgenden „ENISA“) zugänglich gemacht. Darüber hinaus müssen Hersteller aktiv ausgenutzte Schwachstellen und schwerwiegende Sicherheitsvorfälle, die nicht als schwerwiegende Vorkommnisse im Sinne der MP-VO oder der IVD-VO gelten, über Eudamed an die CSIRTs und die ENISA melden. In Anhang I MP-VO/IVD-VO wird die Cybersicherheit in den grundlegenden Sicherheits- und Leistungsanforderungen ausdrücklich genannt. |

| Änderungen der Verordnung (EU) 2022/123 über eine verstärkte Rolle der Europäischen Arzneimittel-Agentur bei der Krisenvorsorge und dem Krisenmanagement für Arzneimittel und Medizinprodukte |  |
| --- | --- |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Verwaltung von Expertengremien (Artikel 30) | Das Mandat der EMA, das Sekretariat der Expertengremien für Medizinprodukte bereitzustellen, wird an die Änderungen der Bestimmungen über die Expertengremien in der MP-VO angepasst. |

| Änderungen der Verordnung (EU) 2024/1689 über künstliche Intelligenz |  |
| --- | --- |
| Artikel | Besondere Bestimmungen des Vorschlags |
| Anhang I | In Anhang I des Gesetzes über künstliche Intelligenz werden die MP-VO und die IVD-VO von Abschnitt A in Abschnitt B verschoben. |

(Text von Bedeutung für den EWR)

DAS EUROPÄISCHE PARLAMENT UND DER RAT DER EUROPÄISCHEN UNION —

gestützt auf den Vertrag über die Arbeitsweise der Europäischen Union, insbesondere auf Artikel 114 und Artikel 168 Absatz 4 Buchstabe c,

auf Vorschlag der Europäischen Kommission,

nach Zuleitung des Entwurfs des Gesetzgebungsakts an die nationalen Parlamente,

nach Stellungnahme des Europäischen Wirtschafts- und Sozialausschusses^(29),

nach Stellungnahme des Ausschusses der Regionen^(30),

gemäß dem ordentlichen Gesetzgebungsverfahren,

in Erwägung nachstehender Gründe:

## Erwägungsgründe

<a id="rec-1"></a>
(1) Die Verordnungen (EU) 2017/745^(31) und (EU) 2017/746^(32) des Europäischen Parlaments und des Rates legen Regulierungsrahmen fest, um das reibungslose Funktionieren des Binnenmarkts für Medizinprodukte bzw. In-vitro-Diagnostika sicherzustellen, wobei sie ein hohes Schutzniveau für die Gesundheit von Patientinnen und Patienten sowie Anwenderinnen und Anwendern zugrunde legen. Gleichzeitig sind in den Verordnungen (EU) 2017/745 und (EU) 2017/746 hohe Standards für die Qualität und Sicherheit von Medizinprodukten und In-vitro-Diagnostika festgelegt, durch die allgemeine Sicherheitsbedenken hinsichtlich solcher Produkte ausgeräumt werden sollen. Darüber hinaus wurden mit beiden Verordnungen Kernelemente des bestehenden Regulierungsrahmens gemäß den Richtlinien 90/385/EWG^(33) und 93/42/EWG^(34) des Rates sowie der Richtlinie 98/79/EG des Europäischen Parlaments und des Rates^(35) erheblich gestärkt, beispielsweise die Überwachung der Benannten Stellen, die Risikoklassifizierung, Konformitätsbewertungsverfahren, Anforderungen an klinische Nachweise, Vigilanz und Marktüberwachung, und in beiden Verordnungen ist die Einrichtung der Europäischen Datenbank für Medizinprodukte (Eudamed) vorgesehen, um Transparenz und Rückverfolgbarkeit in Bezug auf Medizinprodukte und In-vitro-Diagnostika zu schaffen.

<a id="rec-2"></a>
(2) Die Verlängerung der Übergangsfristen gemäß Artikel 120 der Verordnung (EU) 2017/745 und Artikel 110 der Verordnung (EU) 2017/746 hat das Risiko von Engpässen bei Medizinprodukten und In-vitro-Diagnostika in der Union gemindert, adressierte jedoch nicht die zugrunde liegenden strukturellen Probleme im Zusammenhang mit der Umsetzung beider Verordnungen.

<a id="rec-3"></a>
(3) In ihrer gezielten Bewertung^(36) der Verordnungen (EU) 2017/745 und (EU) 2017/746 bestätigte die Kommission, dass die Verordnungen den Regulierungsrahmen durch strengere Anforderungen an die Benennung und Überwachung der Benannten Stellen, die Durchführung von Konformitätsbewertungen sowie die Generierung klinischer Nachweise gestärkt haben. Die Bewertung hob jedoch auch mehrere Schwachstellen und Ineffizienzen im Regulierungsrahmen hervor, die zu unnötigen Belastungen für die Hersteller führen. Übermäßig komplexe und häufig unverhältnismäßige Anforderungen sowie kostspielige, langwierige und unvorhersehbare Konformitätsbewertungsverfahren beeinträchtigen die Verfügbarkeit von Medizinprodukten, die Wettbewerbsfähigkeit der Hersteller in der Union, insbesondere der kleinen und mittleren Unternehmen, sowie die Innovation in der Medizintechnik. Dies wirkt sich negativ auf das Niveau der Gesundheitsversorgung und die Patientensicherheit in der Union aus.

<a id="rec-4"></a>
(4) Um die festgestellten Mängel zu beheben, sollten die bestehenden Vorschriften vereinfacht und der Verwaltungsaufwand verringert werden, ohne das hohe Niveau der öffentlichen Gesundheit und der Patientensicherheit zu gefährden. Zudem sollten die Vorhersehbarkeit und die Kosteneffizienz der Anwendung beider Verordnungen verbessert werden, um deren ursprüngliche Ziele zu erreichen.

<a id="rec-5"></a>
(5) Die Verordnung (EU) 2017/745 umfasst in ihrem Anwendungsbereich bestimmte Gruppen von Produkten, die Medizinprodukten ähnlich sind, jedoch dem Hersteller zufolge lediglich eine kosmetische oder sonstige nicht-medizinische Zweckbestimmung haben. Zur Erhöhung der Rechtssicherheit und zur Gewährleistung der Kohärenz sollte klargestellt werden, dass Zubehör für solche Produkte ohne medizinischen Zweck ebenfalls in den Anwendungsbereich der Verordnung (EU) 2017/745 einbezogen ist.

<a id="rec-6"></a>
(6) Die Bestimmungen der Verordnung (EU) 2017/745 sollten an die Verordnung (EU) 2024/1938 des Europäischen Parlaments und des Rates^(37), die neue Rechtsvorschrift der Union im Bereich der Substanzen menschlichen Ursprungs (SoHO), angepasst werden.

<a id="rec-7"></a>
(7) Um eine doppelte Ebene regulatorischer Anforderungen zu vermeiden, sollten Produkte, die ein Medizinprodukt und ein In-vitro-Diagnostikum kombinieren, entweder der Verordnung (EU) 2017/745 oder der Verordnung (EU) 2017/746 unterliegen, je nach der hauptsächlichen Wirkungsweise des Produkts, während die grundlegenden Sicherheits- und Leistungsanforderungen der jeweils anderen Verordnung auf den Teil des Produkts Anwendung finden, dem eine unterstützende Funktion zukommt.

<a id="rec-8"></a>
(8) Die Definition von Nanomaterial in der Verordnung (EU) 2017/745 sollte aktualisiert werden, um sie mit der Empfehlung der Kommission vom 10. Juni 2022 zur Definition von Nanomaterial in Einklang zu bringen^(38).

<a id="rec-9"></a>
(9) Klinische Daten sind eine wichtige Informationsquelle für den Nachweis der Sicherheit und Leistung eines Medizinprodukts. Der Prozess der Generierung klinischer Daten ist jedoch häufig langwierig und kostspielig. Die Definition der klinischen Daten sollte erweitert werden, um die Verwendung von Daten zu ermöglichen, die durch Studien zu dem betreffenden Medizinprodukt gewonnen wurden und in der wissenschaftlichen Literatur veröffentlicht sind, auch wenn sie nicht notwendigerweise einer gegenseitigen Begutachtung (Peer-Review) unterzogen wurden.

<a id="rec-10"></a>
(10) Medizinprodukte, die etablierte Technologien darstellen, weisen ein geringeres Risikoprofil auf als andere Medizinprodukte derselben Risikoklasse. Sie unterliegen daher in der Verordnung (EU) 2017/745 bestimmten Ausnahmen oder verhältnismäßigeren Anforderungen. Um die Anwendung dieser Bestimmungen flexibler und zukunftssicher zu gestalten, sollte in dieser Verordnung eine Begriffsbestimmung für Medizinprodukte mit bewährter Technologie aufgenommen werden, die auf von der Koordinierungsgruppe Medizinprodukte^(39) erarbeiteten Leitlinien beruht; zudem sollten die bestehenden Listen von Produkten in den Artikeln 18, 52 und 61 der Verordnung (EU) 2017/745 durch einen Verweis auf den neu definierten Begriff ersetzt werden.

<a id="rec-11"></a>
(11) Zur Gewährleistung der Rechtssicherheit und zur Wahrung des Grundsatzes des freien Warenverkehrs sollte der Koordinierungsmechanismus zwischen den nationalen zuständigen Behörden für Entscheidungen über den rechtlichen Status eines Produkts und über die Klassifizierung eines Medizinprodukts gestrafft werden und gegebenenfalls externe Fachkompetenz eines Expertengremiums eingeholt werden, unterstützt durch die EMA. Die Entscheidung über den rechtlichen Status sollte jedoch bei den nationalen Behörden verbleiben oder gegebenenfalls bei der Kommission, die durch Durchführungsrechtsakte handelt.

<a id="rec-12"></a>
(12) Die Herstellung und Verwendung von Produkten innerhalb von Gesundheitseinrichtungen (hausinterne Produkte) unter bestimmten Bedingungen ist für die Erbringung der Gesundheitsversorgung in Fällen wesentlich, in denen die Bedürfnisse der Zielpatientengruppe durch auf dem Markt verfügbare Produkte nicht gedeckt werden können. Während die strengen Bedingungen für die Befreiung solcher hausinternen Produkte von den meisten der in der Verordnung (EU) 2017/745 oder der Verordnung (EU) 2017/746 festgelegten Anforderungen grundsätzlich beibehalten werden sollten, sollte ein gewisses Maß an Flexibilität eingeführt werden, um unnötigen Verwaltungsaufwand für Gesundheitseinrichtungen zu beseitigen, die klinische Forschung zu hausinternen Produkten zu fördern und den Zugang von Patientinnen und Patienten zu hausinternen Produkten zu ermöglichen, wenn keine Alternativen bestehen. So sollten beispielsweise einige Dokumentationspflichten aufgehoben werden, insbesondere im Rahmen der Verordnung (EU) 2017/746 für nach EN ISO 15189 akkreditierte Gesundheitseinrichtungen. Die Weitergabe eines hausinternen Produkts an eine andere Gesundheitseinrichtung sollte zulässig sein, sofern dies im Interesse der öffentlichen Gesundheit, der Gesundheit der Patientinnen und Patienten oder der Patientensicherheit gerechtfertigt ist. Ferner sollte zur Gewährleistung der Rechtssicherheit für Gesundheitseinrichtungen, wenn ein auf dem Markt verfügbares Produkt bereitgestellt wird, das die Bedürfnisse der Zielpatientengruppe in gleichwertiger Weise wie das hausinterne Produkt erfüllt, für die Gesundheitseinrichtung eine lange Übergangsfrist gelten, bis die Ausnahme für die hausinterne Herstellung nicht mehr anwendbar ist. Aufgrund ihrer Bedeutung für die Vorsorge und Reaktion auf Notlagen der öffentlichen Gesundheit sollte für hausinterne In-vitro-Diagnostika die Voraussetzung, dass kein auf dem Markt verfügbares Produkt existiert, das die Bedürfnisse der Zielpatientengruppe in gleichwertiger Weise erfüllt, aufgehoben werden.

<a id="rec-13"></a>
(13) Laboratorien, die klinische Forschung im Rahmen klinischer Prüfungen von Arzneimitteln durchführen, die der Verordnung (EU) Nr. 536/2014 unterliegen, entwickeln häufig hausinternen Tests, um die Bedürfnisse der Patientinnen und Patienten in klinischen Prüfungen zu erfüllen. Soweit diese Tests nicht im industriellen Maßstab hergestellt und nicht in Verkehr gebracht werden, ist die Situation solcher laborentwickelter Tests mit der von hausinternen Produkten vergleichbar, die innerhalb einer Gesundheitseinrichtung hergestellt und verwendet werden. Die Ausnahme von bestimmten Anforderungen der Verordnung (EU) 2017/746, wie sie in Artikel 5 Absatz 5 dieser Verordnung vorgesehen ist, sollte daher auch für laborentwickelte Tests gelten, die ausschließlich in klinischen Prüfungen verwendet werden.

<a id="rec-14"></a>
(14) Zur Gewährleistung gleicher Wettbewerbsbedingungen zwischen online vertriebenen Medizinprodukten und solchen, die über traditionelle Vertriebskanäle verkauft werden, sollten bestimmte für den Fernabsatz geltende Informationsanforderungen verschärft werden. Insbesondere sollte klargestellt werden, dass die Mitgliedstaaten aus Gründen des Schutzes der öffentlichen Gesundheit auch die Einstellung der Tätigkeit von Anbietern diagnostischer oder therapeutischer Dienstleistungen anordnen können, die im Wege von Diensten der Informationsgesellschaft im Sinne der Richtlinie (EU) 2015/1535 des Europäischen Parlaments und des Rates^(40), unbeschadet des nationalen Rechts zur Regelung der ärztlichen Berufsausübung, erbracht werden.

<a id="rec-15"></a>
(15) Während es in der Verantwortung jedes Mitgliedstaats verbleiben sollte, die Sprache festzulegen, in der den Anwendern innerhalb seines Hoheitsgebiets Informationen bereitzustellen sind, sollten die Mitgliedstaaten erwägen, solche Informationen auch in anderen Sprachen der Union, die im medizinischen Bereich allgemein verstanden werden, anzuerkennen, insbesondere in Bezug auf für professionelle Anwender bestimmte Medizinprodukte, um die Übersetzungskosten zu senken.

<a id="rec-16"></a>
(16) Zur Verringerung der Komplexität und zur Verbesserung der Kohärenz sollten redundante Bestimmungen, die lediglich festlegen, dass Anforderungen aus anderen Bestimmungen der Verordnung (EU) 2017/745 oder der Verordnung (EU) 2017/746 oder aus anderen Rechtsvorschriften Anwendung finden, gestrichen werden.

<a id="rec-17"></a>
(17) Einige Hersteller lassen ihre Medizinprodukte von einer anderen juristischen oder natürlichen Person entwerfen und herstellen. Während die Verordnungen (EU) 2017/745 und (EU) 2017/746 die Transparenz hinsichtlich der Person, die das Medizinprodukt entwirft und herstellt, erhöht haben, sollten die Verantwortlichkeiten des Herstellers in Bezug auf seinen Zugang zu den Teilen der technischen Dokumentation, die gegebenenfalls vom Originalausrüstungslieferanten erstellt werden, präzisiert werden, auch zum Zweck der Überwachung durch die zuständigen Behörden.

<a id="rec-18"></a>
(18) Um die Anwendung der Informationspflicht bei Unterbrechung oder Beendigung der Versorgung mit bestimmten Medizinprodukten gemäß den Verordnungen (EU) 2017/745 und (EU) 2017/746 zu erleichtern und zu straffen und die Rechtssicherheit hinsichtlich der Medizinprodukte, die dieser Informationspflicht unterliegen, zu verbessern, sollte ein zentrales IT-Instrument für die Meldung und den Informationsaustausch bereitgestellt werden. Darüber hinaus sollte die EMA ermächtigt werden, eine Liste der unter die Informationspflicht fallenden Medizinprodukte zu erstellen und zu veröffentlichen. Die von der EMA bei Unterbrechung oder Beendigung der Versorgung geleistete Unterstützung sollte auch den Beitrag der durch die Verordnung (EU) 2022/123 des Europäischen Parlaments und des Rates^(41) eingerichteten hochrangigen Lenkungsgruppe für Engpässe bei Medizinprodukten (im Folgenden „MDSSG“) berücksichtigen. Zur Gewährleistung eines hohen Schutzniveaus der öffentlichen Gesundheit, des kontinuierlichen Zugangs zu und der anhaltenden Verfügbarkeit von Medizinprodukten und In-vitro-Diagnostika sowie zur Stärkung der Vorsorge und Reaktion auf gesundheitliche Notlagen sollten die Mitgliedstaaten und die Kommission die Möglichkeit haben, Hersteller jener Medizinprodukte, die in der Liste der unter die Informationspflicht fallenden Medizinprodukte enthalten sind, aufzufordern, Informationen über Risiken und Schwachstellen innerhalb der Lieferkette bereitzustellen, die die Versorgung mit solchen Medizinprodukten beeinträchtigen können. Diese Informationen können zur Bewertung möglicher Schwachstellen in der Lieferkette kritischer Medizinprodukte verwendet werden, beispielsweise im Rahmen der MDSSG.

<a id="rec-19"></a>
(19) Angesichts der Fortschritte bei der digitalen Kommunikation und bei digitalen Instrumenten zur Einhaltung der Vorschriften und zur Verringerung des Verwaltungsaufwands sollte festgelegt werden, dass die Kommunikation zwischen den einschlägigen Akteuren sowie die Einhaltung rechtlicher Verpflichtungen, einschließlich der Erstellung von Dokumentationen, Berichten und sonstigen Unterlagen sowie der Durchführung von Konformitätsbewertungsverfahren, grundsätzlich in digitaler Form möglich sein sollten. Darüber hinaus sollten digitale Formate, wie elektronische Signaturen, standardmäßig akzeptiert werden, sofern kein spezifisches Format vorgeschrieben ist.

<a id="rec-20"></a>
(20) Zur Vereinfachung der Vorschriften und zur Senkung der Kosten für die Einhaltung der Vorschriften sollten einige übermäßig detaillierte Anforderungen aufgehoben werden, etwa die Qualifikationsanforderungen an die für die Einhaltung der Regulierungsvorschriften verantwortliche Person oder die Anforderung ihrer ständigen und kontinuierlichen Verfügbarkeit, wenn diese nicht Teil der Organisation des Herstellers ist. Ferner sollten unnötige Melde- und Zertifizierungsanforderungen im Zusammenhang mit dem Umpacken oder der Neukennzeichnung von Medizinprodukten, die bereits in Verkehr gebracht und innerhalb des Binnenmarkts weiter vertrieben werden, beispielsweise außerhalb der offiziellen Vertriebssysteme des Herstellers, aufgehoben werden.

<a id="rec-21"></a>
(21) Der Bericht der Kommission^(42) über die Anwendung von Artikel 17 der Verordnung (EU) 2017/745 hob hervor, dass die Anwendung der Vorschriften über Einmalprodukte in der Union fragmentiert ist und die einschlägigen Anforderungen mit hohem Umsetzungsaufwand verbunden sind, was zu einem sehr begrenzten und wenig attraktiven Markt für die Aufbereitung von Einmalprodukten führt. Zur Vereinfachung der Vorschriften für Einmalprodukte und zur Erhöhung der Wiederverwendung von Medizinprodukten aus wirtschaftlichen und ökologischen Gründen sollte es in der Verantwortung des Herstellers liegen, auf der Grundlage der Merkmale und Eigenschaften des Medizinprodukts zu bestimmen, ob und wie ein Medizinprodukt aufbereitet werden kann. Sofern die Kennzeichnung als Einmalprodukt vom Hersteller ordnungsgemäß begründet ist, sollten Medizinprodukte der Aufbereitung unterliegen, während Einmalprodukte oder Medizinprodukte, die nicht weiter aufbereitet werden können, einer Neuaufbereitung unterliegen sollten.

<a id="rec-22"></a>
(22) Das System zur einmaligen Produktkennung (UDI) und die Registrierung von Medizinprodukten in der Europäischen Datenbank für Medizinprodukte (Eudamed) sind zentrale Instrumente zur Gewährleistung der Rückverfolgbarkeit und Transparenz von auf dem Unionsmarkt bereitgestellten Medizinprodukten. Zur Verbesserung der Klarheit und zur Erhöhung der Rechtssicherheit sollten die entsprechenden Bestimmungen zu diesen Instrumenten, die in den Verordnungen (EU) 2017/745 und (EU) 2017/746 festgelegt sind, klargestellt und gestrafft werden.

<a id="rec-23"></a>
(23) Der Einsatz künstlicher Intelligenz in Medizinprodukten und In-vitro-Diagnostika kann dazu beitragen, Innovation zu fördern und die Diagnose und Behandlung von Patientinnen und Patienten zu verbessern. Die parallele Anwendung der Verordnungen (EU) 2017/745 und (EU) 2017/746, soweit anwendbar, sowie der Verordnung (EU) 2024/1689^(43) des Europäischen Parlaments und des Rates könnte zu Überschneidungen von Anforderungen führen und Innovation hemmen. Um solche Überschneidungen zu vermeiden und den rechtlichen Rahmen für KI-gestützte Medizinprodukte zu vereinfachen, sollte die Anwendung der Verordnung (EU) 2024/1689 auf diese Produkte auf die in Artikel 2 Absatz 2 dieser Verordnung genannten Bestimmungen beschränkt werden. Die Verweise auf die Verordnungen (EU) 2017/745 und (EU) 2017/746 in Anhang I der Verordnung (EU) 2024/1689 sollten daher von Abschnitt A in Abschnitt B verschoben werden. Soweit erforderlich, kann die Kommission von ihren Durchführungs- und delegierten Befugnissen Gebrauch machen, um spezifische Anforderungen in Bezug auf künstliche Intelligenz festzulegen, wobei die in Kapitel III Abschnitt 2 der Verordnung (EU) 2024/1689 festgelegten Anforderungen zu berücksichtigen sind. Darüber hinaus sollten Benannte Stellen, die zur Bewertung von Hochrisiko-KI-Systemen benannt sind, die unter die Verordnungen (EU) 2017/745 oder (EU) 2017/746 fallen, gegebenenfalls auch die in Artikel 31 der Verordnung (EU) 2024/1689 festgelegten spezifischen KI-bezogenen Anforderungen erfüllen.

<a id="rec-24"></a>
(24) Der Kurzbericht über Sicherheit und klinische Leistung gemäß der Verordnung (EU) 2017/745 sowie der Kurzbericht über Sicherheit und Leistung gemäß der Verordnung (EU) 2017/746 gewährleisten Transparenz hinsichtlich der klinischen Nachweise, auf denen die Bewertung der Sicherheit und der Leistung des Medizinprodukts beruht. Da die Erstellung und Aktualisierung eines solchen Kurzberichts kostspielig ist, sollte der Anwendungsbereich dieser Anforderung klar auf diejenigen Medizinprodukte beschränkt werden, für die gemäß den Verordnungen (EU) 2017/745 und (EU) 2017/746 eine systematische Bewertung der technischen Dokumentation des Medizinprodukts erforderlich ist. Darüber hinaus sollte der Kurzbericht in einer für den vorgesehenen Anwender des Medizinprodukts verständlichen Weise erstellt werden. Zur Verringerung der Belastungen und zur Verbesserung der Kosteneffizienz sollten keine zusätzlichen Fassungen für andere Personengruppen, wie etwa Patientinnen und Patienten, verlangt werden. Zudem sollte keine gesonderte Validierung des Kurzberichts durch die Benannte Stelle erforderlich sein, da der Entwurf des Kurzberichts in jedem Fall Teil der der Benannten Stelle vorzulegenden Dokumentation ist. Darüber hinaus sollte eine Doppelung von Informationen, die in dem Kurzbericht und in der Gebrauchsanweisung bereitzustellen sind, vermieden werden.

<a id="rec-25"></a>
(25) Im Einklang mit den Verordnungen (EU) 2017/745 und (EU) 2017/746 nehmen Benannte Stellen eine Schlüsselfunktion im Regulierungssystem für Medizinprodukte wahr, da die Ausstellung einer Bescheinigung durch eine Benannte Stelle eine Voraussetzung für den Marktzugang der meisten Medizinprodukte ist. Um sicherzustellen, dass Medizinprodukte von einheitlichen und vorhersehbaren Bedingungen für den Marktzugang profitieren, sollten daher die Rechenschaftspflicht der Benannten Stellen sowie der Grad der Harmonisierung ihrer Konformitätsbewertungstätigkeiten gestärkt werden. Zu diesem Zweck sollte das Verfahren zur Bewertung der antragstellenden Benannten Stellen und ihrer Benennung gestrafft werden. Darüber hinaus sollte die Überwachung der Benannten Stellen durch die Einbeziehung gemeinsamer Bewertungsteams auch bei der laufenden Überwachung der Benannten Stellen verschärft werden. Angesichts dieser Änderungen ist eine vollständige Neubewertung der Benannten Stellen alle fünf Jahre nicht mehr erforderlich und sollte daher gestrichen werden.

<a id="rec-26"></a>
(26) Zur Straffung der Bewertung und Überwachung der Benannten Stellen sollten die gemeinsamen Bewertungsteams die für die Benannte Stelle zuständige nationale Behörde sowie Sachverständige aus anderen Mitgliedstaaten und von der Kommission benannte Sachverständige umfassen. Darüber hinaus sollte die für die Benannte Stelle zuständige nationale Behörde damit betraut werden, über Streitigkeiten zwischen Herstellern und Benannten Stellen zu entscheiden, die im Zusammenhang mit Konformitätsbewertungsverfahren entstehen.

<a id="rec-27"></a>
(27) Auch wenn die meisten Benannten Stellen private gewinnorientierte Einrichtungen sind, üben sie ihre Aufgaben im öffentlichen Interesse aus. In Bezug auf Hersteller, die Klein- oder Kleinstunternehmen im Sinne der Empfehlung 2003/361/EG^(44) der Kommission sind, sowie in Bezug auf Medizinprodukte für seltene Erkrankungen sollten Benannte Stellen daher verpflichtet werden, ihre Gebühren für Konformitätsbewertungstätigkeiten gemäß den Verordnungen (EU) 2017/745 und (EU) 2017/746 zu reduzieren.

<a id="rec-28"></a>
(28) Zur Verbesserung der Berechenbarkeit der von Benannten Stellen für Konformitätsbewertungen von Medizinprodukten gemäß den Verordnungen (EU) 2017/745 und (EU) 2017/746 erhobenen Gebühren und zur Verhinderung übermäßig hoher Gebühren sollte die Kommission ermächtigt werden, Durchführungsrechtsakte zu erlassen, um die Höhe und Struktur der von den Benannten Stellen erhobenen Gebühren festzulegen, unbeschadet der möglichen Anwendung der Artikel 101 und/oder 102 des Vertrags über die Arbeitsweise der Europäischen Union auf die Art und Weise, in der Benannte Stellen ihre Preise festsetzen oder ihre wirtschaftlichen Tätigkeiten ausüben.

<a id="rec-29"></a>
(29) Medizinprodukte werden je nach ihrem Risikoniveau in verschiedene Klassen eingestuft. Einige Klassifizierungsregeln sollten so angepasst werden, dass sie das von den Medizinprodukten ausgehende Risiko widerspiegeln, was zu einer Einstufung in eine niedrigere Risikoklasse führt, etwa bei wiederverwendbaren chirurgischen Instrumenten oder bei Zubehör für aktive implantierbare Medizinprodukte.

<a id="rec-30"></a>
(30) Bei Medizinprodukten mit niedrigem und mittlerem Risiko sollte die Beteiligung der Benannten Stellen am Konformitätsbewertungsprozess so reduziert werden, dass sie der Risikoklasse des Medizinprodukts angemessen ist. So sollte beispielsweise bei Medizinprodukten der Klasse IIa und nicht-implantierbaren Medizinprodukten der Klasse IIb oder bei den meisten Medizinprodukten der Klasse C, bei denen die Benannte Stelle die technische Dokumentation stichprobenweise zu bewerten hat, klargestellt werden, dass die Bewertung der technischen Dokumentation nur für ein repräsentatives Medizinprodukt einer Produktkategorie oder einer generischen Produktgruppe erforderlich ist oder – bei Medizinprodukten der Klasse B – nur für ein einziges Medizinprodukt aus dem Produktportfolio des Herstellers. Zusätzliche Bewertungen der technischen Dokumentation im Rahmen von Überwachungstätigkeiten sollten nur dann durchgeführt werden, wenn auf der Grundlage der aus dem System der Überwachung nach dem Inverkehrbringen verfügbaren Daten potenzielle Bedenken bestehen. Da sterile Medizinprodukte der Klasse A ein geringes Risiko aufweisen, sollte die Einbindung der Benannten Stellen für diese Medizinprodukte gestrichen werden.

<a id="rec-31"></a>
(31) Zur Unterstützung von Innovation sowie der Entwicklung und Verfügbarkeit von bahnbrechenden Technologien und von Medizinprodukten für kleine Patientengruppen sollten die Konformitätsbewertungsverfahren angepasst werden, um die spezifische Situation dieser Medizinprodukte zu berücksichtigen. Zu diesem Zweck sollten in den Verordnungen (EU) 2017/745 und (EU) 2017/746 Kriterien für bahnbrechende Medizinprodukte und Medizinprodukte für seltene Erkrankungen aufgenommen werden, die auf von der Koordinierungsgruppe Medizinprodukte erarbeiteten Leitlinien beruhen. Wird der Status als bahnbrechendes Medizinprodukt oder Medizinprodukt für seltene Erkrankungen durch ein Expertengremium bestätigt, sollte die Überprüfung des Medizinprodukts durch die Benannte Stelle priorisiert werden, gegebenenfalls unter Hinzuziehung zusätzlicher Beratung durch die Expertengremien.

<a id="rec-32"></a>
(32) Das in der Verordnung (EU) 2017/745 vorgesehene Konsultationsverfahren zur klinischen Bewertung ist ein Instrument zur Überprüfung der Bewertung von Benannten Stellen in Bezug auf bestimmte Hochrisiko-Medizinprodukte. Das Verfahren sollte auf Medizinprodukte ausgerichtet sein, bei denen diese außergewöhnliche Prüfung eine zusätzliche Gewähr für die Patientensicherheit bietet. Der Anwendungsbereich des Konsultationsverfahrens zur klinischen Bewertung sollte daher auf implantierbare Medizinprodukte der Klasse III beschränkt werden, wobei aktive Medizinprodukte der Klasse IIb, die zur Verabreichung und/oder Entfernung eines Arzneimittels bestimmt sind, aus diesem Anwendungsbereich herausgenommen werden. Es sollte jedoch die Möglichkeit bestehen, bestimmte Arten von Hochrisiko-Medizinprodukten durch einen delegierten Rechtsakt in den Anwendungsbereich des Konsultationsverfahrens zur klinischen Bewertung aufzunehmen, sofern dies aus Gründen der Patientensicherheit gerechtfertigt ist.

<a id="rec-33"></a>
(33) Das in der Verordnung (EU) 2017/746 vorgesehene Bewertungsverfahren zur Leistungsbewertung ist für bestimmte Medizinprodukte der Klasse D nicht wirksam, da es die Zuständigkeiten der Expertengremien und der Benannten Stellen vermischt. Es sollte daher aufgehoben und durch ein Verfahren der frühen wissenschaftlichen Beratung für In-vitro-Diagnostika mit hohem Risiko ersetzt werden, das Herstellern die Möglichkeit einräumt, bei den Expertengremien Beratung zu ihrer Leistungsbewertungsstrategie einzuholen.

<a id="rec-34"></a>
(34) Läuft die Gültigkeit einer von einer Benannten Stelle ausgestellten Bescheinigung für Medizinprodukte oder In-vitro-Diagnostika ab, haben die Benannten Stellen zu prüfen, ob die Bescheinigung verlängert werden kann. Dies führt zu Verwaltungsaufwand, Unsicherheit und unnötigen Kosten. Die maximale Geltungsdauer der von Benannten Stellen ausgestellten Bescheinigungen sollte daher aufgehoben werden, es sei denn, die Benannte Stelle hält es aus objektiv gerechtfertigten Gründen für erforderlich, die Geltungsdauer zu begrenzen, insbesondere im Fall einer unter Auflagen ausgestellten Bescheinigung, bei der der Hersteller im Rahmen der Überwachung nach dem Inverkehrbringen nach der Ausstellung zusätzliche klinische Daten zu erheben hat, wie dies bei Medizinprodukten mit bahnbrechender Technologie der Fall sein kann.

<a id="rec-35"></a>
(35) Um auf eine auf Unionsebene anerkannte gesundheitliche Notlage im Einklang mit der Verordnung (EU) 2022/2371 des Europäischen Parlaments und des Rates^(45) zu reagieren oder die Versorgung mit Medizinprodukten und In-vitro-Diagnostika sicherzustellen, die unter die Definition medizinische Gegenmaßnahmen im Rahmen der Verordnung (EU) 2022/2372 des Rates^(46) fallen, sollte die Kommission befugt sein, durch Durchführungsrechtsakte das Inverkehrbringen oder die Inbetriebnahme von Produkten zu genehmigen, für die keine Konformitätsbewertung gemäß den Verordnungen (EU) 2017/745 und (EU) 2017/746 durchgeführt wurde. Ferner sollten die Mitgliedstaaten oder die Kommission, wenn bestimmte CE-gekennzeichnete Produkte erforderlich sind, etwa in größerer Stückzahl oder mit einer angepassten Zweckbestimmung, um auf eine gesundheitliche Notlage, eine Katastrophe oder eine Krise zu reagieren, befugt sein, Hersteller von bestimmten Anforderungen im Zusammenhang mit der Herstellung, der Gestaltung oder der Zweckbestimmung des Produkts auszunehmen.

<a id="rec-36"></a>
(36) Um sicherzustellen, dass der Rechtsrahmen für die hochinnovativen Branchen der Medizinprodukte und In-vitro-Diagnostika zukunftssicher ist und Innovationen fördern kann, sollten die Mitgliedstaaten und die Kommission befugt sein, im Bereich der Medizinprodukte oder der In-vitro-Diagnostika Reallabore einzurichten, um unter strenger Aufsicht die Entwicklung und Erprobung innovativer Medizinprodukte oder regulatorischer Ansätze zu erleichtern.

<a id="rec-37"></a>
(37) Gemäß Artikel 4 der Richtlinie 2010/63/EU des Europäischen Parlaments und des Rates^(47) ist anstelle eines Tierversuchsverfahrens nach Möglichkeit eine wissenschaftlich zufriedenstellende Methode oder Versuchsstrategie anzuwenden, bei der keine lebenden Tiere verwendet werden. Tierversuchsfreie Tests wie auf neuen Ansätzen beruhende Methoden (New Approach Methodologies, NAMs), die innovative In-vitro-Ansätze (zell- oder gewebebasiert), In-chemico-Ansätze (chemiebasiert), In-silico-Ansätze (computergestützt) oder Kombinationen dieser Ansätze umfassen, können Tierversuche für Sicherheits- und Leistungsstudien zunehmend ersetzen oder ergänzen. Die Verwendung von tierversuchsfreien Methoden, einschließlich NAMs, zur Bereitstellung wissenschaftlicher Nachweise in klinischen und nichtklinischen Studien sollte daher gefördert werden.

<a id="rec-38"></a>
(38) Da sich die Sicherheit und Leistung vieler Produkte außerhalb der Hochrisikoklassen hinreichend anhand nichtklinischer Daten, einschließlich NAMs, nachweisen lassen, sollte die Möglichkeit, nichtklinische Daten zur Bestätigung der Sicherheit und Leistung eines Medizinprodukts im Rahmen der Konformitätsbewertung heranzuziehen, in der Verordnung (EU) 2017/745 stärker hervorgehoben werden.

<a id="rec-39"></a>
(39) Klinische Daten sind häufig für Medizinprodukte verfügbar, die dem im Rahmen der Konformitätsbewertung bewerteten Produkt gleichwertig sind. Um die Bedingungen, unter denen Hersteller Gleichwertigkeit geltend machen können, flexibler zu gestalten, sollten daher die in der Verordnung (EU) 2017/745 vorgesehene Anforderung eines Vertrags mit dem Hersteller des gleichwertigen Produkts, der den Zugang zu dessen technischer Dokumentation gewährt, gestrichen und die Gleichwertigkeitskriterien angepasst werden.

<a id="rec-40"></a>
(40) Die klinische Nachbeobachtung nach dem Inverkehrbringen ist eine wichtige Anforderung der Verordnung (EU) 2017/745, um etwaige Sicherheitsprobleme zu ermitteln, die während der Anwendung des Produkts unter realen Bedingungen auftreten können. Um die Anzahl der von den Herstellern zu erstellenden Berichte zu verringern, sollten Hersteller befugt sein, die Ergebnisse der klinischen Nachbeobachtung nach dem Inverkehrbringen unmittelbar in den aktualisierten klinischen Bewertungsbericht aufzunehmen, ohne dass ein gesonderter Bewertungsbericht für die klinische Nachbeobachtung erstellt werden muss.

<a id="rec-41"></a>
(41) Die Verpflichtung zur Erstellung eines regelmäßig aktualisierten Berichts über die Sicherheit (im Folgenden „Sicherheitsbericht“) ist ein wichtiges Instrument, das in den Verordnungen (EU) 2017/745 und (EU) 2017/746 vorgesehen ist und die Hersteller verpflichtet, die Sicherheit und Leistung eines Produkts während seines gesamten Lebenszyklus zu überprüfen. Um unnötige Kosten und administrativen Aufwand für die Hersteller zu vermeiden und die Verpflichtung verhältnismäßiger zu gestalten, sollte die Häufigkeit der Aktualisierung des Sicherheitsberichts in Abhängigkeit von der Risikoklasse des Produkts verringert werden.

<a id="rec-42"></a>
(42) Unnötige Überschneidungen und Doppelprüfungen zwischen den verschiedenen Akteuren im Regulierungssystem wirken sich negativ auf dessen Effizienz und Kohärenz aus. Daher sollten die Rollen und Zuständigkeiten der zuständigen Behörden und der Benannten Stellen, insbesondere im Hinblick auf die Bewertung von Vigilanz-Fällen, klargestellt und etwaige unnötige Elemente gestrichen werden.

<a id="rec-43"></a>
(43) Es gibt eine zunehmende Zahl klinischer Studien, die gleichzeitig eine klinische Prüfung eines Arzneimittels, die der Verordnung (EU) Nr. 536/2014 des Europäischen Parlaments und des Rates^(48) unterliegt, eine Leistungsstudie eines In-vitro-Diagnostikums, die der Verordnung (EU) 2017/746 unterliegt, oder eine klinische Prüfung eines Medizinprodukts, die der Verordnung (EU) 2017/745 unterliegt, umfassen (im Folgenden „kombinierte Studien“). Um den geäußerten Bedenken hinsichtlich der Komplexität der Anwendung mehrerer Verordnungen auf diese kombinierten Studien zu begegnen, sollten Sponsoren in die Lage versetzt werden, einen einzigen Antrag für eine kombinierte Studie einzureichen, der zu einer koordinierten Bewertung gemäß der Verordnung (EU) Nr. 536/2014 führt. Die Verordnungen (EU) 2017/746 und (EU) 2017/745 sollten keine Anwendung finden, wenn ein einziger Antrag eingereicht wurde.

<a id="rec-44"></a>
(44) Die Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates^(49) verpflichtet Hersteller, aktiv ausgenutzte Schwachstellen und schwerwiegende Sicherheitsvorfälle, die Auswirkungen auf die Sicherheit von Produkten mit digitalen Elementen haben, zu melden, um sicherzustellen, dass die als Koordinatoren benannten zuständigen nationalen Computer-Notfallteams (im Folgenden „CSIRTs“) sowie die Agentur der Europäischen Union für Cybersicherheit (im Folgenden „ENISA“) einen angemessenen Überblick über Schwachstellen und Sicherheitsvorfälle erhalten, die den Binnenmarkt beeinträchtigen. Medizinprodukte und In-vitro-Diagnostika sind jedoch von der Verordnung (EU) 2024/2847 ausgenommen. Während Cybersicherheitsvorfälle, sofern sie als schwerwiegende Vorkommnisse einzustufen sind, gemäß den bestehenden Vigilanzvorschriften der Verordnungen (EU) 2017/745 und (EU) 2017/746 zu melden sind, werden Cybersicherheitsvorfälle, die weder die öffentliche Gesundheit noch die Patientensicherheit betreffen, nicht gemeldet. Dies stellt eine erhebliche Lücke im Bereich der Cybersicherheit dar. Hersteller vernetzter Produkte sollten daher verpflichtet werden, auch diese Vorfälle über Eudamed an die CSIRTs und ENISA zu melden.

<a id="rec-45"></a>
(45) Die zentralen Akteure im Rahmen der Verordnungen (EU) 2017/745 und (EU) 2017/746, nämlich Hersteller, zuständige Behörden, Benannte Stellen und die Kommission, sollten Zugang zu Sachverständigen mit einschlägiger wissenschaftlicher, klinischer, technischer und regulatorischer Fachkompetenz haben. Eine verstärkte Koordinierung und ein verbesserter Zugang zu Fachkompetenz führen zu einem vorhersehbaren und verlässlichen Regulierungsrahmen. Die Art der in den Expertengremien verfügbaren Fachkompetenz, der Bereich der Themen, zu denen die Expertengremien Beratung leisten, sowie ihre Einbindung in das in den Verordnungen (EU) 2017/745 und (EU) 2017/746 festgelegte Regulierungssystem sollten daher ausgeweitet werden. Das Mandat der EMA, die Expertengremien gemäß der Verordnung (EU) 2022/123 zu unterstützen, sollte entsprechend geändert werden.

<a id="rec-46"></a>
(46) Die Verordnungen (EU) 2017/745 und (EU) 2017/746 sehen ein dezentralisiertes Regulierungssystem vor. Eine wirksame Koordinierung zwischen den nationalen Behörden ist unerlässlich, um das reibungslose Funktionieren des Binnenmarkts und eine kohärente Anwendung der in den Verordnungen festgelegten Anforderungen sicherzustellen und ein einheitlich hohes Schutzniveau für die Patientensicherheit und die öffentliche Gesundheit zu gewährleisten. Für eine wirksame und effiziente Koordinierung benötigen die nationalen Behörden wissenschaftliche, technische und administrative Unterstützung, die am geeignetsten von der EMA bereitgestellt werden kann, da sie bereits die Expertengremien für Medizinprodukte verwaltet. Die EMA sollte daher im Namen der Kommission beauftragt werden, die für die Koordinierung zwischen den zuständigen nationalen Behörden erforderliche Unterstützung bereitzustellen, um die einheitliche Anwendung der Verordnungen (EU) 2017/745 und (EU) 2017/746 zu erleichtern.

<a id="rec-47"></a>
(47) Die Union beteiligt sich am Internationalen Forum der Aufsichtsbehörden für Medizinprodukte (im Folgenden „IMP-VOF“)^(50), einer freiwilligen Gruppe von Regulierungsbehörden aus der ganzen Welt, die darauf abzielt, die internationale regulatorische Harmonisierung und Konvergenz im Bereich der Medizinprodukte und In-vitro-Diagnostika zu beschleunigen. Das Regulierungssystem der Union für Medizinprodukte spiegelt in weiten Teilen die im Rahmen des IMP-VOF entwickelten Leitlinien wider. Um die Effizienz zu steigern, Doppelarbeit bei Regulierungsmaßnahmen zu verringern und die globale Konvergenz zu fördern, sollten die Kommission und die Mitgliedstaaten aktiv an internationalen regulatorischen Kooperations- und Anerkennungsmechanismen oder Anerkennungsprogrammen teilnehmen und diese nutzen.

<a id="rec-48"></a>
(48) Um Missverständnisse in Bezug auf Kits für In-vitro-Diagnostika, die Produkte umfassen, die anderen Rechtsvorschriften der Union unterliegen, etwa Arzneimittel, zu vermeiden, sollte klargestellt werden, dass die in diesen Kits enthaltenen Produkte den jeweils für sie geltenden Rechtsvorschriften entsprechen müssen.

<a id="rec-49"></a>
(49) Mit der Verordnung (EU) 2017/746 wurden spezifische Vorschriften für therapiebegleitende Diagnostika eingeführt. Aufgrund der bei der Anwendung dieser Vorschriften gewonnenen Erfahrungen ist es erforderlich, in der Definition der therapiebegleitenden Diagnostika klarzustellen, dass ein therapiebegleitendes Diagnostikum mit mehr als einem Arzneimittel verknüpft sein kann. Ferner sollte zur Vermeidung jeglicher unnötiger Doppelarbeit bei der Bewertung therapiebegleitender Diagnostika klargestellt werden, dass die Konsultation einer Arzneimittelbehörde nur bei neuartigen therapiebegleitenden Diagnostika erforderlich ist und dass eine konsultierte Arzneimittelbehörde die von der Benannten Stelle durchgeführte Bewertung nicht erneut vornehmen sollte.

<a id="rec-50"></a>
(50) Leistungsstudien sind eine wichtige Quelle klinischer Nachweise für In-vitro-Diagnostika. Die für die Durchführung von Leistungsstudien geltenden Vorschriften sollten in den Fällen vereinfacht werden, in denen für die Studienteilnehmer keine zusätzlichen Risiken bestehen, etwa wenn die Studie routinemäßige Blutentnahmen bei nicht schutzbedürftigen Personen umfasst oder wenn Studien zu therapiebegleitenden Diagnostika unter Verwendung von Restproben durchgeführt werden.

<a id="rec-51"></a>
(51) Der Übergang vom früheren Regulierungsrahmen zu dem in den Verordnungen (EU) 2017/745 und (EU) 2017/746 festgelegten Rahmen hat dazu geführt, dass die Versorgung mit bestimmten Produkten, die für kleine Patientengruppen bestimmt sind, beendet wurde, da die mit dem Übergang verbundenen Kosten die Durchführung einer Konformitätsbewertung gemäß diesen Verordnungen für die Hersteller wirtschaftlich erschwerten. Die Einstellung dieser Medizinprodukte für seltene Erkrankungen gefährdet das Versorgungsniveau und den Patientenschutz, wenn keine alternativen Diagnose- oder Behandlungsmethoden verfügbar sind. Hersteller sollten daher unter bestimmten Bedingungen befugt sein, Medizinprodukte für seltene Erkrankungen, die rechtmäßig gemäß den Richtlinien 90/385/EWG, 93/42/EWG und 98/79/EG in Verkehr gebracht wurden, weiterhin in Verkehr zu bringen, ohne dass ein Konformitätsbewertungsverfahren nach den Verordnungen (EU) 2017/745 und (EU) 2017/746 durchgeführt werden muss.

<a id="rec-52"></a>
(52) Bestimmte Anhänge der Verordnungen (EU) 2017/745 und (EU) 2017/746, die die für Benannte Stellen, Wirtschaftsakteure und Produkte geltenden Pflichten und Anforderungen weiter präzisieren, sollten an die in den entsprechenden Bestimmungen dieser Verordnungen vorgenommenen Änderungen angepasst werden, um dieselben Ziele widerzuspiegeln, nämlich Vereinfachung, Abbau von Belastungen, eine höhere Kosteneffizienz des Zertifizierungsverfahrens sowie eine weitere Digitalisierung.

<a id="rec-53"></a>
(53) Um die Kosten und die Dauer der Konformitätsbewertungsverfahren für Medizinprodukte, die einen Arzneistoff oder eine SoHO integrieren, zu verringern, sollte die Konsultation der Arzneimittelbehörden oder der SoHO-Behörden gestrafft und verkürzt werden. Stoffliche Medizinprodukte, die vom menschlichen Körper systemisch aufgenommen werden, sind Medizinprodukte. Sie enthalten keinen Stoff, der bei gesonderter Verwendung unter die Rechtsvorschriften der Union über Arzneimittel fallen würde. Die Konsultation einer Arzneimittelbehörde im Rahmen der Konformitätsbewertung solcher stofflichen Medizinprodukte ist nicht sachgerecht und sollte daher gestrichen werden.

<a id="rec-54"></a>
(54) Mit den Verordnungen (EU) 2017/745 und (EU) 2017/746 wurde der Kommission die Befugnis übertragen, gemäß Artikel 290 AEUV delegierte Rechtsakte zu erlassen, um bestimmte nicht wesentliche Vorschriften der Verordnungen (EU) 2017/745 und (EU) 2017/746 zu ändern. Unter Berücksichtigung der bei der Anwendung dieser Verordnungen gewonnenen Erfahrungen sowie der Notwendigkeit, ein gewisses Maß an Flexibilität in Bezug auf die häufig sehr technischen und Verfahrensvorschriften dieser Verordnungen zu wahren, sollte die Befugnis zum Erlass delegierter Rechtsakte auch für weitere nicht wesentliche Vorschriften der Verordnungen (EU) 2017/745 und (EU) 2017/746 vorgesehen werden, um diese an die bei ihrer Anwendung gewonnenen Erfahrungen, den wissenschaftlichen oder technischen Fortschritt oder Entwicklungen auf internationaler Ebene anzupassen.

<a id="rec-55"></a>
(55) Mit den Verordnungen (EU) 2017/745 und (EU) 2017/746 wurde der Kommission die Befugnis übertragen, Durchführungsrechtsakte zu erlassen. Zur Gewährleistung einheitlicher Bedingungen für die Durchführung dieser Verordnungen sollten der Kommission zusätzliche Durchführungsbefugnisse übertragen werden.

<a id="rec-56"></a>
(56) Da die Ziele der vorliegenden Verordnung, nämlich die Vereinfachung und der Abbau von Belastungen durch Vorschriften über Medizinprodukte und In-vitro-Diagnostika, unter gleichzeitiger Wahrung der Ziele der Verordnungen (EU) 2017/745 und (EU) 2017/746, von den Mitgliedstaaten nicht ausreichend verwirklicht werden können, sondern wegen des Umfangs oder der Wirkungen der Maßnahme besser auf Unionsebene zu erreichen sind, kann die Union im Einklang mit dem in Artikel 5 des Vertrags über die Europäische Union verankerten Subsidiaritätsprinzip Maßnahmen erlassen. Entsprechend dem in demselben Artikel genannten Grundsatz der Verhältnismäßigkeit geht diese Verordnung nicht über das für die Verwirklichung dieser Ziele erforderliche Maß hinaus.

<a id="rec-57"></a>
(57) Die Verordnungen (EU) 2017/745 und (EU) 2017/746 sollten daher entsprechend geändert werden.

<a id="rec-58"></a>
(58) Um allen betroffenen Parteien ausreichend Zeit einzuräumen, die zur Einhaltung dieser Verordnung erforderlichen Maßnahmen zu ergreifen, sollte die Anwendung bestimmter Bestimmungen aufgeschoben werden. Bestimmungen, die keine Vorbereitungszeit erfordern, sollten jedoch ab dem Datum des Inkrafttretens dieser Verordnung gelten.

<a id="rec-59"></a>
(59) Mit dieser Verordnung werden verbindliche Anforderungen an grenzüberschreitende digitale öffentliche Dienste im Sinne der Verordnung (EU) 2024/903 des Europäischen Parlaments und des Rates^(51) eingeführt. Daher wurde eine Interoperabilitätsbewertung abgeschlossen. Das Kapitel über die digitale Dimension des Finanz- und Digitalbogens zu Rechtsakten stellt den daraus resultierenden Bericht dar.

HABEN FOLGENDE VERORDNUNG ERLASSEN:

<a id="art-1"></a>
### Artikel 1

Änderungen der Verordnung (EU) 2017/745

Die Verordnung (EU) 2017/745 wird wie folgt geändert:

- 1. Artikel 1 wird wie folgt geändert:

  - a) Absatz 2 Satz 1 erhält folgende Fassung:

      „Diese Verordnung gilt des Weiteren ab dem Geltungsbeginn der gemäß Artikel 9 erlassenen gemeinsamen Spezifikationen auch für die in Anhang XVI aufgeführten Produktgruppen ohne medizinische Zweckbestimmung sowie für deren Zubehör, unter Berücksichtigung des Stands der Technik und insbesondere der bestehenden harmonisierten Normen für analoge Produkte mit medizinischer Zweckbestimmung, die auf ähnlicher Technologie beruhen.“

  - b) Absatz 4 erhält folgende Fassung:

    - „(4) Für die Zwecke dieser Verordnung werden Medizinprodukte und ihr Zubehör sowie die in Anhang XVI aufgeführten Produkte und ihr Zubehör, auf die diese Verordnung gemäß Absatz 2 Anwendung findet, im Folgenden als ‚Produkte‘ bezeichnet.“

  - c) Absatz 6 Buchstabe g erhält folgende Fassung:

    - „g) zur Transplantation bestimmte Organe, die in den Anwendungsbereich der Richtlinie 2010/53/EU des Europäischen Parlaments und des Rates* fallen, oder Substanzen menschlichen Ursprungs, die in den Anwendungsbereich der Verordnung (EU) 2024/1938 des Europäischen Parlaments und des Rates** fallen, oder deren Derivate oder Produkte, die diese enthalten oder aus ihnen bestehen; allerdings gilt diese Verordnung für Produkte, die aus Derivaten von Substanzen menschlichen Ursprungs hergestellt sind, die nicht lebensfähig sind oder abgetötet wurden;

    - ______________________

    - * Verordnung (EU) 2024/1938 des Europäischen Parlaments und des Rates vom 13. Juni 2024 über Qualitäts- und Sicherheitsstandards für zur Verwendung beim Menschen bestimmte Substanzen menschlichen Ursprungs und zur Aufhebung der Richtlinien 2002/98/EG und 2004/23/EG (ABl. L, 2024/1938, 17.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1938/oj ).

    - ** Richtlinie 2010/53/EU des Europäischen Parlaments und des Rates vom 7. Juli 2010 über Qualitäts- und Sicherheitsstandards für zur Transplantation bestimmte menschliche Organe (ABl. L 207 vom 6.8.2010, S. 14, ELI: http://data.europa.eu/eli/dir/2010/53/oj).“

  - d) Absatz 7 erhält folgende Fassung:

    - „(7) Jedes Produkt, das beim Inverkehrbringen oder bei der Inbetriebnahme als integralen Bestandteil ein In-vitro-Diagnostikum im Sinne von Artikel 2 Nummer 2 der Verordnung (EU) 2017/746 enthält, dem im Rahmen des Produkts, in das es integriert ist, eine unterstützende Funktion zukommt, unterliegt dieser Verordnung. In diesem Fall gelten die einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I der Verordnung (EU) 2017/746 in Bezug auf die Sicherheit und Leistung des aus dem In-vitro-Diagnostikum bestehenden Teils.

        Ist jedoch die Wirkung des In-vitro-Diagnostikums maßgeblich und kommt diesem im Rahmen des Produkts, in das es integriert ist, keine unterstützende Funktion zu, so unterliegt das Gesamtprodukt der Verordnung (EU) 2017/746. In diesem Fall gelten die einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I dieser Verordnung in Bezug auf die Sicherheit und Leistung des aus dem Medizinprodukt bestehenden Teils.“

  - e) Absatz 10 wird wie folgt geändert:

    - i) Unterabsatz 1 erhält folgende Fassung:

      - „Jedes Produkt, das beim Inverkehrbringen oder bei der Inbetriebnahme als integralen Bestandteil nicht lebensfähige Substanzen menschlichen Ursprungs oder deren Derivate enthält, denen im Rahmen des Produkts, in das sie integriert sind, eine unterstützende Funktion zukommt, ist gemäß dieser Verordnung zu bewerten und zuzulassen.“

    - ii) In Unterabsatz 2 Satz 1 wird die Bezugnahme auf „Richtlinie 2004/23/EG“ durch eine Bezugnahme auf „Verordnung (EU) 2024/1938“ ersetzt.

- 2. Artikel 2 wird wie folgt geändert:

  - a) in Nummer 1 erhält Unterabsatz 2 folgende Fassung:

      „Die folgenden Produkte gelten ebenfalls als Medizinprodukte:

    - – Produkte zur Empfängnisverhütung oder -förderung,

    - – Produkte, die speziell zur Reinigung, Desinfektion oder Sterilisation der in Artikel 1 Absatz 4 genannten Produkte bestimmt sind.“

  - b) Nummer 7 erhält folgende Fassung:

    - „7. ‚generische Produktgruppe‘ bezeichnet eine Gruppe von Produkten mit gleichen oder ähnlichen Zweckbestimmungen und mit technologischen Gemeinsamkeiten, die allgemein, also ohne Berücksichtigung spezifischer Merkmale klassifiziert werden können;“

  - c) Die Nummern 18, 19, 20 und 21 werden gestrichen.

  - d) Nummer 48 erhält folgende Fassung:

    - „48. ‚klinische Daten‘ bezeichnet Angaben zur Sicherheit oder Leistung, die im Rahmen der Anwendung eines Produkts gewonnen werden und aus einer der folgenden Quellen stammen:

      - – klinische Prüfungen des betreffenden Produkts oder eines Produkts, für das die Gleichwertigkeit mit dem betreffenden Produkt nachgewiesen werden kann,

      - – sonstige in der wissenschaftlichen Literatur veröffentlichte Studien zu dem betreffenden Produkt oder zu einem Produkt, für das die Gleichwertigkeit mit dem betreffenden Produkt nachgewiesen werden kann,

      - – sonstige klinische Erfahrungen, die in einem Peer-Review unterzogener wissenschaftlicher Literatur veröffentlicht wurden, mit dem betreffenden Produkt oder mit einem Produkt, für das die Gleichwertigkeit mit dem betreffenden Produkt nachgewiesen werden kann,

      - – klinisch relevante Angaben aus der Überwachung nach dem Inverkehrbringen, insbesondere aus der klinischen Nachbeobachtung nach dem Inverkehrbringen;“

  - e) die folgenden Nummern 72, 73, 74, 75 und 76 werden angefügt:

    - „72. ‚Produkt mit bewährter Technologie‘ bezeichnet ein Produkt, das einer generischen Produktgruppe angehört und die folgenden Kriterien erfüllt:

      - a) es weist eine einfache, einheitliche und stabile Konstruktion auf;

      - b) es bestanden in der Vergangenheit keine Sicherheitsprobleme in Verbindung mit diesem Produkt;

      - c) es weist bekannte Merkmale hinsichtlich der klinischen Leistung auf und umfasst medizinische Standardprodukte, bei denen sich die Indikationen und der Stand der Technik kaum weiterentwickeln;

      - d) es ist bereits seit langer Zeit auf dem Unionsmarkt;“

    - 73. ‚kombinierte Studie‘ bezeichnet eine klinische Prüfung eines oder mehrerer Arzneimittel im Sinne von Artikel 2 Absatz 2 Nummer 2 der Verordnung (EU) Nr. 536/2014, in Verbindung mit einer Leistungsstudie eines oder mehrerer In-vitro-Diagnostika im Sinne von Artikel 2 Nummer 42 der Verordnung (EU) 2017/746 und/oder mit einer klinischen Prüfung eines oder mehrerer Produkte;

    - 74. ‚Reallabor‘ bezeichnet eine von einer zuständigen Behörde eingerichtete kontrollierte Umgebung, in der Hersteller oder potenzielle Hersteller unter regulatorischer Aufsicht ein innovatives Produkt oder eine innovative Technologie, die möglicherweise in den Anwendungsbereich dieser Verordnung fällt, für einen begrenzten Zeitraum nach einem Reallabor-Plan entwickeln, testen, validieren und – sofern angezeigt – unter realen Bedingungen anwenden können;

    - 75. ‚Reallabor-Plan‘ bezeichnet ein zwischen dem oder den teilnehmenden Hersteller(n) bzw. potenziellen Hersteller(n) und der zuständigen Behörde vereinbartes Dokument, das die Ziele, Bedingungen, den Zeitrahmen, die Methodik und die Anforderungen für die im Reallabor durchgeführten Tätigkeiten beschreibt;

    - 76. ‚Reallabor der Union‘ bezeichnet eine von der Kommission eingerichtete kontrollierte Umgebung zur Erprobung über einen begrenzten Zeitraum von alternativen oder neuen regulatorischen Anforderungen oder Durchsetzungspraktiken sowie zur Bewertung ihrer Validität im Vergleich zu den bestehenden Anforderungen und Praktiken nach dieser Verordnung.“

- 3. Die Artikel 3 und 4 erhalten folgende Fassung:

**„Artikel 3**

Änderung und Anwendung bestimmter Begriffsbestimmungen

  - (1) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um die in Artikel 2 Nummer 72 festgelegte Begriffsbestimmung eines Produkts mit bewährter Technologie unter Berücksichtigung des technischen und wissenschaftlichen Fortschritts und der auf Unionsebene und auf internationaler Ebene vereinbarten Begriffsbestimmungen zu ändern.

  - (2) Die Kommission kann im Wege von Durchführungsrechtsakten nicht erschöpfende Listen von Produkten erstellen, die unter die Begriffsbestimmung eines Produkts mit bewährter Technologie gemäß Artikel 2 Nummer 72 fallen oder von Produkten, die nicht darunter fallen.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

<a id="art-4"></a>
### Artikel 4

Rechtlicher Status von Produkten

  - (1) Die zuständigen Behörden der Mitgliedstaaten koordinieren ihre Tätigkeiten, wenn sie feststellen, ob ein bestimmtes Produkt, eine Produktkategorie oder eine Produktgruppe unter die Begriffsbestimmung ‚Medizinprodukt‘ gemäß Artikel 2 Nummer 1 oder unter die Begriffsbestimmung ‚Zubehör eines Medizinprodukts‘ gemäß Artikel 2 Nummer 2 fällt oder ob ein Produkt in den Anwendungsbereich von Anhang XVI fällt oder das Zubehör eines in diesem Anhang aufgeführten Produkts ist.

  - (2) Die Mitgliedstaaten stellen ein angemessenes Maß an Anhörung der einschlägigen zuständigen Behörden der Mitgliedstaaten in den Bereichen In-vitro-Diagnostika, Arzneimittel, Substanzen menschlichen Ursprungs (SoHO), Biozidprodukte, Lebensmittel, kosmetische Mittel oder sonstige Produkte, die Unionsrechtsvorschriften unterliegen, sicher, wenn die Feststellung, ob ein Produkt den rechtlichen Status eines Medizinprodukts hat, Aspekte betrifft, die die Abgrenzung zu einer dieser Produktarten berühren. Ist dies der Fall, stellen die Mitgliedstaaten außerdem ein angemessenes Maß an Anhörung der einschlägigen Beratungs- oder Regulierungsstellen sicher, die gemäß den einschlägigen Rechtsvorschriften der Union eingerichtet wurden, wie etwa der Europäischen Arzneimittel-Agentur (EMA), dem SoHO-Koordinierungsgremium, der Europäischen Chemikalienagentur (ECHA) und der Europäischen Behörde für Lebensmittelsicherheit (EFSA).

  - (3) Ist eine zuständige Behörde eines Mitgliedstaats nach Durchführung einer Bewertung gemäß Artikel 94 der Auffassung, dass ein Produkt, das gemäß Artikel 20 mit der CE-Kennzeichnung versehen ist, nicht in den Anwendungsbereich dieser Verordnung fällt, so konsultiert sie die zuständigen Behörden der anderen Mitgliedstaaten zu der von ihr beabsichtigten Maßnahme zur Feststellung des rechtlichen Status des betreffenden Produkts.

  - (4) Erhebt eine zuständige Behörde eines Mitgliedstaats einen begründeten Einwand gegen die in Absatz 3 genannte beabsichtigte Maßnahme, so legt die konsultierende Behörde die Angelegenheit einem Expertengremium gemäß Artikel 106 vor und trägt dessen Stellungnahme weitestgehend Rechnung.

  - (5) Die Ergebnisse der Koordinierungstätigkeiten der zuständigen Behörden gemäß diesem Artikel sowie die Stellungnahmen des Expertengremiums, die gemäß Absatz 4 dieses Artikels und Artikel 4a Absatz 2 abgegeben wurden, werden öffentlich zugänglich gemacht, ohne dass dabei vertrauliche Informationen im Sinne von Artikel 109 offengelegt werden.

  - (6) Die Kommission kann im Wege von Durchführungsrechtsakten das Verfahren, einschließlich der Fristen, für die Anwendung der Absätze 1 bis 4 dieses Artikels sowie des Artikels 4a festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.“

- 4. Folgender Artikel 4a wird eingefügt:

**„Artikel 4a**

Stellungnahme zum und Feststellung des rechtlichen Status eines Produkts

  - (1) Eine zuständige Behörde, eine Benannte Stelle, ein Hersteller, ein Entwickler eines Produkts oder die Kommission können einen begründeten Antrag auf Abgabe einer Stellungnahme durch ein Expertengremium gemäß Artikel 106 zu der Frage stellen, ob ein bestimmtes Produkt, eine Produktkategorie oder eine Produktgruppe unter die Begriffsbestimmungen ‚Medizinprodukt‘ oder ‚Zubehör eines Medizinprodukts‘ fällt oder ob ein Produkt in den Anwendungsbereich von Anhang XVI fällt oder das Zubehör eines in diesem Anhang aufgeführten Produkts ist. Hält der Antragsteller in einem solchen Antrag das betreffende Produkt für ein Medizinprodukt, so ist in dem Antrag außerdem die vorgeschlagene Klassifizierung des Medizinprodukts gemäß Artikel 51 und Anhang VIII anzugeben.

  - (2) Das Expertengremium gibt seine Stellungnahme unverzüglich ab. Der Antragsteller trägt der Stellungnahme des Expertengremiums weitestgehend Rechnung.

  - (3) Unter Berücksichtigung der in Absatz 2 oder in Artikel 4 Absatz 4 genannten Stellungnahme des Expertengremiums kann ein Mitgliedstaat der Kommission einen begründeten Antrag unterbreiten, um feststellen zu lassen, ob ein bestimmtes Produkt, eine Produktkategorie oder eine Produktgruppe unter die Begriffsbestimmungen ‚Medizinprodukt‘ oder ‚Zubehör eines Medizinprodukts‘ fällt oder ob ein Produkt in den Anwendungsbereich von Anhang XVI fällt oder das Zubehör eines in diesem Anhang aufgeführten Produkts ist.

      Die Kommission entscheidet über den begründeten Antrag des Mitgliedstaats oder von sich aus im Wege von Durchführungsrechtsakten, die gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen werden.

      Die Kommission kann das Expertengremium um Klarstellungen ersuchen oder die Stellungnahme zur weiteren Prüfung an das Expertengremium zurückverweisen, einschließlich in Fällen, in denen der begründete Antrag eines Mitgliedstaats neue wissenschaftliche oder technische Fragen aufwirft.

  - (4) Dieser Artikel findet keine Anwendung, wenn das betreffende Produkt, die betreffende Produktkategorie oder die betreffende Produktgruppe nach ihrem im Rahmen anderer Rechtsvorschriften der Union festgestellten rechtlichen Status in den Anwendungsbereich dieser anderen Rechtsvorschriften der Unionfallen oder wenn im Rahmen anderer Rechtsvorschriften der Union ein Verfahren zur Feststellung des rechtlichen Status anhängig ist.“

- 5. Artikel 5 wird wie folgt geändert:

  - a) Absatz 5 wird wie folgt geändert:

    - i) Unterabsatz 1 wird wie folgt geändert:

      - 1. Buchstabe a erhält folgende Fassung:

        - „a) Die Produkte werden nicht an eine andere juristische Person abgegeben, es sei denn an eine andere Gesundheitseinrichtung im ordnungsgemäß begründeten Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten oder zur Vorbereitung oder als Reaktion auf eine gesundheitliche Notlage;“

      - 2. Buchstabe d erhält folgende Fassung:

        - „d) auf Ersuchen einer zuständigen Behörde stellt die Gesundheitseinrichtung auf Anfrage Informationen über die Verwendung solcher Produkte bereit, einschließlich der in den Buchstaben a und c genannten Begründung;“

      - 3. Buchstabe f erhält folgende Fassung:

        - „f) die Gesundheitseinrichtung erstellt Unterlagen, die hinreichend detailliert sind, damit sich die zuständige Behörde vergewissern kann, dass die einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I erfüllt sind;“

      - 4. Buchstabe g wird gestrichen.

    - ii) Unterabsatz 2 erhält folgende Fassung:

        „Die Mitgliedstaaten haben nach wie vor das Recht, die Herstellung oder die Verwendung bestimmter Arten solcher Produkte einzuschränken, und sie erhalten Zugang zu den Gesundheitseinrichtungen, um deren Tätigkeiten zu überprüfen.“

    - iii) Die folgenden drei Unterabsätze werden angefügt:

        „Für die Zwecke von Unterabsatz 1 Buchstabe a stellen im Falle einer Abgabe des Produkts an eine andere Gesundheitseinrichtung die abgebende und die empfangende Gesundheitseinrichtung die Rückverfolgbarkeit des Produkts sicher.

        Für die Zwecke von Unterabsatz 1 Buchstabe c kann die Gesundheitseinrichtung ab dem Zeitpunkt, zu dem sie davon Kenntnis erlangt, dass die spezifischen Erfordernisse der Patientenzielgruppe durch ein auf dem Markt verfügbares Produkt befriedigt werden können, ihr Produkt für einen Zeitraum von höchstens zehn Jahren weiter herstellen und verwenden.

        Für die Zwecke von Unterabsatz 1 Buchstabe h meldet im Fall einer Produktabgabe gemäß Buchstabe a die empfangende Gesundheitseinrichtung jedes das Produkt betreffende Vorkommnis an die abgebende Gesundheitseinrichtung.“

  - b) Die folgenden Absätze 7 und 8 werden angefügt:

    - „(7) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um die grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I an den wissenschaftlichen oder technischen Fortschritt oder an Entwicklungen auf internationaler Ebene anzupassen oder Anforderungen in Bezug auf neu entstehende Risiken oder Technologien hinzuzufügen.

    - (8) Bei der Annahme von Durchführungsrechtsakten gemäß Absatz 6 dieses Artikels, delegierten Rechtsakten gemäß Absatz 7 dieses Artikels oder gemeinsamen Spezifikationen gemäß Artikel 9 dieser Verordnung in Bezug auf Produkte, die Hochrisiko-KI-Systeme im Sinne von Artikel 6 Absatz 1 der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates*** darstellen oder Hochrisiko-KI-Systeme als Sicherheitskomponenten verwenden, berücksichtigt die Kommission die in Kapitel III Abschnitt 2 der genannten Verordnung festgelegten Anforderungen.

    - __________________

    - *** Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: ).“

- 6. Artikel 6 wird wie folgt geändert:

  - a) Folgender Absatz 2a wird eingefügt:

    - „(2a) Jede natürliche oder juristische Person, die gemäß Absatz 1 ein Produkt anbietet oder gemäß Absatz 2 eine Dienstleistung erbringt, macht im Angebot mindestens die in Anhang I Abschnitt 23.2 Buchstaben a bis d und m genannten Informationen und gewährt Zugang zur Gebrauchsanweisung.“

  - b) Die Absätze 3 und 4 erhalten folgende Fassung:

    - „(3) Jede natürliche oder juristische Person, die gemäß Absatz 1 ein Produkt anbietet oder gemäß Absatz 2 eine Dienstleistung erbringt, stellt auf Verlangen einer zuständigen Behörde eine Kopie der gemäß Artikel 19 erstellten EU-Konformitätserklärung oder der gemäß Artikel 21 Absatz 2 erstellten Erklärung für das betreffende Produkt zur Verfügung und arbeitet mit den zuständigen Behörden des Mitgliedstaats zusammen, in dem das Produkt oder die Dienstleistung angeboten wird.

    - (4) Ein Mitgliedstaat kann aus Gründen des Schutzes der öffentlichen Gesundheit von einem Erbringer eines Dienstes im Sinne von Artikel 1 Absatz 1 Buchstabe b der Richtlinie (EU) 2015/1535 oder von einem Erbringer einer Dienstleistung gemäß Absatz 2 verlangen, seine Tätigkeit einzustellen.“

- 7. In Artikel 7 wird folgender Unterabsatz angefügt:

    Unbeschadet der nationalen Rechtsvorschriften über die Ausübung des Arztberufs gilt Unterabsatz 1 auch für Produkte, die für die Erbringung einer Dienstleistung gemäß Artikel 6 Absatz 2 verwendet werden.“

- 8. Artikel 9 Absatz 1 Satz 1 erhält folgende Fassung:

    „Sind keine harmonisierten Normen vorhanden oder sind einschlägige harmonisierte Normen nicht ausreichend oder besteht die Notwendigkeit, Belange der öffentlichen Gesundheit zu berücksichtigen, so kann die Kommission nach Anhörung der Koordinierungsgruppe Medizinprodukte im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen (GS) für die in dieser Verordnung festgelegten Anforderungen erlassen, insbesondere für die von den Herstellern zu erstellenden Berichte und Pläne, die in Anhang I festgelegten grundlegenden Sicherheits- und Leistungsanforderungen, die in den Anhängen II und III festgelegte technische Dokumentation, die in den Anhängen IX bis XI festgelegten Konformitätsbewertungsverfahren und das in Anhang XIII festgelegte Verfahren für Sonderanfertigungen, die in Anhang XIV festgelegte klinische Bewertung und die klinische Nachbeobachtung nach dem Inverkehrbringen oder die in Anhang XV festgelegten Anforderungen an die klinische Prüfung.“

- 9. Artikel 10 wird wie folgt geändert:

  - a) Die Absätze 3 und 7 werden gestrichen.

  - b) Absatz 9 erhält folgende Fassung:

    - „(9) Die Hersteller richten ein geeignetes Qualitätsmanagementsystem ein, um sicherzustellen, dass sie über Verfahren verfügen, die gewährleisten, dass die Anforderungen dieser Verordnung auch bei serienmäßiger Herstellung jederzeit eingehalten werden. Änderungen an der Auslegung des Produkts oder an seinen Merkmalen sowie Änderungen der harmonisierten Normen oder der GS, auf die bei Erklärung der Konformität eines Produkts verwiesen wird, werden zeitgerecht angemessen berücksichtigt. Die Hersteller von Produkten, bei denen es sich nicht um Prüfprodukte handelt, müssen ein Qualitätsmanagementsystem einrichten, dokumentieren, anwenden, aufrechterhalten, ständig aktualisieren und kontinuierlich verbessern, das die Einhaltung dieser Verordnung auf die wirksamste Weise sowie einer der Risikoklasse und der Art des Produkts angemessenen Weise gewährleistet.

        Das Qualitätsmanagementsystem umfasst alle Teile und Elemente der Organisation eines Herstellers, die mit der Qualität der Prozesse, Verfahren und Produkte befasst sind. Es steuert die erforderliche Struktur und die erforderlichen Verantwortlichkeiten, Verfahren, Prozesse und Managementressourcen zur Umsetzung der Grundsätze und Maßnahmen, die notwendig sind, um die Einhaltung der Bestimmungen dieser Verordnung zu erreichen.“

  - c) Absatz 10 wird gestrichen.

  - d) In Absatz 11 wird folgender Unterabsatz angefügt:

      „Wenn die Mitgliedstaaten festlegen, in welcher Amtssprache der Union die in Anhang I Abschnitt 23 genannten Informationen oder sonstige vom Hersteller bereitzustellende Informationen verfügbar zu machen sind, erwägen sie, ob sie eine andere Amtssprache der Union akzeptieren, in der diese Informationen bereitgestellt werden, wobei sie die technischen Kenntnisse, die Erfahrung, die Ausbildung oder die Schulung der vorgesehenen durchschnittlichen Anwender berücksichtigen.“

  - e) Absatz 13 wird gestrichen.

  - f) Absatz 14 wird wie folgt geändert:

    - i) Unterabsatz 3 wird gestrichen.

    - ii) Unterabsatz 4 wird gestrichen.

  - g) Absatz 15 erhält folgende Fassung:

    - „(15) Lassen Hersteller ihre Produkte von einer anderen natürlichen oder juristischen Person konzipieren und herstellen, so ist die Identität dieser Person Teil der gemäß Artikel 29 Absatz 4 vorzulegenden Angaben. In diesen Fällen stellt der Hersteller sicher, dass die einschlägigen Teile der technischen Dokumentation von der juristischen oder natürlichen Person, die das Produkt konzipiert und hergestellt hat, gemäß den Absätzen 4 und 8 dieses Artikels erstellt, auf dem neuesten Stand gehalten und den zuständigen Behörden auf Verlangen zur Verfügung gestellt werden. Darüber hinaus erstellt der Hersteller die übrigen Teile der technischen Dokumentation, hält sie auf dem neuesten Stand und stellt sie den zuständigen Behörden auf Verlangen zur Verfügung, insbesondere die in Anhang II Abschnitt 2 und in Anhang III genannten Teile.“

  - h) Absatz 16 wird gestrichen.

- 10. Artikel 10a wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 2 erhält folgende Fassung:

      „Die in Unterabsatz 1 genannten Informationen werden mindestens sechs Monate vor der voraussichtlichen Unterbrechung oder Beendigung übermittelt oder, wenn dies nicht möglich ist, unverzüglich, nachdem der Hersteller von der voraussichtlichen Unterbrechung oder Beendigung Kenntnis erlangt hat. Der Hersteller gibt die Gründe für die Unterbrechung oder Beendigung in den Informationen, die der zuständigen Behörde übermittelt werden, an.“

  - b) Folgende Absätze 4, 5 und 6 werden angefügt:

    - „(4) Die Kommission richtet erforderlichenfalls in Zusammenarbeit mit der EMA ein IT-System ein, betreibt und verwaltet es, um die Meldung und den Informationsaustausch über Fälle der Unterbrechung oder Beendigung der Versorgung mit Produkten gemäß den Absätzen 1, 2 und 3 zu erleichtern. Dieses IT-System wird in die in Artikel 33 genannte europäische Datenbank für Medizinprodukte integriert oder ist mit ihr interoperabel. Es ermöglicht außerdem Gesundheitseinrichtungen und Angehörigen der Gesundheitsberufe, die zuständigen Behörden über die Nichtverfügbarkeit oder das unmittelbare Risiko der Nichtverfügbarkeit von Produkten zu unterrichten, die für die Ausübung ihrer beruflichen Tätigkeit erforderlich sind.

    - (5) Die EMA entwickelt in Zusammenarbeit mit der durch Artikel 21 der Verordnung (EU) 2022/123 eingerichteten hochrangigen Lenkungsgruppe für Engpässe bei Medizinprodukten (MDSSG) eine Methodik, um die Produkte oder Produktkategorien zu ermitteln, bei denen vernünftigerweise vorhersehbar ist, dass eine Unterbrechung oder Beendigung der Versorgung zu einem schwerwiegenden Schaden oder zur Gefahr eines schwerwiegenden Schadens für die Patienten oder die öffentliche Gesundheit im Sinne von Absatz 1 führen könnte. Auf der Grundlage dieser Methodik erstellt die EMA in Zusammenarbeit mit der MDSSG und im Einvernehmen mit der Kommission eine Liste der Produkte oder Produktkategorien, auf die die Absätze 1, 2 und 3 Anwendung finden, veröffentlicht diese und hält sie auf dem neuesten Stand. Für die Zwecke dieses Absatzes können die Koordinierungsgruppe Medizinprodukte, Vertreter von Herstellern, andere einschlägige Akteure aus der Lieferkette der Medizinproduktebranche sowie Vertreter von Angehörigen der Gesundheitsberufe, Patienten- und Verbrauchervertreter bei Bedarf konsultiert werden.

    - (6) Die zuständigen Behörden der Mitgliedstaaten oder die Kommission können von den Herstellern der in der gemäß Absatz 5 erstellten Liste aufgeführten Produkte verlangen, alle erforderlichen Informationen zu Risiken und Schwachstellen innerhalb der Lieferkette bereitzustellen, die die Versorgung mit diesen Produkten beeinträchtigen können, einschließlich der Produktionskapazität und des Absatzvolumens.“

- 11. In Artikel 11 werden die Absätze 4 und 5 gestrichen.

- 12. Artikel 14 Absatz 2 wird wie folgt geändert:

  - a) Unterabsatz 1 Buchstabe d erhält folgende Fassung:

    - „d) gegebenenfalls wurde vom Hersteller eine UDI gemäß Artikel 27 Absatz 3 vergeben.“

  - b) Unterabsatz 2 erhält folgende Fassung:

      „Zur Erfüllung der Anforderungen gemäß Unterabsatz 1 kann der Händler ein Probenahmeverfahren anwenden, das für die von ihm gelieferten Produkte repräsentativ ist.“

- 13. Artikel 15 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Hersteller verfügen in ihrer Organisation über mindestens eine Person mit dem erforderlichen Fachwissen auf dem Gebiet der Medizinprodukte, die für die Einhaltung der Regulierungsvorschriften verantwortlich ist.“

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Kleinst- und Kleinunternehmen im Sinne der Empfehlung 2003/361/EG der Kommission**** sind nicht verpflichtet, in ihrer Organisation eine für die Einhaltung der Regulierungsvorschriften verantwortliche Person zur Verfügung zu haben; sie müssen jedoch auf eine solche Person zurückgreifen können.

    - __________________

    - ****Empfehlung der Kommission vom 6. Mai 2003 betreffend die Definition der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen (ABl. L 124 vom 20.5.2003, S. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj).“

  - c) Absatz 3 Buchstabe c erhält folgende Fassung:

    - „c) die Verpflichtungen zur Überwachung nach dem Inverkehrbringen gemäß Artikel 83 erfüllt werden;“

  - d) Absatz 6 erhält folgende Fassung:

    - „(6) Bevollmächtigte müssen dauerhaft und ständig auf mindestens eine Person mit dem erforderlichen Fachwissen über die Regulierungsanforderungen oder Medizinprodukte in der Union zurückgreifen können, die für die Einhaltung der Regulierungsvorschriften verantwortlich ist.“

- 14. Artikel 16 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) in Unterabsatz 1 erhalten die einleitenden Worte folgende Fassung:

        „Ein Händler, ein Importeur oder eine andere natürliche oder juristische Person, die ein Produkt in Verkehr bringt oder in Betrieb nimmt, übernimmt die den Herstellern obliegenden Pflichten, wenn sie eine der folgenden Handlungen vornimmt:“

    - ii) Unterabsatz 2 erhält folgende Fassung:

        „Unterabsatz 1 gilt nicht für Angehörige der Gesundheitsberufe oder für andere Personen, die, ohne als Hersteller zu gelten, ein bereits in Verkehr befindliches Produkt ohne Änderung seiner Zweckbestimmung für einen bestimmten Patienten montieren oder anpassen.“

  - b) Absatz 4 wird gestrichen.

- 15. Artikel 17 erhält folgende Fassung:

**„Artikel 17**

Einmalprodukte und Aufbereitung von nicht zur einmaligen Verwendung bestimmten Produkten

  - (1) Ein Produkt darf nur dann zur einmaligen Verwendung bestimmt sein, wenn der Hersteller unter Berücksichtigung der Konzeption, der Konstruktion, des Materials sowie der chemischen, physikalischen und biologischen Eigenschaften des Produkts nicht gewährleisten kann, dass das Produkt bei einer Wiederverwendung gemäß seiner Zweckbestimmung nach einer geeigneten Aufbereitung weiterhin die einschlägigen Sicherheits- und Leistungsanforderungen erfüllt. Die Begründung des Herstellers für die Ausweisung als Einmalprodukt ist Bestandteil der technischen Dokumentation gemäß Anhang II.

  - (2) Ist das Produkt nicht zur einmaligen Verwendung bestimmt, so stellt der Hersteller in der Gebrauchsanweisung gemäß Anhang I Abschnitt 23.4 Buchstabe n Informationen über den geeigneten Aufbereitungsprozess zur Ermöglichung der Wiederverwendung bereit.

  - (3) Einmalprodukte und Produkte, die nicht weiter aufbereitet werden können, können einer Neuaufbereitung im Sinne von Artikel 2 Absatz 31 unterliegen. Die natürliche oder juristische Person, die die Neuaufbereitung durchführt, gilt als Hersteller des neu aufbereiteten Produkts.

  - (4) Die Kommission kann gemäß Artikel 9 Absatz 1 GS zu allgemeinen Anforderungen an die Aufbereitung von Produkten oder an die Neuaufbereitung von Einmalprodukten erlassen.“

- 16. Artikel 18 wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 2 Satz 1 erhält folgende Fassung:

      „Die Angaben gemäß Unterabsatz 1 werden zum Zweck der Bereitstellung für den Patienten, dem das Produkt implantiert wurde, in geeigneten Form, auch in elektronischer oder digitaler Form, bereitgestellt, die einen raschen Zugang zu diesen Angaben ermöglicht, und sie werden in der/den von dem betreffenden Mitgliedstaat festgelegten Sprache(n) verfasst.“

  - b) Absatz 3 erhält folgende Fassung:

      „(3) Implantate, bei denen es sich um Medizinprodukte mit bewährter Technologie handelt, sind von den in diesem Artikel festgelegten Verpflichtungen ausgenommen.“

- 17. in Artikel 19 wird folgender Absatz 2a eingefügt:

  - „(2a) Konformitätserklärungen gemäß den Absätzen 1 und 2 können in elektronischer Form bereitgestellt werden.“

- 18. Artikel 22 Absatz 2 erhält folgende Fassung:

  - „(2) Die gemäß Absatz 1 abgegebene Erklärung enthält mindestens folgende Angaben:

    - a) eine Identifizierung der Produkte und gegebenenfalls anderer im System oder in der Behandlungseinheit enthaltene Produkte, gegebenenfalls einschließlich ihrer Basis-UDI-DI;

    - b) gegebenenfalls eine Identifizierung der an den Sterilisierungstätigkeiten gemäß Absatz 3 beteiligten Benannten Stelle;

    - c) eine Erklärung der natürlichen oder juristischen Person, dass sie

      - i) die gegenseitige Kompatibilität der Medizin- und gegebenenfalls sonstigen Produkte gemäß den Anweisungen der Hersteller überprüft und ihre Tätigkeiten gemäß diesen Anweisungen durchgeführt hat;

      - ii) das System oder die Behandlungseinheit verpackt und die einschlägigen Benutzerhinweise angegeben hat, unter Einbeziehung der Informationen, die vom Hersteller der Medizin- und sonstigen zusammengestellten Produkte bereitzustellen sind;

      - iii) die Zusammenstellung von Medizin- und gegebenenfalls sonstigen Produkten zu einem System oder einer Behandlungseinheit unter Anwendung geeigneter Methoden der internen Überwachung, Überprüfung und Validierung vorgenommen hat.“

- 19. Artikel 27 wird wie folgt geändert:

  - a) in Absatz 1 wird nach Buchstabe b folgender Buchstabe ba eingefügt:

    - „ba) einer Basis-UDI-DI im Sinne von Anhang VI Teil C;

  - b) Absatz 2 wird wie folgt geändert:

    - i) Buchstabe d erhält folgende Fassung:

      - „d) die Stelle gewährt allen interessierten Nutzern unter vorab festgelegten und transparenten Bedingungen, die die Interessen von Kleinst-, kleinen und mittleren Unternehmen im Sinne der Empfehlung 2003/361/EG berücksichtigen, Zugang zu ihrem UDI-Zuteilungssystem;“

    - ii) in Buchstabe e wird folgende Ziffer iv angefügt.

      - „iv) ihr UDI-Zuteilungssystem Herstellern, die Kleinst- und kleine Unternehmen im Sinne der Empfehlung 2003/361/EG sind, zu Vorzugsbedingungen anbieten, die den besonderen Erfordernissen dieser Unternehmen Rechnung tragen und ihrer Größe angemessen sind.“

  - c) Absatz 3 erhält folgende Fassung:

    - „(3) Bevor der Hersteller ein Produkt, das weder eine Sonderanfertigung noch ein Prüfprodukt ist, in Verkehr bringt, weist er dem Produkt gemäß den Vorschriften der von der Kommission gemäß Absatz 2 benannten Zuteilungsstelle eine Basis-UDI-DI und eine UDI im Sinne von Anhang VI Teil C zu. Gegebenenfalls weist der Hersteller allen höheren Verpackungsebenen eine UDI-DI zu.“

  - d) Folgende Absätze 3a und 3b werden eingefügt:

    - „(3a) Bevor ein System oder eine Behandlungseinheit gemäß Artikel 22 Absätze 1 und 3 in Verkehr gebracht wird, weist die verantwortliche natürliche oder juristische Person dem System oder der Behandlungseinheit gemäß den Vorschriften der von der Kommission gemäß Absatz 2 benannten Zuteilungsstelle eine Basis-UDI-DI und eine UDI im Sinne von Anhang VI Teil C zu.

    - (3b) Für Produkte, die Gegenstand einer Konformitätsbewertung gemäß Artikel 52 Absatz 3 sowie Artikel 52 Absatz 4 Unterabsätze 2 und 3 sind, wird die in Absatz 1 dieses Artikels genannte Basis-UDI-DI zugewiesen, bevor der Hersteller bei einer Benannten Stelle die Durchführung dieser Konformitätsbewertung beantragt.“

  - e) in Absatz 10 erhalten die Buchstaben a und b folgende Fassung:

    - „a) die in Anhang VI Teile A und B festgelegte Liste der Informationen unter Berücksichtigung des technischen Fortschritts geändert wird;

    - b) Anhang VI unter Berücksichtigung der bei der Umsetzung des UDI-Systems gewonnenen Erfahrungen oder der internationalen Entwicklungen und des technischen Fortschritts im Bereich der einmaligen Produktkennung geändert wird.“

  - f) In Absatz 11 wird folgender Buchstabe c angefügt:

    - „c) die Festlegung der in diesem Artikel, in Artikel 29 und in Anhang VI Teil C festgelegten UDI-bezogenen Pflichten, die aufgrund der stark individualisierten Ausgestaltung dieser Produkte oder aufgrund ihrer Risikoklasse, der Zahl der in Verkehr gebrachten Produkte sowie des mit der Zuweisung einer UDI verbundenen finanziellen und administrativen Aufwands für bestimmte Produkte, Produktkategorien oder Produktgruppen nicht gelten.“

- 20. Artikel 28 wird wie folgt geändert:

  - a) Absatz 3 erhält folgende Fassung:

    - „(3) Die in die UDI-Datenbank einzugebenden zentralen Datenelemente gemäß Anhang VI Teil B werden der Öffentlichkeit kostenlos zugänglich gemacht, mit Ausnahme des Elements gemäß Nummer 13 des genannten Teils.

- 21. Artikel 29 erhält folgende Fassung:

**„Artikel 29**

Registrierung von Produkten und Systemen oder Behandlungseinheiten

  - (1) Bevor ein Produkt, das keine Sonderanfertigung und kein Prüfprodukt ist, in Verkehr gebracht wird, gibt der Hersteller die Basis-UDI-DI zusammen mit den anderen in Anhang VI Teil B aufgeführten zentralen Datenelementen zu diesem Produkt in die UDI-Datenbank ein. Der Hersteller hält die in der UDI-Datenbank bereitgestellten Informationen auf dem neuesten Stand.

  - (2) Bevor ein System oder eine Behandlungseinheit gemäß Artikel 22 Absätze 1 und 3 in Verkehr gebracht wird, gibt die verantwortliche natürliche oder juristische Person die Basis-UDI-DI zusammen mit den anderen in Anhang VI Teil B aufgeführten zentralen Datenelementen zu diesem System oder dieser Behandlungseinheit in die UDI-Datenbank ein. Die in Artikel 22 Absatz 1 genannte natürliche oder juristische Person hält die in der UDI-Datenbank bereitgestellten Informationen auf dem neuesten Stand.

  - (3) Für Produkte, die einer Konformitätsbewertung gemäß Artikel 52 Absatz 3 sowie Artikel 52 Absatz 4 Unterabsätze 2 und 3 unterzogen werden, bestätigt die Benannte Stelle in Eudamed, dass die in Anhang VI Teil B genannten Informationen korrekt sind.“

- 22. Artikel 30 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Nach Anhörung der Koordinierungsgruppe Medizinprodukte errichtet und betreibt die Kommission ein elektronisches System, mit dem die einmalige Registrierungsnummer gemäß Artikel 31 Absatz 2 generiert wird und in dem die zur Identifizierung eines Herstellers und gegebenenfalls seines Bevollmächtigten, des Importeurs und der in Artikel 22 Absatz 1 genannten Person erforderlichen und verhältnismäßigen Angaben erfasst und verarbeitet werden. Welche Angaben von den Wirtschaftsakteuren in dieses elektronische System genau einzugeben sind, ist in Anhang VI Teil A Abschnitt 1 niedergelegt.“

  - b) In Absatz 2 wird folgender Satz angefügt:

      „Sofern nationale Datenbanken für Händler Informationen über Produkte verlangen, ermöglichen diese Datenbanken den Abruf der Produktinformationen aus den elektronischen Systemen gemäß Artikel 33 Absatz 2 Buchstaben a und b.“

- 23. Artikel 31 wird wie folgt geändert:

  - a) Die Überschrift erhält folgende Fassung:

      „Registrierung von Wirtschaftsakteuren“

  - b) Die Absätze 1 und 2 erhalten folgende Fassung:

    - „(1) Bevor sie ein Produkt, bei dem es sich nicht um eine Sonderanfertigung handelt, in Verkehr bringen, geben die Hersteller, Bevollmächtigte, Importeure und die in Artikel 22 Absatz 1 dieser Verordnung genannten Personen die Angaben gemäß Anhang VI Teil A in das elektronische System gemäß Artikel 30 ein, um sich registrieren zu lassen, sofern sie sich nicht bereits gemäß diesem Artikel registriert haben. In den Fällen, in denen das Konformitätsbewertungsverfahren die Mitwirkung einer Benannten Stelle gemäß Artikel 52 erfordert, werden die Angaben gemäß Anhang VI Teil A an dieses elektronische System übermittelt, bevor der Antrag an die Benannte Stelle gerichtet wird.

    - (2) Die zuständige Behörde überprüft unverzüglich die gemäß Absatz 1 eingegebenen Daten, ruft aus dem elektronischen System gemäß Artikel 30 eine einmalige Registrierungsnummer (‚SRN‘ – Single Registration Number) ab und teilt sie dem Hersteller, dem Bevollmächtigten, dem Importeur oder der in Artikel 22 Absatz 1 genannten Person zu.“

  - c) In Absatz 4 werden die Worte „von einer Woche“ durch die Angabe „von zwei Wochen“ ersetzt.

  - d) Absatz 6 wird gestrichen.

  - e) Absatz 7 erhält folgende Fassung:

    - „(7) Die gemäß Absatz 1 des vorliegenden Artikels in das elektronische System gemäß Artikel 30 eingegebenen Daten sind der Öffentlichkeit zugänglich, mit Ausnahme der Informationen über die für die Einhaltung der Regulierungsvorschriften verantwortliche Person gemäß Anhang VI Teil A Nummer 1.4.“

  - f) Absatz 8 erhält folgende Fassung:

    - „(8) Die zuständige Behörde kann die Daten verwenden, um von dem Hersteller, dem Bevollmächtigten, dem Importeur oder der in Artikel 22 Absatz 1 genannten Person eine Gebühr gemäß Artikel 111 zu erheben.“

- 24. Artikel 32 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Für implantierbare Produkte der Klasse IIb sowie für Produkte der Klasse III, außer Sonderanfertigungen oder Prüfprodukte und Produkte mit bewährter Technologie, erstellt der Hersteller einen Kurzbericht über Sicherheit und klinische Leistung.

        Der Kurzbericht über Sicherheit und klinische Leistung ist so abzufassen, dass er für den bestimmungsgemäßen Anwender verständlich ist; er wird der Öffentlichkeit über Eudamed zugänglich gemacht.

        Der Entwurf dieses Kurzberichts über Sicherheit und klinische Leistung bildet einen Teil der Dokumentation, die der an der Konformitätsbewertung beteiligten Benannten Stelle gemäß Artikel 52 zu übermitteln ist. Der Hersteller stellt sicher, dass der Kurzbericht über Sicherheit und klinische Leistung in Eudamed als Teil der gemäß Artikel 29 Absatz 1 bereitzustellenden Produktinformationen verfügbar ist, und er gibt auf der Kennzeichnung oder in der Gebrauchsanweisung an, wo dieser Kurzbericht abrufbar ist.“

  - b) Absatz 2 Buchstabe h erhält folgende Fassung:

    - „h) Angaben zu möglichen Restrisiken oder unerwünschten Wirkungen sowie etwaige Warnhinweise und Vorsichtsmaßnahmen.“

- 25. Artikel 33 wird wie folgt geändert:

  - a) in Absatz 2 wird folgender Unterabsatz angefügt:

      „Abweichend von Unterabsatz 1 kann die Kommission beschließen, dass eines oder mehrere der in dem genannten Unterabsatz aufgeführten elektronischen Systeme nicht in Eudamed aufgenommen werden. In diesem Fall stellt die Kommission sicher, dass diese elektronischen Systeme mit Eudamed interoperabel sind.“

  - b) Absatz 3 erhält folgende Fassung:

    - „(3) Bei der Konzeption von Eudamed und gegebenenfalls der elektronischen Systeme, die nicht in Eudamed enthalten sind, trägt die Kommission der Kompatibilität mit nationalen Datenbanken und nationalen Web-Schnittstellen gebührend Rechnung, um den Import und Export von Daten zu ermöglichen.“

  - c) Absatz 4 erhält folgende Fassung:

    - „(4) Die Daten werden von den Mitgliedstaaten, den Benannten Stellen, den Wirtschaftsakteuren und den Sponsoren gemäß den Bestimmungen über die elektronischen Systeme gemäß Absatz 2 in Eudamed und gegebenenfalls in die elektronischen Systeme eingegeben, die nicht in Eudamed enthalten sind. Die Kommission stellt den Nutzern von Eudamed und gegebenenfalls der elektronischen Systeme, die nicht in Eudamed enthalten sind, technische und administrative Unterstützung bereit.“

  - d) Absatz 5 erhält folgende Fassung:

    - „(5) Alle von Eudamed sowie gegebenenfalls von den elektronischen Systemen, die nicht in Eudamed enthalten sind, erfassten und verarbeiteten Informationen sind für die Mitgliedstaaten und für die Kommission zugänglich. Den Benannten Stellen, Wirtschaftsakteuren, Sponsoren und der Öffentlichkeit sind die Informationen in dem Umfang zugänglich, der sich aus den Bestimmungen über die elektronische Systeme gemäß Absatz 2 ergibt.

        Die Kommission stellt sicher, dass die öffentlich zugänglichen Teile von Eudamed und gegebenenfalls der elektronischen Systeme, die nicht in Eudamed enthalten sind, in einem benutzerfreundlichen und leicht durchsuchbaren Format dargestellt werden.“

  - e) Absatz 6 erhält folgende Fassung:

    - „(6) Eudamed sowie gegebenenfalls die elektronischen Systeme, die nicht in Eudamed enthalten sind, enthält personenbezogene Daten nur, soweit dies für die Erfassung und Verarbeitung von Informationen durch die elektronischen Systeme gemäß dieser Verordnung erforderlich ist. Personenbezogene Daten werden dergestalt gespeichert, dass eine Identifizierung der betroffenen Personen nur während Zeiträumen möglich ist, die nicht länger als die in Artikel 10 Absatz 8 genannten Zeiträume sind.“

  - f) Absatz 8 erhält folgende Fassung:

    - „(8) Die genauen Regelungen für die Einrichtung und Pflege von Eudamed sowie gegebenenfalls der elektronischen Systeme, die nicht in Eudamed enthalten sind, werden von der Kommission im Wege von Durchführungsrechtsakten festgelegt. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen. Bei Erlass dieser Durchführungsrechtsakte stellt die Kommission sicher, dass die Systeme soweit wie möglich so entwickelt werden, dass die gleiche Information nicht innerhalb desselben elektronischen Systems oder in verschiedenen elektronischen Systemen zweimal eingegeben werden muss.“

  - „g) Absatz 9 erhält folgende Fassung:

    - „(9) Was die Verantwortlichkeiten im Rahmen des vorliegenden Artikels und die sich daraus ergebende Verarbeitung personenbezogener Daten angeht, so gilt die Kommission als für Eudamed und seine elektronischen Systeme sowie gegebenenfalls für alle elektronischen Systeme, die nicht in Eudamed enthalten sind, verantwortlich.“

- 26. Artikel 34 Absatz 1 erhält folgende Fassung:

  - „(1) Die Kommission erstellt in Zusammenarbeit mit der Koordinierungsgruppe Medizinprodukte die funktionalen Spezifikationen für Eudamed sowie gegebenenfalls für die elektronischen Systeme, die nicht in Eudamed enthalten sind.“

- 27. Artikel 35 wird wie folgt geändert:

  - a) Folgender Absatz 6a wird eingefügt:

    - „(6a) Unbeschadet anderer verwaltungsrechtlicher oder gerichtlicher Rechtsbehelfe kann ein Hersteller oder eine Benannte Stelle bei der für Benannte Stellen zuständigen Behörde in ordnungsgemäß begründeter Weise jeden ungelösten Streitfall vorbringen, der sich aus der Anwendung der in Anhang VII festgelegten Anforderungen und aus der Mitwirkung einer Benannten Stelle an der Konformitätsbewertung gemäß Artikel 52 und den Anhängen IX, X und XI ergibt. Die Behörde hört die Beteiligten an und entscheidet innerhalb von 90 Tagen. Ist der Hersteller in einem anderen Mitgliedstaat als die Benannte Stelle niedergelassen, so konsultiert die für die Benannte Stelle zuständige Behörde die zuständige Behörde des Mitgliedstaats, in dem der Hersteller niedergelassen ist.

        In ordnungsgemäß begründeten Fällen kann die für Benannte Stellen zuständige Behörde die Koordinierungsgruppe Medizinprodukte um Beratung ersuchen, die sie gebührend berücksichtigt.

        Jede für Benannte Stellen zuständige Behörde unterrichtet die Kommission und die Koordinierungsgruppe Medizinprodukte mindestens jährlich über die Streitfälle, die ihr gemäß Unterabsatz 1 vorgelegt wurden, sowie über deren Ausgang und die beteiligten Parteien. Diese Informationen werden im Rahmen der Überwachung der Benannten Stellen gemäß Artikel 44 berücksichtigt.

        Abweichend von Unterabsatz 1 und unbeschadet anderer verwaltungsrechtlicher oder gerichtlicher Rechtsbehelfe kann ein Mitgliedstaat beschließen, die in diesem Absatz genannten Aufgaben einer anderen Behörde oder einer außergerichtlichen Streitbeilegungsstelle zu übertragen.“

  - b) Absatz 8 erhält folgende Fassung:

    - „(8) Die für Benannte Stellen zuständigen Behörden koordinieren die nach diesem Kapitel durchzuführenden Tätigkeiten, arbeiten untereinander sowie mit der Kommission zusammen und klären Meinungsverschiedenheiten zwischen ihnen, um eine harmonisierte Anwendung der die Benannten Stellen betreffenden Anforderungen sicherzustellen.“

- 28. Artikel 36 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Die Benannten Stellen erfüllen die Aufgaben, für die sie gemäß dieser Verordnung benannt sind, im öffentlichen Interesse. Sie erfüllen die organisatorischen und allgemeinen Anforderungen sowie die Anforderungen an Qualitätsmanagement, Ressourcen und Verfahren, die in Anhang VII näher festgelegt sind und die erforderlich sind, um diese Aufgaben wirksam, unabhängig, sorgfältig und zügig zu erfüllen.

    - Die Benannten Stellen, die für Konformitätsbewertungstätigkeiten in Bezug auf Produkte benannt sind, bei denen es sich um Hochrisiko-KI-Systeme im Sinne von Artikel 6 Absatz 1 der Verordnung (EU) 2024/1689 handelt oder die Hochrisiko-KI-Systeme als Sicherheitskomponenten verwenden, erfüllen zudem die in Artikel 31 Absätze 4, 5, 10 und 11 der Verordnung (EU) 2024/1689 festgelegten Anforderungen.“

  - b) Folgender Absatz 4 wird angefügt:

    - „(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um Anhang VII zu ändern, um diesen an den technischen oder wissenschaftlichen Fortschritt im Bereich der Konformitätsbewertung von Medizinprodukten, einschließlich der Entwicklungen auf internationaler Ebene, anzupassen.“

- 29. Artikel 37 Absatz 4 wird gestrichen.

- 30. Artikel 39 erhält folgende Fassung:

**„Artikel 39**

Bewertung des Antrags

  - (1) Die für Benannte Stellen zuständige Behörde prüft innerhalb von 30 Tagen, ob der Antrag gemäß Artikel 38 vollständig ist, und fordert den Antragsteller gegebenenfalls auf, fehlende Informationen nachzureichen. Sobald der Antrag vollständig ist, übermittelt ihn diese Behörde der Kommission.

  - (2) Innerhalb von 14 Tagen nach Eingang des in Absatz 1 dieses Artikels genannten Antrags beruft die Kommission nach Anhörung der Koordinierungsgruppe Medizinprodukte drei Sachverständige, die aus der in Artikel 40 Absatz 2 genannten Liste ausgewählt werden. Angesichts der besonderen Umstände des Antrags kann eine abweichende Zahl von Sachverständigen berufen werden.

      Mindestens einer der Sachverständigen ist ein die Kommission vertretender Sachverständiger. Die übrigen Sachverständigen werden von anderen Mitgliedstaaten nominiert als jenem, in dem die antragstellende Konformitätsbewertungsstelle niedergelassen ist.

      Um gemäß Unterabsatz 1 ausgewählt zu werden, müssen die Sachverständigen befähigt sein, die Konformitätsbewertungstätigkeiten sowie die Arten von Produkten zu beurteilen, die Gegenstand des Antrags sind.

  - (3) Die gemäß Absatz 2 berufenen Sachverständigen und die für Benannte Stellen zuständige Behörde bilden ein gemeinsames Bewertungsteam, das von dem die Kommission vertretenden Sachverständigen koordiniert wird.

  - (4) Innerhalb von 90 Tagen nach der Benennung der Sachverständigen gemäß Absatz 3 prüft das gemeinsame Bewertungsteam den Antrag und die zugehörigen Unterlagen und erstellt einen vorläufigen Bewertungsbericht. Während dieses Zeitraums kann das gemeinsame Bewertungsteam von der antragstellenden Konformitätsbewertungsstelle alle erforderlichen Klarstellungen anfordern. Das gemeinsame Bewertungsteam übermittelt der antragstellenden Konformitätsbewertungsstelle den vorläufigen Bewertungsbericht.

  - (5) Ist das gemeinsame Bewertungsteam auf der Grundlage der in diesem Absatz genannten Prüfung des Antrags und der zugehörigen Unterlagen der Auffassung, dass die antragstellende Stelle die Anforderungen dieser Verordnung nicht erfüllt und sie diese auch innerhalb eines angemessenen Zeitraums nicht erfüllen kann und dass eine weitere Bewertung gemäß den Absätzen 6 bis 9 nicht angezeigt ist, so erstellt es einen abschließenden Bewertungsbericht, und die für Benannte Stellen zuständige Behörde lehnt den Antrag ab.

  - (6) Sofern der Antrag nicht abgelehnt wird, plant und führt das gemeinsame Bewertungsteam eine Vor-Ort-Bewertung der antragstellenden Konformitätsbewertungsstelle sowie gegebenenfalls etwaiger Zweigstellen oder Unterauftragnehmer durch, die innerhalb oder außerhalb der Union niedergelassen sind und an dem Konformitätsbewertungsverfahren mitwirken sollen.

      Ist eine Vor-Ort-Bewertung der antragstellenden Stelle, einer Zweigstelle oder eines Unterauftragnehmers aufgrund außergewöhnlicher Umstände vorübergehend nicht möglich oder nicht praktikabel, kann das gemeinsame Bewertungsteam beschließen, die Bewertung mit anderen geeigneten Mitteln durchzuführen.

      Am Ende der Vor-Ort-Bewertung führt das gemeinsame Bewertungsteam für die antragstellende Konformitätsbewertungsstelle alle bei der Bewertung festgestellten Nichtkonformitäten auf und fasst die vom gemeinsamen Bewertungsteam durchgeführte Bewertung zusammen.

  - (7) Innerhalb von 30 Tagen nach Abschluss der Vor-Ort-Bewertung übermittelt das gemeinsame Bewertungsteam der antragstellenden Konformitätsbewertungsstelle den Bewertungsbericht und unterrichtet diese gegebenenfalls über etwaige bei der Bewertung festgestellten Nichtkonformitäten.

      Hat das gemeinsame Bewertungsteam keine Nichtkonformitäten festgestellt, gilt sein Bewertungsbericht als abschließender Bewertungsbericht, und Absatz 11 findet Anwendung.

  - (8) Hat das gemeinsame Bewertungsteam Nichtkonformitäten festgestellt, so schlägt die antragstellende Konformitätsbewertungsstelle dem gemeinsamen Bewertungsteam einen Plan für Korrektur- und Präventivmaßnahmen vor, um die Nichtkonformitäten wirksam und zeitnah zu beheben.

      In dem Plan sind die wesentlichen Gründe für die festgestellten Nichtkonformität anzugeben und eine Frist für die Umsetzung der Maßnahmen enthalten.

  - (9) Innerhalb von 30 Tagen nach Eingang des in Absatz 8 genannten vorgeschlagenen Plans für Korrektur- und Präventivmaßnahmen prüft das gemeinsame Bewertungsteam, ob die während der Bewertung festgestellten Nichtkonformitäten angemessen behoben wurden, und übermittelt der antragstellenden Konformitätsbewertungsstelle gegebenenfalls hierzu Anmerkungen, einschließlich Aufforderungen zu weiteren Klarstellungen und Änderungen.

      Die antragstellende Konformitätsbewertungsstelle und das gemeinsame Bewertungsteam bemühen sich, zeitnah einen endgültigen Plan für Korrektur- und Präventivmaßnahmen zu vereinbaren.

  - (10) Innerhalb von 30 Tagen nach Eingang des endgültigen Plans für Korrektur- und Präventivmaßnahmen oder ab dem Zeitpunkt, zu dem das gemeinsame Bewertungsteam feststellt, dass keine Einigung über einen endgültigen Plan erzielt wurde, erstellt das gemeinsame Bewertungsteam seinen endgültigen Bewertungsbericht. Dieser Bericht enthält das Ergebnis der Bewertung, Schlussfolgerungen zu den Plänen für Korrektur- und Präventivmaßnahmen sowie dazu, ob die Nichtkonformitäten angemessen behoben wurden, und gegebenenfalls den empfohlenen Geltungsbereich der Benennung.

  - (11) Das gemeinsame Bewertungsteam übermittelt seinen endgültigen Bewertungsbericht unverzüglich an die Koordinierungsgruppe Medizinprodukte.

      Auf der Grundlage der Feststellungen des endgültigen Bewertungsberichts übermittelt die für Benannte Stellen zuständige Behörde der Koordinierungsgruppe Medizinprodukte einen Entwurf der Entscheidung über die Benennung der Benannten Stelle oder lehnt den Antrag ab.

  - (12) Innerhalb von 21 Tagen nach Eingang des in Absatz 11 genannten Entwurfs der Entscheidung über die Benennung gibt die Koordinierungsgruppe Medizinprodukte eine Empfehlung zu der vorgesehenen Benennung ab, die von der für Benannte Stellen zuständigen Behörde bei ihrer endgültigen Entscheidung über die Benennung der Benannten Stelle gebührend zu berücksichtigen ist. Die Frist von 21 Tagen kann einmal aus berechtigten Gründen um weitere 21 Tage verlängert werden.

  - (13) Stimmt die für Benannte Stellen zuständige Behörde nicht mit der Empfehlung der Koordinierungsgruppe Medizinprodukte überein, übermittelt sie der Koordinierungsgruppe Medizinprodukte einen ordnungsgemäß begründeten Antrag auf erneute Prüfung ihrer Empfehlung. Innerhalb von 30 Tagen nach Eingang dieses Antrags bestätigt die Koordinierungsgruppe Medizinprodukte entweder ihre Empfehlung oder gibt eine neue Empfehlung ab.

  - (14) Kann zwischen der Koordinierungsgruppe Medizinprodukte und der für Benannte Stellen zuständigen Behörde keine Einigung erzielt werden, kann jede der Parteien die Angelegenheit an die Kommission verweisen.

      Innerhalb von 180 Tagen nach Eingang der Verweisung bewertet die Kommission nach Anhörung der Koordinierungsgruppe Medizinprodukte, der für Benannte Stellen zuständigen Behörde und erforderlichenfalls der betroffenen antragstellenden Konformitätsbewertungsstelle den Entwurf der Entscheidung über die Benennung und entscheidet im Wege eines Durchführungsrechtsakts, ob der Entwurf einer Benennung gerechtfertigt ist.

  - (15) Kann in irgendeiner Phase des Verfahrens innerhalb des gemeinsamen Bewertungsteams in einer Frage kein Konsens erzielt werden, kann jedes Mitglied des gemeinsamen Bewertungsteams die Angelegenheit an die Koordinierungsgruppe Medizinprodukte verweisen; diese gibt unverzüglich und spätestens innerhalb von 60 Tagen nach der Verweisung eine Stellungnahme ab.

  - (16) Die Kommission kann im Wege von Durchführungsrechtsakten Maßnahmen erlassen, mit denen genaue Regelungen über die Verfahren und die einschlägigen Unterlagen für Folgendes festgelegt werden:

    - a) den Antrag auf Benennung gemäß Artikel 38;

    - b) die Bewertung des Antrags gemäß diesem Artikel;

    - c) die Benennung und Auswahl der in Artikel 40 genannten Sachverständigen;

    - d) die Überwachung der Benannten Stellen gemäß Artikel 44.

      Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.“

- 31. Artikel 40 wird wie folgt geändert:

  - a) die Überschrift erhält folgende Fassung:

      „Ernennung der Sachverständigen für die gemeinsame Bewertung“

  - b) Absatz 1 erhält folgende Fassung:

    - „(1) Alle Mitgliedstaaten, die eine für Benannte Stellen zuständige Behörde benannt haben, und die Kommission ernennen Sachverständige, die für die Bewertung, Benennung oder Überwachung von Konformitätsbewertungsstellen im Bereich der Medizinprodukte oder für die Bewertung der technischen Dokumentation der Hersteller qualifiziert sind und die für die Mitwirkung an den Tätigkeiten gemäß den Artikeln 39, 44 und 48 zur Verfügung stehen. Mitgliedstaaten, die keine für Benannte Stellen zuständige Behörde benannt haben, können Sachverständige ernennen, die über diese Qualifikationen verfügen.

        Die ernannten Sachverständigen verpflichten sich zur Mitwirkung an gemeinsamen Bewertungen.“

- 32. Folgender Artikel 40a wird eingefügt:

**„Artikel 40a**

Finanzierung der Tätigkeiten im Zusammenhang mit der Benennung und Überwachung der Benannten Stellen

  - (1) Konformitätsbewertungsstellen und Benannte Stellen entrichten für die Bewertung ihres Antrags auf Benennung und für ihre Überwachung eine Gebühr, in der die Kosten für die Mitwirkung der gemäß Artikel 40 ernannten Sachverständigen an diesen Bewertungs- und Überwachungstätigkeiten enthalten sind.

  - (2) Die Struktur und die Höhe der Gebühren sowie der Umfang und die Art der erstattungsfähigen Kosten werden von der Kommission im Wege von Durchführungsrechtsakten festgelegt. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.“

- 33. Artikel 41 Absatz 3 erhält folgende Fassung:

    „Der Antragsteller stellt Übersetzungen der Unterlagen gemäß den Artikeln 38 und 39 oder von Teilen davon in eine Amtssprache der Union bereit, soweit dies erforderlich ist, damit diese Unterlagen von dem in Artikel 39 Absatz 4 genannten gemeinsamen Bewertungsteam ohne Weiteres verstanden werden können.“

- 34. Artikel 42 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Die Mitgliedstaaten dürfen Konformitätsbewertungsstellen nur gemäß der nach Artikel 39 Absatz 11 oder 12 abgegebenen Empfehlung der Koordinierungsgruppe Medizinprodukte oder gemäß einem von der Kommission nach Artikel 39 Absatz 14 erlassenen Durchführungsrechtsakt benennen.“

  - b) Absatz 4 erhält folgende Fassung:

    - „(4) Der Notifizierung ist die Empfehlung der Koordinierungsgruppe Medizinprodukte beizufügen.“

  - c) Die Absätze 6 bis 9 werden gestrichen.

  - d) Absatz 10 erhält folgende Fassung:

    - „(10) Bei Veröffentlichung der Notifizierung in NANDO nimmt die Kommission die Informationen zur Notifizierung der Benannten Stelle zusammen mit den Unterlagen gemäß Absatz 4 dieses Artikels in das elektronische System gemäß Artikel 57 auf.“

- 35. Artikel 44 wird wie folgt geändert:

  - a) die Überschrift erhält folgende Fassung:

      „Überwachung der Benannten Stellen“

  - b) Absatz 2 Satz 2 erhält folgende Fassung:

      „Die Benannten Stellen stellen auf Anfrage ihrer für Benannte Stellen zuständigen Behörde alle einschlägigen Informationen und Unterlagen zur Verfügung, damit die Behörde und das gemeinsame Bewertungsteam überprüfen können, ob die Anforderungen eingehalten werden.“

  - c) Folgender Absatz 3a wird eingefügt:

    - „(3a) Die für Benannte Stellen zuständige Behörde führt ihre Überwachungs- und Bewertungstätigkeiten gemäß einem Bewertungsprogramm durch, das den gesamten Tätigkeitsumfang der Benannten Stelle berücksichtigt. Dieses Programm stellt sicher, dass die Behörde die fortlaufende Einhaltung der Anforderungen dieser Verordnung durch die Benannte Stelle wirksam überwachen kann, und sieht einen begründeten Zeitplan für die Häufigkeit der Bewertung der Benannten Stelle und gegebenenfalls ihrer Zweigstellen und/oder Unterauftragnehmer für einen Zeitraum von mindestens zwei Jahren vor. Die für Benannte Stellen zuständige Behörde übermittelt der Koordinierungsgruppe Medizinprodukte und der Kommission das Überwachungs- oder Bewertungsprogramm für jede Benannte Stelle, für die sie zuständig ist. Die Behörde kommt jeder von der Kommission oder der Koordinierungsgruppe Medizinprodukte gestellten Bitte um Klarstellung oder Änderung nach.“

  - d) Absatz 4 erhält folgende Fassung:

    - „(4) Mindestens einmal jährlich bewerten die für Benannte Stellen zuständigen Behörden, ob jede in ihrem jeweiligen Hoheitsgebiet niedergelassene Benannte Stelle und gegebenenfalls die Zweigstellen und Unterauftragnehmer, für die diese Benannten Stellen zuständig sind, nach wie vor die Anforderungen und Pflichten gemäß dieser Verordnung und insbesondere gemäß Anhang VII erfüllen.

        Soweit erforderlich umfasst die Bewertung ein Vor-Ort-Audit der Benannten Stelle, ihrer Zweigstellen oder Unterauftragnehmer.

        Die Behörde, die Koordinierungsgruppe Medizinprodukte oder die Kommission können die Mitwirkung von Sachverständigen der Kommission und anderer Mitgliedstaaten an der jährlichen Bewertung einer Benannten Stelle verlangen.“

  - e) Die folgenden Absätze 4a, 4b und 4c werden eingefügt:

    - „(4a) Mindestens alle zwei Jahre wird die jährliche Bewertung einer Benannten Stelle von einem gemeinsamen Bewertungsteam durchgeführt, dem die für Benannte Stellen zuständige Behörde und zwei von der Kommission nach Anhörung der Koordinierungsgruppe Medizinprodukte ernannte Sachverständige aus der in Artikel 40 Absatz 2 genannten Liste angehören. Mindestens einer dieser Sachverständigen ist ein die Kommission vertretender Sachverständiger. Im Hinblick auf die besonderen Umstände der Überwachung kann die Kommission eine abweichende Anzahl von Sachverständigen ernennen. Das gemeinsame Bewertungsteam wird von dem Sachverständigen, der die Kommission vertritt, koordiniert.

        Kann in irgendeiner Phase des Verfahrens innerhalb des gemeinsamen Bewertungsteams in einer Frage kein Konsens erzielt werden, kann jedes Mitglied des gemeinsamen Bewertungsteams die Angelegenheit an die Koordinierungsgruppe Medizinprodukte verweisen; diese gibt unverzüglich und spätestens innerhalb von 60 Tagen nach der Verweisung eine Stellungnahme ab.

    - (4b) Am Ende jeder gemäß Absatz 4 oder 4a durchgeführten Bewertung unterrichtet die für Benannte Stellen zuständige Behörde oder gegebenenfalls das gemeinsame Bewertungsteam die Benannte Stelle über etwaige aus der Bewertung resultierende Nichtkonformitäten und fasst ihre Bewertung zusammen.

        Wurden Nichtkonformitäten festgestellt, schlägt die Benannte Stelle einen Plan für Korrektur- und Präventivmaßnahmen zur Behebung der Nichtkonformitäten vor. Dieser Plan gibt die Grundursache der festgestellten Nichtkonformitäten an und enthält einen Zeitrahmen für die Umsetzung der darin festgelegten Maßnahmen.

        Die für Benannte Stellen zuständige Behörde oder gegebenenfalls das gemeinsame Bewertungsteam bewertet, ob die während der Bewertung festgestellten Nichtkonformitäten in dem Unterabsatz 2 genannten Plan angemessen berücksichtigt wurden, und übermittelt der Benannten Stelle erforderlichenfalls Anmerkungen zu diesem Plan, einschließlich Ersuchen um weitere Klarstellungen und Änderungen. Die Benannte Stelle und die Behörde oder gegebenenfalls das gemeinsame Bewertungsteam bemühen sich, zeitnah einen endgültigen Plan für Korrektur- und Präventivmaßnahmen zu vereinbaren.

    - (4c) Nach Eingang des endgültigen Plans für Korrektur- und Präventivmaßnahmen oder wenn die für Benannte Stellen zuständige Behörde oder gegebenenfalls das gemeinsame Bewertungsteam keine Nichtkonformitäten festgestellt haben oder zu dem Schluss gelangen, dass keine Einigung über einen endgültigen Plan erzielt wurde, erstellt die Behörde oder gegebenenfalls das gemeinsame Bewertungsteam den endgültigen Überwachungsbericht; dieser enthält das Ergebnis der Bewertung und gegebenenfalls Schlussfolgerungen zu dem Plan für Korrektur- und Präventivmaßnahmen sowie gegebenenfalls Empfehlungen zur Benennung der Benannten Stelle.

        Die für Benannte Stellen zuständige Behörde oder gegebenenfalls das gemeinsame Bewertungsteam übermitteln der Koordinierungsgruppe Medizinprodukte ihren endgültigen Überwachungsbericht unverzüglich.

        Die für Benannte Stellen zuständige Behörde überwacht gegebenenfalls die Umsetzung des Plans für Korrektur- und Präventivmaßnahmen durch die Benannte Stelle.

        Lautet das Ergebnis des endgültigen Überwachungsberichts, dass die Benannte Stelle die in dieser Verordnung festgelegten Anforderungen nicht mehr erfüllt, oder setzt die Benannte Stelle den Plan für Korrektur- und Präventivmaßnahmen nicht um, so wendet die für Benannte Stellen zuständige Behörde das in Artikel 46 Absatz 4 festgelegte Verfahren an.“

  - f) Absatz 5 erhält folgende Fassung:

    - „(5) Die Überwachung der Benannten Stellen umfasst Audits unter Beobachtung des Personals der Benannten Stelle und bei Bedarf des Personals der Zweigstellen und Unterauftragnehmer; diese Audits werden anlässlich der in den Räumlichkeiten des Herstellers von dem genannten Personal vorgenommenen Bewertungen des Qualitätsmanagementsystems durchgeführt.“

  - „g) Absatz 6 Unterabsatz 1 erhält folgende Fassung:

    - „Bei der Überwachung der Benannten Stellen werden Daten aus der Marktüberwachung, der Vigilanz und der Überwachung nach dem Inverkehrbringen berücksichtigt.“

  - h) Absatz 8 erhält folgende Fassung:

    - „(8) Im Rahmen der Überwachung einer Benannten Stelle wird eine angemessene Anzahl der von der Benannten Stelle durchgeführten Bewertungen des Qualitätsmanagementsystems und der technischen Dokumentation der Hersteller, insbesondere der Dokumentation der klinischen Bewertung, entweder als Fernprüfung oder vor Ort überprüft. Die Stichprobenauswahl der Akten ist repräsentativ für die Arten der von der Benannten Stelle zertifizierten Produkte und das davon ausgehende Risiko, insbesondere für Hochrisikoprodukte. “

  - i) Die Absätze 9, 10 und 11 werden gestrichen.

  - j) Absatz 12 erhält folgende Fassung:

    - „(12) Die für Benannte Stellen zuständige Behörde erstellt eine jährliche Zusammenfassung ihrer Überwachungstätigkeiten in Bezug auf Benannte Stellen sowie gegebenenfalls deren Zweigstellen und Unterauftragnehmer. Diese Zusammenfassung wird über das elektronische System gemäß Artikel 57 öffentlich zugänglich gemacht.“

- 36. Artikel 45 wird gestrichen;

- 37. Artikel 46 wird wie folgt geändert:

  - a) Die Absätze 1 und 2 erhalten folgende Fassung:

    - „(1) Die für Benannte Stellen zuständige Behörde unterrichtet die Kommission und die Koordinierungsgruppe Medizinprodukte über jeden Antrag auf maßgebliche Änderungen der Benennung einer Benannten Stelle.

        Die in den Artikeln 39 und 42 festgelegten Verfahren gelten für wesentliche Erweiterungen des Geltungsbereichs der Benennung. Abweichend von Artikel 39 wird keine Vor-Ort-Bewertung durchgeführt, wenn das gemeinsame Bewertungsteam eine solche Bewertung für die Bewertung der beantragten Erweiterung des Geltungsbereichs der Benennung nicht für erforderlich hält.

        Für Änderungen der Benennung, die keine wesentlichen Erweiterungen ihres Geltungsbereichs darstellen, gelten die in den Absätzen 2 bis 9 festgelegten Verfahren.

    - (2) Nach Prüfung des Antrags auf Änderungen unterrichtet die für Benannte Stellen zuständige Behörde die Kommission über die maßgeblichen Änderungen der Benennung. Die Kommission veröffentlicht die geänderte Notifizierung unverzüglich in NANDO. Die Kommission gibt die Angaben zur Änderung der Benennung der Benannten Stelle unverzüglich in das elektronische System gemäß Artikel 57 ein.“

  - b) Absatz 4 Unterabsatz 1 erhält folgende Fassung:

      „Hat eine für Benannte Stellen zuständige Behörde festgestellt, dass eine Benannte Stelle die in dieser Verordnung festgelegten Anforderungen nicht mehr erfüllt, ihren Verpflichtungen nicht nachkommt oder die erforderlichen Korrekturmaßnahmen nicht umgesetzt hat, so setzt die Behörde die Benennung aus, schränkt sie ein, entzieht sie ganz oder teilweise oder verhängt Auflagen gegen die Benannte Stelle, je nach Schwere des Verstoßes gegen diese Anforderungen oder Verpflichtungen. Eine Aussetzung darf nicht länger als ein Jahr dauern, kann aber einmal um den gleichen Zeitraum verlängert werden.“

- 38. Artikel 47 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Die Kommission untersucht gemeinsam mit der Koordinierungsgruppe Medizinprodukte alle Fälle, in denen sie Kenntnis davon erhält, dass Bedenken bestehen, ob eine Benannte Stelle oder eine oder mehrere ihrer Zweigstellen oder Unterauftragnehmer die Anforderungen in dieser Verordnung weiterhin erfüllen bzw. ihren Verpflichtungen weiterhin nachkommen. Sie stellt sicher, dass die einschlägige für die Benannten Stellen zuständige Behörde unterrichtet wird und Gelegenheit erhält, diesen Bedenken nachzugehen.“

  - b) Absatz 3 erhält folgende Fassung:

    - „(3) Die Kommission kann im Benehmen mit der Koordinierungsgruppe Medizinprodukte die Bewertung durch ein gemeinsames Bewertungsteam gemäß Artikel 39 Absätze 2 bis 10 einleiten, falls begründete Bedenken bestehen, ob eine Benannte Stelle, eine ihrer Zweigstellen oder einer ihrer Unterauftragnehmer die Anforderungen dieser Verordnung nach wie vor erfüllt, und falls den Bedenken durch die Untersuchung der für Benannte Stellen zuständige Behörde offensichtlich nicht in vollem Umfang Rechnung getragen wurde; das Verfahren kann auch auf Ersuchen der für Benannte Stellen zuständigen Behörde eingeleitet werden. Für die Berichterstattung und das Ergebnis dieser Bewertung gelten die in Artikel 39 festgelegten Grundsätze.“

- 39. Artikel 48 wird wie folgt geändert:

  - a) die Überschrift erhält folgende Fassung:

      „Erfahrungsaustausch zwischen den für Benannte Stellen zuständigen Behörden“

  - b) Die Absätze 2 bis 5 werden gestrichen.

- 40. Die Artikel 49 und 50 erhalten folgende Fassung:

**„Artikel 49**

Koordinierung der Benannten Stellen

  - (1) Die Kommission stellt sicher, dass eine angemessene Koordinierung und Zusammenarbeit der Benannten Stellen stattfindet, und zwar in Form einer Koordinierungsgruppe für Benannte Stellen auf dem Gebiet der Medizinprodukte einschließlich In-vitro-Diagnostika. Die Koordinierungsgruppe tritt regelmäßig, mindestens einmal jährlich, zusammen und erstattet der Koordinierungsgruppe Medizinprodukte Bericht.

      Die Kommission kann die Einzelheiten für die Arbeitsweise der Koordinierungsgruppe festlegen.

  - (2) Die Benannten Stellen stellen sicher, dass ihr Fachpersonal an den einschlägigen Tätigkeiten der Koordinierungsgruppe mitwirkt.

  - (3) Alle nach dieser Verordnung und nach der Verordnung (EU) 2017/746 Benannten Stellen beteiligen sich aktiv an der Arbeit der Koordinierungsgruppe, um die Durchführung dieser Verordnung und der Verordnung (EU) 2017/746 zu unterstützen, indem sie Erfahrungen austauschen und gemeinsame Vorlagen sowie technische Leitlinien erarbeiten, um die Harmonisierung und gemeinsame Ansätze im Hinblick auf Konformitätsbewertungstätigkeiten zu erleichtern. Sie arbeiten untereinander sowie mit der Kommission, den zuständigen Behörden der Mitgliedstaaten, den Expertengremien und gegebenenfalls den Fachlaboratorien oder den Referenzlaboratorien der Europäischen Union zusammen, um eine harmonisierte Anwendung der in dieser Verordnung und in der Verordnung (EU) 2017/746 festgelegten Anforderungen sicherzustellen.

  - (4) Alle nach dieser Verordnung und nach der Verordnung (EU) 2017/746 Benannten Stellen befolgen einen von der Koordinierungsgruppe ausgearbeiteten und von der Koordinierungsgruppe Medizinprodukte genehmigten Verhaltenskodex. Im Verhaltenskodex sind die Grundsätze des öffentlichen Interesses, der höchsten fachlichen Kompetenz und Integrität, der Unparteilichkeit, der Unabhängigkeit, der Transparenz, der Verhältnismäßigkeit, der Vorhersehbarkeit und der Rechenschaftspflicht festgelegt, zu deren Einhaltung sich die Benannten Stellen verpflichten, wenn sie die ihnen durch diese Verordnung oder die Verordnung (EU) 2017/746 übertragenen Rechte und Pflichten ausüben.

<a id="art-50"></a>
### Artikel 50

Zugang zu Benannten Stellen und Gebühren

  - (1) Die Benannten Stellen erstellen Listen ihrer Gebühren für die von ihnen durchgeführten Konformitätsbewertungstätigkeiten und machen diese Listen öffentlich zugänglich. Sie übermitteln der Kommission die Listen, die die Öffentlichkeit auf einer speziellen Website darauf verweist.

  - (2) Benannte Stellen wenden mindestens eine Gebührenermäßigung von 50 % für Hersteller an, die Kleinstunternehmen im Sinne der Empfehlung 2003/361/EG sind, und mindestens eine Gebührenermäßigung von 25 % für kleine Unternehmen im Sinne dieser Empfehlung. Sie wenden mindestens eine Gebührenermäßigung von 50 % für Hersteller an, die eine Konformitätsbewertung für ein Medizinprodukt für seltene Erkrankungen gemäß Artikel 52a Absatz 3 beantragen. Benannte Stellen räumen Herstellern, bei denen es sich um Kleinst- oder kleine Unternehmen im Sinne der Empfehlung 2003/361/EG handelt, die Möglichkeit ein, die Zahlung der Gebühren bis zum Abschluss der jeweiligen Konformitätsbewertungstätigkeit aufzuschieben.

  - (3) Die Kommission kann im Benehmen mit der Koordinierungsgruppe Medizinprodukte Durchführungsrechtsakte erlassen, um die Struktur und die Höhe der in Absatz 1 genannten Gebühren näher festzulegen, wobei sie dabei Folgendes berücksichtigt:

    - a) die Festlegung und Beibehaltung hoher Qualitäts- und Sicherheitsstandards für Produkte;

    - b) die Sicherstellung der Verfügbarkeit von Produkten;

    - c) der Schutz der Interessen von Kleinst-, kleinen oder mittleren Unternehmen im Sinne der Empfehlung 2003/361/EG;

    - d) die Förderung von Innovation und Wettbewerbsfähigkeit.

  - (4) Die Benannten Stellen stellen sicher, dass Hersteller, bei denen es sich um Kleinst-, kleine oder mittlere Unternehmen im Sinne der Empfehlung 2003/361/EG handelt, unter Bedingungen Zugang zu ihren Konformitätsbewertungstätigkeiten erhalten, die mindestens so günstig sind wie die Bedingungen für den Zugang anderer Hersteller.

  - (5) Die Benannten Stellen bearbeiten jeden Antrag eines Herstellers auf Konformitätsbewertungstätigkeiten und unterrichten den Hersteller innerhalb von 15 Tagen nach Eingang des Antrags entsprechend.

  - (6) Ist dies im Interesse der öffentlichen Gesundheit oder der Gesundheit oder Sicherheit der Patienten ordnungsgemäß begründet, kann die für Benannte Stellen zuständige Behörde eine Benannte Stelle anweisen, einen Antrag eines Herstellers auf Konformitätsbewertungstätigkeiten anzunehmen, die in den Geltungsbereich der Benennung dieser Benannten Stelle fallen.“

- 41. Artikel 51 wird wie folgt geändert:

  - a) Absatz 2 erhält folgende Fassung:

    - „(2) Die zuständigen Behörden koordinieren ihre Tätigkeiten bei der Festlegung der Klassifizierung eines Produkts oder einer Kategorie oder Gruppe von Produkten. Die Ergebnisse der Koordinierungstätigkeiten der zuständigen Behörden, einschließlich der Ergebnisse etwaiger von einer zuständigen Behörde gemäß den Artikeln 51a oder 51b erlassener Entscheidungen oder Maßnahmen sowie etwaiger im Zusammenhang mit der Klassifizierung von einem Expertengremium abgegebener Stellungnahmen, werden öffentlich zugänglich gemacht, ohne dass dabei vertrauliche Informationen im Sinne des Artikels 109 offengelegt werden.“

  - b) Absatz 3 Buchstabe b erhält folgende Fassung:

    - „b) die Klassifizierung — abweichend von Anhang VIII — in eine andere Klasse eines Produkts, einer Produktkategorie oder einer Produktgruppe aus Gründen der öffentlichen Gesundheit gemäß neuesten wissenschaftlichen Erkenntnissen oder auf der Grundlage von Informationen, die im Laufe der Vigilanz- und Marktüberwachungstätigkeiten verfügbar werden, unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit und der Klassifizierung von Produkten auf internationaler Ebene.“

  - c) Absatz 5 Satz 1 erhält folgende Fassung:

    - „Um die einheitliche Anwendung der in Anhang VIII festgelegten Vorschriften sicherzustellen und unter Berücksichtigung der einschlägigen wissenschaftlichen Stellungnahmen der zuständigen wissenschaftlichen Ausschüsse oder Expertengremien wird der Kommission die Befugnis übertragen, Durchführungsrechtsakte zu erlassen, soweit dies für die Lösung von Problemen im Zusammenhang mit Unterschieden bei der Auslegung und der praktischen Anwendung erforderlich ist.“

  - d) Folgender Absatz 7 wird angefügt:

    - „(7) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zur Änderung des Anhangs VIII zu erlassen, um ihn an den technischen oder wissenschaftlichen Fortschritt anzupassen oder um Entwicklungen bei der Klassifizierung von Produkten auf internationaler Ebene Rechnung zu tragen.“

- 42. Die folgenden Artikel 51a und 51b werden eingefügt:

**„Artikel 51a**

Klassifizierung im Falle einer Streitigkeit zwischen Hersteller und Benannter Stelle

  - (1) Ein Hersteller oder eine Benannte Stelle kann jede zwischen ihnen aus der Anwendung von Anhang VIII entstehende Streitigkeit an die zuständige Behörde des Mitgliedstaats verweisen, in dem der Hersteller seine eingetragene Niederlassung hat. In Fällen, in denen der Hersteller keine eingetragene Niederlassung in der Union hat und noch keinen Bevollmächtigten ernannt hat, wird die Angelegenheit an die zuständige Behörde des Mitgliedstaats verwiesen, in dem der in Anhang IX Abschnitt 2.2 Unterabsatz 2 Buchstabe b letzter Gedankenstrich genannte Bevollmächtigte seine eingetragene Niederlassung hat.

  - (2) Innerhalb von 30 Tagen nach Eingang der in Absatz 1 genannten Verweisung konsultiert die zuständige Behörde die anderen Mitgliedstaaten zu ihrem Entwurf einer Klassifizierungsentscheidung.

  - (3) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 2 genannten Konsultation von einem Mitgliedstaat kein begründeter Widerspruch erhoben, erlässt die zuständige Behörde ihre Entscheidung innerhalb von 90 Tagen nach Eingang der in Absatz 1 genannten Verweisung.

  - (4) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 2 genannten Konsultation von einem Mitgliedstaat ein begründeter Widerspruch gegen den Entwurf der Klassifizierungsentscheidung erhoben, wird die Angelegenheit an ein Expertengremium gemäß Artikel 106 verwiesen. Dieses Expertengremium gibt innerhalb von 30 Tagen eine Stellungnahme zur Klassifizierung des Produkts ab. Die zuständige Behörde kann das Expertengremium um Klarstellungen zu seiner Stellungnahme ersuchen.

  - (5) Innerhalb von 30 Tagen nach Eingang der in Absatz 4 genannten Stellungnahme des Expertengremiums oder einer etwaigen Klarstellung, um die ersucht wurde, erlässt die zuständige Behörde ihre Entscheidung und trägt dabei der Stellungnahme des Expertengremiums weitestgehend Rechnung. Sie unterrichtet die anderen Mitgliedstaaten und die Kommission unverzüglich über ihre Entscheidung.

  - (6) Die Kommission kann mittels Durchführungsrechtsakten weitere Einzelheiten des Verfahrens für die Anwendung dieses Artikels und des Artikels 51b festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

<a id="art-51b"></a>
### Artikel 51b

Anfechtung der Klassifizierung CE-gekennzeichneter Produkte

  - (1) Ist eine zuständige Behörde nach Durchführung einer Bewertung gemäß Artikel 94 der Auffassung, dass ein gemäß Artikel 20 CE-gekennzeichnetes Produkt nicht im Einklang mit Anhang VIII klassifiziert wurde, so konsultiert sie die anderen Mitgliedstaaten zu der von ihr vorgesehenen Maßnahme hinsichtlich der Klassifizierung des Produkts.

  - (2) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 1 genannten Konsultation von einem Mitgliedstaat kein begründeter Widerspruch erhoben, kann die zuständige Behörde die Maßnahme zur Klassifizierung des betreffenden Produkts erlassen und unterrichtet die anderen Mitgliedstaaten und die Kommission unter Angabe der Gründe für die Entscheidung.

  - (3) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 1 genannten Konsultation von einem Mitgliedstaat ein begründeter Widerspruch gegen die vorgesehene Maßnahme zur Klassifizierung erhoben, wird die Angelegenheit an ein Expertengremium gemäß Artikel 106 verwiesen, das innerhalb von 30 Tagen eine Stellungnahme zur Klassifizierung des Produkts abgibt. Die zuständige Behörde kann das Expertengremium um Klarstellungen zu seiner Stellungnahme ersuchen.

  - (4) Die zuständige Behörde trägt der Stellungnahme des Expertengremiums weitestgehend Rechnung. Trifft die zuständige Behörde eine Maßnahme zur Klassifizierung, unterrichtet sie die anderen Mitgliedstaaten und die Kommission unverzüglich über diese Maßnahme.“

- 43. Artikel 52 wird wie folgt geändert:

  - a) In Absatz 3 wird folgender Unterabsatz angefügt:

      „Abweichend von Unterabsatz 1 unterliegen Produkte der Klasse III, bei denen es sich um Produkte mit bewährter Technologie handelt, einer Konformitätsbewertung gemäß Anhang IX Kapitel I und III, einschließlich einer Bewertung der technischen Dokumentation eines repräsentativen Produkts je generischer Produktgruppe.“

  - b) Absatz 4 erhält folgende Fassung:

    - „(4) Hersteller von Produkten der Klasse IIb, ausgenommen Sonderanfertigungen oder Prüfprodukte, unterliegen einer Konformitätsbewertung gemäß Anhang IX Kapitel I und III, einschließlich einer Bewertung der technischen Dokumentation eines repräsentativen Produkts je generischer Produktgruppe oder, im Fall nicht implantierbarer Produkte der Klasse IIb, bei denen es sich um Produkte mit bewährter Technologie handelt, eines repräsentativen Produkts je Produktkategorie.

        Abweichend von Unterabsatz 1 gilt für implantierbare Produkte der Klasse IIb, mit Ausnahme von Produkten mit bewährter Technologie, die in Anhang IX Abschnitt 4 festgelegte Bewertung der technischen Dokumentation für jedes Produkt. Alternativ können die Hersteller sich für eine Konformitätsbewertung auf der Grundlage einer Baumusterprüfung gemäß Anhang X in Kombination mit einer Konformitätsbewertung auf der Grundlage einer Produktkonformitätsprüfung gemäß Anhang XI entscheiden. “

  - c) Absatz 5 wird gestrichen.

  - d) Absatz 6 erhält folgende Fassung:

    - „(6) Hersteller von Produkten der Klasse IIa, ausgenommen Sonderanfertigungen oder Prüfprodukte, unterliegen einer Konformitätsbewertung gemäß Anhang IX Kapitel I und III, einschließlich einer Bewertung der technischen Dokumentation eines repräsentativen Produkts je Produktkategorie.

        Alternativ können die Hersteller sich dafür entscheiden, die in den Anhängen II und III genannte technische Dokumentation zu erstellen, in Kombination mit einer Konformitätsbewertung gemäß Anhang XI Abschnitt 10 oder Abschnitt 18. Die Bewertung der technischen Dokumentation wird für ein repräsentatives Produkt jeder Produktkategorie durchgeführt.“

  - e) Absatz 7 wird wie folgt geändert:

    - i) Der zweite Satz erhält folgende Fassung:

        „Bei Produkten, die in sterilem Zustand in Verkehr gebracht werden, bei Produkten mit Messfunktion oder bei Produkten, bei denen es sich um wiederverwendbare chirurgische Instrumente handelt, wendet der Hersteller die in Anhang IX Kapitel I und III oder in Anhang XI Abschnitt 10a aufgeführten Verfahren an.“

    - ii) Folgender Unterabsatz wird angefügt:

        „Hat der Hersteller wiederverwendbarer chirurgischer Instrumente der Klasse I harmonisierte Normen oder GS angewendet, die alle in Unterabsatz 1 Buchstabe c genannten relevanten Aspekte abdecken, ist die Mitwirkung einer Benannten Stelle nicht erforderlich.“

  - f) Absatz 12 erhält folgende Fassung:

    - „(12) Die Unterlagen zu den in den Absätzen 1 bis 7 genannten Verfahren müssen in einer Amtssprache der Union vorliegen, mit der die Benannte Stelle einverstanden ist.“

  - g) Absatz 14 Unterabsatz 1 erhält folgende Fassung:

    - „Für folgende Aspekte kann die Kommission im Wege von Durchführungsrechtsakten genaue Regelungen und Verfahrenselemente festlegen:

      - a) die Grundlage für die Auswahl des repräsentativen Produkts für die Bewertung der technischen Dokumentation gemäß den Absätzen 3, 4 und 6;

      - b) Modalitäten der von den Benannten Stellen gemäß Anhang IX Abschnitt 3.4 unter Berücksichtigung der Risikoklasse und der Art der Produkte durchzuführenden unangekündigten Vor-Ort-Audits und Stichprobenprüfungen,

      - c) physische Kontrollen, Laboruntersuchungen oder andere Tests, die von den Benannten Stellen im Rahmen der Stichprobenprüfungen, der Bewertung der technischen Dokumentation und der Musterprüfung durchzuführen sind,

      - d) Modalitäten der Konformitätsbewertungsverfahren für in Artikel 52a genannte bahnbrechende Produkte und Medizinprodukte für seltene Erkrankungen.“

  - h) Folgender Absatz 15 wird angefügt:

    - „(15) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um die Anhänge IX, X, XI und XIII zu ändern, um sie an den technischen oder wissenschaftlichen Fortschritt oder an Entwicklungen bei der Konformitätsbewertung von Produkten auf internationaler Ebene anzupassen und um den Erfordernissen bestimmter Produkte im Hinblick auf ihre besonderen Merkmale Rechnung zu tragen.“

- 44. Die folgenden Artikel 52a und 52b werden eingefügt:

**„Artikel 52a**

Konformitätsbewertung von bahnbrechenden Medizinprodukten und Medizinprodukten für seltene Erkrankungen

  - (1) Für die Konformitätsbewertung von bahnbrechenden Produkten und von Produkten für seltene Erkrankungen, bei denen eine Benannte Stelle an der Konformitätsbewertung mitwirkt, gelten die in Artikel 52 festgelegten Verfahren vorbehaltlich der im vorliegenden Artikel festgelegten besonderen Regelungen.

  - (2) Ein Produkt gilt als bahnbrechendes Produkt, wenn es die folgenden Kriterien erfüllt:

    - a) Es ist davon auszugehen, dass damit eine große Neuheit in Bezug auf die Produkttechnologie, das damit verbundene klinische Verfahren oder die Anwendung des Produkts in der klinischen Praxis in der Union eingeführt wird.

    - b) Es ist davon auszugehen, dass es für Patienten oder die öffentliche Gesundheit im Hinblick auf eine lebensbedrohliche oder irreversibel beeinträchtigende Krankheit oder ein solches Leiden in folgender Hinsicht einen erheblichen positiven klinischen Nutzen bietet:

      - i) indem es einen erheblichen positiven klinischen oder gesundheitlichen Nutzen im Vergleich zu den verfügbaren Alternativen und dem Stand der Technik bietet,

      - ii) indem es eine medizinische Versorgungslücke schließt, wenn für diese Zweckbestimmung keine oder keine ausreichenden Alternativen verfügbar sind.

  - (3) Ein Produkt gilt als Medizinprodukt für seltene Erkrankungen, wenn es die folgenden Kriterien erfüllt:

    - a) Es ist zur Behandlung, Diagnose oder Prävention einer Krankheit oder eines Leidens bestimmt, die/das in der Union bei nicht mehr als 12 000 Personen pro Jahr auftritt.

    - b) Mindestens eines der folgenden Kriterien ist erfüllt:

      - i) Es gibt keine ausreichenden Alternativen.

      - ii) Es ist davon auszugehen, dass das Produkt im Vergleich zu verfügbaren Alternativen oder dem Stand der Technik einen klinischen Nutzen bietet, wobei sowohl produktspezifische Faktoren als auch patientengruppenspezifische Faktoren berücksichtigt werden.

  - (4) Auf einen ordnungsgemäß begründeten Antrag eines Herstellers oder einer Benannten Stelle hin gibt ein Expertengremium gemäß Artikel 106 eine Stellungnahme dazu ab, ob die in Absatz 2 bzw. 3 dieses Artikels genannten Kriterien erfüllt sind. Diese Stellungnahme wird auf einer dafür vorgesehenen Website veröffentlicht, ohne dass dabei vertrauliche Informationen im Sinne des Artikels 109 offengelegt werden, und sie ist von dem Hersteller und der Benannten Stelle gebührend zu berücksichtigen.

  - (5) Bestätigt die Stellungnahme des Expertengremiums die Erfüllung der in Absatz 2 bzw. 3 dieses Artikels genannten Kriterien, kann der Hersteller eines bahnbrechenden Produkts bzw. eines Medizinprodukts für seltene Erkrankungen sich von den Expertengremien gemäß Artikel 106 zu seiner klinischen Entwicklungsstrategie sowie zu geeigneten präklinischen oder klinischen Daten für die klinische Bewertung des Produkts beraten lassen.

  - (6) Für ein bestätigtes bahnbrechendes Produkt bzw. ein Medizinprodukt für seltene Erkrankungen priorisiert die an dem in Artikel 52 festgelegten Konformitätsbewertungsverfahren mitwirkende Benannte Stelle die Konformitätsbewertung dieses Produkts und wendet gegebenenfalls eine fortlaufende Überprüfung an, um die Bewertungsfristen zu verkürzen.

      Die Benannte Stelle trägt einer von den Expertengremien gemäß Absatz 4 oder 5 abgegebenen Stellungnahme oder erteilten Beratung gebührend Rechnung und legt, sofern sie dieser Stellungnahme oder Beratung nicht folgt, eine ordnungsgemäße Begründung dafür vor. Die Benannte Stelle kann das Expertengremium um Klarstellung der von ihm abgegebenen Stellungnahme ersuchen.

  - (7) Die Benannte Stelle stellt gemäß Artikel 56 eine Bescheinigung aus, wenn die präklinischen Nachweise vor dem Inverkehrbringen, auch wenn sie nur auf begrenzten klinischen Daten beruhen, als ausreichend erachtet werden, sofern eine der folgenden Bedingungen erfüllt ist:

    - a) Der Nutzen der unmittelbaren Verfügbarkeit des Produkts auf dem Markt überwiegt das Risiko, das damit verbunden ist, dass zusätzliche klinische Daten noch erforderlich sind.

    - b) Das Nutzen-Risiko-Verhältnis des Produkts ist günstig, und der Hersteller verpflichtet sich, zusätzliche Daten aus Tätigkeiten der klinischen Nachbeobachtungen nach dem Inverkehrbringen bereitzustellen.

      Gegebenenfalls begrenzt die Benannte Stelle die Gültigkeit der Bescheinigung und legt gemäß Artikel 56 etwaige Bedingungen oder Einschränkungen der Gültigkeit der Bescheinigung fest, wie etwa die Verpflichtung des Herstellers, innerhalb eines festgelegten Zeitraums bestimmte klinische Nachbeobachtungen nach dem Inverkehrbringen durchzuführen.

  - (8) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um diesen Artikel zu ändern, um ihn an den technischen oder wissenschaftlichen Fortschritt anzupassen oder um Entwicklungen bei der Konformitätsbewertung bahnbrechender Produkte oder von Medizinprodukten für seltene Erkrankungen auf internationaler Ebene Rechnung zu tragen.

  - (9) Die Kommission kann im Wege von Durchführungsrechtsakten weitere Einzelheiten des in diesem Artikel festgelegten Verfahrens für die Konformitätsbewertung bahnbrechender Produkte oder von Medizinprodukten für seltene Erkrankungen festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

<a id="art-52b"></a>
### Artikel 52b

Digitalisierung der technischen Dokumentation, der Konformitätsbewertung und der Berichte

  - (1) Der Hersteller kann die technische Dokumentation sowie alle nach dieser Verordnung erforderlichen Berichte oder sonstigen Unterlagen in einem digitalen Format erstellen und bereitstellen. Dieses digitale Format kann ein strukturiertes maschinenlesbares Format sein, sofern es in ein vom Menschen lesbares Format umgewandelt werden kann und eine Versionskontrolle besteht, die die Durchführung rückblickender Konformitätsprüfungen ermöglicht. Sind die technische Dokumentation, die Berichte oder sonstige Unterlagen einer Benannten Stelle vorzulegen und von dieser zu bewerten, vereinbart der Hersteller mit der Benannten Stelle das digitale Format.

  - (2) Ist dies erforderlich, um sicherzustellen, dass das in Absatz 1 genannte digitale Format zuverlässig, interoperabel und standardisiert ist, kann die Kommission mittels gemeinsamer Spezifikationen gemäß Artikel 9 Mindestanforderungen oder funktionale Spezifikationen für das digitale Format festlegen.“

- 45. Artikel 53 Absatz 5 erhält folgende Fassung:

  - „(5) Die Benannten Stellen und ihre Mitarbeiter führen ihre Konformitätsbewertungstätigkeiten im öffentlichen Interesse und mit höchster beruflicher Zuverlässigkeit und der erforderlichen technischen und wissenschaftlichen Kompetenz in dem betreffenden Bereich durch; sie dürfen keinerlei Druck oder Einflussnahme, insbesondere finanzieller Art, ausgesetzt sein, der/die sich auf ihre Beurteilung oder die Ergebnisse ihrer Konformitätsbewertungstätigkeit auswirken könnte und der/die insbesondere von Personen oder Personengruppen ausgeht, die ein Interesse am Ergebnis dieser Tätigkeiten haben.“

- 46. Die Artikel 54 und 55 erhalten folgende Fassung:

**„Artikel 54**

Konsultationsverfahren zur klinischen Bewertung bestimmter Hochrisikoprodukte

  - (1) Zusätzlich zu den gemäß Artikel 52 geltenden Verfahren wendet eine Benannte Stelle bei der Durchführung einer Konformitätsbewertung von implantierbaren Produkten der Klasse III, mit Ausnahme von Sonderanfertigungen, das Konsultationsverfahren zur klinischen Bewertung gemäß Anhang IX Abschnitt 5.1 bzw. gemäß Anhang X Abschnitt 6 an.

      Ist dies zum Schutz der Gesundheit und Sicherheit von Patienten, Anwendern oder anderen Personen oder anderer Aspekte der öffentlichen Gesundheit gerechtfertigt, wird der Kommission die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um Absatz 1 zu ändern, indem weitere Produkttypen zu den Produkten hinzugefügt werden, die dem im ersten Unterabsatz genannten Konsultationsverfahren zur klinischen Bewertung unterliegen.

  - (2) Abweichend von Absatz 1 ist das in diesem Absatz genannte Verfahren in den folgenden Fällen nicht erforderlich:

    - a) für die Erneuerung einer nach dieser Verordnung ausgestellten Bescheinigung,

    - b) wenn das Produkt durch Änderung eines Produkts ausgelegt wurde, das bereits mit derselben Zweckbestimmung in Verkehr gebracht wurde, sofern der Hersteller der Benannten Stelle zu deren Zufriedenheit nachgewiesen hat, dass die Änderungen das Nutzen-Risiko-Verhältnis des Produkts nicht beeinträchtigen,

    - c) wenn die Grundsätze der klinischen Bewertung des Produkttyps oder der Produktkategorie in einer harmonisierten Norm gemäß Artikel 8 oder in gemeinsamen Spezifikationen gemäß Artikel 9 festgelegt sind und die Benannte Stelle bestätigt, dass die klinische Bewertung des Herstellers für dieses Produkt mit den einschlägigen harmonisierten Normen oder gemeinsamen Spezifikationen für die klinische Bewertung dieser Art von Produkten im Einklang steht.

  - (3) Die Benannte Stelle teilt den zuständigen Behörden, der für Benannte Stellen zuständigen Behörde und der Kommission über das elektronische System gemäß Artikel 57 mit, ob das Verfahren gemäß Absatz 1 anzuwenden ist. Dieser Mitteilung ist der Bericht über die Begutachtung der klinischen Bewertung beizufügen.

  - (4) Die Benannte Stelle trägt der im Rahmen des Konsultationsverfahrens zur klinischen Bewertung von dem Expertengremium abgegebenen Stellungnahme weitestgehend Rechnung. Hat die Benannte Stelle die in dieser Stellungnahme zum Ausdruck gebrachten Auffassungen und Empfehlungen nicht befolgt, übermittelt sie der für Benannte Stellen zuständigen Behörde des Mitgliedstaats, in dem sie niedergelassen ist, dem Expertengremium, das die Stellungnahme abgegeben hat, und der Kommission eine hinreichende Begründung hierfür sowie ihren abschließenden Bericht über die Begutachtung der klinischen Bewertung.

<a id="art-55"></a>
### Artikel 55

Mechanismus zur Kontrolle von Konformitätsbewertungen

  - (1) Die Koordinierungsgruppe Medizinprodukte oder die Kommission kann sich auf der Grundlage begründeter Bedenken in Bezug auf die Sicherheit und die Leistung eines Produkts durch ein Expertengremium beraten lassen. Zu diesem Zweck kann die Koordinierungsgruppe Medizinprodukte oder die Kommission die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, auffordern, dem Expertengremium ihren Bericht über die Begutachtung der klinischen Bewertung sowie alle nachfolgenden Überwachungsbewertungsberichte zu diesem Produkt vorzulegen. Das Expertengremium kann die Benannte Stelle oder den Hersteller auffordern, zusätzliche für seine Bewertung erforderliche Informationen vorzulegen.

  - (2) Die Koordinierungsgruppe Medizinprodukte oder die Kommission kann sich auf der Grundlage begründeter Bedenken in Bezug auf die Sicherheit und die Leistung eines Produkts durch ein oder mehrere Fachlaboratorien auf der Grundlage von Laborprüfungen beraten lassen, sofern das Produkt in den Geltungsbereich der Benennung dieser Fachlaboratorien fällt. Zu diesem Zweck kann die Koordinierungsgruppe Medizinprodukte oder die Kommission die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, auffordern, den Fachlaboratorien ihren Bericht über die Begutachtung der klinischen Bewertung sowie alle nachfolgenden Überwachungsbewertungsberichte zu diesem Produkt vorzulegen. Die Fachlaboratorien können die Benannte Stelle oder den Hersteller auffordern, Muster des Produkts oder zusätzliche für ihre Bewertung erforderliche Informationen vorzulegen.

  - (3) Die Benannte Stelle trägt der vom Expertengremium oder vom Fachlaboratorium erteilten Beratung weitestgehend Rechnung und ergreift erforderlichenfalls geeignete Maßnahmen, einschließlich der in Artikel 56 Absätze 3 und 4 genannten Maßnahmen.“

- 47. Artikel 56 wird wie folgt geändert:

  - a) Die Absätze 1 und 2 erhalten folgende Fassung:

    - „(1) Die Benannten Stellen stellen Bescheinigungen gemäß den Anhängen IX, X und XI in einer Amtssprache der Union aus und laden sie unverzüglich in Eudamed hoch. In Anhang XII ist niedergelegt, welche Angaben die Bescheinigungen mindestens enthalten müssen.

    - (2) Die Gültigkeit von Bescheinigungen ist zeitlich nicht begrenzt, es sei denn, die Benannte Stelle hält es in hinreichend begründeten Ausnahmefällen für erforderlich, die Gültigkeitsdauer zu beschränken. In diesen Fällen gibt die Benannte Stelle die Gültigkeitsdauer auf der Bescheinigung an. Ist die Gültigkeitsdauer der Bescheinigung begrenzt, kann die Benannte Stelle auf Antrag des Herstellers nach Durchführung einer Bewertung gemäß Anhang VII Abschnitt 4.11 die Gültigkeit der Bescheinigung verlängern. Ein Nachtrag zu einer Bescheinigung ist so lange gültig wie die Bescheinigung, zu der er gehört.“

  - b) Folgender Absatz 2a wird eingefügt:

    - „(2a) Während der Gültigkeitsdauer der Bescheinigung führt die Benannte Stelle geeignete Überwachungstätigkeiten durch, einschließlich regelmäßiger Überprüfungen unter Berücksichtigung der Entwicklungen des Stands der Technik. Diese Überprüfungen müssen der Risikoklasse des Produkts angemessen sein.“

  - c) Absatz 3 erhält folgende Fassung:

    - „(3) Die Benannten Stellen können Bedingungen für die Gültigkeit der Bescheinigung festlegen, etwa indem sie den Verwendungszweck eines Produkts auf bestimmte Patientengruppen beschränken oder den Hersteller verpflichten, gemäß Anhang XIV Teil B bestimmte Studien zur klinischen Nachbeobachtung nach dem Inverkehrbringen durchzuführen.“

  - d) Absatz 4 Satz 1 erhält folgende Fassung:

      „Stellt eine Benannte Stelle fest, dass der Hersteller die Anforderungen dieser Verordnung nicht mehr erfüllt, setzt sie die erteilte Bescheinigung aus oder widerruft diese oder legt Bedingungen dafür fest, jeweils unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit, sofern die Einhaltung der Anforderungen nicht durch geeignete Korrekturmaßnahmen des Herstellers innerhalb einer von der Benannten Stelle gesetzten angemessenen Frist wiederhergestellt wird.“

  - e) Absatz 5 Satz 1 erhält folgende Fassung:

      „Die Benannte Stelle gibt in das elektronische System gemäß Artikel 57 alle Informationen zu ausgestellten Bescheinigungen ein, auch zu deren Änderungen und Nachträgen, sowie Angaben über ausgesetzte, wieder in Kraft gesetzte, widerrufene oder verweigerte Bescheinigungen sowie über für Bescheinigungen festgelegte Bedingungen.“

- 48. Artikel 57 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) Buchstabe f erhält folgende Fassung:

      - „f) Mitteilungen im Zusammenhang mit Konformitätsbewertungen sowie die in Artikel 54 Absätze 3 und 3a genannten Informationen oder Unterlagen;“

    - ii) Ziffer i wird gestrichen.

- 49. Artikel 59 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Abweichend von Artikel 52 kann jede zuständige Behörde auf einen ordnungsgemäß begründeten Antrag hin im Hoheitsgebiet des betreffenden Mitgliedstaats für einen begrenzten Zeitraum das Inverkehrbringen oder die Inbetriebnahme eines bestimmten Produkts genehmigen, für das die geltenden Konformitätsbewertungsverfahren nicht durchgeführt wurden, sofern die Verwendung dieses Produkts im Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten liegt.“

  - b) Folgender Absatz 1a wird eingefügt:

    - „(1a) Abweichend von Artikel 6 Absatz 2 kann jede zuständige Behörde auf einen ordnungsgemäß begründeten Antrag hin für einen begrenzten Zeitraum einer im Hoheitsgebiet des betreffenden Mitgliedstaats niedergelassenen natürlichen oder juristischen Person die Erbringung einer diagnostischen oder therapeutischen Dienstleistung gemäß dem genannten Artikel unter Verwendung eines Produkts genehmigen, für das die in dieser Verordnung festgelegten geltenden Konformitätsbewertungsverfahren nicht durchgeführt wurden, sofern die Erbringung dieser Dienstleistung im Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten liegt.“

  - c) Absatz 2 erhält folgende Fassung:

    - „(2) Der Mitgliedstaat unterrichtet die Kommission, die anderen Mitgliedstaaten und die einschlägigen Expertengremien gemäß Artikel 106 über jede Entscheidung, das Inverkehrbringen oder die Inbetriebnahme eines Produkts oder die Erbringung einer Dienstleistung gemäß Absatz 1 oder 1a zu genehmigen, sofern eine solche Genehmigung nicht nur für die Verwendung bei einem einzigen Patienten erteilt wurde.

        Der Mitgliedstaat macht Informationen über solche Genehmigungen auch öffentlich zugänglich.“

  - d) Absatz 3 Unterabsatz 1 erhält folgende Fassung:

    - „(3) Wurde ein Antrag gemäß Absatz 1 oder Absatz 1a bei den zuständigen Behörden in mehr als einem Mitgliedstaat gestellt, kann die Kommission auf der Grundlage einer Stellungnahme eines Expertengremiums gemäß Artikel 106 in Ausnahmefällen im Zusammenhang mit der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten im Wege von Durchführungsrechtsakten die Gültigkeit einer von einem Mitgliedstaat gemäß Absatz 1 oder Absatz 1a erteilten Genehmigung für einen begrenzten Zeitraum auf das Hoheitsgebiet der Union ausdehnen oder eine Genehmigung gemäß Absatz 1 oder Absatz 1a für das Hoheitsgebiet der Union erteilen. Die Kommission kann die Bedingungen festlegen, unter denen das Produkt in Verkehr gebracht oder in Betrieb genommen werden darf bzw. unter denen die diagnostische oder therapeutische Dienstleistung erbracht werden darf. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.“

  - e) Die folgenden Absätze 4 und 5 werden angefügt:

    - „(4) Im Falle einer gemäß Artikel 23 der Verordnung (EU) 2022/2371 des Europäischen Parlaments und des Rates***** festgestellten gesundheitlichen Notlage auf Unionsebene kann die Kommission von sich aus nach Anhörung der Koordinierungsgruppe Medizinprodukte im Wege von Durchführungsrechtsakten das Inverkehrbringen oder die Inbetriebnahme eines Produkts gemäß Absatz 3 genehmigen. Die Geltung dieser Genehmigung endet spätestens dann, wenn die Feststellung der gesundheitlichen Notlage gemäß Artikel 23 Absatz 2 der Verordnung (EU) 2022/2371 aufgehoben wird. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

        In hinreichend begründeten Fällen äußerster Dringlichkeit im Zusammenhang mit der menschlichen Sicherheit und Gesundheit kann die Kommission gemäß dem in Artikel 114 Absatz 4 genannten Verfahren sofort geltende Durchführungsrechtsakte erlassen.

    - (5) Die Kommission kann im Wege von Durchführungsrechtsakten Vorschriften festlegen, die das in diesem Artikel festgelegte Verfahren weiter präzisieren. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.“

    - ____________________

    - ***** Verordnung (EU) 2022/2371 des Europäischen Parlaments und des Rates vom 23. November 2022 zu schwerwiegenden grenzüberschreitenden Gesundheitsgefahren und zur Aufhebung des Beschlusses Nr. 1082/2013/EU (ABl. L 314 vom 6.12.2022, S. 26, ELI: http://data.europa.eu/eli/reg/2022/2371/oj ).“

- 50. Folgende Artikel 59a, 59b und 59c werden eingefügt:

**„Artikel 59a**

Abweichungen von bestimmten Anforderungen im Falle einer schwerwiegenden grenzüberschreitenden Gesundheitsgefahr, einer Katastrophe oder einer Krise

  - (1) Auf einen ordnungsgemäß begründeten Antrag des Herstellers hin kann eine zuständige Behörde für einen begrenzten Zeitraum abweichend von den einschlägigen Bestimmungen der Anhänge II, III, IX, X und XI eine Ausnahme von den Anforderungen in Bezug auf Änderungen der Herstellung, der Auslegung oder des Verwendungszwecks eines Produkts mit CE-Kennzeichnung genehmigen, sofern dies im Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten liegt, und zwar in einem der folgenden Fälle:

    - a) einer schwerwiegenden grenzüberschreitenden Gesundheitsgefahr im Sinne von Artikel 3 Nummer 1 der Verordnung (EU) 2022/2371;

    - b) eine Katastrophe oder eine Krise im Sinne der Verordnung (EU) …/… des Europäischen Parlaments und des Rates******.

  - (2) Der Hersteller stellt sicher, dass die hergestellten Produkte weiterhin den einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I entsprechen.

  - (3) Die zuständige Behörde kann die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, ersuchen, sie bei der Bewertung eines Antrags gemäß Absatz 1 zu unterstützen.

  - (4) Gegebenenfalls hält der Hersteller die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, über alle Änderungen in Bezug auf die Herstellung, die Auslegung oder den Verwendungszweck eines Produkts mit CE-Kennzeichnung gemäß der Genehmigung nach Absatz 1 auf dem Laufenden.

  - (5) Wurde ein Antrag gemäß Absatz 1 bei den zuständigen Behörden in mehr als einem Mitgliedstaat gestellt, kann die Kommission in Ausnahmefällen im Zusammenhang mit der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten im Wege von Durchführungsrechtsakten die Gültigkeit einer von einem Mitgliedstaat gemäß Absatz 1 gewährten Ausnahme für einen begrenzten Zeitraum auf das Hoheitsgebiet der Union ausdehnen oder eine Ausnahme gemäß Absatz 1 für das Hoheitsgebiet der Union gewähren. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

      In hinreichend begründeten Fällen äußerster Dringlichkeit im Zusammenhang mit der menschlichen Sicherheit und Gesundheit kann die Kommission gemäß dem in Artikel 114 Absatz 4 genannten Verfahren sofort geltende Durchführungsrechtsakte erlassen.

      ___________________

      ****** Verordnung (EU) .../... des Europäischen Parlaments und des Rates vom ... über ... (ABl. ..., ELI). ABl.: Bitte in den Text die Nummer der in 2025/0223(COD) enthaltenen Verordnung (Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates über das Katastrophenschutzverfahren der Union und die Unterstützung der Union für die Krisenvorsorge und -reaktion bei gesundheitlichen Notlagen sowie zur Aufhebung des Beschlusses Nr. 1313/2013/EU (Katastrophenschutzverfahren der Union)) einfügen und in der Fußnote die Nummer, das Datum, den Titel und die Fundstelle im Amtsblatt dieser Verordnung einsetzen.

<a id="art-59b"></a>
### Artikel 59b

Reallabore auf nationaler Ebene

  - (1) Die Mitgliedstaaten können von sich aus oder auf begründeten Antrag eines Herstellers oder eines künftigen Herstellers ein oder mehrere Reallabore einrichten, für die die Anwendung bestimmter Anforderungen der Kapitel V oder VI oder der Anhänge I, VIII, IX, X, XI, XIV oder XV nicht zweckmäßig wäre. Die Mitgliedstaaten benennen die zuständige Behörde, die für die Beaufsichtigung des Reallabors verantwortlich ist.

      Die Mitgliedstaaten können Reallabore auch gemeinsam mit anderen Mitgliedstaaten einrichten.

  - (2) Die Tätigkeiten innerhalb eines Reallabors erfolgen gemäß einem spezifischen Reallabor-Plan, in dem klar die in Absatz 1 genannten Anforderungen dieser Verordnung benannt werden, die im Reallabor abweichend von dieser Verordnung vorübergehend angepasst werden oder von deren Anwendung vorübergehend abgesehen wird, und der eine Begründung, warum die Anwendung dieser Anforderungen als nicht zweckmäßig angesehen wird, sowie eine Erläuterung, wie potenzielle Risiken im Zusammenhang mit der Anpassung oder dem Absehen von der Anwendung kontrolliert und gemindert werden, enthält. Im Plan werden außerdem die angemessene Dauer des Reallabors, die zur Erreichung seiner Ziele erforderlich ist, sowie die Teilnehmer des Reallabors und ihre jeweiligen Funktionen angegeben.

  - (3) Ein Reallabor wird nur dann eingerichtet, wenn die folgenden Bedingungen erfüllt sind:

    - a) Es ist davon auszugehen, dass das Produkt eine medizinische Versorgungslücke schließt oder im Vergleich zu ähnlichen bestehenden Alternativen oder dem Stand der Technik einen erheblichen klinischen Nutzen für die Patienten oder für das Gesundheitssystem bietet.

    - b) Die Anwendung der in Absatz 1 genannten Anforderungen dieser Verordnung würde die Entwicklung des Produkts sowie den Zugang von Angehörigen der Gesundheitsberufe oder von Laienanwendern zu diesem Produkt behindern oder erheblich verzögern.

  - (4) Der Mitgliedstaat kann ein Expertengremium gemäß Artikel 106 ersuchen, wissenschaftliche, technische oder regulatorische Beratung zum Entwurf des Reallabor-Plans zu leisten.

  - (5) Jeder Teilnehmer des Reallabors unterrichtet unverzüglich die für die Beaufsichtigung des Reallabors zuständige Behörde über jeden Schaden, der im Zusammenhang mit der Durchführung des Reallabors eingetreten ist. Die zuständige Behörde ergreift unverzüglich geeignete Korrekturmaßnahmen, einschließlich der Aussetzung oder des Widerrufs des Reallabors oder der Beschränkung seines Anwendungsbereichs.

  - (6) Hersteller und künftige Hersteller, die an einem Reallabor teilnehmen, bleiben nach dem anwendbaren Unionsrecht und nationalen Recht für jeden Schaden haftbar, der Dritten infolge ihrer im Reallabor stattfindenden Tätigkeiten zugefügt wird.

  - (7) Der Mitgliedstaat unterrichtet die Kommission und die Koordinierungsgruppe Medizinprodukte über die Einrichtung eines Reallabors und hält sie über dessen Durchführung und Ergebnisse auf dem Laufenden.

**Artikel 59c**

Reallabore der Union

  - (1) Die Kommission kann von sich aus oder auf begründeten Antrag eines Mitgliedstaats im Wege von Durchführungsrechtsakten für einen begrenzten Zeitraum und nach Maßgabe eines spezifischen Plans Reallabore der Union einrichten, die Aufschluss darüber geben, ob die bestehenden Anforderungen einen bestimmten Produkttyp mit besonderen Merkmalen oder aufkommenden Technologien angemessen regulieren, und ob die Gefahr besteht, dass die bestehenden Anforderungen:

    - a) die Entwicklung solcher Produkte sowie den Zugang von Angehörigen der Gesundheitsberufe oder von Laienanwendern zu diesen Produkten behindern oder erheblich verzögern würden oder

    - b) den Schutz der Gesundheit und Sicherheit von Patienten, Anwendern oder anderen Personen oder andere Aspekte der öffentlichen Gesundheit nicht angemessen gewährleisten würden.

      Reallabore der Union dürfen nicht das Inverkehrbringen oder die Inbetriebnahme von Produkten umfassen, die dieser Verordnung nicht entsprechen.

  - (2) Die Kommission ersucht ein Expertengremium gemäß Artikel 106, wissenschaftliche, technische oder regulatorische Beratung bei der Konzeption eines Reallabors der Union zu leisten.

  - (3) Die Kommission unterrichtet die Koordinierungsgruppe Medizinprodukte über die Einrichtung eines Reallabors und hält sie über dessen Ergebnisse auf dem Laufenden.

  - (4) Die Kommission kann im Wege von Durchführungsrechtsakten einheitliche Grundsätze oder genaue Regelungen für die Einrichtung, den Betrieb und die Beaufsichtigung von Reallaboren gemäß Artikel 59b oder von Reallaboren der Union gemäß diesem Artikel festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

  - (5) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um diesen Artikel oder Artikel 59b zu ändern, um ihn an den wissenschaftlichen, technischen oder regulatorischen Fortschritt anzupassen und um Entwicklungen im Zusammenhang mit Reallaboren , auch in Bereichen außerhalb der Medizinprodukte, zu berücksichtigen.“

- 51. In Artikel 60 werden die folgenden Absätze 1a und 1b angefügt:

  - „(1a) Die in Artikel 22 Absatz 1 oder 3 genannte Person kann bei der zuständigen Behörde des Mitgliedstaats, in dem sie niedergelassen ist, beantragen, dass diese für ein System oder eine Behandlungseinheit, für das bzw. die sie gemäß Artikel 22 eine Erklärung abgegeben hat, ein Freiverkaufszertifikat ausstellt.

  - (1b) Die zuständige Behörde macht die gemäß den Absätzen 1 und 1a ausgestellten Freiverkaufszertifikate in Eudamed öffentlich zugänglich.“

- 52. Artikel 61 wird wie folgt geändert:

  - a) Die Absätze 1 und 2 erhalten folgende Fassung:

    - „(1) Von den Herstellern ist eine klinische Bewertung gemäß diesem Artikel sowie Anhang XIV Teil A zu planen, durchzuführen und zu dokumentieren, um die Sicherheit und Leistung des Produkts unter normalen Verwendungsbedingungen entsprechend der Zweckbestimmung des Produkts zu bestätigen, und es sind etwaige unerwünschte Nebenwirkungen sowie die Vertretbarkeit des in Anhang I Abschnitte 1 und 8 genannten Nutzen-Risiko-Verhältnisses von ihnen zu beurteilen.

        Der Hersteller legt den zur Bestätigung der Sicherheit und Leistung des Produkts erforderlichen Umfang der klinischen Nachweise fest und begründet diesen. Der Umfang der klinischen Nachweise muss in Anbetracht der Merkmale des Produkts und seiner Zweckbestimmung sowie unter Berücksichtigung von Absatz 10 angemessen sein.

        Die klinische Bewertung, ihre Ergebnisse und der daraus abgeleitete klinische Nachweis werden in einem Bericht über die klinische Bewertung gemäß Anhang XIV Abschnitt 4 festgehalten, der, außer bei Sonderanfertigungen, Teil der technischen Dokumentation gemäß Anhang II für das betreffende Produkt ist.

    - (2) Für Produkte der Klasse IIb und Klasse III kann ein Hersteller vor seiner klinischen Prüfung oder klinischen Bewertung ein Expertengremium gemäß Artikel 106 konsultieren, mit dem Ziel, die vom Hersteller beabsichtigte klinische Entwicklungsstrategie oder Vorschläge für die klinische Prüfung überprüfen zu lassen. Der Hersteller und die an einem künftigen Konformitätsbewertungsverfahren mitwirkende Benannte Stelle tragen im Leistungsbewertungsbericht und im Bericht der Begutachtung der Leistungsbewertung der Stellungnahme des Expertengremiums gebührend Rechnung; folgen sie dieser Stellungnahme nicht, müssen sie dies hinreichend begründen.“

  - b) In Absatz 4 Unterabsatz 1 erhalten die einleitenden Worte folgende Fassung:

      „Bei implantierbaren Produkten der Klasse IIb und Produkten der Klasse III, ausgenommen Sonderanfertigungen, werden klinische Prüfungen durchgeführt, es sei denn:“

  - c) Absatz 5 erhält folgende Fassung:

    - „(5) Ein Hersteller eines Produkts, das nachweislich einem bereits in Verkehr gebrachten nicht von ihm hergestellten Produkt gleichartig ist, kann sich ebenfalls auf Absatz 4 stützen, um keine klinische Prüfung durchführen zu müssen, sofern die ursprüngliche klinische Bewertung in Übereinstimmung mit den Anforderungen dieser Verordnung durchgeführt wurde und der Hersteller der Benannten Stelle hierfür eindeutige Nachweise vorlegt.“

  - d) Absatz 6 wird wie folgt geändert:

    - i) Die einleitenden Worte erhalten folgende Fassung:

        „Die Anforderung, klinische Prüfungen gemäß Absatz 4 durchzuführen, gilt nicht für implantierbare Produkte der Klasse IIb und Produkte der Klasse III,“

    - ii) Buchstabe b erhält folgende Fassung:

      - „b) bei denen es sich um Produkte mit bewährter Technologie handelt, für die die klinische Bewertung auf ausreichenden klinischen Nachweisen beruht und mit den einschlägigen produktspezifischen GS, sofern solche GS verfügbar sind, im Einklang steht.“

  - e) Absatz 8 wird gestrichen.

  - f) Die Absätze 10 und 11 erhalten folgende Fassung:

    - „(10) Unbeschadet des Absatzes 4 ist, wenn eine Bestätigung der Sicherheit und Leistung auf der Grundlage klinischer Daten als nicht zweckmäßig erachtet wird, eine angemessene Begründung vorzulegen, die auf den Ergebnissen des Risikomanagements des Herstellers beruht und die Besonderheiten der Wechselwirkung zwischen dem Produkt und dem menschlichen Körper, die beabsichtigte klinische Leistung sowie die Angaben des Herstellers und die für die generische Produktgruppe verfügbaren Daten berücksichtigt. In einem solchen Fall begründet der Hersteller in der in Anhang II genannten technischen Dokumentation ordnungsgemäß, warum er einen Nachweis der Konformität mit den grundlegenden Sicherheits- und Leistungsanforderungen, der ausschließlich auf den Ergebnissen nichtklinischer Prüfmethoden beruht, als ausreichend erachtet; hierzu zählen insbesondere Leistungsbewertung, technische Prüfung („bench testing“), In-vitro-, Ex-vivo- und In-silico-Prüfungen, rechnergestützte Modellierungen oder Simulationen sowie vorklinische Bewertungen.

    - (11) Die klinische Bewertung, ihre Dokumentation und gegebenenfalls soweit erforderlich der in Artikel 32 genannte Kurzbericht über Sicherheit und Leistung sind während des gesamten Lebenszyklus des betreffenden Produkts mit den Daten und Erkenntnissen zu aktualisieren, die aus der Durchführung des Plans der klinischen Nachbeobachtung nach dem Inverkehrbringen des Herstellers gemäß Anhang XIV Teil B sowie aus dem Plan für die Überwachung nach dem Inverkehrbringen gemäß Artikel 84 gewonnen werden, sofern diese im Rahmen der klinischen Nachbeobachtung nach dem Inverkehrbringen gewonnenen Daten und Erkenntnisse für die Bestätigung der Sicherheit und Leistung des Produkts relevant sind.“

  - g) Absatz 12 wird gestrichen.

  - h) Folgender Absatz 14 wird angefügt:

    - „(14) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um Anhang XIV zu ändern, um ihn an den technischen und wissenschaftlichen Fortschritt sowie an Entwicklungen auf internationaler Ebene anzupassen, wobei dem Schutz der Gesundheit und Sicherheit von Patienten, Anwendern oder anderen Personen sowie anderen Aspekten der öffentlichen Gesundheit gebührend Rechnung zu tragen ist.“

- 53. in Artikel 62 Absatz 1 erhalten die einleitenden Worte folgende Fassung:

    „Bei klinischen Prüfungen haben Konzeption, Genehmigung, Durchführung, Aufzeichnung und Berichterstattung gemäß den Bestimmungen dieses Artikels, der Artikel 63 bis 73 sowie der Artikel 75 bis 80, den gemäß Artikel 81 erlassenen Rechtsakten und Anhang XV zu erfolgen, sofern sie zur Bewertung eines Prüfprodukts durchgeführt werden, das nicht gemäß dieser Verordnung in Verkehr gebracht oder in Betrieb genommen wurde, und sofern sie zu einem oder mehreren der folgenden Zwecke durchgeführt werden:“

- 54. Artikel 64 Absatz 1 Buchstabe g erhält folgende Fassung:

  - „g) es gibt wissenschaftliche Gründe für die Annahme, dass die Teilnahme an der klinischen Prüfung zu einem der folgenden Ergebnisse führen wird:

    - i) einem unmittelbaren Nutzen für den nicht einwilligungsfähigen Prüfungsteilnehmer, der die damit verbundenen Risiken und Belastungen überwiegt;

    - ii) einem Nutzen für die durch den nicht einwilligungsfähigen Prüfungsteilnehmer vertretene Population, sofern die klinische Prüfung im Vergleich zur Standardbehandlung der Erkrankung des Prüfungsteilnehmers für diesen nur ein minimales Risiko birgt und ihn nur minimal belastet.“

- 55. Artikel 65 Buchstabe g erhält folgende Fassung:

  - „g) es gibt wissenschaftliche Gründe für die Annahme, dass die Teilnahme an der klinischen Prüfung zu einem der folgenden Ergebnisse führen wird:

    - i) einem unmittelbaren Nutzen für den minderjährigen Prüfungsteilnehmer, der die damit verbundenen Risiken und Belastungen überwiegt;

    - ii) einem Nutzen für die durch den minderjährigen Prüfungsteilnehmer vertretene Population, sofern die klinische Prüfung im Vergleich zur Standardbehandlung der Erkrankung des Prüfungsteilnehmers für diesen nur ein minimales Risiko birgt und ihn nur minimal belastet.“

- 56. Artikel 66 Buchstabe a erhält folgende Fassung:

  - „a) Die klinische Prüfung hat möglicherweise einen unmittelbaren Nutzen für die betroffene schwangere oder stillende Frau oder für ihren Embryo, Fötus oder ihr Kind nach der Geburt, der die damit verbundenen Risiken und Belastungen überwiegt, oder, wenn die klinische Prüfung keinen solchen unmittelbaren Nutzen hat, dann sind die folgenden Bedingungen erfüllt:

    - i) Durch eine klinische Prüfung mit Frauen, die nicht schwanger sind oder nicht stillen, können keine vergleichbaren Ergebnisse gewonnen werden.

    - ii) Die klinische Prüfung trägt dazu bei, Ergebnisse zu gewinnen, die entweder für schwangere Frauen, stillende Frauen, für andere Frauen im Hinblick auf die Fortpflanzung oder für andere Embryonen, Föten oder Kinder von Nutzen sein können.

    - iii) Die klinische Prüfung birgt für die betroffene schwangere oder stillende Frau, den Embryo, den Fötus oder das Kind nach der Geburt nur ein minimales Risiko und stellt für sie nur eine minimale Belastung dar.“

- 57. Artikel 68 Absatz 1 Buchstabe b erhält folgende Fassung:

  - „b) es gibt wissenschaftliche Gründe für die Annahme, dass die Teilnahme des Prüfungsteilnehmers an der klinischen Prüfung möglicherweise eines der folgenden Ergebnisse erzielen kann:

    - i) einen direkten, klinisch relevanten Nutzen für den Prüfungsteilnehmer, der zu einer messbaren gesundheitsbezogenen Verbesserung führt, indem das Leiden gelindert und/oder der Gesundheitszustand des Prüfungsteilnehmers verbessert wird, oder zur Diagnose seines Zustands beiträgt;

    - ii) einen Nutzen für die durch den Prüfungsteilnehmer vertretene Population, sofern die klinische Prüfung im Vergleich zur Standardbehandlung der Erkrankung des Prüfungsteilnehmers für diesen nur ein minimales Risiko birgt und ihn nur minimal belastet.“

- 58. In Artikel 72 wird folgender Absatz 7 angefügt:

  - „(7) Die Verarbeitung personenbezogener Daten im Zusammenhang mit einer klinischen Prüfung, einschließlich der Sekundärnutzung personenbezogener Daten, die ursprünglich für andere Prüfungen erhoben wurden, gilt als zu wissenschaftlichen Forschungszwecken im Sinne des Artikels 9 Absatz 2 Buchstabe j der Verordnung (EU) 2016/679 durchgeführt.“

- 59. Artikel 74 Absatz 1 erhält folgende Fassung:

  - „(1) Wird eine klinische Prüfung durchgeführt, die der weitergehenden Bewertung eines Produkts, das bereits die CE-Kennzeichnung gemäß Artikel 20 Absatz 1 trägt, im Rahmen seiner Zweckbestimmung und in Übereinstimmung mit dem Plan für die klinische Nachbeobachtung nach dem Inverkehrbringen dient (im Folgenden „klinische Prüfung nach dem Inverkehrbringen“), und werden im Rahmen dieser Prüfung Prüfungsteilnehmer zusätzlichen Verfahren zu den bei normalen Verwendungsbedingungen des Produkts durchgeführten Verfahren unterzogen, und sind diese zusätzlichen Verfahren invasiv oder belastend, so unterrichtet der Sponsor die betreffenden Mitgliedstaaten mindestens 30 Tage vor Beginn der Prüfung über das elektronische System gemäß Artikel 73. Der Sponsor übermittelt die Unterlagen gemäß Anhang XV Kapitel II Abschnitte 1, 3 und 4 als Teil der Mitteilung. Artikel 62 Absatz 4 Buchstaben b bis k und m, Artikel 75 Absatz 1, Artikel 76 und 77, Artikel 80 Absätze 5 und 6 sowie die einschlägigen Bestimmungen des Anhangs XV finden auf klinische Prüfungen nach dem Inverkehrbringen Anwendung, die zusätzliche invasive oder belastende Verfahren beinhalten.

- 60. Artikel 75 wird wie folgt geändert:

  - a) Absatz 1 Satz 1 erhält folgende Fassung:

      „Hat ein Sponsor die Absicht, Änderungen an einer klinischen Prüfung vorzunehmen, die wahrscheinlich wesentliche Auswirkungen auf die Sicherheit, die Gesundheit oder die Rechte der Prüfungsteilnehmer oder die Belastbarkeit oder Zuverlässigkeit der im Rahmen der Prüfung gewonnenen klinischen Daten haben, teilt er dem bzw. den Mitgliedstaat(en), in dem bzw. denen die klinische Prüfung durchgeführt wird oder werden soll, die Gründe für die Änderungen und deren Art über das elektronische System gemäß Artikel 73 mit.“

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Wurde die klinische Prüfung gemäß Artikel 62 Absatz 4 Buchstabe a genehmigt, so bewertet der Mitgliedstaat jede wesentliche Änderung der klinischen Prüfung nach dem in Artikel 71 festgelegten Verfahren.“

  - c) In Absatz 3 erhalten die einleitenden Worte folgende Fassung:

      „Der Sponsor kann die in Absatz 1 genannten Änderungen umsetzen, sobald der betreffende Mitgliedstaat den Sponsor über seine Genehmigung unterrichtet hat oder, sofern keine Genehmigung erforderlich ist, frühestens 38 Tage nach der in dem genannten Absatz vorgesehenen Mitteilung des Sponsors, es sei denn,“

- 61. Artikel 78 wird wie folgt geändert:

  - a) Absatz 4 Unterabsatz 2 erhält folgende Fassung:

      „Der abschließende Bewertungsbericht wird von allen betroffenen Mitgliedstaaten bei ihrer Entscheidung über den Antrag des Sponsors gemäß Absatz 11 berücksichtigt.“

  - b) Absatz 5 erhält folgende Fassung:

    - „(5) Jeder betroffene Mitgliedstaat kann einmalig zusätzliche Informationen vom Sponsor anfordern. Der Sponsor übermittelt die angeforderten zusätzlichen Informationen innerhalb von 12 Tagen nach Eingang der Anforderung. Der Ablauf der letzten Frist gemäß Absatz 4 Buchstabe d ist vom Tag der Anforderung bis zum Eingang der zusätzlichen Informationen ausgesetzt.“

  - c) in Absatz 6 wird die Angabe „50 Tage“ durch die Angabe „20 Tage“ ersetzt“

  - d) Folgender Absatz 15 wird angefügt:

    - „(15) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um diesen Artikel unter Berücksichtigung der bei der praktischen Anwendung des koordinierten Bewertungsverfahrens gewonnenen Erfahrungen zu ändern, insbesondere in Bezug auf Fristen und die Genehmigung klinischer Prüfungen, die einer koordinierten Bewertung unterliegen.“

- 62. Artikel 79 wird gestrichen;

- 63. Folgender Artikel 79a wird eingefügt:

**„Artikel 79a**

Klinische Prüfungen in kombinierten Studien

    Klinische Prüfungen, die Teil kombinierter Studien sind und die gemäß Artikel 62 genehmigungspflichtig sind, können gemäß Artikel 14c der Verordnung (EU) Nr. 536/2014 durchgeführt werden.

    Entscheidet sich der Sponsor für die Anwendung des Artikels 14c der Verordnung (EU) Nr. 536/2014, so gelten die darin sowie in gemäß dem genannten Artikel erlassenen Durchführungsrechtsakten oder delegierten Rechtsakten festgelegten Anforderungen anstelle der entsprechenden in der vorliegenden Verordnung festgelegten Anforderungen.“

- 64. Artikel 82 wird gestrichen;

- 65. Artikel 83 Absatz 4 Satz 1 erhält folgende Fassung:

    „Zeigt sich im Verlauf der Überwachung nach dem Inverkehrbringen, dass Präventiv- oder Korrekturmaßnahmen oder beides erforderlich sind, so ergreift der Hersteller die geeigneten Maßnahmen. Die zuständigen Behörden können vom Hersteller verlangen, sie darüber zu unterrichten, wann solche Präventiv- oder Korrekturmaßnahmen ergriffen werden, um ein Risiko zu verringern, das die Sicherheit oder die Leistung des Produkts beeinträchtigen kann.“

- 66. Artikel 84 Satz 2 wird gestrichen.

- 67. Artikel 86 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) Unterabsatz 1 Satz 1 erhält folgende Fassung:

        „Hersteller von Produkten der Klassen IIa, IIb und III, mit Ausnahme von Sonderanfertigungen, erstellen für jedes Produkt oder gegebenenfalls für jede Produktkategorie oder Produktgruppe einen regelmäßig aktualisierten Bericht über die Sicherheit (im Folgenden „Sicherheitsbericht“), der eine Zusammenfassung der Ergebnisse und Schlussfolgerungen der Analysen der aufgrund des Plans zur Überwachung nach dem Inverkehrbringen gemäß Artikel 84 gesammelten Daten über die Überwachung nach dem Inverkehrbringen zusammen mit einer Beschreibung etwaiger ergriffener Präventiv- und Korrekturmaßnahmen, einschließlich ihrer Begründung, enthält.“

    - ii) Die Unterabsätze 2 und 3 erhalten folgende Fassung:

        „Hersteller von Produkten der Klassen IIb und III aktualisieren den Sicherheitsbericht im ersten Jahr nach Ausstellung der Bescheinigung und danach alle zwei Jahre oder wenn sich die Nutzen-Risiko-Abwägung oder die Vertretbarkeit unerwünschter Nebenwirkungen wesentlich ändert. Der Sicherheitsbericht ist Teil der technischen Dokumentation gemäß Anhang III.

        Hersteller von Produkten der Klasse IIa aktualisieren den Sicherheitsbericht bei Bedarf. Die Sicherheitsberichte sind Teil der technischen Dokumentation gemäß Anhang III. “

    - iii) Unterabsatz 4 wird gestrichen.

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Für Produkte der Klasse III oder implantierbare Produkte der Klasse IIb, mit Ausnahme von Produkten mit bewährter Technologie, überprüft die Benannte Stelle den Sicherheitsbericht im Rahmen der Überwachungsbewertung. Der Hersteller und die Benannte Stelle stellen diese Sicherheitsberichte sowie die Bewertung durch die Benannte Stelle den zuständigen Behörden über das elektronische System gemäß Artikel 92 zur Verfügung.“

- 68. Artikel 87 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) Unterabsatz 1 Buchstabe a erhält folgende Fassung:

      - „a) Jedes schwerwiegende Vorkommnis im Zusammenhang mit Produkten, die auf dem Unionsmarkt bereitgestellt werden, außer erwartete unerwünschte Nebenwirkungen, die in den Produktinformationen eindeutig dokumentiert, in der technischen Dokumentation quantifiziert und Gegenstand der Meldung von Trends gemäß Artikel 88 sind;“

    - ii) Unterabsatz 2 erhält folgende Fassung:

        “Die in Unterabsatz 1 genannten Meldungen werden unverzüglich über das elektronische System gemäß Artikel 92 übermittelt.“

  - b) Absatz 3 erhält folgende Fassung:

      „(3) Die Hersteller melden jedes schwerwiegende Vorkommnis gemäß Absatz 1 Unterabsatz 1 Buchstabe a unverzüglich, nachdem sie einen Kausalzusammenhang oder einen durchaus möglichen Kausalzusammenhang zwischen dem Vorkommnis und ihrem Produkt festgestellt haben, und spätestens 30 Tage, nachdem sie von dem Vorkommnis Kenntnis erlangt haben.“

- 69. Folgender Artikel 87a wird eingefügt:

**„Artikel 87a**

Meldung aktiv ausgenutzter Schwachstellen und schwerwiegender Sicherheitsvorfälle im Zusammenhang mit Produkten

  - (1) Unbeschadet der Meldepflichten in Bezug auf schwerwiegende Vorkommnisse und Sicherheitskorrekturmaßnahmen im Feld gemäß Artikel 87 meldet der Hersteller eines Produkts den als Koordinatoren der Mitgliedstaaten, in denen ein Produkt bereitgestellt wurde, benannten Computer-Notfallteams (im Folgenden „CSIRTs“) sowie der Europäischen Agentur der Europäischen Union für Cybersicherheit (ENISA) jedes der folgenden Ereignisse:

    - a) jede im Produkt vorliegende aktiv ausgenutzte Schwachstelle im Sinne des Artikels 3 Nummer 42 der Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates*******;

    - b) jeden schwerwiegenden Sicherheitsvorfall gemäß Artikel 14 Absatz 5 der Verordnung (EU) 2024/2847 mit Auswirkungen auf die Sicherheit des Produkts.

  - (2) Der Hersteller übermittelt die Meldung gemäß Absatz 1 über das elektronische System gemäß Artikel 92 spätestens 30 Tage, nachdem er von der aktiv ausgenutzten Schwachstelle oder dem schwerwiegenden Sicherheitsvorfall Kenntnis erlangt hat.

  - (3) Die in Absatz 1 genannte Meldung sowie jede von einem Hersteller gemäß Artikel 87 übermittelte Meldung, deren Gegenstand ebenfalls als aktiv ausgenutzte Schwachstelle oder als schwerwiegender Sicherheitsvorfall einzustufen ist, werden gleichzeitig den als Koordinatoren der Mitgliedstaaten, in denen ein Produkt bereitgestellt wurde, benannten CSIRTs und der ENISA zugänglich gemacht.

  - (4) Für die Zwecke dieses Artikels haben die als Koordinatoren benannten CSIRTs und die ENISA Zugang zu Eudamed.“

  - _______________

  - ******* Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates vom 23. Oktober 2024 über horizontale Cybersicherheitsanforderungen für Produkte mit digitalen Elementen und zur Änderung der Verordnungen (EU) Nr. 168/2013 und (EU) 2019/1020 und der Richtlinie (EU) 2020/1828 (Cyberresilienz-Verordnung) (ABl. L, 2024/2847, 20.11.2024, ELI: http://data.europa.eu/eli/reg/2024/2847/oj).“

- 70. Artikel 88 Absatz 1 Satz 1 erhält folgende Fassung:

    „Hersteller melden über das elektronische System gemäß Artikel 92 jede statistisch signifikante Zunahme der Häufigkeit oder des Schweregrads von Vorkommnissen, die keine schwerwiegenden Vorkommnisse sind oder erwartete unerwünschte Nebenwirkungen darstellen, die erhebliche Auswirkungen auf die in Anhang I Abschnitte 1 und 8 genannte Nutzen-Risiko-Analyse haben könnten.“

- 71. Artikel 89 wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 2 erhält folgende Fassung:

      „Der Hersteller arbeitet bei den Untersuchungen gemäß Unterabsatz 1 mit den zuständigen Behörden zusammen und nimmt keine Untersuchung vor, die zu einer Veränderung des Produkts oder einer Probe der betroffenen Charge in einer Weise führen, die Auswirkungen auf eine spätere Bewertung der Ursachen des Vorkommnisses haben kann, bevor er die zuständigen Behörden über eine solche Maßnahme unterrichtet hat.“

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Die Mitgliedstaaten unternehmen die notwendigen Schritte, um sicherzustellen, dass alle Informationen im Zusammenhang mit einem schwerwiegenden Vorkommnis, das in ihrem Hoheitsgebiet aufgetreten ist, oder einer Sicherheitskorrekturmaßnahme im Feld, die in ihrem Hoheitsgebiet ergriffen wurde oder ergriffen werden soll, von denen sie gemäß Artikel 87 Kenntnis erhalten haben, von ihrer zuständigen Behörde auf nationaler Ebene zentral bewertet werden, und zwar nach Möglichkeit in Zusammenarbeit mit dem Hersteller.“

  - c) Folgender Absatz 3a wird eingefügt:

    - „(3a) Die zuständige Behörde kann die Benannte Stelle, die gemäß Artikel 56 eine Bescheinigung für das betreffende Produkt ausgestellt hat, ersuchen, bei der Bewertung einer Korrekturmaßnahme im Zusammenhang mit einem schwerwiegenden Vorkommnis oder einer Sicherheitskorrekturmaßnahme im Feld Unterstützung zu leisten.“

  - d) Absatz 6 erhält folgende Fassung:

      „(6) Sind Produkte gemäß Artikel 1 Absatz 8 Unterabsatz 1 betroffen und bestätigt der Hersteller, dass das schwerwiegende Vorkommnis oder die Sicherheitskorrekturmaßnahme im Feld mit einem Stoff zusammenhängt, der bei alleiniger Verwendung als Arzneimittel gelten würde, so unterrichtet die bewertende zuständige Behörde oder die in Absatz 9 genannte koordinierende zuständige Behörde die nationale zuständige Behörde oder die EMA, die die wissenschaftliche Stellungnahme gemäß Artikel 52 Absatz 9 zu diesem Stoff abgegeben hat, über dieses schwerwiegende Vorkommnis oder diese Sicherheitskorrekturmaßnahme im Feld.

      Bei Produkten, die gemäß Artikel 1 Absatz 6 Buchstabe g oder gemäß Artikel 1 Absatz 10 in den Anwendungsbereich dieser Verordnung fallen, unterrichtet die zuständige Behörde oder die in Absatz 9 dieses Artikels genannte koordinierende zuständige Behörde die für Substanzen menschlichen Ursprungs zuständige Behörde, die von der Benannten Stelle gemäß Artikel 52 Absatz 10 konsultiert wurde, sofern der Hersteller bestätigt, dass das schwerwiegende Vorkommnis oder die Sicherheitskorrekturmaßnahme im Feld mit den für die Herstellung des Produkts verwendeten Derivaten von Substanzen menschlichen Ursprungs oder mit nicht lebensfähigen Substanzen menschlichen Ursprungs oder deren Derivaten zusammenhängt, denen im Rahmen des Produkts eine unterstützende Funktion zukommt.“

  - e) Absatz 7 erhält folgende Fassung:

    - „(7) Stellt die bewertende zuständige Behörde nach Durchführung der Bewertung gemäß Absatz 3 dieses Artikels fest, dass zusätzliche Korrekturmaßnahmen des Herstellers erforderlich sind, um das Risiko eines erneuten Auftretens des schwerwiegenden Vorkommnisses zu minimieren, so unterrichtet sie über das elektronische System gemäß Artikel 92 unverzüglich die anderen zuständigen Behörden über die vom Hersteller ergriffenen oder geplanten oder von ihm verlangten Korrekturmaßnahmen zur Minimierung des Risikos eines erneuten Auftretens des schwerwiegenden Vorkommnisses, einschließlich Informationen zu den zugrunde liegenden Ereignissen und zum Ergebnis ihrer Bewertung.“

  - f) In Absatz 9 erhalten die einleitenden Worte folgende Fassung:

      „Die zuständigen Behörden beteiligen sich aktiv an einem Verfahren zur Koordinierung ihrer in Absatz 3 genannten Bewertungen, sobald eine solche Koordinierung erforderlich ist, um ein hohes Schutzniveau für die Gesundheit und Sicherheit von Patienten, Anwendern und anderen Personen oder den Schutz der öffentlichen Gesundheit in der gesamten Union zu gewährleisten, insbesondere in den folgenden Fällen:“

- 72. Artikel 91 Unterabsatz 1 wird wie folgt geändert:

  - a) Die einleitenden Worte erhalten folgende Fassung:

      „Die Kommission kann im Wege von Durchführungsrechtsakten nach Anhörung der Koordinierungsgruppe Medizinprodukte die zur Umsetzung der Artikel 84 bis 90 und Artikel 92 notwendigen genauen Regelungen und Verfahrensaspekte in Bezug auf folgende Elemente festlegen:“

  - b) Buchstabe b erhält folgende Fassung:

    - „b) Meldung von schwerwiegenden Vorkommnissen, Sicherheitskorrekturmaßnahmen im Feld und Sicherheitsanweisungen im Feld sowie Vorlage und Inhalt des Plans zur Überwachung nach dem Inverkehrbringen, der periodischen Sammelmeldungen, der Berichte zur Überwachung nach dem Inverkehrbringen, der Sicherheitsberichte und der Trendmeldungen durch die Hersteller gemäß den Artikeln 84, 85, 86, 87, 88 bzw. 89;“

- 73. In Artikel 92 Absatz 2 wird der Verweis auf „Artikel 53“ ersetzt durch „Absatz 56“

- 74. Artikel 93 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Die zuständigen Behörden führen geeignete Kontrollen der Konformitätsmerkmale und der Leistung von Produkten sowie der Einhaltung der in dieser Verordnung festgelegten Pflichten durch die Wirtschaftsakteure durch; hierzu gehören gegebenenfalls eine Überprüfung der Unterlagen sowie physische oder Laboruntersuchungen auf der Grundlage angemessener Stichproben. Die zuständigen Behörden berücksichtigen insbesondere die etablierten Grundsätze in Bezug auf Risikobewertungen und Risikomanagement, Vigilanz-Daten und Beschwerden.“

  - b) Folgender Absatz 1a wird eingefügt:

    - „(1a) Die Mitgliedstaaten sorgen dafür, dass ihre zuständigen nationalen Behörden mit angemessenen und ausreichenden technischen und finanziellen Mitteln sowie geeignetem Personal und Infrastrukturen ausgestattet werden, damit sie ihre Aufgaben im Rahmen dieser Verordnung wirksam erfüllen können.“

  - c) Absatz 2 erhält folgende Fassung:

    - „(2) Die zuständigen Behörden erstellen Jahrespläne für die Überwachungstätigkeiten unter Berücksichtigung des von der Koordinierungsgruppe Medizinprodukte auszuarbeitenden und zu pflegenden europäischen Marktüberwachungsprogramms sowie der lokalen Gegebenheiten.“

  - d) Folgender Absatz 12 wird hinzugefügt:

    - „(12) In Bezug auf Produkte, bei denen es sich um Hochrisiko-KI-Systeme im Sinne von Artikel 6 Absatz 1 der Verordnung (EU) 2024/1689 handelt, arbeiten die zuständigen Behörden mit den gemäß Artikel 70 der Verordnung (EU) 2024/1689 benannten Marktüberwachungsbehörden ihres Mitgliedstaats zusammen.“

- 75. Artikel 94 erhält folgende Fassung:

**„Artikel 94**

Bewertung von Produkten, die mutmaßlich ein unannehmbares Risiko darstellen oder anderweitig nicht konform sind

    Die zuständigen Behörden eines Mitgliedstaats führen allein oder in Zusammenarbeit mit den zuständigen Behörden anderer Mitgliedstaaten eine Bewertung eines Produkts oder eines Wirtschaftsakteurs durch, die alle einschlägigen in dieser Verordnung festgelegten Anforderungen im Zusammenhang mit dem vom Produkt ausgehenden Risiko oder mit einer sonstigen Nichtkonformitäten des Produkts oder des Wirtschaftsakteurs erfasst, wenn sie auf der Grundlage von im Rahmen der Vigilanz- oder Marktüberwachungstätigkeiten gewonnenen Daten oder anderer Informationen Grund zu der Annahme haben, dass einer der folgenden Fälle vorliegt:

  - a) Das Produkt kann ein unannehmbares Risiko für die Gesundheit oder Sicherheit der Patienten, Anwender oder anderer Personen oder für andere Aspekte des Schutzes der öffentlichen Gesundheit darstellen.

  - b) Das Produkt oder der betreffende Wirtschaftsakteur erfüllt anderweitig nicht die in dieser Verordnung niedergelegten Anforderungen.

    Die betroffenen Wirtschaftsakteure und auf Verlangen gegebenenfalls die Benannte Stelle, die für das betreffende Produkt eine Bescheinigung ausgestellt hat, arbeiten mit den zuständigen Behörden zusammen.

    Die zuständigen Behörden der Mitgliedstaaten können von jedem Wirtschaftsakteur oder jeder Benannten Stelle verlangen, die jeweils verfügbare Dokumentation vorzulegen, sofern der Zugang zu dieser Dokumentation im Interesse der öffentlichen Gesundheit oder der Patientensicherheit oder der Gesundheit der Patienten erforderlich ist.“

- 76. Artikel 95 wird wie folgt geändert:

  - a) Absatz 3 erhält folgende Fassung:

    - „(3) Die in Absatz 1 genannten Wirtschaftsakteure stellen unverzüglich sicher, dass innerhalb der in Absatz 1 genannten Frist unionsweit in Bezug auf sämtliche betroffenen Produkte, die sie auf dem Markt bereitgestellt haben, alle geeigneten Korrekturmaßnahmen ergriffen werden.“

  - b) Absatz 7 wird wie folgt geändert:

    - i) Unterabsatz 1 erhält folgende Fassung:

        „Erhebt weder ein Mitgliedstaat noch die Kommission innerhalb von zwei Monaten nach Erhalt der Mitteilung gemäß Absatz 4 einen Einwand gegen die mitgeteilten Maßnahmen eines Mitgliedstaats, so gelten diese Maßnahmen als gerechtfertigt.“

    - ii) In Unterabsatz 2 wird folgender Satz angefügt:

        „Absatz 4 gilt nicht für solche von den Mitgliedstaaten erlassenen Maßnahmen.“

- 77. Artikel 96 wird wie folgt geändert:

  - a) In Absatz 1 wird der dritte Satz gestrichen.

  - b) In Absatz 2 Unterabsatz 1 erhält der zweite Satz folgende Fassung:

      „Hält die Kommission die nationale Maßnahme für ungerechtfertigt, so zieht der betreffende Mitgliedstaat sowie jeder Mitgliedstaat, der entsprechende restriktive Maßnahmen oder Verbote ergriffen hat, diese Maßnahmen zurück.“

- 78. Artikel 97 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Stellen die zuständigen Behörden eines Mitgliedstaats nach Durchführung einer Bewertung gemäß Artikel 94 fest, dass ein Produkt oder ein Wirtschaftsakteur nicht die in dieser Verordnung niedergelegten Anforderungen erfüllt, aber kein unvertretbares Risiko für die Gesundheit oder Sicherheit der Patienten, Anwender oder anderer Personen oder in Bezug auf andere Aspekte des Schutzes der öffentlichen Gesundheit darstellt, so fordern sie den entsprechenden Wirtschaftsakteur auf, die betreffende Nichtkonformität innerhalb eines der Nichtkonformität angemessenen, eindeutig festgelegten und dem Wirtschaftsakteur mitgeteilten Zeitraums zu beheben.“

  - b) Absatz 2 Satz 1 erhält folgende Fassung:

    - „Behebt der Wirtschaftsakteur innerhalb der Frist gemäß Absatz 1 die Nichtkonformität nicht, trifft der betreffende Mitgliedstaat unverzüglich alle geeigneten Maßnahmen, um die Bereitstellung des Produkts auf dem nationalen Markt zu untersagen oder einzuschränken oder um sicherzustellen, dass das Produkt vom nationalen Markt genommen oder zurückgerufen wird.“

  - c) Folgender Absatz 2a wird eingefügt:

    - „(2a) Der Wirtschaftsakteur ergreift gemäß Absatz 1 oder 2 unionsweit in Bezug auf alle betroffenen Produkte, die er auf dem Markt bereitgestellt hat, alle geeigneten Korrekturmaßnahmen, sofern nicht eine zuständige Behörde andere geeignete Maßnahmen ergreift.“

- 79. In Artikel 98 Absatz 3 wird der vierte Satz gestrichen.

- 80. Die Überschrift des Kapitels VIII erhält folgende Fassung:

„KOOPERATION ZWISCHEN DEN MITGLIEDSTAATEN, DER KOORDINIERUNGSGRUPPE MEDIZINPRODUKTE, FACHLABORATORIEN, EXPERTENGREMIEN UND PRODUKTREGISTER, INTERESSENKONFLIKTE UND INTERNATIONALE ZUSAMMENARBEIT“

- 81. Nach der Überschrift des Kapitels VIII wird folgende Überschrift eingefügt:

„ABSCHNITT 1

Kooperation zwischen den Mitgliedstaaten, der Koordinierungsgruppe Medizinprodukte, Expertengremien, Fachlaboratorien und Produktregistern sowie Interessenkonflikte“

- 82. Artikel 101 erhält folgende Fassung:

**„Artikel 101**

Zuständige Behörden

    Die Mitgliedstaaten benennen die für die Durchführung und praktische Anwendung dieser Verordnung zuständige(n) Behörde(n). Sie stellen sicher, dass diese Behörden mit ausreichenden Befugnissen, Ressourcen, Ausrüstung und Fachkenntnissen ausgestattet werden, damit sie ihre Aufgaben gemäß dieser Verordnung wirksam und effizient wahrnehmen können. Die Mitgliedstaaten teilen der Kommission die Namen und Kontaktdaten der zuständigen Behörden mit; die Kommission veröffentlicht eine Liste der zuständigen Behörden.“

- 83. Artikel 102 Absatz 2 wird gestrichen.

- 84. Artikel 103 wird wie folgt geändert:

  - a) Absatz 2 Unterabsatz 2 Satz 2 erhält folgende Fassung:

      „Sie vertreten je nach Sachlage die zuständigen Behörden der Mitgliedstaaten sowie die für die Benannten Stellen der Mitgliedstaaten zuständigen Behörden.“

  - b) Absatz 7 erhält folgende Fassung:

    - „(7) Die Koordinierungsgruppe Medizinprodukte richtet eine Untergruppe mit Mitgliedern ein, die die für die Benannten Stellen zuständigen Behörden vertreten, und kann weitere ständige oder zeitlich befristete Untergruppen einrichten. Gegebenenfalls werden Vertreter der in Artikel 49 genannten Koordinierungsgruppe sowie von Organisationen, die die Interessen der Medizinprodukteindustrie, insbesondere der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen im Sinne der Empfehlung 2003/361/EG, von Angehörigen der Gesundheitsberufe, Laboratorien, Patienten und Verbrauchern auf Unionsebene vertreten, als Beobachter zur Koordinierungsgruppe Medizinprodukte und zu ihren Untergruppen eingeladen.“

  - c) Absatz 9 erhält folgende Fassung:

    - „(9) Die Koordinierungsgruppe Medizinprodukte nimmt die in Artikel 105 dieser Verordnung festgelegten Aufgaben wahr.“

- 85. Artikel 104 Satz 2 wird gestrichen.

- 86. Die Artikel 105 und 106 erhalten folgende Fassung:

**„Artikel 105**

Aufgaben der Koordinierungsgruppe Medizinprodukte

    Zusätzlich zu den ihr in anderen Bestimmungen dieser Verordnung und der Verordnung (EU) 2017/746 übertragenen Aufgaben unterstützt die Koordinierungsgruppe Medizinprodukte insbesondere die Kommission bei der Bewertung aller Fragen im Zusammenhang mit der Durchführung dieser Verordnungen und trägt zur Ausarbeitung von Leitlinien bei, die auf eine wirksame und einheitliche Durchführung abzielen.

<a id="art-106"></a>
### Artikel 106

Expertengremien

  - (1) Die Kommission trifft nach Anhörung der Koordinierungsgruppe Medizinprodukte im Wege von Durchführungsrechtsakten Vorkehrungen für die Benennung von Expertengremien, die der Kommission, der Koordinierungsgruppe Medizinprodukte, den Mitgliedstaaten, den Benannten Stellen oder den Herstellern wissenschaftliche, klinische, technische oder regulatorische Stellungnahmen und Beratung im Zusammenhang mit der Durchführung dieser Verordnung und der Verordnung (EU) 2017/746 zur Verfügung stellen.

      Die Expertengremien können auf ständiger oder zeitlich befristeter Basis benannt werden.

  - (2) Die Expertengremien bestehen aus Sachverständigen mit nachgewiesener aktueller klinischer, wissenschaftlicher, technischer oder regulatorischer Fachkompetenz auf dem Gebiet der Medizinprodukte oder In-vitro-Diagnostika, die die Vielfalt der wissenschaftlichen und klinischen Ansätze in der Union widerspiegeln.

      Die Sachverständigen werden nach Veröffentlichung eines Aufrufs zur Interessenbekundung ernannt. Je nach Art der Aufgabe und des Bedarfs an spezialisiertem Fachwissen können die Sachverständigen für einen Zeitraum von höchstens drei Jahren in die Gremien berufen werden; eine Verlängerung ist möglich.

      Werden die Expertengremien um eine Stellungnahme zum rechtlichen Status eines Produkts ersucht, die Aspekte der Abgrenzung zu anderen Produktarten betrifft, so werden Sachverständige mit Fachkompetenz auf dem Gebiet der jeweils relevanten anderen Produkte einbezogen.

  - (3) Die Sachverständigen wahren die Grundsätze höchster wissenschaftlicher Kompetenz und nehmen ihre Aufgaben unparteiisch, objektiv und transparent wahr. Sie dürfen Weisungen von Benannten Stellen oder Herstellern weder einholen noch entgegennehmen. Jeder Sachverständige gibt eine Interessenerklärung ab, die öffentlich zugänglich gemacht wird.

  - (4) Die Expertengremien berücksichtigen relevante von Interessenträgern, auch von Patientenorganisationen und Verbänden der Gesundheitsberufe, bereitgestellte Informationen.

  - (5) Die Sachverständigen können in eine Liste verfügbarer Sachverständiger aufgenommen werden, die zwar nicht formal in ein Expertengremium berufen wurden, jedoch zur Beratung und zur Unterstützung der Arbeit der Expertengremien nach Bedarf zur Verfügung stehen.

  - (6) Sachverständige aus Benannten Stellen dürfen nicht an dem in Artikel 54 Absatz 1 vorgesehenen Konsultationsverfahren zur klinischen Bewertung mitwirken.

  - (7) Zusätzlich zu den ihnen in anderen Bestimmungen dieser Verordnung und der Verordnung (EU) 2017/746 übertragenen Aufgaben können die Expertengremien insbesondere folgende Aufgaben wahrnehmen:

    - a) der Kommission, der Koordinierungsgruppe Medizinprodukte, den Mitgliedstaaten oder den Benannten Stellen im Zusammenhang mit der Durchführung dieser Verordnung oder der Verordnung (EU) 2017/746 wissenschaftliche, klinische, technische und regulatorische Beratung leisten;

    - b) zur Ausarbeitung und Pflege geeigneter Leitlinien und GS zur Unterstützung der Durchführung dieser Verordnung oder der Verordnung (EU) 2017/746 beitragen;

    - c) zur Ausarbeitung von Normen auf Unionsebene oder internationaler Ebene beitragen und sicherstellen, dass diese Normen dem Stand der Technik entsprechen;

    - d) zur Erfassung von Bedenken und neuen Frage im Zusammenhang mit der Sicherheit und der Leistung von Medizinprodukten, einschließlich In-vitro-Diagnostika, beitragen.

  - (8) Bei der Abgabe ihrer Stellungnahmen oder Erbringung ihrer Beratungsleistung bemühen sich die Mitglieder der Expertengremien nach besten Kräften, einen Konsens zu erzielen. Kann kein Konsens erzielt werden, entscheiden die Expertengremien mit der Mehrheit ihrer Mitglieder, und in der Stellungnahme oder Beratungsleistung werden die abweichenden Standpunkte sowie die Gründe, auf denen sie beruhen, angegeben.

  - (9) Die Kommission verlangt von den Herstellern und den Benannten Stellen die Zahlung von Gebühren für von den Expertengremien abgegebene Stellungnahmen und erbrachte Beratungsleistung. Die Kommission legt Struktur und Höhe der Gebühren sowie den Umfang und die Art der erstattungsfähigen Kosten im Wege von Durchführungsrechtsakten fest und berücksichtigt dabei die Ziele der angemessenen Umsetzung dieser Verordnung, des Schutzes der Gesundheit und Sicherheit, der Innovationsförderung und der Wirtschaftlichkeit sowie die Notwendigkeit, eine aktive Beteiligung in den Expertengremien zu erreichen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

  - Die im ersten Unterabsatz genannten Gebühren werden transparent und auf der Grundlage der Kosten für die erbrachten Dienstleistungen festgelegt. Die Gebühren werden für Hersteller, bei denen es sich um Kleinstunternehmen sowie kleine oder mittlere Unternehmen im Sinne der Empfehlung 2003/361/EG handelt, ermäßigt, auch im Fall eines gemäß Anhang IX Abschnitt 5.1 Buchstabe c eingeleiteten Konsultationsverfahrens zur klinischen Bewertung, an dem ein Hersteller beteiligt ist, bei dem es sich um ein Kleinstunternehmen sowie ein kleines oder mittleres Unternehmen im Sinne der Empfehlung 2003/361/EG handelt. Die Gebühren für die Stellungnahmen und Beratungsleistungen der Expertengremien sind gemäß Artikel 30 Buchstabe f der Verordnung (EU) 2022/123 an die EMA zu entrichten.

  - (10) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um Absatz 7 des vorliegenden Artikels zu ändern, indem Aufgaben in die Aufgabenliste der Expertengremien aufgenommen, angepasst oder von ihr gestrichen werden.“

- 87. Die folgenden Artikel 106a und 106b werden eingefügt:

**„Artikel 106a**

Fachlaboratorien

  - (1) Die Kommission kann nach Anhörung der Koordinierungsgruppe Medizinprodukte im Wege von Durchführungsrechtsakten Fachlaboratorien benennen, und zwar auf der Grundlage ihrer Fachkompetenz im Bereich der Prüfung von Medizinprodukten, etwa der physikalisch-chemischen Charakterisierung sowie mikrobiologischer, Biokompatibilitäts-, mechanischer, elektrischer, elektronischer oder nichtklinisch-toxikologischer Untersuchungen bestimmter Produkte, Kategorien oder Gruppen von Produkten.

      Die Kommission benennt nur Fachlaboratorien, deren Benennung von einem Mitgliedstaat oder der Gemeinsamen Forschungsstelle beantragt wurde.

  - (2) Die Fachlaboratorien müssen folgende Kriterien erfüllen:

    - a) über geeignetes und angemessen qualifiziertes Personal verfügen, das seinerseits über angemessenes Fachwissen und angemessene Erfahrung in Bezug auf die Produkte, für die die Laboratorien benannt wurden, verfügt;

    - b) über die notwendige Ausrüstung für die Durchführung der ihnen übertragenen Aufgaben verfügen;

    - c) über die erforderlichen Kenntnisse der internationalen Normen und vorbildlichen Verfahren verfügen;

    - d) eine geeignete Verwaltungs- und Organisationsstruktur aufweisen;

    - e) sicherstellen, dass ihr Personal die Vertraulichkeit der im Rahmen ihrer Tätigkeit erlangten Informationen und Daten wahrt;

    - f) unabhängig und im Interesse des Gemeinwohls handeln.

  - (3) Fachlaboratorien können folgende Aufgaben wahrnehmen:

    - a) wissenschaftliche und technische Unterstützung der Kommission, der Koordinierungsgruppe Medizinprodukte, der EMA, der Mitgliedstaaten und der Benannten Stellen bei der Durchführung dieser Verordnung;

    - b) Mitwirkung an der Ausarbeitung und Weiterentwicklung geeigneter Leitlinien und GS zur Unterstützung der Durchführung dieser Verordnung;

    - c) Mitwirkung an der Entwicklung von Normen auf Unionsebene oder internationaler Ebene und Gewährleistung, dass diese Normen dem Stand der Technik entsprechen;

    - d) Mitwirkung an der Erfassung von Bedenken und neuen Fragen im Zusammenhang mit der Sicherheit und Leistung von Medizinprodukten;

    - e) wissenschaftliche und technische Unterstützung der Mitgliedstaaten und der Kommission bei Vigilanz- und Marktüberwachungstätigkeiten.

  - (4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 115 delegierte Rechtsakte zu erlassen, um Absatz 3 dieses Artikels zu ändern, indem Aufgaben in die Aufgabenliste der Fachlaboratorien aufgenommen, angepasst oder von ihr gestrichen werden.

  - (5) Die Fachlaboratorien können für die der EMA, den Mitgliedstaaten oder den Benannten Stellen zur Durchführung der angeforderten Aufgabe geleistete wissenschaftliche und technische Unterstützung unter vorab festgelegten und transparenten Bedingungen Gebühren erheben. Für die Erbringung von Dienstleistungen im öffentlichen Interesse auf Ersuchen der Kommission oder der Koordinierungsgruppe Medizinprodukte kann den Fachlaboratorien ein finanzieller Beitrag der Union gewährt werden.

**Artikel 106b**

Unterstützung durch die EMA

  - (1) Die EMA leistet im Auftrag der Kommission den nach dieser Verordnung und der Verordnung (EU) 2017/746 benannten nationalen zuständigen Behörden wissenschaftliche, technische und administrative Unterstützung, um den Erfahrungsaustausch, die Zusammenarbeit und die Koordinierung zu erleichtern, mit dem Ziel, eine einheitliche Anwendung dieser Verordnungen sicherzustellen, insbesondere in folgenden Bereichen:

    - a) rechtlicher Status von Produkten und Klassifizierung von Produkten gemäß den Artikeln 4, 4a, 51, 51a und 51b der vorliegenden Verordnung sowie den Artikeln 3, 3a, 47, 47a und 47b der Verordnung (EU) 2017/746;

    - b) Ausnahmen von den geltenden Konformitätsbewertungsverfahren gemäß den Artikeln 59 und 59a der vorliegenden Verordnung sowie den Artikeln 54 und 54a der Verordnung (EU) 2017/746;

    - c) klinische Bewertung, klinische Prüfungen, Leistungsbewertung und Leistungsstudien gemäß Kapitel VI der vorliegenden Verordnung und Kapitel VI der Verordnung (EU) 2017/746, einschließlich der Unterstützung des koordinierenden Mitgliedstaats bei dem koordinierten Bewertungsverfahren für klinische Prüfungen und Leistungsstudien gemäß Artikel 78 der vorliegenden Verordnung und Artikel 74 der Verordnung (EU) 2017/746;

    - d) Vigilanz und Marktüberwachung gemäß Kapitel VII der vorliegenden Verordnung und Kapitel VII der Verordnung (EU) 2017/746, einschließlich der Unterstützung der koordinierenden zuständigen Behörde bei dem koordinierten Verfahren gemäß Artikel 89 Absatz 9 der vorliegenden Verordnung und Artikel 84 Absatz 9 der Verordnung (EU) 2017/746.

  - (2) Die EMA leistet der Kommission wissenschaftliche, technische und administrative Unterstützung bei der Einrichtung von Reallaboren der Union gemäß Artikel 59c der vorliegenden Verordnung und Artikel 54c der Verordnung (EU) 2017/746.

  - (3) Die EMA richtet für Hersteller von Medizinprodukten und In-vitro-Diagnostika, bei denen es sich um Kleinstunternehmen sowie kleine und mittlere Unternehmen im Sinne der Empfehlung 2003/361/EG handelt, ein Unterstützungsprogramm in Bezug auf die Anforderungen der vorliegenden Verordnung und der Verordnung (EU) 2017/746 ein.

  - (4) Die EMA erhält Zugang zu Eudamed sowie zu jedem elektronischen System, das nicht in Eudamed enthalten ist, gemäß Artikel 33 Absatz 2 der vorliegenden Verordnung oder Artikel 30 Absatz 2 der Verordnung (EU) 2017/746.“

- 88. Artikel 107 Absatz 1 Sätze 4 und 5 erhalten folgende Fassung:

    „Die Interessenerklärung wird öffentlich zugänglich gemacht. Dieser Artikel gilt nicht für die Vertreter der Interessenträger, die an der Koordinierungsgruppe Medizinprodukte oder ihren Untergruppen teilnehmen.“

- 89. In Artikel 108 erhält Satz 1 folgende Fassung:

    „Die Kommission, die Mitgliedstaaten und die EMA treffen alle geeigneten Maßnahmen, um die Einrichtung von Registern und Datenbanken für bestimmte Arten von Produkten zu fördern, gegebenenfalls einschließlich In-vitro-Diagnostika, und legen gemeinsame Grundsätze für die Erhebung vergleichbarer Informationen fest.“

- 90. Nach Artikel 108 wird folgender Abschnitt 2 eingefügt:

‘ABSCHNITT 2 – Internationale Zusammenarbeit

<a id="art-108a"></a>
### Artikel 108a

Internationale regulatorische und administrative Zusammenarbeit

  - (1) Die Kommission verfolgt die internationale regulatorische Zusammenarbeit im Bereich der Medizinprodukte und In-vitro-Diagnostika mit dem Ziel, ein hohes Schutzniveau der öffentlichen Gesundheit und der Patientensicherheit herbeizuführen, Innovationen zu fördern und durch weltweite Konvergenz eine effizientere Einhaltung regulatorischer Anforderungen zu erreichen. Zu diesem Zweck tragen die Europäische Kommission und die Mitgliedstaaten zur Entwicklung und Annahme globaler Grundsätze, Normen und Leitlinien bei, die ein hohes Maß an internationaler Konvergenz im Bereich der Medizinprodukte und In-vitro-Diagnostika gewährleisten, auch hinsichtlich Sicherheit, Leistung, Qualitätsmanagementsysteme, Konformitätsbewertung und Überwachung nach dem Inverkehrbringen.

  - (2) Die Kommission beteiligt sich an einschlägigen internationalen Foren im Bereich der Medizinprodukte und In-vitro-Diagnostika, einschließlich des Internationalen Forums der Aufsichtsbehörden für Medizinprodukte (IMP-VOF), des Programms zur Durchführung eines einheitlichen Audits für Medizinprodukte (MDSAP) sowie internationaler Normungsorganisationen.

  - (3) Bei ihren Tätigkeiten gemäß den Absätzen 1 und 2 wird die Kommission durch von den Mitgliedstaaten benannte Sachverständige unterstützt, die über Fachkompetenz im Bereich der Medizinprodukte oder der In-vitro-Diagnostika verfügen.

  - (4) Die Europäische Kommission kann mit Behörden von Drittländern und mit internationalen Organisationen administrative Vereinbarungen zum Zweck der regulatorischen Zusammenarbeit im Bereich der Medizinprodukte und In-vitro-Diagnostika schließen, die Folgendes umfassen:

    - a) Austausch von Informationen und bewährten Verfahren;

    - b) gemeinsame oder koordinierte Inspektionen und Bewertungen;

    - c) koordinierte Maßnahmen im Zusammenhang mit Sicherheitsfragen, einschließlich Rückrufen oder Sicherheitsmitteilungen.

      Schließt die Kommission solche administrativen Vereinbarungen, die den Austausch von Informationen oder Daten vorsehen, so enthalten diese administrativen Vereinbarungen Bestimmungen zum Schutz dieser Informationen oder Daten gemäß Artikel 109 der vorliegenden Verordnung bzw. Artikel 102 der Verordnung (EU) 2017/746.

  - (5) Die Europäische Union finanziert die Tätigkeiten der Kommission und der Mitgliedstaaten im Zusammenhang mit der in diesem Artikel genannten internationalen Zusammenarbeit sowie den in Artikel 108b genannten Anerkennungsmechanismen.

**Artikel 108b**

Anerkennungsmechanismen

  - (1) Die Europäische Kommission kann an bilateralen oder multilateralen Anerkennungsmechanismen oder Anerkennungsprogrammen im Bereich der Medizinprodukte und In-vitro-Diagnostika teilnehmen, die die Nutzung von Bewertungen, Inspektionen und sonstigen regulatorischen Entscheidungen ermöglichen, die von Regulierungsbehörden von Drittländern oder von internationalen Organisationen oder internationalen Gremien durchgeführt oder getroffen wurden, sofern die folgenden Bedingungen erfüllt sind:

    - a) Der Anerkennungsmechanismus oder das Anerkennungsprogramm gewährleistet ein Schutzniveau für die Gesundheit und Sicherheit, das dem nach der vorliegenden Verordnung bzw. der Verordnung (EU) 2017/746 erforderlichen Schutzniveau gleichwertig ist.

    - b) Es gibt wirksame Regelungen für den gegenseitigen Austausch von Informationen, Transparenz und Überwachung, die den Schutz der Informationen und Daten gemäß Artikel 109 der vorliegenden Verordnung bzw. gemäß Artikel 102 der Verordnung (EU) 2017/746 gewährleisten.

  - (2) Die Kommission kann die Mitgliedstaaten auffordern, Sachverständige zu benennen, die aufgrund ihrer Fachkompetenz im Bereich der Medizinprodukte oder der In-vitro-Diagnostika an den Anerkennungsmechanismen oder Anerkennungsprogrammen gemäß Absatz 1 teilnehmen.

  - (3) Die Anerkennungsmechanismen oder Anerkennungsprogramme gemäß Absatz 1 werden von den zuständigen Behörden, den Wirtschaftsakteuren oder den Benannten Stellen im Rahmen der Durchführung der vorliegenden Verordnung bzw. der Verordnung (EU) 2017/746 berücksichtigt.

  - (4) Die Kommission kann Durchführungsrechtsakte erlassen, mit denen detaillierte Vorschriften für die Beteiligung an Anerkennungsmechanismen oder Anerkennungsprogrammen festgelegt werden; diese können Bedingungen für die Beteiligung von Benannten Stellen an Anerkennungsmechanismen oder Anerkennungsprogrammen, Anforderungen in Bezug auf den Umfang der im Rahmen von Anerkennungsmechanismen oder Anerkennungsprogrammen durchgeführten Bewertungen, Inspektionen oder sonstigen regulatorischen Entscheidungen sowie Verfahrensgarantien für Hersteller umfassen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 114 Absatz 3 genannten Prüfverfahren erlassen.

**Artikel 108c**

Kapazitätsaufbau sowie technische Hilfe

  - (1) Die Kommission kann die Stärkung der regulatorischen Kapazitäten in Drittländern unterstützen, einschließlich durch die Bereitstellung technischer Unterstützung, Schulungen, den Austausch von Sachverständigen sowie die Verbreitung bewährter Verfahren.

  - (2) Die Kommission kann die Mitgliedstaaten auffordern, Sachverständige zu benennen, die aufgrund ihrer Fachkompetenz im Bereich der Medizinprodukte oder In-vitro-Diagnostika an den in Absatz 1 genannten Tätigkeiten teilnehmen.

  - (3) Die in Absatz 1 genannten Tätigkeiten können über einschlägige Unionsprogramme oder Instrumente des auswärtigen Handelns finanziert werden.“

- 91. Folgender Artikel 110a wird angefügt:

**„Artikel 110a**

Übermittlung von Informationen oder Unterlagen

    Die Übermittlung von Informationen oder Unterlagen gemäß dieser Verordnung erfolgt elektronisch.“

- 92. Artikel 111 Absatz 1 erhält folgende Fassung:

  - „(1) Diese Verordnung hindert die Mitgliedstaaten und die Kommission nicht daran, für die ihnen mit dieser Verordnung übertragenen Aufgaben Gebühren zu erheben, sofern die Höhe dieser Gebühren auf transparente Weise und nach dem Grundsatz der Kostendeckung festgelegt wird.“

- 93. Artikel 112 wird gestrichen;

- 94. Artikel 116 wird gestrichen;

- 95. In Artikel 120 werden die folgenden Absätze 14 und 15 angefügt:

  - „(14) Abweichend von Artikel 5 und von den Absätzen 3 bis 3e dieses Artikels darf ein Produkt gemäß Absatz 3a oder 3b dieses Artikels, das die Kriterien für ein Medizinprodukt für seltene Erkrankungen im Sinne des Artikels 52a Absatz 3 erfüllt, nach den Zeitpunkten gemäß den Absätzen 3a und 3b dieses Artikels in Verkehr gebracht oder in Betrieb genommen werden, sofern die folgenden Bedingungen erfüllt sind:

    - a) Ein Expertengremium gemäß Artikel 106 hat eine Stellungnahme abgegeben, in der die Erfüllung der Kriterien für ein Medizinprodukt für seltene Erkrankungen im Sinne des Artikels 52a Absatz 3 bestätigt wird.

    - b) Die Auslegung und Zweckbestimmung des Produkts wurden nicht wesentlich geändert.

    - c) Das Produkt stellt kein unannehmbares Risiko für die Gesundheit oder Sicherheit der Patienten, Anwender oder anderer Personen oder für andere Aspekte des Schutzes der öffentlichen Gesundheit dar.

      Die Anforderungen der vorliegenden Verordnung gelten mit Ausnahme der Kapitel IV, V und VI für das in Unterabsatz 1 genannte Produkt.

      Abweichend von Artikel 86 Absatz 1 aktualisieren Hersteller von Produkten der Klassen IIa, IIb und III, die gemäß diesem Absatz in Verkehr gebracht oder in Betrieb genommen werden, den Sicherheitsbericht mindestens jährlich. Der Hersteller übermittelt jährlich den Sicherheitsbericht und gegebenenfalls eine Aktualisierung des Kurzberichts über Sicherheit und klinische Leistung an die zuständige Behörde des Mitgliedstaats, in dem er niedergelassen ist.

      Die zuständige Behörde des Mitgliedstaats kann vom Hersteller verlangen, innerhalb eines festgelegten Zeitraums definierte Maßnahmen zur Überwachung nach dem Inverkehrbringen oder zur klinischen Nachbeobachtung nach dem Inverkehrbringen durchzuführen, um zusätzliche klinische Daten zu generieren, mit denen die Sicherheit und die Leistung des Produkts bestätigt sowie etwaige unerwünschte Nebenwirkungen und die Vertretbarkeit des Nutzen-Risiko-Verhältnisses bewertet werden.

      Produkte, die gemäß diesem Absatz in Verkehr gebracht oder in Betrieb genommen werden und die nicht über eine gültige Bescheinigung gemäß Absatz 2 verfügen, dürfen keine CE-Kennzeichnung tragen. In seiner EU-Konformitätserklärung verweist der Hersteller darauf, dass es sich bei dem Produkt um ein Medizinprodukt für seltene Erkrankungen handelt, das gemäß dieser Bestimmung in Verkehr gebracht oder in Betrieb genommen wurde.

      Der Hersteller informiert die vorgesehenen Anwender gegebenenfalls im Kurzbericht über Sicherheit und klinische Leistung sowie in der Gebrauchsanweisung oder in sonstigen Begleitunterlagen darüber, dass es sich bei dem Produkt um ein Medizinprodukt für seltene Erkrankungen handelt, das gemäß dieser Bestimmung in Verkehr gebracht oder in Betrieb genommen wurde.

      Mindestens alle zehn Jahre beantragt der Hersteller bei einem Expertengremium gemäß Artikel 106 eine Stellungnahme, in der die Erfüllung der Kriterien für ein Medizinprodukt für seltene Erkrankungen im Sinne des Artikels 52a Absatz 3 bestätigt wird.

  - (15) In Bezug auf Produkte, für die am … [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach dem Inkrafttreten dieser Verordnung] ein Konformitätsbewertungsverfahren anhängig ist oder für die vor diesem Datum von einer Benannten Stelle eine Bescheinigung ausgestellt wurde, können der Hersteller und die Benannte Stelle vereinbaren, die Bestimmungen dieser Verordnung in der vor dem … [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach dem Inkrafttreten dieser Verordnung] geltenden Fassung solange weiter anzuwenden, bis das Konformitätsbewertungsverfahren abgeschlossen ist oder die Bescheinigung erneuert wird.“

- 96. Artikel 121 erhält folgende Fassung:

**„Artikel 121**

Bewertung

    Frühestens am … [Amt für Veröffentlichungen: bitte Datum einfügen = fünf Jahre nach dem Geltungsbeginn dieser Verordnung] nimmt die Kommission eine Bewertung dieser Verordnung vor und legt dem Europäischen Parlament und dem Rat einen Bericht über die wichtigsten Ergebnisse vor.

    Die Mitgliedstaaten und die Benannte Stellen übermitteln der Kommission die für die Ausarbeitung dieses Berichts erforderlichen Informationen.“

- 97. In Artikel 123 Absatz 3 Buchstabe d wird folgender Unterabsatz 3 angefügt:

    „Falls die Mitgliedstaaten nationale Datenbanken unterhalten, werden die für diese nationalen Datenbanken relevanten und in Eudamed verfügbaren Informationen nach dem Geltungsbeginn der in Unterabsatz 1 genannten Bestimmungen aus Eudamed abgerufen.“

- 98. Die Anhänge I, II, III, VI, VII, VIII, IX, X, XI, XII, XIII, XIV und XV werden gemäß Anhang I der vorliegenden Verordnung geändert.

**Artikel 2**

**Artikel 2**

Änderungen der Verordnung (EU) 2017/746

Die Verordnung (EU) 2017/746 wird wie folgt geändert:

- 1. Artikel 1 Absatz 4 erhält folgende Fassung:

  - „(4) Enthält ein Produkt bei seinem Inverkehrbringen oder seiner Inbetriebnahme als integralen Bestandteil ein Medizinprodukt im Sinne des Artikels 2 Nummer 1 der Verordnung (EU) 2017/745, dem im Rahmen des In-vitro-Diagnostikums eine unterstützende Funktion zukommt, so unterliegt das Gesamtprodukt der vorliegenden Verordnung. In diesem Fall gelten für die Sicherheit und die Leistung des aus dem Medizinprodukt bestehenden Teils die in Anhang I der Verordnung (EU) 2017/745 aufgeführten einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen.

      Kommt der Wirkung des Medizinprodukts jedoch eine hauptsächliche und keine unterstützende Funktion im Rahmen des In-vitro-Diagnostikums zu, so unterliegt das Gesamtprodukt der Verordnung (EU) 2017/745. In diesem Fall gelten für die Sicherheit und die Leistung des aus dem In-vitro-Diagnostikum bestehenden Teils die in Anhang I der vorliegenden Verordnung aufgeführten einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen.“

- 2. Artikel 2 wird wie folgt geändert:

  - a) Unter Nummer 2 Unterabsatz 1 erhält Buchstabe f folgende Fassung:

    - „f) (betrifft nicht die deutsche Fassung)“

  - b) unter Nummer 7 erhalten die einleitenden Worte folgende Fassung:

      „‚therapiebegleitendes Diagnostikum‘ bezeichnet ein Produkt, das für die sichere und wirksame Verwendung eines oder mehrerer zugehöriger Arzneimittel(s) wesentlich ist, um:“

  - c) Nummer 8 erhält folgende Fassung:

    - „8. ‚generische Produktgruppe‘ bezeichnet eine Gruppe von Produkten mit gleichen oder ähnlichen Zweckbestimmungen und mit technologischen Gemeinsamkeiten, die allgemein, also ohne Berücksichtigung spezifischer Merkmale klassifiziert werden können;“

  - d) es werden folgende Nummern 75, 76, 77 und 78 angefügt:

    - „75. ‚kombinierte Studie‘ bezeichnet eine klinische Prüfung im Sinne des Artikels 2 Absatz 2 Nummer 2 der Verordnung (EU) Nr. 536/2014 in Verbindung mit einer Leistungsstudie und/oder einer klinischen Prüfung im Sinne des Artikels 2 Nummer 45 der Verordnung (EU) 2017/745;

    - 76. ‚Reallabor‘ bezeichnet eine von einer zuständigen Behörde eingerichtete kontrollierte Umgebung, in der Hersteller oder potenzielle Hersteller unter regulatorischer Aufsicht ein innovatives Produkt oder eine innovative Technologie, die möglicherweise in den Anwendungsbereich dieser Verordnung fällt, für einen begrenzten Zeitraum nach einem Reallabor-Plan entwickeln, testen, validieren und – sofern angezeigt – unter realen Bedingungen anwenden können“;

    - 77. ‚Reallabor-Plan‘ bezeichnet ein zwischen dem oder den teilnehmenden Hersteller(n) bzw. potenziellen Hersteller(n) und der zuständigen Behörde vereinbartes Dokument, das die Ziele, Bedingungen, den Zeitrahmen, die Methodik und die Anforderungen für die im Reallabor durchgeführten Tätigkeiten beschreibt;

    - 78. ‚Reallabor der Union‘ bezeichnet eine von der Kommission eingerichtete kontrollierte Umgebung zur Erprobung über einen begrenzten Zeitraum von alternativen oder neuen regulatorischen Anforderungen oder Durchsetzungspraktiken sowie zur Bewertung ihrer Validität im Vergleich zu den bestehenden Anforderungen und Praktiken nach dieser Verordnung.“

- 3. Artikel 3 erhält folgende Fassung:

**„Artikel 3**

Rechtlicher Status von Produkten

  - (1) Die zuständigen Behörden der Mitgliedstaaten koordinieren ihre Tätigkeiten, wenn sie feststellen, ob ein bestimmtes Produkt oder eine Produktkategorie oder eine Produktgruppe unter die Begriffsbestimmung eines ‚In-vitro-Diagnostikums‘ oder eines ‚Zubehörs für ein In-vitro-Diagnostikum‘ fällt.

  - (2) Die Mitgliedstaaten stellen ein angemessenes Maß an Konsultation der einschlägigen zuständigen Behörden der Mitgliedstaaten in den Bereichen Medizinprodukte, Arzneimittel, Substanzen menschlichen Ursprungs (SoHO), Biozidprodukte, Lebensmittel, kosmetische Mittel oder sonstige unter das Unionsrecht fallende Produkte sicher, wenn die Feststellung des rechtlichen Status eines Produkts Aspekte der Abgrenzung zu einer dieser Produktarten betrifft. In diesem Fall stellen die Mitgliedstaaten außerdem ein angemessenes Maß an Konsultation der einschlägigen Beratungs- oder Regulierungsstellen sicher, die gemäß den einschlägigen Rechtsvorschriften der Union eingerichtet wurden, wie etwa der Europäischen Arzneimittel-Agentur (EMA), dem SoHO-Koordinierungsgremium, der Europäischen Chemikalienagentur (ECHA) und der Europäischen Behörde für Lebensmittelsicherheit (EFSA).

  - (3) Ist eine zuständige Behörde eines Mitgliedstaats nach Durchführung einer Bewertung gemäß Artikel 89 der Auffassung, dass ein Produkt, das gemäß Artikel 18 mit der CE-Kennzeichnung versehen ist, nicht in den Anwendungsbereich dieser Verordnung fällt, so konsultiert sie die zuständigen Behörden der anderen Mitgliedstaaten zu der von ihr beabsichtigten Maßnahme zur Feststellung des rechtlichen Status des betreffenden Produkts.

  - (4) Erhebt eine zuständige Behörde eines Mitgliedstaats einen begründeten Einwand gegen die in Absatz 3 genannte beabsichtigte Maßnahme, so legt die konsultierende Behörde die Angelegenheit einem Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 vor und trägt dessen Stellungnahme weitestgehend Rechnung.

  - (5) Die Ergebnisse der Koordinierungstätigkeiten der zuständigen Behörden gemäß diesem Artikel sowie die Stellungnahmen des Expertengremiums, die gemäß Absatz 4 dieses Artikels und Artikel 3a Absatz 2 abgegeben wurden, werden öffentlich zugänglich gemacht, ohne dass dabei vertrauliche Informationen im Sinne von Artikel 102 offengelegt werden.

  - (6) Die Kommission kann im Wege von Durchführungsrechtsakten das Verfahren, einschließlich der Fristen, für die Anwendung der Absätze 1 bis 4 dieses Artikels sowie des Artikels 3a festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.“

- 4. es wird folgender Artikel 3a eingefügt:

**„Artikel 3a**

Stellungnahme zum und Feststellung des rechtlichen Status von Produkten auf Unionsebene

  - (1) Eine zuständige Behörde, eine Benannte Stelle, ein Hersteller, ein Entwickler eines Produkts oder die Kommission kann einen begründeten Antrag auf Abgabe einer Stellungnahme durch ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 zu der Frage stellen, ob ein bestimmtes Produkt oder eine Produktkategorie oder Produktgruppe unter die Begriffsbestimmung eines ‚In-vitro-Diagnostikums‘ oder eines ‚Zubehörs für ein In-vitro-Diagnostikum‘ fällt“. Hält der Antragsteller in einem solchen Antrag das betreffende Produkt für ein In-vitro-Diagnostikum, so ist im Antrag auch die vorgeschlagene Klassifizierung des Produkts gemäß Artikel 47 und Anhang VIII anzugeben.

  - (2) Das Expertengremium gibt seine Stellungnahme unverzüglich ab. Der Antragsteller trägt der Stellungnahme des Expertengremiums weitestgehend Rechnung.

  - (3) Unter Berücksichtigung der in Absatz 2 oder in Artikel 3 Absatz 4 genannten Stellungnahme des Expertengremiums kann ein Mitgliedstaat der Kommission einen begründeten Antrag unterbreiten, um feststellen zu lassen, ob ein bestimmtes Produkt oder eine Produktkategorie oder eine Produktgruppe unter die Begriffsbestimmung eines ‚In-vitro-Diagnostikums‘ oder eines ‚Zubehörs für ein In-vitro-Diagnostikum‘ fällt.

      Die Kommission entscheidet über den begründeten Antrag des Mitgliedstaats oder von sich aus im Wege von Durchführungsrechtsakten, die gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen werden.

      Die Kommission kann das Expertengremium um Klarstellungen ersuchen oder die Stellungnahme zur weiteren Prüfung an das Expertengremium zurückverweisen, einschließlich in Fällen, in denen der begründete Antrag eines Mitgliedstaats neue wissenschaftliche oder technische Fragen aufwirft.

  - (4) Dieser Artikel findet keine Anwendung, wenn das betreffende Produkt, die betreffende Produktkategorie oder die betreffende Produktgruppe nach ihrem im Rahmen anderer Rechtsvorschriften der Union festgestellten rechtlichen Status in den Anwendungsbereich dieser anderen Rechtsvorschriften fallen oder wenn im Rahmen anderer Rechtsvorschriften der Union ein Verfahren zur Feststellung des rechtlichen Status anhängig ist.“

- 5. Artikel 5 wird wie folgt geändert:

  - a) Absatz 5 wird wie folgt geändert:

    - i) Unterabsatz 1 wird wie folgt geändert:

      - 1. Buchstabe a erhält folgende Fassung:

        - „a) Die Produkte werden nicht an eine andere juristische Person abgegeben, es sei denn an eine andere Gesundheitseinrichtung im ordnungsgemäß begründeten Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten oder zur Vorbereitung oder als Reaktion auf eine gesundheitliche Notlage;“

      - 2. Buchstabe c erhält folgende Fassung:

        - „c) das Labor der Gesundheitseinrichtung entspricht der Norm EN ISO 15189 oder gegebenenfalls nationalen Vorschriften für Qualität und Kompetenz in medizinischen Laboratorien einschließlich nationaler Akkreditierungsvorschriften;“

      - 3. Buchstabe d wird gestrichen.

      - 4. Buchstabe e erhält folgende Fassung:

        - „e) auf Ersuchen einer zuständigen Behörde stellt die Gesundheitseinrichtung der für sie zuständigen Behörde Informationen über die Verwendung solcher Produkte zur Verfügung, die auch die Begründung gemäß Buchstabe a umfassen;“

      - 5. Buchstabe f Ziffer iii erhält folgende Fassung:

        - „iii) eine Erklärung entweder darüber, dass die Gesundheitseinrichtung nach der unter Buchstabe c genannten Norm akkreditiert ist, oder darüber, dass die Produkte die einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I erfüllen, und gegebenenfalls Angaben – mit entsprechender Begründung – darüber, welche Anforderungen nicht vollständig erfüllt sind;“

      - 6. Buchstabe g erhält folgende Fassung:

        - „g) im Zusammenhang mit Produkten, die gemäß Anhang VIII in die Klasse D eingestuft werden, erstellt die Gesundheitseinrichtung, sofern sie nicht nach der unter Buchstabe c genannten Norm akkreditiert sind, hinreichend detaillierte Unterlagen, damit sich die zuständige Behörde vergewissern kann, dass die einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I erfüllt sind;“

      - 7. Buchstabe h wird gestrichen.

    - ii) In Unterabsatz 2 wird der erste Satz gestrichen.

    - iii) Es werden folgende Unterabsätze angefügt:

        „Für die Zwecke von Unterabsatz 1 Buchstabe a stellen im Falle einer Abgabe des Produkts an eine andere Gesundheitseinrichtung die abgebende und die empfangende Gesundheitseinrichtung die Rückverfolgbarkeit des Produkts sicher.

        Für die Zwecke von Unterabsatz 1 Buchstabe i meldet im Fall einer Produktabgabe gemäß Unterabsatz 1 Buchstabe a die empfangende Gesundheitseinrichtung jedes das Produkt betreffende Vorkommnis an die abgebende Gesundheitseinrichtung.

        Dieser Absatz gilt auch für Produkte, die in einem in der Union niedergelassenen Labor hergestellt und verwendet werden, das konsistente Prüfleistungen auf dem Stand der Technik für die klinische Forschung erbringt, sofern diese Produkte ausschließlich zur Verwendung im Rahmen einer klinischen Prüfung bestimmt sind, die der Verordnung (EU) Nr. 536/2014 des Europäischen Parlaments und des Rates* unterliegt. Soweit in diesem Absatz auf eine Gesundheitseinrichtung Bezug genommen wird, ist ein solcher Bezug auch als Bezug auf ein in Satz 1 dieses Unterabsatzes genanntes Labor zu verstehen.

        __________________

        *Verordnung (EU) Nr. 536/2014 des Europäischen Parlaments und des Rates vom 16. April 2014 über klinische Prüfungen mit Humanarzneimitteln und zur Aufhebung der Richtlinie 2001/20/EG (Abl. L 158 vom 27.5.2014, S. 1, ELI: http://data.europa.eu/eli/reg/2014/536/oj ).“

  - b) Es wird folgender Absatz 7 angefügt:

    - „(7) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um die grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I an den wissenschaftlichen oder technischen Fortschritt oder an Entwicklungen auf internationaler Ebene anzupassen oder Anforderungen in Bezug auf neu entstehende Risiken oder Technologien hinzuzufügen.

    - (8) Bei der Annahme von Durchführungsrechtsakten gemäß Absatz 6 dieses Artikels, delegierten Rechtsakten gemäß Absatz 7 dieses Artikels oder gemeinsamen Spezifikationen gemäß Artikel 9 dieser Verordnung in Bezug auf Produkte, die Hochrisiko-KI-Systeme im Sinne von Artikel 6 Absatz 1 der Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates** darstellen oder Hochrisiko-KI-Systeme als Sicherheitskomponenten verwenden, berücksichtigt die Kommission die in Kapitel III Abschnitt 2 der genannten Verordnung festgelegten Anforderungen.

    - __________________

    - **Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: ).“

- 6. Artikel 6 wird wie folgt geändert:

  - a) Es wird folgender Absatz 2a eingefügt:

    - „(2a) Jede natürliche oder juristische Person, die gemäß Absatz 1 ein Produkt anbietet oder gemäß Absatz 2 eine Dienstleistung erbringt, macht im Angebot mindestens die in Anhang I Abschnitt 20.2 Buchstaben a bis e und m genannten Angaben und gewährt Zugang zur Gebrauchsanweisung.“

  - b) Die Absätze 3 und 4 erhalten folgende Fassung:

    - „(3) Jede natürliche oder juristische Person, die gemäß Absatz 1 ein Produkt anbietet oder gemäß Absatz 2 eine Dienstleistung erbringt, stellt auf Verlangen einer zuständigen Behörde eine Kopie der gemäß Artikel 17 erstellten EU-Konformitätserklärung für das betreffende Produkt zur Verfügung und arbeitet mit den zuständigen Behörden des Mitgliedstaats zusammen, in dem das Produkt oder die Dienstleistung angeboten wird.

    - (4) Ein Mitgliedstaat kann aus Gründen des Schutzes der öffentlichen Gesundheit von dem Erbringer eines Dienstes im Sinne von Artikel 1 Absatz 1 Buchstabe b der Richtlinie (EU) 2015/1535 oder von dem Erbringer einer Dienstleistung gemäß Absatz 2 verlangen, seine Tätigkeit einzustellen.“

- 7. in Artikel 7 wird folgender Unterabsatz angefügt:

    „Unbeschadet der nationalen Rechtsvorschriften über die Ausübung des Arztberufs gilt Unterabsatz 1 auch für Produkte, die für die Erbringung einer Dienstleistung gemäß Artikel 6 Absatz 2 verwendet werden.“

- 8. Artikel 9 Absatz 1 Satz 1 erhält folgende Fassung:

    „Sind keine harmonisierten Normen vorhanden oder sind die einschlägigen harmonisierten Normen nicht ausreichend oder muss Belangen der öffentlichen Gesundheit Rechnung getragen werden, so kann die Kommission nach Anhörung der Koordinierungsgruppe Medizinprodukte im Wege von Durchführungsrechtsakten gemeinsame Spezifikationen (GS) für die in dieser Verordnung festgelegten Anforderungen erlassen, insbesondere in Bezug auf die von den Herstellern zu erstellenden Berichte und Pläne, die in Anhang I aufgeführten grundlegenden Sicherheits- und Leistungsanforderungen, die in den Anhängen II und III aufgeführte technische Dokumentation, die in den Anhängen IX, X und XI festgelegten Konformitätsbewertungsverfahren, die in Anhang XIII festgelegte Leistungsbewertung und die Nachbeobachtung der Leistung nach dem Inverkehrbringen oder die in Anhang XIII und XIV aufgeführten Anforderungen an die Leistungsstudien.“

- 9. Artikel 10 wird wie folgt geändert:

  - a) Die Absätze 3 und 6 werden gestrichen.

  - b) Absatz 8 wird wie folgt geändert:

    - i) Unterabsatz 1 Satz 1 erhält folgende Fassung:

        „Die Hersteller richten ein geeignetes Qualitätsmanagementsystem ein, um sicherzustellen, dass sie über Verfahren verfügen, die gewährleisten, dass die Anforderungen dieser Verordnung auch bei serienmäßiger Herstellung jederzeit eingehalten werden.“

    - ii) Unterabsatz 3 wird gestrichen.

  - c) Absatz 9 wird gestrichen.

  - d) Absatz 10 wird wie folgt geändert:

    - i) In Unterabsatz 1 wird folgender Satz angefügt:

        „Wenn die Mitgliedstaaten festlegen, in welcher Amtssprache der Union die in Anhang I Abschnitt 20 genannten Informationen oder sonstige vom Hersteller bereitzustellende Informationen verfügbar zu machen sind, erwägen sie, ob sie eine andere Amtssprache der Union akzeptieren, in der diese Informationen bereitgestellt werden, wobei sie die technischen Kenntnisse, die Erfahrung, die Ausbildung oder die Schulung der durchschnittlichen vorgesehenen Nutzer berücksichtigen.“

    - ii) Unterabsatz 2 wird gestrichen.

  - e) Absatz 12 wird gestrichen.

  - f) In Absatz 13 werden die Unterabsätze 3 und 4 gestrichen.

  - g) Absatz 14 erhält folgende Fassung:

      „(14) Lassen Hersteller ihre Produkte von einer anderen natürlichen oder juristischen Person konzipieren und herstellen, so ist die Identität dieser Person Teil der gemäß Artikel 26 Absatz 3 vorzulegenden Angaben. In diesen Fällen stellt der Hersteller sicher, dass die einschlägigen Teile der technischen Dokumentation von der juristischen oder natürlichen Person, die das Produkt konzipiert und hergestellt hat, gemäß den Absätzen 4 und 7 erstellt, auf dem neuesten Stand gehalten und den zuständigen Behörden auf Verlangen zur Verfügung gestellt werden. Darüber hinaus erstellt der Hersteller die übrigen Teile der technischen Dokumentation, hält sie auf dem neuesten Stand und stellt sie den zuständigen Behörden auf Verlangen zur Verfügung, insbesondere die in Anhang II Abschnitt 2 und in Anhang III genannten Teile.“

  - h) Absatz 15 wird gestrichen.

- 10. Artikel 10a wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 2 Satz 1 erhält folgende Fassung:

      „Die in Unterabsatz 1 genannten Informationen werden mindestens sechs Monate vor der voraussichtlichen Unterbrechung oder Beendigung übermittelt oder, wenn dies nicht möglich ist, unverzüglich, nachdem der Hersteller von der voraussichtlichen Unterbrechung oder Beendigung Kenntnis erlangt hat.“

  - b) Es werden folgende Absätze 4, 5 und 6 angefügt:

    - „(4) Die Kommission richtet erforderlichenfalls in Zusammenarbeit mit der EMA ein IT-System ein, betreibt und verwaltet es, um die Meldung und den Informationsaustausch über Fälle der Unterbrechung oder Beendigung der Versorgung mit Produkten gemäß den Absätzen 1, 2 und 3 zu erleichtern. Dieses IT-System wird in die in Artikel 30 genannte europäische Datenbank für Medizinprodukte integriert oder ist mit ihr interoperabel. Es ermöglicht außerdem Gesundheitseinrichtungen und Angehörigen der Gesundheitsberufe, die zuständigen Behörden über die Nichtverfügbarkeit oder das unmittelbare Risiko der Nichtverfügbarkeit von Produkten zu unterrichten, die für die Ausübung ihrer beruflichen Tätigkeit erforderlich sind.

    - (5) Die EMA entwickelt in Zusammenarbeit mit der durch Artikel 21 der Verordnung (EU) 2022/123 des Europäischen Parlaments und des Rates*** eingerichteten hochrangigen Lenkungsgruppe für Engpässe bei Medizinprodukten (im Folgenden „MDSSG“) eine Methodik, um die Produkte oder Produktkategorien zu ermitteln, bei denen vernünftigerweise vorhersehbar ist, dass eine Unterbrechung oder Beendigung der Lieferung zu einem schwerwiegenden Schaden oder zur Gefahr eines schwerwiegenden Schadens für die Patienten oder die öffentliche Gesundheit im Sinne von Absatz 1 führen könnte. Auf der Grundlage dieser Methodik erstellt die EMA in Zusammenarbeit mit der MDSSG und im Einvernehmen mit der Kommission eine Liste der Produkte oder Produktkategorien, auf die die Absätze 1, 2 und 3 Anwendung finden, veröffentlicht diese und hält sie auf dem neuesten Stand. Für die Zwecke dieses Absatzes können die Koordinierungsgruppe Medizinprodukte, Vertreter von Herstellern, andere einschlägige Akteure aus der Lieferkette der Medizinproduktebranche sowie Vertreter von Angehörigen der Gesundheitsberufe, Patienten- und Verbrauchervertreter bei Bedarf konsultiert werden.

    - (6) Die zuständigen Behörden der Mitgliedstaaten oder die Kommission können von den Herstellern der in der gemäß Absatz 5 erstellten Liste aufgeführten Produkte verlangen, alle erforderlichen Informationen zu Risiken und Schwachstellen innerhalb der Lieferkette bereitzustellen, die die Versorgung mit diesen Produkten beeinträchtigen können, einschließlich der Produktionskapazität und des Absatzvolumens.

    - _______________________________

    - *** Verordnung (EU) 2022/123 des Europäischen Parlaments und des Rates vom 25. Januar 2022 zu einer verstärkten Rolle der Europäischen Arzneimittel-Agentur bei der Krisenvorsorge und -bewältigung in Bezug auf Arzneimittel und Medizinprodukte (ABl. L 20 vom 31.1.2022, S. 1, ELI: http://data.europa.eu/eli/reg/2022/123/oj).“

- 11. In Artikel 11 werden die Absätze 4 und 5 gestrichen.

- 12. Artikel 14 Absatz 2 wird wie folgt geändert:

  - a) Unterabsatz 1 Buchstabe d erhält folgende Fassung:

    - „d) gegebenenfalls wurde vom Hersteller eine UDI gemäß Artikel 24 Absatz 3 vergeben.“

  - b) Unterabsatz 2 erhält folgende Fassung:

  - „Zur Erfüllung der Anforderungen gemäß Unterabsatz 1 kann der Händler ein Probenahmeverfahren anwenden, das für die von ihm gelieferten Produkte repräsentativ ist.“

- 13. Artikel 15 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Hersteller verfügen in ihrer Organisation über mindestens eine Person mit dem erforderlichen Fachwissen auf dem Gebiet der In-vitro-Diagnostika, die für die Einhaltung der Regulierungsvorschriften verantwortlich ist.“

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Kleinst- und Kleinunternehmen im Sinne der Empfehlung 2003/361/EG der Kommission**** sind nicht verpflichtet, in ihrer Organisation eine für die Einhaltung der Regulierungsvorschriften verantwortliche Person zur Verfügung zu haben; sie müssen jedoch auf eine solche Person zurückgreifen können.

    - ______________

    - **** Empfehlung der Kommission vom 6. Mai 2003 betreffend die Definition der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen (ABl. L 124 vom 20.5.2003, S. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj).“

  - c) Absatz 3 Buchstabe c erhält folgende Fassung:

    - „c) die Verpflichtungen zur Überwachung nach dem Inverkehrbringen gemäß Artikel 78 erfüllt werden;“

  - d) Absatz 6 erhält folgende Fassung:

    - „(6) Bevollmächtigte müssen dauerhaft und ständig auf mindestens eine Person mit dem erforderlichen Fachwissen über die Regulierungsanforderungen für In-vitro-Diagnostika in der Union zurückgreifen können, die für die Einhaltung der Regulierungsvorschriften verantwortlich ist.“

- 14. Artikel 16 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) In Unterabsatz 1 erhalten die einleitenden Worte folgende Fassung:

        „Ein Händler, ein Importeur oder eine andere natürliche oder juristische Person, die ein Produkt in Verkehr bringt oder in Betrieb nimmt, übernimmt die den Herstellern obliegenden Pflichten, wenn sie eine der folgenden Handlungen vornimmt:“

    - ii) Unterabsatz 2 erhält folgende Fassung:

        „Unterabsatz 1 gilt nicht für Angehörige der Gesundheitsberufe oder für andere Personen, die, ohne als Hersteller zu gelten, ein bereits in Verkehr befindliches Produkt ohne Änderung seiner Zweckbestimmung für einen bestimmten Patienten montieren oder anpassen.“

  - b) Absatz 4 wird gestrichen.

- 15. Artikel 17 wird wie folgt geändert:

  - a) Absatz 1 Satz 1 erhält folgende Fassung:

      Die EU-Konformitätserklärung besagt, dass die in dieser Verordnung genannten Anforderungen hinsichtlich des von dieser Erklärung erfassten Produkts erfüllt wurden.“

  - b) Es wird folgender Absatz 2a eingefügt:

    - „(2a) Konformitätserklärungen gemäß den Absätzen 1 und 2 können in elektronischer Form bereitgestellt werden.“

- 16. Es wird folgender Artikel 19a eingefügt:

**„Artikel 19a**

Kits

    Ein Kit kann folgende Komponenten enthalten:

  - a) In-vitro-Diagnostika oder deren Zubehör, die/das jeweils einzeln mit der CE-Kennzeichnung gemäß dieser Verordnung versehen sein können/kann;

  - b) Medizinprodukte oder deren Zubehör, die/das mit der CE-Kennzeichnung gemäß der Verordnung (EU) 2017/745 versehen sind/ist;

  - c) andere Produkte, die im Rahmen der In-vitro-Diagnostik verwendet werden oder deren Vorhandensein im Kit anderweitig gerechtfertigt ist und die den für sie geltenden Rechtsvorschriften der Union entsprechen.“

- 17. Die Überschrift des Kapitels III erhält folgende Fassung:

    „IDENTIFIZIERUNG UND RÜCKVERFOLGBARKEIT VON PRODUKTEN, REGISTRIERUNG VON PRODUKTEN UND WIRTSCHAFTSAKTEUREN, KURZBERICHT ÜBER SICHERHEIT UND LEISTUNG, EUROPÄISCHE DATENBANK FÜR MEDIZINPRODUKTE“

- 18. Artikel 24 wird wie folgt geändert:

  - a) In Absatz 1 wird folgender Buchstabe ba eingefügt:

    - „ba) einer Basis-UDI-DI im Sinne von Anhang VI Teil C;“

  - b) Absatz 2 wird wie folgt geändert:

    - i) Buchstabe d erhält folgende Fassung:

      - „d) die Stelle gewährt allen interessierten Nutzern unter vorab festgelegten und transparenten Bedingungen, die die Interessen von Kleinst-, kleinen und mittleren Unternehmen im Sinne der Empfehlung 2003/361/EG berücksichtigen, Zugang zu ihrem UDI-Zuteilungssystem;“

    - ii) unter Buchstabe e wird folgende Ziffer iv angefügt:

      - „iv) ihr UDI-Zuteilungssystem Herstellern, die Kleinst- und kleine Unternehmen im Sinne der Empfehlung 2003/361/EG sind, zu Vorzugsbedingungen anbieten, die den besonderen Erfordernissen dieser Unternehmen Rechnung tragen und ihrer Größe angemessen sind.“

  - c) Absatz 3 erhält folgende Fassung:

    - „(3) Bevor der Hersteller ein Produkt, das kein Produkt für Leistungsstudien ist, in Verkehr bringt, weist er dem Produkt gemäß den Vorschriften der von der Kommission gemäß Absatz 2 benannten Zuteilungsstelle eine Basis-UDI-DI und eine UDI im Sinne von Anhang VI Teil C zu. Gegebenenfalls weist der Hersteller allen höheren Verpackungsebenen eine UDI-DI zu.“

  - d) Es wird folgender Absatz 3a eingefügt:

    - „(3a) Bei Produkten, die einer Konformitätsbewertung gemäß Artikel 48 Absätze 3 und 4, Artikel 48 Absatz 7 Unterabsatz 2, Artikel 48 Absatz 8 und Artikel 48 Absatz 9 Unterabsatz 2 unterzogen werden, erfolgt die Zuweisung der Basis-UDI-DI gemäß Absatz 1 des vorliegenden Artikels, bevor der Hersteller bei einer Benannten Stelle diese Bewertung beantragt.“

  - e) In Absatz 10 erhalten die Buchstaben a und b folgende Fassung:

    - „a) die in Anhang VI Teil A und B festgelegte Informationsliste zur Einbeziehung des technischen Fortschritts geändert wird und

    - b) Anhang VI unter Berücksichtigung der bei der Umsetzung des UDI-Systems gewonnenen Erfahrungen oder internationaler Entwicklungen und des technischen Fortschritts im Bereich der einmaligen Produktkennung geändert wird.“

- 19. Artikel 26 erhält folgende Fassung:

**„Artikel 26**

Registrierung von Produkten

  - (1) Bevor ein Produkt, das kein Produkt für Leistungsstudien ist, in Verkehr gebracht wird, gibt der Hersteller die Basis-UDI-DI zusammen mit den anderen in Anhang VI Teil B aufgeführten zentralen Datenelementen zu diesem Produkt in die UDI-Datenbank ein. Der Hersteller hält die in der UDI-Datenbank bereitgestellten Informationen auf dem neuesten Stand.

  - (2) Für Produkte, die Gegenstand einer Konformitätsbewertung gemäß Artikel 48 Absätze 3 und 4, Artikel 48 Absatz 7 Unterabsatz 2, Artikel 48 Absatz 8 und Artikel 48 Absatz 9 Unterabsatz 2 sind, bestätigt die Benannte Stelle in Eudamed, dass die in Anhang VI Teil B genannten Informationen korrekt sind.“

- 20. In Artikel 27 Absatz 2 wird folgender Satz angefügt:

    „Sofern nationale Datenbanken für Händler Informationen über Produkte verlangen, ermöglichen diese Datenbanken den Abruf der Produktinformationen aus den in Artikel 30 Absatz 2 Buchstaben a und b genannten elektronischen Systemen.“

- 21. Artikel 28 wird wie folgt geändert:

  - a) Die Überschrift erhält folgende Fassung:

      „Registrierung von Wirtschaftsakteuren“

  - b) Die Absätze 1 und 2 erhalten folgende Fassung:

    - „(1) Bevor sie ein Produkt in Verkehr bringen, geben die Hersteller, Bevollmächtigten und Importeure die Angaben gemäß Anhang VI Teil A in das elektronische System gemäß Artikel 27 ein, um sich registrieren zu lassen, sofern sie sich nicht bereits gemäß diesem Artikel registriert haben. In den Fällen, in denen das Konformitätsbewertungsverfahren die Mitwirkung einer Benannten Stelle gemäß Artikel 48 erfordert, werden die Angaben gemäß Anhang VI Teil A an dieses elektronische System übermittelt, bevor der Antrag an die Benannte Stelle gerichtet wird.

    - (2) Die zuständige Behörde überprüft unverzüglich die gemäß Absatz 1 eingegebenen Daten, ruft aus dem elektronischen System gemäß Artikel 27 eine einmalige Registrierungsnummer (‚SRN‘ – Single Registration Number) ab und teilt sie dem Hersteller, dem Bevollmächtigten oder dem Importeur zu.“

  - c) In Absatz 4 werden die Worte „von einer Woche“ durch die Angabe „von zwei Wochen“ ersetzt.

  - d) Absatz 6 wird gestrichen.

  - e) Absatz 7 erhält folgende Fassung:

    - „(7) Die gemäß Absatz 1 des vorliegenden Artikels in das elektronische System gemäß Artikel 27 eingegebenen Daten sind der Öffentlichkeit zugänglich, mit Ausnahme der Informationen über die für die Einhaltung der Regulierungsvorschriften verantwortliche Person gemäß Anhang VI Teil A Nummer 1.4.“

- 22. Artikel 29 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Für therapiebegleitende Diagnostika, Produkte der Klasse C zur Eigenanwendung und Produkte der Klasse D, außer Produkten für Leistungsstudien, erstellt der Hersteller einen Kurzbericht über Sicherheit und Leistung.

        Der Kurzbericht über Sicherheit und Leistung ist so abzufassen, dass er für den bestimmungsgemäßen Anwender verständlich ist.

        Der Entwurf dieses Kurzberichts über Sicherheit und Leistung bildet einen Teil der Dokumentation, die der an der Konformitätsbewertung beteiligten Benannten Stelle gemäß Artikel 48 zu übermitteln ist. Der Hersteller stellt sicher, dass der Kurzbericht über Sicherheit und Leistung für die Öffentlichkeit über Eudamed zugänglich ist, und er gibt auf der Kennzeichnung oder in der Gebrauchsanweisung an, wo der Kurzbericht abrufbar ist. “

  - b) Absatz 2 wird wie folgt geändert:

    - i) Buchstabe a erhält folgende Fassung:

      - „a) die Identifizierung des Produkts und des Herstellers, einschließlich der Basis-UDI-DI und, falls bereits ausgestellt, der SRN, sowie die Angabe, wo die Gebrauchsanweisung in Eudamed zu finden ist;“

    - ii) Die Buchstaben b, f, g und h werden gestrichen.

- 23. In Artikel 30 Absatz 2 wird folgender Unterabsatz angefügt:

    „Abweichend von Unterabsatz 1 kann die Kommission beschließen, dass eines oder mehrere der in dem genannten Unterabsatz aufgeführten elektronischen Systeme nicht in Eudamed aufgenommen werden. In diesem Fall stellt die Kommission sicher, dass das elektronische System mit Eudamed interoperabel ist.“

- 24. Artikel 31 erhält folgende Fassung:

**„Artikel 31**

Anwendung von Kapitel IV der Verordnung (EU) 2017/745

    Artikel 35 und Artikel 37 bis 50 der Verordnung (EU) 2017/745 gelten entsprechend für:

  - a) die Behörden, die für die von den Mitgliedstaaten für die Zwecke der vorliegenden Verordnung zu benennenden Benannten Stellen und deren Erfahrungsaustausch zuständig sind;

  - b) die Konformitätsbewertungsstellen, die die Benennung nach der vorliegenden Verordnung beantragen, sowie die Bewertung ihrer Anträge;

  - c) die Benennung von Sachverständigen für gemeinsame Bewertungen sowie die Finanzierung von Tätigkeiten im Zusammenhang mit der Benennung und Überwachung der Benannten Stellen;

  - d) das Benennungs- und Notifizierungsverfahren für Benannte Stellen nach der vorliegenden Verordnung, ihre Zweigstellen und Unterauftragnehmer sowie ihre Kennnummer;

  - e) die Sprachenregelung;

  - f) die Überwachung der Benannten Stellen;

  - g) Änderungen hinsichtlich der Benennung und Notifizierung der Benannten Stellen sowie Anfechtung ihrer Kompetenz;

  - h) die Koordinierung der Benannten Stellen;

  - i) den Zugang zu den Benannten Stellen und Gebühren.“

- 25. Artikel 32 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Die Benannten Stellen erfüllen die Aufgaben, für die sie gemäß dieser Verordnung benannt sind, im öffentlichen Interesse. Sie erfüllen die organisatorischen und allgemeinen Anforderungen sowie die Anforderungen an Qualitätsmanagement, Ressourcen und Verfahren, die in Anhang VII festgelegt sind und die erforderlich sind, um diese Aufgaben wirksam, unabhängig, sorgfältig und zügig zu erfüllen.

    - Die Benannten Stellen, die für Konformitätsbewertungstätigkeiten in Bezug auf Produkte benannt sind, bei denen es sich um Hochrisiko-KI-Systeme im Sinne von Artikel 6 Absatz 1 der Verordnung (EU) 2024/1689 handelt oder die Hochrisiko-KI-Systeme als Sicherheitskomponenten verwenden, erfüllen zudem die in Artikel 31 Absätze 4, 5, 10 und 11 der genannten Verordnung festgelegten Anforderungen.“

  - b) Es wird folgender Absatz 4 angefügt:

    - „(4) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um Anhang VII zu ändern, um diesen an den technischen und wissenschaftlichen Fortschritt im Bereich der Konformitätsbewertung von In-vitro-Diagnostika, einschließlich der Entwicklungen auf internationaler Ebene, anzupassen.“

- 26. Die Artikel 33 bis 46 werden aufgehoben.

- 27. Artikel 47 wird wie folgt geändert:

  - a) Absatz 2 erhält folgende Fassung:

    - „(2) Die zuständigen Behörden koordinieren ihre Tätigkeiten bei der Festlegung der Klassifizierung eines Produkts oder einer Produktkategorie oder Produktgruppe. Die Ergebnisse der Koordinierungstätigkeiten der zuständigen Behörden, einschließlich der Ergebnisse etwaiger von einer zuständigen Behörde gemäß den Artikeln 47a oder 47b erlassener Entscheidungen oder Maßnahmen sowie etwaiger im Zusammenhang mit der Klassifizierung von einem Expertengremium abgegebener Stellungnahmen, werden öffentlich zugänglich gemacht, ohne dass dabei vertrauliche Informationen im Sinne des Artikels 102 offengelegt werden.“

  - b) Absatz 3 Buchstabe b erhält folgende Fassung:

    - „b) die Klassifizierung – abweichend von Anhang VIII – in eine andere Klasse eines Produkts, einer Produktkategorie oder einer Produktgruppe aus Gründen der öffentlichen Gesundheit gemäß neuesten wissenschaftlichen Erkenntnissen oder auf der Grundlage von Informationen, die im Laufe der Vigilanz- und Marktüberwachungstätigkeiten verfügbar werden, unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit und der Klassifizierung von Produkten auf internationaler Ebene.“

  - c) Absatz 5 erhält folgende Fassung:

    - „(5) Um die einheitliche Anwendung der in Anhang VIII festgelegten Vorschriften sicherzustellen und unter Berücksichtigung der einschlägigen wissenschaftlichen Stellungnahmen der zuständigen wissenschaftlichen Ausschüsse oder Expertengremien kann die Kommission Durchführungsrechtsakte erlassen, soweit dies für die Lösung von Problemen im Zusammenhang mit Unterschieden bei der Auslegung und der praktischen Anwendung erforderlich ist.“

  - d) Es wird folgender Absatz 7 angefügt:

    - „(7) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zur Änderung des Anhangs VIII zu erlassen, um ihn an den technischen oder wissenschaftlichen Fortschritt anzupassen oder um Entwicklungen bei der Klassifizierung von Produkten auf internationaler Ebene Rechnung zu tragen.“

- 28. Es werden folgende Artikel 47a und 47b eingefügt:

**„Artikel 47a**

Klassifizierung im Falle einer Streitigkeit zwischen Hersteller und Benannter Stelle

  - (1) Ein Hersteller oder eine Benannte Stelle kann jede zwischen ihnen aus der Anwendung von Anhang VIII entstehende Streitigkeit an die zuständige Behörde des Mitgliedstaats verweisen, in dem der Hersteller seine eingetragene Niederlassung hat. In Fällen, in denen der Hersteller keine eingetragene Niederlassung in der Union hat und noch keinen Bevollmächtigten ernannt hat, wird die Angelegenheit an die zuständige Behörde des Mitgliedstaats verwiesen, in dem der in Anhang IX Abschnitt 2.2 Absatz 2 Buchstabe b letzter Gedankenstrich genannte Bevollmächtigte seine eingetragene Niederlassung hat.

      Die zuständige Behörde des Mitgliedstaats, in dem der Hersteller seine eingetragene Niederlassung hat, setzt die Koordinierungsgruppe Medizinprodukte und die Kommission über ihre Entscheidung in Kenntnis. Die Entscheidung wird auf Verlangen zur Verfügung gestellt.

  - (2) Innerhalb von 30 Tagen nach Eingang der in Absatz 1 genannten Verweisung konsultiert die zuständige Behörde die anderen Mitgliedstaaten zu ihrem Entwurf einer Klassifizierungsentscheidung.

  - (3) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 2 genannten Konsultation von einem Mitgliedstaat kein begründeter Widerspruch erhoben, erlässt die zuständige Behörde ihre Entscheidung innerhalb von 90 Tagen nach Eingang der in Absatz 1 genannten Verweisung.

  - (4) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 2 genannten Konsultation von einem Mitgliedstaat ein begründeter Widerspruch gegen die mitgeteilte beabsichtigte Entscheidung über die Klassifizierung erhoben, so wird die Angelegenheit an ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 verwiesen. Dieses Expertengremium gibt innerhalb von 30 Tagen eine Stellungnahme zur Klassifizierung des Produkts ab. Die zuständige Behörde kann das Expertengremium um Klarstellungen zu seiner Stellungnahme ersuchen.

  - (5) Innerhalb von 30 Tagen nach Eingang der Stellungnahme des Expertengremiums oder einer etwaigen Klarstellung, um die ersucht wurde, erlässt die zuständige Behörde ihre Entscheidung und trägt dabei der Stellungnahme des Expertengremiums weitestgehend Rechnung. Sie unterrichtet die anderen Mitgliedstaaten und die Kommission unverzüglich über ihre Entscheidung.

  - (6) Die Kommission kann im Wege von Durchführungsrechtsakten weitere Einzelheiten des Verfahrens für die Anwendung dieses Artikels und des Artikels 47b festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.

**Artikel 47b**

Anfechtung der Klassifizierung CE-gekennzeichneter Produkte

  - (1) Ist eine zuständige Behörde nach Durchführung einer Bewertung gemäß Artikel 89 der Auffassung, dass ein gemäß Artikel 18 CE-gekennzeichnetes Produkt nicht im Einklang mit Anhang VIII klassifiziert wurde, so konsultiert sie die anderen Mitgliedstaaten zu der von ihr vorgesehenen Maßnahme hinsichtlich der Klassifizierung des Produkts.

  - (2) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 1 genannten Konsultation von einem Mitgliedstaat kein begründeter Widerspruch erhoben, kann die zuständige Behörde die Maßnahme zur Klassifizierung des betreffenden Produkts erlassen und unterrichtet die anderen Mitgliedstaaten und die Kommission unter Angabe der Gründe für die Entscheidung.

  - (3) Wird innerhalb von 30 Tagen nach Eingang der in Absatz 1 genannten Konsultation von einem Mitgliedstaat ein begründeter Widerspruch gegen die mitgeteilte beabsichtigte Maßnahme zur Klassifizierung erhoben, wird die Angelegenheit an ein in Artikel 106 der Verordnung (EU) 2017/745 genanntes Expertengremium verwiesen, das innerhalb von 30 Tagen eine Stellungnahme zur Klassifizierung des Produkts abgibt. Die zuständige Behörde kann das Expertengremium um Klarstellungen zu seiner Stellungnahme ersuchen.

  - (4) Die zuständige Behörde trägt der Stellungnahme des Expertengremiums weitestgehend Rechnung. Trifft die zuständige Behörde eine Maßnahme zur Klassifizierung, unterrichtet sie die anderen Mitgliedstaaten und die Kommission unverzüglich über diese Maßnahme.“

- 29. Artikel 48 wird wie folgt geändert:

  - a) Absatz 3 Unterabsätze 2 und 3 werden gestrichen.

  - b) Absatz 4 Unterabsatz 2 wird gestrichen.

  - c) Die Absätze 5 und 6 werden gestrichen.

  - d) Absatz 7 erhält folgende Fassung:

    - „(7) Hersteller von Produkten der Klasse C, bei denen es sich nicht um Produkte für Leistungsstudien handelt, werden einer Konformitätsbewertung gemäß Anhang IX Kapitel I und III unterworfen.“

  - e) Absatz 8 Unterabsatz 2 wird gestrichen.

  - f) Absatz 9 erhält folgende Fassung:

    - „(9) Hersteller von Produkten der Klasse B, bei denen es sich nicht um Produkte für Leistungsstudien handelt, werden einer Konformitätsbewertung gemäß Anhang IX Kapitel I und III unterworfen.“

  - g) Es wird folgender Absatz 9a eingefügt:

    - „(9a) Hersteller von Produkten der Klasse B, bei denen es sich nicht um Produkte für Leistungsstudien handelt, können sich anstatt des Konformitätsbewertungsverfahrens gemäß Absatz 9 für eine Konformitätsbewertung gemäß Anhang X in Kombination mit einer Konformitätsbewertung gemäß Anhang XI – außer dessen Abschnitt 5 – entscheiden.“

  - h) Absatz 10 Unterabsatz 2 wird gestrichen.

  - i) Es werden folgende Absätze 10a und 10b eingefügt:

    - „(10a) Bei Produkten zur Eigenanwendung gilt zusätzlich zu den gemäß Absatz 3, 7 oder 9 anwendbaren Verfahren auch das in Anhang IX Abschnitt 5.1 festgelegte Verfahren.

    - (10b) Bei therapiebegleitenden Diagnostika gilt zusätzlich zu den gemäß Absatz 3, 4, 7 oder 8 anwendbaren Verfahren auch das in Anhang IX Abschnitt 5.2 bzw. das in Anhang X Abschnitt 3 Buchstabe k festgelegte Verfahren.“

  - j) Die Absätze 12 und 13 erhalten folgende Fassung:

    - „(12) Die Unterlagen zu den in den Absätzen 1 bis 4 und 7 bis 10b genannten Verfahren müssen in einer Amtssprache der Union vorliegen, mit der die Benannte Stelle einverstanden ist.

    - (13) Die Kommission kann im Wege von Durchführungsrechtsakten die detaillierten Vorkehrungen und Verfahrenselemente der Konformitätsbewertungsverfahren in Bezug auf einen der folgenden Aspekte festlegen:

      - a) bei Produkten der Klassen B und C die Grundlage für die Auswahl des repräsentativen Produkts für die Bewertung der technischen Dokumentation gemäß Anhang IX Abschnitt 2.3;

      - b) Modalitäten der von den Benannten Stellen gemäß Anhang IX Abschnitt 3.4 unter Berücksichtigung der Risikoklasse und der Art der Produkte durchzuführenden unangekündigten Vor-Ort-Audits und Stichprobenprüfungen;

      - c) Häufigkeit der Stichproben bei hergestellten Produkten oder Produktchargen der Klasse D, die gemäß Anhang IX Abschnitt 4.12 sowie Anhang XI Abschnitt 5.1 an ein gemäß Artikel 100 benanntes EU-Referenzlaboratorium geschickt werden müssen;

      - d) physische Kontrollen, Laboruntersuchungen oder andere Tests, die von den Benannten Stellen im Rahmen der Stichprobenprüfungen, der Bewertung der technischen Dokumentation und der Musterprüfung durchzuführen sind;

      - e) Modalitäten der Konformitätsbewertungsverfahren für in Artikel 48a genannte bahnbrechende Produkte und Produkte für seltene Erkrankungen.

          Die Durchführungsrechtsakte gemäß Unterabsatz 1 werden im Einklang mit dem Prüfverfahren gemäß Artikel 107 Absatz 3 erlassen.“

  - k) Es wird folgender Absatz 14 angefügt:

    - „(14) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um die Anhänge IX, X und XI zu ändern, um sie an den technischen oder wissenschaftlichen Fortschritt oder an Entwicklungen bei der Konformitätsbewertung von Produkten auf internationaler Ebene anzupassen und um den Erfordernissen bestimmter Produkte im Hinblick auf ihre besonderen Merkmale Rechnung zu tragen.“

- 30. Es werden folgende Artikel 48a und 48b eingefügt:

**„Artikel 48a**

Konformitätsbewertung von bahnbrechenden Produkten und Produkten für seltene Erkrankungen

  - (1) Für die Konformitätsbewertung von bahnbrechenden Produkten und von Produkten für seltene Erkrankungen, bei denen eine Benannte Stelle an der Konformitätsbewertung mitwirkt, gelten die in Artikel 48 festgelegten Verfahren vorbehaltlich der im vorliegenden Artikel festgelegten besonderen Regelungen.

  - (2) Ein Produkt gilt als bahnbrechendes Produkt, wenn es die folgenden Kriterien erfüllt:

    - a) Es ist davon auszugehen, dass damit eine große Neuheit in Bezug auf die Produkttechnologie, das damit verbundene klinische Verfahren oder die Anwendung des Produkts in der klinischen Praxis in der Union eingeführt wird.

    - b) Es ist davon auszugehen, dass es für Patienten oder die öffentliche Gesundheit im Hinblick auf eine lebensbedrohliche oder irreversibel beeinträchtigende Krankheit oder ein solches Leiden in folgender Hinsicht einen erheblichen positiven klinischen Nutzen bietet:

      - i) indem es einen erheblichen positiven klinischen oder gesundheitlichen Nutzen im Vergleich zu den verfügbaren Alternativen und dem Stand der Technik bietet,

      - ii) indem es eine medizinische Versorgungslücke schließt, wenn für diese Zweckbestimmung keine oder keine ausreichenden verfügbaren Alternativen verfügbar sind.

  - (3) Ein Produkt gilt als Produkt für seltene Erkrankungen, wenn es die folgenden Kriterien erfüllt:

    - a) Es ist dazu bestimmt, Informationen über eine Krankheit oder ein Leiden, die/das in der Union bei nicht mehr als 12 000 Personen pro Jahr auftritt, bereitzustellen.

    - b) Mindestens eines der folgenden Kriterien ist erfüllt:

      - i) Es gibt keine ausreichenden Alternativen.

      - ii) Es ist davon auszugehen, dass das Produkt im Vergleich zu verfügbaren Alternativen oder dem Stand der Technik einen klinischen Nutzen bietet.

  - (4) Auf einen ordnungsgemäß begründeten Antrag eines Herstellers oder einer Benannten Stelle hin gibt ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 eine Stellungnahme dazu ab, ob die in Absatz 2 bzw. 3 dieses Artikels genannten Kriterien erfüllt sind. Diese Stellungnahme wird auf einer dafür vorgesehenen Website veröffentlicht, ohne dass dabei vertrauliche Informationen im Sinne des Artikels 102 offengelegt werden, und sie ist von dem Hersteller und der Benannten Stelle gebührend zu berücksichtigen.

  - (5) Bestätigt die Stellungnahme des Expertengremiums die Erfüllung der in Absatz 2 bzw. 3 dieses Artikels genannten Kriterien, kann der Hersteller eines bahnbrechenden Produkts bzw. eines Produkts für seltene Erkrankungen sich von den Expertengremien gemäß Artikel 106 der Verordnung (EU) 2017/745 zu seiner Leistungsbewertungsstrategie sowie zu geeigneten analytischen oder klinischen Daten für die Leistungsbewertung des Produkts beraten lassen.

  - (6) Für ein bestätigtes bahnbrechendes Produkt bzw. ein Produkt für seltene Erkrankungen priorisiert die an dem in Artikel 48 festgelegten Konformitätsbewertungsverfahren mitwirkende Benannte Stelle die Konformitätsbewertung und wendet gegebenenfalls eine fortlaufende Bewertung an, um die Bewertungsfristen zu verkürzen.

      Die Benannte Stelle trägt einer von dem Expertengremium gemäß Absatz 4 oder 5 abgegebenen Stellungnahme oder erteilten Beratung gebührend Rechnung und legt, sofern sie dieser Stellungnahme oder Beratung nicht folgt, eine ordnungsgemäße Begründung dafür vor. Die Benannte Stelle kann das Expertengremium um Klarstellung der von ihm abgegebenen Stellungnahme ersuchen.

  - (7) Die Benannte Stelle stellt gemäß Artikel 51 eine Bescheinigung aus, wenn die klinischen Nachweise vor dem Inverkehrbringen, auch wenn sie auf begrenzten klinischen Leistungsdaten beruhen, als ausreichend erachtet werden, sofern eine der folgenden Bedingungen erfüllt ist:

    - a) Der Nutzen der unmittelbaren Verfügbarkeit des Produkts auf dem Markt überwiegt das Risiko, das damit verbunden ist, dass zusätzliche klinische Leistungsdaten noch erforderlich sind.

    - b) Das Nutzen-Risiko-Verhältnis des Produkts ist günstig, und der Hersteller verpflichtet sich, zusätzliche Daten aus Tätigkeiten der Nachbeobachtung der Leistung nach dem Inverkehrbringen bereitzustellen.

      Gegebenenfalls begrenzt die Benannte Stelle die Gültigkeit der Bescheinigung und legt gemäß Artikel 51 etwaige Bedingungen oder Einschränkungen der Gültigkeit der Bescheinigung fest, wie etwa spezifische Maßnahmen der Nachbeobachtung der Leistung nach dem Inverkehrbringen, die innerhalb eines festgelegten Zeitraums durchzuführen sind.

  - (8) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um diesen Artikel zu ändern, um ihn an den technischen und wissenschaftlichen Fortschritt anzupassen und um Entwicklungen bei der Konformitätsbewertung von bahnbrechenden Produkten oder Produkten für seltene Erkrankungen auf internationaler Ebene Rechnung zu tragen.

  - (9) Die Kommission kann im Wege von Durchführungsrechtsakten weitere Einzelheiten des in diesem Artikel festgelegten Verfahrens für die Konformitätsbewertung von bahnbrechenden Produkten oder Produkten für seltene Erkrankungen festlegen. Diese Durchführungsrechtsakte werden im Einklang mit dem Prüfverfahren gemäß Artikel 107 Absatz 3 erlassen.

**Artikel 48b**

Digitalisierung der technischen Dokumentation, der Konformitätsbewertung und der Berichte

  - (1) Der Hersteller kann die technische Dokumentation sowie alle nach dieser Verordnung erforderlichen Berichte oder sonstigen Unterlagen in einem digitalen Format, insbesondere in einem strukturierten maschinenlesbaren Format, erstellen und bereitstellen, sofern es in ein vom Menschen lesbares Format umgewandelt werden kann und eine Versionskontrolle besteht, die die Durchführung rückblickender Konformitätsprüfungen ermöglicht. Sind die technische Dokumentation, die Berichte oder sonstige Unterlagen einer Benannten Stelle vorzulegen und von dieser zu bewerten, vereinbart der Hersteller mit der Benannten Stelle das digitale Format.

  - (2) Ist dies erforderlich, um sicherzustellen, dass das digitale Format der technischen Dokumentation, der Berichte oder sonstigen Unterlagen zuverlässig, interoperabel und standardisiert ist, kann die Kommission mittels GS gemäß Artikel 9 Mindestanforderungen oder funktionale Spezifikationen für das digitale Format festlegen.“

- 31. Artikel 49 Absatz 5 erhält folgende Fassung:

  - „(5) Die Benannten Stellen und ihre Mitarbeiter führen ihre Konformitätsbewertungstätigkeiten im öffentlichen Interesse und mit höchster beruflicher Integrität und der erforderlichen technischen und wissenschaftlichen Kompetenz in dem betreffenden Bereich durch; sie dürfen keinerlei Druck oder Einflussnahme, insbesondere finanzieller Art, ausgesetzt sein, der/die sich auf ihre Beurteilung oder die Ergebnisse ihrer Konformitätsbewertungstätigkeit auswirken könnte und der/die insbesondere von Personen oder Personengruppen ausgeht, die ein Interesse am Ergebnis dieser Tätigkeiten haben.“

- 32. Artikel 50 erhält folgende Fassung:

**„Artikel 50**

Mechanismus zur Kontrolle von Konformitätsbewertungen

  - (1) Die Koordinierungsgruppe Medizinprodukte oder die Kommission kann sich auf der Grundlage begründeter Bedenken in Bezug auf die Sicherheit und die Leistung eines Produkts durch ein Expertengremium beraten lassen. Zu diesem Zweck kann die Koordinierungsgruppe Medizinprodukte oder die Kommission die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, auffordern, dem Expertengremium ihren Bericht über die Begutachtung der Leistungsbewertung sowie alle nachfolgenden Überwachungsbewertungsberichte zu diesem Produkt vorzulegen. Das Expertengremium kann die Benannte Stelle oder den Hersteller auffordern, alle zusätzlichen für seine Bewertung erforderlichen Informationen vorzulegen.

  - (2) Die Koordinierungsgruppe Medizinprodukte oder die Kommission kann sich auf der Grundlage begründeter Bedenken in Bezug auf die Sicherheit und die Leistung eines Produkts durch ein oder mehrere EU-Referenzlaboratorien auf der Grundlage von Laborprüfungen beraten lassen, sofern das Produkt in den Geltungsbereich der Benennung dieser EU-Referenzlaboratorien fällt. Zu diesem Zweck kann die Koordinierungsgruppe Medizinprodukte oder die Kommission die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, auffordern, den EU-Referenzlaboratorien ihren Bericht über die Begutachtung der Leistungsbewertung sowie alle nachfolgenden Überwachungsbewertungsberichte zu diesem Produkt vorzulegen. Die EU-Referenzlaboratorien können die Benannte Stelle oder den Hersteller auffordern, Muster des Produkts oder zusätzliche für ihre Bewertung erforderliche Informationen vorzulegen.

  - (3) Die Benannte Stelle trägt der vom Expertengremium oder vom EU-Referenzlaboratorium erteilten Beratung weitestgehend Rechnung und ergreift erforderlichenfalls geeignete Maßnahmen, einschließlich der in Artikel 51 Absätze 3 und 4 genannten Maßnahmen.“

- 33. Artikel 51 wird wie folgt geändert:

  - a) Die Absätze 1 und 2 erhalten folgende Fassung:

    - „(1) Die Benannten Stellen stellen Bescheinigungen gemäß den Anhängen IX, X und XI in einer Amtssprache der Union aus und laden sie unverzüglich in Eudamed hoch. In Anhang XII ist niedergelegt, welche Angaben die Bescheinigungen mindestens enthalten müssen.

    - „(2) Die Gültigkeit von Bescheinigungen ist zeitlich nicht begrenzt, es sei denn, die Benannte Stelle hält es in hinreichend begründeten Ausnahmefällen für erforderlich, die Gültigkeitsdauer zu beschränken. In diesen Fällen gibt die Benannte Stelle die Gültigkeitsdauer auf der Bescheinigung an. Ist die Gültigkeitsdauer der Bescheinigung begrenzt, kann die Benannte Stelle auf Antrag des Herstellers nach Durchführung einer Bewertung gemäß Anhang VII Abschnitt 4.11 die Gültigkeit der Bescheinigung verlängern. Ein Nachtrag zu einer Bescheinigung ist so lange gültig wie die Bescheinigung, zu der er gehört.“

  - b) Folgender Absatz 2a wird eingefügt:

    - „(2a) Während der Gültigkeitsdauer der Bescheinigung führt die Benannte Stelle geeignete Überwachungstätigkeiten durch, einschließlich regelmäßiger Überprüfungen unter Berücksichtigung der Entwicklungen des Stands der Technik. Diese Überprüfungen müssen der Risikoklasse des Produkts angemessen sein.“

  - c) Absatz 3 erhält folgende Fassung:

    - „(3) Die Benannten Stellen können Bedingungen für die Gültigkeit der Bescheinigung festlegen, etwa indem sie den Verwendungszweck eines Produkts auf bestimmte Patientengruppen beschränken oder den Hersteller verpflichten, gemäß Anhang XIII Teil B bestimmte Studien zur klinischen Nachbeobachtung nach dem Inverkehrbringen durchzuführen.“

  - d) Absatz 4 Satz 1 erhält folgende Fassung:

      „Stellt eine Benannte Stelle fest, dass der Hersteller die Anforderungen dieser Verordnung nicht mehr erfüllt, setzt sie die erteilte Bescheinigung aus oder widerruft diese oder legt Bedingungen dafür fest, jeweils unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit, sofern die Einhaltung der Anforderungen nicht durch geeignete Korrekturmaßnahmen des Herstellers innerhalb einer von der Benannten Stelle gesetzten angemessenen Frist wiederhergestellt wird.“

  - e) Absatz 5 Satz 1 erhält folgende Fassung:

      „Die Benannte Stelle gibt in das elektronische System gemäß Artikel 52 alle Informationen zu ausgestellten Bescheinigungen ein, auch zu deren Änderungen und Nachträgen, sowie Angaben über ausgesetzte, wieder in Kraft gesetzte, widerrufene oder verweigerte Bescheinigungen sowie über für Bescheinigungen festgelegte Bedingungen.“

- 34. In Artikel 52 werden die Buchstaben f und i gestrichen.

- 35. Artikel 54 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Abweichend von Artikel 48 kann jede zuständige Behörde auf einen ordnungsgemäß begründeten Antrag hin im Hoheitsgebiet des betreffenden Mitgliedstaats für einen begrenzten Zeitraum das Inverkehrbringen oder die Inbetriebnahme eines bestimmten Produkts genehmigen, für das die geltenden Konformitätsbewertungsverfahren nicht durchgeführt wurden, sofern die Verwendung dieses Produkts im Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten liegt.“

  - b) Folgender Absatz 1a wird eingefügt:

    - „(1a) Abweichend von Artikel 6 Absatz 2 kann jede zuständige Behörde auf einen ordnungsgemäß begründeten Antrag hin einer im Hoheitsgebiet des betreffenden Mitgliedstaats niedergelassenen natürlichen oder juristischen Person für einen begrenzten Zeitraum die Erbringung einer diagnostischen oder therapeutischen Dienstleistung gemäß dem genannten Artikel unter Verwendung eines Produkts genehmigen, für das die in dieser Verordnung festgelegten geltenden Konformitätsbewertungsverfahren nicht durchgeführt wurden, sofern die Erbringung dieser Dienstleistung im Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten liegt.“

  - c) Absatz 2 erhält folgende Fassung:

    - „(2) Der Mitgliedstaat unterrichtet die Kommission, die anderen Mitgliedstaaten und die einschlägigen Expertengremien gemäß Artikel 106 der Verordnung (EU) 2017/745 über jede Entscheidung, das Inverkehrbringen oder die Inbetriebnahme eines Produkts oder die Erbringung einer Dienstleistung gemäß Absatz 1 oder Absatz 1a dieses Artikels zu genehmigen, sofern eine solche Genehmigung nicht nur für die Verwendung bei einem einzigen Patienten erteilt wurde.

        Der Mitgliedstaat macht Informationen über solche Genehmigungen auch öffentlich zugänglich.“

  - d) Absatz 3 Unterabsatz 1 erhält folgende Fassung:

      „Wurde ein Antrag gemäß Absatz 1 oder Absatz 1a bei den zuständigen Behörden in mehr als einem Mitgliedstaat gestellt, kann die Kommission auf der Grundlage einer Stellungnahme eines Expertengremiums gemäß Artikel 106 der Verordnung (EU) 2017/745 in Ausnahmefällen im Zusammenhang mit der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten im Wege von Durchführungsrechtsakten die Gültigkeit einer von einem Mitgliedstaat gemäß Absatz 1 oder Absatz 1a erteilten Genehmigung für einen begrenzten Zeitraum auf das Hoheitsgebiet der Union ausdehnen oder eine Genehmigung gemäß Absatz 1 oder Absatz 1a für das Hoheitsgebiet der Union erteilen. Die Kommission kann die Bedingungen festlegen, unter denen das Produkt in Verkehr gebracht oder in Betrieb genommen werden darf oder unter denen die diagnostische oder therapeutische Dienstleistung erbracht werden darf. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.“

  - e) Die folgenden Absätze 4 und 5 werden angefügt:

    - „(4) Im Falle einer gemäß Artikel 23 der Verordnung (EU) 2022/2371 des Europäischen Parlaments und des Rates***** festgestellten gesundheitlichen Notlage auf Unionsebene kann die Kommission von sich aus nach Anhörung der Koordinierungsgruppe Medizinprodukte im Wege von Durchführungsrechtsakten das Inverkehrbringen oder die Inbetriebnahme eines Produkts gemäß Absatz 3 genehmigen. Die Geltung dieser Genehmigung endet spätestens dann, wenn die Feststellung der gesundheitlichen Notlage gemäß Artikel 23 Absatz 2 der Verordnung (EU) 2022/2371 aufgehoben wird. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.

        In hinreichend begründeten Fällen äußerster Dringlichkeit im Zusammenhang mit der menschlichen Sicherheit und Gesundheit kann die Kommission gemäß dem in Artikel 107 Absatz 4 genannten Verfahren sofort geltende Durchführungsrechtsakte erlassen.

    - (5) Die Kommission kann im Wege von Durchführungsrechtsakten Vorschriften festlegen, die das in diesem Artikel festgelegte Verfahren weiter präzisieren. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.

    - ____________________

    - ***** Verordnung (EU) 2022/2371 des Europäischen Parlaments und des Rates vom 23. November 2022 zu schwerwiegenden grenzüberschreitenden Gesundheitsgefahren und zur Aufhebung des Beschlusses Nr. 1082/2013/EU (ABl. L 314 vom 6.12.2022, S. 26, ELI: ).“

- 36. Folgende Artikel 54a, 54b und 54c werden eingefügt:

**„Artikel 54a**

Abweichungen von bestimmten Anforderungen im Falle einer schwerwiegenden grenzüberschreitenden Gesundheitsgefahr, einer Katastrophe oder einer Krise

  - (1) Auf einen ordnungsgemäß begründeten Antrag eines Herstellers hin kann eine zuständige Behörde für einen begrenzten Zeitraum abweichend von den einschlägigen Bestimmungen der Anhänge II, III, IX, X und XI eine Ausnahme von den Anforderungen in Bezug auf Änderungen der Herstellung, der Auslegung oder des Verwendungszwecks eines Produkts mit CE-Kennzeichnung genehmigen, sofern dies im Interesse der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten liegt, und zwar in einem der folgenden Fälle:

    - a) eine schwerwiegende grenzüberschreitende Gesundheitsgefahr im Sinne von Artikel 3 Nummer 1 der Verordnung (EU) 2022/2371;

    - b) eine Katastrophe oder eine Krise im Sinne der Verordnung (EU) .../... des Europäischen Parlaments und des Rates******.

  - (2) Der Hersteller stellt sicher, dass die hergestellten Produkte weiterhin den einschlägigen grundlegenden Sicherheits- und Leistungsanforderungen gemäß Anhang I entsprechen.

  - (3) Die zuständige Behörde kann die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, ersuchen, sie bei der Bewertung des Antrags gemäß Absatz 1 zu unterstützen.

  - (4) Gegebenenfalls hält der Hersteller die Benannte Stelle, die die Bescheinigung für das betreffende Produkt ausgestellt hat, über alle Änderungen in Bezug auf die Herstellung, die Auslegung oder den Verwendungszweck eines Produkts mit CE-Kennzeichnung gemäß der Genehmigung nach Absatz 1 auf dem Laufenden.

  - (5) Wurde ein Antrag gemäß Absatz 1 bei den zuständigen Behörden in mehr als einem Mitgliedstaat gestellt, kann die Kommission in Ausnahmefällen im Zusammenhang mit der öffentlichen Gesundheit, der Patientensicherheit oder der Gesundheit der Patienten im Wege von Durchführungsrechtsakten die Gültigkeit einer von einem Mitgliedstaat gemäß Absatz 1 gewährten Ausnahme für einen begrenzten Zeitraum auf das Hoheitsgebiet der Union ausdehnen oder eine Ausnahme gemäß Absatz 1 für das Hoheitsgebiet der Union gewähren. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.

      In hinreichend begründeten Fällen äußerster Dringlichkeit im Zusammenhang mit der menschlichen Sicherheit und Gesundheit kann die Kommission gemäß dem in Artikel 107 Absatz 4 genannten Verfahren sofort geltende Durchführungsrechtsakte erlassen.

      _______________

      ****** Verordnung (EU) .../... des Europäischen Parlaments und des Rates vom ... über ... (ABl. ..., ELI). ABl.: Bitte in den Text die Nummer der in 2025/0223(COD) enthaltenen Verordnung (Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates über das Katastrophenschutzverfahren der Union und die Unterstützung der Union für die Krisenvorsorge und -reaktion bei gesundheitlichen Notlagen sowie zur Aufhebung des Beschlusses Nr. 1313/2013/EU (Katastrophenschutzverfahren der Union)) einfügen und in der Fußnote die Nummer, das Datum, den Titel und die Fundstelle im Amtsblatt dieser Verordnung einsetzen.

**Artikel 54b**

Reallabore auf nationaler Ebene

  - (1) Die Mitgliedstaaten können von sich aus oder auf begründeten Antrag eines Herstellers oder eines künftigen Herstellers ein oder mehrere Reallabore einrichten, für die die Anwendung bestimmter Anforderungen der Kapitel V oder VI oder der Anhänge I, VIII, IX, X, XI, XIII oder XIV nicht zweckmäßig wäre. Die Mitgliedstaaten benennen die zuständige Behörde, die für die Beaufsichtigung des Reallabors verantwortlich ist.

      Die Mitgliedstaaten können Reallabore auch gemeinsam mit anderen Mitgliedstaaten einrichten.

  - (2) Die Tätigkeiten innerhalb eines Reallabors erfolgen gemäß einem spezifischen Reallabor-Plan, in dem klar die in Absatz 1 genannten Anforderungen dieser Verordnung benannt werden, die im Reallabor vorübergehend angepasst werden oder von deren Anwendung vorübergehend abgesehen wird, und der eine Begründung, warum die Anwendung dieser Anforderungen nicht als zweckmäßig angesehen wird, sowie eine Erläuterung, wie potenzielle Risiken im Zusammenhang mit der Anpassung oder dem Absehen von der Anwendung zu kontrollieren und zu mindern sind, enthält. Im Plan werden außerdem die angemessene Dauer des Reallabors, die zur Erreichung seiner Ziele erforderlich ist, sowie die Teilnehmer des Reallabors und ihre jeweiligen Funktionen angegeben.

  - (3) Ein Reallabor wird nur dann eingerichtet, wenn die folgenden Bedingungen erfüllt sind:

    - a) Es ist davon auszugehen, dass das Produkt eine medizinische Versorgungslücke schließt oder im Vergleich zu ähnlichen bestehenden Alternativen oder dem Stand der Technik einen erheblichen klinischen Nutzen für die Patienten oder für das Gesundheitssystem bietet.

    - b) Die Anwendung der in Absatz 1 genannten Anforderungen dieser Verordnung würde die Entwicklung des Produkts sowie den Zugang von Angehörigen der Gesundheitsberufe oder von Laienanwendern zu diesem Produkt behindern oder erheblich verzögern.

  - (4) Der Mitgliedstaat kann ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 ersuchen, wissenschaftliche, technische oder regulatorische Beratung bei der Konzeption des Reallabor-Plans zu leisten.

  - (5) Jeder Teilnehmer des Reallabors unterrichtet unverzüglich die für die Beaufsichtigung des Reallabors zuständige Behörde über jeden Schaden, der im Zusammenhang mit der Durchführung des Reallabors eingetreten ist. Die zuständige Behörde ergreift unverzüglich geeignete Korrekturmaßnahmen, einschließlich der Aussetzung oder des Widerrufs des Reallabors oder der Beschränkung seines Anwendungsbereichs.

  - (6) Hersteller und künftige Hersteller, die an einem Reallabor teilnehmen, bleiben nach dem anwendbaren Unionsrecht und nationalen Recht für jeden Schaden haftbar, der Dritten infolge ihrer im Reallabor stattfindenden Tätigkeiten zugefügt wird.

  - (7) Der Mitgliedstaat unterrichtet die Kommission und die Koordinierungsgruppe Medizinprodukte über die Einrichtung eines Reallabors und hält sie über dessen Durchführung und Ergebnisse auf dem Laufenden.

**Artikel 54c**

Reallabore der Union

  - (1) Die Kommission kann von sich aus oder auf begründeten Antrag eines Mitgliedstaats, im Wege von Durchführungsrechtsakten, für einen begrenzten Zeitraum und gemäß einem spezifischen Plan, Reallabore der Union einrichten, die Aufschluss darüber geben, ob die bestehenden Anforderungen einen bestimmten Produkttyp mit besonderen Merkmalen oder aufkommenden Technologien angemessen regulieren, und ob die Gefahr besteht, dass die bestehenden Anforderungen

    - a) die Entwicklung solcher Produkte sowie den Zugang von Angehörigen der Gesundheitsberufe oder von Patienten zu diesen Produkten behindern oder erheblich verzögern würden oder

    - b) den Schutz der Gesundheit und Sicherheit von Patienten, Anwendern oder anderen Personen oder andere Aspekte der öffentlichen Gesundheit nicht angemessen gewährleisten würden.

      Reallabore der Union dürfen nicht das Inverkehrbringen oder die Inbetriebnahme von Produkten umfassen, die dieser Verordnung nicht entsprechen.

  - (2) Die Kommission ersucht ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745, wissenschaftliche, technische oder regulatorische Beratung bei der Konzeption eines Reallabors der Union zu leisten.

  - (3) Die Kommission unterrichtet die Koordinierungsgruppe Medizinprodukte über die Einrichtung eines Reallabors und hält sie über dessen Ergebnisse auf dem Laufenden.

  - (4) Die Kommission kann im Wege von Durchführungsrechtsakten einheitliche Grundsätze oder genaue Regelungen für die Einrichtung, den Betrieb und die Beaufsichtigung von Reallaboren gemäß Artikel 54b oder von Reallaboren der Union gemäß diesem Artikel festlegen. Diese Durchführungsrechtsakte werden gemäß dem in Artikel 107 Absatz 3 genannten Prüfverfahren erlassen.

  - (5) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um diesen Artikel oder Artikel 54b zu ändern, um ihn an den wissenschaftlichen, technischen oder regulatorischen Fortschritt anzupassen und um Entwicklungen im Zusammenhang mit Reallaboren, auch in Bereichen außerhalb der In-vitro-Diagnostika, zu berücksichtigen.“

- 37. In Artikel 55 wird folgender Absatz 1a eingefügt:

  - „(1a) Die zuständige Behörde des Mitgliedstaats, die das Freiverkaufszertifikat gemäß Absatz 1 ausgestellt hat, macht dieses Zertifikat in Eudamed öffentlich zugänglich.“

- 38. Artikel 56 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Von den Herstellern ist eine Leistungsbewertung gemäß diesem Artikel und Anhang XIII Teil A zu planen, durchzuführen und zu dokumentieren, um die Sicherheit und Leistung des Produkts insbesondere in Bezug auf die in Anhang I Kapitel I und Abschnitt 9 genannten Leistungsmerkmale unter normalen Verwendungsbedingungen entsprechend der Zweckbestimmung des Produkts zu bestätigen, und es ist die Vertretbarkeit des in Anhang I Abschnitte 1 und 8 genannten Nutzen-Risiko-Verhältnisses von ihnen zu beurteilen.

        Die Leistungsbewertung erfolgt nach einem genau definierten und methodisch soliden Verfahren und im Einklang mit diesem Artikel und mit Anhang XIII Teil A zum Nachweis folgender Aspekte:

      - a) wissenschaftliche Validität;

      - b) Analyseleistung;

      - c) klinische Leistung.

        Die aus der Bewertung dieser Elemente gewonnenen Daten und Erkenntnisse bilden den klinischen Nachweis für das Produkt.

        Vom Hersteller ist das zur Bestätigung der Sicherheit und Leistung des Produkts erforderliche Niveau der klinischen Nachweise festzulegen und zu begründen. Der Umfang der klinischen Nachweise muss den Merkmalen des Produkts und seiner Zweckbestimmung angemessen sein.

        Die Leistungsbewertung, ihre Ergebnisse und die daraus abgeleiteten klinischen Nachweise werden in einem Bericht über die Leistungsbewertung gemäß Anhang XIII Abschnitt 1.3 dokumentiert, der Teil der technischen Dokumentation gemäß Anhang II für das betreffende Produkt ist.“

  - b) Die Absätze 2 bis 5 werden gestrichen.

  - c) Absatz 6 erhält folgende Fassung:

    - „(6) Die Leistungsbewertung, ihre Dokumentation und gegebenenfalls soweit erforderlich der in Artikel 29 genannte Kurzbericht über Sicherheit und Leistung sind während des gesamten Lebenszyklus des betreffenden Produkts mit den Daten und Erkenntnissen zu aktualisieren, die aus der Durchführung des Plans der klinischen Nachbeobachtung nach dem Inverkehrbringen des Herstellers gemäß Anhang XIII Teil B sowie aus dem Plan für die Überwachung nach dem Inverkehrbringen gemäß Artikel 79 gewonnen werden, sofern diese Daten und Erkenntnisse für die Bestätigung der Sicherheit und Leistung des Produkts relevant sind.“

  - d) Folgender Absatz 8 wird hinzugefügt:

    - „(8) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um Anhang XIII in Anbetracht des technischen und wissenschaftlichen Fortschritts sowie der Entwicklungen auf internationaler Ebene zu ändern, wobei dem Schutz der Gesundheit und Sicherheit von Patienten, Anwendern oder anderen Personen sowie anderen Aspekten der öffentlichen Gesundheit gebührend Rechnung zu tragen ist.“

- 39. Folgender Artikel 56a wird eingefügt:

**„Artikel 56a**

Beratung durch Expertengremien

    Für Produkte der Klassen C und D kann ein Hersteller vor seiner Leistungsstudie oder klinischen Leistungsbewertung ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 konsultieren, um die vom Hersteller vorgesehene Strategie zum Nachweis der klinischen Leistung oder Vorschläge für eine klinische Leistungsstudie überprüfen zu lassen. Der Hersteller und die an einem künftigen Konformitätsbewertungsverfahren mitwirkende Benannte Stelle, tragen im Leistungsbewertungsbericht und im Bericht der Begutachtung der Leistungsbewertung der Stellungnahme des Expertengremiums gebührend Rechnung, andernfalls ist dies von ihnen hinreichend zu begründen.“

- 40. Artikel 58 wird wie folgt geändert:

  - a) Absatz 1 Buchstabe a wird gestrichen.

  - b) Absatz 1 Buchstabe c erhält folgende Fassung:

    - „c) die Durchführung der Studie zusätzliche invasive Verfahren umfasst, einschließlich Hochrisikoverfahren zur Gewinnung von Proben, oder andere Risiken für die Studienteilnehmer beinhaltet,“

  - c) Absatz 2 wird gestrichen.

  - d) Absatz 5 Buchstabe a erhält folgende Fassung:

    - „a) Die Leistungsstudie ist — sofern nichts anderes festgelegt ist — von dem Mitgliedstaat bzw. den Mitgliedstaaten, in dem bzw. denen die Proben für die Leistungsstudie entnommen werden sollen, gemäß dieser Verordnung genehmigt; “

- 41. Artikel 64 Absatz 1 Buchstabe b erhält folgende Fassung:

  - „b) es gibt wissenschaftliche Gründe für die Annahme, dass die Teilnahme des Prüfungsteilnehmers an der Leistungsstudie möglicherweise eines der folgenden Ergebnisse erzielen kann:

    - i) einen direkten, klinisch relevanten Nutzen für den Prüfungsteilnehmer, der zu einer messbaren gesundheitsbezogenen Verbesserung führt, die das Leiden lindert oder den Gesundheitszustand des Prüfungsteilnehmers verbessert wird, oder mit dem die Diagnose seiner Krankheit ermöglicht wird; oder

    - ii) einen Nutzen für die durch den Prüfungsteilnehmer vertretene Population, sofern die Leistungsstudie im Vergleich zur Standardbehandlung der Erkrankung des Prüfungsteilnehmers für diesen nur ein minimales Risiko birgt und ihn nur minimal belastet.“

- 42. Artikel 66 wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 1 erhält folgende Fassung:

      „Der Sponsor einer Leistungsstudie gemäß Artikel 58 Absätze 1 und 2 gibt den Antrag ein und reicht ihn bei dem/den Mitgliedstaat(en) ein, in dem/denen die Proben für die Leistungsstudie entnommen werden sollen (für die Zwecke des vorliegenden Artikels und von Artikel 71 als der „betreffende Mitgliedstaat“ bezeichnet); dem Antrag sind die in Anhang XIII Abschnitte 2 und 3 und in Anhang XIV aufgeführten Unterlagen beizufügen.“

  - b) Absatz 7 erhält folgende Fassung:

    - „(7) Der Sponsor kann die Leistungsstudie beginnen, sobald der betreffende Mitgliedstaat den Sponsor über seine Genehmigung unterrichtet hat und sofern nicht eine Ethik-Kommission des betreffenden Mitgliedstaats eine ablehnende Stellungnahme in Bezug auf die Leistungsstudie abgegeben hat, die nach dem nationalen Recht des betreffenden Mitgliedstaats für dessen gesamtes Hoheitsgebiet gültig ist. Der Mitgliedstaat unterrichtet den Sponsor über die Genehmigung innerhalb von 45 Tagen nach dem Datum der Validierung des Antrags gemäß Absatz 5. Der Mitgliedstaat kann diese Frist um weitere 20 Tage verlängern, um eine Beratung mit Sachverständigen zu ermöglichen.“

- 43. Artikel 67 Absatz 2 erhält folgende Fassung:

  - „(2) Die Mitgliedstaaten sorgen dafür, dass die Bewertung von einer geeigneten Anzahl von Personen gemeinsam vorgenommen wird, die zusammen über die erforderlichen Qualifikationen und Erfahrung verfügen.“

- 44. In Artikel 68 wird folgender Absatz 7 angefügt:

  - „(7) Die Verarbeitung personenbezogener Daten im Zusammenhang mit einer Leistungsstudie, einschließlich der Sekundärnutzung personenbezogener Daten, die ursprünglich für andere Studien erhoben wurden, gilt als zu wissenschaftlichen Forschungszwecken im Sinne des Artikels 9 Absatz 2 Buchstabe j der Verordnung (EU) 2016/679 des Europäischen Parlaments und des Rates ******* durchgeführt.

  - _________________

  - ******* Verordnung (EU) 2016/679 des Europäischen Parlaments und des Rates vom 27. April 2016 zum Schutz natürlicher Personen bei der Verarbeitung personenbezogener Daten, zum freien Datenverkehr und zur Aufhebung der Richtlinie 95/46/EG (Datenschutz-Grundverordnung) (ABl. L 119 vom 4.5.2016, S. 1, ELI: ).“

- 45. Artikel 70 Absatz 1 Sätze 2 und 3 erhalten folgende Fassung:

    „Der Sponsor übermittelt die in Anhang XIII Teil A Abschnitt 2 und in Anhang XIV Kapitel I Abschnitte 1, 3 und 4 genannten Unterlagen. Artikel 58 Absatz 5 Buchstaben b bis l und Buchstabe p, Artikel 71 Absatz 1, Artikel 72 und 73, Artikel 76 Absätze 5 und 6 sowie die einschlägigen Bestimmungen der Anhänge XIII und XIV finden auf Nachbeobachtungsstudien der Leistung nach dem Inverkehrbringen Anwendung, die zusätzliche invasive oder belastende Verfahren beinhalten.“

- 46. in Artikel 71 erhalten die Absätze 1 und 2 sowie die einleitenden Worte von Absatz 3 und Buchstabe a folgende Fassung:

  - „(1) Hat ein Sponsor die Absicht, Änderungen an einer Leistungsstudie vorzunehmen, die wahrscheinlich wesentliche Auswirkungen auf die Sicherheit, die Gesundheit oder die Rechte der Prüfungsteilnehmer oder die Robustheit oder Zuverlässigkeit der im Rahmen der Studie gewonnenen Daten haben, teilt er dem bzw. den betreffenden Mitgliedstaat(en) die Gründe für die Änderungen und deren Art über das elektronische System gemäß Artikel 69 mit. Der Sponsor übermittelt eine aktualisierte Fassung der einschlägigen Unterlagen gemäß Anhang XIV als Teil der Mitteilung. Änderungen der einschlägigen Unterlagen müssen deutlich gekennzeichnet sein.

  - (2) Wurde die Leistungsstudie gemäß Artikel 58 Absatz 5 Buchstabe a genehmigt, so bewertet der Mitgliedstaat jede wesentliche Änderung der Leistungsstudie nach dem in Artikel 67 festgelegten Verfahren.

  - (3) Der Sponsor kann die in Absatz 1 genannten Änderungen umsetzen, sobald der betreffende Mitgliedstaat den Sponsor über seine Genehmigung unterrichtet hat oder, sofern keine Genehmigung erforderlich ist, frühestens 38 Tage nach der in Absatz 1 genannten Mitteilung, es sei denn

    - a) der betreffende Mitgliedstaat hat dem Sponsor mitgeteilt, dass er die Änderungen aufgrund von Artikel 67 Absatz 4 oder aus Gründen der öffentlichen Gesundheit, der Sicherheit oder Gesundheit der Prüfungsteilnehmer und Anwender oder der öffentlichen Ordnung ablehnt, oder“

- 47. Artikel 73 Absatz 1 Satz 1 erhält folgende Fassung:

    „Hat der Sponsor eine Leistungsstudie vorübergehend ausgesetzt oder vorzeitig beendet, so unterrichtet er innerhalb von 15 Tagen nach der vorübergehenden Aussetzung oder vorzeitigen Beendigung den Mitgliedstaat, in dem die Leistungsstudie vorübergehend ausgesetzt oder vorzeitig beendet wurde, über das elektronische System gemäß Artikel 69 und legt eine Begründung vor.“

- 48. Artikel 74 wird wie folgt geändert:

  - a) Absatz 4 Unterabsatz 2 erhält folgende Fassung:

      „Der abschließende Bewertungsbericht wird von allen betroffenen Mitgliedstaaten bei ihrer Entscheidung über den Antrag des Sponsors gemäß Absatz 11 berücksichtigt.“

  - b) Absatz 5 Satz 1 und 2 erhalten folgende Fassung:

      „Jeder betreffende Mitgliedstaat kann einmalig zusätzliche Informationen vom Sponsor anfordern. Der Sponsor übermittelt die angeforderten zusätzlichen Informationen innerhalb von 12 Tagen ab Eingang des Informationsersuchens.“

  - c) In Absatz 6 werden die Worte „50 Tage“ durch die Worte „20 Tage“ ersetzt;

  - d) Folgender Absatz 15 wird angefügt:

    - „(15) Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um diesen Artikel unter Berücksichtigung der bei der praktischen Anwendung des koordinierten Bewertungsverfahrens gewonnenen Erfahrungen zu ändern, insbesondere in Bezug auf Fristen und die Genehmigung von Leistungsstudien, die einer koordinierten Bewertung unterliegen.“

- 49. Artikel 75 wird gestrichen;

- 50. Folgender Artikel 75a wird eingefügt:

**„Artikel 75a**

Leistungsstudien in kombinierten Studien

    Leistungsstudien, die Teil kombinierter Studien sind und die gemäß Artikel 58 genehmigungspflichtig sind, können nach Maßgabe des Artikels 14c der Verordnung (EU) Nr. 536/2014 durchgeführt werden.

    Entscheidet sich der Sponsor für die Anwendung des Artikels 14c der Verordnung (EU) Nr. 536/2014, so gelten die darin sowie in den gemäß dem genannten Artikel erlassenen Durchführungsrechtsakten oder delegierten Rechtsakten festgelegten Anforderungen anstelle der entsprechenden in der vorliegenden Verordnung festgelegten Anforderungen.“

- 51. Artikel 78 Absatz 4 Satz 1 erhält folgende Fassung:

    „Zeigt sich im Verlauf der Überwachung nach dem Inverkehrbringen, dass Präventiv- oder Korrekturmaßnahmen oder beides erforderlich sind, so ergreift der Hersteller die geeigneten Maßnahmen. Die zuständigen Behörden können vom Hersteller verlangen, sie darüber zu unterrichten, wann solche Präventiv- und Korrekturmaßnahmen ergriffen werden, um ein Risiko zu verringern, das die Sicherheit oder die Leistung des Produkts beeinträchtigen könnte.“

- 52. Artikel 79 Satz 2 wird gestrichen.

- 53. Artikel 81 wird wie folgt geändert:

  - a) Absatz 1 wird wie folgt geändert:

    - i) Unterabsatz 1 Satz 1 erhält folgende Fassung:

        „Die Hersteller von Produkten der Klassen C und D erstellen für jedes Produkt oder gegebenenfalls für jede Produktkategorie oder Produktgruppe einen regelmäßig aktualisierten Bericht über die Sicherheit (im Folgenden „Sicherheitsbericht“), der eine Zusammenfassung der Ergebnisse und Schlussfolgerungen der Analysen der aufgrund des Plans zur Überwachung nach dem Inverkehrbringen gemäß Artikel 79 gesammelten Daten über die Überwachung nach dem Inverkehrbringen zusammen mit einer Beschreibung etwaiger ergriffener Präventiv- und Korrekturmaßnahmen, einschließlich ihrer Begründung, enthält.“

    - ii) Unterabsatz 2 erhält folgende Fassung:

        „Die Hersteller von Produkten der Klassen C und D aktualisieren den Sicherheitsbericht im ersten Jahr nach Ausstellung der Bescheinigung und danach alle zwei Jahre oder wenn sich die Nutzen-Risiko-Abwägung oder die Vertretbarkeit fehlerhafter Ergebnisse wesentlich ändert. Der Sicherheitsbericht ist Teil der technischen Dokumentation gemäß Anhang III.“

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Bei Produkten der Klasse D überprüft die Benannte Stelle den Sicherheitsbericht während der Überwachungsbewertung. Der Hersteller und die Benannte Stelle stellen diese Sicherheitsberichte sowie die Bewertung durch die Benannte Stelle den zuständigen Behörden über das elektronische System gemäß Artikel 87 zur Verfügung.“

- 54. Artikel 82 wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 2 erhält folgende Fassung:

      „Die Meldungen gemäß Unterabsatz 1 erfolgen unverzüglich über das elektronische Systemgemäß Artikel 87.“

  - b) Absatz 3 erhält folgende Fassung:

    - „(3) Die Hersteller melden jedes schwerwiegende Vorkommnis gemäß Absatz 1 Unterabsatz 1 Buchstabe a unverzüglich, nachdem sie einen Kausalzusammenhang oder einen durchaus möglichen Kausalzusammenhang zwischen dem Vorkommnis und ihrem Produkt festgestellt haben, spätestens jedoch 30 Tage, nachdem sie von dem Vorkommnis Kenntnis erlangt haben.“

- 55. Folgender Artikel 82a wird eingefügt:

**„Artikel 82a**

Meldung aktiv ausgenutzter Schwachstellen und schwerwiegender Sicherheitsvorfälle im Zusammenhang mit Produkten

  - (1) Unbeschadet der Meldepflichten in Bezug auf schwerwiegende Vorkommnisse und Sicherheitskorrekturmaßnahmen im Feld gemäß Artikel 82 meldet der Hersteller eines Produkts den als Koordinatoren der Mitgliedstaaten, in denen ein Produkt bereitgestellt wurde, benannten Computer-Notfallteams (im Folgenden „CSIRTs“) sowie der Europäischen Agentur der Europäischen Union für Cybersicherheit (ENISA) jedes der folgenden Ereignisse:

    - a) jede im Produkt vorliegende aktiv ausgenutzte Schwachstelle im Sinne des Artikels 3 Nummer 42 der Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates********;

    - b) jeden schwerwiegenden Sicherheitsvorfall gemäß Artikel 14 Absatz 5 der Verordnung (EU) 2024/2847 mit Auswirkungen auf die Sicherheit des Produkts.

  - (2) Der Hersteller übermittelt die Meldung gemäß Absatz 1 über das elektronische System gemäß Artikel 87 spätestens 30 Tage, nachdem er von der aktiv ausgenutzten Schwachstelle oder dem schwerwiegenden Sicherheitsvorfall Kenntnis erlangt hat.

  - (3) Die Meldung gemäß Absatz 1 sowie alle von einem Hersteller gemäß Artikel 82 übermittelten Meldungen, die auch als aktiv ausgenutzte Schwachstellen oder schwerwiegende Sicherheitsvorfälle gelten, werden gleichzeitig den als Koordinatoren der Mitgliedstaaten, in denen das Produkt bereitgestellt wurde, benannten CSIRTs und der ENISA übermittelt.

  - (4) Für die Zwecke dieses Artikels haben die als Koordinatoren benannten CSIRTs und die ENISA Zugang zu Eudamed.

  - _____________

  - ******** Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates vom 23. Oktober 2024 über horizontale Cybersicherheitsanforderungen für Produkte mit digitalen Elementen und zur Änderung der Verordnungen (EU) Nr. 168/2013 und (EU) 2019/1020 und der Richtlinie (EU) 2020/1828 (Cyberresilienz-Verordnung) (ABl. L, 2024/2847, 20.11.2024, ELI: http://data.europa.eu/eli/reg/2024/2847/oj).“

- 56. Artikel 83 Absatz 1 Unterabsatz 1 erhält folgende Fassung:

    „Die Hersteller melden über das elektronische System gemäß Artikel 87 jede statistisch signifikante Zunahme der Häufigkeit oder der Schwere von Vorkommnissen, die keine schwerwiegenden Vorkommnisse sind und die erhebliche Auswirkungen auf die in Anhang I Abschnitte 1 und 8 genannte Nutzen-Risiko-Analyse haben könnten, oder jede erhebliche Zunahme erwarteter fehlerhafter Ergebnisse, die im Vergleich zur erklärten Leistung des Produkts gemäß Anhang I Abschnitt 9.1 Buchstaben a und b festgestellt wird und in der technischen Dokumentation sowie in den Produktinformationen angegeben ist.“

- 57. Artikel 84 wird wie folgt geändert:

  - a) Absatz 1 Unterabsatz 2 erhält folgende Fassung:

      „Der Hersteller arbeitet bei den Untersuchungen gemäß Unterabsatz 1 mit den zuständigen Behörden zusammen und nimmt keine Untersuchung vor, die zu einer Veränderung des Produkts oder einer Probe der betroffenen Charge in einer Weise führen, die Auswirkungen auf eine spätere Bewertung der Ursachen des Vorkommnisses haben könnte, bevor er die zuständigen Behörden über eine solche Maßnahme unterrichtet hat.“

  - b) Absatz 2 erhält folgende Fassung:

    - „(2) Die Mitgliedstaaten unternehmen die notwendigen Schritte um sicherzustellen, dass alle Informationen im Zusammenhang mit einem schwerwiegenden Vorkommnis, das in ihrem Hoheitsgebiet aufgetreten ist, oder einer Sicherheitskorrekturmaßnahme im Feld, die in ihrem Hoheitsgebiet ergriffen wurde oder ergriffen werden soll, von denen sie gemäß Artikel 82 Kenntnis erhalten haben, von ihrer zuständigen Behörde auf nationaler Ebene zentral bewertet werden, und zwar nach Möglichkeit in Zusammenarbeit mit dem Hersteller.“

  - c) Folgender Absatz 3a wird eingefügt:

    - „(3a) Die zuständige Behörde kann die Benannte Stelle, die gemäß Artikel 51 eine Bescheinigung für das betreffende Produkt ausgestellt hat, ersuchen, bei der Bewertung einer Korrekturmaßnahme im Zusammenhang mit einem schwerwiegenden Vorkommnis oder einer Sicherheitskorrekturmaßnahme im Feld Unterstützung zu leisten.“

  - d) Die Absätze 6 und 7 erhalten folgende Fassung:

    - „(6) Im Falle eines therapiebegleitenden Diagnostikums und sofern der Hersteller bestätigt, dass das schwerwiegende Vorkommnis oder die Korrekturmaßnahme im Feld die sichere und wirksame Anwendung des entsprechenden Arzneimittels beeinträchtigen kann, unterrichtet die bewertende zuständige Behörde oder die in Absatz 9 genannte koordinierende zuständige Behörde die nationale zuständige Behörde oder die EMA, die von der Benannten Stelle gemäß den in Anhang IX Abschnitt 5.2 und Anhang X Abschnitt 3 Buchstabe k festgelegten Verfahren konsultiert wurde.

    - (7) Stellt die bewertende zuständige Behörde nach Durchführung der Bewertung gemäß Absatz 3 fest, dass zusätzliche Korrekturmaßnahmen des Herstellers erforderlich sind, um das Risiko eines erneuten Auftretens des schwerwiegenden Vorkommnisses zu minimieren, so unterrichtet sie über das elektronische System gemäß Artikel 87 unverzüglich die anderen zuständigen Behörden über die vom Hersteller ergriffenen oder geplanten oder von ihm verlangten Korrekturmaßnahmen zur Minimierung des Risikos eines erneuten Auftretens des schwerwiegenden Vorkommnisses; übermittelt werden dabei außerdem Angaben über die zugrunde liegenden schwerwiegenden Vorkommnisse und das Ergebnis ihrer Bewertung.“

  - e) In Absatz 9 erhält der einleitende Satz folgende Fassung:

      „Die zuständigen Behörden beteiligen sich aktiv an einem Verfahren zur Koordinierung ihrer in Absatz 3 genannten Bewertungen, sobald eine solche Koordinierung erforderlich ist, um ein hohes Schutzniveau für die Gesundheit und Sicherheit von Patienten, Anwendern und anderen Personen oder den Schutz der öffentlichen Gesundheit in der gesamten Union zu gewährleisten, insbesondere in den folgenden Fällen:“

- 58. Artikel 86 wird wie folgt geändert:

  - a) in Unterabsatz 1 wird die Bezugnahme auf „Artikel 80 bis 85 und 87“ durch „Artikel 79 bis 85 und 87“ ersetzt;

  - b) Unterabsatz 1 Buchstabe b erhält folgende Fassung:

    - „b) Meldung von schwerwiegenden Vorkommnissen, Sicherheitskorrekturmaßnahmen im Feld und Sicherheitsanweisungen im Feld sowie Vorlage und Inhalt des Plans zur Überwachung nach dem Inverkehrbringen, der periodischen Sammelmeldungen, der Berichte zur Überwachung nach dem Inverkehrbringen, der Sicherheitsberichte und der Trendmeldungen durch die Hersteller gemäß den Artikeln 79, 80, 81, 82, 83 bzw. 84;“

- 59. In Artikel 87 Absatz 2 Satz 2 wird der Verweis auf „Artikel 49“ ersetzt durch „Absatz 51“

- 60. Artikel 88 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Die zuständigen Behörden führen geeignete Kontrollen der Konformitätsmerkmale und der Leistung von Produkten sowie der Einhaltung der in dieser Verordnung festgelegten Pflichten durch die Wirtschaftsakteure durch; hierzu gehören gegebenenfalls eine Überprüfung der Unterlagen sowie physische oder Laboruntersuchungen auf der Grundlage angemessener Stichproben. Die zuständigen Behörden berücksichtigen insbesondere die etablierten Grundsätze in Bezug auf Risikobewertungen und Risikomanagement, Vigilanz-Daten und Beschwerden.“

  - b) Folgender Absatz 1a wird eingefügt:

    - „(1a) Die Mitgliedstaaten sorgen dafür, dass ihre zuständigen nationalen Behörden mit angemessenen und ausreichenden technischen und finanziellen Mitteln sowie geeignetem Personal und Infrastrukturen ausgestattet werden, damit sie ihre Aufgaben im Rahmen dieser Verordnung wirksam erfüllen können.“

  - c) Absatz 2 erhält folgende Fassung:

    - „(2) Die zuständigen Behörden erstellen Jahrespläne für Überwachungsaktivitäten unter Berücksichtigung des von der Koordinierungsgruppe Medizinprodukte auszuarbeitenden und zu pflegenden europäischen Marktüberwachungsprogramms sowie der lokalen Gegebenheiten.“

  - d) Folgender Absatz 12 wird hinzugefügt:

    - „(12) In Bezug auf Produkte, bei denen es sich um Hochrisiko-KI-Systeme im Sinne von Artikel 6 Absatz 1 der Verordnung (EU) 2024/1689 handelt, arbeiten die zuständigen Behörden mit den gemäß Artikel 70 der Verordnung (EU) 2024/1689 benannten Marktüberwachungsbehörden ihres Mitgliedstaats zusammen.“

- 61. Artikel 89 erhält folgende Fassung:

**„Artikel 89**

Bewertung von Produkten, die mutmaßlich ein unannehmbares Risiko darstellen oder anderweitig nicht konform sind

    Die zuständigen Behörden eines Mitgliedstaats führen allein oder in Zusammenarbeit mit den zuständigen Behörden anderer Mitgliedstaaten eine Bewertung eines Produkts oder eines Wirtschaftsakteurs durch, die die einschlägigen in dieser Verordnung festgelegten Anforderungen im Zusammenhang mit dem vom Produkt ausgehenden Risiko oder mit einer sonstigen Nichtkonformität des Produkts oder des Wirtschaftsakteurs erfasst, wenn sie auf der Grundlage von im Rahmen der Vigilanz- oder Marktüberwachungstätigkeiten gewonnenen Daten oder anderer Informationen Grund zu der Annahme haben, dass einer der folgenden Fälle vorliegt:

  - a) ein Produkt kann ein unannehmbares Risiko für die Gesundheit oder Sicherheit der Patienten, Anwender oder anderer Personen oder für andere Aspekte des Schutzes der öffentlichen Gesundheit darstellen;

  - b) ein Produkt oder ein Wirtschaftsakteur erfüllt anderweitig nicht die in dieser Verordnung niedergelegten Anforderungen.

    Die betreffenden Wirtschaftsakteure und gegebenenfalls auf Verlangen die Benannte Stelle, die für das betreffende Produkt eine Bescheinigung ausgestellt hat, arbeiten mit den zuständigen Behörden zusammen.“

- 62. Artikel 90 wird wie folgt geändert:

  - a) Absatz 3 erhält folgende Fassung:

    - „(3) Die Wirtschaftsakteure gemäß Absatz 1 stellen unverzüglich sicher, dass innerhalb der dort genannten Frist unionsweit in Bezug auf alle betroffenen Produkte, die sie auf dem Markt bereitgestellt haben, alle geeigneten Korrekturmaßnahmen ergriffen werden.“

  - b) Absatz 7 wird wie folgt geändert:

    - i) Satz 1 erhält folgende Fassung:

    - „Erhebt weder ein Mitgliedstaat noch die Kommission innerhalb von zwei Monaten nach Erhalt der Mitteilung gemäß Absatz 4 einen Einwand gegen die mitgeteilten Maßnahmen eines Mitgliedstaats, so gelten diese Maßnahmen als gerechtfertigt.“

    - ii) Folgender Unterabsatz wird angefügt:

        „Absatz 4 gilt nicht für solche von den Mitgliedstaaten erlassenen Maßnahmen.“

- 63. Artikel 91 wird wie folgt geändert:

  - a) In Absatz 1 wird der dritte Satz gestrichen.

  - b) Absatz 2 Unterabsatz 1 erhält folgende Fassung:

      „Ist die Kommission der Auffassung, dass die nationale Maßnahme gemäß Absatz 1 des vorliegenden Artikels gerechtfertigt ist, findet Artikel 90 Absatz 7 Satz 2 Anwendung. Hält die Kommission die nationale Maßnahme für ungerechtfertigt, so zieht der betreffende Mitgliedstaat sowie jeder Mitgliedstaat, der entsprechende restriktive Maßnahmen oder Verbote ergriffen hat, diese Maßnahmen zurück.“

- 64. Artikel 92 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Stellen die zuständigen Behörden eines Mitgliedstaats nach Durchführung einer Bewertung gemäß Artikel 89 fest, dass ein Produkt oder ein Wirtschaftsakteur nicht die in dieser Verordnung niedergelegten Anforderungen erfüllt, aber kein unvertretbares Risiko für die Gesundheit oder Sicherheit der Patienten, Anwender oder anderer Personen oder in Bezug auf andere Aspekte des Schutzes der öffentlichen Gesundheit darstellt, so fordern sie den entsprechenden Wirtschaftsakteur auf, die betreffende Nichtkonformität innerhalb eines der Nichtkonformität angemessenen, eindeutig festgelegten und dem Wirtschaftsakteur mitgeteilten Zeitraums zu beheben.“

  - b) Absatz 2 Satz 1 erhält folgende Fassung:

      „Behebt der Wirtschaftsakteur innerhalb der Frist gemäß Absatz 1 die Nichtkonformität nicht, trifft der betreffende Mitgliedstaat unverzüglich alle geeigneten Maßnahmen, um die Bereitstellung des Produkts auf dem Markt zu untersagen oder einzuschränken oder um sicherzustellen, dass das Produkt vom nationalen Markt genommen oder zurückgerufen wird.“

  - c) Folgender Absatz 2a wird eingefügt:

    - „(2a) Der Wirtschaftsakteur ergreift gemäß Absatz 1 oder Absatz 2 unionsweit in Bezug auf alle betroffenen Produkte, die er auf dem Markt bereitgestellt hat, alle geeigneten Korrekturmaßnahmen, sofern nicht eine zuständige Behörde andere geeignete Maßnahmen ergreift.“

- 65. In Artikel 93 Absatz 3 wird der vierte Satz gestrichen.

- 66. Die Überschrift des Kapitels VIII erhält folgende Fassung:

„ZUSAMMENARBEIT ZWISCHEN DEN MITGLIEDSTAATEN UND EU-REFERENZLABORATORIEN“

- 67. In Artikel 96 erhalten die ersten beiden Sätze folgende Fassung:

    „Die Mitgliedstaaten benennen die für die Durchführung und praktische Anwendung dieser Verordnung zuständige(n) Behörde(n). Sie stellen sicher, dass diese Behörden mit ausreichenden Befugnissen, Ressourcen, Ausrüstung und Fachkenntnissen ausgestattet werden, damit sie ihre Aufgaben gemäß dieser Verordnung wirksam und effizient wahrnehmen können..“

- 68. Artikel 97 Absatz 2 wird gestrichen.

- 69. Die Artikel 98 und 99 werden aufgehoben.

- 70. Artikel 100 wird wie folgt geändert:

  - a) Absatz 2 wird wie folgt geändert:

    - i) Buchstabe a erhält folgende Fassung:

        „a) bei Produkten der Klasse D Überprüfung der vom Hersteller angegebenen Leistung und der Einhaltung der GS, sofern verfügbar, oder anderer vom Hersteller gewählter Lösungen, die ein mindestens gleichwertiges Sicherheits- und Leistungsniveau wie gemäß Anhang IX Abschnitt 4.9 und Anhang X Abschnitt 3 Buchstabe j gewährleisten;“

    - ii) Buchstabe d erhält folgende Fassung:

      - „d) wissenschaftliche Beratung zum Stand der Technik in Bezug auf bestimmte Produkte oder eine Kategorie oder Gruppe von Produkten, wenn dies auf der Grundlage vergleichender Testergebnisse oder anderer Studien verlangt wird;“

    - iii) Die Buchstaben e und j werden gestrichen.

    - iv) Folgender Unterabsatz wird angefügt:

        „Der Kommission wird die Befugnis übertragen, gemäß Artikel 108 delegierte Rechtsakte zu erlassen, um Unterabsatz 1 zu ändern, indem Aufgaben in die Aufgabenliste der EU-Referenzlaboratorien aufgenommen, angepasst oder von ihr gestrichen werden.“

  - b) Absatz 3 wird gestrichen.

  - c) Absatz 4 Buchstabe b erhält folgende Fassung:

    - „b) (betrifft nicht die deutsche Fassung);“

  - d) Absatz 5 Buchstabe j wird gestrichen.

  - e) Absatz 7 erhält folgende Fassung:

    - „(7) Ersuchen Benannte Stellen oder Mitgliedstaaten ein EU-Referenzlaboratorium um wissenschaftliche oder technische Unterstützung oder um ein wissenschaftliches Gutachten, können von dem Labor unter vorab festgelegten und transparenten Bedingungen Gebühren für diese Leistung erhoben werden, die die bei der Ausführung seiner Aufgaben anfallenden Kosten ganz oder teilweise decken.“

- 71. Artikel 101 wird gestrichen;

- 72. Artikel 103 wird wie folgt geändert:

  - a) In Absatz 1 wird die Bezugnahme auf „Richtlinie 95/46/EG“ durch „Verordnung (EU) 2016/679“ ersetzt;

  - b) in Absatz 2 wird die Bezugnahme auf die „Verordnung (EG) Nr. 45/2001“ durch „Verordnung (EU) 2018/1725 des Europäischen Parlaments und des Rates*********“ ersetzt.

  - ______________________

  - ********* Verordnung (EU) 2018/1725 des Europäischen Parlaments und des Rates vom 23. Oktober 2018 zum Schutz natürlicher Personen bei der Verarbeitung personenbezogener Daten durch die Organe, Einrichtungen und sonstigen Stellen der Union, zum freien Datenverkehr und zur Aufhebung der Verordnung (EG) Nr. 45/2001 und des Beschlusses Nr. 1247/2002/EG (ABl. L 295 vom 21.11.2018, S. 39, ELI: http://data.europa.eu/eli/reg/2018/1725/oj).“

- 73. Folgender Artikel 103a wird eingefügt:

**„Artikel 103a**

Übermittlung von Informationen oder Unterlagen

    Die Übermittlung von Informationen oder Unterlagen gemäß dieser Verordnung erfolgt elektronisch. “

- 74. Artikel 104 wird wie folgt geändert:

  - a) Absatz 1 erhält folgende Fassung:

    - „(1) Diese Verordnung hindert die Mitgliedstaaten und die Kommission nicht daran, für die ihnen mit dieser Verordnung übertragenen Aufgaben Gebühren zu erheben, sofern die Höhe dieser Gebühren auf transparente Weise und nach dem Grundsatz der Kostendeckung festgelegt wird.“

  - b) In Absatz 2 Satz 2 werden die Worte „auf Anfrage“ gestrichen.

- 75. Artikel 105 wird gestrichen;

- 76. In Artikel 108 Absatz 6 Sätze 1 und 2 werden die Worte „von drei Monaten“ bzw. „um drei Monate“ durch die Worte „von zwei Monaten“ bzw. „um zwei Monate“ ersetzt.

- 77. Artikel 109 wird gestrichen;

- 78. In Artikel 110 werden die folgenden Absätze 12 und 13 angefügt:

  - „(12) Abweichend von Artikel 5 und von den Absätzen 3 bis 3e dieses Artikels darf ein Produkt gemäß Absatz 3a oder Absatz 3b dieses Artikels, das die Kriterien für ein Medizinprodukt für seltene Erkrankungen nach Artikel 48a Absatz 3 erfüllt, über die in den Absätzen 3a und 3b genannten Zeitpunkte hinaus in Verkehr gebracht oder in Betrieb genommen werden, sofern die folgenden Bedingungen erfüllt sind:

    - a) ein Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 hat eine Stellungnahme abgegeben, in der die Erfüllung der Kriterien für ein Medizinprodukt für seltene Erkrankungen gemäß Artikel 48a Absatz 3 bestätigt wird;

    - b) die Auslegung und Zweckbestimmung des Produkts wurden nicht wesentlich geändert;

    - c) das Produkt stellt kein unannehmbares Risiko für die Gesundheit oder Sicherheit der Patienten, Anwender oder anderer Personen oder für andere Aspekte des Schutzes der öffentlichen Gesundheit dar.

      Die Anforderungen der vorliegenden Verordnung gelten mit Ausnahme der Kapitel IV, V und VI für das in Unterabsatz 1 genannte Produkt. Abweichend von Artikel 81 Absatz 1 aktualisieren die Hersteller von Produkten der Klassen C und D, die gemäß diesem Absatz in Verkehr gebracht oder in Betrieb genommen werden, den Sicherheitsbericht mindestens jährlich. Der Hersteller übermittelt jährlich den Sicherheitsbericht und gegebenenfalls eine Aktualisierung des Kurzberichts über Sicherheit und Leistung an die zuständige Behörde des Mitgliedstaats, in dem er niedergelassen ist.

      Die zuständige Behörde des Mitgliedstaats kann vom Hersteller verlangen, innerhalb eines festgelegten Zeitraums definierte Maßnahmen zur Überwachung nach dem Inverkehrbringen oder zur klinischen Nachbeobachtung nach dem Inverkehrbringen durchzuführen, um zusätzliche Daten zu generieren, mit denen die Sicherheit und die Leistung des Produkts bestätigt sowie die Vertretbarkeit des Nutzen-Risiko-Verhältnisses bewertet werden.

      Produkte, die gemäß diesem Absatz in Verkehr gebracht oder in Betrieb genommen werden und die nicht über eine gültige Bescheinigung gemäß Absatz 2 verfügen, dürfen keine CE-Kennzeichnung tragen. In seiner EU-Konformitätserklärung verweist der Hersteller darauf, dass es sich bei dem Produkt um ein Medizinprodukt für seltene Erkrankungen handelt, das gemäß diesem Absatz in Verkehr gebracht oder in Betrieb genommen wurde.

      Der Hersteller informiert die vorgesehenen Anwender gegebenenfalls im Kurzbericht über Sicherheit und Leistung sowie in der Gebrauchsanweisung oder in sonstigen Begleitunterlagen darüber, dass es sich bei dem Produkt um ein Medizinprodukt für seltene Erkrankungen handelt, das gemäß diesem Absatz in Verkehr gebracht oder in Betrieb genommen wurde.

      Mindestens alle zehn Jahre beantragt der Hersteller bei einem Expertengremium gemäß Artikel 106 der Verordnung (EU) 2017/745 eine Stellungnahme, in der die Erfüllung der Kriterien für ein Medizinprodukt für seltene Erkrankungen, wie in Artikel 48a Absatz 3 dieser Verordnung festgelegt, bestätigt wird.

  - (13) In Bezug auf Produkte, für die am … [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach dem Inkrafttreten dieser Verordnung] ein Konformitätsbewertungsverfahren anhängig ist oder für die vor diesem Datum von einer Benannten Stelle eine Bescheinigung ausgestellt wurde, können der Hersteller und die Benannte Stelle vereinbaren, die Bestimmungen dieser Verordnung in der vor dem … [Amt für Veröffentlichungen: bitte Datum einfügen = sechs Monate nach dem Inkrafttreten dieser Verordnung] geltenden Fassung solange weiter anzuwenden, bis das Konformitätsbewertungsverfahren abgeschlossen ist oder die Bescheinigung erneuert wird.“

- 79. Artikel 111 wird wie folgt geändert:

  - a) Im ersten Satz wird das Datum „27. Mai 2027“ durch das Datum... „[Amt für Veröffentlichungen, bitte Datum einfügen = fünf Jahre nach Inkrafttreten dieser Verordnung]“ ersetzt.

  - b) Der zweite Satz wird gestrichen.

- 80. In Artikel 113 Absatz 3 Buchstabe f wird folgender Unterabsatz angefügt:

    „Falls die Mitgliedstaaten nationale Datenbanken unterhalten, werden die für diese nationalen Datenbanken relevanten und in Eudamed verfügbaren Informationen nach dem Geltungsbeginn der in Unterabsatz 1 genannten Bestimmungen aus Eudamed abgerufen.“

- 81. Die Anhänge I, II, III, VI, VII, IX, X, XI, XII, XIII und XIV der Verordnung (EU) 2017/746 werden entsprechend Anhang II der vorliegenden Verordnung geändert.

**Artikel 3**

Änderungen der Verordnung (EU) 2022/123

Artikel 30 der Verordnung (EU) 2022/123 wird wie folgt geändert:

- 1. Unterabsatz 1 erhält folgende Fassung:

    „Die Agentur nimmt die Sekretariatsgeschäfte der gemäß Artikel 106 Absatz 1 der Verordnung (EU) 2017/745 benannten Expertengremien (im Folgenden „Expertengremien“) wahr und leistet die erforderliche Unterstützung, um sicherzustellen, dass diese Expertengremien ihre Aufgaben gemäß der genannten Verordnung und der Verordnung (EU) 2017/746 effizient wahrnehmen können.“

- 2. Unterabsatz 2 wird wie folgt geändert:

  - a) Die einleitenden Worte erhalten folgende Fassung: „Die Agentur übernimmt insbesondere folgende Aufgaben:“

  - b) Buchstabe a erhält folgende Fassung:

    - „a) sie wählt die Sachverständigen gemäß Artikel 106 Absätze 2 und 5 der Verordnung (EU) 2017/745 aus und ernennt sie und leistet den Expertengremien administrative und technische Unterstützung bei der Abgabe von Stellungnahmen und Erbringung von Beratungsleistungen;“

  - c) Die Buchstaben c, d und e erhalten folgende Fassung:

    - „c) sie gewährleistet, dass die Arbeit der Expertengremien gemäß Artikel 106 Absatz 3 und Artikel 107 der Verordnung (EU) 2017/745 unabhängig durchgeführt wird. Zu diesem Zweck richtet die Agentur Systeme und Verfahren ein, mit denen mögliche Interessenkonflikte aktiv bewältigt und verhindert werden können;

    - d) sie pflegt und aktualisiert regelmäßig eine Internetseite für die Expertengremien und veröffentlicht darauf alle Informationen, die erforderlich und noch nicht in Eudamed öffentlich zugänglich sind;

    - e) sie veröffentlicht die Stellungnahmen der Expertengremien gemäß der Verordnung (EU) 2017/745 bzw. der Verordnung (EU) 2017/746 unter Wahrung der Vertraulichkeit gemäß Artikel 109 der Verordnung (EU) 2017/745 bzw. Artikel 102 der Verordnung (EU) 2017/746;“

  - d) In Buchstabe f wird die Bezugnahme auf „Artikel 106 Absatz 14“ durch die Bezugnahme auf „Artikel 106 Absatz 10“ ersetzt;

  - e) Folgender Buchstabe i wird angefügt:

    - „i) sie übermittelt der Kommission eine begründete Empfehlung für die Gebühren, die von Herstellern oder Benannten Stellen für die von Expertengremien abgegebenen Stellungnahmen oder erbrachten Beratungsleistungen gemäß Artikel 106 Absätze 9 und 10 der Verordnung (EU) 2017/745 zu entrichten sind.“

**Artikel 4**

Änderungen der Verordnung (EU) 2024/1689

Anhang I der Verordnung (EU) 2024/1689 wird wie folgt geändert:

- 1. In Abschnitt A werden die Nummern 11 und 12 gestrichen.

- 2. In Abschnitt B werden die folgenden Nummern angefügt:

    „21. Verordnung (EU) 2017/745 des Europäischen Parlaments und des Rates vom 5. April 2017 über Medizinprodukte, zur Änderung der Richtlinie 2001/83/EG, der Verordnung (EG) Nr. 178/2002 und der Verordnung (EG) Nr. 1223/2009 und zur Aufhebung der Richtlinien 90/385/EWG und 93/42/EWG (ABl. L 117 vom 5.5.2017, S. 1);

    22. Verordnung (EU) 2017/746 des Europäischen Parlaments und des Rates vom 5. April 2017 über In-vitro-Diagnostika und zur Aufhebung der Richtlinie 98/79/EG und des Beschlusses 2010/227/EU der Kommission (ABl. L 117 vom 5.5.2017, S. 176).“

**Artikel 5**

Inkrafttreten und Anwendung

- (1) Diese Verordnung tritt am zwanzigsten Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft.

- (2) Sie gilt ab dem ... [Amt für Veröffentlichungen, bitte Datum einfügen = sechs Monate nach Inkrafttreten dieser Verordnung].

- (3) Abweichend von Absatz 2 gilt Folgendes:

  - a) Artikel 1 Nummern 47 und 95, Artikel 2 Nummern 33, 40 und 78, Artikel 3 und Artikel 4 gelten ab dem ... [Amt für Veröffentlichungen, bitte Datum einfügen = Datum des Inkrafttretens dieser Verordnung];

  - b) Artikel 1 Nummern 27 bis 40 und Artikel 2 Nummern 24, 25 und 26 gelten ab dem ... [Amt für Veröffentlichungen, bitte Datum einfügen = 12 Monate nach dem Datum des Inkrafttretens dieser Verordnung];

  - c) Artikel 1 Nummer 69 und Artikel 2 Nummer 55 gelten ab dem ... [Amt für Veröffentlichungen, bitte Datum einfügen = drei Jahre nach dem Datum des Inkrafttretens dieser Verordnung];

  - d) Artikel 1 Nummer 15 gilt ab dem ... [Amt für Veröffentlichungen, bitte Datum einfügen = fünf Jahre nach dem Datum des Inkrafttretens dieser Verordnung].

Diese Verordnung ist in allen ihren Teilen verbindlich und gilt unmittelbar in jedem Mitgliedstaat.

Geschehen zu Straßburg am […]

Im Namen des Europäischen Parlaments Im Namen des Rates

Die Präsidentin Die Präsidentin

<a id="finanz-und-digitalbogen-zu-rechtsakten"></a>
## FINANZ- UND DIGITALBOGEN ZU RECHTSAKTEN

### 1. RAHMEN DES VORSCHLAGS/DER INITIATIVE

#### 1.1. Bezeichnung des Vorschlags/der Initiative

    Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Änderung der Verordnungen (EU) 2017/745 und (EU) 2017/746 hinsichtlich der Vereinfachung und Verringerung der Belastungen durch die Vorschriften für Medizinprodukte und In-vitro-Diagnostika sowie zur Änderung der Verordnung (EU) 2022/123 hinsichtlich der Unterstützung der Europäischen Arzneimittel-Agentur für die Expertengremien für Medizinprodukte und zur Änderung der Verordnung (EU) 2024/1689 hinsichtlich der Liste der in Anhang I genannten Harmonisierungsrechtsvorschriften der Union

#### 1.2. Politikbereich(e)

    Wettbewerbsfähigkeit, Wohlstand und Sicherheit

#### 1.3. Ziel(e)

##### 1.3.1. Allgemeine(s) Ziel(e)

    Vereinfachung der Vorschriften für Medizinprodukte und In-vitro-Diagnostika, Verringerung des Verwaltungsaufwands für die Hersteller sowie Verbesserung der Vorhersehbarkeit und der Kosteneffizienz der Zertifizierungsverfahren durch Benannte Stellen bei gleichzeitiger Wahrung eines hohen Schutzniveaus für die öffentliche Gesundheit und die Patientensicherheit.

    Dadurch werden diese Maßnahmen das Wachstum und die Entwicklung der Unternehmen unterstützen, ihre Wettbewerbsfähigkeit sowie ihren Beitrag zu Wohlstand und Wohlergehen in Europa stärken und ein günstigeres unternehmerisches Umfeld fördern, das den Verwaltungsaufwand verringert und die Fähigkeit der Unternehmen stärkt, Innovationen voranzutreiben, Arbeitsplätze zu schaffen und das Wirtschaftswachstum anzukurbeln, und zugleich ein hohes Niveau der Patientenversorgung fördert.

##### 1.3.2. Einzelziel(e)

    Einzelziel Nr. 1: Steigerung der Kosteneffizienz und der Gesamtwettbewerbsfähigkeit des EU-Sektors für Medizinprodukte und In-vitro-Diagnostika durch die Förderung von Innovationen (unter anderem durch adaptive regulatorische Pfade für bahnbrechende Technologien sowie durch eine weitere Digitalisierung) bei gleichzeitiger Gewährleistung eines hohen Schutzniveaus der menschlichen Gesundheit für Patienten und Anwender.

    Einzelziel Nr. 2: Vereinfachung und Straffung bestimmter Anforderungen und Verfahren für Medizinprodukte und In-vitro-Diagnostika, die als besonders belastend und unverhältnismäßig eingestuft wurden, insbesondere für Produkte mit niedrigem und mittlerem Risiko sowie für Medizinprodukte für seltene Erkrankungen.

    Einzelziel Nr. 3: Verbesserung der Koordinierung zwischen den nationalen zuständigen Behörden, der Kommission/EMA und den Benannten Stellen, d. h. der Governance und Organisation des EU-Regelungsrahmens, sowie Ermöglichung, dass der EU-Medizinproduktesektor von der internationalen Zusammenarbeit, einschließlich Anerkennungsmechanismen, profitiert.

##### 1.3.3. Erwartete Ergebnisse und Auswirkungen

    Bitte geben Sie an, wie sich der Vorschlag/die Initiative auf die Begünstigten/Zielgruppen auswirken sollte.

    Der Vorschlag zielt darauf ab, das Funktionieren des derzeitigen Rechtsrahmens zu verbessern, insbesondere im Hinblick auf das reibungslose Funktionieren des Binnenmarkts, wobei zugleich ein hohes Schutzniveau für die Gesundheit der Patienten gewährleistet wird.

    Er baut auf den bestehenden wesentlichen Merkmalen des Rahmens auf, insbesondere auf dem dezentralen Ansatz mit den den Mitgliedstaaten zugewiesenen Zuständigkeiten und der Einbindung der Benannten Stellen in das Konformitätsbewertungsverfahren. Ziel dieser Überarbeitung ist es, einen schlankeren und kosteneffizienteren Rechtsrahmen zu gewährleisten und das bestehende Harmonisierungsniveau weiter zu stärken, um einen wettbewerbsfähigeren und innovativeren EU-Markt zu schaffen.

    Es wird erwartet, dass sich die Auswirkungen des vorliegenden Vorschlags auf mehrere Akteure erstrecken.

    Hersteller

  - • Sie profitieren von erhöhter rechtlicher Klarheit und Rechtssicherheit durch einen klareren Anwendungsbereich und präzisere Begriffsbestimmungen, einschließlich veröffentlichter Ergebnisse von Streitigkeiten in Bezug auf Klassifizierungen.

  - • Sie operieren innerhalb eines flexibleren und verhältnismäßigeren Rahmens für die klinische Bewertung und klinische Prüfungen (Beratung durch Expertengremien, verhältnismäßige klinische Aktualisierungen, Nutzung nichtklinischer Daten, klarere Regeln für schutzbedürftige Bevölkerungsgruppen).

  - • Sie unterliegen vereinfachten und weniger belastenden Klassifizierungs- und Konformitätsbewertungsverfahren, die Innovationen fördern (z. B. spezielle Pfade für bahnbrechende Medizinprodukte, Reallabore).

  - • Sie profitieren von gestrafften Erneuerungsverfahren für Zertifizierungen und verringerten damit verbundenen Kosten.

  - • Sie erleben einen geringeren Verwaltungsaufwand bei der Überwachung nach dem Inverkehrbringen, der Vigilanz und der Marktüberwachung.

  - • Sie gewinnen Zugang zu Expertengremien für eine frühzeitige Beratung, wodurch die Vorhersehbarkeit verbessert wird (bei teilweise zusätzlichen Kosten und Zeitaufwand).

  - • KMU profitieren von verhältnismäßigeren Gebühren und maßgeschneiderten Unterstützungsprogrammen, einschließlich der von der EMA angebotenen Unterstützung.

    Benannte Stellen

  - • Sie profitieren von verbesserter rechtlicher Klarheit und Rechtssicherheit aufgrund eines klareren Anwendungsbereichs und präziserer Begriffsbestimmungen.

  - • Sie operieren innerhalb eines effizienteren und besser vorhersehbaren Regelungsrahmens.

  - • Sie erleben möglicherweise eine Anpassung der Gebühreneinnahmen infolge vereinfachter Verfahren sowie eines gestraffteren Rahmens, der die Komplexität und den Verwaltungsaufwand verringert.

    Händler

  - • Sie profitieren von klareren Verpflichtungen und verbesserter Rechtssicherheit.

  - • Sie profitieren von stabileren und zuverlässigeren Lieferketten aufgrund verringerter Risiken von Versorgungsengpässen bei Medizinprodukten.

  - • Sie unterliegen geringerem Verwaltungsaufwand dank gestraffter Verfahren.

    Nationale zuständige Behörden

  - • Sie profitieren von einem klareren Anwendungsbereich, präziseren Begriffsbestimmungen und größerer Rechtssicherheit.

  - • Sie profitieren von vereinfachten Governance-Strukturen, verstärkten Koordinierungsmechanismen und internationaler Zusammenarbeit.

  - • Sie erreichen eine effizientere Aufsicht durch klarere Verfahren.

    Patienten, Anwender und Gesundheitssysteme

  - • Sie profitieren von der nachhaltigen Verfügbarkeit sicherer, hochwertiger und innovativer Produkte.

  - • Sie profitieren von besserer Verfügbarkeit von Informationen über das Regulierungsverfahren.

  - • Es bestehen geringere Risiken von Versorgungsengpässen, wodurch die Kontinuität der Versorgung gesichert wird.

  - • Sie profitieren von verbesserten Ergebnissen im Bereich der öffentlichen Gesundheit aufgrund von Sicherheit, Verfügbarkeit und Innovation.

##### 1.3.4. Leistungsindikatoren

  - – Dauerhafte Verfügbarkeit kritischer Produkte (Ziel: keine Versorgungsengpässe aus regulatorischen Gründen) (Messung der Verfügbarkeit und der Kontinuität der Versorgung)

  - – Verkürzte Dauer der Konformitätsbewertung

  - – Verringerter Verwaltungsaufwand für Hersteller (Ziel: messbare jährliche Verringerung).

  - – Erhöhte Zahl innovativer Produkte, die auf den Markt kommen

  - – Aufrechterhaltung der Verfügbarkeit von Medizinprodukten für seltene Erkrankungen sowie von Produkten, die für kleine Patientengruppen bestimmt sind.

  - – Stabile oder verbesserte Sicherheitsindikatoren (keine Zunahme schwerwiegender Vorkommnisse).

  - – Verbesserte Vorhersehbarkeit und Kohärenz bei regulatorischen Entscheidungen (z. B. Anzahl der Stellungnahmen von Expertengremien).

  - – Stärkere Beteiligung von KMU am EU-Markt für Medizinprodukte (Unterstützung von KMU bei der Nutzung des EU-Rechtsrahmens).

  - – Nutzung spezieller Pfade für bahnbrechende Medizinprodukte (Messung der Unterstützung von Innovationen)

  - – Beteiligung an internationalen Kooperationsmechanismen

#### 1.4. Der Vorschlag/Die Initiative betrifft

    ¨ eine neue Maßnahme

    ¨ eine neue Maßnahme im Anschluss an ein Pilotprojekt/eine vorbereitende Maßnahme^(52)

    x die Verlängerung einer bestehenden Maßnahme

    ¨ die Zusammenführung mehrerer Maßnahmen oder die Neuausrichtung mindestens einer Maßnahme

#### 1.5. Begründung des Vorschlags/der Initiative

##### 1.5.1. Kurz- oder langfristig zu deckender Bedarf, einschließlich einer detaillierten Zeitleiste für die Durchführung der Initiative

    Die Annahme der Verordnung durch die gesetzgebenden Organe wird für das zweite Quartal 2027 erwartet. Sie tritt am 20. Tag nach ihrer Veröffentlichung im Amtsblatt der Europäischen Union in Kraft. Für Maßnahmen, die verfahrensbezogene oder technische Anpassungen durch die Hersteller erfordern, um einen reibungslosen Übergang zum geänderten Regelungsrahmen zu gewährleisten, sind Übergangszeiträume vorgesehen.

##### 1.5.2. Mehrwert aufgrund des Tätigwerdens der EU (kann sich aus unterschiedlichen Faktoren ergeben, z. B. Vorteile durch Koordinierung, Rechtssicherheit, größere Wirksamkeit oder Komplementarität). Für die Zwecke dieses Abschnitts bezeichnet der Ausdruck „Mehrwert aufgrund des Tätigwerdens der EU“ den Wert, der sich aus dem Tätigwerden der EU ergibt und den Wert ergänzt, der andernfalls allein von den Mitgliedstaaten geschaffen worden wäre.

Die Verordnung (EU) 2017/745 über Medizinprodukte und die Verordnung (EU) 2017/746 über In-vitro-Diagnostika zielten darauf ab, einen robusten, transparenten, vorhersehbaren und dauerhaften Rechtsrahmen für Medizinprodukte und In-vitro-Diagnostika zu schaffen, der ein hohes Sicherheits- und Gesundheitsschutzniveau gewährleistet und zugleich Innovationen fördert. Sie gelten seit dem 26. Mai 2021 bzw. dem 26. Mai 2022.

Jedoch haben die deutlich anspruchsvolleren Anforderungen, die sich aus diesen Verordnungen ergeben, auch für bereits bestehende Produkte, in Verbindung mit den begrenzten Kapazitäten der Benannten Stellen und der unzureichenden Vorbereitung der Hersteller zu einem Risiko von Versorgungsengpässen und sogar zum Verschwinden kritischer Produkte vom Markt geführt. In der Praxis haben diese Herausforderungen gezeigt, dass bestimmte Elemente der Verordnungen selbst strukturelle Hindernisse geschaffen haben, die das System nicht bewältigen konnte.

Folglich wurden die Übergangsfristen wiederholt verlängert, doch haben diese Verlängerungen nur zu einer kurzfristigen Entlastung geführt und konnten die dem derzeitigen Rechtsrahmen zugrunde liegenden Probleme nicht beheben. Um diese strukturellen Probleme zu beheben und ein gestrafftes, vorhersehbares und zukunftssicheres System zu erreichen, ist durch diesen vorgeschlagenen Rechtsakt ein koordiniertes Vorgehen auf EU-Ebene erforderlich.

##### 1.5.3. Aus früheren ähnlichen Maßnahmen gewonnene Erkenntnisse

    Dieser Vorschlag geht aus den Ergebnissen der gezielten Bewertung hervor.

##### 1.5.4. Vereinbarkeit mit dem Mehrjährigen Finanzrahmen sowie mögliche Synergieeffekte mit anderen geeigneten Instrumenten

  - • Die Initiative wird vollständig durch Umschichtungen aus Programmen im Rahmen des Mehrjährigen Finanzrahmens (MFR) 2028-2034 finanziert.

  - • Strategische Projekte, die eine Schwachstelle in den Lieferketten kritischer Medizinprodukte adressieren, gelten als Beitrag zu den STEP-Zielen und können von einer Erleichterung der finanziellen Unterstützung profitieren, wenn ihnen auf der Grundlage der Verordnung (EU) 2024/795 zur Errichtung der Plattform „Strategische Technologien für Europa“ (STEP) das STEP-Siegel verliehen wird.

##### 1.5.5. Bewertung der verschiedenen verfügbaren Finanzierungsoptionen, einschließlich der Möglichkeiten für eine Umschichtung

    Nicht zutreffend

#### 1.6. Laufzeit der vorgeschlagenen Maßnahme/der Initiative und Dauer der finanziellen Auswirkungen

    ¨ Befristete Laufzeit

    - – ¨ Laufzeit: [TT.MM.]JJJJ bis [TT.MM.]JJJJ

    - – ¨ Finanzielle Auswirkungen auf die Mittel für Verpflichtungen von JJJJ bis JJJJ und auf die Mittel für Zahlungen von JJJJ bis JJJJ

    x Unbefristete Laufzeit

  - – Anlaufphase von JJJJ bis JJJJ

  - – Anschließend reguläre Umsetzung

#### 1.7. Vorgeschlagene Haushaltsvollzugsart(en)^(53)

    x Direkte Mittelverwaltung durch die Kommission

    - – x über ihre Dienststellen, einschließlich ihres Personals in den EU-Delegationen

    - – x über Exekutivagenturen

    ¨ Geteilte Mittelverwaltung mit Mitgliedstaaten

    x Indirekte Mittelverwaltung durch Übertragung von Haushaltsvollzugsaufgaben an:

    - – ¨ Drittländer oder die von ihnen benannten Einrichtungen

    - – ¨ internationale Einrichtungen und deren Agenturen (bitte angeben)

    - – ¨ die Europäische Investitionsbank und den Europäischen Investitionsfonds

    - – x Einrichtungen im Sinne der Artikel 70 und 71 der Haushaltsordnung

    - – ¨ öffentlich-rechtliche Körperschaften

    - – ¨ privatrechtliche Einrichtungen, die im öffentlichen Auftrag tätig werden, sofern ihnen ausreichende finanzielle Garantien bereitgestellt werden

    - – ¨ privatrechtliche Einrichtungen eines Mitgliedstaats, die mit der Einrichtung einer öffentlich-privaten Partnerschaft betraut werden und denen ausreichende finanzielle Garantien bereitgestellt werden

    - – ¨ Einrichtungen oder Personen, die mit der Durchführung bestimmter Maßnahmen im Bereich der Gemeinsamen Außen- und Sicherheitspolitik im Rahmen des Titels V des Vertrags über die Europäische Union betraut und die in dem maßgeblichen Basisrechtsakt benannt sind

    - – ¨ in einem Mitgliedstaat ansässige Einrichtungen, die dem Privatrecht eines Mitgliedstaats oder dem Unionsrecht unterliegen und im Einklang mit sektorspezifischen Vorschriften für die Betrauung mit der Ausführung von Unionsmitteln oder mit der Erteilung von Haushaltsgarantien in Betracht kommen, insofern diese Einrichtungen von privatrechtlichen, im öffentlichen Auftrag tätig werdenden Einrichtungen kontrolliert und von den Kontrollstellen mit angemessenen finanziellen Garantien mit gesamtschuldnerischer Haftung oder gleichwertigen finanziellen Garantien ausgestattet werden, die bei jeder Maßnahme auf den Höchstbetrag der Unionsunterstützung begrenzt sein können.

Bemerkungen

Der Haushalt wird von der Europäischen Kommission, der HaDEA und der Europäischen Arzneimittel-Agentur (EMA) umgesetzt.

### 2. VERWALTUNGSMAẞNAHMEN

#### 2.1. Überwachung und Berichterstattung

    Alle Agenturen der Union unterliegen einem strengen Überwachungssystem, das eine Koordinierungsstelle für interne Audits, den internen Auditdienst der Kommission, den Verwaltungsrat, die Kommission, den Rechnungshof und die Haushaltsbehörde umfasst. Dieses System spiegelt sich in der Gründungsverordnung der EMA wider und ist darin festgelegt. In Übereinstimmung mit der Gemeinsamen Erklärung zu den dezentralen EU-Agenturen („gemeinsames Konzept“) und der Rahmenfinanzregelung (2019/715) und der damit verbundenen Mitteilung der Kommission C(2020)2297 umfassen das jährliche Arbeitsprogramm und das Einheitliche Programmplanungsdokument der Agentur detaillierte Ziele und erwartete Ergebnisse einschließlich der Festlegung von Leistungsindikatoren. Das Einheitliche Programmplanungsdokument kombiniert die mehrjährige und die jährliche Programmplanung sowie „Strategiedokumente“, z. B. zur Unabhängigkeit. Die GD SANTE bringt ihren Standpunkt über den Verwaltungsrat der Agentur ein und erstellt eine förmliche Stellungnahme der Kommission zum Einheitlichen Programmplanungsdokument. Die Tätigkeiten der Agentur werden im konsolidierten jährlichen Tätigkeitsbericht an diesen Indikatoren gemessen. Die Agentur wird die Leistung ihres internen Kontrollsystems regelmäßig überwachen, um sicherzustellen, dass die Daten effizient, wirksam und zeitnah erhoben werden, und um Mängel bei der internen Kontrolle zu ermitteln, die Ergebnisse von Kontrollen, Kontrollabweichungen und Ausnahmen zu registrieren und zu bewerten. Die Ergebnisse der Beurteilung der internen Kontrolle, einschließlich der festgestellten erheblichen Mängel und etwaiger Abweichungen von den Feststellungen der internen und externen Prüfung, werden im konsolidierten jährlichen Tätigkeitsbericht offengelegt.

#### 2.2. Verwaltungs- und Kontrollsystem(e)

##### 2.2.1. Begründung der Haushaltsvollzugsart(en), des Durchführungsmechanismus/der Durchführungsmechanismen für die Finanzierung, der Zahlungsmodalitäten und der Kontrollstrategie, wie vorgeschlagen

    Der jährliche EU-Zuschuss wird der Agentur entsprechend ihrem Zahlungsbedarf und auf ihren Antrag hin überwiesen. Die Agentur wird Verwaltungskontrollen unterliegen, einschließlich Haushaltskontrolle, interner Rechnungsprüfung, Jahresberichten des Europäischen Rechnungshofes, der jährlichen Entlastung für die Ausführung des EU-Haushalts und möglichen Untersuchungen durch das OLAF, um insbesondere sicherzustellen, dass die der Agentur zugewiesenen Mittel ordnungsgemäß verwendet werden. Durch ihre Vertretung im Verwaltungsrat und im Prüfungsausschuss der Agentur erhält die Kommission Prüfberichte und stellt sicher, dass angemessene Maßnahmen festgelegt und von der Agentur rechtzeitig umgesetzt werden, um die festgestellten Probleme zu beheben. Alle Zahlungen bleiben Vorfinanzierungen, bis die Rechnungslegung der Agentur vom Europäischen Rechnungshof geprüft wurde und die Agentur ihren endgültigen Jahresabschluss vorgelegt hat. Erforderlichenfalls zieht die Kommission nicht in Anspruch genommene Beträge der an die Agentur gezahlten Raten zurück. Die Tätigkeit der Agentur unterliegt der Aufsicht des Bürgerbeauftragten gemäß Artikel 228 des Vertrags. Diese Verwaltungskontrollen bieten eine Reihe von Verfahrensgarantien, um sicherzustellen, dass die Interessen der Beteiligten berücksichtigt werden.

##### 2.2.2. Angaben zu den ermittelten Risiken und dem/den zu deren Eindämmung eingerichteten System(en) der internen Kontrolle

    Die Hauptrisiken betreffen die Leistung und Unabhängigkeit der Agentur bei der Durchführung der ihr übertragenen Aufgaben. Unzureichende Leistungen oder eine Beeinträchtigung der Unabhängigkeit könnten die Verwirklichung der Ziele dieser Initiative behindern und sich negativ auf den Ruf der Kommission auswirken. Die Kommission und die Agentur haben interne Verfahren eingeführt, mit denen die oben genannten Risiken abgedeckt werden sollen. Die internen Verfahren stehen uneingeschränkt mit der Haushaltsordnung im Einklang; sie umfassen Betrugsbekämpfungsmaßnahmen und sind geleitet von Kosten-Nutzen-Erwägungen. In erster Linie sollten der Agentur ausreichende finanzielle und personelle Ressourcen zur Verfügung gestellt werden, damit die Ziele dieser Initiative erreicht werden. Darüber hinaus umfasst das Qualitätsmanagement sowohl die Tätigkeiten des integrierten Qualitätsmanagements als auch das Risikomanagement innerhalb der Agentur. Jährlich wird eine Risikobewertung durchgeführt, bei der die noch verbleibenden Risiken bewertet werden, d. h. bereits bestehende Kontrollen und Minderungsmaßnahmen werden berücksichtigt. Die Durchführung von Selbstbewertungen (im Rahmen des Benchmarking-Programms der EU-Agenturen), jährliche Überprüfungen sensibler Funktionen und Ex-post-Kontrollen fallen ebenfalls in diesen Bereich, ebenso wie die Führung eines Ausnahmeregisters. Um bei allen Aspekten der Arbeit der Agentur Unparteilichkeit und Objektivität zu wahren, wurden eine Reihe von Strategien und Vorschriften für den Umgang mit konkurrierenden Interessen eingeführt, die regelmäßig aktualisiert werden und in denen spezifische Regelungen, Anforderungen und Verfahren beschrieben werden, die für den Verwaltungsrat der Agentur, die Mitglieder des wissenschaftlichen Ausschusses und die Sachverständigen, das Personal und die Bewerber der Agentur sowie Berater und Auftragnehmer gelten. Die Kommission wird rechtzeitig über einschlägige Fragen des Managements und der Unabhängigkeit unterrichtet, mit denen die Agentur konfrontiert ist, und reagiert auf mitgeteilte Sachverhalte rechtzeitig und auf angemessene Weise.

##### 2.2.3. Schätzung und Begründung der Kosteneffizienz der Kontrollen (Verhältnis zwischen den Kontrollkosten und dem Wert der betreffenden verwalteten Mittel) sowie Bewertung des erwarteten Ausmaßes des Fehlerrisikos (bei Zahlung und beim Abschluss)

    Die internen Kontrollstrategien der Kommission und der Agentur berücksichtigen die wichtigsten Kostenfaktoren und die bereits über mehrere Jahre unternommenen Anstrengungen zur Senkung der Kontrollkosten, ohne die Wirksamkeit der Kontrollen zu beeinträchtigen. Das bestehende Kontrollsystem hat sich bei der Vermeidung, Aufdeckung und Korrektur von Fehlern und Unregelmäßigkeiten bewährt. In den letzten fünf Jahren machten die jährlichen Kosten der Kommission für Kontrollen im Rahmen der indirekten Mittelverwaltung weniger als 1 % der jährlichen Ausgaben für an die Agentur gezahlten Zuschüsse aus. Die Agentur stellte weniger als 0,5 % ihres jährlichen Gesamthaushalts für Kontrolltätigkeiten bereit, die sich auf integriertes Qualitätsmanagement, Audits, Betrugsbekämpfungsmaßnahmen, Finanz- und Überprüfungsverfahren, Risikomanagement auf Unternehmensebene und Selbstbewertung konzentrieren.

#### 2.3. Prävention von Betrug und Unregelmäßigkeiten

    Was ihre Tätigkeiten in der indirekten Mittelverwaltung betrifft, trifft die Kommission geeignete Maßnahmen, um sicherzustellen, dass die finanziellen Interessen der Europäischen Union geschützt werden, indem präventive Maßnahmen gegen Betrug, Korruption und sonstige rechtswidrige Handlungen angewandt werden, wirksame Kontrollen durchgeführt werden und, sofern Unregelmäßigkeiten festgestellt werden,

    zu Unrecht gezahlte Beträge zurückgefordert werden sowie gegebenenfalls wirksame, verhältnismäßige und abschreckende Sanktionen verhängt werden. Zu diesem Zweck hat die Kommission eine Betrugsbekämpfungsstrategie angenommen, die zuletzt im April 2019 aktualisiert wurde (COM(2019) 196)^(54) und Präventiv-, Aufdeckungs- und Korrekturmaßnahmen umfasst. Die Kommission oder ihre Vertreter und der Europäische Rechnungshof sind befugt, bei allen Finanzhilfeempfängern, Auftragnehmern und Unterauftragnehmern, die EU-Mittel erhalten, Aktenprüfungen und Vor-Ort-Audits durchzuführen. Das Europäische Amt für Betrugsbekämpfung (OLAF) ist ermächtigt, bei allen indirekt durch Finanzierungen aus Unionsmitteln betroffenen Wirtschaftsakteuren Kontrollen und Überprüfungen vor Ort durchzuführen. In Bezug auf die Europäische Arzneimittel-Agentur sind die Betrugsbekämpfungsmaßnahmen in Artikel 69 der Verordnung (EG) Nr. 726/2004 und in der Rahmenfinanzregelung (2019/715) geregelt. Der Exekutivdirektor und der Verwaltungsrat werden die geeigneten Maßnahmen in Übereinstimmung mit den in allen EU-Organen angewandten Grundsätzen der internen Kontrolle ergreifen. Im Einklang mit dem gemeinsamen Konzept und Artikel 42 der Rahmenfinanzregelung wurde die Betrugsbekämpfungsstrategie entwickelt und wird von der Agentur angewandt. Die Betrugsbekämpfungsstrategie der Agentur erstreckt sich über einen Zeitraum von drei Jahren und wird von einem entsprechenden Aktionsplan begleitet, in dem sowohl spezifische Schwerpunktbereiche als auch Maßnahmen für die nächsten Jahre dargelegt werden, sowie mehrere fortlaufende Maßnahmen, die jedes Jahr durchgeführt werden, wie eine spezifische eigenständige Bewertung des Betrugsrisikos, wobei die ermittelten Betrugsrisiken in das allgemeine Risikoregister der Agentur aufgenommen werden. Schulungen zur Betrugsprävention werden im Rahmen der Einführungsschulung sowie mittels verpflichtender E-Learning-Schulungen zur Betrugsbekämpfung für neue Mitarbeiter durchgeführt. Die Bediensteten werden darüber informiert, wie sie den Verdacht eines Fehlverhaltens melden können, und es gibt Disziplinarverfahren gemäß den Bestimmungen des Statuts.

### 3. GESCHÄTZTE FINANZIELLE AUSWIRKUNGEN DES VORSCHLAGS/DER INITIATIVE

#### 3.1. Betroffene Rubrik(en) des Mehrjährigen Finanzrahmens und Ausgabenlinie(n) im Haushaltsplan

  - · Bestehende Haushaltslinien

    In der Reihenfolge der Rubriken des Mehrjährigen Finanzrahmens und der Haushaltslinien.

| Rubrik des Mehrjährigen Finanzrahmens | Haushaltslinie | Art der Ausgaben | Beiträge |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  | Nummer | GM/NGM^(55) | von EFTA-Ländern^(56) | von Kandidatenländern und potenziellen Kandidaten^(57) | von anderen Drittländern | andere zweckgebundene Einnahmen |
| 2 | Betriebsausgaben | GM | JA | JA | JA | NEIN |
| 2 | Unterstützungsausgaben | NGM | JA | JA | JA | NEIN |
| 2 | Beitrag der Union zur Europäischen Arzneimittel-Agentur | NGM | JA | JA | JA | NEIN |
| 4 | Zentrale Dienststellen und Vertretungen – Beamte und Bedienstete auf Zeit | NGM | NEIN | NEIN | NEIN | NEIN |
| 4 | Externes Personal – Zentrale Dienststellen und Vertretungen | NGM | NEIN | NEIN | NEIN | NEIN |
| 4 | Ausgaben für Konferenzen und Sitzungen | NGM | NEIN | NEIN | NEIN | NEIN |
| 4 | Dienstreise- und Repräsentationskosten, Ausgaben für Konferenzen | NGM | NEIN | NEIN | NEIN | NEIN |

#### 3.2. Geschätzte finanzielle Auswirkungen des Vorschlags auf die Mittel

##### 3.2.1. Übersicht über die geschätzten Auswirkungen auf die operativen Mittel

  - – ¨ Für den Vorschlag/die Initiative werden keine operativen Mittel benötigt.

  - – x Für den Vorschlag/die Initiative werden die folgenden operativen Mittel benötigt:

Die Beträge sind indikativ und greifen dem Ergebnis der laufenden Verhandlungen über den nächsten MFR nicht vor.

##### 3.2.1.1. Mittel aus dem verabschiedeten Haushaltsplan

in Mio. EUR (3 Dezimalstellen)

| Rubrik des Mehrjährigen Finanzrahmens | Nummer | 2 |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GD: <SANTE.> | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR INSGESAMT 2028-2034 | NACH 2024 |  |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |  |  |
| Operative Mittel |  |  |  |  |  |  |  |  |  |  |  |
| TBA | Verpflichtungen | (1a) | 0,297 | 0,303 | 0,309 | 0,315 | 0,322 | 0,328 | 0,335 | 2,210 | 0,335 |
|  | Zahlungen | (2a) | 0,059 | 0,209 | 0,303 | 0,309 | 0,315 | 0,321 | 0,694 | 2,210 | 0,694 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel |  |  |  |  |  |  |  |  |  |  |  |
| Unterstützungsausgaben |  | (3) | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 7,070 | 1,010 |
| Mittel INSGESAMT | Verpflichtungen | =1a+1b+3 | 1,307 | 1,313 | 1,319 | 1,325 | 1,332 | 1,338 | 1,345 | 9,280 | 1,345 |
| für GD <SANTE> | Zahlungen | =2a+2b+3 | 1,069 | 1,219 | 1,313 | 1,319 | 1,325 | 1,331 | 1,704 | 9,280 | 1,704 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

in Mio. EUR (3 Dezimalstellen)

| [Agentur]: <EMA> | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 (jährliche Ausgaben) |
| TBA / Beitrag der Union zur Europäischen Arzneimittel-Agentur | 3,209 | 4,689 | 4,782 | 4,878 | 4,976 | 5,075 | 5,177 | 32,785 | 5,280 |

Unbeschadet der Verhandlungen über den nächsten MFR werden die der Agentur ab 2028 zugewiesenen Mittel durch Umschichtungen aus einschlägigen Programmen derselben Rubrik wie die Agentur im Rahmen des MFR 2028-2034 ausgeglichen. Falls eine kompensatorische Kürzung erforderlich ist, müssen die den Agenturen zugewiesenen Mittel und ihre Finanzierungsströme gegebenenfalls überarbeitet werden.

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR INSGESAMT 2028-2034 | NACH 2034 |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | Jährliche Ausgaben |  |  |
| Operative Mittel INSGESAMT (einschließlich des Beitrags an die dezentrale Agentur) | Verpflichtungen | (4) | 3,506 | 4,992 | 5,092 | 5,193 | 5,297 | 5,403 | 5,511 | 34,995 | 5,615 |
|  | Zahlungen | (5) | 3,268 | 4,898 | 5,085 | 5,187 | 5,290 | 5,396 | 5,870 | 34,995 | 5,974 |
| Aus der Dotation bestimmter spezifischer Programme finanzierte Verwaltungsmittel INSGESAMT | (6) | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 7,070 | 1,010 |  |
| Mittel INSGESAMT unter der RUBRIK <SANTE> | Verpflichtungen | = 4+6 | 4,516 | 6,002 | 6,102 | 6,203 | 6,307 | 6,413 | 6,521 | 42,065 | 6,6256 |
| des Mehrjährigen Finanzrahmens | Zahlungen | = 5+6 | 4,278 | 5,908 | 6,095 | 6,197 | 6,300 | 6,406 | 6,880 | 42,065 | 6,984 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

====================================================================================================

==================================================================================================

| Rubrik des Mehrjährigen Finanzrahmens | 4 | „Verwaltungsausgaben“^(58) |
| --- | --- | --- |

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 (jährliche Ausgaben) |
| RUBRIK 4 |  |  |  |  |  |  |  |  |  |
| Personalausgaben | 2,820 | 2,820 | 2,820 | 2,820 | 2,820 | 2,820 | 2,820 | 19,740 | 2,820 |
| Sonstige Verwaltungsausgaben | 0,108 | 0,110 | 0,113 | 0,115 | 0,117 | 0,120 | 0,122 | 0,805 | 0,122 |
| Zwischensumme RUBRIK 4 | 2,928 | 2,930 | 2,933 | 2,935 | 2,937 | 2,940 | 2,942 | 20,545 | 2,942 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |  |
| Personalausgaben | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 7,070 | 1,010 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 4 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 7,070 | 1,010 |
| INSGESAMT | 3,938 | 3,940 | 3,943 | 3,945 | 3,947 | 3,950 | 3,952 | 27,615 | 3,952 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

in Mio. EUR (3 Dezimalstellen)

| RUBRIK 1-4 INSGESAMT |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR INSGESAMT 2028-2034 |  |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |  |
| Mittel INSGESAMT unter den RUBRIKEN 1 bis 4 | Verpflichtungen | 7,444 | 8,932 | 9,034 | 9,138 | 9,244 | 9,353 | 9,463 | 62,610 |
| des Mehrjährigen Finanzrahmens | Zahlungen | 7,207 | 8,838 | 9,028 | 9,132 | 9,238 | 9,346 | 9,822 | 62,610 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

##### 3.2.2. Geschätzter Output, der mit operativen Mitteln finanziert wird

Mittel für Verpflichtungen, in Mio. EUR (3 Dezimalstellen)

| Ziele und Outputs angeben |  |  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028-2034 | NACH |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ò |  |  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 |  |  |  |  |  |  |  |  |  |
|  | OUTPUTS |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Art | Durchschnitts- kosten | Nr. | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten | Anzahl | Kosten |
| EINZELZIEL Nr. 1, Nr. 2 und Nr. 3 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| - Eudamed – Wartung und Anpassung des Systems an die neuen Anforderungen |  |  |  | 0,297 |  | 0,303 |  | 0,309 |  | 0,315 |  | 0,322 |  | 0,328 |  | 0,335 |  | 2,210 |  | 0,335 |
| Zwischensumme für Einzelziel Nr. 1 |  | 0,297 |  | 0,303 |  | 0,309 |  | 0,315 |  | 0,322 |  | 0,328 |  | 0,335 |  | 2,210 |  | 0,335 |  |  |
| INSGESAMT |  | 0,297 |  | 0,303 |  | 0,309 |  | 0,315 |  | 0,322 |  | 0,328 |  | 0,335 |  | 2,210 |  | 0,335 |  |  |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

##### 3.2.3. Übersicht über die geschätzten Auswirkungen auf die Verwaltungsmittel

  - – ¨ Für den Vorschlag/die Initiative werden keine Verwaltungsmittel benötigt.

  - – x Für den Vorschlag/die Initiative werden die folgenden Verwaltungsmittel benötigt:

#####  3.2.3.1. Mittel aus dem verabschiedeten Haushaltsplan

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 Jährliche Ausgaben) |
| RUBRIK 4 |  |  |  |  |  |  |  |  |  |
| Personalausgaben | 2,820 | 2,820 | 2,820 | 2,820 | 2,820 | 2,820 | 2,820 | 19,740 | 2,820 |
| Sonstige Verwaltungsausgaben | 0,108 | 0,110 | 0,113 | 0,115 | 0,117 | 0,120 | 0,122 | 0,805 | 0,122 |
| Zwischensumme RUBRIK 4 | 2,928 | 2,930 | 2,933 | 2,935 | 2,937 | 2,940 | 2,942 | 20,545 | 2,942 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |  |
| Personalausgaben | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 7,070 | 1,010 |
| Sonstige Verwaltungsausgaben | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Zwischensumme außerhalb der RUBRIK 4 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 1,010 | 7,070 | 1,010 |
| INSGESAMT | 3,938 | 3,940 | 3,943 | 3,945 | 3,947 | 3,950 | 3,952 | 27,615 | 3,952 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

Der für Personalressourcen und sonstige Ausgaben administrativer Art erforderliche Mittelbedarf kann nicht durch Umschichtungen innerhalb der GD SANTE gedeckt werden und wird im Rahmen des jährlichen Zuteilungsverfahrens und unter Berücksichtigung der haushaltsrechtlichen Beschränkungen durch Umschichtungen innerhalb der Kommission gedeckt.

##### 3.2.4. Geschätzter Personalbedarf

  - – ¨ Für den Vorschlag/die Initiative wird kein Personal benötigt.

  - – x Für den Vorschlag/die Initiative wird das folgende Personal benötigt:

##### 3.2.4.1. Finanziert aus dem verabschiedeten Haushalt

Schätzung in Vollzeitäquivalenten (VZÄ)^(59)

| BEWILLIGTE MITTEL | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | NACH |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 |  |
| Ÿ Planstellen (Beamte und Bedienstete auf Zeit) |  |  |  |  |  |  |  |  |  |
| 20 01 02 01 (Zentrale Dienststellen und Vertretungen der Kommission) | 15 | 15 | 15 | 15 | 15 | 15 | 15 | 15 |  |
| 20 01 02 03 (EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 01 (Indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 11 (Direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| • Externes Personal (in Vollzeitäquivalenten) |  |  |  |  |  |  |  |  |  |
| 20 02 01 (VB und ANS der Globaldotation) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 20 02 03 (VB, ÖB, ANS und JPD in den EU-Delegationen) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Haushaltslinie Unterstützung =XX.01.YY.YY [2] | - in den zentralen Dienststellen | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
|  | - in den EU-Delegationen | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 01 01 01 02 (VB und ANS – indirekte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| 01 01 01 12 (VB und ANS – direkte Forschung) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (bitte angeben) – Rubrik 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| Sonstige Haushaltslinien (Haushaltslinie „Unterstützungskredite“ des Gesundheitsprogramms) – außerhalb von Rubrik 4 | 10 | 10 | 10 | 10 | 10 | 10 | 10 | 10 |  |
| INSGESAMT | 25 | 25 | 25 | 25 | 25 | 25 | 25 | 25 |  |

Angesichts der angespannten Lage in Rubrik 4 sowohl bei der Personalausstattung als auch der Höhe der Mittel wird der Personalbedarf durch bereits der Verwaltung der Maßnahme zugeordnetes Personal der GD oder durch Personalumschichtung innerhalb der GD oder anderer Kommissionsdienststellen gedeckt.

    Das für die Umsetzung des Vorschlags erforderliche interne Personal (15 VZÄ) wird durch zusätzliches Personal abgedeckt, das unter Rubrik 4 finanziert wird. Das zusätzliche externe Personal (10 VZÄ) wird aus den Unterstützungsausgaben der Haushaltslinie des Programms finanziert.

|  | Personal aus den Dienststellen der Kommission | Zusatzpersonal (ausnahmsweise)* |  |  |
| --- | --- | --- | --- | --- |
|  |  | Zu finanzieren aus Rubrik 4 oder Forschung | Zu finanzieren aus einer Haushaltslinie für administrative Unterstützung | Zu finanzieren aus Gebühren |
| Planstellen |  | 15 | Nicht zutreffend |  |
| Externes Personal (VB, ANS, LAK) |  |  | 10 |  |

* Die im vorliegenden Vorschlag enthaltenen Aufgaben können durch bestehende Personalressourcen und interne Umschichtungen innerhalb GD SANTE nicht vollständig abgedeckt werden, da die vorhandenen Ressourcen bereits Aufgaben aus dem bestehenden Rechtsrahmen zugewiesen sind und daher nicht umgeschichtet werden können. Darüber hinaus werden für die Umsetzung des Vorschlags neue, unterschiedliche Profile erforderlich sein.

    Beschreibung der Aufgaben, die ausgeführt werden sollen durch:

| Beamte und Zeitbedienstete | 1. Zusätzliche 13 VZÄ (5 AD + 2 AST + 6 CA FG IV) werden erforderlich sein, um gemeinsame Bewertungen von Benannten Stellen, die neuen gemeinsamen Überwachungstätigkeiten sowie verstärkte Koordinierungsmaßnahmen zu unterstützen. 2. Zusätzliche 12 VZÄ (8 AD und 4 CA FG IV) werden erforderlich sein, um die Umsetzung vor dem Hintergrund einer verstärkten EU-Aufsicht über Benannte Stellen und sonstige einschlägige Regulierungstätigkeiten sicherzustellen (d. h. Stärkung der Koordinierung, delegierte Rechtsakte und Durchführungsrechtsakte, Tätigkeiten der NBO-Arbeitsgruppe zur Beilegung divergierender Auffassungen und Streitigkeiten, Beteiligung an internationalen Programmen bzw. Anerkennungsprogrammen sowie die Beilegung von Qualifikations- und Klassifizierungsstreitigkeiten). |
| --- | --- |
| Externes Personal | Siehe oben |

##### 3.2.5. Einschätzung der Auswirkungen auf die Investitionen im Zusammenhang mit digitalen Technologien

    Obligatorisch: In die Tabelle unten ist die bestmögliche Einschätzung der für den Vorschlag/die Initiative erforderlichen Investitionen in digitale Technologien einzutragen.

    Wenn dies für die Durchführung des Vorschlags/der Initiative erforderlich ist, sollten die Mittel unter Rubrik 4 ausnahmsweise in der dafür vorgesehenen Haushaltslinie ausgewiesen werden.

    Die Mittel unter den Rubriken 1-3 sollten als „IT-Ausgaben zur Politikunterstützung für operationelle Programme“ ausgewiesen sein. Diese Ausgaben beziehen sich auf die operativen Mittel, die für die Wiederverwendung/den Erwerb/die Entwicklung von IT-Plattformen/Instrumenten verwendet werden, welche in direktem Zusammenhang mit der Durchführung der Initiative und den damit verbundenen Investitionen stehen (z. B. Lizenzen, Studien, Datenspeicherung usw.). Die in dieser Tabelle dargelegten Informationen sollten mit den Angaben in Abschnitt 4 „Digitale Aspekte“ vereinbar sein.

| Mittel INSGESAMT für Digitales und IT | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | MFR 2028-2034 INSGESAMT |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| RUBRIK 4 |  |  |  |  |  |  |  |  |
| IT-Ausgaben (intern) | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Zwischensumme RUBRIK 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Außerhalb der RUBRIK 4 |  |  |  |  |  |  |  |  |
| IT-Ausgaben zur Politikunterstützung für operationelle Programme | 0,297 | 0,303 | 0,309 | 0,315 | 0,322 | 0,328 | 0,335 | 2,210 |
| Zwischensumme außerhalb der RUBRIK 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| INSGESAMT | 0,297 | 0,303 | 0,309 | 0,315 | 0,322 | 0,328 | 0,335 | 2,210 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

##### 3.2.6. Vereinbarkeit mit dem derzeitigen Mehrjährigen Finanzrahmen

    Der Vorschlag/Die Initiative

  - – x kann durch Umschichtungen innerhalb der entsprechenden Rubrik des Mehrjährigen Finanzrahmens (MFR) in voller Höhe finanziert werden.

    Die Initiative wird vollständig durch Umschichtungen aus Programmen im Rahmen des Mehrjährigen Finanzrahmens (MFR) 2028-2034^(60) finanziert.

##### 3.2.7. Beiträge Dritter

    Der Vorschlag/Die Initiative

  - – x sieht keine Kofinanzierung durch Dritte vor.

  - – ¨ sieht folgende Kofinanzierung durch Dritte vor:

Mittel in Mio. EUR (3 Dezimalstellen)

|  | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Insgesamt |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  |
| Kofinanzierende Einrichtung |  |  |  |  |  |  |  |  |
| Kofinanzierung INSGESAMT |  |  |  |  |  |  |  |  |

##### 3.2.8. Schätzung des Personal- und Mittelbedarfs in einer dezentralen Agentur

Personalbedarf (Vollzeitäquivalente)

| [Agentur]: <EMA> | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 | 2034 (jährliche Anzahl) |
| Bedienstete auf Zeit (Funktionsgruppe AD) | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 5 |
| Bedienstete auf Zeit (Funktionsgruppe AST) | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 |
| Zwischensumme Bedienstete auf Zeit (AD+AST) | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 8 |
| Vertragsbedienstete | 16 | 16 | 16 | 16 | 16 | 16 | 16 | 16 |
| Abgeordnete nationale Sachverständige |  |  |  |  |  |  |  |  |
| Zwischensumme Vertragsbedienstete plus Abgeordnete nationale Sachverständige | 16 | 16 | 16 | 16 | 16 | 16 | 16 | 16 |
| Personal INSGESAMT | 24 | 24 | 24 | 24 | 24 | 24 | 24 | 24 |

Durch einen Beitrag aus dem EU-Haushalt gedeckte Mittel in Mio. EUR (3 Dezimalstellen)

| [Agentur]: <EMA> | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 (jährliche Ausgaben) |
| Titel 1: Personalausgaben | 1,808 | 3,688 | 3,762 | 3,837 | 3,914 | 3,992 | 4,072 | 25,075 | 4,154 |
| Titel 2: Infrastruktur- und Betriebsausgaben |  |  |  |  |  |  |  | 0,000 |  |
| Titel 3: Betriebsausgaben | 1,401 | 1,000 | 1,020 | 1,041 | 1,061 | 1,083 | 1,104 | 7,710 | 1,126 |
| Aus dem EU-Haushalt gedeckte Mittel INSGESAMT | 3,209 | 4,698 | 4,782 | 4,878 | 4,976 | 5,075 | 5,177 | 32,785 | 5,280 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

Etwaige durch Gebühren gedeckte Zahlungen in Mio. EUR (3 Dezimalstellen)

| [Agentur]: <EMA> | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 (jährliche Ausgaben) |
| Titel 1: Personalausgaben |  |  |  |  |  |  |  | 0,000 |  |
| Titel 2: Infrastruktur- und Betriebsausgaben |  |  |  |  |  |  |  | 0,000 |  |
| Titel 3: Betriebsausgaben |  | 0,600 | 0,610 | 0,650 | 0,750 | 0,770 | 0,800 | 4,180 | 0,816 |
| Durch Gebühren gedeckte Mittel INSGESAMT | 0,000 | 0,600 | 0,610 | 0,650 | 0,750 | 0,770 | 0,800 | 4,180 | 0,816 |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

Überblick/Zusammenfassung des Bedarfs an Personal und Mitteln (in Mio. EUR) für den Vorschlag/die Initiative in einer dezentralen Agentur

| [Agentur]: <EMA> | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | Jahr | INSGESAMT 2028 - 2034 | NACH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | 2028 | 2029 | 2030 | 2031 | 2032 | 2033 | 2034 |  | 2034 (jährliche Ausgaben) |
| Bedienstete auf Zeit (AD+AST) | 8 | 8 | 8 | 8 | 8 | 8 | 8 |  | 8 |
| Vertragsbedienstete | 16 | 16 | 16 | 16 | 16 | 16 | 16 |  | 16 |
| Abgeordnete nationale Sachverständige | 0 | 0 | 0 | 0 | 0 | 0 | 0 |  |  |
| Personal insgesamt | 24 | 24 | 24 | 24 | 24 | 24 | 24 |  | 24 |
| Aus dem EU-Haushalt gedeckte Mittel | 3,209 | 4,689 | 4,782 | 4,878 | 4,976 | 5,075 | 5,177 | 32,785 | 5,280 |
| Durch Gebühren gedeckte Mittel | 0,000 | 0,600 | 0,610 | 0,650 | 0,750 | 0,770 | 0,800 | 4,180 | 0,816 |
| Kofinanzierte Mittel (falls zutreffend) | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 | 0,000 |
| Mittel INSGESAMT | 3,209 | 5,289 | 5,392 | 5,528 | 5,726 | 5,845 | 5,977 | 36,965 | 6,096 |

| Bedienstete auf Zeit und externes Personal 1. Ausgaben im Zusammenhang mit der EMA: Diese Komponente deckt den Finanzbedarf für zusätzliche VZÄ bei der EMA ab, der sich aus neuen oder erweiterten Aufgaben ergibt, etwa der Verwaltung einer zunehmenden Zahl von Expertengremien sowie neuen Zuständigkeiten für die Überwachung von Engpässen bei Medizinprodukten, einschließlich der Erstellung und Pflege einer Liste kritischer Medizinprodukte. Dies entspricht 24 zusätzlichen VZÄ, um die oben genannten zusätzlichen Tätigkeiten abzudecken, die der Agentur übertragen werden sollen: a) 11 VZÄ für Expertengremien infolge der Ausweitung des Anwendungsbereichs auf In-vitro-Diagnostika und alle Produkte der Klasse III (2 AD, 2 AST, 6 CA FG IV und 1 CA FG II) b) 9 VZÄ für Governance (10 VZÄ für verstärkte Koordinierung der nationalen zuständigen Behörden in spezifischen Bereichen und 2 VZÄ zur Unterstützung der Hersteller durch das KMU-Büro) (2 AD, 1 AST und 6 CA FG IV) c) 4 VZÄ für Artikel 10a Absatz 4 (IT-System zur Überwachung von Engpässen, Umsetzung von Änderungen an der Datenbank) und Artikel 10a Absatz 5 (Erstellung und Verwaltung einer Liste kritischer Medizinprodukte) (1 AD und 3 CA FG IV). |
| --- |

* Bei den Zahlen in der vorstehenden Tabelle handelt es sich lediglich um Richtwerte, bis das Ergebnis der Verhandlungen über den MFR 2028-2034 vorliegt.

3.3. Geschätzte Auswirkungen auf die Einnahmen

  - – x Der Vorschlag/Die Initiative wirkt sich nicht auf die Einnahmen aus.

  - – ¨ Der Vorschlag/Die Initiative wirkt sich auf die Einnahmen aus, und zwar

- – ¨ auf die Eigenmittel

- – ¨ auf die übrigen Einnahmen

- – ¨ Bitte geben Sie an, ob die Einnahmen bestimmten Ausgabenlinien zugeordnet sind.

in Mio. EUR (3 Dezimalstellen)

| Einnahmenlinie: | Für das laufende Haushaltsjahr zur Verfügung stehende Mittel | Auswirkungen des Vorschlags/der Initiative^(61) |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | Jahr 2028 | Jahr 2029 | Jahr 2030 | Jahr 2031 | Jahr 2032 | Jahr 2033 | Jahr 2034 |
| Artikel …. |  |  |  |  |  |  |  |  |

    Bitte geben Sie für die sonstigen zweckgebundenen Einnahmen die betreffende(n) Ausgabenlinie(n) im Haushaltsplan an.

    Sonstige Anmerkungen (bei der Ermittlung der Auswirkungen auf die Einnahmen verwendete Methode/Formel oder weitere Informationen).

### 4. Digitale Aspekte

    Ausgangslage: Die MP-VO und die IVD-VO sind bereits durch eine hohe digitale Relevanz gekennzeichnet, da mit der Einführung der Europäischen Datenbank für Medizinprodukte (Eudamed) ein vernetztes IT-System mit sechs Modulen geschaffen wurde, das Daten zum gesamten Lebenszyklus der auf dem EU-Markt in Verkehr gebrachten Medizinprodukte speichert. Eudamed erhöht nicht nur die Transparenz und Rückverfolgbarkeit, sondern ist auch ein wesentliches Instrument für alle an der Einhaltung der Verordnungen beteiligten Akteure. Vier der sechs Module von Eudamed sind abgeschlossen. Diese Datenbank bzw. dieses System wird die weitere Digitalisierung des Medizinproduktesektors erleichtern und ein erhebliches Potenzial für Digitalisierung und Harmonisierung bieten.

    Mit der Änderungsverordnung werden Vereinfachungsmaßnahmen sowie neue Berichtspflichten eingeführt; sie wirkt sich daher auf die bereits entwickelten Module von Eudamed aus.

    Ausgehend von dieser Annahme wurde in Bezug auf Eudamed die nachstehende Tabelle erstellt, wobei die Auswirkungen bzw. der Änderungsbedarf der durch den Vorschlag eingeführten Bestimmungen auf die bereits abgeschlossenen Module berücksichtigt wurden.

#### 4.1. Anforderungen von digitaler Relevanz

| Verweis auf die Anforderung (MP-VO/IVD-VO) | Beschreibung der Anforderung | Von der Anforderung betroffene oder sie betreffende Akteure | Verfahren auf übergeordneter Ebene | Kategorien |
| --- | --- | --- | --- | --- |
| Artikel 10a Absatz 4 (MP-VO/IVD-VO) | Die Kommission richtet erforderlichenfalls in Zusammenarbeit mit der EMA eine IT-Plattform für die Meldung und den Informationsaustausch über Unterbrechungen oder die Beendigung der Versorgung mit Medizinprodukten ein und betreibt und verwaltet sie | Wirtschaftsakteure Zuständige Behörden der Mitgliedstaaten | Marktüberwachung | Daten Digitale Lösung Digitaler öffentlicher Dienst |
| Artikel 18 Absatz 1 MP-VO | Der Hersteller kann die Angaben des Implantationsausweises in elektronischer oder digitaler Form bereitstellen | Wirtschaftsakteure | Rückverfolgbarkeit Kennzeichnung | Daten |
| Artikel 19 Absatz 2a MP-VO / Artikel 17 Absatz 2a IVD-VO | Die Konformitätserklärung kann in elektronischer Form vorgelegt werden | Wirtschaftsakteure | Konformität des Produkts | Daten |
| Artikel 30 Absatz 2 MP-VO / Artikel 27 Absatz 2 IVD-VO | Nationale Datenbanken über Händler rufen die Geräteinformationen aus Eudamed ab | Zuständige Behörden der Mitgliedstaaten Händler | Registrierung von Händlern | Daten Digitaler Dienst |
| Artikel 52b MP-VO / Artikel 48b IVD-VO | Digitalisierung der Konformitätsbewertung: Im Einvernehmen mit den Benannten Stellen kann der Hersteller die technische Dokumentation in digitaler Form sowie sämtliche Berichte oder Unterlagen für die Zwecke der Konformitätsbewertungsverfahren bereitstellen. | Hersteller Benannte Stellen | Konformitätsbewertung | Daten Digitaler Dienst |
| Artikel 60 MP-VO / Artikel 55 IVD-VO | (Eudamed) Freiverkaufszertifikate werden von der zuständigen Behörde in Eudamed bereitgestellt | Zuständige Behörden | Transparenz | Daten Digitaler Dienst |
| Artikel 87a Absatz 2 MP-VO / Artikel 82a Absatz 2 IVD-VO | Meldung aktiv ausgenutzter Schwachstellen und schwerwiegender Sicherheitsvorfälle bei vernetzten Medizinprodukten | Hersteller Zuständige Behörden der Mitgliedstaaten Als Koordinatoren benannte CSIRTs und ENISA | Cybersicherheit | Daten |
| Artikel 106b Absatz 5 MP-VO | Zugang der EMA zu Eudamed | EMA | Unterstützung durch die EMA | Daten Digitaler Dienst |
| Artikel 110a MP-VO / Artikel 103a IVD-VO | Elektronische Übermittlung von Informationen oder Unterlagen | Alle, die nach der MP-VO einer entsprechenden Verpflichtung unterliegen | Übermittlung von Informationen/Unterlagen | Digitaler Dienst |
| Anhang I Abschnitt 23.1 Buchstabe c MP-VO / Anhang I Abschnitt 20.1 Buchstabe c IVD-VO | Kennzeichnungen können nach Maßgabe der gemäß der MP-VO erlassenen Durchführungsbestimmungen in digitaler Form bereitgestellt werden | Wirtschaftsakteure | Kennzeichnung | Digitaler öffentlicher Dienst |
| Anhang VI Teil A Abschnitte 1.2 und 1.3 (MP-VO/IVD-VO) und Teil B Abschnitt 13 MP-VO / Abschnitt 10 IVD-VO | Kontaktdaten, einschließlich digitaler Kontaktdaten | Wirtschaftsakteure | Kommunikation | Daten |
| Anhang VI Teil B Abschnitt 37 MP-VO / Abschnitt 29 IVD-VO | Bereitstellung der Gebrauchsanweisung in elektronischer Form oder Angabe der URL der Website, auf der sie verfügbar ist | Hersteller | Verfügbarkeit der Gebrauchsanweisung | Daten Digitaler öffentlicher Dienst |

#### 4.2. Daten

| Verweis auf die Anforderung (MP-VO/IVD-VO) | Art der Daten | Standard und/oder Spezifikation (falls zutreffend) |
| --- | --- | --- |
| Artikel 10a Absatz 4 (MP-VO/IVD-VO) | Daten zu möglichen Engpässen bei Medizinprodukten |  |
| Artikel 18 Absatz 1 MP-VO | Daten zu implantierbaren Produkten |  |
| Artikel 19 Absatz 2a MP-VO / Artikel 17 Absatz 2a IVD-VO | Angaben zur Konformität des Produkts |  |
| Artikel 30 Absatz 2 MP-VO / Artikel 27 Absatz 2 IVD-VO | Produktdaten | In barrierefreien Formaten; unentgeltlich sowie in klarer, umfassender, benutzerfreundlicher und leicht zugänglicher Weise. Download im XML-Format. Öffentlich einsehbar |
| Artikel 52b MP-VO / Artikel 48b IVD-VO | Technische Dokumentation des Produkts |  |
| Artikel 60 MP-VO / Artikel 55 IVD-VO | Daten zu Freiverkaufszertifikaten | In barrierefreien Formaten; unentgeltlich sowie in klarer, umfassender, benutzerfreundlicher und leicht zugänglicher Weise. Download im XML-Format. Öffentlich einsehbar |
| Artikel 87a Absatz 2 MP-VO / Artikel 82a Absatz 2 IVD-VO | Daten zu aktiv ausgenutzten Schwachstellen und schwerwiegenden Sicherheitsvorfällen bei vernetzten Medizinprodukten | In barrierefreien Formaten; unentgeltlich sowie in klarer, umfassender, benutzerfreundlicher und leicht zugänglicher Weise. Upload/Download im XML-Format |
| Artikel 106b Absatz 5 MP-VO | Eudamed-Daten | In barrierefreien Formaten; unentgeltlich sowie in klarer, umfassender, benutzerfreundlicher und leicht zugänglicher Weise. |
| Artikel 110a MP-VO / Artikel 103a IVD-VO | Dokumentation zu Medizinprodukten |  |
| Anhang I Abschnit t 23.1 Buchstabe c MP-VO / Anhang I Abschnitt 20.1 Buchstabe c IVD-VO | Daten auf Kennzeichnungen von Medizinprodukten |  |
| Anhang VI Teil A Abschnitte 1.2 und 1.3 (MP-VO/IVD-VO) und Teil B Abschnitt 13 MP-VO / Abschnitt 10 IVD-VO | --------Kontaktangaben |  |
| Anhang VI Teil B Abschnitt 37 MP-VO / Abschnitt 29 IVD-VO | Daten zu Gebrauchsanweisungen von Produkten |  |

    Vereinbarkeit mit der europäischen Datenstrategie

    Der Vorschlag steht im Einklang mit der Datenstrategie, da er gegenüber der MP-VO und der IVD-VO die weitere Digitalisierung bestimmter Verfahren fördert, wie etwa die Übermittlung der technischen Dokumentation und anderer einschlägiger Unterlagen durch die Hersteller an die Benannten Stellen; er umfasst in Eudamed neue Elemente wie Freiverkaufszertifikate und die Gebrauchsanweisungen der Produkte und erweitert damit den öffentlich zugänglichen Datenbestand weiter; darüber hinaus vereinfacht er bestimmte Arbeitsabläufe, die in Eudamed durchzuführen sind und erleichtert damit die Nutzung der Systeme für die beteiligten Akteure.

    Eudamed: Die Kommission ist Verantwortlicher und Auftragsverarbeiter für die Daten.

    Kein Link zum Europäischen Gesundheitsdatenraum (EHDS).

    Grundsatz der einmaligen Erfassung

    Nicht zutreffend, da der Grundsatz der einmaligen Erfassung bereits mit der Einrichtung von Eudamed in der MP-VO/IVD-VO verankert wurde. Der Vorschlag baut nun lediglich darauf auf; die ursprüngliche Einhaltung dieses Prinzips war jedoch bereits in den ursprünglichen Verordnungen vorgesehen.

    Datenströme

| Art der Daten | Anforderung(en) | Akteure, die die Daten bereitstellen | Akteure, die die Daten empfangen | Auslöser für den Datenaustausch | Häufigkeit (falls zutreffend) |
| --- | --- | --- | --- | --- | --- |
| Implantationsausweis einschließlich in elektronischem oder digitalem Format | Artikel 18 Absatz 1 MP-VO | Wirtschaftsakteure | Patienten, Angehörige der Gesundheitsberufe, zuständige Behörden | Produktkontrolle/Rückverfolgbarkeit |  |
| EU-Konformitätserklärung | Artikel 19 Absatz 2a MP-VO, Artikel 17 Absatz 2a IVD-VO | Wirtschaftsakteure | Patienten, Angehörige der Gesundheitsberufe, zuständige Behörden | Konformität des Produkts |  |
| Produktdaten | Artikel 30 Absatz 2 MP-VO / Artikel 27 Absatz 2 IVD-VO | Wirtschaftsakteure | Zuständige Behörden der Mitgliedstaaten | Produktkontrolle |  |
| Freiverkaufszertifikate | Artikel 60 MP-VO, Artikel 55 IVD-VO | Zuständige Behörden | Öffentlich | Produktkontrolle |  |
| Technische Dokumentation des Produkts für die Konformitätsbewertung in elektronischer Form | Artikel 52b MP-VO, Artikel 48b IVD-VO | Wirtschaftsakteure | Zuständige Behörden Benannte Stellen | Produktkontrolle Konformitätsbewertung |  |
| Informationen über aktiv ausgenutzte Schwachstellen und schwerwiegende Sicherheitsvorfälle bei vernetzten Medizinprodukten | Artikel 87a Absatz 2 MP-VO / Artikel 82a Absatz 2 IVD-VO | Hersteller | Zuständige Behörden der Mitgliedstaaten Als Koordinatoren benannte CSIRTs und ENISA | Cybersicherheitsproblem/-vorfall |  |
| Daten zu möglichen Engpässen bei Medizinprodukten | Artikel 10a MP-VO, Artikel 10a IVD-VO | Wirtschaftsakteure | Zuständige Behörden Gesundheitseinrichtungen und Angehörige der Gesundheitsberufe | Meldepflicht Produktkontrolle |  |

#### 4.3. Digitale Lösungen

| Digitale Lösung | Art der Daten | Anforderung(en) | Wichtigste vorgeschriebene Funktion | Zuständige Stelle | Inwiefern wird Zugänglichkeit gewährleistet? | Wie wird die Wiederverwendbarkeit berücksichtigt? | Einsatz von KI? |
| --- | --- | --- | --- | --- | --- | --- | --- |
| IT-Plattform | Daten zu Engpässen bei Medizinprodukten | Artikel 10a MP-VO, Artikel 10a IVD-VO | Wirtschaftsakteuren ermöglichen, Informationen über mögliche Engpässe bei Produkten bereitzustellen | EMA | Die einschlägigen Bestimmungen der Barrierefreiheitsrichtlinie^(62) werden in den technischen Spezifikationen genannt. | Einheitliche Plattform für die Berichterstattung | Nicht zutreffend |
| Dokument in elektronischem Format | Implantationsausweis, Konformitätserklärung | Artikel 18 Absatz 1, Artikel 19 Absatz 2a MP-VO, Artikel 17 Absatz 2a IVD-VO | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend |
| Nationales elektronisches System | Produktinformationen | Artikel 30 Absatz 2 MP-VO / Artikel 27 Absatz 2 IVD-VO | Abruf von Produktdaten aus dem einschlägigen elektronischen System von Eudamed | Zuständige Behörden der Mitgliedstaaten | Die einschlägigen Bestimmungen der Barrierefreiheitsrichtlinie werden in den technischen Spezifikationen genannt | Aus Eudamed abgerufene Daten, die nicht von Wirtschaftsakteuren in nationalen Systemen erneut bereitgestellt werden | Nicht zutreffend |
| Elektronisches System in Eudamed | Freiverkaufszertifikate | Artikel 60 MP-VO, Artikel 55 IVD-VO | Das Hochladen von Freiverkaufszertifikaten ermöglichen und sie der Öffentlichkeit zugänglich machen | KOM | Die einschlägigen Bestimmungen der Barrierefreiheitsrichtlinie werden in den technischen Spezifikationen genannt | Einheitliche Plattform für die Berichterstattung | Nicht zutreffend |
| Dokument in elektronischem Format | Technische Dokumentation des Produkts für die Konformitätsbewertung in elektronischer Form | Artikel 52b MP-VO, Artikel 48b IVD-VO | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend |
| Elektronisches System in Eudamed | Daten zu Cybersicherheitsvorfällen und Schwachstellen von Medizinprodukten | Artikel 87a Absatz 2 MP-VO / Artikel 82a Absatz 2 IVD-VO | Die Meldung von Cybersicherheitsvorfällen und Schwachstellen durch Wirtschaftsakteure ermöglichen | KOM | Die einschlägigen Bestimmungen der Barrierefreiheitsrichtlinie werden in den technischen Spezifikationen genannt | Einheitliche Plattform für die Berichterstattung | Nicht zutreffend |
| Elektronische Systeme in Eudamed | Daten zu Medizinprodukten | Artikel 106b Absatz 5 MP-VO | Der EMA den Zugang zu den Daten der elektronischen Systeme von Eudamed ermöglichen | KOM | Die einschlägigen Bestimmungen der Barrierefreiheitsrichtlinie werden in den technischen Spezifikationen genannt | Nicht zutreffend | Nicht zutreffend |
| Dokument in elektronischem Format | Dokumentation zu Medizinprodukten | Artikel 110a MP-VO / Artikel 103a IVD-VO | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend |
| Dokument in elektronischem Format | Daten auf Kennzeichnungen | Anhang I Abschnitt 23.1 Buchstabe c MP-VO / Anhang I Abschnitt 20.1 Buchstabe c IVD-VO | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend | Nicht zutreffend |

Digitale Lösung 1 EUDAMED

| Digitale und/oder sektorspezifische Strategie (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen. |
| EU-Rahmen für Cybersicherheit | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen, einschließlich der Einhaltung der Verordnung (EU) 2024/2847. |
| eIDAS | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen. |
| Einheitliches digitales Zugangstor und IMI | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen. |
| Sonstige |  |

    Digitale Lösung 2 IT-Plattform (falls als Alternative zu Eudamed für die Zwecke des Artikels 10a gewählt)

| Digitale und/oder sektorspezifische Strategie (falls anwendbar) | Erläuterung der Vereinbarkeit |
| --- | --- |
| KI-Verordnung | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen. |
| EU-Rahmen für Cybersicherheit | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen, einschließlich der Einhaltung der Verordnung (EU) 2024/2847. |
| eIDAS | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen. |
| Einheitliches digitales Zugangstor und IMI | Ist bei delegierten Rechtsakten und Durchführungsrechtsakten zu berücksichtigen. |
| Sonstige |  |

#### 4.4. Interoperabilitätsbewertung

Allgemeine Beschreibung der von den Anforderungen betroffenen digitalen öffentlichen Dienste

| Digitaler öffentlicher Dienst oder Kategorie digitaler öffentlicher Dienste | Beschreibung | Anforderung(en) | Lösung(en) für ein interoperables Europa (NICHT ZUTREFFEND) | Andere Interoperabilitätslösung(en) |
| --- | --- | --- | --- | --- |
| Konformitätsbewertung von Medizinprodukten | Hersteller dürfen Konformitätsbewertungsunterlagen in digitaler Form übermitteln | MP-VO Artikel 52b, IVD-VO Artikel 48b | Nicht zutreffend | Diese Lösung wird die künftige Interoperabilität erleichtern |
| Eudamed | Europäische Datenbank für Medizinprodukte | MP-VO Artikel 33, IVD-VO Artikel 30 | Nicht zutreffend | Derzeit interoperabel mit nationalen Datenbanken und den Systemen der Wirtschaftsakteure (Datenaustausch über Maschine-Maschine-Schnittstellen). |

Auswirkungen der Anforderung(en) auf die grenzüberschreitende Interoperabilität nach digitalem öffentlichen Dienst

Digitale öffentliche Dienste: Konformitätsbewertung von Medizinprodukten und Eudamed

| Bewertung | Maßnahme(n) | Mögliche verbleibende Hindernisse (falls zutreffend) |
| --- | --- | --- |
| Vereinbarkeit mit bestehenden digitalen und sektorspezifischen Strategien. |  |  |
| Organisatorische Maßnahmen für eine reibungslose grenzüberschreitende Erbringung digitaler öffentlicher Dienste. | Erweiterte Rolle der Europäischen Arzneimittel-Agentur |  |
| Maßnahmen, die ergriffen wurden, um ein gemeinsames Verständnis der Daten zu gewährleisten. Bitte führen Sie solche Maßnahmen auf. | Wiederverwendung des bereits durch frühere Fassungen der MP-VO/IVD-VO definierten und etablierten Eudamed-Datenmodells |  |
| Verwendung gemeinsam vereinbarter offener technischer Spezifikationen und Standards. Bitte führen Sie solche Maßnahmen auf. | Nicht zutreffend für die neuen Anforderungen |  |

#### 4.5. Unterstützungsmaßnahmen für die digitale Umsetzung

| Beschreibung der Maßnahme | Verweis(e) auf die Anforderung(en) | Rolle der Kommission (falls zutreffend) | Zu beteiligende Akteure (falls zutreffend) | Voraussichtlicher Zeitplan (falls zutreffend) |
| --- | --- | --- | --- | --- |
| Die Kommission wird die IKT-Beschaffung nutzen, um die erforderlichen Funktionalitäten in Eudamed einzurichten, und kann Durchführungsrechtsakte bzw. delegierte Rechtsakte erlassen, um weitere Einzelheiten zur Umsetzung der einschlägigen Anforderungen bzw. Artikel festzulegen. | Artikel 60, Artikel 87a, Artikel 106b Absatz 5 MP-VO, Artikel 55, Artikel 82a Absatz 2 IVD-VO | Die Kommission richtet die Funktionalitäten ein und erlässt erforderlichenfalls solche Rechtsakte. | EMA Wirtschaftsakteure Zuständige Behörden der Mitgliedstaaten |  |
| Die Kommission oder die EMA kann die IKT-Beschaffung nutzen, um die erforderlichen Funktionalitäten in der IT-Plattform einzurichten. | Artikel 10a MP-VO, Artikel 10a IVD-VO | Die Kommission wird die erforderlichen Synergien mit Eudamed fördern. | Wirtschaftsakteure Gesundheitseinrichtungen Angehörige der Gesundheitsberufe Zuständige Behörden der Mitgliedstaaten |  |

^(1) https://www.who.int/health-topics/medical-devices#tab=tab_ 1 (abgerufen am 17.10.2025).

^(2) https://www.medtecheurope.org/resource-library/medtech-europes-facts-figures-2025/ (abgerufen am 17.10.2025). Die Daten beziehen sich auf die EU-27 sowie auf Island, Norwegen, die Schweiz und das Vereinigte Königreich.

^(3) Verordnung (EU) 2017/745 des Europäischen Parlaments und des Rates vom 5. April 2017 über Medizinprodukte, zur Änderung der Richtlinie 2001/83/EG, der Verordnung (EG) Nr. 178/2002 und der Verordnung (EG) Nr. 1223/2009 und zur Aufhebung der Richtlinien 90/385/EWG und 93/42/EWG (ABl. L 117 vom 5.5.2017, S. 1).

^(4) Verordnung (EU) 2017/746 des Europäischen Parlaments und des Rates vom 5. April 2017 über In-vitro-Diagnostika und zur Aufhebung der Richtlinie 98/79/EG und des Beschlusses 2010/227/EU der Kommission ( ABl. L 117 vom 5.5.2017, S. 176 ).

^(5) Medizinprodukte werden in die Klassen I (geringes Risiko), IIa (geringes bis mittleres Risiko), IIb (mittleres bis hohes Risiko) und III (hohes Risiko) eingestuft; In-vitro-Diagnostika werden in die Klassen A (geringes individuelles Risiko und geringes Risiko für die öffentliche Gesundheit), B (mäßiges individuelles Risiko und geringes Risiko für die öffentliche Gesundheit), C (hohes individuelles Risiko und mäßiges Risiko für die öffentliche Gesundheit) und D (hohes individuelles Risiko und hohes Risiko für die öffentliche Gesundheit) eingeteilt.

^(6) Mit der Verordnung (EU) 2020/561 des Europäischen Parlaments und des Rates vom 23. April 2020 zur Änderung der Verordnung (EU) 2017/745 über Medizinprodukte hinsichtlich des Geltungsbeginns einiger ihrer Bestimmungen (ABl. L 130 vom 24.4.2020, S. 18) wurde der Geltungsbeginn der Verordnung (EU) 2017/745 aufgrund des COVID-19-Ausbruchs und der damit verbundenen Krise im Bereich der öffentlichen Gesundheit vom 26. Mai 2020 auf den 26. Mai 2021 verschoben.

^(7) Verordnung (EU) 2023/607 des Europäischen Parlaments und des Rates vom 15. März 2023 zur Änderung der Verordnungen (EU) 2017/745 und (EU) 2017/746 hinsichtlich der Übergangsbestimmungen für bestimmte Medizinprodukte und In-vitro-Diagnostika (ABl. L 80 vom 20.3.2023, S. 24).

^(8) Verordnung (EU) 2022/112 des Europäischen Parlaments und des Rates vom 25. Januar 2022 zur Änderung der Verordnung (EU) 2017/746 hinsichtlich der Übergangsbestimmungen für bestimmte In-vitro-Diagnostika und des späteren Geltungsbeginns der Bedingungen für hausinterne Produkte (ABl. L 19 vom 28.1.2022, S. 1).

^(9) Verordnung (EU) 2024/1860 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Änderung der Verordnungen (EU) 2017/745 und (EU) 2017/746 hinsichtlich der schrittweisen Einführung von Eudamed, der Informationspflicht im Falle einer Unterbrechung oder Beendigung der Versorgung und der Übergangsbestimmungen für bestimmte In-vitro-Diagnostika (ABl. L, 2024/1860, 9.7.2024).

^(10) Entschließung des Europäischen Parlaments vom 23. Oktober 2024 zu der dringend notwendigen Überarbeitung der Verordnung über Medizinprodukte (2024/2849(RSP)) (ABl. C, C/2025/485, 29.1.2025, ELI: http://data.europa.eu/eli/C/2025/485/oj ).

^(11) Gemeinsames Papier Kroatiens, Finnlands, Frankreichs, Deutschlands, Irlands, Luxemburgs, Rumäniens, Maltas und Sloweniens zu erforderlichen Reformen der MDR und der IVDR: Prioritäten/Hauptpunkte (Rat der Europäischen Union, 28.11.2024, 15380/24).

^(12) Website der Europäischen Kommission, Medizinprodukte – Expertengremien – Überblick .

^(13) Artikel 30 der Verordnung (EU) 2022/123 über eine verstärkte Rolle der Europäischen Arzneimittel-Agentur bei der Krisenvorsorge und beim Krisenmanagement für Arzneimittel und Medizinprodukte.

^(14) Reform der EU-Arzneimittelvorschriften – öffentliche Gesundheit .

^(15) Vorschlag für eine Verordnung des Europäischen Parlaments und des Rates zur Schaffung eines Rahmens von Maßnahmen zur Stärkung der Biotechnologie- und Bioproduktionssektoren der Union, insbesondere im Bereich der Gesundheit, sowie zur Änderung der Verordnungen (EG) Nr. 178/2002, (EG) Nr. 1394/2007, (EU) Nr. 536/2014, (EU) 2019/6, (EU) 2024/795 und (EU) 2024/1938 (Europäischer Biotech-Rechtsakt), COM(2025) 1022 vom 16. Dezember 2025.

^(16) Verordnung (EU) Nr. 536/2014, ELI: http://data.europa.eu/eli/reg/2014/536/oj.

^(17) Verordnung (EU) Nr. 2024/1938, ELI: http://data.europa.eu/eli/reg/2024/1938/oj.

^(18) Mitteilung der Kommission an das Europäische Parlament, den Europäischen Rat, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Ein Kompass für eine wettbewerbsfähige EU, COM(2025) 30 final vom 29.1.2025.

^(19) Mitteilung der Kommission an das Europäische Parlament, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen – Ein einfacheres und schnelleres Europa: Mitteilung über die Umsetzung und Vereinfachung, COM(2025) 47 final vom 11.2.2025.

^(20) Mitteilung der Kommission an das Europäische Parlament, den Europäischen Rat, den Rat, den Europäischen Wirtschafts- und Sozialausschuss und den Ausschuss der Regionen, „Den Standort Europa wählen für Biowissenschaften – Eine Strategie, um Europa bis 2030 zum weltweit attraktivsten Standort für Biowissenschaften zu machen“, COM(2025) 525 final vom 2.7.2025.

^(21) Commission Staff Working Document on the Targeted evaluation of Regulation (EU) 2017/745 on Medical Devices and Regulation (EU) 2017/746 on In Vitro Diagnostic Medical Devices, (Arbeitsunterlage der Kommissionsdienststellen über die gezielte Bewertung der Verordnung (EU) 2017/745 über Medizinprodukte und der Verordnung (EU) 2017/746 über In-vitro-Diagnostika), SWD(2025) 1051.

^(22) Europäische Kommission, Medizinprodukte und In-vitro-Diagnostika – gezielte Überarbeitung der EU-Vorschriften , Ihre Meinung zählt-Seite.

^(23) Die Zahlen umfassen einen Beitrag, der wegen Nichtbeachtung der Rückmeldevorschriften ausgeschlossen wurde; fünf Beiträge von vier Teilnehmenden wurden als Duplikate entfernt, und 14 Beiträge wurden als komplementäre Rückmeldungen zu sechs Beiträgen zusammengeführt.

^(24) Von den im Rahmen der Aufforderung zur Stellungnahme eingegangenen 171 Anhängen wurden fünf bei der Analyse nicht berücksichtigt (ein Anhang stammte aus dem ausgeschlossenen Beitrag, zwei Anhänge waren Teil der oben genannten Duplikate, und ein Dokument wurde von einer bzw. einem Teilnehmenden dreimal übermittelt).

^(25) Ein von einer bzw. einem Teilnehmenden dreimal übermittelter Anhang wurde als themenfremd eingestuft.

^(26) Arbeitsunterlage der Kommissionsdienststellen über Kosteneinsparungen, SWD(2025)1050.

^(27) EUR-Lex – 12012P/TXT – DE – EUR-Lex .

^(28) COM(2025) 1022, siehe Fußnote 15.

^(29) ABl. C , , S. .

^(30) ABl. C , , S. .

^(31) Verordnung (EU) 2017/745 des Europäischen Parlaments und des Rates vom 5. April 2017 über Medizinprodukte, zur Änderung der Richtlinie 2001/83/EG, der Verordnung (EG) Nr. 178/2002 und der Verordnung (EG) Nr. 1223/2009 und zur Aufhebung der Richtlinien 90/385/EWG und 93/42/EWG (ABl. L 117 vom 5.5.2017, S. 1, ELI: http://data.europa.eu/eli/reg/2017/745/oj ).

^(32) Verordnung (EU) 2017/746 des Europäischen Parlaments und des Rates vom 5. April 2017 über In-vitro-Diagnostika und zur Aufhebung der Richtlinie 98/79/EG und des Beschlusses 2010/227/EU der Kommission (ABl. L 117 vom 5.5.2017, S. 176, ELI: http://data.europa.eu/eli/reg/2017/746/oj ).

^(33) Richtlinie des Rates vom 20. Juni 1990 zur Angleichung der Rechtsvorschriften der Mitgliedstaaten über aktive implantierbare medizinische Geräte (ABl. L 189 vom 20.7.1990, S. 17, ELI: http://data.europa.eu/eli/dir/1990/385/oj ).

^(34) Richtlinie 93/42/EWG des Rates vom 14. Juni 1993 über Medizinprodukte (ABl. L 169 vom 12.7.1993, S. 1, ELI: http://data.europa.eu/eli/dir/1993/42/oj ).

^(35) Richtlinie 98/79/EG des Europäischen Parlaments und des Rates vom 27. Oktober 1998 über In-vitro-Diagnostika (ABl. L 331 vom 7.12.1998, ELI: http://data.europa.eu/eli/dir/1998/79/oj ).

^(36) SWD(2025) 1051.

^(37) Verordnung (EU) 2024/1938 des Europäischen Parlaments und des Rates vom 13. Juni 2024 über Qualitäts- und Sicherheitsstandards für zur Verwendung beim Menschen bestimmte Substanzen menschlichen Ursprungs und zur Aufhebung der Richtlinien 2002/98/EG und 2004/23/EG (ABl. L 2024/1938, 17.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1938/oj ).

^(38) Empfehlung C/2022/3689 der Kommission vom 10. Juni 2022 zur Definition von Nanomaterialien (ABl. C 229 vom 14.6.2022, S 1).

^(39) MDCG 2020-6 Verordnung (EU) 2017/745: Klinischer Nachweis, der für Medizinprodukte erforderlich ist, die zuvor gemäß den Richtlinien 93/42/EWG oder 90/385/EWG CE-gekennzeichnet waren; Ein Leitfaden für Hersteller und Benannte Stellen (April 2020).

^(40) Richtlinie (EU) 2015/1535 des Europäischen Parlaments und des Rates vom 9. September 2015 über ein Informationsverfahren auf dem Gebiet der technischen Vorschriften und der Vorschriften für die Dienste der Informationsgesellschaft (ABl. L 241 vom 17.9.2015, S. 1, ELI: http://data.europa.eu/eli/dir/2015/1535/oj ).

^(41) Verordnung (EU) 2022/123 des Europäischen Parlaments und des Rates vom 25. Januar 2022 zu einer verstärkten Rolle der Europäischen Arzneimittel-Agentur bei der Krisenvorsorge und -bewältigung in Bezug auf Arzneimittel und Medizinprodukte (ABl. L 20 vom 31.1.2022, S. 1, ELI: http://data.europa.eu/eli/reg/2022/123/oj ).

^(42) Bericht der Kommission an das Europäische Parlament und den Rat vom 29. November 2024 über die Anwendung von Artikel 17 der Verordnung (EU) 2017/745 des Europäischen Parlaments und des Rates über Einmalprodukte und ihre Wiederaufbereitung (COM(2024) 560 final).

^(43) Verordnung (EU) 2024/1689 des Europäischen Parlaments und des Rates vom 13. Juni 2024 zur Festlegung harmonisierter Vorschriften für künstliche Intelligenz und zur Änderung der Verordnungen (EG) Nr. 300/2008, (EU) Nr. 167/2013, (EU) Nr. 168/2013, (EU) 2018/858, (EU) 2018/1139 und (EU) 2019/2144 sowie der Richtlinien 2014/90/EU, (EU) 2016/797 und (EU) 2020/1828 (Verordnung über künstliche Intelligenz) (ABl. L, 2024/1689, 12.7.2024, ELI: http://data.europa.eu/eli/reg/2024/1689/oj ).

^(44) Empfehlung der Kommission vom 6. Mai 2003 betreffend die Definition der Kleinstunternehmen sowie der kleinen und mittleren Unternehmen (ABl. L 124 vom 20.5.2003, S. 36, ELI: http://data.europa.eu/eli/reco/2003/361/oj ).

^(45) Verordnung (EU) 2022/2371 des Europäischen Parlaments und des Rates vom 23. November 2022 zu schwerwiegenden grenzüberschreitenden Gesundheitsgefahren und zur Aufhebung des Beschlusses Nr. 1082/2013/EU (ABl. L 314 vom 6.12.2022, S. 26, ELI: http://data.europa.eu/eli/reg/2022/2371/oj ).

^(46) Verordnung (EU) 2022/2372 des Rates vom 24. Oktober 2022 über einen Rahmen zur Gewährleistung der Bereitstellung von krisenrelevanten medizinischen Gegenmaßnahmen im Falle einer gesundheitlichen Notlage auf Unionsebene (ABl. L 314 vom 6.12.2024, S. 64, ELI: http://data.europa.eu/eli/reg/2022/2372/oj ).

^(47) Richtlinie 2010/63/EU des Europäischen Parlaments und des Rates vom 22. September 2010 zum Schutz der für wissenschaftliche Zwecke verwendeten Tiere (ABl. L 276 vom 20.10.2010, S. 33, ELI: http://data.europa.eu/eli/dir/2010/63/2019-06-26 ).

^(48) Verordnung (EU) Nr. 536/2014 des Europäischen Parlaments und des Rates vom 16. April 2014 über klinische Prüfungen mit Humanarzneimitteln und zur Aufhebung der Richtlinie 2001/20/EG (ABl. L 158 vom 27.5.2014, S. 1. ELI: http://data.europa.eu/eli/reg/2014/536/oj ).

^(49) Verordnung (EU) 2024/2847 des Europäischen Parlaments und des Rates vom 23. Oktober 2024 über horizontale Cybersicherheitsanforderungen für Produkte mit digitalen Elementen und zur Änderung der Verordnungen (EU) Nr. 168/2013 und (EU) 2019/1020 und der Richtlinie (EU) 2020/1828 (Cyberresilienz-Verordnung) (ABl. L 2024/2847, 20.11.2024, ELI: http://data.europa.eu/eli/reg/2024/2847/o j).

^(50) Internationales Forum der Aufsichtsbehörden für Medizinprodukte (IMDRF) Internationales Forum der Aufsichtsbehörden für Medizinprodukte .

^(51) Verordnung (EU) 2024/903 des Europäischen Parlaments und des Rates vom 13. März 2024 über Maßnahmen für ein hohes Maß an Interoperabilität des öffentlichen Sektors in der Union (Verordnung für ein interoperables Europa) (ABl. L, 2024/903, 22.3.2024, ELI: http://data.europa.eu/eli/reg/2024/903/oj ).

^(52) Im Sinne des Artikels 58 Absatz 2 Buchstabe a oder b der Haushaltsordnung.

^(53) Erläuterungen zu den Haushaltsvollzugsarten und die Haushaltsordnung können über die Website BUDGpedia (in englischer Sprache) abgerufen werden: https://myintracomm.ec.europa.eu/corp/budget/financial-rules/budget-implementation/Pages/implementation-methods.aspx .

^(54) Commission Anti-Fraud Strategy: enhanced action to protect the EU budget .

^(55) GM = Getrennte Mittel/NGM = Nichtgetrennte Mittel.

^(56) EFTA: Europäische Freihandelsassoziation.

^(57) Kandidatenländer und gegebenenfalls potenzielle Kandidaten des Westbalkans.

^(58) Der Mittelbedarf sollte auf der Grundlage der Angaben zu den Durchschnittskosten veranschlagt werden, die auf der einschlägigen BUDGpedia-Seite verfügbar sind.

^(59) Bitte unter der Tabelle angeben, wie viele der aufgeführten VZÄ bereits der Verwaltung der Maßnahme zugeordnet sind und/oder durch Personalumschichtung innerhalb der GD dieser Aufgabe zugeteilt werden können. Den Nettobedarf beziffern.

^(60) Bei den traditionellen Eigenmitteln (Zölle, Zuckerabgaben) sind die Beträge netto, d. h. abzüglich 20 % für Erhebungskosten, anzugeben.

^(61) Richtlinie (EU) 2019/882 des Europäischen Parlaments und des Rates vom 17. April 2019 über die Barrierefreiheitsanforderungen für Produkte und Dienstleistungen (ABl. L 151 vom 7.6.2019, S. 70, ELI: http://data.europa.eu/eli/dir/2019/882/oj ).

<a id="annex-i"></a>
## Anhang I

Die Anhänge I, II, III, VI, VII, VIII, IX, X, XI, XII, XIII, XIV und XV der Verordnung (EU) Nr. 2017/745 werden wie folgt geändert:

- 1. Anhang I wird wie folgt geändert:

  - a) Abschnitt 10.6 erhält folgende Fassung:

    - „10.6. Sofern sie nicht nur mit unversehrter Haut in Berührung kommen, werden die Produkte so ausgelegt und hergestellt, dass die Risiken in Verbindung mit der Größe und den Eigenschaften der Partikel, die in den Körper des Patienten oder des Anwenders eindringen oder eindringen können, so weit wie möglich verringert werden. Besondere Aufmerksamkeit ist Nanomaterialien im Sinne der Empfehlung C/2022/3689 der Kommission* zu widmen.

    - ______________________

    - * Empfehlung der Kommission vom 10. Juni 2022 zur Definition von Nanomaterialien (ABl. C 229 vom 14.6.2022, S. 1).“

  - b) Abschnitt 13 wird wie folgt geändert:

    - i) Abschnitt 13.1 erhält folgende Fassung:

      - „13.1. Für unter Verwendung von Derivaten von nicht lebensfähigen oder abgetöteten Substanzen menschlichen Ursprungs hergestellte Produkte, die gemäß Artikel 1 Absatz 6 Buchstabe g unter die vorliegende Verordnung fallen, gilt Folgendes:

        - a) die Spenderregistrierung, die Spenderbewertung sowie die Gewinnung und Prüfung der Substanzen menschlichen Ursprungs erfolgen gemäß der Verordnung (EU) 2024/1938;

        - b) die Verarbeitung, Konservierung sowie jede anderweitige Behandlung solcher Substanzen menschlichen Ursprungs oder ihrer Derivate erfolgt so, dass die Sicherheit für Patienten, Anwender und gegebenenfalls Dritte gewährleistet ist. Insbesondere wird durch geeignete Methoden der Herkunftsbestimmung und durch validierte Verfahren zur Ausmerzung oder Inaktivierung im Verlauf des Herstellungsprozesses für den Schutz vor Viren und anderen übertragbaren Erregern gesorgt;

        - c) das Rückverfolgbarkeitssystem für diese Produkte ergänzt die in der Verordnung (EU) 2024/1938 festgelegten Rückverfolgbarkeits- und Datenschutzanforderungen und ist mit ihnen vereinbar.“

    - ii) Abschnitt 13.2 Buchstabe c erhält folgende Fassung:

      - „c) für Produkte, die unter Verwendung von Geweben oder Zellen tierischen Ursprungs oder ihrer Derivate im Sinne der Verordnung (EU) Nr. 722/2012 hergestellt werden, gelten die in dieser Verordnung oder in etwaigen nachfolgenden gemäß dieser Verordnung erlassenen Durchführungsrechtsakten festgelegten besonderen Anforderungen.“

  - c) Abschnitt 17.4 erhält folgende Fassung:

    - „17.4. Die Hersteller legen Mindestanforderungen bezüglich Hardware, Eigenschaften von IT-Netzen, IT-Sicherheitsmaßnahmen und Cybersicherheit einschließlich des Schutzes vor unbefugtem Zugriff fest, die für den bestimmungsgemäßen Einsatz der Software erforderlich sind.“

  - d) Abschnitt 23.1 wird wie folgt geändert:

    - i) Unterabsatz 1 Satz 2 erhält folgende Fassung:

        „Diese Angaben können auf dem Produkt selbst, auf der Verpackung oder in der Gebrauchsanweisung erscheinen, wobei Folgendes zu berücksichtigen ist:“

    - ii) In Buchstabe c wird der folgende Satz angefügt:

        „Kennzeichnungen können in digitaler Form bereitgestellt werden, soweit und nur unter den Bedingungen, die in gemäß dieser Verordnung erlassenen Durchführungsrechtsakten festgelegt sind.“

    - iii) In Buchstabe f wird die Bezugnahme auf die „Verordnung (EU) Nr. 207/2012“ ersetzt durch die Bezugnahme auf die „Durchführungsverordnung (EU) Nr. 2021/2226 der Kommission**“

    - ______________________

    - ** Durchführungsverordnung (EU) 2021/2226 der Kommission vom 14. Dezember 2021 mit Durchführungsbestimmungen zur Verordnung (EU) 2017/745 des Europäischen Parlaments und des Rates hinsichtlich elektronischer Gebrauchsanweisungen für Medizinprodukte (ABl. L 448 vom 15.12.2021, S. 32, ELI: http://data.europa.eu/eli/reg_impl/2021/2226/oj).“

    - iv) Folgender Buchstabe i wird angefügt:

      - „i) Für ein Produkt, das gemäß Artikel 19 des [Vorschlags für eine Richtlinie über den Unionskodex für Humanarzneimittel und zur Aufhebung der Richtlinie 2011/83/EG und der Richtlinie 2009/35/EG] ausschließlich zusammen mit einem Arzneimittel verwendet wird und gemeinsam mit einem Arzneimittel verpackt ist, kann die Gebrauchsanweisung, sofern erforderlich, der gemeinsamen Verpackung des Arzneimittels und des Produkts beigefügt werden. Darüber hinaus können die Angaben auf der Kennzeichnung des Produkts auf die in Abschnitt 23.2 Buchstaben a und c genannten Angaben beschränkt werden, sofern nach Zustimmung der für die Genehmigung des Arzneimittels zuständigen Behörde die folgenden Bedingungen erfüllt sind:

        - – Die für die sichere Verwendung und das ordnungsgemäße Funktionieren des Produkts erforderlichen Informationen werden dem Anwender zusammen mit der Zusammenfassung der Merkmale des Arzneimittels und/oder der Packungsbeilage des Arzneimittels unter der Verantwortung des in dem [Vorschlag für eine Richtlinie über den Unionskodex für Humanarzneimittel und zur Aufhebung der Richtlinie 2011/83/EG und der Richtlinie 2009/35/EG] genannten Zulassungsinhabers bereitgestellt.

        - – Die Rückverfolgbarkeit und Identifizierung des Produkts werden durch den Zulassungsinhaber sichergestellt.“

  - e) Abschnitt 23.2 wird wie folgt geändert:

    - i) Buchstabe e zweiter und dritter Gedankenstrich erhalten folgende Fassung:

      - – „Substanzen menschlichen Ursprungs oder ihre Derivate oder

      - – Geweben oder Zellen tierischen Ursprungs oder ihre Derivate im Sinne der Verordnung (EU) Nr. 722/2012 oder in etwaigen nachfolgenden gemäß dieser Verordnung erlassenen Durchführungsrechtsakten;“

    - ii) Buchstabe o wird gestrichen.

    - iii) Buchstabe q Satz 1 erhält folgende Fassung:

        „einen Hinweis, dass es sich bei dem Produkt um ein Medizinprodukt oder ein Zubehör eines Medizinprodukts handelt“

  - f) Abschnitt 23.4 Buchstabe s vierter Gedankenstrich erhält folgende Fassung:

    - – „falls das Produkt dazu bestimmt ist, Arzneimittel, Substanzen menschlichen oder Geweben oder Zellen tierischen Ursprungs oder ihre Derivate oder biologische Stoffe abzugeben, mögliche Beschränkungen oder Unverträglichkeiten hinsichtlich der Wahl der abzugebenden Stoffe,“

- 2. Anhang II wird wie folgt geändert:

  - a) Abschnitt 6.1 wird wie folgt geändert:

    - i) Die Überschrift von Abschnitt 6.1 erhält folgende Fassung:

      - „6.1 Nichtklinische, vorklinische und klinische Daten“

    - ii) Buchstabe a erhält folgende Fassung:

      - „a) Ergebnisse von Tests wie technischen, Labor-, In-vitro-, Ex-vivo- und In-silico-Tests, computergestützter Modellierung, Anwendungssimulations- und Tiertests bzw. Versuchen sowie Auswertung der Literatur, die unter Berücksichtigung der Zweckbestimmung zu dem Produkt – oder ähnlichen Produkten – bezüglich der vorklinischen Sicherheit des Produkts und seiner Konformität mit den Spezifikationen veröffentlicht wurde;“

    - iii) Buchstabe c erhält folgende Fassung:

      - „c) den Plan für die klinische Bewertung, den Bericht über die klinische Bewertung sowie seine Aktualisierungen gemäß Artikel 61 Absatz 1 und Anhang XIV Teil A.“

    - iv) Buchstabe d wird gestrichen.

  - b) Abschnitt 6.2 wird wie folgt geändert:

    - i) Buchstabe b Satz 1 erhält folgende Fassung:

      - „b) Wird ein Produkt unter Verwendung von Substanzen menschlichen Ursprungs oder Geweben oder Zellen tierischen Ursprungs oder ihren Derivaten hergestellt und fällt es unter diese Verordnung gemäß Artikel 1 Absatz 6 Buchstaben f und g, und enthält ein Produkt als integralen Bestandteil Substanzen menschlichen Ursprungs oder ihre Derivate mit einer untergeordneten Funktion im Rahmen des Produkts und fällt es unter diese Verordnung gemäß Artikel 1 Absatz 10 Unterabsatz 1, so ist auf diesen Sachverhalt hinzuweisen.“

    - ii) Folgender Buchstabe h wird angefügt:

      - „h) Enthält das Produkt als integralen Bestandteil ein In-vitro-Diagnostikum, dessen Wirkung derjenigen des Produkts im Sinne des Artikels 1 Absatz 7 dieser Verordnung untergeordnet ist, so umfasst die Dokumentation die Ergebnisse der Bewertung der Konformität des In-vitro-Diagnostikums mit den einschlägigen allgemeinen Sicherheits- und Leistungsanforderungen gemäß Anhang I der Verordnung (EU) 2017/746, wie sie in der EU-Konformitätserklärung des Herstellers oder in der einschlägigen, von einer Benannten Stelle ausgestellten Bescheinigung enthalten sind, die den Hersteller zur Anbringung der CE-Kennzeichnung an dem In-vitro-Diagnostikum berechtigt. Liegen diese Ergebnisse der Konformitätsbewertung nicht vor und ist für die Konformitätsbewertung des In-vitro-Diagnostikums, sofern es gesondert verwendet wird, gemäß der Verordnung (EU) 2017/746 die Beteiligung einer Benannten Stelle erforderlich, so ist der Dokumentation eine Stellungnahme zur Konformität des In-vitro-Diagnostikums mit den einschlägigen allgemeinen Sicherheits- und Leistungsanforderungen gemäß Anhang I der Verordnung (EU) 2017/746 beizufügen, die von einer nach dieser Verordnung für den betreffenden Produkttyp benannten Stelle ausgestellt wurde.“

- 3. Anhang III Abschnitt 2 erhält folgende Fassung:

  - „2. Den Sicherheitsbericht gemäß Artikel 86 oder den Bericht über die Überwachung nach dem Inverkehrbringen gemäß Artikel 85.“

- 4. Anhang VI wird wie folgt geändert:

  - a) Die Teile A und B erhalten folgende Fassung:

„TEIL A

BEI DER REGISTRIERUNG VON WIRTSCHAFTSAKTEUREN GEMÄẞ ARTIKEL 31 VORZULEGENDE INFORMATIONEN

      Die Hersteller und gegebenenfalls ihre Bevollmächtigten sowie gegebenenfalls die Importeure und gegebenenfalls die in Artikel 22 Absatz 1 genannten Personen übermitteln die folgenden Informationen über den Wirtschaftsakteur:

    - 1. Art des Wirtschaftsakteurs (Hersteller, Bevollmächtigter, Importeur oder die in Artikel 22 Absatz 1 genannte Person),

    - 2. Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, des Wirtschaftsakteurs,

    - 3. falls die Informationen von einer anderen Person im Namen eines der in Abschnitt 1.1 aufgeführten Wirtschaftsakteure eingereicht werden, Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, dieser Person,

    - 4. Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, der für die Einhaltung der Regulierungsvorschriften zuständigen Person(en) gemäß Artikel 15.

<a id="part-b"></a>
## Teil B

IN DIE UDI-DATENBANK GEMÄẞ DEN ARTIKELN 28 UND 29 EINZUGEBENDE ZENTRALE DATENELEMENTE

      Der Hersteller gibt in die UDI-Datenbank die folgenden Informationen zum Hersteller und zum Produkt ein:

    - 1. Basis-UDI-DI gemäß Artikel 27 und alle zusätzlichen UDI-DI,

    - 2. für die in Artikel 120 Absatz 3 genannten Produkte Art, Nummer und Ablaufdatum der von der Benannten Stelle ausgestellten Bescheinigung und Name oder Kennnummer dieser Benannten Stelle sowie Link zu den Informationen auf der Bescheinigung, die die Benannte Stelle in das elektronische System für Benannte Stellen und Bescheinigungen eingegeben hat,

    - 3. Mitgliedstaat, in dem das Produkt in der Union in Verkehr gebracht werden soll bzw. gebracht wurde,

    - 4. Mitgliedstaaten, in denen das Produkt verfügbar ist bzw. verfügbar gemacht werden soll,

    - 5. Risikoklasse des Produkts,

    - 6. Vorhandensein eines Stoffes, der für sich allein genommen als Arzneimittel gelten kann, sowie Name dieses Stoffes,

    - 7. Vorhandensein eines Stoffes, der für sich allein genommen als ein aus menschlichem Blut oder Plasma gewonnenes Arzneimittel gelten kann, sowie Name dieses Stoffes,

    - 8. Vorhandensein von Geweben oder Zellen menschlichen Ursprungs oder ihren Derivaten (j/n),

    - 9. Vorhandensein von Geweben oder Zellen tierischen Ursprungs oder ihrer Derivate im Sinne der Verordnung (EU) Nr. 722/2012 oder in etwaigen nachfolgenden gemäß dieser Verordnung erlassenen Durchführungsrechtsakten (j/n),

    - 10. gegebenenfalls die einmalige Kennnummer der in Verbindung mit dem Produkt durchgeführten klinischen Prüfung(en) oder ein Link zur Registrierung der klinischen Prüfung im elektronischen System für klinische Prüfungen,

    - 11. bei in Anhang XVI aufgeführten Produkten: Angabe, ob das Produkt eine andere Zweckbestimmung als die medizinische hat,

    - 12. bei Produkten, die von einer anderen in Artikel 10 Absatz 15 aufgeführten juristischen oder natürlichen Person ausgelegt und hergestellt wurden: Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, dieser juristischen oder natürlichen Person,

    - 13. gegebenenfalls den Kurzbericht über Sicherheit und klinische Leistung,

    - 14. Marktstatus des Produkts (auf den Markt gebracht, nicht mehr auf dem Markt, zurückgerufen, Sicherheitskorrekturmaßnahmen im Feld eingeleitet),

    - 15. Menge pro Packung,

    - 16. Art der Kontrolle der Herstellung des Produkts (Verfallsdatum oder Herstellungsdatum, Losnummer, Seriennummer),

    - 17. gegebenenfalls die UDI-DI der Gebrauchseinheit (falls auf dem Produkt auf der Ebene der Gebrauchseinheit keine UDI angegeben ist, wird eine ‚Gebrauchseinheit-DI‘ zugeteilt, um die Verwendung eines Produkts einem Patienten zuzuordnen),

    - 18. Name und Anschrift des Herstellers (wie auf der Kennzeichnung angegeben),

    - 19. die SRN gemäß Artikel 31 Absatz 2,

    - 20. gegebenenfalls Name und Anschrift des Bevollmächtigten (wie auf der Kennzeichnung angegeben),

    - 21. den Code in der Nomenklatur für Medizinprodukte gemäß Artikel 26,

    - 22. gegebenenfalls Name oder Handelsname und gegebenenfalls weitere Handelsnamen,

    - 23. gegebenenfalls Modell-, Referenz- oder Katalognummer des Produkts,

    - 24. gegebenenfalls klinische Größe (einschließlich Volumen, Länge, Breite, Durchmesser),

    - 25. zusätzliche Produktbeschreibung (fakultativ),

    - 26. gegebenenfalls Lagerungs- und/oder Handhabungshinweise (wie auf der Kennzeichnung oder in der Gebrauchsanweisung angegeben),

    - 27. als Produkt zum Einmalgebrauch ausgewiesen (j/n),

    - 28. gegebenenfalls Höchstzahl der Wiederverwendungen,

    - 29. als steril ausgewiesenes Produkt (j/n),

    - 30. Sterilisation vor Verwendung erforderlich (j/n),

    - 31. enthält Latex (j/n),

    - 32. gegebenenfalls nach Anhang I Abschnitt 10.4.5 gekennzeichnete Angaben,

    - 33. gegebenenfalls die Gebrauchsanweisung oder, soweit verfügbar, die URL der Website, auf der die Gebrauchsanweisung zur Verfügung gestellt wird,

    - 34. gegebenenfalls wichtige Warnhinweise oder Kontraindikationen.“

  - b) TEIL C wird wie folgt geändert:

    - i) In Abschnitt 1 erhält die Begriffsbestimmung von „Basis-UDI-DI“ folgende Fassung:

        „Basis-UDI-DI

        Die Basis-UDI-DI ist die primäre Kennung eines Produktmodells. Die Basis-UDI-DI ist der wichtigste Schlüssel in der Datenbank und den einschlägigen Unterlagen (z. B. Bescheinigungen, Konformitätserklärung, technische Dokumentation und Kurzbericht über Sicherheit und klinische Leistung), um Produkte mit derselben Zweckbestimmung, Risikoklasse und denselben wesentlichen Auslegungs- und Herstellungsmerkmalen miteinander in Verbindung zu bringen. Sie ist das wichtigste Ordnungsmerkmal für Datensätze in der UDI-Datenbank und ist in den einschlägigen Bescheinigungen und EU-Konformitätserklärungen ausgewiesen.“

    - ii) Abschnitt 4.10 Satz 2 erhält folgende Fassung:

        „Der UDI-Träger für wiederverwendbare Produkte, bei denen zwischen den Anwendungen am Patienten eine Reinigung, Desinfektion, Sterilisation oder Aufbereitung erforderlich ist, muss dauerhaft angebracht und nach jedem Verfahren, das zur Vorbereitung des Produkts für die nachfolgende Verwendung durchgeführt wird, während der gesamten erwarteten Lebensdauer des Produkts lesbar sein, es sei denn, das Produkt ist dazu bestimmt, ausschließlich von oder für denselben Patienten wiederverwendet zu werden.“

- 5. Anhang VII wird wie folgt geändert:

  - a) In Abschnitt 1.1.1 wird folgender Satz angefügt:

      „Die Unterlagen enthalten außerdem Angaben zur übergeordneten Organisation, der die Benannte Stelle angehört.“

  - b) Abschnitt 1.1.2 erhält folgende Fassung:

    - „1.1.2. Handelt es sich bei der Benannten Stelle um eine juristische Person, die Teil einer größeren Einrichtung ist, so sind die Tätigkeiten dieser Einrichtung sowie ihre Organisations- und Leitungsstruktur und ihr Verhältnis zu der Benannten Stelle eindeutig zu dokumentieren. In diesen Fällen gelten die Anforderungen des Abschnitts 1.2 sowohl für die Benannte Stelle als auch für die größere Einrichtung, zu der sie gehört. Die größere Einrichtung und alle zu ihr gehörenden juristischen Personen dürfen weder an der Auslegung, Herstellung, Vermarktung, Installation oder Wartung der Produkte, für die die Benannte Stelle benannt ist, beteiligt sein noch Beratungsleistungen für diese Tätigkeiten anbieten; ebenso wenig dürfen sie die an diesen Tätigkeiten beteiligten Parteien vertreten.“

  - c) In Abschnitt 1.2.9 wird folgender Satz angefügt:

      „Die Benannte Stelle verfügt über dokumentierte Verfahren, um Dialoge mit dem Hersteller vor und nach Einreichung eines Antrags auf Konformitätsbewertung anzubieten und durchzuführen.“

  - d) Abschnitt 1.3.1 erhält folgende Fassung:

    - „1.3.1. Die Benannte Stelle gewährleistet durch dokumentierte Verfahren, dass ihre Mitarbeiter, Ausschüsse, Zweigstellen, Niederlassungen, Unterauftragnehmer sowie alle zugeordneten Stellen oder Mitarbeiter externer Einrichtungen die Vertraulichkeit der Informationen, die bei der Durchführung der Konformitätsbewertungstätigkeiten in ihren Besitz gelangen, wahren, außer wenn die Offenlegung gesetzlich vorgeschrieben ist.“

  - e) Abschnitt 1.4.2 Satz 2 wird gestrichen.

  - f) Folgender Abschnitt 1.4.3 wird eingefügt:

    - „1.4.3. Abweichend von Abschnitt 1.4.1 kann die Benannte Stelle den Nachweis der Deckung ihrer Haftung durch den Beitritt zu einem Garantiefonds erbringen, der einen wirksamen Schutz gewährleistet und von dem bzw. den betreffenden Mitgliedstaat(en) anerkannt ist.“

  - g) Abschnitt 1.6.1 erhält folgende Fassung:

    - „1.6.1. Die Benannte Stelle wirkt an allen Aktivitäten der Koordinierungsgruppe Benannter Stellen gemäß Artikel 49 mit und stellt sicher, dass ihre Entscheidungsträger von allen im Rahmen dieser Verordnung angenommenen einschlägigen Rechtsvorschriften, Normen, Leitlinien und Dokumenten über vorbildliche Verfahren Kenntnis erhalten.“

  - h) Abschnitt 2.1 erhält folgende Fassung:

    - „2.1. Das von der Benannten Stelle eingerichtete, dokumentierte, umgesetzte, aufrechterhaltene und betriebene Qualitätsmanagementsystem ist für die Art, den Bereich und den Umfang ihrer Konformitätsbewertungstätigkeiten geeignet und ermöglicht es, auf die effizienteste Weise eine dauerhafte Erfüllung der in dieser Verordnung beschriebenen Anforderungen zu unterstützen und aufzuzeigen.“

  - i) Abschnitt 2.3 erhält folgende Fassung:

    - „2.3. Die oberste Leitungsebene der Benannten Stelle stellt sicher, dass das Qualitätsmanagementsystem in der gesamten Organisation der Benannten Stelle vollständig verstanden, umgesetzt und aufrechterhalten wird, was auch für ihre Zweigstellen, Niederlassungen und Unterauftragnehmer, die an Konformitätsbewertungstätigkeiten gemäß dieser Verordnung beteiligt sind, gilt.“

  - j) Abschnitt 3.2.3 wird wie folgt geändert:

    - i) Satz 1 erhält folgende Fassung:

      - „3.2.3. Das für die Festlegung der Qualifikationskriterien und die Zulassung anderer Mitarbeiter zur Durchführung spezifischer Konformitätsbewertungstätigkeiten zuständige Personal wird nicht als externe Sachverständige oder über einen Unterauftrag beschäftigt.“

    - ii) Der sechste Gedankenstrich erhält folgende Fassung:

      - – „einschlägige Erfahrung in Bezug auf Konformitätsbewertungen nach Maßgabe dieser Verordnung, der Verordnung (EU) 2017/746 oder vorher gültiger Rechtsvorschriften in einer Benannten Stelle.“

  - k) Abschnitt 3.2.4 Satz 1 erhält folgende Fassung:

      „Der Benannten Stelle steht permanent Personal mit einschlägiger klinischer Erfahrung zur Verfügung.“

  - l) Abschnitt 3.2.7 Satz 1 erhält folgende Fassung:

      „Die für die abschließenden Prüfungen und die Entscheidung über die Zertifizierung gesamtverantwortlichen Personen sind keine externen Sachverständigen oder Unterauftragnehmer.“

  - m) In Abschnitt 3.4.1 Absatz 1 wird folgender Satz angefügt:

      „Sie unterrichten den Hersteller entsprechend.“

  - n) Abschnitt 4.1 Absatz 2 erhält folgende Fassung:

      „Die in den Abschnitten 4.3, 4.4, 4.7 und 4.8 festgelegten Anforderungen dürfen nicht an externe Sachverständige vergeben oder von diesen erfüllt werden.“

  - o) Abschnitt 4.2 Buchstabe a Satz 2 erhält folgende Fassung:

      „In dieser Beschreibung wird angegeben, welche Sprachen für das Einreichen von Dokumenten und für diesbezügliche Korrespondenz zulässig sind, sowie die Modalitäten für die Durchführung des Dialogs gemäß Abschnitt 1.2.9 vor der Antragstellung,“

  - p) Abschnitt 4.5.1 Unterabsatz 2 wird wie folgt geändert:

    - i) Der neunte Gedankenstrich erhält folgende Fassung:

      - – „bei Produkten der Klassen IIa oder IIb die Bewertung der technischen Dokumentation des repräsentativen Produkts bzw. der repräsentativen Produkte,“

    - ii) Der elfte Gedankenstrich wird gestrichen.

    - iii) Folgende Gedankenstriche werden angefügt:

      - – „gegebenenfalls die Durchführung einer fortlaufenden Überprüfung der Daten oder Unterlagen des Herstellers, sobald diese verfügbar werden,

      - – die Bewertung des Qualitätsmanagementsystems bei Produkten der Klasse I, die in sterilem Zustand in Verkehr gebracht werden, eine Messfunktion aufweisen oder wiederverwendbare chirurgische Instrumente sind, ausschließlich im Hinblick auf die einschlägigen besonderen Aspekte dieser Produkte,

      - – die Heranziehung der Nachweise aus zuvor durchgeführten Bewertungen.“

  - q) Abschnitt 4.5.2 Buchstabe a wird wie folgt geändert:

    - i) Der einleitende Teil erhält folgende Fassung:

      - „a) Eine Benannte Stelle ist vor oder im Zusammenhang mit dem Audit und im Einklang mit ihren dokumentierten Verfahren für folgende Aufgaben als Teil der Bewertung des Qualitätsmanagementsystems zuständig:“

    - ii) Der vierte Gedankenstrich erhält folgende Fassung:

      - – „eindeutige Bestimmung der für die Bewertung der technischen Dokumentation gemäß den Anhängen II und III ausgewählten repräsentativen Produkte der Klassen IIa und IIb,“

  - r) Abschnitt 4.5.2 Buchstabe b Absatz 2 erhält folgende Fassung:

      „Stichproben der Dokumentation werden in einer Weise genommen, dass die mit der bestimmungsgemäßen Verwendung des Produkts verbundenen Risiken, die Komplexität der Fertigungstechnologien, die Bandbreite und die Klassen der hergestellten oder zu zertifizierenden Produkte und alle verfügbaren Informationen zur Überwachung nach dem Inverkehrbringen aufgezeigt werden.“

  - s) In Abschnitt 4.5.4 Buchstabe a erhält der zweite Gedankenstrich folgende Fassung:

    - – „die vorklinische Erprobung, zum Beispiel Laboruntersuchungen, In-vitro-, Ex-vivo-, In-silico-Tests, Erprobung der simulierten Verwendung, Computermodelle, Verwendung von Tiermodellen,“

  - t) In Abschnitt 4.5.5 Absatz 3 wird folgender Gedankenstrich angefügt:

    - – gegebenenfalls die Begründung für die Bestätigung der Sicherheit und Leistung, die ausschließlich auf den Ergebnissen nichtklinischer Prüfmethoden beruht.“

  - u) Abschnitt 4.5.6 Absatz 2 erhält folgende Fassung:

      „Im Falle von Produkten, die unter Verwendung von Geweben oder Zellen tierischen Ursprungs oder deren Derivaten, etwa von für transmissible spongiforme Enzephalopathien (TSE) empfänglichen Spezies, hergestellt wurden, wie in der Verordnung (EU) Nr. 722/2012 oder in etwaigen nachfolgenden gemäß dieser Verordnung erlassenen Durchführungsrechtsakten vorgesehen, verfügt die Benannte Stelle über dokumentierte Verfahren, die die in der Verordnung (EU) Nr. 722/2012 oder in diesen nachfolgenden Durchführungsrechtsakten festgelegten Anforderungen erfüllen.“

  - v) In Abschnitt 4.6 Absatz 2 erhält der einleitende Teil folgende Fassung:

      „Der Bericht bzw. die Berichte der Benannten Stelle“

  - w) Abschnitt 4.8 wird wie folgt geändert:

    - i) Satz 1 erhält folgende Fassung:

        „Die Benannte Stelle verfügt über dokumentierte Verfahren für die Entscheidungsfindung, unter anderem in Bezug auf die Zuteilung von Zuständigkeiten für die Erteilung, Aussetzung, Beschränkung und den Widerruf von Bescheinigungen.“

    - ii) Satz 3 wird wie folgt geändert:

      - 1. Der vierte Gedankenstrich erhält folgende Fassung:

        - – „zu entscheiden, ob bestimmte Bedingungen oder Beschränkungen für die Zertifizierung festgelegt werden müssen,“

      - 2. Der fünfte Gedankenstrich erhält folgende Fassung:

        - – „gegebenenfalls auf der Grundlage der Neuartigkeit, der Risikoklassifizierung, der klinischen Bewertung und der Schlussfolgerungen der Risikoanalyse des Produkts über die Geltungsdauer der Zertifizierung zu entscheiden,“

      - 3. Der achte Gedankenstrich erhält folgende Fassung:

        - – „eine Bescheinigung bzw. Bescheinigungen gemäß den in Anhang XII festgelegten Mindestanforderungen auszustellen und darin anzugeben, ob mit der Bescheinigung Bedingungen oder Beschränkungen verbunden sind,“

  - x) Abschnitt 4.9 wird wie folgt geändert:

    - i) Der dritte Gedankenstrich erhält folgende Fassung:

      - – „der bestimmungsgemäßen Verwendung des Produkts oder den für das Produkt geltend gemachten Ansprüchen,“

    - ii) Absatz 2 erhält folgende Fassung:

        „Die im ersten Absatz genannten Verfahren und vertraglichen Vereinbarungen unterscheiden eindeutig zwischen Änderungen, die nicht gemeldet werden müssen, solchen, die ohne vorherige Genehmigung gemeldet werden müssen, und solchen, die einer vorherigen Genehmigung bedürfen.“

    - iii) in Absatz 3 erhält der einleitende Satz folgende Fassung:

        „Im Einklang mit ihren dokumentierten Verfahren hat die betreffende Benannte Stelle, sofern Änderungen einer vorherigen Genehmigung bedürfen, folgende Aufgaben:“

    - iv) Folgender Absatz wird angefügt:

        „Gegebenenfalls vereinbaren die Benannte Stelle und der Hersteller einen vorab festgelegten Änderungssteuerungsplan, der es dem Hersteller ermöglicht, Änderungen gemäß einem solchen Plan ohne vorherige Unterrichtung umzusetzen.“

  - y) Abschnitt 4.10 wird wie folgt geändert:

    - i) In Absatz 1 erhalten der zweite und der dritte Gedankenstrich folgende Fassung:

      - – „die Prüfung einschlägiger Quellen wissenschaftlicher und klinischer Daten sowie Informationen nach dem Inverkehrbringen in dem Bereich, für den sie benannt wurden. Dieses Screening wird im Rahmen der in Artikel 49 eingesetzten Koordinierungsgruppe durchgeführt, um unnötige Doppelarbeit zu vermeiden und die Effizienz sowie die Arbeitsteilung zu verbessern. Die Ergebnisse des Screenings werden bei der Planung und Durchführung von Überwachungstätigkeiten berücksichtigt,

      - – um zu beurteilen, ob ein gemeldetes schwerwiegendes Vorkommnis im Zusammenhang mit einer schwerwiegenden Gefahr für die öffentliche Gesundheit oder eine vom Hersteller ergriffene oder in Erwägung gezogene Sicherheitskorrekturmaßnahme im Feld oder eine von einer zuständigen Behörde vom Hersteller verlangte Maßnahme Auswirkungen auf die Gültigkeit bestehender Bescheinigungen hat. Die Ergebnisse der Bewertung und alle getroffenen Entscheidungen werden gründlich dokumentiert.“

    - ii) Absatz 2 wird wie folgt geändert:

      - 1. Der einleitende Teil erhält folgende Fassung:

          „Die betreffende Benannte Stelle entscheidet im Hinblick auf Signale aus Vigilanzdaten, zu denen sie gemäß Artikel 92 Absatz 2 Zugang hat, gegebenenfalls, welche der folgenden Optionen anzuwenden ist:“

      - 2. Der erste Gedankenstrich wird gestrichen.

    - iii) Absatz 3 wird wie folgt geändert:

      - 1. Der erste Gedankenstrich erhält folgende Fassung:

        - – „Audits zur Überwachung des Herstellers durchzuführen, die gemäß den relevanten Anforderungen in Abschnitt 4.5 geplant und durchgeführt werden,“

      - 2. Der achte Gedankenstrich erhält folgende Fassung:

        - – „bei Bedarf Bedingungen oder Beschränkungen in Bezug auf die einschlägige Bescheinigung vorzusehen oder diese Bescheinigung auszusetzen oder zu widerrufen.“

    - iv) In Absatz 4 erhält der dritte Gedankenstrich folgende Fassung:

      - – „zu gewährleisten, dass die zuletzt aktualisierte klinische Bewertung in den Gebrauchsanweisungen und gegebenenfalls im Kurzbericht über Sicherheit und klinische Leistung angemessen wiedergegeben wird.“

  - z) Abschnitt 4.11 erhält folgende Fassung:

    - „4.11. Regelmäßige Überprüfungen und Verlängerung der Geltungsdauer einer Bescheinigung

        Die Benannte Stelle verfügt über dokumentierte Verfahren für die regelmäßige Überprüfung genehmigter Qualitätsmanagementsysteme oder von EU-Bescheinigungen über die Bewertung der technischen Dokumentation oder EU-Baumusterprüfbescheinigungen.

        Diese Verfahren verpflichten den betreffenden Hersteller, in festgelegten Abständen eine Zusammenfassung der Änderungen sowie der einschlägigen Daten vorzulegen, die im Rahmen des Systems des Herstellers zur Überwachung nach dem Inverkehrbringen erhoben wurden. Die Benannte Stelle bewertet diese Informationen und schenkt dabei insbesondere klinischen Daten aus der Überwachung nach dem Inverkehrbringen sowie den seit der vorherigen Zertifizierung oder regelmäßigen Überprüfung durchgeführten Tätigkeiten der klinischen Nachbeobachtung nach dem Inverkehrbringen besondere Aufmerksamkeit, einschließlich geeigneter Aktualisierungen der klinischen Bewertungsberichte der Hersteller, ohne bereits durchgeführte Bewertungen zu wiederholen.

        Die Benannte Stelle verfügt über dokumentierte Verfahren für die Verlängerung der Geltungsdauer einer Bescheinigung in Fällen, in denen sie die Geltungsdauer ausnahmsweise beschränkt hat. Diese Verfahren verpflichten den Hersteller, vor Ablauf der Bescheinigung die von der Benannten Stelle festgelegten Daten oder Unterlagen vorzulegen, damit diese über die Verlängerung der Geltungsdauer der Bescheinigung entscheiden kann.“

- 6. Anhang VIII wird wie folgt geändert:

  - a) Abschnitt 3.2 erhält folgende Fassung:

    - „3.2. Wenn das betreffende Produkt dazu bestimmt ist, in Verbindung mit einem anderen Produkt angewandt zu werden, werden die Klassifizierungsregeln auf jedes Produkt gesondert angewendet. Zubehör für ein Medizinprodukt und Zubehör für ein in Anhang XVI aufgeführtes Produkt wird unabhängig von dem Produkt, mit dem es verwendet wird, gesondert klassifiziert.“

  - b) Abschnitt 4.2 Absatz 1 zweiter Gedankenstrich erhält folgende Fassung:

    - – „wenn sie für die Durchleitung oder Aufbewahrung von Blut oder anderen Körperflüssigkeiten oder für die Aufbewahrung von Organen, Organteilen oder Körperzellen und -geweben eingesetzt werden, mit Ausnahme von Blutbeuteln; abweichend von anderen Klassifizierungsregeln werden Blutbeutel der Klasse IIb zugeordnet.“

  - c) In Abschnitt 5.2 erhält der zweite Gedankenstrich folgende Fassung:

    - – „es handelt sich um wiederverwendbare chirurgische Instrumente, unabhängig davon, mit welchem Körperteil sie in Kontakt kommen; in diesem Fall werden sie der Klasse I zugeordnet,“

  - d) In Abschnitt 5.3 wird folgender Gedankenstrich angefügt:

    - – „es handelt sich um wiederverwendbare chirurgische Instrumente, unabhängig davon, mit welchem Körperteil sie in Kontakt kommen; in diesem Fall werden sie der Klasse I zugeordnet.“

  - e) Abschnitt 5.4 wird wie folgt geändert:

    - i) Der sechste Gedankenstrich erhält folgende Fassung:

      - – „es handelt sich um aktive implantierbare Produkte; in diesen Fällen werden sie der Klasse III zugeordnet, “

    - ii) Der achte und der neunte Gedankenstrich erhalten folgende Fassung:

      - – „es handelt sich um Total- oder Teilprothesen von Gelenken; in diesem Fall werden sie der Klasse III zugeordnet, mit Ausnahme von Komponenten wie Schrauben, Keilen, Platten und Instrumenten sowie anderen Produkten, die Produkte mit bewährter Technologie sind, oder

      - – es handelt sich um Implantate zum Ersatz der Bandscheibe oder implantierbare Produkte, die mit der Wirbelsäule in Berührung kommen; in diesem Fall werden sie der Klasse III zugeordnet, mit Ausnahme von Komponenten wie Schrauben, Keilen, Platten und Instrumenten sowie andere Produkte, die Produkte mit bewährter Technologie sind.“

  - f) Artikel 6.1 Absätze 1 und 2 erhalten folgende Fassung:

      „Alle aktiven therapeutischen Produkte und alle in Anhang XVI aufgeführten aktiven Produkte, die zur Abgabe oder zum Austausch von Energie bestimmt sind, gehören zur Klasse IIa, es sei denn, die Abgabe von Energie an den menschlichen Körper oder der Austausch von Energie mit dem menschlichen Körper kann unter Berücksichtigung der Art, der Dichte und des Körperteils, an dem die Energie angewandt wird, aufgrund der Merkmale des Produkts eine potenzielle Gefährdung darstellen; in diesem Fall werden sie der Klasse IIb zugeordnet.

      Alle aktiven Produkte, die dazu bestimmt sind, die Leistung aktiver therapeutischer Produkte der Klasse IIb sowie aller in Anhang XVI aufgeführten aktiven Produkte, die der Klasse IIb zugeordnet sind, zu steuern oder zu kontrollieren oder die Leistung solcher Produkte unmittelbar zu beeinflussen, werden der Klasse IIb zugeordnet.“

  - g) Abschnitt 6.3 erhält folgende Fassung:

    - „6.3. Regel 11

        Software, die dazu bestimmt ist, ein Ergebnis zu erzeugen, das einen klinischen Nutzen vermittelt, und die zur Diagnose, Behandlung, Prävention, Überwachung, Vorhersage, Prognose, Kompensation oder Linderung einer Krankheit oder eines Zustands verwendet wird, wird der Klasse I zugeordnet, es sei denn, das Ergebnis ist für eine Krankheit oder einen Zustand bestimmt:

      - – in einer kritischen Situation mit dem Risiko, den Tod oder eine irreversible Verschlechterung des Gesundheitszustands einer Person zu verursachen; in diesem Fall wird sie der Klasse III zugeordnet;

      - – in einer schwerwiegenden Situation mit dem Risiko, eine schwerwiegende Verschlechterung des Gesundheitszustands einer Person oder einen chirurgischen Eingriff zu verursachen, oder zur Steuerung des klinischen Managements in einer kritischen Situation; in diesen Fällen wird sie der Klasse IIb zugeordnet;

      - – in einer nicht schwerwiegenden Situation oder zur Steuerung des klinischen Managements in einer schwerwiegenden Situation oder zur Information des klinischen Managements in einer kritischen oder schwerwiegenden Situation; in diesen Fällen wird sie der Klasse IIa zugeordnet.“

  - h) In Abschnitt 7.6 erhält der einleitende Teil folgende Fassung:

      „Regel 19

      Alle Produkte, die Nanomaterialien im Sinne der Empfehlung C/2022/3689 der Kommission enthalten oder daraus bestehen, werden wie folgt eingestuft:“

  - i) In Abschnitt 7.8 erhält der einleitende Teil folgende Fassung:

      „Produkte, die aus Stoffen oder Kombinationen von Stoffen bestehen, die dazu bestimmt sind, durch eine Körperöffnung in den menschlichen Körper eingeführt oder auf die Haut aufgetragen zu werden, und die vom Körper aufgenommen oder lokal auf dem oder im Körper verteilt werden, werden wie folgt zugeordnet:“

- 7. Anhang IX wird wie folgt geändert:

  - a) Abschnitt 2.3 Absätze 3 und 4 erhalten folgende Fassung:

      „Darüber hinaus wird bei Produkten der Klassen IIa und IIb die Bewertung des Qualitätsmanagementsystems von einer Bewertung der technischen Dokumentation gemäß den Anhängen II und III, wie in den Abschnitten 4.3 bis 4.8 für ein repräsentatives Produkt festgelegt, begleitet. Bei Produkten der Klasse IIa ist Anhang II Abschnitt 3 Buchstabe a jedoch von der Bewertung ausgenommen. Bei der Auswahl des repräsentativen Produkts wendet die Benannte Stelle einen risikobasierten Ansatz unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit an und berücksichtigt insbesondere die physikalischen, chemischen und biologischen Eigenschaften des Produkts, den Grad der Neuartigkeit der Technologie, Ähnlichkeiten in Bezug auf Auslegung, Technologie sowie Herstellungs- und Sterilisationsverfahren, die Zweckbestimmung, die Anwendung harmonisierter Normen oder Gemeinsamer Spezifikationen (GS) durch den Hersteller für das Produkt sowie die Ergebnisse etwaiger früherer einschlägiger Bewertungen, etwa hinsichtlich physikalischer, chemischer, biologischer oder klinischer Eigenschaften, die gemäß dieser Verordnung durchgeführt wurden. Die betreffende Benannte Stelle dokumentiert ihre Begründung für die gewählten repräsentativen Produkte.

      Für Produkte der Klassen IIa und IIb kann die Benannte Stelle in hinreichend begründeten Fällen, die im Rahmen der Bewertung des Qualitätsmanagementsystems festgestellt wurden, eine anlassbezogene Bewertung der technischen Dokumentation zusätzlicher repräsentativer Produkte vornehmen.

      Falls das Qualitätsmanagementsystem sowie die technische Dokumentation des bewerteten repräsentativen Produkts den einschlägigen Bestimmungen dieser Verordnung entspricht, stellt die Benannte Stelle eine EU-Qualitätsmanagementbescheinigung aus. Die Benannte Stelle teilt dem Hersteller ihre Entscheidung zur Ausstellung einer Bescheinigung mit. Die Entscheidung enthält auch die Ergebnisse des Audits und einen mit Gründen versehenen Bericht.“

  - b) In Abschnitt 3.2 erhält der zweite Gedankenstrich folgende Fassung:

    - – „die Dokumentation über alle Erkenntnisse und Ergebnisse, die bei der Anwendung des Plans zur Überwachung nach dem Inverkehrbringen einschließlich des Plans für die klinische Nachbeobachtung nach dem Inverkehrbringen bei den repräsentativen Produkten und der in den Artikeln 87 bis 92 festgelegten Vigilanz-Bestimmungen gewonnen wurden,“

  - c) Abschnitt 3.3 erhält folgende Fassung:

    - „3.3. Die Benannten Stellen führen regelmäßig geeignete Audits und Bewertungen durch, um sich davon zu überzeugen, dass der betreffende Hersteller das genehmigte Qualitätsmanagementsystem und den Plan zur Überwachung nach dem Inverkehrbringen anwendet. Diese Audits und Bewertungen schließen Audits in den Betriebsstätten des Herstellers und gegebenenfalls den Betriebsstätten der Zulieferer des Herstellers und/oder seiner Subunternehmer ein. In begründeten Fällen kann das Audit anstelle einer Vor-Ort-Prüfung als Fernprüfung durchgeführt werden. Die Benannte Stelle führt, soweit erforderlich, Prüfungen durch oder veranlasst solche, um zu überprüfen, ob das Qualitätsmanagementsystem ordnungsgemäß funktioniert. Die Benannte Stelle stellt dem Hersteller einen Bericht über die Überwachungsaudits und gegebenenfalls über die vorgenommenen Prüfungen zur Verfügung.

        Die Benannte Stelle führt die Überwachungsaudits und bewertungen einmal alle 12 Monate durch. Ist dies jedoch unter Berücksichtigung der Ergebnisse früherer Überwachungsaudits und bewertungen gerechtfertigt und bestehen keine Bedenken aufgrund von Daten aus der Überwachung nach dem Inverkehrbringen oder der Vigilanz, so führt die Benannte Stelle die Überwachungsaudits und bewertungen nur einmal alle 24 Monate durch.“

  - d) Abschnitt 3.4 wird wie folgt geändert:

    - i) Absatz 1 erhält folgende Fassung:

        „Die Benannte Stelle führt kurzfristig angekündigte oder unangekündigte Audits am Standort des Herstellers und, soweit erforderlich, bei dessen Lieferanten und/oder Unterauftragnehmern durch, sofern dies aufgrund von Bedenken im Zusammenhang mit Daten aus der Überwachung nach dem Inverkehrbringen oder der Vigilanz gerechtfertigt ist oder auf Antrag einer zuständigen Behörde erfolgt. Das kurzfristig angekündigte oder unangekündigte Audit kann mit der in Abschnitt 3.3 genannten regelmäßigen Überwachungsbewertung kombiniert oder zusätzlich zu dieser Überwachungsbewertung durchgeführt werden.“

    - ii) Absatz 2 Satz 1 erhält folgende Fassung:

        „Im Rahmen solcher unangekündigten Vor-Ort-Audits kann die Benannte Stelle eine angemessene Stichprobe der hergestellten Produkte oder eine angemessene Stichprobe aus dem Herstellungsprozess prüfen, um festzustellen, ob das hergestellte Produkt mit der technischen Dokumentation übereinstimmt, mit Ausnahme der in Artikel 52 Absatz 8 Unterabsatz 2 genannten Produkte.“

    - iii) Absatz 3 Satz 1 erhält folgende Fassung:

        „Anstelle oder zusätzlich zu der in Absatz 2 genannten Stichprobe kann die Benannte Stelle Stichproben von auf dem Markt vorhandenen Produkten zusammenstellen, um zu prüfen, ob das hergestellte Produkt mit der technischen Dokumentation übereinstimmt, mit Ausnahme der in Artikel 52 Absatz 8 Unterabsatz 2 genannten Produkte.“

  - e) Abschnitt 3.5 erhält folgende Fassung:

    - „3.5. Bei Produkten der Klassen IIa und IIb sowie bei Produkten der Klasse III, die Produkte mit bewährter Technologie sind, kann die Benannte Stelle im Rahmen der Überwachungsbewertung eine anlassbezogene Bewertung der technischen Dokumentation repräsentativer Produkte einbeziehen, sofern sie auf der Grundlage von Daten aus der Überwachung nach dem Inverkehrbringen oder aus einem hinreichenden sonstigen Grund potenzielle Bedenken festgestellt hat.

        Bei Produkten der Klasse III, mit Ausnahme von Produkten mit bewährter Technologie, umfasst die Überwachungsbewertung zudem eine Prüfung der genehmigten Teile und/oder Materialien, die für die Unversehrtheit des Produkts unerlässlich sind, einschließlich gegebenenfalls einer Überprüfung, ob die Mengen der hergestellten oder beschafften Teile und/oder Materialien den Mengen der fertigen Produkte entsprechen.“

  - f) Abschnitt 3.7 erhält folgende Fassung:

    - „3.7. Stellt die Benannte Stelle Abweichungen zwischen der aus den hergestellten Produkten oder vom Markt entnommenen Stichprobe und den in der technischen Dokumentation oder der genehmigten Auslegung beschriebenen Spezifikationen fest, so setzt sie die jeweilige Bescheinigung aus, widerruft sie oder versieht sie mit Bedingungen oder Beschränkungen.“

  - g) Die Überschrift von Abschnitt 4 erhält folgende Fassung:

    - „4. Bewertung der technischen Dokumentation“

  - h) Abschnitt 4.2 Satz 2 erhält folgende Fassung:

      „Er enthält die technischen Unterlagen gemäß den Anhängen II und III oder einen Plan und die entsprechenden Fristen für die Vorlage dieser technischen Unterlagen.“

  - i) Abschnitt 4.4 Satz 2 erhält folgende Fassung:

      „Für die Zwecke dieser Überprüfung verwendet die Benannte Stelle Produktprüfer mit ausreichendem klinischen Fachwissen und setzt externe klinische Experten mit unmittelbarer aktueller Erfahrung im Zusammenhang mit dem betreffenden Produkt oder den klinischen Bedingungen, unter denen es verwendet wird, ein.“

  - j) Abschnitt 4.8 erhält folgende Fassung:

      „Die Benannte Stelle übermittelt dem Hersteller einen Bericht über die Bewertung der technischen Dokumentation einschließlich eines Berichts über die Begutachtung der klinischen Bewertung.“

  - k) In Abschnitt 4.9 werden die Sätze 1 und 3 gestrichen.

  - l) Abschnitt 5.1 wird wie folgt geändert:

    - i) Der Titel erhält folgende Fassung:

      - „5.1. Bewertungsverfahren für Produkte gemäß Artikel 54“

    - ii) Buchstabe a Absätze 1 und 2 erhalten folgende Fassung:

      - „a) Bei Produkten gemäß Artikel 54 erstellt die Benannte Stelle — nachdem sie die Qualität der klinischen Daten, auf denen der klinische Bewertungsbericht des Herstellers gemäß Artikel 61 Absatz 1 beruht, geprüft hat — einen Bericht über die Begutachtung der klinischen Bewertung, in dem sie ihre Schlussfolgerungen zu dem vom Hersteller vorgelegten klinischen Nachweis, insbesondere zur Nutzen-Risiko-Abwägung, zur Kohärenz dieses Nachweises mit der Zweckbestimmung, einschließlich der medizinischen Indikation oder Indikationen, und zu dem in Artikel 10 Absatz 3 und Anhang XIV Teil B genannten Plan für die klinische Nachbeobachtung nach dem Inverkehrbringen darlegt.

          Die Benannte Stelle übermittelt ihren Bericht über die Begutachtung der klinischen Bewertung zusammen mit dem klinischen Bewertungsbericht des Herstellers und gegebenenfalls dem Plan für die klinische Nachbeobachtung nach dem Inverkehrbringen an die Kommission.“

    - iii) In Buchstabe b wird der folgende Satz angefügt:

        „Gegebenenfalls kann das Expertengremium den Hersteller zudem auffordern, die Schlussfolgerungen seiner klinischen Bewertung darzulegen.“

    - iv) Buchstabe g erhält folgende Fassung:

      - „g) Die Benannte Stelle trägt den im wissenschaftlichen Gutachten des Expertengremiums geäußerten Ansichten in größtmöglichem Umfang Rechnung und aktualisiert gegebenenfalls ihren Bericht über die Begutachtung der klinischen Bewertung. Stellt das Expertengremium fest, dass der klinische Nachweis nicht ausreichend ist oder auf andere Weise Anlass zu ernsthafter Besorgnis im Hinblick auf die Nutzen-Risiko-Abwägung, die Kohärenz dieses Nachweises mit der Zweckbestimmung, einschließlich der medizinischen Indikation(en), und den Plan für die klinische Nachbeobachtung nach dem Inverkehrbringen gibt, so rät die Benannte Stelle dem Hersteller erforderlichenfalls, zusätzliche klinische Daten zu sammeln und die klinische Bewertung zu aktualisieren, um die Zweckbestimmung des Produkts auf bestimmte Patientengruppen oder bestimmte medizinische Indikationen zu beschränken und/oder eine Begrenzung der Geltungsdauer der Bescheinigung vorzusehen, spezifische Studien über die klinische Nachbeobachtung nach dem Inverkehrbringen durchzuführen und die Gebrauchsanweisung oder den Kurzbericht über Sicherheit und klinische Leistung anzupassen, oder sieht — gegebenenfalls in ihrem Konformitätsbewertungsbericht — andere Bedingungen vor. Die Benannte Stelle legt dar, wie sie die im Gutachten des Expertengremiums geäußerten Ansichten und Empfehlungen berücksichtigt hat, und legt, sofern sie den Ansichten und Empfehlungen des Expertengremiums nicht gefolgt ist, hinreichende Gründe hierfür vor. Das wissenschaftliche Gutachten des Expertengremiums sowie die Darlegung, wie diesem Rechnung getragen wurde, oder gegebenenfalls die von der Benannten Stelle vorgelegte hinreichende Begründung werden ohne vertrauliche Informationen im Sinne des Artikels 109 über Eudamed öffentlich zugänglich gemacht.“

  - m) Abschnitt 5.2 wird wie folgt geändert:

    - i) Buchstabe d erhält folgende Fassung:

        „Die konsultierte Arzneimittelbehörde übermittelt der Benannten Stelle ihr Gutachten innerhalb von 90 Tagen nach Eingang aller erforderlichen Unterlagen. Diese Frist von 90 Tagen kann einmal aus berechtigten Gründen um weitere 30 Tage verlängert werden. Ist der Arzneimittelwirkstoff in der Union nicht zuvor zugelassen worden, so gibt die konsultierte Arzneimittelbehörde ihre Stellungnahme innerhalb von 180 Tagen ab. Bei der Erstellung ihrer Stellungnahme kann die konsultierte Arzneimittelbehörde die Benannte Stelle oder den Hersteller auffordern, innerhalb einer festgelegten Frist zusätzliche für ihre Bewertung gemäß Buchstabe b erforderliche Informationen vorzulegen. Im Falle eines solchen Ersuchens wird die in diesem Absatz festgelegte Frist ausgesetzt, bis die angeforderten zusätzlichen Informationen vorgelegt worden sind.“

    - ii) Buchstabe g erhält folgende Fassung:

      - „g) Erhält die konsultierte Arzneimittelbehörde Informationen über den unterstützenden Stoff, die Auswirkungen auf den Nutzen oder das Risiko, der/das zuvor für die Verwendung des Stoffes in dem Produkt festgestellt wurde, haben könnten, so teilt sie der Benannten Stelle mit, ob diese Informationen Auswirkungen auf den Nutzen oder das Risiko, der/das zuvor für die Verwendung des Stoffes in dem Produkt festgestellt wurde, haben. Im Falle von Informationen über schwerwiegende Vorkommnisse, die im Wege der in Artikel 89 Absatz 6 Unterabsatz 1 dieser Verordnung vorgesehenen Meldung erlangt wurden, überprüft die konsultierte Arzneimittelbehörde die Daten, die in aggregierter Form vorgelegt werden können, und kann, soweit erforderlich, mit der Benannten Stelle Kontakt aufnehmen, um weitere Informationen zu erhalten. Die Benannte Stelle berücksichtigt diese Mitteilung bei ihren Überlegungen zu einer erneuten Bewertung des Konformitätsbewertungsverfahrens.“

  - n) Abschnitt 5.3.1 erhält folgende Fassung:

    - „5.3.1. Substanzen menschlichen Ursprungs oder ihre Derivate

      - a) Im Fall von Produkten, die unter Verwendung von Derivaten von Substanzen menschlichen Ursprungs hergestellt werden, die in dieser Verordnung unter Artikel 1 Absatz 6 Buchstabe g erfasst sind, und von Produkten, die als integralen Bestandteil von der Verordnung (EU) 2024/1938 erfasste Substanzen menschlichen Ursprungs oder deren Derivate enthalten, denen im Rahmen des Produkts eine unterstützende Funktion zukommt, holt die Benannte Stelle vor Ausstellung einer EU-Bescheinigung über die Bewertung der technischen Dokumentation ein wissenschaftliches Gutachten einer der von den Mitgliedstaaten gemäß Verordnung (EU) 2024/1938 bezeichneten zuständigen Behörden (im Folgenden „für SoHO zuständige Behörde“) zu den Aspekten im Zusammenhang mit der Spenderregistrierung, der Spenderbewertung sowie der Gewinnung und Prüfung der Substanzen menschlichen Ursprungs oder deren Derivaten ein. Die Benannte Stelle legt eine Zusammenfassung der vorläufigen Konformitätsbewertung vor, die unter anderem Informationen zur Nichtlebensfähigkeit der betreffenden Substanz menschlichen Ursprungs, die Spenderregistrierung, die Spenderbewertung sowie die Gewinnung und Prüfung und das Risiko oder den Nutzen der Integration der Substanz menschlichen Ursprungs oder deren Derivaten in das Produkt enthält.

      - b) Innerhalb von 90 Tagen nach Eingang aller erforderlichen Unterlagen legt die für SoHO zuständige Behörde der Benannten Stelle ihr Gutachten vor. Diese Frist von 90 Tagen kann einmal aus berechtigten Gründen um weitere 30 Tage verlängert werden.

      - c) Das wissenschaftliche Gutachten der für SoHO zuständigen Behörde sowie etwaige Aktualisierungen werden in die Dokumentation der Benannten Stelle zu dem Produkt aufgenommen. Bei ihrer Entscheidung berücksichtigt die Benannte Stelle gebührend die in dem wissenschaftlichen Gutachten der für SoHO zuständigen Behörde geäußerten Standpunkte. Die Benannte Stelle stellt keine Bescheinigung aus, wenn dieses wissenschaftliche Gutachten negativ ist. Sie setzt die für SoHO zuständige Behörde von ihrer abschließenden Entscheidung in Kenntnis.

      - d) Bevor eine Änderung in Bezug auf in ein Produkt integrierte nicht lebensfähige Substanzen menschlichen Ursprungs oder deren Derivate vorgenommen wird, insbesondere im Zusammenhang mit der Spenderregistrierung, der Spenderbewertung sowie der Gewinnung und Prüfung, unterrichtet der Hersteller die Benannte Stelle über die beabsichtigten Änderungen. Die Benannte Stelle konsultiert die Behörde, die an der ursprünglichen Konsultation beteiligt war, um zu bestätigen, dass Qualität und Sicherheit der Substanzen menschlichen Ursprungs oder ihrer Derivate, die in dem Produkt verwendet werden, erhalten bleiben. Die für SoHO zuständige Behörde berücksichtigt die Angaben über den Nutzen der Verwendung der Substanzen menschlichen Ursprungs und ihrer Derivate in dem Produkt, wie von der Benannten Stelle ermittelt, um sicherzustellen, dass sich die Änderungen nicht negativ auf das Nutzen-Risiko-Verhältnis auswirken, das für die Aufnahme der Substanzen menschlichen Ursprungs oder ihrer Derivate in das Produkt bestimmt wurde. Sie übermittelt ihr Gutachten innerhalb von 60 Tagen nach Eingang aller erforderlichen Unterlagen zu den beabsichtigten Änderungen. Die Benannte Stelle stellt keinen Nachtrag zu der EU-Bescheinigung über die Bewertung der technischen Dokumentation aus, wenn das wissenschaftliche Gutachten negativ ist, und setzt die für SoHO zuständige Behörde von ihrer abschließenden Entscheidung in Kenntnis.

      - e) Im Falle von Informationen über schwerwiegende Vorkommnisse, die im Wege der in Artikel 89 Absatz 6 Unterabsatz 2 vorgesehenen Meldung erlangt wurden, überprüft die für SoHO zuständige Behörde die Daten und kann, soweit erforderlich, mit der Benannten Stelle Kontakt aufnehmen, um weitere Informationen zu erhalten.“

  - o) Abschnitt 5.3.2 wird gestrichen.

  - p) In Abschnitt 5.4 werden die Buchstaben b, c und d gestrichen.

- 8. Anhang X wird wie folgt geändert:

  - a) Abschnitt 3 Buchstabe c erhält folgende Fassung:

    - „c) Sie überprüft den vom Hersteller in dem klinischen Bewertungsbericht gemäß Anhang XIV Abschnitt 4 vorgelegten klinischen Nachweis. Für die Zwecke dieser Überprüfung verwendet die Benannte Stelle Produktprüfer mit ausreichendem klinischen Fachwissen und setzt externe klinische Experten mit unmittelbarer aktueller Erfahrung im Zusammenhang mit dem betreffenden Produkt oder den klinischen Bedingungen, unter denen es verwendet wird, ein.“

  - b) Abschnitt 4 erhält folgende Fassung:

      „Falls das Baumuster dieser Verordnung entspricht, stellt die Benannte Stelle eine EU-Baumusterprüfbescheinigung aus. Die relevanten Teile der Dokumentation werden der Bescheinigung beigefügt; eine Abschrift verbleibt bei der Benannten Stelle.“

- 9. Anhang XI wird wie folgt geändert:

  - a) Abschnitt 3 erhält folgende Fassung:

    - „3. Abweichend von den Abschnitten 1 und 2 können Abschnitt 10 oder Abschnitt 18 dieses Anhangs in Verbindung mit der Erstellung einer technischen Dokumentation gemäß den Anhängen II und III auch von Herstellern von Produkten der Klasse IIa angewendet werden.“

  - b) Vor Teil A wird folgender Abschnitt 3a eingefügt:

    - „3a. Abweichend von den vorstehenden Abschnitten 1 und 2 kann Abschnitt 10a auch von Herstellern von Produkten der Klasse I angewendet werden, die in sterilem Zustand in Verkehr gebracht werden, eine Messfunktion aufweisen oder wiederverwendbare chirurgische Instrumente sind.“

  - c) Abschnitt 7 Absatz 2 erhält folgende Fassung:

      „Bei Produkten der Klasse III, mit Ausnahme von Produkten mit bewährter Technologie, wird im Rahmen der Überwachung auch überprüft, ob die Menge der für das Baumuster genehmigten hergestellten oder beschafften Rohstoffe oder wesentlichen Komponenten der Menge der Endprodukte entspricht.“

  - d) Abschnitt 10 erhält folgende Fassung:

    - „10. Anwendung auf Produkte der Klasse IIa

      - 10.1. Der Hersteller gewährleistet die Anwendung des für die Herstellung der betreffenden Produkte genehmigten Qualitätsmanagementsystems.

      - 10.2. Mit der EU-Konformitätserklärung gewährleistet und erklärt der Hersteller, dass die betreffenden Produkte der Klasse IIa im Einklang mit der technischen Dokumentation gemäß den Anhängen II und III hergestellt werden und den einschlägigen Anforderungen dieser Verordnung entsprechen.

      - 10.3. Der Hersteller beantragt bei einer Benannten Stelle die Bewertung seines Qualitätsmanagementsystems. Der Antrag muss alle in Anhang IX Abschnitt 2.1 aufgeführten Elemente enthalten. Der Hersteller stellt sicher, dass für die Bewertung des Qualitätsmanagementsystems eine angemessene Beschreibung aller in Abschnitt 2.2 Buchstaben a, b, d und e des Anhangs IX aufgeführten Elemente verfügbar ist.

      - 10.4. Es gilt Anhang IX Abschnitt 2.3 Absätze 1 bis 4.

      - 10.5. Bestätigt die Bewertung gemäß Abschnitt 10.4 des vorliegenden Anhangs, dass die betreffenden Produkte mit der in den Anhängen II und III beschriebenen technischen Dokumentation übereinstimmen und die einschlägigen Anforderungen dieser Verordnung erfüllen, so stellt die Benannte Stelle eine EU-Produktionsqualitätssicherungsbescheinigung gemäß Teil A dieses Anhangs aus.

      - 10.6. Es gilt Anhang IX Abschnitt 2.4.

      - 10.7. Es gelten Anhang IX Abschnitt 3.1, Abschnitt 3.2 erster, zweiter und vierter Gedankenstrich sowie Anhang IX Abschnitte 3.3 bis 3.7.

      - 10.8. Der Hersteller oder sein Bevollmächtigter hält während eines Zeitraums, der frühestens zehn Jahre nach dem Inverkehrbringen des letzten Produkts endet, für die zuständigen Behörden folgende Unterlagen bereit:

        - – die EU-Konformitätserklärung,

        - – die technische Dokumentation gemäß den Anhängen II und III und

        - – die Bescheinigung gemäß Abschnitt 10.5 dieses Anhangs.

      - 10.9. Es gilt Anhang IX Abschnitt 8.“

  - e) Vor Teil B wird folgender Abschnitt 10a eingefügt:

    - „10a. Anwendung auf Produkte der Klasse I, die in sterilem Zustand in Verkehr gebracht werden, eine Messfunktion aufweisen oder wiederverwendbare chirurgische Instrumente sind

    - 10a.1. Der Hersteller gewährleistet die Anwendung des für die Herstellung der betreffenden Produkte genehmigten Qualitätsmanagementsystems.

    - 10a.2. Mit der EU-Konformitätserklärung gewährleistet und erklärt der Hersteller, dass die betreffenden Produkte im Einklang mit der technischen Dokumentation gemäß den Anhängen II und III hergestellt werden und den einschlägigen Anforderungen dieser Verordnung entsprechen.

    - 10a.3. Der Hersteller beantragt bei einer Benannten Stelle die Bewertung seines Qualitätsmanagementsystems. Der Antrag muss die in Anhang IX Abschnitt 2.1 erster bis sechster Gedankenstrich aufgeführten Elemente enthalten. Der Hersteller stellt sicher, dass für die Bewertung des Qualitätsmanagementsystems eine angemessene Beschreibung aller in Anhang IX Abschnitt 2.2 Buchstaben d und e aufgeführten Elemente verfügbar ist.

    - 10a.4. Es gilt Anhang IX Abschnitt 2.3 Absatz 1 und 2. Die Bewertung durch die Benannte Stelle ist beschränkt

      - – bei Produkten, die in sterilem Zustand in Verkehr gebracht werden, auf die Aspekte, die mit der Herstellung, der Sicherung und der Aufrechterhaltung steriler Bedingungen zusammenhängen,

      - – bei Produkten mit Messfunktion auf die Aspekte, die mit der Konformität der Produkte mit den messtechnischen Anforderungen zusammenhängen,

      - – bei wiederverwendbaren chirurgischen Instrumenten auf die Aspekte, die mit der Wiederverwendung in Zusammenhang stehen, insbesondere die Reinigung, Desinfektion, Sterilisation, Wartung und Funktionsprüfung sowie die damit verbundenen Gebrauchsanweisungen.

    - 10a.5. Bestätigt die Bewertung gemäß Abschnitt 10a.4., dass Elemente des Qualitätsmanagementsystems den einschlägigen Bestimmungen dieser Verordnung entsprechen, so stellt die Benannte Stelle gemäß diesem Teil dieses Anhangs eine EU-Produktionsqualitätssicherungsbescheinigung aus.

    - 10a.6. Es gilt Anhang IX Abschnitt 2.4.

    - 10a.7. Es gelten Anhang IX Abschnitt 3.1, Abschnitt 3.2 erster, zweiter und vierter Gedankenstrich sowie Anhang IX Abschnitte 3.3, 3.4 und 3.6.

    - 10a.8. Der Hersteller oder sein Bevollmächtigter hält während eines Zeitraums, der frühestens zehn Jahre nach dem Inverkehrbringen des letzten Produkts endet, für die zuständigen Behörden folgende Unterlagen bereit:

      - – die EU-Konformitätserklärung,

      - – die Dokumentation gemäß Anhang IX Abschnitt 2.1 fünfter Gedankenstrich,

      - – die Bescheinigung gemäß Abschnitt 10a.5

    - 10a.9. Es gilt Anhang IX Abschnitt 8.“

  - f) Abschnitt 12 Absatz 2 erhält folgende Fassung:

      „Bei Produkten, die in sterilem Zustand in Verkehr gebracht werden, wendet der Hersteller ferner die Bestimmungen der Abschnitte 6.1, 6.2, 6.3 Absatz 1, 6.4 und 7 an; diese Vorschrift bezieht sich jedoch nur auf die Herstellungsschritte, die der Sterilisation und der Aufrechterhaltung der Sterilität dienen.“

  - g) Abschnitt 18 erhält folgende Fassung:

    - „18. Anwendung auf Produkte der Klasse IIa

    - 18.1. Die Produktprüfung ist als Verfahren zu verstehen, mit dem es als vom Hersteller nach Prüfung jedes hergestellten Produkts durch Ausstellung einer EU-Konformitätserklärung gemäß Artikel 19 und Anhang IV als gewährleistet und erklärt gilt, dass die Produkte, die dem in den Abschnitten 14 und 15 beschriebenen Verfahren unterzogen wurden, mit der technischen Dokumentation gemäß den Anhängen II und III übereinstimmen und den einschlägigen Anforderungen dieser Verordnung entsprechen.

    - 18.2. Der Hersteller trifft alle erforderlichen Maßnahmen, damit im Herstellungsverfahren die Übereinstimmung der Produkte mit den in der EU-Konformitätserklärung beschriebenen Produkten und den einschlägigen Anforderungen der Verordnung sichergestellt wird. Vor Beginn der Herstellung erstellt der Hersteller Unterlagen zur Festlegung des Herstellungsverfahrens, insbesondere – soweit erforderlich – in Bezug auf die Sterilisation, sowie sämtliche routinemäßige, im Voraus festgelegte Verfahren, die zur Gewährleistung einer homogenen Produktion umzusetzen sind.

        Bei Produkten, die in sterilem Zustand in Verkehr gebracht werden, wendet der Hersteller ferner die Bestimmungen der Abschnitte 10.3, 10.4, 10.6 und 10.7 an; diese Vorschrift bezieht sich jedoch nur auf die Herstellungsschritte, die der Sterilisation und der Aufrechterhaltung der Sterilität dienen.

    - 18.3. Es gelten die Abschnitte 13 und 14. Abschnitt 15 findet Anwendung, um die Konformität der Produkte mit den in der EU-Konformitätserklärung beschriebenen Produkten zu überprüfen.

    - 18.4. Abweichend von Abschnitt 17 hält der Hersteller oder sein Bevollmächtigter während eines Zeitraums, der frühestens zehn Jahre nach dem Inverkehrbringen des letzten Produkts endet, für die zuständigen Behörden folgende Unterlagen bereit:

      - – die EU-Konformitätserklärung,

      - – die Dokumentation gemäß Abschnitt 18.2,

      - – die technische Dokumentation gemäß den Anhängen II und III,

      - – die Bescheinigung gemäß Abschnitt 15.2.

    - 18.5. Es gilt Anhang IX Abschnitt 8.“

- 10. Anhang XII wird wie folgt geändert:

  - a) Kapitel I Abschnitt 4 Buchstabe b erhält folgende Fassung:

    - „b) EU-Qualitätsmanagementbescheinigungen und EU-Qualitätssicherungsbescheinigungen enthalten Angaben zu den Produkten bzw. Produktgruppen, zur Risikoklassifizierung sowie zu den erfassten Fertigungsstätten.“

  - b) Kapitel II wird wie folgt geändert:

    - i) Abschnitt 6 erhält folgende Fassung:

      - „6. gegebenenfalls das Ablaufdatum;“

    - ii) Abschnitt 7 erhält folgende Fassung:

      - „7. Daten für die eindeutige Identifizierung des Produkts bzw. der Produkte, gegebenenfalls gemäß Kapitel I Abschnitt 4;“

    - iii) Abschnitt 10 erhält folgende Fassung:

      - „10. Verweis auf einschlägige GS und harmonisierte Normen;“

- 11. Anhang XIII wird wie folgt geändert:

  - a) In Abschnitt 1 erhält der achte Gedankenstrich folgende Fassung:

      „gegebenenfalls ein Hinweis, dass zu den Bestandteilen oder Inhaltsstoffen des Produkts ein Arzneimittel gehört, einschließlich eines Derivats aus menschlichem Blut oder Plasma, oder Geweben oder Zellen menschlichen oder tierischen Ursprungs gemäß Verordnung (EU) Nr. 722/2012 oder etwaigen nachfolgenden gemäß dieser Verordnung erlassenen Durchführungsrechtsakten.“

  - b) in Abschnitt 5 erhält der erste Satz folgende Fassung:

      „Der Hersteller überprüft und dokumentiert die in der Phase nach der Herstellung gewonnenen Erfahrungen, gegebenenfalls einschließlich der klinischen Nachbeobachtung nach dem Inverkehrbringen gemäß Teil B des Anhangs XIV, und trifft geeignete Maßnahmen zur Durchführung etwaiger erforderlicher Korrekturmaßnahmen.“

- 12. Anhang XIV wird wie folgt geändert:

  - a) Abschnitt 1 wird wie folgt geändert:

    - i) Buchstabe a wird wie folgt geändert:

      - 1. Der erste Gedankenstrich erhält folgende Fassung:

        - – „eine Bestimmung der grundlegenden Sicherheits- und Leistungsanforderungen, die mit relevanten klinischen Daten zu untermauern sind, oder eine angemessene Begründung dafür, dass eine Bestätigung der Sicherheit und Leistung auf der Grundlage klinischer Daten gemäß Artikel 61 Absatz 10 als nicht angemessen angesehen wird;“

      - 2. Der siebte und der achte Gedankenstrich erhalten folgende Fassung:

        - – „eine Angabe, wie Fragen hinsichtlich des Nutzen-Risiko-Verhältnisses für bestimmte Komponenten wie die Verwendung pharmazeutischer, nicht lebensfähiger Substanzen menschlichen Ursprungs oder nicht lebensfähiger tierischer Gewebe zu klären sind;

        - – gegebenenfalls eine klinische Entwicklungsstrategie von explorativen Studien, wie Studien zur Erstanwendung am Menschen („First-in-man“-Studien), Durchführbarkeitsstudien und Pilotstudien bis hin zu Bestätigungsstudien, wie pivotale klinische Prüfungen, und einer klinischen Überwachung nach dem Inverkehrbringen gemäß Teil B, unter Angabe von Etappenzielen und Beschreibung möglicher Akzeptanzkriterien;“

    - ii) Folgender Absatz wird angefügt:

        „Die Buchstaben b bis e finden keine Anwendung auf Produkte, für die eine Bestätigung der Sicherheit und Leistung auf der Grundlage klinischer Daten gemäß Artikel 61 Absatz 10 als nicht angemessen angesehen wird.“

  - b) In Abschnitt 3 erhalten der zweite und dritte Gedankenstrich folgende Fassung:

    - – „Biologisch: Das Produkt verwendet die gleichen oder ähnliche Materialien oder Stoffe im Kontakt mit den gleichen menschlichen Geweben oder Körperflüssigkeiten für eine ähnliche Art und Dauer des Kontakts bei ähnlichem Abgabeverhalten der Stoffe einschließlich Abbauprodukte und herauslösbarer Bestandteile (‚leachables‘).

    - – Klinisch: Das Produkt wird unter der gleichen oder einer ähnlichen klinischen Bedingung oder zum gleichen klinischen Zweck, einschließlich eines ähnlichen Schweregrads und Stadiums der Krankheit, an der gleichen Körperstelle und bei ähnlichen Patientenpopulationen in Bezug auf u. a. Alter, Anatomie und Physiologie angewandt, hat die gleichen Anwender; und erbringt eine ähnliche, maßgebliche und entscheidende Leistung im Hinblick auf die erwartete klinische Wirkung für eine spezielle Zweckbestimmung.“

  - c) In Abschnitt 5 wird nach Satz 1 folgender Satz eingefügt:

      „Wird die klinische Nachbeobachtung nach dem Inverkehrbringen als nicht anwendbar erachtet, so legt der Hersteller eine Begründung im Plan zur Überwachung nach dem Inverkehrbringen gemäß Anhang III Abschnitt 1 vor.“

  - d) Abschnitt 7 erhält folgende Fassung:

    - „7. Der Hersteller analysiert die Feststellungen aus der klinischen Nachbeobachtung nach dem Inverkehrbringen und dokumentiert die Ergebnisse in dem klinischen Bewertungsbericht und der technischen Dokumentation.“

  - e) Abschnitt 8 erhält folgende Fassung:

    - „8. Die Schlussfolgerungen des Bewertungsberichts über die klinische Nachbeobachtung nach dem Inverkehrbringen finden bei der klinischen Bewertung gemäß Artikel 61 und Teil A dieses Anhangs und beim Risikomanagement gemäß Anhang I Abschnitt 3 Berücksichtigung. Wird im Rahmen der klinischen Nachbeobachtung nach dem Inverkehrbringen die Notwendigkeit von Präventiv- und/oder Korrekturmaßnahmen festgestellt, so setzt der Hersteller solche Maßnahmen um.“

- 13. Anhang XV wird wie folgt geändert:

  - a) In Kapitel I Abschnitt 2.6 wird folgender Satz angefügt:

      „Bei kombinierten Studien können Endpunkte verwendet werden, die das Produkt und das Arzneimittel gemeinsam betreffen.“

  - b) Kapitel II wird wie folgt geändert:

    - i) Abschnitt 1.4 erhält folgende Fassung:

      - „1.4. Status des Antrags auf klinische Prüfung (d. h. Erstantrag, Wiedervorlage, wesentliche Änderung);“

    - ii) Abschnitt 1.6 erhält folgende Fassung:

      - „1.6. bei einer Wiedervorlage des Antrags für ein Produkt, für das bereits ein Antrag eingereicht wurde, das Datum bzw. die Daten und die Referenznummer bzw. die Referenznummern des vorherigen Antrags oder, im Fall einer wesentlichen Änderung, ein Verweis auf den Originalantrag. Der Sponsor macht alle Änderungen gegenüber dem vorhergehenden Antrag kenntlich und begründet diese; insbesondere gibt er an, ob sie infolge von Schlussfolgerungen vorangegangener Überprüfungen der zuständigen Behörde oder der Ethik-Kommission vorgenommen wurden.“

<a id="annex-ii"></a>
## Anhang II

Die Anhänge I, II, III, VI, VII, IX, X, XI, XII, XIII und XIV der Verordnung (EU) Nr. 2017/746 werden wie folgt geändert:

- 1. Anhang I wird wie folgt geändert:

  - a) Abschnitt 16.4 erhält folgende Fassung:

      „Die Hersteller legen Mindestanforderungen bezüglich Hardware, Eigenschaften von IT-Netzen und IT-Sicherheitsmaßnahmen sowie Cybersicherheit einschließlich des Schutzes vor unbefugtem Zugriff fest, die für den bestimmungsgemäßen Einsatz der Software erforderlich sind.“

  - b) Abschnitt 20.1 wird wie folgt geändert:

    - i) Absatz 1 Satz 2 erhält folgende Fassung:

        „Diese Angaben können auf dem Produkt selbst, auf der Verpackung oder in der Gebrauchsanweisung erscheinen, wobei Folgendes zu berücksichtigen ist:“

    - ii) In Buchstabe c wird der folgende Satz angefügt:

        „Kennzeichnungen können in digitaler Form in dem Umfang und nur unter den Bedingungen, die in gemäß dieser Verordnung erlassenen Durchführungsrechtsakten festgelegt sind, bereitgestellt werden.“

    - iii) Buchstabe e erhält folgende Fassung:

      - „e) Werden mehrere Produkte an einen einzigen Anwender und/oder Ort geliefert, so kann eine einzige Ausfertigung der Gebrauchsanweisung beigefügt werden, wenn dies mit dem Käufer, welcher in jedem Fall kostenlos weitere Exemplare anfordern kann, so vereinbart wurde.“

    - iv) Buchstabe f erhält folgende Fassung:

      - „f) Wenn das Produkt lediglich für den beruflichen Gebrauch bestimmt ist, kann die Gebrauchsanweisung dem Anwender in anderer Form als in Papierform (z. B. elektronisch) bereitgestellt werden.“

    - v) Folgender Buchstabe k wird angefügt:

      - „k) Für Produkte, die gemäß Artikel 19 des [Vorschlags für eine Richtlinie über den Unionskodex für Humanarzneimittel und zur Aufhebung der Richtlinie 2011/83/EG und der Richtlinie 2009/35/EG] ausschließlich zusammen mit einem Arzneimittel verwendet wird und gemeinsam mit einem Arzneimittel verpackt ist, kann die Gebrauchsanweisung, sofern erforderlich, als Bestandteil der gemeinsamen Verpackung des Arzneimittels und des Produkts beigefügt werden. Darüber hinaus können die Angaben auf der Kennzeichnung des Produkts auf die in Abschnitt 20.2 Buchstaben a und c genannten Angaben beschränkt werden, sofern nach Zustimmung der für die Genehmigung des Arzneimittels zuständigen Behörde die folgenden Bedingungen erfüllt sind:

        - i) Die für die sichere Verwendung und das ordnungsgemäße Funktionieren des Produkts erforderlichen Informationen werden dem Anwender zusammen mit der Zusammenfassung der Merkmale des Arzneimittels und/oder der Packungsbeilage des Arzneimittels unter der Verantwortung des in dem [Vorschlag für eine Richtlinie über den Unionskodex für Humanarzneimittel und zur Aufhebung der Richtlinie 2011/83/EG und der Richtlinie 2009/35/EG] genannten Zulassungsinhabers bereitgestellt.

        - ii) Die Rückverfolgbarkeit und Identifizierung des Produkts werden durch den Zulassungsinhaber sichergestellt.“

  - c) Abschnitt 20.2 wird wie folgt geändert:

    - i) Buchstabe e erhält folgende Fassung:

      - „e) einen Hinweis, dass es sich bei dem Produkt um ein In-vitro-Diagnostikum oder um ein Zubehör eines In-vitro-Diagnostikums handelt, oder, wenn es sich bei dem Produkt um ein ‚Produkt für Leistungsstudien‘ handelt, einen Hinweis auf diesen Sachverhalt;“

    - ii) Buchstabe j erhält folgende Fassung:

      - „j) (betrifft nicht die deutsche Fassung)

    - iii) Buchstabe r erhält folgende Fassung:

      - „r) (betrifft nicht die deutsche Fassung)

  - d) Abschnitt 20.4.1 wird wie folgt geändert:

    - i) Buchstabe c Ziffer viii erhält folgende Fassung:

      - „viii) bei therapiebegleitenden Diagnostika den bzw. die internationalen Freinamen (INN) oder eine Beschreibung der spezifischen Gruppe des bzw. der zugehörigen Arzneimittel(s), für das bzw. die es sich um ein therapiebegleitendes Diagnostikum handelt;“

    - ii) Buchstabe d erhält folgende Fassung:

      - „d) einen Hinweis, dass es sich bei dem Produkt um ein In-vitro-Diagnostikum oder um ein Zubehör eines In-vitro-Diagnostikums handelt, oder, wenn es sich bei dem Produkt um ein ‚Produkt für Leistungsstudien‘ handelt, einen Hinweis auf diesen Sachverhalt;“

    - iii) Buchstabe h erhält folgende Fassung:

      - „h) eine Beschreibung der Reagenzien sowie etwaige Einschränkungen ihres Gebrauchs (z. B. ausschließliche Eignung für Spezialinstrumente) und die Zusammensetzung des Reagenzprodukts nach Art und Menge oder Konzentration des kritischen Bestandteils bzw. der kritischen Bestandteile des Reagenz bzw. der Reagenzien oder des Kits sowie gegebenenfalls einen Hinweis darauf, dass das Produkt noch weitere Inhaltsstoffe enthält, die die Messung beeinflussen könnten;“

    - iv) Buchstabe w erhält folgende Fassung:

      - „w) Merkmale der Analyseleistung und der klinischen Leistung gemäß Abschnitt 9.1 Buchstaben a und b;“

    - v) Buchstabe x wird gestrichen.

    - vi) Buchstabe z erhält folgende Fassung:

      - „z) Informationen über die Anwendung verfügbarer Referenzmessverfahren und -materialien durch den Anwender;“

    - vii) Buchstabe ae erhält folgende Fassung:

      - „ae) Ausstellungsdatum der Gebrauchsanweisung oder, falls diese überarbeitet wurde, Ausstellungsdatum und Kennnummer der neuesten Fassung der Gebrauchsanweisung;“

- 2. Anhang II wird wie folgt geändert:

  - a) Abschnitt 1.1 wird wie folgt geändert:

    - i) Buchstabe c erhält folgende Fassung:

      - „c) die Zweckbestimmung des Produkts gemäß Abschnitt 20.4.1 Buchstabe c des Anhangs I;“

    - ii) Buchstabe g erhält folgende Fassung:

      - „g) eine Beschreibung der Komponenten und gegebenenfalls der kritischen Inhaltsstoffe relevanter Komponenten wie Antikörper, Antigene, Enzyme und Nukleinsäureprimer;“

  - b) Abschnitt 3.1 Buchstabe a erhält folgende Fassung:

    - „a) gegebenenfalls eine Beschreibung der kritischen Reagenzien wie Antikörper, Antigene, Enzyme und Nukleinsäureprimer, die nicht zur Verfügung gestellt, aber für die Verwendung mit dem Produkt empfohlen werden;“

  - c) Abschnitt 6.1.2.6 Buchstabe c erhält folgende Fassung:

    - „c) statistische Methoden wie Grenzwertoptimierungskurve (Receiver Operating Characteristic, ROC) zur Berechnung von Ergebnissen und gegebenenfalls zur Bestimmung der Grauzone/mehrdeutigen Zone.“

  - d) Abschnitt 6.1.3 wird gestrichen.

  - e) In Abschnitt 6.2 erhalten die Überschrift und Absatz 1 folgende Fassung:

    - „6.2. Informationen zur Gesamtleistungsbewertung und zu klinischen Studien

        Die Dokumentation enthält den Leistungsbewertungsplan gemäß Anhang XIII Abschnitt 1.1 und den Bericht über die Leistungsbewertung gemäß Anhang XIII Abschnitt 1.3.2.“

  - f) In Abschnitt 6.5 wird folgender Buchstabe e angefügt:

    - „e) Enthält das Produkt als integralen Bestandteil ein Medizinprodukt, dessen Wirkung derjenigen des Produkts im Sinne des Artikels 1 Absatz 4 dieser Verordnung untergeordnet ist, so umfasst die Dokumentation die Ergebnisse der Bewertung der Konformität des Medizinprodukts mit den einschlägigen allgemeinen Sicherheits- und Leistungsanforderungen gemäß Anhang I der Verordnung (EU) 2017/745, wie sie in der EU-Konformitätserklärung des Herstellers oder in der einschlägigen, von einer Benannten Stelle ausgestellten Bescheinigung enthalten sind, die den Hersteller zur Anbringung der CE-Kennzeichnung an dem Medizinprodukt berechtigt. Liegen diese Ergebnisse der Konformitätsbewertung nicht vor und ist für die Konformitätsbewertung des Medizinprodukts, sofern es gesondert verwendet wird, gemäß der Verordnung (EU) 2017/745 die Beteiligung einer Benannten Stelle erforderlich, so ist der Dokumentation eine Stellungnahme zur Konformität des Medizinprodukts mit den einschlägigen allgemeinen Sicherheits- und Leistungsanforderungen gemäß Anhang I der Verordnung (EU) 2017/745 beizufügen, die von einer nach dieser Verordnung für den betreffenden Produkttyp Benannten Stelle ausgestellt wurde.“

- 3) Anhang III wird wie folgt geändert:

  - a) Abschnitt 1 Buchstabe a sechster Gedankenstrich erhält folgende Fassung:

    - – „öffentlich zugängliche Informationen über ähnliche Produkte.“

  - b) Abschnitt 2 erhält folgende Fassung:

    - „2. Den Sicherheitsbericht gemäß Artikel 81 oder den Bericht über die Überwachung nach dem Inverkehrbringen gemäß Artikel 80.“

- 4) Anhang VI wird wie folgt geändert:

  - a) Die Teile A und B erhalten folgende Fassung:

„TEIL A

BEI DER REGISTRIERUNG VON WIRTSCHAFTSAKTEUREN GEMÄẞ ARTIKEL 28 VORZULEGENDE INFORMATIONEN

      Die Hersteller und gegebenenfalls ihre Bevollmächtigten sowie gegebenenfalls die Importeure übermitteln die folgenden Informationen über den Wirtschaftsakteur:

    - 1. Art des Wirtschaftsakteurs (Hersteller, Bevollmächtigter oder Importeur),

    - 2. Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, des Wirtschaftsakteurs,

    - 3. falls die Informationen von einer anderen Person im Namen eines der in Abschnitt 1.1 aufgeführten Wirtschaftsakteure eingereicht werden, Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, dieser Person,

    - 4. Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, der für die Einhaltung der Regulierungsvorschriften zuständigen Person(en) gemäß Artikel 15.

<a id="part-b"></a>
## Teil B

IN DIE UDI-DATENBANK ZUSAMMEN MIT DER UDI-DI GEMÄẞ DEN ARTIKELN 25 UND 26 EINZUGEBENDE ZENTRALE DATENELEMENTE

      Der Hersteller gibt in die UDI-Datenbank die folgenden Informationen zum Hersteller und zum Produkt ein:

    - 1. Basis-UDI-DI gemäß Artikel 24 und alle zusätzlichen UDI-DI,

    - 2. Für die in Artikel 110 Absatz 3 genannten Produkte Art, Nummer und Ablaufdatum der von der Benannten Stelle ausgestellten Bescheinigung und Name oder Kennnummer dieser Benannten Stelle sowie Link zu den Informationen auf der Bescheinigung, die die Benannte Stelle in das elektronische System für Benannte Stellen und Bescheinigungen eingegeben hat,

  - 3. Mitgliedstaat, in dem das Produkt in der Union in Verkehr gebracht werden soll bzw. gebracht wurde,

    - 4. Mitgliedstaaten, in denen das Produkt verfügbar ist bzw. verfügbar gemacht werden soll,

    - 5. Vorhandensein von Substanzen menschlichen Ursprungs oder ihren Derivaten (j/n),

    - 6. Vorhandensein von Zellen oder Stoffen mikrobiellen Ursprungs (j/n),

    - 7. Risikoklasse des Produkts,

    - 8. gegebenenfalls die einmalige Kennnummer der Leistungsstudie,

    - 9. bei Produkten, die von einer anderen in Artikel 10 Absatz 14 aufgeführten juristischen oder natürlichen Person ausgelegt und hergestellt wurden: Name, Anschrift und Kontaktdaten, einschließlich der digitalen Kontaktdaten, dieser juristischen oder natürlichen Person,

    - 10. gegebenenfalls der Kurzbericht über Sicherheit und Leistung,

    - 11. Marktstatus des Produkts (auf den Markt gebracht, nicht mehr auf dem Markt, zurückgerufen, Sicherheitskorrekturmaßnahmen im Feld eingeleitet),

    - 12. Angabe, ob das Produkt für die Eigenanwendung oder für patientennahe Tests vorgesehen ist.

    - 13. Menge pro Packung,

    - 14. Art der Kontrolle der Herstellung des Produkts (Verfallsdatum oder Herstellungsdatum, Losnummer, Seriennummer),

    - 15. gegebenenfalls die UDI-DI der Gebrauchseinheit (falls auf dem Produkt auf der Ebene der Gebrauchseinheit keine UDI angegeben ist, wird eine ‚Gebrauchseinheit-UDI-DI‘ zugeteilt, um die Verwendung eines Produkts einem Patienten zuzuordnen),

    - 16. Name und Anschrift des Herstellers, wie auf der Kennzeichnung angegeben,

    - 17. die SRN gemäß Artikel 28 Absatz 2,

    - 18. gegebenenfalls Name und Anschrift des Bevollmächtigten (wie auf der Kennzeichnung angegeben),

    - 19. den Code in der Nomenklatur für Medizinprodukte gemäß Artikel 23,

    - 20. gegebenenfalls Name oder Handelsname und gegebenenfalls weitere Handelsnamen,

    - 21. gegebenenfalls Modell-, Referenz- oder Katalognummer des Produkts,

    - 22. zusätzliche Produktbeschreibung (fakultativ),

    - 23. gegebenenfalls Lagerungs- und/oder Handhabungshinweise (wie auf der Kennzeichnung oder in der Gebrauchsanweisung angegeben),

    - 24. Angabe, ob das Produkt zum Einmalgebrauch ausgewiesen wurde (j/n),

    - 25. gegebenenfalls Höchstzahl der Wiederverwendungen,

    - 26. als steril ausgewiesenes Produkt (j/n),

    - 27. Sterilisation vor Verwendung erforderlich (j/n),

    - 28. gegebenenfalls die Gebrauchsanweisung oder, soweit verfügbar, die URL der Website, auf der die Gebrauchsanweisung zur Verfügung gestellt wird,

    - 29. gegebenenfalls wichtige Warnhinweise oder Kontraindikationen.“

  - b) Teil C wird wie folgt geändert:

    - i) In Abschnitt 1 erhält die Begriffsbestimmung von „Basis-UDI-DI“ folgende Fassung:

        „Basis-UDI-DI

        Die Basis-UDI-DI ist die primäre Kennung eines Produktmodells. Die Basis-UDI-DI ist der wichtigste Schlüssel in der Datenbank und den einschlägigen Unterlagen (z. B. Bescheinigungen, Konformitätserklärung, technische Dokumentation und Kurzbericht über Sicherheit und Leistung), um Produkte mit derselben Zweckbestimmung, Risikoklasse und denselben wesentlichen Auslegungs- und Herstellungsmerkmalen miteinander zu verbinden. Sie ist das wichtigste Ordnungsmerkmal für Datensätze in der UDI-Datenbank und ist in den einschlägigen Bescheinigungen und EU-Konformitätserklärungen ausgewiesen.“

    - ii) Abschnitt 4.10 erhält folgende Fassung:

      - „4.10. Wiederverwendbare Produkte tragen den UDI-Träger auf dem Produkt selbst. Der UDI-Träger für wiederverwendbare Produkte, bei denen zwischen den Anwendungen am Patienten eine Desinfektion, Sterilisation oder Aufbereitung erforderlich ist, muss dauerhaft angebracht und nach jedem Verfahren, das zur Vorbereitung des Produkts für die nachfolgende Verwendung durchgeführt wird, während der gesamten erwarteten Lebensdauer des Produkts lesbar sein, es sei denn, das Produkt ist dazu bestimmt, ausschließlich von oder für denselben Patienten wiederverwendet zu werden. Die Anforderung dieses Abschnitts gilt nicht für Produkte, auf die einer der folgenden Umstände zutrifft:

        - a) Jegliche Art von direkter Kennzeichnung würde die Sicherheit oder Leistung des Produkts beeinträchtigen;

        - b) das Produkt kann nicht direkt gekennzeichnet werden, weil dies technisch nicht möglich ist.“

- 5. Anhang VII wird wie folgt geändert:

  - a) In Abschnitt 1.1.1 wird folgender Satz angefügt:

      „Die Unterlagen enthalten außerdem Angaben zur übergeordneten Organisation, der die Benannte Stelle angehört.“

  - b) Abschnitt 1.1.2 erhält folgende Fassung:

    - „1.1.2. Handelt es sich bei der Benannten Stelle um eine juristische Person, die Teil einer größeren Einrichtung ist, so sind die Tätigkeiten dieser Einrichtung sowie ihre Organisations- und Leitungsstruktur und ihr Verhältnis zu der Benannten Stelle eindeutig zu dokumentieren. In diesen Fällen gelten die in Abschnitt 1.2 festgelegten Anforderungen sowohl für die Benannte Stelle als auch für die größere Einrichtung, zu der sie gehört. Die größere Einrichtung und alle zu ihr gehörenden juristischen Personen dürfen weder an der Auslegung, Herstellung, Vermarktung, Installation oder Wartung der Produkte, für die die Benannte Stelle benannt ist, beteiligt sein noch Beratungsleistungen für diese Tätigkeiten anbieten. Sie dürfen die an diesen Tätigkeiten beteiligten Parteien nicht vertreten.“

  - c) Abschnitt 1.1.5 erhält folgende Fassung:

    - „1.1.5. Die Organisationsstruktur und die Funktionen, Zuständigkeiten und Befugnisse ihrer obersten Leitungsebene und anderer Mitarbeiter mit möglichem Einfluss auf die Leistung der Benannten Stelle sowie auf die Ergebnisse ihrer Konformitätsbewertungstätigkeiten sind von der Benannten Stelle klar zu dokumentieren.“

  - d) In Abschnitt 1.2.9 wird folgender Satz angefügt:

      „Die Benannte Stelle verfügt über dokumentierte Verfahren, um Dialoge mit dem Hersteller vor und nach Einreichung eines Antrags auf Konformitätsbewertung anzubieten und durchzuführen.“

  - e) Abschnitt 1.3.1 erhält folgende Fassung:

    - „1.3.1. Die Benannte Stelle gewährleistet durch dokumentierte Verfahren, dass ihre Mitarbeiter, Ausschüsse, Zweigstellen, Niederlassungen, Unterauftragnehmer sowie alle zugeordneten Stellen oder Mitarbeiter externer Einrichtungen die Vertraulichkeit der Informationen, die bei der Durchführung der Konformitätsbewertungstätigkeiten in ihren Besitz gelangen, wahren, außer wenn die Offenlegung gesetzlich vorgeschrieben ist.“

  - f) Abschnitt 1.4.2 Satz 2 wird gestrichen.

  - g) Folgender Abschnitt 1.4.3. wird angefügt:

    - „1.4.3. Abweichend von Abschnitt 1.4.1 kann die Benannte Stelle den Nachweis der Deckung ihrer Haftung durch den Beitritt zu einem Garantiefonds erbringen, der einen wirksamen Schutz gewährleistet und von dem bzw. den betreffenden Mitgliedstaat(en) anerkannt ist.“

  - h) Abschnitt 1.6.1 erhält folgende Fassung:

    - „1.6.1. Die Benannte Stelle wirkt an allen Aktivitäten der Koordinierungsgruppe Benannter Stellen gemäß Artikel 49 der Verordnung (EU) 2017/745 mit und stellt sicher, dass ihr und ihre Entscheidungsträger von allen im Rahmen dieser Verordnung angenommenen einschlägigen Rechtsvorschriften, Normen, Leitlinien und Dokumenten über vorbildliche Verfahren Kenntnis erhalten.“

  - i) Abschnitt 2.1 erhält folgende Fassung:

    - „2.1. Das von der Benannten Stelle eingerichtete, dokumentierte, umgesetzte, aufrechterhaltene und betriebene Qualitätsmanagementsystem ist für die Art, den Bereich und den Umfang ihrer Konformitätsbewertungstätigkeiten geeignet und ermöglicht es, auf die wirksamste Weise eine dauerhafte Erfüllung der in dieser Verordnung beschriebenen Anforderungen zu unterstützen und aufzuzeigen.“

  - j) Abschnitt 2.3 erhält folgende Fassung:

    - „2.3. Die oberste Leitungsebene der Benannten Stelle stellt sicher, dass das Qualitätsmanagementsystem in der gesamten Organisation der Benannten Stelle vollständig verstanden, umgesetzt und aufrechterhalten wird, was auch für ihre Zweigstellen, Niederlassungen und Unterauftragnehmer, die an Konformitätsbewertungstätigkeiten gemäß dieser Verordnung beteiligt sind, gilt.“

  - k) Abschnitt 3.2.3 wird wie folgt geändert:

    - i) Satz 1 erhält folgende Fassung:

        „Das für die Festlegung der Qualifikationskriterien und die Zulassung anderer Mitarbeiter zur Durchführung spezifischer Konformitätsbewertungstätigkeiten zuständige Personal wird nicht als externe Sachverständige oder über einen Unterauftrag beschäftigt.“

    - ii) Absatz 2 sechster Gedankenstrich erhält folgende Fassung:

      - – „einschlägige Erfahrung in Bezug auf Konformitätsbewertungen nach Maßgabe dieser Verordnung, der Verordnung (EU) 2017/745 oder vorher gültiger Rechtsvorschriften in einer Benannten Stelle.“

  - l) Abschnitt 3.2.4 Satz 1 erhält folgende Fassung:

      „Der Benannten Stelle steht permanent Personal mit einschlägiger klinischer Erfahrung zur Verfügung.“

  - m) Abschnitt 3.2.7 Satz 1 erhält folgende Fassung:

      „Die für die abschließenden Prüfungen und die Entscheidung über die Zertifizierung gesamtverantwortlichen Personen sind keine externen Sachverständigen oder Unterauftragnehmer.“

  - n) In Abschnitt 3.4.1 Absatz 1 wird folgender Satz angefügt:

      „Sie unterrichten den Hersteller entsprechend.“

  - o) Abschnitt 4.1 Absatz 2 erhält folgende Fassung:

      „Die in den Abschnitten 4.3, 4.4, 4.7 und 4.8 festgelegten Anforderungen dürfen nicht an externe Sachverständige vergeben werden und dürfen nicht von externen Sachverständigen erfüllt werden.“

  - p) Abschnitt 4.2 Buchstabe a Satz 2 erhält folgende Fassung:

      „In dieser Beschreibung wird angegeben, welche Sprachen für das Einreichen von Dokumenten und für diesbezügliche Korrespondenz zulässig sind, sowie die Modalitäten für die Durchführung des Dialogs gemäß Abschnitt 1.2.9 dieses Anhangs vor der Antragstellung.“

  - q) Abschnitt 4.3 Absatz 2 Satz 3 erhält folgende Fassung:

      „Dieser Vertrag legt eindeutige Geschäftsbedingungen fest und enthält Verpflichtungen, die es der Benannten Stelle ermöglichen, gemäß den Anforderungen dieser Verordnung zu handeln, einschließlich der Verpflichtung des Herstellers, die Benannte Stelle über Vigilanz-Berichte zu benachrichtigen, des Rechts der Benannten Stelle, ausgestellte Bescheinigungen auszusetzen, zu beschränken oder zu widerrufen und der Pflicht der Benannten Stelle, ihren Informationspflichten nachzukommen.“

  - r) Abschnitt 4.5.1 Absatz 2 wird wie folgt geändert:

    - i) Der achte Gedankenstrich erhält folgende Fassung:

      - – „bei Produkten der Klassen B oder C die Bewertung der technischen Dokumentation des repräsentativen Produkts bzw. der repräsentativen Produkte,“

    - ii) Der zehnte Gedankenstrich wird gestrichen.

    - iii) Folgende Gedankenstriche werden angefügt:

      - – gegebenenfalls die Durchführung einer fortlaufenden Überprüfung der Daten oder Unterlagen des Herstellers, sobald diese verfügbar werden,

      - – die Nutzung von Nachweisen aus zuvor durchgeführten Bewertungen.“

  - s) Abschnitt 4.5.2 wird wie folgt geändert:

    - i) Buchstabe a wird wie folgt geändert:

      - 1. Der einleitende Teil erhält folgende Fassung:

          „Eine Benannte Stelle ist vor oder im Zusammenhang mit dem Audit und im Einklang mit ihren dokumentierten Verfahren für folgende Aufgaben als Teil der Bewertung des Qualitätsmanagementsystems zuständig:“

      - 2. Der vierte Gedankenstrich erhält folgende Fassung:

        - – “eindeutige Bestimmung der für die Bewertung der technischen Dokumentation gemäß den Anhängen II und II ausgewählten repräsentativen Produkte der Klassen B und C, sowie“

    - ii) in Buchstabe b erhält der vierte Gedankenstrich folgende Fassung:

      - – „Stichproben der Dokumentation werden in einer Weise genommen, dass die mit der bestimmungsgemäßen Verwendung des Produkts verbundenen Risiken, die Komplexität der Fertigungstechnologien, die Bandbreite und die Klassen der hergestellten oder zertifizierten Produkte und alle verfügbaren Informationen zur Überwachung nach dem Inverkehrbringen aufgezeigt werden,“

  - t) In Abschnitt 4.5.3 erhält der dritte Absatz mit der Überschrift „Prüfung durch Untersuchung und Erprobung jeder einzelnen Produktcharge“ folgende Fassung:

      „Prüfung durch Untersuchung und Erprobung von Produkten oder Produktchargen

      Die Benannten Stellen

    - a) verfügen über dokumentierte Verfahren, ausreichendes Fachwissen und Zugang zu Einrichtungen für die Prüfung durch Untersuchung und Erprobung von Produkten oder Produktchargen;

    - b) erstellen einen Prüfungsplan, in dem alle relevanten und kritischen Parameter aufgeführt werden, die unter der Verantwortung der Benannten Stellen geprüft werden müssen und dokumentieren ihre Begründung für die Auswahl der Parameter;

    - c) verfügen über dokumentierte Verfahren zur Durchführung der geeigneten Bewertungen und Prüfungen, um die Konformität des Produkts mit den Anforderungen dieser Verordnung zu überprüfen, gegebenenfalls einschließlich Verfahren in Bezug auf Prüfungen durch EU-Referenzlaboratorien gemäß den Anhängen IX, X und XI;

    - d) verfügen über dokumentierte Verfahren, um mit dem Antragsteller eine Einigung über Zeit und Ort der Durchführung der erforderlichen Prüfungen, die nicht von der Benannten Stelle selbst durchgeführt werden müssen, zu erzielen,

    - e) übernehmen gemäß den dokumentierten Verfahren die volle Verantwortung für die Prüfungsergebnisse, es sei denn, die Prüfungen wurden von EU-Referenzlaboratorien gemäß den Anhängen IX, X oder XI dieser Verordnung durchgeführt; vom Hersteller vorgelegte Prüfberichte werden nur berücksichtigt, wenn sie von kompetenten und vom Hersteller unabhängigen Konformitätsbewertungsstellen herausgegeben wurden.“

  - u) In Abschnitt 4.6 Absatz 2 erhält der einleitende Satz folgende Fassung:

      „Der Bericht bzw. die Berichte der Benannten Stelle“

  - v) Abschnitt 4.8 wird wie folgt geändert:

    - i) Satz 1 erhält folgende Fassung:

        „Die Benannten Stellen verfügen über dokumentierte Verfahren für die Entscheidungsfindung, unter anderem in Bezug auf die Zuteilung von Zuständigkeiten für die Erteilung, Aussetzung, Beschränkung und den Widerruf von Bescheinigungen.“

    - ii) Satz 3 wird wie folgt geändert:

      - 1. Der vierte Gedankenstrich erhält folgende Fassung:

        - – „zu entscheiden, ob bestimmte Bedingungen oder Beschränkungen für die Zertifizierung festgelegt werden müssen,“

      - 2. Der fünfte Gedankenstrich erhält folgende Fassung:

        - – „gegebenenfalls auf der Grundlage der Neuartigkeit, der Risikoklassifizierung, der Leistungsbewertung und der Schlussfolgerungen der Risikoanalyse des Produkts über die Geltungsdauer der Zertifizierung zu entscheiden,“

      - 3. Der achte Gedankenstrich erhält folgende Fassung:

        - – „eine Bescheinigung bzw. Bescheinigungen gemäß den in Anhang XII festgelegten Mindestanforderungen auszustellen und darin anzugeben, ob mit der Bescheinigung Bedingungen oder Einschränkungen verbunden sind,“

  - w) Abschnitt 4.9 wird wie folgt geändert:

    - i) Absatz 1 vierter Gedankenstrich erhält folgende Fassung:

      - – „der bestimmungsgemäßen Verwendung des Produkts oder den für das Produkt geltend gemachten Ansprüchen.“

    - ii) Absatz 2 erhält folgende Fassung:

        „Die im ersten Absatz genannten Verfahren und vertraglichen Vereinbarungen unterscheiden eindeutig zwischen Änderungen, die nicht gemeldet werden müssen, solchen, die ohne vorherige Genehmigung gemeldet werden müssen, und solchen, die einer vorherigen Genehmigung bedürfen.“

    - iii) Absatz 3 wird wie folgt geändert:

      - 1. Der einleitende Satz erhält folgende Fassung:

          „Im Einklang mit ihren dokumentierten Verfahren hat die betreffende Benannte Stelle, sofern Änderungen einer vorherigen Genehmigung bedürfen, folgende Aufgaben:“

      - 2. Folgender Absatz 4 wird angefügt:

          „Gegebenenfalls vereinbaren die Benannte Stelle und der Hersteller einen vorab festgelegten Änderungssteuerungsplan, der es dem Hersteller ermöglicht, Änderungen gemäß einem solchen Plan ohne vorherige Unterrichtung umzusetzen.“

  - x) Abschnitt 4.10 wird wie folgt geändert:

    - i) Absatz 1 wird wie folgt geändert:

      - 1. Der zweite Gedankenstrich erhält folgende Fassung:

        - – „die Prüfung einschlägiger Quellen wissenschaftlicher und klinischer Daten sowie Informationen nach dem Inverkehrbringen in dem Bereich, für den sie benannt wurden. Dieses Screening wird im Rahmen der in Artikel 49 eingesetzten Koordinierungsgruppe durchgeführt, um unnötige Doppelarbeit zu vermeiden und die Effizienz sowie die Arbeitsteilung zu verbessern. Die Ergebnisse des Screenings werden bei der Planung und Durchführung von Überwachungstätigkeiten berücksichtigt,“

      - 2. Satz 1 des dritten Gedankenstrichs erhält folgende Fassung:

        - – „um zu beurteilen, ob ein gemeldetes schwerwiegendes Vorkommnis im Zusammenhang mit einer schwerwiegenden Gefahr für die öffentliche Gesundheit oder eine vom Hersteller ergriffene oder in Erwägung gezogene Sicherheitskorrekturmaßnahme im Feld oder eine von einer zuständigen Behörde vom Hersteller verlangte Maßnahme Auswirkungen auf die Gültigkeit bestehender Bescheinigungen hat. Die Ergebnisse der Bewertung und alle getroffenen Entscheidungen werden gründlich dokumentiert.“

    - ii) Absatz 2 wird wie folgt geändert:

      - 1. Der einleitende Satz erhält folgende Fassung:

          „Die betreffende Benannte Stelle entscheidet im Hinblick auf Signale aus Vigilanzdaten, zu denen sie gemäß Artikel 87 Absatz 2 Zugang hat, gegebenenfalls, welche der folgenden Optionen anzuwenden ist:“

      - 2. Der erste Gedankenstrich wird gestrichen.

    - iii) Absatz 3 wird wie folgt geändert:

      - 1. Der erste Gedankenstrich erhält folgende Fassung:

        - – „Audits zur Überwachung des Herstellers durchzuführen, die gemäß den relevanten Anforderungen in Abschnitt 4.5 geplant und durchgeführt werden“;

      - 2. Der achte Gedankenstrich erhält folgende Fassung:

        - – „bei Bedarf Bedingungen oder Beschränkungen in Bezug auf die einschlägige Bescheinigung vorzusehen oder diese Bescheinigung auszusetzen oder zu widerrufen.“

  - y) Abschnitt 4.11 erhält folgende Fassung:

      „Regelmäßige Überprüfungen und Verlängerung der Geltungsdauer einer Bescheinigung

      Die Benannte Stelle verfügt über dokumentierte Verfahren für die regelmäßige Überprüfung der genehmigten Qualitätsmanagementsysteme oder von EU-Bescheinigungen über die Bewertung der technischen Dokumentation oder EU-Baumusterprüfbescheinigungen.

      Diese Verfahren verpflichten den betreffenden Hersteller, in festgelegten Abständen eine Zusammenfassung der Änderungen sowie der einschlägigen Daten vorzulegen, die im Rahmen des Systems des Herstellers zur Überwachung nach dem Inverkehrbringen erhoben wurden. Die Benannte Stelle bewertet diese Informationen und schenkt dabei insbesondere klinischen Daten aus der Überwachung nach dem Inverkehrbringen sowie den seit der vorherigen Zertifizierung oder regelmäßigen Überprüfung durchgeführten Tätigkeiten der klinischen Nachbeobachtung nach dem Inverkehrbringen besondere Aufmerksamkeit, einschließlich geeigneter Aktualisierungen der Leistungsbewertungsberichte der Hersteller, ohne bereits durchgeführte Bewertungen zu wiederholen.

      Die Benannte Stelle verfügt über dokumentierte Verfahren für die Verlängerung der Geltungsdauer einer Bescheinigung in Fällen, in denen sie die Geltungsdauer ausnahmsweise beschränkt hat. Diese Verfahren verpflichten den Hersteller, vor Ablauf der Bescheinigung die von der Benannten Stelle festgelegten Daten oder Unterlagen vorzulegen, damit diese über die Verlängerung der Geltungsdauer der Bescheinigung entscheiden kann.“

- 6) Anhang IX wird wie folgt geändert:

  - a) Abschnitt 2.3 Absätze 3 und 4 erhalten folgende Fassung:

      „Darüber hinaus wird bei Produkten der Klassen B und C die Bewertung des Qualitätsmanagementsystems von der Bewertung der technischen Dokumentation gemäß den Anhängen II und III begleitet, wie in den Abschnitten 4.3 bis 4.8 für ein wie folgt ausgewähltes repräsentatives Produkt festgelegt:

    - – bei Produkten der Klasse B ein Produkt;

    - – bei Produkten der Klasse C ein Produkt pro generischer Produktgruppe.

      Bei der Auswahl des repräsentativen Produkts wendet die Benannte Stelle einen risikobasierten Ansatz unter Berücksichtigung des Grundsatzes der Verhältnismäßigkeit an und berücksichtigt insbesondere den Grad der Neuartigkeit der Technologie, den Grad der Neuartigkeit des nachzuweisenden Analyten und/oder Markers, die potenziellen Auswirkungen auf den Patienten und die medizinische Standardpraxis, Ähnlichkeiten in Bezug auf Auslegung, Technologie sowie Herstellungs- und gegebenenfalls Sterilisationsverfahren, die Zweckbestimmung, die Anwendung harmonisierter Normen oder Gemeinsamer Spezifikationen (GS) durch den Hersteller für das Produkt sowie die Ergebnisse etwaiger früherer einschlägiger Bewertungen, die gemäß dieser Verordnung durchgeführt wurden. Die betreffende Benannte Stelle dokumentiert ihre Begründung für das gewählte repräsentative Produkt.

      Die Benannte Stelle kann in hinreichend begründeten Fällen, die im Rahmen der Bewertung des Qualitätsmanagementsystems festgestellt wurden, eine anlassbezogene Bewertung der technischen Dokumentation zusätzlicher repräsentativer Produkte vornehmen.

      Falls das Qualitätsmanagementsystem sowie die technische Dokumentation des bewerteten repräsentativen Produkts den einschlägigen Bestimmungen dieser Verordnung entspricht, stellt die Benannte Stelle eine EU-Qualitätsmanagementbescheinigung aus. Die Benannte Stelle teilt dem Hersteller ihre Entscheidung zur Ausstellung einer Bescheinigung mit. Die Entscheidung enthält auch die Ergebnisse des Audits und einen mit Gründen versehenen Bericht.“

  - b) In Abschnitt 3.2 erhält der zweite Gedankenstrich folgende Fassung:

    - – „die Dokumentation über alle Erkenntnisse und Ergebnisse, die bei der Anwendung des Plans zur Überwachung nach dem Inverkehrbringen einschließlich des Plans für die klinische Nachbeobachtung nach dem Inverkehrbringen bei den repräsentativen Produkten und der in den Artikeln 82 bis 87 festgelegten Vigilanz-Bestimmungen gewonnen wurden,“

  - c) Abschnitt 3.3 erhält folgende Fassung:

    - „3.3. Die Benannten Stellen führen regelmäßig geeignete Audits und Bewertungen durch, um sich davon zu überzeugen, dass der betreffende Hersteller das genehmigte Qualitätsmanagementsystem und den Plan zur Überwachung nach dem Inverkehrbringen anwendet. Diese Audits und Bewertungen schließen Audits in den Betriebsstätten des Herstellers und gegebenenfalls den Betriebsstätten der Zulieferer des Herstellers und/oder seiner Subunternehmer ein. In begründeten Fällen kann das Audit anstelle einer Vor-Ort-Prüfung als Fernprüfung durchgeführt werden. Die Benannte Stelle führt, soweit erforderlich, Prüfungen durch oder veranlasst solche, um zu überprüfen, ob das Qualitätsmanagementsystem ordnungsgemäß funktioniert. Die Benannte Stelle stellt dem Hersteller einen Bericht über die Überwachungsaudits und gegebenenfalls über die vorgenommenen Prüfungen zur Verfügung.

        Die Benannte Stelle führt die Überwachungsaudits und bewertungen einmal alle 12 Monate durch. Ist dies jedoch unter Berücksichtigung der Ergebnisse früherer Überwachungsaudits und bewertungen gerechtfertigt und bestehen keine Bedenken aufgrund von Daten aus der Überwachung nach dem Inverkehrbringen oder der Vigilanz, so führt die Benannte Stelle die Überwachungsaudits und bewertungen nur einmal alle 24 Monate durch.“

  - d) Abschnitt 3.4 wird wie folgt geändert:

    - i) Absatz 1 erhält folgende Fassung:

      - „3.4. Die Benannte Stelle führt Audits, kurzfristig angekündigt oder unangekündigt, am Standort des Herstellers und, soweit erforderlich, am Standort von dessen Lieferanten und/oder Unterauftragnehmern durch, sofern dies aufgrund von Bedenken im Zusammenhang mit Daten aus der Überwachung nach dem Inverkehrbringen oder der Vigilanz gerechtfertigt ist oder auf Antrag einer zuständigen Behörde erfolgt. Das kurzfristig angekündigte oder unangekündigte Audit kann mit der in Abschnitt 3.3 genannten regelmäßigen Überwachungsbewertung kombiniert oder zusätzlich zu dieser Überwachungsbewertung durchgeführt werden.“

    - ii) Absatz 2 Satz 1 erhält folgende Fassung:

        „Im Rahmen solcher unangekündigten Vor-Ort-Audits kann die Benannte Stelle eine angemessene Stichprobe der hergestellten Produkte oder eine angemessene Stichprobe aus dem Herstellungsprozess prüfen, um festzustellen, ob das hergestellte Produkt mit der technischen Dokumentation übereinstimmt.“

    - iii) Absatz 3 Satz 1 erhält folgende Fassung:

        „Anstelle von oder zusätzlich zu den Probenahmen gemäß Absatz 2 kann die Benannte Stelle Stichproben von auf dem Markt vorhandenen Produkten zusammenstellen, um zu prüfen, ob das hergestellte Produkt mit der technischen Dokumentation übereinstimmt.“

  - e) Abschnitt 3.5 erhält folgende Fassung:

    - „3.5. Bei Produkten der Klassen B und C kann die Benannte Stelle im Rahmen der Überwachungsbewertung eine anlassbezogene Bewertung der technischen Dokumentation repräsentativer Produkte einbeziehen, sofern sie auf der Grundlage von Daten aus der Überwachung nach dem Inverkehrbringen oder aus einem hinreichenden sonstigen Grund potenzielle Bedenken festgestellt hat.“

  - f) Abschnitt 3.7 erhält folgende Fassung:

    - „3.7. Stellt die Benannte Stelle Abweichungen zwischen der aus den hergestellten Produkten oder vom Markt entnommenen Stichprobe und den in der technischen Dokumentation oder der genehmigten Auslegung beschriebenen Spezifikationen fest, so setzt sie die jeweilige Bescheinigung aus, widerruft sie oder versieht sie mit Bedingungen oder Beschränkungen.“

  - g) Die Überschrift von Abschnitt 4 erhält folgende Fassung:

    - „4. Bewertung der technischen Dokumentation“

  - h) Abschnitt 4.2 Satz 2 erhält folgende Fassung:

      „Er umfasst die technischen Unterlagen gemäß den Anhängen II und III oder einen Plan für die Vorlage dieser technischen Unterlagen.“

  - i) Abschnitt 4.4 Satz 2 erhält folgende Fassung:

      „Für die Zwecke dieser Überprüfung setzt die Benannte Stelle Produktprüfer mit ausreichendem klinischen Fachwissen ein; dazu gehören auch externe klinische Experten mit unmittelbarer aktueller Erfahrung im Zusammenhang mit der klinischen Anwendung des betreffenden Produkts.“

  - j) Abschnitt 4.8 erhält folgende Fassung:

    - „4.8. Die Benannte Stelle übermittelt dem Hersteller einen Bericht über die Bewertung der technischen Dokumentation einschließlich eines Berichts über die Begutachtung der Leistungsbewertung.“

  - k) Abschnitt 4.9 wird wie folgt geändert:

    - i) Absatz 2 wird gestrichen.

    - ii) Absatz 4 erhält folgende Fassung:

        „Das wissenschaftliche Gutachten des EU-Referenzlaboratoriums sowie etwaige Aktualisierungen werden in die Dokumentation der Benannten Stelle zu dem Produkt aufgenommen. Die Benannte Stelle trägt bei ihrer Entscheidung den im wissenschaftlichen Gutachten des EU-Referenzlaboratoriums geäußerten Ansichten gebührend Rechnung. Die Benannte Stelle stellt keine Bescheinigung aus, wenn das wissenschaftliche Gutachten des EU-Referenzlaboratoriums negativ ist.“

  - l) In Abschnitt 4.10 werden die Sätze 1 und 3 gestrichen.

  - m) Abschnitt 4.12 wird wie folgt geändert:

    - i) Satz 3 erhält folgende Fassung:

        „Darüber hinaus stellt der Hersteller der Benannten Stelle die Stichproben der hergestellten Produktchargen gemäß vorher vereinbarten Bedingungen und detaillierten Vorkehrungen zur Verfügung; dies umfasst, dass der Hersteller dem EU-Referenzlaboratorium, falls ein solches Laboratorium gemäß Artikel 100 benannt wurde, Stichproben der hergestellten Produktchargen übermittelt, damit dieses entsprechende Tests durchführt.“

    - ii) Folgender Satz wird angefügt:

        „Wurde kein EU-Referenzlaboratorium gemäß Artikel 100 benannt, so können diese Vereinbarungen auch vorsehen, dass die Benannte Stelle die Überprüfung von Stichproben oder Chargen auf alternative Weise durchführt.“

  - n) Abschnitt 5.1 wird wie folgt geändert:

    - i) Die Überschrift erhält folgende Fassung:

        „Bewertung der technischen Dokumentation für Produkte der Klassen B, C und D zur Eigenanwendung“

    - ii) Buchstabe a erhält folgende Fassung:

      - „a) Der Hersteller von Produkten zur Eigenanwendung der Klassen B, C und D stellt bei der Benannten Stelle einen Antrag auf Bewertung der technischen Dokumentation.“

    - iii) Buchstabe b Ziffer iii erhält folgende Fassung:

      - „iii) Angaben, die die Eignung des Produkts im Hinblick auf die vorgesehene Eigenanwendung belegen;“

  - o) Abschnitt 5.2 wird wie folgt geändert:

    - i) Buchstabe c erhält folgende Fassung:

      - „c) Vor Ausstellung einer EU-Bescheinigung über die Bewertung der technischen Dokumentation für das therapiebegleitende Diagnostikum und auf der Grundlage des Entwurfs des Kurzberichts über Sicherheit und Leistung sowie des Entwurfs der Gebrauchsanweisung ersucht die Benannte Stelle eine der von den Mitgliedstaaten gemäß der Richtlinie 2001/83/EG benannten zuständigen Behörden oder die EMA (im Folgenden in diesem Abschnitt jeweils als „konsultierte Arzneimittelbehörde“ bezeichnet, je nachdem, welche Stelle unter diesem Buchstaben konsultiert wurde) um ein wissenschaftliches Gutachten zur Eignung der klinischen Leistung des Produkts in Verbindung mit dem betreffenden Arzneimittel. Bei der Bewertung durch die konsultierte Arzneimittelbehörde wird die von der Benannten Stelle gemäß dieser Verordnung durchzuführende Bewertung nicht wiederholt. Fällt das Arzneimittel ausschließlich in den Geltungsbereich von Anhang I der Verordnung (EG) Nr. 726/2004 des Europäischen Parlaments und des Rates*, so holt die Benannte Stelle ein Gutachten der EMA ein. Ist das betreffende Arzneimittel bereits zugelassen oder wurde ein Antrag auf seine Zulassung eingereicht, so konsultiert die Benannte Stelle die Arzneimittelbehörde, die für die Zulassung zuständig ist, oder die EMA.

    - _______________

      - * Verordnung (EG) Nr. 726/2004 des Europäischen Parlaments und des Rates vom 31. März 2004 zur Festlegung von Gemeinschaftsverfahren für die Genehmigung und Überwachung von Human- und Tierarzneimitteln und zur Errichtung einer Europäischen Arzneimittel-Agentur (ABl. L 136 vom 30.4.2004, S. 1, ELI: http://data.europa.eu/eli/reg/2004/726/oj).“

    - ii) In Buchstabe d werden nach Satz 2 folgende Sätze eingefügt:

        „Bei der Erstellung ihres Gutachtens kann die konsultierte Arzneimittelbehörde die Benannte Stelle oder den Hersteller auffordern, innerhalb einer festgelegten Frist zusätzliche für ihre Bewertung gemäß Buchstabe c erforderliche Informationen vorzulegen. Im Falle eines solchen Ersuchens wird die in diesem Absatz festgelegte Frist ausgesetzt, bis die angeforderten zusätzlichen Informationen vorgelegt worden sind.“

    - iii) In Buchstabe f erhält Satz 1 folgende Fassung:

        „Vor der Umsetzung von Änderungen, die sich auf die Leistung und/oder die Zweckbestimmung und/oder Eignung der klinischen Leistung des Produkts in Verbindung mit dem betreffenden Arzneimittel auswirken, informiert der Hersteller die Benannte Stelle über die Änderungen.“

    - iv) Folgender Buchstabe g wird angefügt:

      - „g) Die Buchstaben c bis f gelten nicht in den Fällen, in denen die folgenden Voraussetzungen erfüllt sind:

        - i) Das therapiebegleitende Diagnostikum hat dieselbe Zweckbestimmung wie ein anderes bereits mit der CE-Kennzeichnung versehenes therapiebegleitendes Diagnostikum, für das eine Arzneimittelbehörde gemäß Buchstabe d oder Anhang X Abschnitt 3 Buchstabe k ein befürwortendes Gutachten abgegeben hat.

        - ii) Der Hersteller weist eine gleichwertige Leistung im Vergleich zu dem bereits CE-gekennzeichneten therapiebegleitenden Diagnostikum nach.“

- 7. Anhang X wird wie folgt geändert:

  - a) Abschnitt 2 wird wie folgt geändert:

    - i) Der dritte Gedankenstrich erhält folgende Fassung:

      - – „bei Produkten zur Eigenanwendung: Testberichte, einschließlich der Ergebnisse von mit vorgesehenen Anwendern durchgeführten Studien und Daten, die die Eignung des Produkts im Zusammenhang mit seiner Zweckbestimmung zur Eigenanwendung belegen,“

    - ii) Der fünfte Gedankenstrich erhält folgende Fassung:

      - – „Angaben, die die Eignung des Produkts im Hinblick auf dessen Zweckbestimmung zur Eigenanwendung belegen,“

  - b) Abschnitt 3 wird wie folgt geändert:

    - i) Buchstabe c erhält folgende Fassung:

      - „c) Sie überprüft den vom Hersteller in dem Bericht über die Leistungsbewertung gemäß Anhang XIII Abschnitt 1.3.2 vorgelegten klinischen Nachweis. Für die Zwecke dieser Überprüfung setzt die Benannte Stelle Produktprüfer mit ausreichendem klinischen Fachwissen sowie externe klinische Experten mit unmittelbarer aktueller Erfahrung im Zusammenhang mit der klinischen Anwendung des betreffenden Produkts ein.“

    - ii) Buchstabe i erhält folgende Fassung:

      - „i) Sie erstellt einen EU-Baumusterprüfbericht über die Ergebnisse der nach den Buchstaben a bis g durchgeführten Bewertungen und Prüfungen, einschließlich des Berichts über die Begutachtung der Leistungsbewertung gemäß Buchstabe e.“

    - iii) Buchstabe j wird wie folgt geändert:

      - 1. Absatz 2 wird gestrichen.

      - 2. Absatz 4 erhält folgende Fassung:

          „Das wissenschaftliche Gutachten des EU-Referenzlaboratoriums sowie etwaige Aktualisierungen werden in die Dokumentation der Benannten Stelle zu dem Produkt aufgenommen. Bei ihrer Entscheidung berücksichtigt die Benannte Stelle gebührend die in dem wissenschaftlichen Gutachten des EU-Referenzlaboratoriums geäußerten Standpunkte. Die Benannte Stelle stellt keine Bescheinigung aus, wenn das wissenschaftliche Gutachten des EU-Referenzlaboratoriums negativ ist.“

    - iv) Buchstabe k erhält folgende Fassung:

      - „k) Bei therapiebegleitenden Diagnostika ersucht sie auf der Grundlage des Entwurfs des Kurzberichts über Sicherheit und Leistung sowie des Entwurfs der Gebrauchsanweisung eine der von den Mitgliedstaaten gemäß der Richtlinie 2001/83/EG benannten zuständigen Behörden oder die EMA (im Folgenden jeweils als „konsultierte Arzneimittelbehörde“ bezeichnet, je nachdem, welche Stelle unter diesem Buchstaben konsultiert wurde) um ein Gutachten bezüglich der Eignung der klinischen Leistung des Produkts in Verbindung mit dem betreffenden Arzneimittel. Bei der Bewertung durch die konsultierte Arzneimittelbehörde wird die von der Benannten Stelle gemäß dieser Verordnung durchzuführende Bewertung nicht wiederholt. Fällt das Arzneimittel ausschließlich in den Geltungsbereich des Anhangs I der Verordnung (EG) Nr. 726/2004, so konsultiert die Benannte Stelle die EMA. Ist das betreffende Arzneimittel bereits zugelassen oder wurde ein Antrag auf seine Zulassung eingereicht, so konsultiert die Benannte Stelle die zuständige Arzneimittelbehörde oder die EMA, je nachdem, welche Behörde für die Zulassung verantwortlich ist. Die Arzneimittelbehörde bzw. die EMA legt innerhalb von 60 Tagen nach Eingang aller notwendigen Unterlagen ihr Gutachten vor. Diese Frist von 60 Tagen kann einmal aus berechtigten Gründen um weitere 60 Tage verlängert werden. Bei der Erstellung ihres Gutachtens kann die konsultierte Arzneimittelbehörde die Benannte Stelle oder den Hersteller auffordern, innerhalb einer festgelegten Frist zusätzliche für ihre Bewertung erforderliche Informationen vorzulegen. Im Falle eines solchen Ersuchens wird die in diesem Absatz festgelegte Frist ausgesetzt, bis die angeforderten zusätzlichen Informationen vorgelegt worden sind. Das Gutachten der konsultierten Arzneimittelbehörde sowie etwaige Aktualisierungen werden in die Dokumentation der Benannten Stelle zu dem Produkt aufgenommen. Bei ihrer Entscheidung berücksichtigt die Benannte Stelle gebührend das von der zuständigen Arzneimittelbehörde bzw. der EMA vorgelegte Gutachten. Sie teilt der konsultierten Arzneimittelbehörde ihre endgültige Entscheidung mit.

          Dieser Punkt gilt nicht in den Fällen, in denen die folgenden Voraussetzungen erfüllt sind:

        - i) Das therapiebegleitende Diagnostikum hat dieselbe Zweckbestimmung wie ein anderes bereits mit der CE-Kennzeichnung versehenes therapiebegleitendes Diagnostikum, für das eine Arzneimittelbehörde gemäß dem vorherigen Absatz oder Anhang IX Abschnitt 5.2 Buchstabe d eine befürwortende Stellungnahme abgegeben hat.

        - ii) Der Hersteller weist eine gleichwertige Leistung im Vergleich zu dem bereits CE-gekennzeichneten therapiebegleitenden Diagnostikum nach.“

    - v) Buchstabe l erhält folgende Fassung:

      - „l) Sie erstellt den EU-Baumusterprüfbericht gemäß Ziffer i unter Berücksichtigung der wissenschaftlichen Gutachten gemäß den Buchstaben j und k.“

  - c) Abschnitt 4 Satz 2 wird gestrichen.

  - d) Abschnitt 5.5 Satz 1 erhält folgende Fassung:

      „Betreffen die Änderungen die Leistung oder die Zweckbestimmung eines mit einer EU-Baumusterprüfbescheinigung genehmigten therapiebegleitenden Diagnostikums oder die Eignung seiner klinischen Leistung in Verbindung mit einem Arzneimittel, so konsultiert die Benannte Stelle die zuständige Arzneimittelbehörde, die an der ursprünglichen Konsultation beteiligt war, oder die EMA.“

- 8. Anhang XI wird wie folgt geändert:

  - a) Abschnitt 2 Satz 2 erhält folgende Fassung:

      „Mit der Ausstellung einer EU-Konformitätserklärung gilt, dass der Hersteller gewährleistet und erklärt, dass das betreffende Produkt die für selbiges geltenden Anforderungen dieser Verordnung erfüllt und, im Falle von Produkten, die einer Baumusterprüfung unterzogen werden, mit dem in der EU-Baumusterprüfbescheinigung beschriebenen Baumuster übereinstimmt.“

  - b) Abschnitt 5.1 wird wie folgt geändert:

    - i) Satz 3 erhält folgende Fassung:

        „Darüber hinaus stellt der Hersteller der Benannten Stelle Stichproben der hergestellten Produkte oder Produktchargen gemäß vorher vereinbarten Bedingungen und Modalitäten zur Verfügung; dies umfasst, dass der Hersteller einem gemäß Artikel 100 benannten EU-Referenzlaboratorium Stichproben der hergestellten Produkte oder Produktchargen übermittelt, damit dieses entsprechende Laboruntersuchungen durchführt.“

    - ii) Folgender Satz wird angefügt:

        „Wurde kein EU-Referenzlaboratorium gemäß Artikel 100 benannt, so können diese Vereinbarungen auch vorsehen, dass die Benannte Stelle die Überprüfung von Stichproben oder Chargen auf alternative Weise durchführt.“

- 9. Anhang XII wird wie folgt geändert:

  - a) Kapitel I wird wie folgt geändert:

    - i) Abschnitt 4 Buchstabe b erhält folgende Fassung:

      - „b) EU-Qualitätsmanagementbescheinigungen und EU-Produktionsqualitätssicherungsbescheinigung enthalten Angaben zu den Produkten bzw. Produktgruppen, zur Risikoklassifizierung sowie zu den erfassten Fertigungsstätten.“

    - ii) Abschnitt 7 wird gestrichen.

  - b) Kapitel II wird wie folgt geändert:

    - i) Abschnitt 6 erhält folgende Fassung:

      - „6. gegebenenfalls das Ablaufdatum;“

    - ii) Abschnitt 7 erhält folgende Fassung

      - „7. Daten für die eindeutige Identifizierung des Produkts bzw. der Produkte, gegebenenfalls gemäß Kapitel I Abschnitt 4;“

    - iii) Abschnitt 10 erhält folgende Fassung:

      - „10. Verweis auf einschlägige GS und harmonisierte Normen;“

- 10. Anhang XIII wird wie folgt geändert:

  - a) Abschnitt 1.1 wird wie folgt geändert:

    - i) Der erste und der zweite Gedankenstrich erhalten folgende Fassung:

      - – „Spezifizierung der Zweckbestimmung des Produkts gemäß Anhang I Abschnitt 20.4.1 Buchstabe c, einschließlich einer Spezifizierung des durch das Produkt zu bestimmenden Analyten oder Markers;

      - – Spezifizierung der Merkmale des Produkts gemäß Anhang I Abschnitt 9;“

    - ii) Der dritte Gedankenstrich wird gestrichen.

  - b) Abschnitt 1.2 dritter Gedankenstrich erhält folgende Fassung:

    - – „neue oder zusätzliche Daten, die für die Behandlung noch offener Fragen erforderlich sind, erzeugen; gegebenenfalls kann dies durch computergestützte Modellierung und In-silico-Tests unterstützt werden.“

  - c) In Abschnitt 1.2.1 erhält Absatz 2 folgende Fassung:

      „Die wissenschaftliche Validität des Analyten oder Markers wird in einem gesonderten Abschnitt des Berichts über die wissenschaftliche Validität nachgewiesen und dokumentiert.“

  - d) Abschnitt 1.2.2 Absatz 4 erhält folgende Fassung:

      „Die Analyseleistung wird in einem gesonderten Abschnitt des Berichts über die Leistungsbewertung nachgewiesen und dokumentiert.“

  - e) Abschnitt 1.2.3 erhält folgende Fassung:

      „1.2.3. Nachweis der klinischen Leistung

      Der Hersteller weist die klinische Leistung des Produkts anhand aller Parameter gemäß Anhang I Abschnitt 9.1 Buchstabe b nach; Parameter, deren Nichtanwendbarkeit begründet werden kann, können jedoch unberücksichtigt bleiben.

      Der Nachweis der klinischen Leistung eines Produkts beruht auf einer der folgenden Quellen oder Kombinationen dieser Quellen:

    - – klinische Leistungsstudien des betreffenden Produkts oder eines Produkts, dessen Gleichartigkeit mit dem betreffenden Produkt nachgewiesen werden kann;

    - – andere in der wissenschaftlichen Literatur veröffentlichte Studien zu dem betreffenden Produkt oder zu einem Produkt, dessen Gleichartigkeit mit dem betreffenden Produkt nachgewiesen werden kann;

    - – andere in der durch Peer-Review überprüften wissenschaftlichen Literatur veröffentlichte klinische Erfahrungen mit dem betreffenden Produkt oder mit einem Produkt, dessen Gleichartigkeit mit dem betreffenden Produkt nachgewiesen werden kann;

    - – klinisch relevante Angaben aus der Überwachung nach dem Inverkehrbringen, insbesondere aus der klinischen Nachbeobachtung nach dem Inverkehrbringen;

    - – aus diagnostischen Routinetests gewonnene Erfahrungen, die veröffentlicht wurden.

      Auf die Durchführung klinischer Leistungsstudien kann nur dann verzichtet werden, wenn es ausreichende Gründe dafür gibt, auf andere Quellen klinischer Leistungsdaten zurückzugreifen.

      Die klinische Leistung wird in einem gesonderten Abschnitt des Berichts über die Leistungsbewertung nachgewiesen und dokumentiert.“

  - f) Abschnitt 1.3.1 Satz 1 erhält folgende Fassung:

      „Der Hersteller bewertet alle einschlägigen Daten zur wissenschaftlichen Validität, zur Analyseleistung und zur klinischen Leistung.“

  - g) Abschnitt 1.3.2 Absatz 1 Satz 2 erhält folgende Fassung:

      „Dieser Bericht enthält eine Bewertung der wissenschaftlichen Validität, der Analyseleistung und der klinischen Leistung, die es gestattet, einen ausreichenden klinischen Nachweis aufzuzeigen.“

  - h) Abschnitt 1.3.3 wird gestrichen.

  - i) Abschnitt 2.3.2 Absatz 2 wird wie folgt geändert:

    - i) In Buchstabe k wird die Bezugnahme auf „Anhang I Kapitel I Abschnitt 9.1“ durch die Bezugnahme auf „Anhang I Abschnitt 9.1“ ersetzt.

    - ii) In Buchstabe l wird der folgende Satz angefügt:

        „Bei kombinierten Studien können Endpunkte verwendet werden, die das Produkt und das Arzneimittel gemeinsam betreffen.“

    - iii) Buchstabe n erhält folgende Fassung:

        „Informationen zur Verwendung von Daten aus Banken mit Restproben, Gen- oder Gewebebanken, Patienten- oder Krankheitsregistern usw. mit einer Beschreibung der Zuverlässigkeit und Repräsentativität und des Ansatzes für die statistische Analyse; Aussagekraft der einschlägigen Methode für die Bestimmung des tatsächlichen Status der Patientenproben.“

  - j) Abschnitt 3 erhält folgende Fassung:

      „3. SONSTIGE LEISTUNGSSTUDIEN

      Analog dazu werden der Leistungsstudienplan gemäß Abschnitt 2.3.2 und der Bericht über die Leistungsstudie gemäß Abschnitt 2.3.3 für Leistungsstudien mit Ausnahme von klinischen Leistungsstudien dokumentiert.“

  - k) In Abschnitt 4 Absatz 1 wird folgender Satz angefügt:

      „Wird die klinische Nachbeobachtung nach dem Inverkehrbringen als nicht anwendbar erachtet, so legt der Hersteller eine Begründung im Plan zur Überwachung nach dem Inverkehrbringen gemäß Anhang III Abschnitt 1 vor.“

  - l) Abschnitt 6 erhält folgende Fassung:

    - „6. Der Hersteller analysiert die Feststellungen aus der klinischen Nachbeobachtung nach dem Inverkehrbringen und dokumentiert die Ergebnisse in dem Leistungsbewertungsbericht und der technischen Dokumentation.“

  - m) Abschnitt 8 wird gestrichen.

- 11. Anhang XIV wird wie folgt geändert:

  - a) Kapitel I wird wie folgt geändert:

    - i) Abschnitt 1.2 erhält folgende Fassung:

      - „1.2. Falls von Abschnitt 1.1 abweichend, Name, Anschrift und Kontaktdaten des Herstellers des Produkts, das einer Leistungsstudie unterzogen werden soll, und gegebenenfalls seines Bevollmächtigten.“

    - ii) Abschnitt 1.5 erhält folgende Fassung:

      - 1.5. (betrifft nicht die deutsche Fassung)

    - iii) Abschnitt 1.7 erhält folgende Fassung:

      - „1.7. Bei einer Wiedervorlage des Antrags für ein Produkt, für das bereits ein Antrag eingereicht wurde, das Datum bzw. die Daten und die Referenznummer bzw. die Referenznummern des vorherigen Antrags oder, im Fall einer wesentlichen Änderung, ein Verweis auf den Originalantrag.“
