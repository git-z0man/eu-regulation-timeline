---
act: product-digitalisation-regulation
version: 2026-06-23_agreed-text-st-10482-26-add-2-rev-1
stage: agreed-text
language: en
document: ST 10482/26 ADD 2 REV 1
title: Proposal for a DIRECTIVE OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL amending Directives 2000/14/EC, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU and 2014/90/EU of the European Parliament and of the Council as regards digitalisation and common specifications
retrieved: '2026-10-01'
converter: tools/pdf2md.py
counts:
  recitals: 18
  articles: 17
  annexes: 13
official_source: https://data.consilium.europa.eu/doc/document/ST-10482-2026-ADD-2-REV-1/en/pdf
reuse: '© European Union, Council of the EU (Council register). Reuse: Council Decision (EU) 2017/1842, Article 6: source acknowledged, meaning not distorted, no liability of the Council.'
notice: Unofficial Markdown conversion made for reading and searching; conversion errors are possible. Only the official document linked in `official_source` is authentic.
extraction: Text extracted from the PDF text layer; headers, footers and page numbers removed, hyphenation joined, structure inferred from the layout, tables flattened. Check wording against the PDF before quoting.
---


# Proposal for a DIRECTIVE OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL amending Directives 2000/14/EC, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU and 2014/90/EU of the European Parliament and of the Council as regards digitalisation and common specifications

**Council of the** **European Union** **Brussels, 24 June 2026** **(OR. en)**

**1 0482/26** **ADD 2 REV 1** **Interinstitutional File:** **2025/0133 (COD) LIMITE** **SIMPL 142 TELECOM 315** **ANTICI 146 POLCOM 219** **ECOFIN 808 ENV 721** **EF 179 COMPET 767** **MI 627 CLIMA 327** **ECO 22 TRANS 418** **ENT 144 ENER 395** **IA 163 CODEC 1163** **I ND 411** **NOTE** From: General Secretariat of the Council To: Permanent Representatives Committee Subject: Omnibus IV Proposal for a DIRECTIVE OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL amending Directives 2000/14/EC 2011/65/EU, 2013/53/EU, 2014/29/EU, 20141301EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU and 2014/90/EU of the European Parliament and of the Council as regards digitalisation and common specifications - Final compromise text

Delegations will find enclosed the final compromise text on the Directive on digitalisation and common specifications.

GIP.B **LIMITE EN**

**ANNEX**

2025/0133 (COD)

Proposal for a

**DIRECTIVE OF THE EUROPEAN PARLIAMENT AND OF THE COUNCIL**

**amending Directives 2000/14/EC, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU,** **2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU and** **2014/90/EU of the European Parliament and of the Council as regards digitalisation and** **common specifications**

(Text with EEA relevance)

THE EUROPEAN PARLIAMENT AND THE COUNCIL OF THE EUROPEAN UNION,

Having regard to the Treaty on the Functioning of the European Union, and in particular Article 114 **and Article 100(2)** thereof,

Having regard to the proposal from the European Commission,

After transmission of the draft legislative act to the national parliaments,

Having regard to the opinion of the European Economic and Social Committee,

**Having regard to the opinion of the Committee of the Regions ^(1),**

Acting in accordance with the ordinary legislative procedure,

Whereas:

## Recitals

<a id="rec-1"></a>
(1) Reporting requirements play a key role in ensuring proper monitoring and correct enforcement of legislation. **The overall costs of reporting are balanced by the benefits** **they bring, in particular for ensuring compliance with key policy measures.** However, in order to ensure that they fulfil **their** intended **purpose** and to limit the administrative burden, it is important to streamline those requirements.

<a id="rec-2"></a>
(2) In its Communication on ‘Long-term competitiveness of the EU: looking beyond 2030’, the Commission has committed to rationalise and simplify reporting requirements, with the aim to reduce such burdens by 25%, without undermining the related policy objectives.

<a id="rec-3"></a>
(3) In its Better Regulation Guidelines, the Commission promotes the ‘digital by default’ principle to support digital transformations by facilitating digital-ready policies which consider the fast-evolving world of digitalisation and technology, and which are digital, interoperable, future-proof and agile by default.

<a id="rec-4"></a>
(4) The increasing importance of digitalisation in simplifying regulatory frameworks necessitates the reduction**, harmonisation** and modernisation of reporting requirements and economic operators’ obligations. In line with the efforts to accelerate digitalisation, it is essential to fully digitalise business-to-authority reporting and economic operators’ obligations when they do not affect protection and safety of consumers **or require an** **excessive burden for the economic operators**. Embracing digitalisation will not only simplify compliance procedures but also enhance the overall efficiency of the regulatory framework, ultimately benefiting both businesses and authorities alike. **A smooth** **transition should be pursued.**

**(4a) The Commission and the Member States are encouraged to provide guidance and** **practical support, and to promote the development of streamlined and standardised** **digital tools, with a view to facilitating the digital transition of companies, in particular** **SMEs and micro-enterprises.**

<a id="rec-5"></a>
(5) A number of sectoral Union legal acts lay down harmonised rules regarding the obligations of economic operators when placing a product on the market or putting it into service.

Such legal acts include Directives 2000/14/EC ^(2), 2011/65/EU ^(3), 2013/53/EU ^(4), 2014/29/EU ^(5), 2014/30/EU ^(6), 2014/31/EU ^(7), 2014/32/EU ^(8), 2014/33/EU ^(9), 2014/34/EU ^(10), 2014/35/EU ^(11),

2 **Directive 2000/14/EC of the European Parliament and of the Council of 8 May 2000 on** **the approximation of the laws of the Member States relating to the noise emission in the** **environment by equipment for use outdoors (OJ L 162, 3.7.2000, p. 1, ELI:** **http://data.europa.eu/eli/dir/2000/14/oj).** 3 **Directive 2011/65/EU of the European Parliament and of the Council of 8 June 2011 on** **the restriction of the use of certain hazardous substances in electrical and electronic** **equipment (OJ L 174, 1.7.2011, p. 88, ELI: http://data.europa.eu/eli/dir/2011/65/oj).** 4 **Directive 2013/53/EU of the European Parliament and of the Council of 20 November** **2013 on recreational craft and personal watercraft and repealing Directive 94/25/EC** **(OJ L 354, 28.12.2013, p. 90, ELI: http://data.europa.eu/eli/dir/2013/53/oj).** 5 **Directive 2014/29/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to the making** **available on the market of simple pressure vessels (OJ L 96, 29.3.2014, p. 45, ELI:** **http://data.europa.eu/eli/dir/2014/29/oj).** 6 **Directive 2014/30/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to electromagnetic** **compatibility (OJ L 96, 29.3.2014, p. 79, ELI: http://data.europa.eu/eli/dir/2014/30/oj).** 7 **Directive 2014/31/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to the making** **available on the market of non-automatic weighing instruments (OJ L 96, 29.3.2014,** **p. 107, ELI: http://data.europa.eu/eli/dir/2014/31/oj).** 8 **Directive 2014/32/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to the making** **available on the market of measuring instruments (OJ L 96, 29.3.2014, p. 149, ELI:** **http://data.europa.eu/eli/dir/2014/32/oj9).** 9 **Directive 2014/33/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to lifts and safety** **components for lifts (OJ L 96, 29.3.2014, p. 251, ELI:** **http://data.europa.eu/eli/dir/2014/33/oj).** 10 **Directive 2014/34/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to equipment and** **protective systems intended for use in potentially explosive atmospheres (OJ L 96,** **29.3.2014, p. 309, ELI: http://data.europa.eu/eli/dir/2014/34/oj).** 11 **Directive 2014/35/EU of the European Parliament and of the Council of 26 February** **2014 on the harmonisation of the laws of the Member States relating to the making** **available on the market of electrical equipment designed for use within certain voltage** **limits (OJ L 96, 29.3.2014, p. 357, ELI: http://data.europa.eu/eli/dir/2014/35/oj).**

014/53/EU ^(12), 2014/68/EU ^(13) and 2014/90/EU ^(14) of the European Parliament and of the Council (‘the Directives concerned’). Most of the Directives **concerned** are based on the principles of the ‘new approach’ to technical harmonisation and are ▌ aligned **with** the reference provisions laid down **in** Decision No 768/2008/EC of the European Parliament and of the Council ^(15).

<a id="rec-6"></a>
(6) In accordance with the Directives concerned, manufacturers are to draw up an EU declaration of conformity stating that the fulfilment of essential requirements set out in the applicable Directives has been demonstrated. In order to enable seamless electronic processes, the EU declaration of conformity should be drawn up only in electronic form.

<a id="rec-7"></a>
(7) Moreover, Directives 2000/14/EC, 2013/53/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU and 2014/53/EU require that a copy of the EU declaration of conformity accompanies the product. Considering the evolution of digitalisation, it is essential to modernise this obligation by requiring that such EU declaration of conformity accompany the product in electronic form. The manufacturer should therefore **ensure** that the EU declaration of conformity is **directly** accessible through an internet address or a machine-readable code**,** **meaning that intermediate steps, such as the number of landing pages, should be** **minimised as much as possible**. **Such a direct access should be free of charge, without** **the need for login procedures, providing any personal data, downloading or using** **additional applications specific to the economic operator or the obligation to register** **solely to access the EU declaration of conformity.**

<a id="rec-8"></a>
(8) Taking into account that in 2024 no less than 94% of EU households had access to internet, the **availability of product** instructions **in digital format offers an opportunity to align** **with** current technologies **and contribute to** green objectives **. In light of this**, the possibility for a digital format of the instructions should be introduced in the Directives **concerned.** This will allow manufacturers to **provide** instructions in digital format, if they wish to do so. Where manufacturers choose to provide instructions in digital format, **specific safeguards for** consumers **should ensure that they**, **as non-professional users,** **are still able to access and understand the information, in contrast to professional users,** **who are expected to possess the expertise and knowledge necessary for the correct use** **and handling of products. In that spirit, where a product is used solely by professional** **users, namely persons acquiring the product as professional end-users in the course of** **their industrial or professional activities,** safety information, including instructions **that** **have an** impact on **the safe use of the** product**, might be provided in digital format. In** **contrast, the** safety **information** should **always** be provided in paper format or marked on the product **where it is reasonably foreseeable that a product, even if primarily intended** **for professional use, could also be used by consumers.** Moreover, end-users should be able to obtain a paper copy of the instructions for use or safety information, upon request – at the time of the purchase and for a certain period of time after their purchase.

**(8a) The definition of ‘consumer’ forms part of the notion of ‘end user’ as laid down in** **Regulation (EU) 2019/1020 of the European Parliament and of the Council, which** **applies to the Directives concerned, and refers to any natural person acting for purposes** **outside their trade, business, craft or profession. This requirement ensures that all** **consumers, including vulnerable consumers such as elderly persons, persons with** **disabilities or those with limited digital literacy, are able to access and understand the** **safety information.**

**(8b) In order to ensure that all consumers, including those who may not have regular access** **to digital tools, can effectively exercise their right to obtain the instructions or safety** **information in paper format, manufacturers may still provide additional accessible** **means of communication for submitting such requests, including by telephone. This is** **particularly important for elderly consumers and other groups at risk of digital** **exclusion. End-users should also be clearly informed, in the safety information** **accompanying the product, of their right to request the instructions or safety** **information in paper format.**

**(8c) Manufacturers should, where relevant, ensure that instructions and safety information** **provided in digital format take into account the requirements set out in Annex I of** **Directive (EU) 2019/882 of the European Parliament and of the Council, insofar as the** **products fall within the scope of that Directive, so as to ensure usability by all end-users,** **including persons with disabilities, are able to access and understand the safety** **information and instructions. Other categories, such as elderly persons or persons with** **limited digital literacy, may also benefit from these provisions.**

**(8d) Manufacturers can offer alternative means to deliver the instructions on paper directly** **to the end-user, free of charge and without imposing any obligation on distributors** **which are not required to print the instructions, unless they choose to do so voluntarily.**

**(8e) When providing the instructions and safety information in electronic form, the** **manufacturer should ensure that those instructions and safety information are directly** **accessible through an internet address or a machine-readable code, meaning that** **intermediate steps, such as the number of landing pages, should be minimised as much** **as possible. Such a direct access should be free of charge, without the need for login** **procedures, providing any personal data, downloading or using additional applications** **specific to the economic operator or the obligation to register solely to access the** **instructions and safety information. This is in line with the overarching vision of digital** **inclusion, as set out in the European Declaration on Digital Rights and Principles for** **the Digital Decade, notably chapter II on Solidarity and inclusion.**

**(8f) Given the shift towards digital information for consumers, when evaluating the** **implementation of the Directives amended by this Omnibus, where appropriate, the** **Commission should also assess whether the provisions concerning instructions in digital** **format are effectively ensuring that such information remains easily accessible and** **comprehensible for consumers.**

**(8g) The possibility for the end-user to request the instructions or safety information in paper** **format should not preclude manufacturers from providing supplementary information** **materials in an electronic-only format, such as video or audio content, which cannot be** **reproduced in a paper format. The same content should be provided in paper format and** **in the materials provided in electronic format.**

<a id="rec-9"></a>
(9) Directive 2014/53/EU provides for the possibility for manufacturers to provide a simplified EU declaration of conformity in an electronic form. Considering that this proposal is introducing a digital by default format of the EU declaration of conformity, the provisions on the simplified EU declaration of Conformity become redundant. It is therefore necessary to remove such provisions from Directive 2014/53/EU.

**(9a) The term ‘digital contact’, similarly to the term ‘electronic address’ in Regulation (EU)** **2023/988 of the European Parliament and of the Council, should be interpreted in a** **technologically neutral manner, capable of evolving with future technological** **developments, and should cover all forms of direct digital communication.**

<a id="rec-10"></a>
(10) In order to facilitate communication between economic operators and national competent authorities and end-users, the indication of a digital contact of the manufacturer on the product and in the EU declaration of conformity is necessary to enhance the effectiveness of market surveillance and to expedite the process of tracing non-compliant products. Currently, economic operators are required to indicate their postal address on the product, but this is not always sufficient to ensure that competent authorities can establish rapid contact. It is therefore necessary to require economic operators to provide both a postal address and a digital contact on the product and in the EU declaration of conformity. Such digital contact should be defined in the Directives. **The digital contact should allow** **consumers and competent authorities to contact economic operators directly, and should** **be accessible free of charge, without the need for login procedures, to provide any** **personal data, download or use additional applications specific to the economic operator** **or the obligation to register solely to contact the economic operator. Such digital contact** **may include, for example, an email address or a contact form on a website, or any other** **direct means of digital communication without intermediate steps which allow for** **traceability of exchanges and should be interpreted in a technologically neutral manner.** **However, it should not be understood as encompassing automatic replies to queries,** **chatbots, fax numbers, or telephone lines.**

<a id="rec-11"></a>
(11) The Directives concerned require that economic operators provide, **upon** a reasoned request from a competent national authority ▌, all information and documentation necessary to demonstrate the conformity of the concerned products with the respective Directives, in paper or electronic form. The paper-based form is **becoming less important**, while electronic communication enhances interaction between authorities and businesses, streamlining processes and reducing administrative burdens. In order to achieve the digitalisation of reporting requirements and to reduce administrative burden for economic operators**, in particular SMEs,** and competent authorities, the economic operators should be required to provide the necessary information and documentation in electronic form only. Documentation provided in electronic form could be made available, for example, in a digital printable format, which allows the possibility to print, download and save the documentation on an electronic device.

<a id="rec-12"></a>
(12) Directive 2014/90/EU contains certain sectoral specificities, including the unique requirements for ensuring the safety of marine equipment on board EU ships. Due to those specificities, that Directive differs from other NLF-aligned legislation. Specifically, it foresees the obligation for a paper copy of the declaration of conformity to be on board an EU ship until the marine equipment is removed. However, given the availability of the European Maritime Safety Agency’s database to Member State flag states and market surveillance authorities, the obligation should be satisfied by uploading a copy of the declaration of conformity to this database. This would enable the necessary checks and controls of the marine equipment on the ship to be carried out electronically and ensure uniform application and practices under this legislation.

<a id="rec-13"></a>
(13) The current Union standardisation framework which is based on Regulation (EU) No 1025/2012 of the European Parliament and of the Council ^(16), represents the framework by default to elaborate standards that provide for a presumption of conformity with the relevant essential health and safety requirements or with other requirements. However, where no harmonised standards exist or where they are insufficient, the Commission should be able to adopt implementing acts establishing common specifications for the essential health and safety or other requirements, as an exceptional fall-back solution to facilitate the manufacturer’s obligation to comply with those health and safety or other requirements. **Several legislative acts already contain such an option to provide** **businesses with legal predictability and prove compliance with Union law, to cater for** **such situations. Compliance with common specifications remains purely voluntary for** **manufacturers, who may rely on them to benefit from a presumption of conformity or** **choose other appropriate methods to demonstrate compliance with Union requirements.**

**(13a) Where the lack of cooperation by international standardisation organisations prevents** **European standardisation organisations from adopting relevant international standards** **as harmonised standards, and where such situation cannot be adequately mitigated by** **alternative measures, implementing powers should be conferred on the Commission to** **adopt, as a measure of last resort, common specifications without prior request to one or** **more European standardisation organisations to draft or to revise harmonised** **standards. In view of the upcoming revision of the standardisation regulation, it is** **appropriate to limit the scope of the last resort clause to a limited period of time. When** **the Commission drafts such implementing acts, all relevant information concerning the** **third parties contracted for supporting the drafting process of the implementing act** **should be made public in a timely manner.**

▌

<a id="rec-14"></a>
(14) As the digital product passport is foreseen in certain Union **legislation**, such as Regulation (EU) 2023/1542 of the European Parliament and of the Council ^(17), it is essential to require ▌ economic operators to store the information contained in the EU declaration of conformity and instructions ▌ in the digital product passport where a product is covered by multiple pieces of legislation. This approach would reduce the administrative burden on manufacturers, as they would no longer need to maintain separate storage locations for compliance documents**, such as declarations of conformity required under the various** **pieces of product legislation that may apply to the same product, thereby upholding the** **principle of a single declaration of conformity. In addition, instructions provided in** **electronic form would be stored together with the declaration of conformity**. By storing the documentation in one place, all necessary documents demonstrating product compliance would be easily accessible, ensuring transparency and facilitating compliance. This streamlined approach would enhance the overall efficiency of the regulatory framework**, and it** aligns with the principle that where several pieces of Union harmonisation legislation apply to a product, the manufacturer or ▌ other economic operator, where appropriate, should provide a single EU declaration of conformity.

<a id="rec-15"></a>
(15) Since the objectives of this Directive cannot be sufficiently achieved by the Member States as this Directive amends Directives which are harmonising products legislations but can rather, by reason of harmonisation of EU applicable rules **to products**, be better achieved at Union level, the Union may adopt measures, in accordance with the principle of subsidiarity as set out in Article 5 of the Treaty on European Union. In accordance with the principle of proportionality, as set out in that Article, this Directive does not go beyond what is necessary in order to achieve those objectives.

<a id="rec-16"></a>
(16) In order to enable economic operators to supply stock of products that have been placed on the market before the date of application of the national measures transposing this Directive, it is necessary to provide for reasonable transitional arrangements that do not impede the making available on the market of products that have been placed on the market in accordance with the Directives concerned before the date of application of the national measures transposing this Directive.

<a id="rec-17"></a>
(17) To ensure a smooth and effective transition, to **minimise** disruptions, and to provide a reasonable timeframe for industries to adjust to the new requirements, application of transposition measures concerning digitalisation should be deferred.

<a id="rec-18"></a>
(18) Directives 2000/14/EC, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU and 2014/90/EU should therefore be amended accordingly,

HAVE ADOPTED THIS DIRECTIVE:

<a id="art-1"></a>
### Article 1 – Amendments to Directive 2000/14/EC

Directive 2000/14/EC is amended as follows:

- (1) in Article 3, the following point (g) is added:

‘(g) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use additional applications** **specific to the economic operator**;’

- (2) in Article 4(1), the third indent is replaced by the following:

‘the equipment bears CE marking and the indication of the guaranteed sound power level and is accompanied by the internet address or machine-readable code through which the EC declaration of conformity can be **directly** accessed. ▌

- (3) in Article 5, paragraph 1 is replaced by the following:

‘1. Member States shall take appropriate measures to ensure that equipment referred to in Article 2(1) may be placed on the market or put into service only if it conforms to the provisions of this Directive, bears the CE marking and the indication of the guaranteed sound power level and is accompanied by the internet address or machine-readable code through which the EC declaration of conformity can be **directly** accessed. ▌

- (4) in Article 6, paragraph 1 is replaced by the following:

‘1. Member States shall not prohibit, restrict or impede the placing on the market or putting into service in their territory of equipment referred to in Article 2(1) which complies with the provisions of this Directive, bears the CE marking, the indication of the guaranteed sound power level and is accompanied by the internet address or machine-readable code through which the EC declaration of conformity can be **directly** accessed. ▌

- (5) Article 7 is replaced by the following:

‘Presumption of conformity

Member States shall presume that equipment referred to in Article 2(1) bearing the CE marking and the indication of the guaranteed sound power level and which is accompanied by the internet address or machine-readable code through which the EC declaration of conformity can be **directly** accessed conforms to all the provisions of this Directive. ▌

- (6) Article 8 is amended as follows:

  - (a) paragraph 1 is replaced by the following:

‘1. The manufacturer, or his authorised representative established in the Community, of equipment referred to in Article 2(1) shall, in order to certify that an item of equipment is in conformity with the provisions of this Directive, draw up an EC declaration of conformity, in electronic form, for each type of equipment manufactured; the minimum content of this declaration of conformity is laid down in Annex II.;’

  - (b) the following paragraph 4 is added:

‘4. Where other Union legislation applicable to the equipment requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the **EU** declaration of conformity or instructions in a digital product passport, the information required in Annex II to be included in the EC declaration of conformity **or, as appropriate, the EC declaration of** **conformity,** and the instructions referred to in Article 11(5)**, where provided in** **electronic form,** shall be provided only in that digital product passport.;’

- (7) Article 14 is amended as follows:

  - (a) paragraph 3 is replaced by the following:

‘3. Member States shall ensure that the Commission and any other Member State may, on a reasoned request, obtain all information, in electronic form, used during the conformity assessment procedure concerning a type of equipment and in particular the technical documentation provided for in Annex V item 3,

Annex VI item 3, Annex VII item 2, Annex VIII items 3.1 and 3.3.;’

  - (b) the following paragraph 4 is added:

‘4. Where appropriate, the manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (8) Annexes II and V to VIII are amended in accordance with Annex I to this Directive.

<a id="art-2"></a>
### Article 2 – Amendments to Directive 2011/65/EU

Directive 2011/65/EU is amended as follows:

- (1) Article 3 is amended as follows:

  - (a) the following point (6a) is inserted:

‘(6a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (13a) is inserted:

‘(13a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provides means of complying with the requirements **set out in** **Article 4** applicable to **an EEE;’’**

- (2) Article 7 is amended as follows:

  - (a) in point (c), the first sentence is replaced by the following:

‘(c) Where compliance of EEE with the applicable requirements has been demonstrated by the procedure referred to in point (b), manufacturers draw up an EU declaration of conformity, in electronic form, and affix the CE marking on the finished product.;’

  - (b) in point (e), the second sentence is replaced by the following:

‘Changes in product design or characteristics and changes in the harmonised standards, in the common specifications or in technical specifications by reference to which conformity of EEE is declared shall be adequately taken into account;’

  - (c) point (h) is replaced by the following:

‘(h) manufacturers indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the EEE or, where that is not possible, on its packaging or in a document accompanying the EEE. The postal address and digital contact must indicate a single point through which the manufacturer can be **contacted**. Where other applicable Union legislation contains provisions for the affixing of the manufacturer’s name, postal address and digital contact which are at least as stringent, those provisions shall apply; ▌

  - (d) point (j) is replaced by the following:

‘(j) manufacturers, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the EEE with this Directive, in a language which can be easily understood by that authority, and that they cooperate with that authority, at its request, on any action taken to ensure compliance with this Directive of EEE which they have placed on the market.;’

- (3) in Article 8, point (b), the second indent is replaced by the following:

‘– further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of an EEE with this Directive,;’

- (4) Article 9 is amended as follows:

  - (a) point (d) is replaced by the following:

‘(d) importers indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the EEE or, where that is not possible, on its packaging or in a document accompanying the EEE. Where other applicable Union legislation contains provisions for the affixing of the importer’s name, postal address and digital contact which are at least as stringent, those provisions shall apply.;’

  - (b) point (h) is replaced by the following:

‘(h) importers, further to a reasoned request from a competent national authority, provide it with all the information and documentation, in electronic form, necessary to demonstrate the conformity of an EEE with this Directive in a language which can be easily understood by that authority, and that they cooperate with that authority, at its request, on any action taken to ensure compliance with this Directive of EEE which they have placed on the market.;’

- (5) in Article 10, point (d) is replaced by the following:

‘(d) distributors, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of EEE with this Directive, and that they cooperate with that authority, at its request, on any action taken to ensure the compliance with this Directive of the EEE which they have made available on the market.;’

- (6) in Article 13, the following paragraph 4 is added:

‘4. Where other Union legislation applicable to EEE requires the economic operator to include the information that the product complies with the requirement set out in that legislation in a digital product passport or to upload the declaration of conformity in a digital product passport, the information required in Annex VI to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of conformity** shall be provided only in that digital product passport.;’

- (7) The following Article 16a is inserted:

‘Article 16a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the ▌ requirements set out in Article 4**. Those implementing acts shall only be adopted where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to** Article **10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements **and:**

    - (i) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (ii) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (1) **are not delivered within the deadline set in the request;**

      - (2) **do not comply with the request; or**

      - (3) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **19(2)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.**

**The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 19(2). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive]** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

2. Materials, components and EEE that are in conformity with the common specification shall be presumed to be in conformity with ▌ requirements, covered by those common specifications or parts thereof, set out in Article 4.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential requirements set** **out in Article 4 which it covers, it shall inform the Commission thereof by** **submitting a detailed explanation. The Commission shall assess that detailed** **explanation and may, if appropriate, amend the implementing act establishing the** **common specification in question.’**

- (8) in Article 19, the following paragraph 3 is added:

‘3. Where reference is made to this paragraph, Article 4 of Regulation (EU) No 182/2011 shall apply.;’

- (9) Annexes V and VI are amended in accordance with Annex II to this Directive.

<a id="art-3"></a>
### Article 3 – Amendments to Directive 2013/53/EU

Directive 2013/53/EU is amended as follows:

- (1) Article 3 is amended as follows:

  - (a) the following point (19a) is inserted:

‘(19a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) The following point (20a) is inserted:

‘(20a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential requirements **set** **out in Article 4(1) and Annex I** applicable to a product ▌;**’’**

- (2) Article 7 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of a product with the applicable requirements has been demonstrated by that procedure, manufacturers shall draw up a declaration referred to in Article 15, in electronic form, and mark and affix the CE marking, as set out in Articles 17 and 18.;’

  - (b) in paragraph 4, the second sentence is replaced by the following:

‘Changes in product design or characteristics and changes in the harmonised standards or common specifications by reference to which conformity of a product is declared shall be adequately taken into account.;’

  - (c) paragraphs 6 and 7 are replaced by the following:

‘6. Manufacturers shall indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the product or, where that is not possible, on its packaging or in a document accompanying the product. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

7. Manufacturers shall ensure that the product is accompanied by instructions and safety information in the owner’s manual in a language or languages which can be easily understood by consumers and other end-users, as determined by the Member State concerned. The instructions and safety information may be provided in electronic form.

The manufacturer shall take into account the intended use and the foreseeable end-user of the product when deciding the specific format for the instructions and safety information.

In the case of product intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, or mark on the product, the safety information. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and safety information, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions play for ensuring safety.

When the instructions **and safety information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the product, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and safety information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the product; this requirement also applies where the instructions **and safety information** are embedded in the software of the product;

    - (c) make them accessible online during the expected lifetime of the product and for at least 10 years after the placing on the market of the product.

However, the end-user may, at time of the purchase of the product, or up to **24** months after that purchase, request the instructions or safety information in paper format. Where the end-user requests those instructions or safety information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The safety information shall clearly inform the end-** **user of their right to request the instructions in paper format.’**

  - (d) in paragraph 9, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the product, in a language which can be easily understood by that authority.;’

- (3) in Article 8(3), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a product;’

- (4) Article 9 is amended as follows:

  - (a) paragraph 3 is replaced by the following:

‘3. Importers shall indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the product or, in the case of components where that is not possible, on the packaging or in a document accompanying the product.;’

  - (b) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the product, in a language which can be easily understood by that authority.;’

- (5) in Article 10(5), the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the product.;’

- (6) the following Article 14a is inserted:

‘Article 14a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential requirements set out in Article **4(1) and Annex I. Those implementing acts shall** **only be adopted where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to** Article **10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements **and:**

    - (i) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (ii) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (1) **are not delivered within the deadline set in the request;**

      - (2) **do not comply with the request; or**

      - (3) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **50(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.** **The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 50(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

2. Products that are in conformity with the common specification shall be presumed to be in conformity with essential requirements, covered by those common specifications or parts thereof, set out in Article **4(1) and Annex I**.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential requirements set** **out in Article 4(1) and Annex I which it covers, it shall inform the Commission** **thereof by submitting a detailed explanation. The Commission shall assess that** **detailed explanation and may, if appropriate, amend the implementing act** **establishing the common specification in question.’;’**

- (7) Article 15 is amended as follows:

  - (a) in paragraph 4, the introductory sentence is replaced by the following:

‘The following products, when made available on the market or put into service, shall be accompanied by the internet address of machine-readable code through which the EU declaration of conformity, referred to in paragraph 3, can be **directly** accessed: ▌

  - (b) the following paragraph 6 is added:

‘6. Where other Union legislation applicable to the product requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions **and safety information** in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of** **conformity,** and the instructions **and safety information** referred to in Article 7(7)**, where provided in electronic form,** shall be provided only in **that** digital product passport.;’

- (8) in Article 19, the following paragraph 5 is added:

‘5. The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to the conformity assessment procedures in electronic form.;’

- (9) in Article 20(1), point (b)(i), the indents are replaced by the following:

‘— where the harmonised standards or common specifications relating to points 3.2 and 3.3 of Part A of Annex I are complied with: Module A (internal production control), Module A1 (internal production control plus supervised product testing), Module B (EU type-examination) together with Module C, D, E or F, Module G (conformity based on unit verification) or Module H (conformity based on full quality assurance);

  - — where the harmonised standards or common specifications relating to points 3.2 and 3.3 of Part A of Annex I are not complied with: Module A1 (internal production control plus supervised product testing), Module B (EU type-examination) together with Module C, D, E or F, Module G (conformity based on unit verification) or Module H (conformity based on full quality assurance);’

- (10) Article 21 is amended as follows:

  - (a) in point (a), the introductory sentence is replaced by the following:

‘where tests are conducted using the harmonised standard or common specification, any of the following modules:;’

  - (b) in point (b), the introductory sentence is replaced by the following:

‘where tests are conducted without using the harmonised standard or common specification, any of the following modules:;’

- (11) Article 22 is amended as follows:

  - (a) paragraph 1 is amended as follows:

    - (i) in point (a), the introductory sentence is replaced by the following:

‘where tests are conducted using the harmonised standard or common specification for noise measurement, any of the following modules:;’

    - (ii) point (b) is replaced by the following:

‘(b) Where tests are conducted without using the harmonised standard or common specification for noise measurement, Module G (conformity based on unit verification).;’

  - (b) paragraph 2 is amended as follows:

    - (i) in point (a), the introductory sentence is replaced by the following:

‘Where tests are conducted using the harmonised standard or common specification for noise measurement, any of the following modules:;’

    - (ii) point (b) is replaced by the following:

‘(b) Where tests are conducted without using the harmonised standard or common specification for noise measurement, Module G (conformity based on unit verification).;’

- (12) in Article 30(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential requirements, the applicable harmonised standards **and** common specifications, the relevant Union harmonisation legislation and the relevant national legislation;

;’

- (13) in Article 38, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that requirements laid down in Article 4(1) and Annex I or in corresponding harmonised standards or common specifications have not been met by a manufacturer or a private importer, it shall require that manufacturer or private importer to take appropriate corrective measures and shall not issue a conformity certificate.;’

- (14) Annexes I, III, IV and V are amended in accordance with Annex III to this Directive.

<a id="art-4"></a>
### Article 4 – Amendments to Directive 2014/29/EU

Directive 2014/29/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (7a) is inserted:

‘(7a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (9a) is inserted:

‘(9a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential requirements **set** **out in Annex I** applicable to a **vessel**;**’’**

- (2) Article 6 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of a vessel of which the product of PS × V exceeds 50 bar.L with the applicable requirements has been demonstrated by that procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking and the inscriptions provided for in point 1 of Annex III.;’

  - (b) in paragraph 4, first subparagraph, the second sentence is replaced by the following:

‘Changes in vessels design or characteristics and changes in the harmonised standards, in the common specifications or in other technical specifications by reference to which conformity of a vessel is declared shall be adequately taken into account.;’

  - (c) in paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the vessel their name, registered trade name or registered trademark as well as their postal address and digital contact. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**.;’

  - (d) paragraph 7 is replaced by the following:

‘7. Manufacturers shall ensure that the vessel is accompanied by the instructions and safety information referred to in point 2 of Annex III in a language which can be easily understood by end-users, as determined by the Member State concerned. The instructions and safety information referred to in point 2 of Annex III may be provided in electronic form. Such instructions and safety information, as well as any labelling, shall be clear, understandable and intelligible.

The manufacturer shall take into account the intended use and the foreseeable end-user of the vessel when deciding the specific format for the instructions and safety information.

In the case of vessel for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, or mark on the vessel, the safety information referred to in point 2 of Annex III. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and safety information, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions play for ensuring safety.

When the instructions **and safety information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the vessel, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and safety information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the vessel; this requirement also applies where the instructions **and safety information** are embedded in the software of the vessel;

    - (c) make them accessible online during the expected lifetime of the vessel and for at least 10 years after the placing on the market of the vessel.

However, the end-user may, at time of the purchase of the vessel, or up to **24** months after that purchase, request the instructions or safety information in paper format. Where the end-user requests those instructions or safety information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The safety information shall clearly inform the end-** **user of their right to request the instructions in paper format.’**

  - (e) in paragraph 9, the first sentence, is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the vessel with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 7(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a vessel;’

- (4) Article 8 is amended as follows:

  - (a) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the vessel their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, in a document accompanying the vessel.;’

  - (b) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a vessel in a language which can be easily understood by that authority.;’

- (5) in Article 9(5), the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a vessel.;’

- (6) the following Article 12a is inserted:

‘Article 12a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential **safety** requirements set out in Annex I**. Those implementing acts shall only be adopted** **where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements**; and:**

    - (i) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (ii) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (1) **are not delivered within the deadline set in the request;**

      - (2) **do not comply with the request; or**

      - (3) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **39(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.** **The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 39(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].**

**This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Vessels of which the product of PS × V exceeds 50 bar.L that are in conformity with the common specification shall be presumed to be in conformity with **the** essential **safety** requirements, covered by those common specifications or parts thereof, set out in Annex I.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential safety** **requirements set out in Annex I which it covers, it shall inform the Commission** **thereof by submitting a detailed explanation. The Commission shall assess that** **detailed explanation and may, if appropriate, amend the implementing act** **establishing the common specification in question.’;’**

- (7) Article 13 is amended as follows

  - (a) paragraph 1 is amended as follows:

    - (i) in point (a), the introductory sentence is replaced by the following:

‘(a) for vessels manufactured in accordance with the harmonised standards referred to in Article 12 or common specifications referred to in Article 12a, at the choice of the manufacturer, in either of the following two manners:;’

    - (ii) point (b) is replaced by the following:

‘(b) for vessels not manufactured, or manufactured only partly, in accordance with the harmonised standards referred to in Article 12, or the common specifications referred to in Article 12a, the manufacturer shall submit for examination a prototype, representative of the production envisaged, of the complete vessel and the technical documentation and supporting evidence for examination and assessment of the adequacy of the technical design of the vessel (Module B – production type).;’

  - (b) paragraph 3 is replaced by the following:

‘3. The records and correspondence relating to the conformity assessment procedures referred to in paragraphs 1 and 2 shall be drawn up, in electronic form, in an official language of the Member State in which the notified body is established or in a language accepted by that body.;’

  - (c) the following paragraph 4 is added:

‘4. The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (8) in Article 14, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to the vessel requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the** **EU declaration of conformity,** and the instructions **and safety information** referred to in Article 6(7)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (9) in Article 21(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential safety requirements set out in Annex I, of the applicable harmonised standards **and** common specifications and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (10) in Article 29, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that the essential safety requirements set out in Annex I or corresponding harmonised standards, or common specifications, or other technical specifications have not been met by a manufacturer, it shall require that manufacturer to take appropriate corrective measures and shall not issue a certificate of conformity.;’

- (11) Annexes II, III and IV are amended in accordance with Annex IV to this Directive.

<a id="art-5"></a>
### Article 5 – Amendments to Directive 2014/30/EU

Directive 2014/30/EU is amended as follows:

- (1) Article 3 is amended as follows:

  - (a) the following point (15a) is inserted:

‘(15a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (17a) is inserted:

‘(17a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential requirements **set** **out in Annex I** applicable to **equipment**;**’’**

- (2) Article 7 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of apparatus with the applicable requirements has been demonstrated by that procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking.;’

  - (b) in paragraph 4, the second sentence is replaced by the following:

‘Changes in apparatus design or characteristics and changes in the harmonised standards, in the common specifications, or in other technical specifications by reference to which conformity of apparatus is declared shall be adequately taken into account.;’

  - (c) in paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate, on the apparatus, their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the apparatus. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) paragraph 7 is replaced by the following:

‘7. Manufacturers shall ensure that the apparatus is accompanied by instructions and the information referred to in Article 18, in a language which can be easily understood by consumers and other end-users, as determined by the Member State concerned. The instructions and information referred to in Article 18 may be provided in electronic form. Such instructions and information, as well as any labelling, shall be clear, understandable and intelligible.

In the case of apparatus intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, or mark on the apparatus, the information referred to in Article 18. Such information shall be easily visible and legible for consumers.

When drafting the instructions and information referred to in Article 18, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user.

When the instructions **and information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the apparatus, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the apparatus;

    - (c) make them accessible online during the expected lifetime of the apparatus and for at least 10 years after the placing on the market of the apparatus.

However, the end-user may, at time of the purchase of the apparatus, or up to **24** months after that purchase, request the instructions or information referred to in

Article 18 in paper format. Where the end-user requests those instructions or information referred to in Article 18, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request.; **The** **information shall clearly inform the end-user of their right to request the** **instructions in paper format.’**

  - (e) in paragraph 9, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the apparatus with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 8(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the apparatus;’

- (4) Article 9 is amended as follows:

  - (a) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the apparatus their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the apparatus.;’

  - (b) in paragraph 8, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of apparatus in a language which can be easily understood by that authority.;’

- (5) in Article 10(5), the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the apparatus.;’

- (6) the following Article 13a is inserted:

‘Article 13a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential requirements set out in Annex I**. Those implementing acts shall only be adopted** **where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements**; and:**

    - (i) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (ii) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (1) **are not delivered within the deadline set in the request;**

      - (2) **do not comply with the request; or**

      - (3) **do not satisfy the requirements they aim to cover.**

▌ Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **41(2a)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.**

**The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 41(2a). Where** **the committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. **Equipment** that is in conformity with the common specification shall be presumed to be in conformity with essential requirements, covered by those common specifications or parts thereof, set out in Annex I.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential requirements set** **out in Annex I which it covers, it shall inform the Commission thereof by** **submitting a detailed explanation. The Commission shall assess that detailed** **explanation and may, if appropriate, amend the implementing act establishing the** **common specification in question.’;’**

- (7) in Article 14, the following subparagraph is added:

‘The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedure in electronic form.;’

- (8) in Article 15, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to an apparatus requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the** **EU declaration of conformity,** and the instructions **and information** referred to in Article 7(7)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (9) in Article 24(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential requirements set out in Annex I, of the applicable harmonised standards **and** common specifications and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (10) in Article 32, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that the essential requirements set out in Annex I or corresponding harmonised standards or common specifications or other technical specifications have not been met by a manufacturer, it shall require that manufacturer to take appropriate corrective measures and shall not issue a certificate.;’

- (10a) **in Article 41, the following paragraph is inserted:**

**‘2a. Where reference is made to this paragraph, Article 5 of Regulation (EU)** **No 182/2011 shall apply.’;’**

- (11) Annexes II, III and IV are amended in accordance with Annex V to this Directive.

<a id="art-6"></a>
### Article 6 – Amendments to Directive 2014/31/EU

Directive 2014/31/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (9a) is inserted:

‘(9a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (11a) is inserted:

‘(11a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential requirements **set** **out in Annex I** applicable to **an instrument**;**’’**

- (2) Article 6 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of an instrument intended to be used for the applications listed in points (a) to (f) of Article 1(2) with the applicable requirements has been demonstrated by that conformity assessment procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking and the supplementary metrology marking.;’

  - (b) in paragraph 4, first subparagraph, the second sentence is replaced by the following:

‘Changes in instrument design or characteristics and changes in the harmonised standards, in the common specifications, or in other technical specifications by reference to which conformity of an instrument is declared shall be adequately taken into account.;’

  - (c) in paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the instrument their name, registered trade name or registered trademark as well as their postal address and digital contact. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) paragraph 7 is replaced by the following:

‘7. Manufacturers shall ensure that the instrument intended to be used for the applications listed in points (a) to (f) of Article 1(2) is accompanied by instructions and information in a language which can be easily understood by end-users, as determined by the Member State concerned. The instructions and information may be provided in electronic form. Such instructions and information, as well as any labelling, shall be clear, understandable and intelligible.

The manufacturer shall take into account the intended use and the foreseeable end-user of the product when deciding the specific format for the instructions and information.

In the case of an instrument intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide in paper format, or mark on the **instrument**, the information that is essential for **its intended use**. Such information shall be easily visible and legible for consumers.

When drafting the instructions and information, the manufacturer shall take account of the intended use and foreseeable misuse by the end-user.

When the instructions **and information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the instrument, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the instrument; this requirement also applies where the instructions **and information** are embedded in the software of the instrument;

    - (c) make them accessible online during the expected lifetime of the instrument and for at least 10 years after the placing on the market of the instrument.

However, the end-user may, at time of the purchase of the instrument, or up to **24** months after that purchase, request the instructions and information in paper format. Where the end-user requests those instructions and information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The information shall clearly inform the end-user of** **their right to request the instructions in paper format.’**

  - (e) in paragraph 9, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the instrument with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 7(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of an instrument;’

- (4) Article 8 is amended as follows:

  - (a) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the instrument their name, registered trade name or registered trademark as well as their postal address and digital contact.;’

  - (b) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of an instrument in a language which can be easily understood by that authority.;’

- (5) in Article 9(5), the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of an instrument.;’

- (6) the following Article 12a is inserted:

‘Article 12a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential requirements set out in Annex I**. Those implementing acts shall only be adopted** **where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements **and:**

    - (i) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (ii) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (1) **are not delivered within the deadline set in the request;**

      - (2) **do not comply with the request; or**

      - (3) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **41(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.** **The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 41(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].**

**This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Instruments that are in conformity with the common specification shall be presumed to be in conformity with essential requirements, covered by those common specifications or parts thereof, set out in Annex I.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential requirements set** **out in Annex I which is covers, it shall inform the Commission thereof by** **submitting a detailed explanation. The Commission shall assess that detailed** **explanation and may, if appropriate, amend the implementing act establishing the** **common specification in question.’;’**

- (7) in Article 13, paragraph (2 is replaced by the following:

‘2. The documents and correspondence relating to the conformity assessment procedures referred to in paragraph 1 shall be drawn up, in electronic form, in one of the official languages of the Member State where those procedures are carried out, or in a language accepted by the body notified in accordance with Article 19.;’

- (8) in Article 14, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to an instrument requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the** **EU declaration of conformity, and the** instructions **and information** referred to in Article 6(7)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (9) in Article 23(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential requirements set out in Annex I, of the applicable harmonised standards **and** common specifications and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (10) in Article 31, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that the essential requirements set out in Annex I or corresponding harmonised standards or common specifications or other technical specifications have not been met by a manufacturer, it shall require that manufacturer to take appropriate corrective measures and shall not issue a certificate of conformity.;’

- (11) Annexes II and IV are amended in accordance with Annex VI to this Directive.

<a id="art-7"></a>
### Article 7 – Amendments to Directive 2014/32/EU

Directive 2014/32/EU is amended as follows:

- (1) Article 4 is amended as follows:

  - (a) the following point (12a) is inserted:

‘(12a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (14a) is inserted:

‘(14a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard **or a normative document**, that provide means of complying with the essential requirements **set out in Annex I and in the relevant instrument-** **specific Annexes** applicable to a **measuring instrument**;**’’**

- (2) Article 8 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of a measuring instrument with the applicable requirements of this Directive has been demonstrated by that conformity assessment procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking and the supplementary metrology marking.;’

  - (b) in paragraph 4, the second sentence is replaced by the following:

‘Changes in measuring instrument design or characteristics and changes in the harmonised standards, common specifications, normative documents or in other technical specifications by reference to which conformity of a measuring instrument is declared shall be adequately taken into account.’

  - (c) paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the measuring instrument their name, registered trade name or registered trademark, as well as their postal address and digital contact or, where that is not possible, in a document accompanying the measuring instrument and on the packaging, if any, in accordance with point 9.2 of Annex I. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) in paragraph 7, the first sentence is replaced by the following:

‘7. Manufacturers shall ensure that the measuring instrument which they have placed on the market is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed, and by instructions and information in accordance with point 9.3 of Annex I in a language which can be easily understood by end-users, as determined by the Member State concerned. The instructions and information may be provided in electronic form. Such instructions and information, as well as any labelling, shall be clear, understandable and intelligible.

The manufacturer shall take into account the intended use and the foreseeable end-user of the **measuring instrument** when deciding the specific format for the instructions and information in accordance with point 9.3 of Annex I.

In the case of measuring instrument intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, or mark on the **measuring** **instrument**, the information in accordance with point 9.3 of Annex I. Such information shall be easily visible and legible for consumers.

When drafting the instructions and information in accordance with point 9.3 of Annex I, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions and information play for ensuring safety.

When the instructions **and information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the measuring instrument, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the measuring instrument; this requirement also applies where the instructions **and information** are embedded in the software of the measuring instrument;

    - (c) make them accessible online during the expected lifetime of the measuring instrument and for at least 10 years after the placing on the market of the measuring instrument.

However, the end-user may, at time of the purchase of the measuring instrument, or up to **24** months after that purchase, request the instructions and information in accordance with point 9.3 of Annex I in paper format. Where the end-user requests those instructions information in accordance with point 9.3 of Annex I, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The information shall clearly inform the end-** **user of their right to request the instructions in paper format.’**

  - (e) in paragraph 9, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the measuring instrument with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 9(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a measuring instrument;’

- (4) Article 10 is amended as follows:

  - (a) in paragraph 2, first subparagraph, the second sentence is replaced by the following:

‘They shall ensure that the manufacturer has drawn up the technical documentation, that the measuring instrument bears the CE marking and the supplementary metrology marking and is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed and by the required documents, and that the manufacturer has complied with the requirements set out in Article 8(5) and (6).;’

  - (b) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the measuring instrument their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, in a document accompanying the measuring instrument and on its packaging, if any, in accordance with point 9.2 of Annex I.;’

  - (c) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a measuring instrument in a language which can be easily understood by that authority.;’

- (5) Article 11 is amended as follows:

  - (a) in paragraph 2, the first subparagraph is replaced by the following:

‘Before making a measuring instrument available on the market and/or putting a measuring instrument into use distributors shall verify that the measuring instrument bears the CE marking and the supplementary metrology marking, that it is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed, by the required documents, and by instructions and information in accordance with point 9.3 of Annex I, in a language which can be easily understood by end-users in the Member State in which the measuring instrument is to be made available on the market and/or put into use, and that the manufacturer and the importer have complied with the requirements set out in Article 8(5) and (6) and Article 10(3) respectively. ▌

  - (b) in paragraph 5, the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a measuring instrument.;’

- (6) the following Article 14a is inserted:

‘Article 14a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential requirements set out in Annex I and in the relevant instrument-specific Annexes**.** Those **implementing acts shall only be adopted where** the following **conditions are** **fulfilled**:

  - (a) **there is no harmonised standard and/or normative document covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such reference is expected to be published within a** **reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012, one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements**; and:**

    - (1) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (2) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (a) **are not delivered within the deadline set in the request;**

      - (b) **do not comply with the request; or**

      - (c) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **46(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.**

**The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 46(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Measuring instruments that are in conformity with the common specification shall be presumed to be in conformity with essential requirements set out in **Annex I and in** **the relevant instrument-specific Annexes** covered by those common specifications or parts thereof.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential requirements set** **out in Annex I and the relevant instrument-specific Annexes which it covers, it** **shall inform the Commission thereof by submitting a detailed explanation. The** **Commission shall assess that detailed explanation and may, if appropriate, amend** **the implementing act establishing the common specification in question.’;’**

- (7) Article 17 is amended as follows:

  - (a) the third subparagraph is replaced by the following:

‘Records and correspondence relating to conformity assessment procedures shall be drawn up in electronic form, in the official language(s) of the Member State where the notified body carrying out the conformity assessment procedures is established, or in a language accepted by that body.;’

  - (b) the following subparagraph is added:

‘The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (8) in Article 18(3), points (f) and (g) are replaced by the following:

‘(f) a list of the harmonised standards and/or normative documents referred to in Article 14, and/or common specifications referred to in Article 14a applied in full or in part, the references of which have been published in the Official Journal of the European Union;

  - (g) descriptions of the solutions adopted to meet the essential requirements where the harmonised standards and/or common specification and/or normative documents referred to in Article 14 have not been applied, including a list of the relevant technical specifications applied;’

- (9) in Article 19, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to measuring instruments requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex XIII to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of conformity,** and the instructions **and information in accordance with point 9.3 of Annex I** referred to in Article 8(7)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (10) in Article 27(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential requirements set out in Annex I and in the relevant instrument-specific Annexes, of the applicable harmonised standards **and** common specifications **or** normative documents and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (11) in Article 36, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that the essential requirements set out in Annex I and in the relevant instrument-specific Annexes or corresponding harmonised standards, normative documents, common specifications or other technical specifications have not been met by a manufacturer, it shall require that manufacturer to take appropriate corrective measures and shall not issue a certificate of conformity.;’

- (12) in Article 45(1), point (d) is replaced by the following:

‘(d) the measuring instrument is not accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed; ▌

- (13) Annexes II and XIII are amended in accordance with Annex VII to this Directive.

<a id="art-8"></a>
### Article 8 – Amendments to Directive 2014/33/EU

Directive 2014/33/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (11a) is inserted:

‘(11a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (13a) is inserted:

‘(13a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential **health and safety** requirements **set out in Annex I** applicable to a **lift or a safety component for** **lifts**;**’’**

- (2) Article 7 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of the lift with the applicable essential health and safety requirements has been demonstrated by that procedure, the installer shall draw up an EU declaration of conformity, in electronic form, ensure that the lift is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed and, affix the CE marking.;’

  - (b) in paragraph 6, the first and second sentences are replaced by the following:

‘Installers shall indicate, on the lift, their name, registered trade name or registered trademark, as well as their postal address and digital contact. The postal address and digital contact shall indicate a single point through which the installer can be **contacted**.’

  - (c) paragraph 7 is replaced by the following:

‘7. Installers shall ensure that the lift is accompanied by the instructions referred to in point 6.2 of Annex I, in a language which can be easily understood by end-users, as determined by the Member State in which the lift is placed on the market. The instructions may be provided in electronic form. Such instructions, as well as any labelling, shall be clear, understandable and intelligible.

When the instructions are provided in electronic form, the installer shall:

    - (a) mark on the lift, or, where that is not possible, ▌ in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the lift; this requirement also applies where the instructions are embedded in the software of the lift;

    - (c) make them accessible online during the expected lifetime of the lift and for at least 10 years after the placing on the market of the lift.

However, the end-user may, at time of the purchase of the lift, or up to **24** months after that purchase, request the instructions in paper format. Where the end-user requests those instructions, the installer shall provide them to the end-user, free of charge, within one month of receiving the request.**’**

  - (d) in paragraph 9, the first subparagraph is replaced by the following:

‘Installers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the lift with this Directive, in a language which can be easily understood by that authority.;’

- (3) Article 8 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of a safety component for lifts with the applicable essential health and safety requirements has been demonstrated by that procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, ensure that the safety component for lifts is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed, and affix the CE marking. ▌

  - (b) in paragraph 4, first subparagraph, the second sentence is replaced by the following:

‘Changes in product design or characteristics and changes in the harmonised standards, in the common specifications, or in other technical specifications by reference to which conformity of a safety component for lifts is declared shall be adequately taken into account.;’

  - (c) in paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the safety component for lifts their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on the label referred to in Article 19(1). The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) paragraph 7 is replaced by the following:

‘7. Manufacturers shall ensure that the safety component for lifts is accompanied by the instructions referred to in point 6.1 of Annex I, in a language which can be easily understood by end-users, as determined by the Member State concerned. The instructions may be provided in electronic form. Such instructions, as well as any labelling, shall be clear, understandable and intelligible.

When the instructions are provided in electronic form, the manufacturer shall:

    - (a) mark on the safety component for lifts, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions and save them on an electronic device so that the end-user can access them at all times; this requirement also applies where the instructions are embedded in the software of the safety component for lifts;

    - (c) make them accessible online during the expected lifetime of the safety component for lifts and for at least 10 years after the placing on the market of safety component for lifts.

However, the end-user may, at time of the purchase of the safety component for lift, or up to **24** months after that purchase, request the instructions in paper format. Where the end-user requests those instructions, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request.**’**

  - (e) in paragraph 9, first subparagraph, the first sentence is replaced the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the safety components for lifts with this Directive, in a language which can be easily understood by that authority.;’

- (4) in Article 9(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the safety components for lifts or the lift;’

- (5) Article 10 is amended as follows:

  - (a) in paragraph 2, first subparagraph, the second sentence is replaced by the following:

‘They shall ensure that the manufacturer has drawn up the technical documentation, that the safety component for lifts bears the CE marking and that it is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed and by the required documents, and that the manufacturer has complied with the requirements set out in Article 8(5) and (6).;’

  - (b) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the safety component for lifts their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the safety component for lifts.;’

  - (c) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a safety component for lifts in a language which can be easily understood by that authority.;’

- (6) Article 11 is amended as follows:

  - (a) in paragraph 2, the first subparagraph is replaced by the following:

‘Before making a safety component for lifts available on the market, distributors shall verify that the safety component for lifts bears the CE marking and that it is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed, by the required documents and by the instructions referred to in point 6.1 of Annex I, in a language which can be easily understood by end-users, as determined by the Member State concerned and that the manufacturer and the importer have complied with the requirements set out in Article 8(5) and (6) and Article 10(3), respectively. ▌

  - (b) in paragraph 5, the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a safety component for lifts.;’

- (7) the following Article 14a is inserted:

‘Article 14a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential **health and** **safety** requirements set out in Annex I**. Those implementing acts shall only be** **adopted where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements **and:**

    - (1) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (2) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (a) **are not delivered within the deadline set in the request;**

      - (b) **do not comply with the request; or**

      - (c) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **42(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.**

**The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 42(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Lifts and safety components for lifts that are in conformity with the common specification shall be presumed to be in conformity with essential **health and safety** requirements, covered by those common specifications or parts thereof, set out in Annex I.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential health and** **safety requirements set out in Annex I which it covers, it shall inform the** **Commission thereof by submitting a detailed explanation. The Commission shall** **assess that detailed explanation and may, if appropriate, amend the implementing** **act establishing the common specification in question.’;’**

- (8) in Article 15, the following subparagraph is added:

‘The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures for safety components for lifts in electronic form.;’

- (9) in Article 16, the following paragraph 5 is added:

‘5. The installer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures for lifts in electronic form.;’

- (10) in Article 17, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to lifts or safety components for lifts requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex II to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of conformity,** and the instructions referred to in Articles 7(7) and 8(7)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (11) in Article 24(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential health and safety requirements set out in Annex I, of the applicable harmonised standards **and** common specifications and of the relevant provisions of Union harmonisation legislation and of its relevant national legislation;’

- (12) in Article 32, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that the essential health and safety requirements of this Directive or corresponding harmonised standards or common specifications or other technical specifications have not been met by an installer or a manufacturer, it shall require the installer or the manufacturer to take appropriate corrective measures and shall not issue a certificate.;’

- (13) in Article 41(1), point (g) is replaced by the following:

‘(g) the name, registered trade name or registered trademark, the postal address and digital contact of the installer, manufacturer or importer has not been indicated in compliance with Article 7(6), Article 8(6) or Article 10(3);’

- (14) Annexes II and IV to XII are amended in accordance with Annex VIII to this Directive.

<a id="art-9"></a>
### Article 9 – Amendments to Directive 2014/34/EU

Directive 2014/34/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (16a) is inserted:

‘(16a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (18a) is inserted:

‘(18a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential **health and safety** requirements **set out in Annex II** applicable to a product**’’**

- (2) Article 6 is amended as follows:

  - (a) in paragraph 2, the second, third and fourth subparagraphs are replaced by the following:

‘Where compliance of a product, other than a component, with the applicable requirements has been demonstrated by that procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking.

Where compliance of a component with the applicable requirements has been demonstrated by the relevant conformity assessment procedure, manufacturers shall draw up a written attestation of conformity, in electronic form, as referred to in Article 13(3).

Manufacturers shall ensure that each product is accompanied by the internet address or machine-readable code through which the EU declaration of conformity or the attestation of conformity, as appropriate, can be **directly** accessed. However, where a large number of products are delivered to a single end-user, the batch or consignment concerned may be accompanied by a single internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed. ▌

  - (b) in paragraph 4, first subparagraph, the second sentence is replaced by the following:

‘Changes in a product design or characteristics and changes in the harmonised standards, in the common specifications, or in other technical specifications by reference to which conformity of a product is declared shall be adequately taken into account.;’

  - (c) in paragraph 7, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate, on the product, their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the product. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) paragraph 8 is replaced by the following:

‘8. Manufacturers shall ensure that the product is accompanied by instructions and safety information in a language which can be easily understood by end-users, as determined by the Member State concerned. The instructions and safety information may be provided in electronic form. Such instructions and safety information, as well as any labelling, shall be clear, understandable and intelligible.

The manufacturer shall take into account the intended use and the foreseeable end-user of the product when deciding the specific format for the instructions and safety information.

In the case of products intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide in paper format, or mark on the product, the safety information. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and safety information, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions play for ensuring safety.

When the instructions **and safety information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the product, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and safety information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the product; this requirement also applies where the instructions are embedded in the software of the product;

    - (c) make them accessible online during the expected lifetime of the product and for at least 10 years after the placing on the market of the product.

However, the end-user may, at time of the purchase of the product, or up to **24** months after that purchase, request the instructions or safety information in paper format. Where the end-user requests those instructions or safety information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The safety information shall clearly inform the end-** **user of their right to request the instructions in paper format.’**

  - (e) in paragraph 10, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the product with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 7(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a product;’

- (4) Article 8 is amended as follows:

  - (a) in paragraph 2, first subparagraph, the second sentence is replaced by the following

‘They shall ensure that the manufacturer has drawn up the technical documentation, that the product bears the CE marking, where applicable, and that it is accompanied by the internet address or machine-readable code where the EU declaration of conformity or the attestation of conformity can be **directly** accessed and by the required documents, and that the manufacturer has complied with the requirements set out in Article 6(5), (6) and (7).;’

  - (b) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the product their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the product.;’

  - (c) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a product in a language which can be easily understood by that authority.;’

- (5) Article 9 is amended as follows:

  - (a) in paragraph 2, the first subparagraph is replaced by the following:

‘Before making a product available on the market distributors shall verify that the product bears the CE marking, where applicable, and that it is accompanied by the internet address or machine-readable code through which the EU declaration of conformity or the attestation of conformity can be **directly** accessed and by the required documents and by instructions and safety information, in a language which can be easily understood by end-users in the Member State in which the product is to be made available on the market, and that the manufacturer and the importer have complied with the requirements set out in Article 6(5), (6) and (7) and Article 8(3) respectively.;’

  - (b) in paragraph 5, the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a product.;’

- (6) the following Article 12a is inserted:

‘Article 12a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential **health and** **safety** requirements set out in Annex II**. Those implementing acts shall only be** **adopted where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements**; and:**

    - (1) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (2) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (a) **are not delivered within the deadline set in the request;**

      - (b) **do not comply with the request; or**

      - (c) **do not satisfy the requirements they aim to cover.**

▌ Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **39(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.**

**The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 39(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Products that are in conformity with the common specification shall be presumed to be in conformity with essential **health and safety** requirements, covered by those common specifications or parts thereof, set out in Annex II.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential health and** **safety requirements set out in Annex II which it covers, it shall inform the** **Commission thereof by submitting a detailed explanation. The Commission shall** **assess that detailed explanation and may, if appropriate, amend the implementing** **act establishing the common specification in question.’;’**

- (7) Article 13 is amended as follows:

  - (a) paragraph 6 is replaced by the following:

‘6. Documents and correspondence relating to the conformity assessment procedures referred to in paragraphs 1 to 4 shall be drawn up, in electronic form, in a language, determined by the Member State concerned.;’

  - (b) the following paragraph 7 is added:

‘7. The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (8) in Article 14, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to a product requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex X to be included in the EU declaration of conformity **or, as appropriate, the** **EU declaration of conformity,** and the instructions **and safety information** referred to in Article **6(8), where provided in electronic form,** shall be provided only in that digital product passport.;’

- (9) in Article 21(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential health and safety requirements set out in Annex II, of the applicable harmonised standards **and** common specifications, of the relevant provisions of Union harmonisation legislation and of national legislation;’;’

- (10) in Article 29, paragraph 3 is replaced by the following:

‘3. Where a notified body finds that the essential health and safety requirements set out in Annex II or corresponding harmonised standards or common specifications or other technical specifications have not been met by a manufacturer, it shall require that manufacturer to take appropriate corrective measures and shall not issue a certificate of conformity.;’

- (11) in Article 38(1), point (e) is replaced by the following:

‘(e) the product is not accompanied by the internet address or machine-readable code through which the EU declaration of conformity or the attestation of conformity, as appropriate, can be **directly** accessed; ▌

- (12) Annexes II to V and VII to X are amended in accordance with Annex IX to this Directive.

<a id="art-10"></a>
### Article 10 – Amendments to Directive 2014/35/EU

Directive 2014/35/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (7a) is inserted:

‘(7a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (9a) is inserted:

‘(9a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the safety objectives **referred** **to in Article 3 and set out in Annex I** applicable to **electrical equipment**;**’’**

- (2) Article 6 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of electrical equipment with the safety objectives referred to in Article 3 and set out in Annex I has been demonstrated by the conformity assessment procedure referred to in the first subparagraph, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking.;’

    - (b) in paragraph 4, first subparagraph, the second sentence is replaced by the following:

    - (c) ‘Changes in product design or characteristics and changes in the harmonised standards referred to in Article 12, the common specifications referred to in Article 12a, the international or national standards referred to in Articles 13 and 14, or in other technical specifications by reference to which conformity of electrical equipment is declared shall be adequately taken into account.;’

  - (c) in paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the electrical equipment their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the electrical equipment. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) paragraph 7 is replaced by the following:

‘7. Manufacturers shall ensure that the electrical equipment is accompanied by instructions and safety information, in a language which can be easily understood by consumers and other end-users, as determined by the Member State concerned. The instructions and safety information may be provided in electronic form. Such instructions and safety information, as well as any labelling, shall be clear, understandable and intelligible.

The manufacturer shall take into account the intended use and the foreseeable end-user of the electrical equipment when deciding the specific format for the instructions and safety information.

In the case of electrical equipment intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, or mark on the **electrical** **equipment**, the safety information. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and safety information, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions play for ensuring safety.

When the instructions **and safety information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the electrical equipment, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and safety information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the electrical equipment; this requirement also applies where the instructions **and safety information** are embedded in the software of the electrical equipment;

    - (c) make them accessible online during the expected lifetime of the electrical equipment and for at least 10 years after the placing on the market of the electrical equipment.

However, the end-user may, at time of the purchase of the electrical equipment, or up to **24** months after that purchase, request the instructions or safety information in paper format. Where the end-user requests those instructions or safety information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The safety information shall clearly** **inform the end-user of their right to request the instructions in paper format.’**

  - (e) in paragraph 9, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the electrical equipment with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 7(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of electrical equipment;’

- (4) Article 8 is amended as follows:

  - (a) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate on the electrical equipment their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the electrical equipment.;’

  - (b) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of electrical equipment in a language which can be easily understood by that authority.;’

- (5) in Article 9(5), the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of electrical equipment.;’

- (6) the following Article 14a is inserted:

‘Article 14a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the safety objectives referred to in Article 3 and set out in Annex I**. Those implementing acts shall only** **be adopted where** the following **conditions are fulfilled**:

  - (a) **there is no** harmonised **standard covering those safety objectives the reference** of which **is** published in the Official Journal of the European Union **and no** **such reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to** Article **10(1) of Regulation (EU)** **No 1025/2012, one or more** European **standardisation organisations to draft** **or to revise European** standards **for those safety objectives; and**

    - (1) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (2) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (a) **are not delivered within the deadline set in the request;**

      - (b) **do not comply with the request; or**

      - (c) **do not satisfy the safety objectives they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **23(2)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.** **The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 23(2). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Electrical equipment that are in conformity with the common specification shall be presumed to be in conformity with safety objectives covered by those common specifications or parts thereof, referred to in Article 3 and set out in Annex I.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the safety objectives referred** **to in Article 3 and set out in Annex I which it covers, it shall inform the** **Commission thereof by submitting a detailed explanation. The Commission shall** **assess that detailed explanation and may, if appropriate, amend the implementing** **act establishing the common specification in question.’;’**

- (7) in Article 15, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to electrical equipment requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of conformity,** and the instructions **and safety** **information** referred to in Article 6(7)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (8) in Article 23, the following paragraph 3a is inserted:

‘3a. Where reference is made to this paragraph, Article 4 of Regulation (EU) No 182/2011 shall apply.;’

- (9) Annexes III and IV are amended in accordance with Annex X to this Directive.

<a id="art-11"></a>
### Article 11 – Amendments to Directive 2014/53/EU

Directive 2014/53/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (16a) is inserted:

‘(16a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (18a) is inserted:

‘(18a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential requirements **set** **out in Article 3** applicable to **radio equipment**; ▌

- (2) Article 10 is amended as follows:

  - (a) in paragraph 3, the second subparagraph is replaced by the following:

‘Where compliance of radio equipment with the applicable requirements has been demonstrated by that conformity assessment procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking.;’

  - (b) in paragraph 5, the second sentence is replaced by the following:

‘Changes in radio equipment design or characteristics and changes in the harmonised standards, or in the common specifications, or in other technical specifications by reference to which conformity of radio equipment is declared shall be adequately taken into account.;’

  - (c) in paragraph 7, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the radio equipment their name, registered trade name or registered trademark as well as their postal address and digital contact or, where the size or nature of radio equipment does not allow it, on its packaging, or in a document accompanying the radio equipment. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**.;’

  - (d) paragraph 8 is replaced by the following:

‘8. Manufacturers shall ensure that the radio equipment is accompanied by instructions and safety information. The instructions and safety information may be provided in electronic form in accordance with the sixth subparagraph of this paragraph. The manufacturer shall take into account the intended use and the foreseeable end-user of the radio equipment when deciding the specific format for the instructions and safety information. The instructions shall include the information required to use radio equipment in accordance with its intended use. Such information shall include, where applicable, a description of accessories and components, including software, which allow the radio equipment to operate as intended. Such instructions and safety information, as well as any labelling, shall be clear, understandable and intelligible.

The following information shall also be included in the instructions in the case of radio equipment intentionally emitting radio waves:

    - (a) frequency band(s) in which the radio equipment operates;

    - (b) maximum radio-frequency power transmitted in the frequency band(s) in which the radio equipment operates.

In the case of radio equipment referred to in Article 3(4), the instructions shall contain information on the specifications relating to the radio equipment’s charging capabilities and the compatible charging devices, as set out in Part II of Annex Ia. In addition to being included in the instructions, when the manufacturers make such radio equipment available to consumers and other end-users, the information shall be also displayed on a label, as set out in Part IV of Annex Ia. The label shall be included in the instructions and printed on the packaging or affixed to the packaging as a sticker. In the absence of packaging, the sticker with the label shall be affixed to the radio equipment. When the radio equipment is made available to consumers and other end-users, the label shall be displayed in a visible and legible manner and, in the case of distance selling, close to the price indication. Where the size or nature of the radio equipment does not allow otherwise, the label may be printed as a separate document accompanying the radio equipment.

The instructions and safety information referred to in the first, second and third subparagraphs of this paragraph shall be in a language which can be easily understood by consumers and other end-users, as determined by the Member State concerned.

The Commission is empowered to adopt delegated acts in accordance with Article 44 in order to amend Parts II and IV of Annex Ia, as a consequence of amendments to Part I of that Annex, or as a consequence of future amendments to labelling requirements, or in the light of technological progress, by introducing, modifying, adding or removing any details in relation to the information, graphic or textual elements, as set out in this Article.’;

In the case of radio equipment intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, the safety information in paper format. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and safety information, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions play for ensuring safety.

When the instructions **and safety information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the radio equipment, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and safety information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the radio equipment; this requirement also applies where the instructions are embedded in the software of the radio equipment;

    - (c) make them accessible online during the expected lifetime of the radio equipment and for at least 10 years after the placing on the market of the radio equipment.

However, the end-user may, at time of the purchase of the radio equipment, or up to **24** months after that purchase, request the instructions or safety information in paper format. Where the end-user requests those instructions or safety information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The safety information shall clearly** **inform the end-user of their right to request the instructions in paper format.’**

  - (e) paragraph 9 is amended as follows:

    - (i) the first sentence is replaced by the following:

‘Manufacturers shall ensure that each item of radio equipment is accompanied by the internet address or machine-readable code through which the EU declaration of conformity can be **directly** accessed. ▌

    - (ii) the second sentence is deleted;

  - (f) in paragraph 12, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the radio equipment with this Directive, in a language which can be easily understood by that authority.;’

- (3) in Article 11(2), point (b), is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of radio equipment;’

- (4) Article 12 is amended as follows:

  - (a) in paragraph 3, the first and second sentences are replaced by the following:

‘Importers shall indicate on the radio equipment their name, registered trade name or registered trademark as well as their postal address and digital contact or, where that is not possible, on its packaging or in a document accompanying the radio equipment. This includes cases where the size of radio equipment does not allow it, or where importers would have to open the packaging in order to indicate their name, postal address and digital contact on the radio equipment.;’

  - (b) in paragraph 9, the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of radio equipment in a language which can be easily understood by that authority.;’

- (5) in Article 13(5), the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of radio equipment.;’

- (6) the following Article 16a is inserted:

‘Article 16a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential requirements set out in Article 3**. Those implementing acts shall only be adopted** **where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to** Article **10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements**; and:**

    - (1) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (2) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (a) **are not delivered within the deadline set in the request;**

      - (b) **do not comply with the request; or**

      - (c) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **45(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.** **The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 45(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].**

**This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Radio equipment that is in conformity with the common specification shall be presumed to be in conformity with essential requirements, covered by those common specifications or parts thereof, set out in Article 3.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential requirements set** **out in Article 3 which it covers, it shall inform the Commission thereof by** **submitting a detailed explanation. The Commission shall assess that detailed** **explanation and may, if appropriate, amend the implementing act establishing the** **common specification in question.’;’**

- (7) Article 17 is amended as follows:

  - (a) in paragraph 3, the first sentence is replaced by the following:

‘3. Where, in assessing the compliance of radio equipment with the essential requirements set out in Article 3(2) and (3), the manufacturer has applied harmonised standards the references of which have been published in the Official Journal of the European Union, **and** common specifications, the manufacturer shall use any of the following procedures:;’

  - (b) In paragraph 4, the first sentence is replaced by the following:

‘4. Where, in assessing the compliance of radio equipment with the essential requirements set out in Article 3(2) and (3), the manufacturer has not applied or has applied only in part harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, or where such harmonised standards or common specifications do not exist, radio equipment shall be submitted with regard to those essential requirements to either of the following procedures:;’

  - (c) the following paragraph 5 is added:

‘5. Where applicable, manufacturers shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (8) Article 18 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is deleted;

  - (b) the following paragraph 5 is added:

‘5. Where other Union legislation applicable to radio equipment requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of** **conformity,** and the instructions **and safety information** referred to in **Articles** **10(8) and 10(10), where provided in electronic form,** shall be provided only in that digital product passport.;’

- (9) in Article 26(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential requirements set out in Article 3, of the applicable harmonised standards, of the applicable common specifications and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (10) Annexes Ia, and III to ▌ VII are amended in accordance with Annex XI to this Directive.

<a id="art-12"></a>
### Article 12 – Amendments to Directive 2014/68/EU

Directive 2014/68/EU is amended as follows:

- (1) Article 2 is amended as follows:

  - (a) the following point (22a) is inserted:

‘(22a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use** **additional applications specific to the economic operator**;’

  - (b) the following point (24a) is inserted:

‘(24a) ‘common **specification**’ means a ▌ technical **specification**, other than a standard, that provide means of complying with the essential requirements **set** **out in Annex I** applicable to **pressure equipment or assemblies**;**’’**

- (2) Article 6 is amended as follows:

  - (a) in paragraph 2, the second subparagraph is replaced by the following:

‘Where compliance of the pressure equipment or assemblies referred to in Article 4(1) and (2) with the applicable requirements has been demonstrated by the procedure referred to in the first subparagraph of this paragraph, manufacturers shall draw up an EU declaration of conformity, in electronic form, and affix the CE marking.;’

  - (b) in paragraph 4, first subparagraph, the second sentence is replaced by the following:

‘Changes in design or characteristics of pressure equipment or assemblies and changes in the harmonised standards or in the common specifications or in other technical specifications by reference to which conformity of pressure equipment or assemblies is declared shall be adequately taken into account.;’

  - (c) in paragraph 6, the first and second sentences are replaced by the following:

‘Manufacturers shall indicate on the pressure equipment or assembly their name, registered trade name or registered trademark, as well as their postal address and digital contact or, where that is not possible, on the packaging or in a document accompanying the equipment or assembly. The postal address and digital contact shall indicate a single point through which the manufacturer can be **contacted**. ▌

  - (d) paragraph 7 is replaced by the following:

‘7. Manufacturers shall ensure that the pressure equipment or assemblies referred to in Article 4(1) and (2) is accompanied by instructions and safety information in accordance with points 3.3 and 3.4 of Annex I in a language which can be easily understood by consumers and other end-users, as determined by the Member State concerned. The instructions and safety information may be provided in electronic form. Such instructions and safety information shall be clear, understandable and intelligible.

Manufacturers shall ensure that the pressure equipment or assemblies referred to in Article 4(3) are accompanied by instructions and safety information in accordance with Article 4(3), in a language which can be easily understood by consumers and other end-users, as determined by the Member State concerned. The instructions and safety information may be provided in electronic form. Such instructions and safety information shall be clear, understandable and intelligible.

The manufacturer shall take into account the intended use and the foreseeable end-user of the pressure equipment or assemblies when deciding the specific format for the instructions and safety information.

In the case of pressure equipment or assemblies intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, the safety information in accordance with points 3.3 and 3.4 of Annex I. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and safety information, the manufacturers shall take account of the intended use and foreseeable misuse by the end-user, as well as the role which the instructions play for ensuring safety.

When the instructions **and safety information**, referred to in the first subparagraph, are provided in electronic form, the manufacturer shall:

    - (a) mark on the pressure equipment or assemblies or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and safety information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the pressure equipment or assemblies; this requirement also applies where the instructions **and safety** **information** are embedded in the software of the pressure equipment or assemblies;

    - (c) make them accessible online during the expected lifetime of the pressure equipment or assemblies and for at least 10 years after the placing on the market of the pressure equipment or assemblies.

However, the end-user may, at time of the purchase of the pressure equipment or assemblies, or up to **24** months after that purchase, request the instructions or safety information in paper format. Where the end-user requests those instructions or safety information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The safety information shall** **clearly inform the end-user of their right to request the instructions in paper** **format.’**

  - (e) paragraph 9 is amended as follows:

    - (a) the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the pressure equipment or assembly with this Directive, in a language which can be easily understood by that authority.;’

    - (b) the second sentence is deleted;

- (3) in Article 7(2), point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent national authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the pressure equipment or assembly;’

- (4) Article 8 is amended as follows:

  - (a) in paragraph 3, the first sentence is replaced by the following:

‘Importers shall indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the pressure equipment or assembly, or, where that is not possible, on its packaging or in a document accompanying the equipment or assembly.;’

  - (b) paragraph 9 is amended as follows:

    - (i) the first sentence is replaced by the following:

‘Importers shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of pressure equipment or **assemblies** in a language which can be easily understood by that authority.;’

    - (ii) the second sentence is deleted;

- (5) Article 9 is amended as follows:

  - (a) the first sentence is replaced by the following:

‘Distributors shall, further to a reasoned request from a competent national authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of pressure equipment or assemblies.;’

  - (b) the second sentence is deleted;

- (6) the following Article 12a is inserted:

‘Article 12a

Common Specifications

1. The Commission may **adopt** implementing acts **establishing** common specifications **covering requirements that provide a means to comply** with the essential **safety** requirements set out in Annex I**. Those implementing acts shall only be adopted** **where** the following **conditions are fulfilled**:

  - (a) **there is no harmonised standard covering those** requirements **the reference** of which **is** published in the Official Journal of the European Union **and no such** **reference is expected to be published within a reasonable period**;

  - (b) **the Commission has requested, pursuant to Article 10(1) of Regulation (EU)** **No 1025/2012**, **one or more** European **standardisation organisations to draft** **or to revise European** standards **for those** requirements**; and:**

    - (1) **the request has not been accepted by any of the European** **standardisation organisations to which the request was addressed; or**

    - (2) **the request has been accepted by at least one of the European** **standardisation organisations to which the request was addressed, but** **the European standards requested:**

      - (a) **are not delivered within the deadline set in the request;**

      - (b) **do not comply with the request; or**

      - (c) **do not satisfy the requirements they aim to cover.**

▌

Those implementing acts shall be adopted in accordance with the **examination** procedure referred to in Article **44(3)**.

**1a. In exceptional cases where the lack of cooperation by international** **standardisation organisations prevents European standardisation organisations** **from adopting relevant international standards as harmonised standards and that** **situation cannot be adequately mitigated by alternative measures, and where the** **condition set out in point (a) of paragraph 1 is met, the Commission may, as a** **measure of last resort, adopt implementing acts establishing common** **specifications without prior request to one or more European standardisation** **organisations to draft or revise harmonised standards.** **The draft implementing act shall be accompanied by a report justifying the** **exceptional situation and describing its implications for the internal market, the** **alternative measures which were taken and did not adequately mitigate the** **situation, and the reasons justifying the need to adopt common specifications. This** **report shall be presented to the Committee referred in paragraph 3.** **Within six months after the adoption of an implementing act pursuant to the first** **subparagraph, the Commission shall request, pursuant to Article 10(1) of** **Regulation (EU) No 1025/2012, one or more European standardisation** **organisations to draft or to revise harmonised standards for those requirements** **covered by the implementing act.** **The implementing acts referred to in the first subparagraph shall be adopted in** **accordance with the examination procedure referred to in Article 44(3). Where the** **committee delivers no opinion, the Commission shall not adopt the draft** **implementing act and Article 5(4), third subparagraph, of Regulation (EU)** **No 182/2011 shall apply.** **The implementing acts adopted pursuant to this paragraph shall be repealed or** **amended by the Commission in accordance with paragraph 5.** **This paragraph shall apply from... [date of transposition of this Directive].** **This paragraph shall cease to apply... [48 months after the date of transposition of** **this Directive].**

▌

2. Pressure equipment or assemblies that are in conformity with the common specification shall be presumed to be in conformity with essential **safety** requirements covered by those common specifications or parts thereof, set out in Annex I.;

**3. Before preparing the draft of the implementing act referred to in paragraphs 1 and** **1a of this Article, the Commission shall inform the committee referred to in Article** **22 of Regulation (EU) No 1025/2012 that it considers that the conditions in,** **respectively, paragraphs 1 and 1a of this Article are fulfilled.** **In cases referred to in paragraph 1a, the Commission shall present the justification** **report to the Committee and shall obtain the Committee’s opinion in writing.**

**4. When preparing the draft of the implementing acts referred to in paragraphs 1 and** **1a, the Commission shall take into account the views of the assigned expert** **group as well as of any other relevant bodies, and shall duly consult all relevant** **stakeholders.**

**5. Where a harmonised standard is adopted by a European standardisation** **organisation and proposed to the Commission for the purpose of publishing its** **reference in the Official Journal of the European Union, the Commission shall** **assess that standard in accordance with Regulation (EU) No 1025/2012. When the** **reference of a harmonised standard is published in the Official Journal of the** **European Union, the Commission shall repeal or amend the implementing acts** **referred to in paragraphs 1 and 1a, or parts thereof which cover the same** **requirements as those covered by that harmonised standard.**

**6. When a Member State or the European Parliament considers that a common** **specification or parts thereof does not entirely satisfy the essential safety** **requirements set out in Annex I which it covers, it shall inform the Commission** **thereof by submitting a detailed explanation. The Commission shall assess that** **detailed explanation and may, if appropriate, amend the implementing act** **establishing the common specification in question.’;’**

- (7) Article 14 is amended as follows:

  - (a) paragraph 8 is replaced by the following:

‘8. The records and correspondence relating to conformity assessment procedures shall be drafted, in electronic form, in an official language of the Member State where the body responsible for carrying out these conformity assessment procedures is established, or in a language accepted by that body.;’

  - (b) the following paragraph 9 is added:

‘9. The manufacturer shall provide the notified body carrying out the conformity assessment procedure with all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (8) in Article 15(5), the first sentence is replaced by the following:

‘The notified body which issued the European approval for materials shall withdraw that approval if it finds that it should not have been issued or if the type of materials is covered by a harmonised standard or common specifications.;’

- (9) in Article 17, the following paragraph 5 is added:

‘5. Where other Union legislation applicable to the pressure equipment or assembly requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required in Annex IV to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of conformity,** and the instructions **and safety information** referred to in Article 6(7)**, where provided in** **electronic form,** shall be provided only in that digital product passport.;’

- (10) in Article 24(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential safety requirements set out in Annex I, of the applicable harmonised standards **and** common specifications and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (11) in Article 25(7), point (c) is replaced by the following:

‘(c) appropriate knowledge and understanding of the essential safety requirements set out in Annex I, of the applicable harmonised standards **and** common specifications and of the relevant provisions of Union harmonisation legislation and of national legislation;’

- (12) in Article 34, paragraph 3 is replaced by the following:

‘3. Where a conformity assessment body finds that essential safety requirements set out in Annex I or corresponding harmonised standards or common specifications or other technical specifications have not been met by a manufacturer, it shall require that manufacturer to take appropriate corrective measures and shall not issue a certificate of conformity.;’

- (13) Annexes I, III and IV are amended in accordance with Annex XII to this Directive.

<a id="art-13"></a>
### Article 13 – Amendments to Directive 2014/90/EU

Directive 2014/90/EU is amended as follows:

- (1) in Article 2, the following point (14a) is inserted:

‘(14a) ‘digital contact’ means any up-to-date and **freely** accessible online communication channel **such as email addresses** through which economic operators can be **contacted** without the need to register or to download **or use additional applications** **specific to the economic operator**;’

- (2) Article 12 is amended as follows:

  - (a) paragraph 3 is replaced by the following:

‘3. Where the compliance of marine equipment with the applicable requirements has been demonstrated by the conformity assessment procedure, manufacturers shall draw up an EU declaration of conformity, in electronic form, in accordance with Article 16, and affix the wheel mark in accordance with Articles 9 and 10.;’

  - (b) paragraphs 7 and 8 are replaced by the following:

‘7. Manufacturers shall indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the product or, where that is not possible, on its packaging or in a document accompanying the product or both, as appropriate. The postal address and digital contact must indicate a single point through which the manufacturer can be **contacted**.

8. Manufacturers shall ensure that the product is accompanied by instructions and all necessary information for safe installation on board and safe use of the product, including limitations of use, if any, that can be easily understood by the end-users, together with any other documentation required by the international instruments or testing standards. The instructions and all the necessary information may be provided in electronic form.

In the case of products intended for consumers or that can, under reasonably foreseeable conditions, be used by consumers, even if not intended for them, the manufacturer shall provide, in paper format, or mark on the product, information for safe installation on board and safe use of the product, including limitations of use. Such safety information shall be easily visible and legible for consumers.

When drafting the instructions and information, the manufacturer shall take account of the intended use and foreseeable misuse by the end-user.

When the instructions **and information**, referred to in the first subparagraph, are provided in electronic form, manufacturers shall:

    - (a) mark on the product, or, where that is not possible, on its packaging or in an accompanying document, how to **directly** access them and how to request them in paper format;

    - (b) present them in a format that makes it possible for the end-user to print and download the instructions **and information** and save them on an electronic device so that the end-user can access them at all times, in particular during a breakdown of the product; this requirement also applies where the instructions **and information** are embedded in the software of the product;

    - (c) make them accessible online during the expected lifetime of the product and for at least 10 years after the placing on the market of the product.

However, the end-user may, at time of the purchase of the product, or up to **24** months after that purchase, request the instructions or information for safe installation on board and safe use of the product, including limitations of use in paper format. Where the end-user requests those instructions or information, the manufacturer shall provide them to the end-user, free of charge, within one month of receiving the request. **The information shall clearly inform the end-user of** **their right to request the instructions in paper format.’**

  - (c) in paragraph 10, the first sentence is replaced by the following:

‘Manufacturers shall, further to a reasoned request from a competent authority, promptly provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of the product, in a language which can be easily understood by or is acceptable to that authority, grant that authority access to their premises for market surveillance purposes in accordance with Article 19 of Regulation (EC) No 765/2008 and provide samples or access to samples in accordance with Article 25(4) of this Directive.;’

- (3) Article 13 is amended as follows:

  - (a) paragraph 1 is replaced by the following:

‘1. A manufacturer who is not located in the territory of at least one Member State shall, by a written mandate, appoint an authorised representative for the Union and shall indicate in the mandate the name of the authorised representative and the postal address and digital contact through which it can be **contacted**. ▌

  - (b) in paragraph 3, point (b) is replaced by the following:

‘(b) further to a reasoned request from a competent authority, provide that authority, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a product;’

- (4) Article 14 is amended as follows:

  - (a) paragraph 1 is replaced by the following:

‘1. Importers shall indicate their name, registered trade name or registered trademark as well as their postal address and digital contact on the product or, where that is not possible, on its packaging or in a document accompanying the product or both, as appropriate.;’

  - (b) in paragraph 2, the first sentence is replaced by the following:

‘Importers and distributors shall, further to a reasoned request from a competent authority, provide it, in electronic form, with all the information and documentation necessary to demonstrate the conformity of a product in a language which can be easily understood by, or is acceptable to, that authority.;’

- (5) in Article 15, the following paragraph 4 is added:

‘4. The manufacturer shall provide to the notified body carrying out the conformity assessment procedure all the information and documentation relating to conformity assessment procedures in electronic form.;’

- (6) Article 16 is amended as follows:

  - (a) in paragraph 4, the first sentence is replaced by the following:

‘When marine equipment is placed on **the market or for the first time on** board **of any** EU ship the manufacturer shall upload the EU declaration of conformity covering the equipment concerned onto the database set up by the Commission in accordance with Article 35(4).;’

  - (b) paragraph 5 is replaced by the following:

‘5. The EU declaration of conformity shall be provided to the notified body or to the bodies which carried out the relevant conformity assessment procedures via the database set up by the Commission in accordance with Article 35(4).;’

- (7) the following paragraph 6 is added:

‘6. Where other Union legislation applicable to the marine equipment requires the economic operator to include the information that the product complies with the requirements set out in that legislation in a digital product passport or to upload the EU declaration of conformity or instructions in a digital product passport, the information required Annex III to Decision No 768/2008/EC to be included in the EU declaration of conformity **or, as appropriate, the EU declaration of conformity,** **and** the instructions **and the necessary information for safe installation on board** **and safe use of the product, including limitations of use, if any,** referred to in Article 12(8)**, where provided in electronic form,** shall be provided only in that digital product passport.;’

- (8) in Article 29(1), point (f) is replaced by the following:

‘(f) the EU declaration of conformity has not been made accessible electronically to the ship;’

- (9) Annex II is amended in accordance with Annex XIII to this Directive.

<a id="art-14"></a>
### Article 14 – Transitional provision

Member States shall not impede the making available on the market of products which were placed on the market in accordance with Directives 2000/14/EC, 2011/65/EU, 2013/53/EU, 2014/29/EU, 2014/30/EU, 2014/31/EU, 2014/32/EU, 2014/33/EU, 2014/34/EU, 2014/35/EU, 2014/53/EU, 2014/68/EU and 2014/90/EU before [PO: Please insert the date set out in Article 15(1), second subparagraph].

<a id="art-15"></a>
### Article 15 – Transposition

1. Member States shall adopt and publish, by **... [24** months after **the date of** entry into force of this amending Directive] ▌, the laws, regulations and administrative provisions necessary to comply with this Directive. They shall forthwith communicate to the Commission the text of those provisions.

They shall apply those provisions from **... [24** months after **the date of** entry into force of this amending Directive].

However, Member States shall apply the following provisions from **... [30** months after **the** **date of** entry into force of this amending Directive]:

- (a) Article 1;

- (b) Article 2, point (1)(a), point (2)(a), (c) and(d), and points (3), (4), (5) and (6);

- (c) Article 3, point (1)(a), point (2)(a), (c) and(d), and points (3), (4), (5), (7) and (8);

- (d) Article 4, point (1)(a), point (2)(a), (c), (d) and(e), and points (3), (4) and (5), point (7)(b) and(c), and point (8);

- (e) Article 5, point (1)(a), point (2)(a), (c), (d) and(e), and points (3), (4), (5), (7) and (8);

- (f) Article 6, point (1)(a), point (2)(a), (c), (d) and (e), and points (3), (4), (5), (7) and (8);

- (g) Article 7, point (1)(a), point (2)(a), (c), (d) and(e), and points (3), (4), (5), (7), (9) and (12);

- (h) Article 8, point (1)(a), point (2), point (3)(a), (c), (d) and (e), and points (4) (5), (6), (8), (9), (10) and (13);

- (i) Article 9, point (1)(a), point (2)(a), (c), (d) and (e), and points (3), (4), (5), (7), (8) and (11);

- (j) Article 10, point (1)(a), point (2)(a), (c), (d) and (e), and points (3), (4), (5) and (7);

- (k) Article 11, point (1)(a), point (2)(a), (c), (d), (e) and (f), and points (3), (4) and (5), point (7)(c) and point (8);

- (l) Article 12, point (1)(a), point (2)(a), (c), (d) and(e), and points (3), (4), (5), (7) and (9);

- (m) Article 13;

- (n) **Annex** I;

- (o) Annex II, point (1) and point (2)(a);

- (p) Annex III, point (1)(a)(ii) and (b)(i), point (2)(a), point (3)(a) and point (4);

- (q) Annex IV, point (1)(a)(i) and(c), point (2) and point (3)(a);

- (r) Annex V, point (2)(a)(i) and (b) and point 3(a);

- (s) Annex VI, point (1)(a)(i),(c), (d) and(g) and point (2)(a);

- (t) Annex VII, point (1)(b)(i), first indent, (b)(iii), (d)(i), (e)(i), (f)(i), (g)(i), (k)(i), (l)(i), (l)(iv), first indent, and (l)(v), and point (2)(a);

- (u) Annex VIII, point (1)(a)(i), (a)(iii), (b)(i) and (b)(iii), point (2)(a)(i), (a)(v), (b)(i) and (b)(v), point (4)(a), point (5)(a), point (6)(a), point (7)(a), point (8)(a), point (9)(a) and point 10(a);

- (v) Annex IX, point (1), point (2)(a), (d) and(a), point 5(a) and point 8(a);

- (w) Annex X, point (2)(a);

- (x) Annex XI, point (1), point (2)(a)(i) and (b), point (3)(a), point (5)(a) and point (6);

- (y) Annex XII, point (2)(c)(i), first indent, (c)(iv), (c)(v), first indent, (c)(viii), (e)(i), (f)(ii), (g)(i), (h)(ii), (k)(i), (l)(i), (l)(v) and (l)(viii), and point (3)(a) and (c);

- (z) Annex XIII.

2. Member States shall communicate to the Commission the text of the main provisions of national law which they adopt in the field covered by this Directive.

<a id="art-16"></a>
### Article 16 – Entry into force

This Directive shall enter into force on the twentieth day following that of its publication in the Official Journal of the European Union.

<a id="art-17"></a>
### Article 17 – Addressees

This Directive is addressed to the Member States.

Done at Brussels,

For the European Parliament For the Council The President The President

<a id="annex-i"></a>
## Annex I

Annexes II and V to VIII to Directive 2000/14/EC are amended as follows:

- (1) Annex II is amended as follows:

  - (a) the first and second indents are replaced by the following:

‘— name, postal address and digital contact of the manufacturer or his authorised representative established in the Community

    - — name, postal address and digital contact of the person who keeps the technical documentation;’

  - (b) the fourth indent is replaced by the following:

‘— conformity assessment procedure followed, and, where appropriate, name, postal address and digital contact of the notified body involved;’

- (2) Annex V is amended as follows:

  - (a) in point 2, the third sentence is replaced by the following:

‘In this case he has to include the name, postal address and digital contact of this person in the EC declaration of conformity.;’

  - (b) in point 3, the first indent is replaced by the following:

‘— name, postal address and digital contact of the manufacturer or his authorised representative established in the Community;’

- (3) Annex VI is amended as follows:

  - (a) in point 2, the third sentence is replaced by the following:

‘In this case he has to include the name, postal address and digital contact of this person in the EC declaration of conformity.;’

  - (b) in point 3, the first indent is replaced by the following:

‘— name, postal address and digital contact of the manufacturer or his authorised representative established in the Community;’

- (4) in Annex VII, point 2, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact in addition;’

- (5) in Annex VIII, point 3.1, first indent, the first subindent is replaced by the following:

‘— name, postal address and digital contact of the manufacturer or his authorised representative established in the Community.’

<a id="annex-ii"></a>
## Annex II

Annexes V and VI to Directive 2011/65/EU are amended as follows:

- (1) in Annex V, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the applicant;’

- (2) Annex VI is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer or his authorised representative;’

  - (b) point 6 is replaced by the following:

‘6. Where applicable, references to the relevant harmonised standards or common specifications used or references to the technical specifications in relation to which conformity is declared:.’

<a id="annex-iii"></a>
## Annex III

Annexes I, III, IV and V to Directive 2013/53/EU are amended as follows:

- (1) Annex I is amended as follows:

  - (a) Part A is amended as follows:

    - (i) in point 2.1., the second subparagraph is replaced by the following:

‘Detailed requirements for the identification number referred to in the first paragraph are set out in the relevant harmonised standard or common specification.;’

    - (ii) in point 2.2, point (a) is replaced by the following:

‘(a) manufacturer’s name, registered trade name or registered trade mark and as well as the postal address and digital contact;’

  - (b) Part B is amended as follows

    - (i) in point 1.1, point (a) is replaced by the following:

‘(a) engine manufacturer’s name, registered trade name or registered trade mark as well as the postal address and digital contact; and, if applicable, the name, postal address and digital contact of the person adapting the engine;’

    - (ii) in point 2.3, the fourth subparagraph is replaced by the following:

‘Notified bodies may accept tests carried out on the basis of other tests cycles as specified in a harmonised standard or common specification and as applicable for the engine duty cycle.;’

    - (iii) in point 2.5, the second subparagraph is replaced by the following:

‘Notified bodies may accept tests carried out on the basis of other tests fuel as specified in a harmonised standard or common specification.;’

    - (iv) in point 4, point (b) is replaced by the following:

‘(b) specify the power of the engine when measured in accordance with the harmonised standard or common specification.;’

- (2) Annex III is amended as follows:

  - (a) points (a), and (b) are replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer;

    - (b) the name, postal address and digital contact of the representative of the manufacturer established in the Union or, if appropriate, of the person responsible for the placing on the market;’

  - (b) point (d) is replaced by the following:

‘(d) a statement that the partly completed watercraft complies with the essential requirements that apply at this stage of construction; this shall include references to the relevant harmonised standards or common specifications used, or references to **other technical** specifications in relation to which compliance is declared at this stage of construction; furthermore, it is intended to be completed by other legal or natural persons in full compliance with this Directive.;’

- (3) Annex IV is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer or his authorised representative [The authorised representative must also give the business name, postal address and digital contact of the manufacturer] or the private importer.;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared:;’

- (4) Annex V is amended as follows:

  - (a) in point 2, the first subparagraph is replaced by the following:

‘The person who is placing the product on the market or putting it into service shall lodge an application for a post-construction assessment of the product with a notified body and must provide the notified body, in electronic form, with the documents and technical file enabling the notified body to assess the conformity of the product with the requirements of this Directive and any available information on the use of the product after its first putting into service.;’

  - (b) in point 4.2, first subparagraph, the first sentence is replaced by the following:

‘The person who is placing the product on the market or putting it into service shall draw up, in electronic form, an EU declaration of conformity and keep it at the disposal of the national authorities for 10 years after the date the post-construction assessment certificate has been issued..’

<a id="annex-iv"></a>
## Annex IV

Annexes II, III and IV to Directive 2014/29/EU are amended as follows:

- (1) Annex II is amended as follows:

  - (a) point 1.3 is amended as follows::

    - (i) point (a) is replaced by the following

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

    - (ii) in point (c), point (iv) is replaced by the following:

‘(iv) a list of the harmonised standards applied in full or in part, the references of which have been published in the Official Journal of the European Union, or common specifications, and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential safety requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

    - (iii) in point (e), the second sentence is replaced by the following:

‘This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full.;’

  - (b) points 1.4.2., 1.4.3 and 1.4.4. are replaced by the following:

‘1.4.2. verify that the prototype vessel(s) has/have been manufactured in conformity with the technical documentation, that it may safely be used under its intended working conditions and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards or common specifications, as well as the elements which have been designed in accordance with other relevant technical specifications;

1.4.3 carry out appropriate examinations and tests, or have them carried out, to check whether, where the manufacturer has chosen to apply the solutions in the relevant harmonised standards or common specifications, these have been applied correctly;

1.4.4. carry out appropriate examinations and tests, or have them carried out, to check whether, where the solutions in the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the manufacturer applying other relevant technical specifications meet the corresponding essential safety requirements of this Directive;’

  - (c) in point 1.6, first paragraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

  - (d) in point 3.3., first subparagraph, the second sentence is replaced by the following:

‘An adequate sample of the final vessels, taken on site by the notified body before the placing on the market, shall be examined and appropriate tests as identified by the relevant parts of the harmonised standards, and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, shall be carried out to check the conformity of the vessel with the type described in the EU-type examination certificate and with the relevant requirements of this Directive.;’

- (2) in Annex III, point 1.2, point (e) is replaced by the following:

‘(e) the name, registered trade name or registered trade mark as well as the postal address and digital contact of the manufacturer;’

- (3) Annex IV is amended as follows

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer and, where applicable, his authorised representative:;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared:.’

<a id="annex-v"></a>
## Annex V

Annexes II, III and IV to Directive 2014/30/EU are amended as follows:

- (1) in Annex II, point 3, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

- (2) Annex III, Part A is amended as follows:

  - (a) point 3 is amended as follows:

    - (i) point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

    - (ii) in point (c), point (iv) is replaced by the following:

‘(iv) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications, and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

  - (b) in point 6, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the aspects of the essential requirements covered by the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

- (3) Annex IV is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer or his authorised representative:;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used, including the date of the standard or common specification, or references to the other technical specifications, including the date of the specification, in relation to which conformity is declared:.’

<a id="annex-vi"></a>
## Annex VI

Annexes II and IV to Directive 2014/31/EU are amended as follows:

- (1) Annex II is amended as follows:

  - (a) point 1.3 is amended as follows:

    - (i) point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

    - (ii) in point (c), point (iv) is replaced by the following:

‘(iv) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

    - (iii) in point (e), the second sentence is replaced by the following:

‘This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full.;’

  - (b) point 1.4.2, 1.4.3 and 1.4.4. are replaced by the following:

‘1.4.2. verify that the specimen(s) have been manufactured in conformity with the technical documentation, and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards or common specifications, as well as the elements which have been designed in accordance with other relevant technical specifications;

1.4.3. carry out appropriate examinations and tests, or have them carried out, to check whether, where the manufacturer has chosen to apply the solutions in the relevant harmonised standards or common specifications, these have been applied correctly;

1.4.4. carry out appropriate examinations and tests, or have them carried out, to check whether, where the solutions in the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the manufacturer applying other relevant technical specifications meet the corresponding essential requirements of this Directive;’

  - (c) in point 1.6, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

  - (d) in point 2.3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (f) in point 3.2., point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications, and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

  - (g) in point 3.5.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (i) point 4.4.1. is replaced by the following:

‘4.4.1. All instruments shall be individually examined and appropriate tests set out in the relevant harmonised standard(s), and/or in the relevant common specifications and/or other relevant technical specifications, shall be carried out in order to verify conformity with the approved type described in the EU-type examination certificate and with the appropriate requirements of this Directive.

In the absence of such a harmonised standard or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

  - (j) in point 5.2.1., point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

  - (k) point 5.5.1. is replaced by the following:

‘5.5.1. All instruments shall be individually examined and appropriate tests, set out in the relevant harmonised standards and/or equivalent tests set out in the relevant common specifications or other relevant technical specifications, shall be carried out to verify conformity with the requirements that apply to them. In the absence of such a harmonised standard or common specification the notified body concerned shall decide on the appropriate tests to be carried out.;’

  - (l) in point 6.2.1, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications, and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

  - (m) in point 6.4., the first subparagraph is replaced by the following:

‘A notified body chosen by the manufacturer shall carry out appropriate examinations and tests, set out in the relevant harmonised standards and/or in the relevant common specifications and/or other relevant technical specifications, to check the conformity of the instrument with the applicable requirements of this Directive, or have them carried out. In the absence of such a harmonised standard or common specification the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (2) Annex IV is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer and, where applicable, his authorised representative;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared:.’

<a id="annex-vii"></a>
## Annex VII

Annexes II and XIII to Directive 2014/32/EU are amended as follows:

- (1) Annex II is amended as follows:

- (a) in Module A2: INTERNAL PRODUCTION CONTROL PLUS SUPERVISED INSTRUMENT CHECKS AT RANDOM INTERVALS, point 4, first subparagraph, the second and third sentences are replaced by the following:

‘An adequate sample of the final measuring instruments, taken on site by the body before the placing on the market, shall be examined and appropriate tests as identified by the relevant parts of the harmonised standard, and/or normative document, and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, shall be carried out to verify the conformity of the instruments with the relevant requirements of this Directive. In the absence of a relevant harmonised standard or normative document or common specification, the accredited in-house body or notified body concerned shall decide on the appropriate tests to be carried out.;’

- (b) Module B: EU-TYPE EXAMINATION is amended as follows:

  - (i) point 3 is amended as follows

  - - point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - - point (e) is replaced by the following

‘(e) the supporting evidence for the adequacy of the technical design solution. This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards, and/or common specifications, and/or normative documents have not been applied in full. The supporting evidence shall include, where necessary, the results of tests carried out in accordance with other relevant technical specifications by the appropriate laboratory of the manufacturer, or by another testing laboratory on his behalf and under his responsibility.;’

  - (ii) in point 4, points 4.2, 4.3 and 4.4 are replaced by the following:

‘4.2. verify that the specimen(s) have been manufactured in conformity with the technical documentation and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards and/or normative documents, and/or common specifications, as well as the elements which have been designed in accordance with other relevant technical specifications;

4.3. carry out appropriate examinations and tests, or have them carried out, to check whether, where the manufacturer has chosen to apply the solutions in the relevant harmonised standards, normative documents, and common specifications, these have been applied correctly;

4.4. carry out appropriate examinations and tests, or have them carried out, to check whether, where the solutions in the relevant harmonised standards, and/or normative documents, and/or common specifications have not been applied, the solutions adopted by the manufacturer applying other relevant technical specifications meet the corresponding essential requirements of this Directive;’

  - (iii) in point 6, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

- (c) in Module C2: CONFORMITY TO TYPE BASED ON INTERNAL PRODUCTION CONTROL PLUS SUPERVISED INSTRUMENT CHECKS AT RANDOM INTERVALS, point 3, first subparagraph, the second sentence is replaced by the following:

‘An adequate sample of the final measuring instrument, taken on site by the accredited in-house body or by the notified body before the placing on the market, shall be examined and appropriate tests, as identified by the relevant parts of the harmonised standards, and/or normative documents, and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, shall be carried out to verify the conformity of the instrument with the type described in the EU-type examination certificate and with the relevant requirements of this Directive.;’

- (d) Module D: CONFORMITY TO TYPE BASED ON QUALITY ASSURANCE OF THE PRODUCTION PROCESS is amended as follows:

  - (i) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (e) Module D1: QUALITY ASSURANCE OF THE PRODUCTION PROCESS, is amended as follows:

  - (i) in point 5.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

- (f) Module E: CONFORMITY TO TYPE BASED ON PRODUCT QUALITY ASSURANCE is amended as follows:

  - (i) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

- (g) Module E1: QUALITY ASSURANCE OF FINAL INSTRUMENT INSPECTION AND TESTING is amended as follows:

  - (i) in point 5.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

- (h) Module F: CONFORMITY TO TYPE BASED ON PRODUCT VERIFICATION, is amended as follows:

  - (i) in point 4, point 4.1 is replaced by the following:

‘4.1. All measuring instruments shall be individually examined and appropriate tests set out in the relevant harmonised standard(s) and/or normative documents, and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, shall be carried out in order to verify their conformity with the approved type described in the EU-type examination certificate and with the appropriate requirements of this Directive.

In the absence of a harmonised standard or normative document or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

  - (ii) in point 5, point 5.2 is replaced by the following:

‘5.2. A random sample shall be taken from each lot according to the requirements of point 5.3. All measuring instruments in a sample shall be individually examined and appropriate tests set out in the relevant harmonised standard(s) and/or normative document(s), and/or common specification(s), and/or equivalent tests set out in other relevant technical specifications, shall be carried out in order to verify their conformity with the type described in the EU-type examination certificate and with the applicable requirements of this Directive, and to determine whether the lot is accepted or rejected. In the absence of such harmonised standard or normative document or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (i) Module F1: CONFORMITY BASED ON PRODUCT VERIFICATION, is amended as follows:

  - (i) In point 5, point 5.1 is replaced by the following:

‘5.1. All measuring instruments shall be individually examined and appropriate tests, set out in the relevant harmonised standards and/or normative documents, and/or common specifications and/or equivalent tests set out in other relevant technical specifications, shall be carried out to verify their conformity with the requirements that apply to them. In the absence of such a harmonised standard, or normative document, or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

  - (ii) in point 6, point 6.3 is replaced by the following:

‘6.3. All measuring instruments in the sample shall be individually examined and appropriate tests set out in the relevant harmonised standards and/or normative documents, and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, shall be carried out in order to verify their conformity with the applicable requirements of this Directive and to determine whether the lot is accepted or rejected. In the absence of such harmonised standard, or normative document, or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (j) in Module G: CONFORMITY BASED ON UNIT VERIFICATION, point 4, the first subparagraph is replaced by the following:

‘A notified body chosen by the manufacturer shall carry out the appropriate examinations and tests set out in the relevant harmonised standards, and/or normative documents, and/or common specifications or equivalent tests set out in other relevant technical specifications, to verify the conformity of the instrument with the applicable requirements of this Directive, or have them carried out. In the absence of such a harmonised standard, or normative document, or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (k) Module H: CONFORMITY BASED ON FULL QUALITY ASSURANCE, is amended as follows:

  - (i) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (ii) in point 3.2, point (b) is replaced by the following:

‘(b) the technical design specifications, including standards, that will be applied and, where the relevant harmonised standards, and/or normative documents, and/or common specifications will not be applied in full, the means that will be used to ensure that the essential requirements of this Directive that apply to the measuring instruments will be met applying other relevant technical specifications;’

- (l) Module H1: CONFORMITY BASED ON FULL QUALITY ASSURANCE PLUS DESIGN EXAMINATION is amended as follows:

  - (i) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (ii) in point 3.2., point (b) is replaced by the following:

‘(b) the technical design specifications, including standards, that will be applied and, where the relevant harmonised standards and/or normative documents, and/or common specifications will not be applied in full, the means that will be used to ensure that the essential requirements of this Directive that apply to the measuring instruments will be met, applying other relevant technical specifications;’

  - (iv) point 4.2 is amended as follows:

    - - point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer;’

    - - point (d) is replaced by the following:

‘(d) the supporting evidence for the adequacy of the technical design. This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards and/or normative documents, and/or common specifications have not been applied in full, and shall include, where necessary, the results of tests carried out in accordance with other relevant technical specifications, by the appropriate laboratory of the manufacturer, or by another testing laboratory on his behalf and under his responsibility.;’

  - (v) in point 4.3, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall give the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the data necessary for identification of the approved design.;’

- (2) Annex XIII is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer and, where applicable, his authorised representative;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or normative documents or common specifications used or references to the other technical specifications in relation to which conformity is declared:’.’

<a id="annex-viii"></a>
## Annex VIII

Annexes **II and** VI to XII to Directive 2014/33/EU are amended as follows:

- (1) Annex II is amended as follows:

  - (a) Part A is amended as follows:

    - (i) points (a) and (b) are replaced by the following:

‘(a) business name, postal address and digital contact of the manufacturer;

      - (b) where appropriate, business name, postal address and digital contact of the authorised representative;’

    - (ii) point (h) **is** replaced by the following:

‘(h) where appropriate, reference(s) to harmonised standard(s) or common specification(s) used;’

    - (iii) points (i) to (k) are replaced by the following:

‘(i) where appropriate, the name, postal address, digital contact and identification number of the notified body which carried out the EU-type examination of safety components for lifts set out in Annex IV, Part A and Annex VI, and the reference of the EU-type examination certificate issued by that notified body;

      - (j) where appropriate, the name, postal address, digital contact and identification number of the notified body which carried out the conformity to type with random checking for safety components for lifts set out in Annex IX;

      - (k) where appropriate, the name, postal address, digital contact and identification number of the notified body which approved the quality system operated by the manufacturer in accordance with the conformity assessment procedure set out in Annex VI or VII;’

  - (b) Part B is amended as follows:

    - (i) points (a) and (b) are replaced by the following:

‘(a) business name, postal address and digital contact of the installer;

      - (b) where appropriate, business name, postal address and digital contact of the authorised representative;’

    - (ii) **point** (g) is replaced by the following:

‘(g) where appropriate, reference(s) to harmonised standard(s) or common specifications used;’

    - (iii) points (h) to (k) are replaced by the following:

‘(h) where appropriate, the name, postal address, digital contact and identification number of the notified body which carried out the EU-type examination of lifts set out in Annex IV, Part B and the reference of the EU-type examination certificate issued by that notified body;

      - (i) where appropriate, the name, postal address, digital contact and identification number of the notified body which carried out the unit verification for lifts set out in Annex VIII;

      - (j) where appropriate, the name, postal address, digital contact and identification number of the notified body which carried out the final inspection for lifts set out in Annex V;

      - (k) where appropriate, the name, postal address, digital contact and identification number of the notified body which approved the quality assurance system operated by the installer in accordance with the conformity assessment procedure set out in Annex X, XI or XII;’;’

- (2) Annex IV is amended as follows:

  - (a) Part A is amended as follows:

    - (i) in point 2, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well and the place of manufacture of the safety components for lifts;’

    - (ii) in point 2(e), the second sentence is replaced by the following:

‘This supporting evidence shall mention any documents, including other relevant technical specifications, that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full.;’

    - (iii) in point 3, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to enable the safety component for lifts to meet the conditions referred to in point 1, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

    - (iv) in point 4, points (c), (d) and (e) are replaced by the following:

‘(c) verify that the representative specimen(s) has(have) been manufactured in conformity with the technical documentation, and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards or common specifications, as well as the elements which have been designed in accordance with other relevant technical specifications;

      - (d) carry out appropriate examinations and tests, or have them carried out, to check whether, where the manufacturer has chosen to apply the specifications of the relevant harmonised standards or common specifications, these have been applied correctly;

      - (e) carry out appropriate examinations and tests, or have them carried out, to check whether, where the specifications of the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the manufacturer applying other relevant technical specifications enable the safety component for lifts to meet the conditions referred to in point 1.;’

    - (v) in point 5, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the EU-type examination, any conditions of validity of the certificate and the particulars necessary to identify the approved type.;’

  - (b) Part B is amended as follows:

    - (i) in point 2, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the installer; and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

    - (ii) in point 2(e), the second sentence is replaced by the following:

‘This supporting evidence shall mention any documents, including other relevant technical specifications that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full.;’

    - (iii) in point 3, point (e) is replaced by the following:

‘(e) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential health and safety requirements of the Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

    - (iv) in point 4, points (c), (d) and (e) are replaced by the following:

‘(c) examine the specimen lift to check that it has been manufactured in accordance with the technical documentation, and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards or common specifications, as well as the elements which have been designed in accordance with other relevant technical specifications;

      - (d) carry out appropriate examinations and tests, or have them carried out, to check whether, where the installer has chosen to apply the specifications of the relevant harmonised standards or common specifications, these have been applied correctly;

      - (e) carry out appropriate examinations and tests, or have them carried out, to check whether, where the specifications of the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the installer applying other relevant technical specifications meet the corresponding essential health and safety requirements of this Directive.;’

    - (v) in point 6, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the installer, the conclusions of the EU-type examination, any conditions of validity of the certificate and the particulars necessary to identify the approved type.;’

- (3) Annex V is amended as follows:

  - (a) in point 2, point (b) is replaced by the following:

‘(b) a lift designed and manufactured in accordance with a quality system pursuant to Annex XI and the EU design examination certificate if the design is not wholly in accordance with the harmonised standards or common specifications.;’

  - (b) in point 3.1, the third subparagraph is replaced by the following:

‘The appropriate examinations and tests set out in the relevant harmonised standard(s) or common specifications, or equivalent tests shall be carried out in order to check the conformity of the lift with the applicable essential health and safety requirements set out in Annex I.;’

  - (c) in point 3.2, point (b) is replaced by the following:

‘(b) examination of the documents referred to in point 3.1 to check that the lift conforms with the lift designed and manufactured in accordance with an approved quality system pursuant to Annex XI and if the design is not wholly in accordance with the harmonised standards or common specifications, with the EU design examination certificate.;’

- (4) Annex VI, is amended as follows:

  - (a) point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

- (5) Annex VII is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (b) in point 3.2, point (b) is replaced by the following:

‘(b) the technical design specifications, including standards that will be applied and, where the relevant harmonised standards or common specifications will not be applied or not applied in full, the means, including other relevant technical specifications, that will be used to ensure that the conditions referred to in point 1 will be met;’

- (6) Annex VIII is amended as follows:

  - (a) in point 2.2, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the installer, and if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

    - (d) in point 3, point (e) is replaced by the following:

‘(e) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential health and safety requirements of the Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

  - (c) in point 4, first subparagraph, the first sentence is replaced by the following:

‘The notified body chosen by the installer shall examine the technical documentation and the lift and carry out the appropriate tests as set out in the relevant harmonised standard(s) or common specification(s), or equivalent tests, to check its conformity with the applicable essential health and safety requirements set out in Annex I.;’

- (7) Annex IX is amended as follows:

  - (a) in point 3, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (b) in point 4, first subparagraph, the second sentence is replaced by the following:

‘An adequate sample of the final safety components for lifts, taken on site by the notified body, shall be examined and appropriate tests set out in the relevant harmonised standards, and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, shall be carried out to check whether the safety components for lifts meets the conditions referred to in point 1.;’

- (8) Annex X is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the installer, and if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

- (9) Annex XI is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the installer, and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (b) in point 3.2, point (b) is replaced by the following:

‘(b) the technical design specifications, including standards that will be applied and, where the relevant harmonised standards or common specifications will not be applied in full, the means, including other relevant technical specifications that will be used to ensure that the applicable essential health and safety requirements set out in Annex I will be met;’

  - (c) in point 3.3, point 3.3.1 is replaced by the following:

‘3.3.1. When the design is not entirely in accordance with harmonised standards or common specifications, the notified body shall ascertain whether the design conforms to the essential health and safety requirements set out in Annex I and, if it does, issue an EU design examination certificate to the installer, stating the limits of the certificate’s validity and giving the details required for identification of the approved design.;’

- (10) Annex XII is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the installer, and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

<a id="annex-ix"></a>
## Annex IX

Annexes II to V and VII to X to Directive 2014/34/EU are amended as follows:

- (1) in Annex II, point 1.0.5, the first indent is replaced by the following:

‘— name, registered trade name or registered trade mark as well as postal address and digital contact of the manufacturer,;’

- (2) Annex III is amended as follows:

  - (a) in point 3, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

  - (b) in point 3, point (c), point (iv) is replaced by the following:

‘(iv) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential health and safety requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,’

  - (c) in point 4, points 4.1, 4.2, and 4.3 are replaced by the following:

‘4.1. examine the technical documentation, verify that the specimen(s) have been manufactured in conformity with the technical documentation, and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards or common specifications, as well as the elements which have been designed in accordance with other relevant technical specifications;

4.2. carry out appropriate examinations and tests, or have them carried out, to check whether, where the manufacturer has chosen to apply the solutions in the relevant harmonised standards or common specifications, these have been applied correctly;

4.3. carry out appropriate examinations and tests, or have them carried out, to check whether, where the solutions in the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the manufacturer applying other relevant technical specifications meet the corresponding essential health and safety requirements of this Directive;’

  - (d) in point 6, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

- (3) Annex IV is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (4) in Annex V, point 4, point 4.1 is replaced by the following:

‘4.1. All products shall be individually examined and appropriate tests set out in the relevant harmonised standard(s) and/or common specification(s) and/or equivalent tests set out in other relevant technical specifications, shall be carried out in order to verify conformity with the approved type described in the EU-type examination certificate and with the appropriate requirements of this Directive.

In the absence of such a harmonised standard or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (5) Annex VII is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (6) in Annex VIII, point 2, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential health and safety requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

- (7) Annex IX is amended as follows:

  - (a) in point 2.1, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential health and safety requirements of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (b) in point 4, the first subparagraph is replaced by the following:

‘A notified body chosen by the manufacturer shall carry out appropriate examinations and tests, set out in the relevant harmonised standards and/or common specifications, and/or equivalent tests set out in other relevant technical specifications, to check the conformity of the product with the applicable requirements of this Directive, or have them carried out. In the absence of such a harmonised standard or common specification the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (8) Annex X is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer and, where applicable, his authorised representative:;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared:.’

<a id="annex-x"></a>
## Annex X

Annexes III and IV to Directive 2014/35/EU are amended as follows:

- (1) in Annex III, point 2, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union or international or national standards referred to in Articles 13 and 14 or common specifications referred to in Article 12a and, where those harmonised standards or international or national standards or common specifications have not been applied, descriptions of the solutions adopted to meet the safety objectives of this Directive, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or international or national standards referred to in Articles 13 and 14 or common specifications, the technical documentation shall specify the parts which have been applied;’

- (2) Annex IV is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer or his authorised representative:;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared:.’

<a id="annex-xi"></a>
## Annex XI

Annexes Ia, and III to VII to Directive 2014/53/EU are amended as follows:

- (1) in Annex Ia, Part II, the introductory sentence is replaced by the following:

‘In the case of radio equipment falling within the scope of Article 3(4), first subparagraph, the following information shall be indicated in accordance with the requirements set out in Article 10(8):;’

- (2) Annex III, Module B: EU-type examination, is amended as follows:

  - (a) point 3 is amended as follows:

    - (i) point (a) and (d) are replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

    - (ii) in point (d), the second sentence is replaced by the following:

‘That supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards or common specifications have not been applied or have not been fully applied.;’

  - (b) in point 6, first subparagraph, the second sentence is replaced by the following:

‘That certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the aspects of the essential requirements covered by the examination, the conditions (if any) for its validity and the necessary data for identification of the assessed type.;’

  - (c) in point 8, third subparagraph, the first sentence is replaced by the following:

‘Each notified body shall inform the Member States of EU-type examination certificates it has issued and/or additions thereto in those cases where harmonised standards the references of which have been published in the Official Journal of the European Union or common specifications have not been applied or not been fully applied.;’

- (3) Annex IV is amended as follows:

  - (a) in point 3.1, point (a) is replaced by the following:

‘(a) the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well;’

  - (b) in point 3.2, point (b) is replaced by the following:

‘(b) the technical design specifications, including standards, that will be applied and, where the relevant harmonised standards or common specifications will not be applied in full, the means that will be used to ensure that the essential requirements of this Directive that apply to the radio equipment will be met;’

- (4) in Annex V, point (d) is replaced by the following:

‘(d) a list of the harmonised standards applied in full or in part the references of which have been published in the Official Journal of the European Union, or common specifications and, where those harmonised standards or common specifications have not been applied, descriptions of the solutions adopted to meet the essential requirements set out in Article 3, including a list of other relevant technical specifications applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied;’

- (5) Annex VI is amended as follows:

  - (a) point 2 is replaced by the following:

‘2. Name, postal address and digital contact of the manufacturer or his authorised representative:;’

  - (b) in point 6, the first sentence is replaced by the following:

‘References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared.;’

- (6) Annex VII is deleted.

<a id="annex-xii"></a>
## Annex XII

Annexes I, III and IV to Directive 2014/68/EU are amended as follows:

- (1) Annex I is amended as follows:

  - (a) in point 3.1.2, the fifth subparagraph is replaced by the following:

‘To carry out these approvals the third party must perform examinations and tests as set out in the appropriate harmonised standards or common specifications or equivalent examinations and tests or shall have them performed.;’

  - (b) in point 4.2., point (b), the first indent is replaced by the following:

‘— by using materials which comply with harmonised standards or common specifications,;’

  - (c) in point 7, first subparagraph, the second sentence is replaced by the following:

‘However, where they are not applied, including in cases where materials are not specifically referred to and no harmonised standards or common specifications are applied, the manufacturer shall demonstrate that appropriate measures have been taken to achieve an equivalent overall level of safety.;’

- (2) Annex III is amended as follows:

- (a) in Part 1: Module A: (INTERNAL PRODUCTION CONTROL), point 2, the fourth indent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and a description of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

- (b) in Part 2: Module A2: INTERNAL PRODUCTION CONTROL PLUS SUPERVISED PRESSURE EQUIPMENT CHECKS AT RANDOM INTERVALS, point 2, the fourth indent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

- (c) Part 3: Module B: EU-TYPE EXAMINATION is amended as follows:

  - (i) in point 3.1 EU-Type examination – production type, point 3 is amended as follows:

    - - in the second subparagraph, the first indent is replaced by the following:

‘- the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

    - - in the second subparagraph, third indent, fourth subindent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

    - - in the fourth subparagraph, only indent, the second sentence is replaced by the following:

‘This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full.;’

  - (ii) in point 4.1, second subparagraph, the first indent is replaced by the following:

‘— assess the materials where these are not in conformity with the relevant harmonised standards or common specifications or with a European approval for pressure equipment materials, and check the certificate issued by the material manufacturer in accordance with point 4.3 of Annex I,;’

  - (iii) points 4.2., 4.3. and 4.4. are replaced by the following:

‘4.2. verify that the specimen(s) have been manufactured in conformity with the technical documentation and identify the elements which have been designed in accordance with the applicable provisions of the relevant harmonised standards or common specifications as well as the elements which have been designed using other relevant technical specifications without applying the relevant provisions of those standards.

4.3. carry out appropriate examinations and necessary tests to check whether when the manufacturer has chosen to apply the solutions the relevant harmonised standards or common specifications, these have been applied correctly.

4.4. carry out appropriate examinations and necessary tests to check whether, where the solutions in the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the manufacturer applying other relevant technical specifications meet the corresponding essential safety requirements of this Directive.;’

  - (iv) in point 6, first subparagraph, the second sentence is replaced by the following:

‘Without prejudice to point 7, the certificate shall be valid for 10 years and be renewable and shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

  - (v) in point 3.2. EU-Type examination – design type, point 3 is amended as follows:

    - - in the second subparagraph, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

  - - in the second subparagraph, third indent, the fourth subindent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - - in the second subparagraph, fourth indent, the second sentence is replaced by the following:

‘This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full.;’

  - (vi) in point 4.1., second subparagraph, the first indent is replaced by the following:

‘— assess the materials where these are not in conformity with the relevant harmonised standards or common specifications or with a European approval for pressure equipment materials,;’

  - (vii) points 4.2. and 4.3. are replaced by the following:

‘4.2. carry out appropriate examinations to check whether where the manufacturer has chosen to apply the solutions in the relevant harmonised standards or common specifications these have been applied correctly.

4.3. carry out appropriate examinations to check whether, where the solutions in the relevant harmonised standards or common specifications have not been applied, the solutions adopted by the manufacturer meet the corresponding essential safety requirements of this Directive.;’

  - (viii) in point 6, first subparagraph, the second sentence is replaced by the following:

‘Without prejudice to point 7, the certificate shall be valid for 10 years and be renewable and shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved design.;’

- (d) in Part 4: MODULE C2: CONFORMITY TO TYPE BASED ON INTERNAL PRODUCTION CONTROL PLUS SUPERVISED PRESSURE EQUIPMENT CHECKS AT RANDOM INTERVALS, point 3, the third subparagraph is replaced by the following:

‘An adequate sample of the final pressure equipment, taken on site by the notified body before the placing on the market, shall be examined and appropriate tests as identified by the relevant parts of the harmonised standards, and/or common specifications, and/or equivalent tests applying other technical specifications, shall be carried out to check the conformity of the pressure equipment with the relevant requirements of this Directive.;’

- (e) Part 5: MODULE D: CONFORMITY TO TYPE BASED ON QUALITY ASSURANCE OF THE PRODUCTION PROCESS is amended as follows:

  - (i) in point 3.1, second subparagraph, the first indent is replaced by the following:

‘- the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (f) Part 6: MODULE D1: QUALITY ASSURANCE OF THE PRODUCTION PROCESS is amended as follows:

  - (i) in point 2, first subparagraph, the fourth indent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (ii) in point 5.1, second subparagraph, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (g) Part 7: MODULE E: CONFORMITY TO TYPE BASED ON PRESSURE EQUIPMENT QUALITY ASSURANCE is amended as follows:

  - (i) in point 3.1, second subparagraph, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (h) Part 8: MODULE E1: QUALITY ASSURANCE OF FINAL PRESSURE EQUIPMENT INSPECTION AND TESTING is amended as follows:

  - (i) in point 2, first subparagraph, the fourth indent is replaced by the following:

‘— a list of the harmonised standards, the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (ii) in point 5.1, second subparagraph, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

- (i) in Part 9: MODULE F: CONFORMITY TO TYPE BASED ON PRESSURE EQUIPMENT VERIFICATION, point 4.1., the first subparagraph is replaced by the following:

‘All pressure equipment shall be individually examined and appropriate tests set out in the relevant harmonised standard(s) or common specifications or equivalent tests shall be carried out in order to verify conformity with the approved type and described in the EU-type examination certificate and with the appropriate requirements of this Directive. In the absence of such a harmonised standard or common specification, the notified body concerned shall decide on the appropriate tests to be carried out.;’

- (j) Part 10: MODULE G: CONFORMITY BASED ON UNIT VERIFICATION is amended as follows:

  - (i) in point 2, third subparagraph, the fourth indent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications, have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (ii) in point 4, the first subparagraph is replaced by the following:

‘A notified body chosen by the manufacturer shall carry out appropriate examinations and tests, set out in the relevant harmonised standard(s), and/or common specifications, and/or equivalent tests, to check the conformity of the pressure equipment with the applicable requirements of this Directive, or have them carried out. In the absence of such a harmonised standard or common specification the notified body concerned shall decide on the appropriate tests to be carried out applying other technical specifications.;’

  - (iii) in point 4, second subparagraph, the second indent is replaced by the following:

‘— assess the materials used where these are not in conformity with the relevant harmonised standards or common specifications or with a European approval for pressure equipment materials, and check the certificate issued by the material manufacturer in accordance with point 4.3 of Annex I,;’

- (k) Part 11: MODULE H: CONFORMITY BASED ON FULL QUALITY ASSURANCE is amended as follows:

  - (i) point 3.1, second subparagraph, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

  - (ii) in point 3.1, second subparagraph, second indent, the fourth subindent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (iii) in point 3.2, third subparagraph, the second indent is replaced by the following:

‘— the technical design specifications, including standards, that will be applied and, where the relevant harmonised standards or common specifications will not be applied in full, the means that will be used to ensure that the essential requirements of this Directive that apply to the pressure equipment will be met,;’

- (l) Part 12: MODULE H1: CONFORMITY BASED ON FULL QUALITY ASSURANCE PLUS DESIGN EXAMINATION is amended as follows:

  - (i) in point 3.1, second subparagraph, the first indent is replaced by the following:

‘- the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, his name, postal address and digital contact as well,;’

  - (ii) in point 3.1, second subparagraph, second indent, the fourth subindent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (iii) in point 3.2, third subparagraph, the second indent is replaced by the following:

‘— the technical design specifications, including standards, that will be applied and, where relevant harmonised standards or common specifications will not be applied in full, the means that will be used to ensure that the essential safety requirements of the Directive that apply to the pressure equipment will be met,;’

  - (v) in point 4.2, the first indent is replaced by the following:

‘— the name, postal address and digital contact of the manufacturer,;’

  - (vi) in point 4.2, third indent, the fourth subindent is replaced by the following:

‘— a list of the harmonised standards the references of which have been published in the Official Journal of the European Union, or common specifications, applied in full or in part, and descriptions of the solutions adopted to meet the essential safety requirements of this Directive, where those harmonised standards or common specifications have not been applied. In the event of partly applied harmonised standards or common specifications, the technical documentation shall specify the parts which have been applied,;’

  - (vii) in point 4.2, the fourth indent is replaced by the following:

‘— the supporting evidence for the adequacy of the technical design. This supporting evidence shall mention any documents that have been used, in particular where the relevant harmonised standards or common specifications have not been applied in full, and shall include, where necessary, the results of tests carried out by the appropriate laboratory of the manufacturer or by another testing laboratory on his behalf and under his responsibility.;’

  - (viii) in point 4.3, first subparagraph, the second sentence is replaced by the following:

‘The certificate shall give the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the data necessary for identification of the approved design.;’

- (3) Annex IV is amended as follows:

  - (a) point 1 is replaced by the following:

‘1. Name, postal address and digital contact of the manufacturer and, where applicable, his authorised representative:;’

  - (b) point 6 is replaced by the following:

‘6. References to the relevant harmonised standards or common specifications used or references to the other technical specifications in relation to which conformity is declared:;’

  - (c) point 7 is replaced by the following:

‘7. Where appropriate, the name, postal address, digital contact and number of the notified body which carried out the conformity assessment and the number of the certificate issued, and a reference to the EU-type examination certificate – production type, EU-type examination certificate – design type, EU design examination certificate or certificate of conformity..’

<a id="annex-xiii"></a>
## Annex XIII

Annex II to Directive 2014/90/EU is amended as follows:

- (1) Part I: Module B: EC-TYPE EXAMINATION is amended as follows:

  - (a) in point 3, second subparagraph, the first indent is replaced by the following:

‘- the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, its name, postal address and digital contact as well;’

  - (b) in point 6, first subparagraph, the second sentence is replaced by the following:

‘The certificate shall contain the name, postal address and digital contact of the manufacturer, the conclusions of the examination, the conditions (if any) for its validity and the necessary data for identification of the approved type.;’

- (2) in Part II: Module D: CONFORMITY TO TYPE BASED ON QUALITY ASSURANCE OF THE PRODUCTION PROCESS, point 3.1, second subparagraph, the first indent is replaced by the following:

‘- the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, its name, postal address and digital contact as well;’

- (3) in Part III: Module E: CONFORMITY TO TYPE BASED ON PRODUCT QUALITY ASSURANCE, point 3.1, second subparagraph, the first indent is replaced by the following:

‘- the name, postal address and digital contact of the manufacturer and, if the application is lodged by the authorised representative, its name, postal address and digital contact as well.’

## Notes

^(1) Opinion of... (not yet published in the Official Journal).

^(12) Directive 2014/53/EU of the European Parliament and of the Council of 16 April 2014 on the harmonisation of the laws of the Member States relating to the making available on the market of radio equipment and repealing Directive 1999/5/EC (OJ L 153, 22.5.2014, p. 62, ELI: http://data.europa.eu/eli/dir/2014/53/oj).

^(13) Directive 2014/68/EU of the European Parliament and of the Council of 15 May 2014 on the harmonisation of the laws of the Member States relating to the making available on the market of pressure equipment (OJ L 189, 27.6.2014, p. 164, ELI: http://data.europa.eu/eli/dir/2014/68/oj).

^(14) Directive 2014/90/EU of the European Parliament and of the Council of 23 July 2014 on marine equipment and repealing Council Directive 96/98/EC (OJ L 257, 28.8.2014, p. 146, ELI: http://data.europa.eu/eli/dir/2014/90/oj).

^(15) Decision No 768/2008/EC of the European Parliament and of the Council of 9 July 2008 on a common framework for the marketing of products, and repealing Council Decision 93/465/EEC (OJ L 218, 13.8.2008, p. 82, ELI: http://data.europa.eu/eli/dec/2008/768(1)/oj).

^(16) Regulation (EU) No 1025/2012 of the European Parliament and of the Council of 25 October 2012 on European standardisation, amending Council Directives 89/686/EEC and 93/15/EEC and Directives 94/9/EC, 94/25/EC, 95/16/EC, 97/23/EC, 98/34/EC, 2004/22/EC, 2007/23/EC, 2009/23/EC and 2009/105/EC of the European Parliament and of the Council and repealing Council Decision 87/95/EEC and Decision No 1673/2006/EC of the European Parliament and of the Council (OJ L 316, 14.11.2012, p. 12, ELI: http://data.europa.eu/eli/reg/2012/1025/oj).

^(17) Regulation (EU) 2023/1542 of the European Parliament and of the Council of 12 July

^(2023) concerning batteries and waste batteries, amending Directive 2008/98/EC and Regulation (EU) 2019/1020 and repealing Directive 2006/66/EC (OJ L 191, 28.7.2023, p. 1, ELI: http://data.europa.eu/eli/reg/2023/1542/oj).
